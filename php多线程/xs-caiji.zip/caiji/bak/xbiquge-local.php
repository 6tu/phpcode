<?php
$base_path = $_SERVER['DOCUMENT_ROOT'];
$base_path = '/home/www/html/book/';
$path = getcwd();
$path = $path . '\51687';
$srcpath = $path . '-src\\';
$path = $path . '\\';
$chaset = 'gbk';
$div = 'div.content_read';

$foot = '<div class="footer_cont">
    <p>小说<a href="https://www.xbiquge.cc/book/51687/" title="极品赘婿">极品赘婿</a>所有内容均来自互联网，笔趣阁只为原作者二五八的小说进行宣传。欢迎各位书友支持二五八并收藏<a href="https://www.xbiquge.cc/book/51687/" title="极品赘婿">极品赘婿最新章节</a>。</p>
    </div>';
$list = file_get_contents($base_path . 'newurl.txt');
$array = explode("\r\n", $list);
foreach($array as $fn){
	$src = $srcpath . $fn;
	$new = $path . $fn;
	$body = caiji_info($src, $chaset, $div);
	$array1 = explode('<div id="content" name="content">', $body);
	$array2 = explode('<div class="tjlist"', $array1[0]);
	$body = $array2[0] .'<div id="content" name="content">'. $array1[1];
	# 删除js
    $preg = "/<script[\s\S]*?<\/script>/i";
    $html = preg_replace($preg, "", $body, -1);
	$html = str_replace("https://www.xbiquge.cc", "", $html);
	$html .= $foot;
	file_put_contents($new, $html);
}

function caiji_info($url, $chaset, $div){
    if(empty($url)) die('url is empty');
    if(empty($chaset)) $chaset = 'gbk';
    if(empty($div)) $div = 'div#maininfo';
    require_once('./lib/phpQuery/phpQuery.php');
    phpQuery :: $defaultCharset = $chaset;
    $html = phpQuery :: newDocumentFile($url);
    // $html = phpQuery::newDocument($html);
    $title = pq("title") -> text();
    $maininfo = pq($div) -> html();
    if($chaset == 'gbk') $maininfo = mb_convert_encoding($maininfo, 'utf-8', 'GBK');
    $head = '<!DOCTYPE html><html lang="zh-CN">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" type="text/css" href="/book/biqugecss/common.css" />
    <link rel="stylesheet" type="text/css" href="/book/biqugecss/read.css" />';
    $head .= '        <title>' . $title . '</title>
	</head>
	<body>';
    $output = $head . $maininfo;
    return $output;
}

?>