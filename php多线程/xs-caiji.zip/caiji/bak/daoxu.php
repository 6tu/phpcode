<?php
$c = file_get_contents('index.html');
$array = explode("\r\n", $c);
$arr = array_reverse($array);
$str = join($arr);
$str = str_replace('</dd><dd>', "</dd>\r\n<dd>", $str);
$str = str_replace('</dd><dl>', "</dd>\r\n<dl>", $str);
$str = str_replace('</dl><dd>', "</dl>\r\n<dd>", $str);
file_put_contents('xindex.html', $str);
?>