<?php

$url = 'http://pub.6tu.me/caiji/suyun.php';

date_default_timezone_set('Asia/Hong_Kong');
// $showtime = date("Y-m-d H:i:s");
$today = getdate();
// print_r($today);
$sec = $today['seconds'];
$min = $today['minutes'];
$hou = $today['hours'];
$day = $today['mday'];
$mon = $today['mon'];
$year = $today['year'];

if(8 < $hou and $hou < 19){
    $refer = 'http://pub.6tu.me/caiji/cron.php';
    $option = array('http' => array('header' => "Referer:$refer"));
    $c = file_get_contents($url, false, stream_context_create($option));
    $arr = explode("\r\n", $c);
    echo "回馈信息: $arr[0]";
    file_put_contents('./log/cron.log', $day . $hou . $min . $sec . "\r\n", FILE_APPEND);
    // system('/opt/lampp/bin/php-f/home/www/caiji/suyun.php', $re);
    // system('cd/home/www/caiji&&/opt/lampp/bin/php-f/home/www/caiji/suyun.php', $re);
    // echo $re;
}
echo "It is all done";
?>
