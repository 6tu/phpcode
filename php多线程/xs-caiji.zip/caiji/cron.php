<?php

$url = 'http://pub.6tu.me/caiji/suyun.php';

date_default_timezone_set('Asia/Hong_Kong');
// $showtime = date("Y-m-d H:i:s");
$today = getdate();
// print_r($today);
$sec = $today['seconds'];
$min = $today['minutes'];
$hou = $today['hours'];
$day = $today['mday'];
$mon = $today['mon'];
$year = $today['year'];
$time_key = $day . $hou . $min . $sec;
if(8 < $hou and $hou < 17){
    $refer = 'http://pub.6tu.me/caiji/cron.php';
    $option = array('http' => array('header' => "Referer:$refer"));
    $c = file_get_contents($url, false, stream_context_create($option));
    $arr = explode("\r\n", $c);
    echo "<pre>回馈信息: $arr[0]\r\n";
    file_put_contents('/home/www/caiji/log/cron.log',  $time_key. "\r\n", FILE_APPEND);
}
echo "It is all done";
?>
