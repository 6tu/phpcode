<?php
# wget 出错，一般是网址末端包含特殊符号造成的

set_time_limit(0);
date_default_timezone_set ('Asia/Hong_Kong');
$base_path = '/home/www/book/';
$base_path = $_SERVER['DOCUMENT_ROOT'] . '/book/';
$base_url = 'http://pub.6tu.me/book/';

$remote_full = file_get_contents($base_url . 'all.txt');

# 生成本地文件列表
$dirarr = scandir($base_path . '51687');
// print_r($dirarr);
$all = '';
foreach($dirarr as $v){
    if($v!='.' && $v!='..'){
       $all .= $v . "\r\n";
    }
}
file_put_contents($base_path . 'all.txt', $all);
//file_put_contents('test.html', print_r($array[1], true));

echo '<pre>';
echo "本地文件统计完毕<br>\r\n";
echo "远端文件获取完毕<br>\r\n";

# 比对出剩余链接
$local = file_get_contents($base_path . 'all.txt');
$arr = explode("\r\n", $remote_full);
// print_r($arr);
$newurl = '';
foreach($arr as $v){
    if(empty($v)) continue;
    if(strpos($local, $v) !== false) continue;
    $v = $base_url .'51687/'. $v;
    $newurl .= $v ."\r\n";
}
file_put_contents($base_path . 'newurl.txt', $newurl);
if(empty($newurl)) die("没有更新的文件.<br>\r\n");
echo "筛选后的 URL 是:<br>\r\n$newurl\r\n";

$new_arr = explode("\n", $newurl);
foreach($new_arr as $v){
    $v = preg_replace ( "/\s(?=\s)/","\\1",$v);
    $v = trim($v);
    if(empty($v)) continue;
    $cmd = '/usr/bin/wget -P '. $base_path . '51687/ '. $v;
    system($cmd);
    echo $cmd . "\r\n";
}
$cmd = '/usr/bin/wget -O index.html -P '. $base_path . '51687/ '. $base_url .'51687/index.html';
system($cmd);
echo "命令执行完毕，相关文件已经被更新<br>\r\n";
