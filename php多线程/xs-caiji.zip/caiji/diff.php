<?php
# wget出错,一般是网址末端包含特殊符号造成的
# 数组保存到文件
// file_put_contents($base_path . 'all.txt', print_r($array[1], true));
// $cmd = '/usr/bin/wget -O ' . $base_path . '51687/index.html ' . $base_url . '51687/index.html';


set_time_limit(0);
date_default_timezone_set('Asia/Hong_Kong');
$base_path = '/home/www/book/';
$base_path = $_SERVER['DOCUMENT_ROOT'] . '/book/';
$base_url = 'http://pub.6tu.me/book/';

# 下载远端的index.html,然后从其中提取超链接
# 这样既更新了index.html又获取了按照章节排序的文件列表
// $index = file_get_contents($base_url . '51687/index.html');
// file_put_contents($base_path . '51687/index.html', $index);
$index = file_get_contents('http://127.0.0.1/book/51687/index.html');
preg_match_all('/<a[^<]+href="(.+?)"/is', $index, $m);
$remote_full = join($m[1]);
$remote_full = str_replace('.html', ".html\r\n", $remote_full);
$array_index = explode("\n", $index);
$last_v750 = '';
foreach($array_index as $_v){
    if(empty($_v)) continue;
    if(strpos($_v, '.html') == false) continue;
    if(strpos($_v, '34578864.html') !== false) break;
    $last_v750 .= $_v;
}
echo $last_v750. "<br>\r\n";
echo "<pre>远端文件列表提取完成<br>\r\n";

# 生成本地文件列表
$dirarr = scandir($base_path . '51687');
$local = '';
foreach($dirarr as $v){
    if($v != '.' && $v != '..') $local .= $v . "\r\n";
}
echo "本地文件统计完毕<br>\r\n";

# 比对出剩余链接
$arr = explode("\r\n", $remote_full);
$newurl = '';
foreach($arr as $v){
    if(empty($v)) continue;
    if(strpos($local, $v) !== false) continue;
    $newurl .= $v . "\r\n";
}
if(empty($newurl)) die("没有更新的文件.<br>\r\n");
$n = substr_count($newurl, ".html");
$num = $n + 1;
echo "更新的<b> $num 条</b>链接是:<br>\r\n$newurl";

$newurl = '';
foreach($m[1] as $key => $value){
    $value = preg_replace("/\s(?=\s)/", "\\1", $value);
    $value = trim($value);
    if(empty($value)) continue;
    $value = $base_url . '51687/' . $value;
    $cmd = '/usr/bin/wget -P ' . $base_path . '51687/ ' . $value;
    system($cmd);
    echo $cmd . "\r\n";
    if($key == $n) break;
    $newurl .= $value . "\r\n";
}
echo "\r\n命令执行完毕,相关文件已经被更新<br>\r\n";

file_put_contents($base_path . 'newurl.txt', $newurl);
