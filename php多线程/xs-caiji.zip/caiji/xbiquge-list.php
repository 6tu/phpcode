<?php

# 获取文章目录
set_time_limit(0);
$base_path = $_SERVER['DOCUMENT_ROOT'];
$base_path = '/home/www/book/';
$url = 'https://www.xbiquge.cc/book/51687/';
$start = '750';

echo "<pre><font size='4'>\r\nIt is recommended to run suyun.php first.<br>\r\n";

$dirarr = scandir($base_path . '51687');
// print_r($dirarr);
$all = '';
foreach($dirarr as $v){
    if($v!='.' && $v!='..'){
       $all .= $v . "\r\n";
    }
}
file_put_contents($base_path . 'all.txt', $all);
echo "Directory read complete. <br>\r\n";

$chaset = 'gbk';
$div = 'div#list';
$list = caiji_info($url, $chaset, $div);
$list = str_replace("'", '"', $list);
$array = explode('</dt>', $list);
$arr = explode("\n", $array[1]);

# 重新排序后写入index.html文件
$arr_list = array_reverse($arr);
$str = join($arr_list);
$str = $array[0] .'</dt>'. $str . "\r\n</dl>";
$str = str_replace('</dd><dd>', "</dd>\r\n<dd>", $str);
$str = str_replace('</dt></dl>', "</dt>\r\n", $str);
$str = str_replace("           <dl>\n", "\r\n<dl>", $str);
//file_put_contents('test.html', print_r($array[1], true));
file_put_contents($base_path . '51687/index.html', $str);
echo "The index file has been sussessfully updated.<br>\r\n";

# 更新章节，如果文件已经存在则不写入新内容
$max = count($arr);
$new_article = '';
for($i = $start; $i <= $max; $i++){
    if(empty($arr[$i])) continue;
    if(strpos($arr[$i], 'href="') == false) continue;
    $link = explode('href="', $arr[$i]);
    $link2 = explode('">', $link[1]);
    if(strpos($all, $link2[0]) !== false) continue;
    if(empty($link2[0])) continue;
    $new_url = $url . $link2[0] . "\r\n";
    $new_article .= $new_url;
}

if(empty($new_article)) die("All files are already up-to-date.无需更新<br>\r\n");

echo "The following links will be UPDATED:<br>\r\n";
echo $new_article . "<br>\r\n";
$last_article = $url . $link2[0] . "\r\n";
file_put_contents($base_path . 'newurl.txt', $last_article . $new_article);
# 由于首页没有探测到文件名，而且代码处理不一致，故不能将网站首页加入到该文件



function get_links($content) {  
    $pattern = '/<a(.*?)href="(.*?)"(.*?)>(.*?)<\/a>/i';  
    preg_match_all($pattern, $content, $m);  
    return $m;
}

function caiji_info($url, $chaset, $div){
    if(empty($url)) die('url is empty');
    if(empty($chaset)) $chaset = 'gbk';
    if(empty($div)) $div = 'div#maininfo';
    require_once('./lib/phpQuery/phpQuery.php');
    phpQuery :: $defaultCharset = $chaset;
    $html = phpQuery :: newDocumentFile($url);
    // $html = phpQuery::newDocument($html);
    $title = pq("title") -> text();
    $maininfo = pq($div) -> html();
    if($chaset == 'gbk') $maininfo = mb_convert_encoding($maininfo, 'utf-8', 'GBK');
    $head = '<!DOCTYPE html><html lang="zh-CN"><head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	';
    $head .= '<title>' . $title . '</title></head><body>';
    $output = $head . $maininfo;
    return $output;
}


?>