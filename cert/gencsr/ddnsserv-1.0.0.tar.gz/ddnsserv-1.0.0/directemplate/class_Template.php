<?php
/* DirecTemplate - Simple, efficient template system
 * Version 1.1.6
 * Copyright 2003-2005, Steve Blinch
 * http://code.blitzaffe.com
 * ============================================================================
 *
 * OVERVIEW
 *
 *
 * Variables:
 *
 *		Variables assigned with $tpl->assign("myvar","value") can be
 *		accessed as {$myvar} in templates.
 *
 *
 * Loops:
 *
 *		Loops are structured as:
 *
 *		{loop $iterator=$myvar}
 *		This element of myvar is: {$iterator}.  The key is {$_loop.key}.
 *		{/loop}
 *
 *		This is roughly equivalent in PHP to "foreach ($myvar as $iterator)".
 *		Inside loops, the value of the current element is assigned to
 *		{$iterator}, and the {$_loop} variable contains an array of various
 *		information about the current iteration of the loop.
 *
 *		$_loop elements include:
 *			$_loop.key (the current key in the array)
 *			$_loop.iteration (current iteration)
 *			$_loop.odd (false if iteration is evenly divisible by 2)
 *			$_loop.first (true if this is the first iteration of the loop)
 *			$_loop.last (true if this is the last iteration of the loop)
 *
 *
 *	Conditionals:
 *
 *		If statements are structured in the following manner:
 *
 *		{if $var1==$var2} var1 equals var2 {/if}
 *		{if $var1} var1 is not false, zero, or null {/if}
 *		{if $var1==$var2} var1 equals var2 {else} var1 does not equal var2 {/if}
 *		{if $var1>$var2} greater {elseif $var1<$var2} lesser {else} equal {/if}
 *
 *
 *	Transformations:
 *
 *		Transformations modify the text inside their tags.  They
 *		are structured in the following manner:
 *
 *		{tranform strtoupper}this string will appear in uppercase{/transform}
 *		-or-
 *		{$variable|strtoupper}
 *
 *		Other transformations available currently include:
 *
 *		ucfirst			Identical to PHP functions of same names
 *		strtolower
 *		strtoupper
 *		ucwords
 *		urlencode
 *		urldecode
 *		htmlentities
 *		addslashes
 *		stripslashes
 *		abs
 *		round
 *		floor
 *		ceil
 *		striptags
 *
 *		count			Returns the number of elements if variable is an array,
 *						or 0 if not an array
 *		
 *
 *		yesno			Outputs "Yes" if contents are non-null/non-zero/true,
 *						otherwise displays "No"
 *		truefalse		Same as "yesno", but outputs "True" or "False"
 *		random			Outputs a random number (ignores any content)
 *		vardump			Outputs var_dump(variable) - use "variable", not "{$variable}"!
 *		null			Null transform, displays contents unmodified
 *
 *		noquotes		Replaces all "'s with &quot;'s
 *		nbsp			Replaces all spaces with &nbsp;'s
 *		nl2br			Replaces all newlines with <BR>'s
 *		base64_encode	BASE64-encodes the variable
 *		chr				Returns the character value of an ordinal value in a variable
 *		ord				Returns the ordinal value of the variable
 *
 *		vardump			Dumps the contents of {$variable}
 *
 *		mysqldatetime	Converts a string from a MySQL DATETIME field to a
 *			more presentable format.  
 *
 *			Example usage:
 *
 *			{$timestamp|mysqltimestamp:numeric:date}
 *
 *			Note the use of colons; full=display date/time, date=date only,
 *			time=time only, verbose=use full words, numeric=numbers only.
 *			Verbose/numeric/unix must be specified before full/date/time.
 *			(Unix returns a UNIX timestamp, regardless off full/date/time).
 *
 *			For a date()-style formatted date, it is also possible to use:
 *
 *			{$date_var|mysqltimestamp:formatted:M_d,_H:ia}
 *
 *
 *		mysqltimestamp	Same as mysqldatetime, but accepts a TIMESTAMP
 *		unixtimestamp	Same as mysqldatetime, but accepts a UNIX timestamp
 *		gettime			Same as mysqldatetime, but works with the current time
 *
 *		sprintf			Returns the content string formatted with the specified format
 *						string, eg: {$var|"$%.2f"} performs sprintf('$%.2f',$var)
 *
 *		substr			Returns a portion of the content string, eg: {$var|substr:2}
 *						performs substr($var,2), or {$var|substr:2:5} = substr($var,2,5)
 *		contains		Determines whether a substring appears in a string, eg:
 *						{$var|contains:"string"} performs strpos($var,"string")!==false)
 *
 *		str_replace		Perform a search/replace on the content string.  Be sure to use
 *						quotes around string literals
 *
 *			Example usage:
 *			{$string_var|str_replace:"%%SOMETHING%%":"Something else"}
 *			{$string_var|str_replace:"%%SOMETHING%%":$somethingelse}
 *
 *		preg_replace	Perform a regular expression search/replace on the content string.
 *
 *			Example usage:
 *			{transform preg_replace:/beer[\.]+/:donuts!}Mmm.... beer...{/transform}
 *
 *			Note: the regex is urldecoded before being processed.  As such, if you
 *			need to use a ':' character in your regex, use '%3A' instead.  If you
 *			need a '%', use '%21' instead, etc.
 *
 *		preg_match		Identical in syntax to preg_replace, except it returns 1 if the
 *						content string matched, or 0 if not.
 *
 *		mod				Performs arithmetic operations on the content variable.  eg:
 *		add				{$var|add:2} adds 2 to $var and returns the sum.
 *		sub
 *		mul
 *		div
 *		and
 *		or
 *		xor
 *
 *
 *		in_array		Determines whether a content variable appears in the specified array.
 *						{$var|in_array:myarray} returns true if $var is included in $myarray.
 *		in_keys			Identical in syntax to in_array - determines whether $var is a key in
 *						the specified array.
 *
 *		ellipsis		Returns a the content variable truncated to the specified length, with
 *						an ellipsis appended, eg: {$var|ellipsis:8} returns "Tests..." if $var
 *						is set to "Teststring"
 *		midellipsis		Returns a the content variable truncated to the specified length, with
 *						an ellipsis in the middle, and the specified number of trailing
 *						characters intact, eg: {$var|midellipsis:8:2} returns "Tes...ng" if $var
 *						is set to "Teststring" 
 *
 *		dateselect		Returns a <SELECT> suitable for choosing a date/time value, eg:
 *						{transform dateselect}basevarname|datetime:allownull:showtime|2003-04-04 00:00:00{/transform}
 *						Then use $this->parse_date_select() in your code to parse the submitted value
 *						and obtain a UNIX timestamp.
 *
 *
 *		Some transformations do not operate on variables, but instead just act as
 *		function calls.  These transformations may be invoked using:
 *
 *			{$_|transformation}
 *
 *		Non-variable transformations currently available include:
 *
 *		range			Returns an array containing the specified numeric range, eg:
 *						{$_|range:5:10} returns an array containing (5,6,7,8,9,10).
 *
 *
 *	Includes:
 *
 *		Use {include "filename.tpl"/} to parse the template filename.tpl and
 *		include its output inside the current template.
 *
 *
 *	Assigning variables within templates:
 *
 *		Occasionally it may be necessary to set variables from within a template,
 *		rather than from the script itself.  The procedure for doing this is 
 *		somewhat convoluted due to the non-linear technique that DirecTemplate
 *		uses (for the sake of speed) to parse templates.
 *
 *		Note that you cannot set variables conditionally within an {if} or {check}
 *		clause; {set}, {postset}, and {loopset} tokens are ALWAYS processed no
 *		matter where they are placed in the code.
 *
 *		To assign a variable from within a template, use the following syntax:
 *			{set $varname}Value for variable, {$vars} permitted{/set}
 *
 *		Note that variables set in this manner will be set BEFORE loops are
 *		executed.  Thus, any variables created or modified during a loop will
 *		NOT be accessible through {set} tags.  To perform a {set} operation
 *		AFTER all loops are executed, you may use:
 *
 *			{postset $varname}Value for variable, {$vars} permitted{/postset}
 *
 *		This latter notation should also be used if you intend to set variables
 *		from INSIDE a loop, such that any embedded variables will be parsed after
 *		the loop has been executed.
 *
 *		And finally, if you need to set a variable from INSIDE a loop, which will
 *		also be USED inside the loop, use:
 *
 *			{loopset $varname}Value for variable, {$vars} permitted{/loopset}
 *
 *		Note that variables set using this final notation will ONLY be valid 
 *		within during the loop in which they were defined; before and after the
 *		loop, their values should be treated as undefined.
 *
 *
 *	Multiple-page result sets:
 *
 *		DirecTemplate has internal support for displaying sets of data (eg: result
 *		sets from a database server) spanning multiple pages, with a "search engine"
 *		style set of page navigation links.
 *
 *		To prepare the template engine, use:
 *			$tpl->prepare_multipage($pagelimit,$totalitems,$baseurl)
 *
 *		Where $pagelimit is the maximum number of items per page, $baseurl is the
 *		total number of items available, and $baseurl is the URL to which users
 *		should be sent when they click a link.
 *
 *		In your template, use {$_multipage.nav} to display the navigation links.
 *
 *
 *	Custom plug-ins, transforms, and filters:
 *
 *		To define a custom plug-in, add it to the $tpl->plugins array as in:
 *		$tpl->plugins = array("plugin_name"=>"function_to_call");
 *
 *		Then define a function as in:
 *		function function_to_call($arguments) { }
 *
 *		$arguments is an array in the format array("argumentname"=>"value");
 *		Use as: {plugin_name argumentname=value}
 *
 *
 *		To define a custom transform, add it to the $tpl->transforms array as in:
 *		$tpl->transforms = array("transform_name"=>"function_to_call");
 *
 *		Then define a function as in:
 *		function function_to_call($data,$arguments) { }
 *
 *		$data is the data being transformed; $arguments is a list of arguments
 *		passed with the transform.  Use as: {$data|transform_name:argument:...}
 *
 *		Alternately, transforms and plugins may be defined using the
 *		TPL_CUSTOM_TRANSFORMS and TPL_CUSTOM_PLUGINS string constants, eg:
 *		define("TPL_CUSTOM_TRANSFORMS","transform_name:function_to_call|...");
 *
 *		To define a custom filter, add it to the $tpl->filters array as in:
 *		$tpl->filters = array("filter_name"=>"function_to_call");
 *
 *		Then define a function as in:
 *		function function_to_call($data) { }
 *
 *		$data is the final version of the page after parsing, but before being
 *		returned or displayed.  Your filter function should simply return the 
 *		filtered version of the data.
 *
 *
 * 
 * LICENSE
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * 
 * NOTES
 * 
 * NOTE: If you don't need the advanced features of the templating engine
 * (conditional processing, transforms, etc.) you can disable them by
 * uncommenting the following constants (or defining them in your apps)
 * to improve performance of your scripts.
 */

// Disable conditional processing (if/compare)
//define("DT_NO_CONDITIONALS",true);
//
// Disable transforms (transform/set)
//define("DT_NO_TRANSFORMS",true);
//
// Disable loops & file includes (loop/include)
//define("DT_NO_LOOPINC",true);
//
// Disable custom transforms
//define("DT_NO_CUSTOMTRANSFORMS",true);
//
// Disable custom plugins
//define("DT_NO_CUSTOMPLUGINS",true);

if (!defined("CACHE_PATH")) {
	define("CACHE_PATH","/tmp/cache");
}

// Template Class
// -----------------
class Template {

	// Constructor
	//
	function Template($use_caching=false,$cache_id=NULL,$cache_auto_display=true,$cache_allow_override=true,$cache_prefix="") {
		//	$use_caching		  - TRUE if page caching should be enabled, otherwise false
		//	$cache_id             - a unique identifier used to store/retrieve this page
		//	$cache_auto_display   - if a valid cached copy of this page exists, and
		//	                        $cache_auto_display is TRUE, the constructor will automatically
		//	                        display the cached version and terminate the script (otherwise,
		//                          if FALSE, the user must manually display the cached page)
		//	$cache_allow_override - if TRUE, passing ?nocache=1 to the calling script will prevent caching.

		set_magic_quotes_runtime(0);
		$this->cache_prefix = $cache_prefix;

		$this->page_prev = "&lt; Prev";
		$this->page_next = "Next &gt;";			

		// should we use caching?
		if (!is_null($use_caching) and !DISABLE_TEMPLATE_CACHING) {
			// has caching been overridden?
			if (!($cache_allow_override and isset($_REQUEST["nocache"]))) {
				// if the user didn't specify a cache ID, generate one that's hopefully unique
				if (is_null($cache_id)) $cache_id = $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
				$this->cache_id = $cache_id;
				
				if ($this->load_cache($cache_id)) { // try to load cached copy
					// cache hit!
					$this->cached = true;
					if ($cache_auto_display) { // if enabled, display the cached page and terminate
						echo $this->output;
						if (TEMPLATE_CACHE_DEBUG) {
							echo "<div align='center'>Cache hit (\"$this->cache_id\"".($this->cache_prefix?"; prefix: \"{$this->cache_prefix}\"":"").")</div>";
						}
						die;
					}
				}
			}
		}

		// not cached, so load the template from disk
		$this->cached = false;
		$this->auto_store_cache = true; // cache files should automatically be created
		$this->nocache_semaphore = false; // will not look for a "no-cache" semaphore
		

		// if the following is enabled, template variables that have not been set will
		// appear as "{Undefined:VARIABLENAME}" when parsed
		$this->display_undefined = false;
		
		$this->set_server_variables();
		$this->filters = array();
		$this->template_dirs = array();
		$this->template_fallback_dirs = array();
		$this->internal_i18n = false;
	}
	
	function set_cache_lifetime($cache_expire_time) {
		$this->cache_expire_time = $cache_expire_time;
	}
	
	function set_nocache_semaphore($permanent=false,$temporary=false,$timeout=28800) {
		$this->nocache_perm_semaphore = $permanent;
		$this->nocache_temp_semaphore = $temporary;
		$this->nocache_temp_timeout = $timeout; // 8 hours
	}

	// Sets default variables for use in templates.
	// eg: using {SERVER_PHP_SELF} in a template will
	//     return the value of $_SERVER["PHP_SELF"]
	function set_server_variables() {
		$this->variables = array(
			"server_php_self"=>$_SERVER["PHP_SELF"],
			"server_request_uri"=>$_SERVER["REQUEST_URI"],
			"server_server_name"=>$_SERVER["SERVER_NAME"],
			"server_script_name"=>$_SERVER["SCRIPT_NAME"],
			"server_remote_addr"=>$_SERVER["REMOTE_ADDR"],
			"server_unix_time"=>time(),
			"server_date"=>strftime("%b %d, %Y"),
			"server_time"=>strftime("%I:%M:%S%p"),
			"_nil"=>0,
			"_null"=>0,
			"_"=>0,
		);
		$this->assign_by_ref("_REQUEST",$_REQUEST);
		$this->assign_by_ref("_SERVER",$_SERVER);
		$this->assign_by_ref("_ENV",$_ENV);
		$this->assign_by_ref("_COOKIE",$_COOKIE);
		
		// Note: you MUST CALL session_start() BEFORE instantiating the Template object
		// if you want to access $_SESSION from templates
		$this->assign_by_ref("_SESSION",$_SESSION);

		if (defined("TPL_CUSTOM_PLUGINS")) {
			$plugins = explode("|",TPL_CUSTOM_PLUGINS);
			foreach ($plugins as $k=>$plugin) {
				list($plugin_name,$plugin_function) = explode(":",$plugin);
				$this->plugins[$plugin_name] = $plugin_function;
			}
		}
		if (defined("TPL_CUSTOM_TRANSFORMS")) {
			$transforms = explode("|",TPL_CUSTOM_TRANSFORMS);
			foreach ($transforms as $k=>$transform) {
				list($transform_name,$transform_function) = explode(":",$transform);
				$this->transforms[$transform_name] = $transform_function;
			}
		}
		
	}
	
	function get_template_filename($filename,$absolute_path = false) {
		if ($this->template_dir) {
			// get the full path to the template based on $this->template_dir
			if (substr($this->template_dir,-1)!="/") $this->template_dir .= "/";
			$pathname = $this->template_dir.$filename;
			
			if ($this->template_fallback_dir) {
				// if a fallback template directory has been set, and the template was not
				// found in $this->template_dir, then check the $this->template_fallback_dir
				// directory
				if (!is_readable($pathname)) {
					if (substr($this->template_fallback_dir,-1)!="/") $this->template_fallback_dir .= "/";
					$pathname = $this->template_fallback_dir.$filename;
				}
			}
			$filename = $pathname;
			
		} elseif (defined("TEMPLATE_BASE") && !$absolute_path) {
			$filename = TEMPLATE_BASE.$filename;
		}
		
		return $filename;
	}

	function include_template($filename) {
		$filename = $this->get_template_filename($filename);
    	return $this->read_template($filename);
	}
	
	function load_template($filename,$absolute_path = false) {
		$filename = $this->get_template_filename($filename,$absolute_path);
		return ($this->template = $this->read_template($filename));
	}
	
	// Loads a template from the specified filename.
	//
	// Accepts:
	//	$filename - the name of the file containing the template
	//
	// Returns:
	//	TRUE on success, FALSE on error
	function read_template($filename) {
		$fp = @fopen($filename,"r");
		if ($fp) {
			$template = "";
			while (!feof($fp)) {
				$template .= fread($fp,4096);
			}
			fclose($fp);
			
			return $template;
		} else {
			$this->error = "Template $filename not found";
			return "";
		}
	}
	
	// Assigns a value to the specified template variable.
	//
	// Accepts:
	//	$variable - the name of the variable in the template (eg: {VARIABLENAME}), OR
	//	            an array of ("VARIABLENAME"=>"VALUE") pairs
	//	$value - the value that should replace {VARIABLENAME} when the template is parsed, OR
	//           omitted, blank, or NULL if passing an array for $variable
	function assign($variable,$value="") {
		if (is_array($variable)) {
			foreach ($variable as $var=>$val) {
				$var = strtolower($var);
				$this->variables[$var] = $val;
			}
		} else {
			$this->variables[strtolower($variable)] = $value;
		}
	}

	// Assigns a value to the specified template variable by reference.
	//
	// Accepts:
	//	$variable - the name of the variable in the template
	//	$value - the value that should replace {VARIABLENAME} when the template is parsed
	function assign_by_ref($variable,&$value) {
		$this->variables[strtolower($variable)] = &$value;
	}

	function unassign($variable) {
	  	if (is_array($variable)) {
	      foreach ($variable as $var=>$val) {
	      	$var = strtolower($var);
	        unset($this->variables[$var]);
	      }
	    } else {
	  		$variable = strtolower($variable);
	      unset($this->variables[$variable]);
	  	}
	}

	// Appends a value to the current value of the specified template variable.
	//
	// Accepts:
	//	$variable - the name of the variable in the template (eg: {VARIABLENAME})
	//	$value - the value that should replace {VARIABLENAME} when the template is parsed
	function append($variable,$value) {
		$variable = strtolower($variable);
		$this->variables[$variable] .= $value;
	}

	// Begins capturing all subsequent output into the specified template variable.
	// Capturing stops when ::end_capture() is called.
	//
	// Accepts:
	//	$variable - the name of the variable in the template (eg: {VARIABLENAME})
	//
	// Example:
	//	$tpl->begin_capture("CONTENT");
	//	echo "hi!";
	//	$tpl->end_capture();
	//
	//	In this example, {CONTENT} now contains the string: "hi!"
	function begin_capture($variable) {
		$this->capturing = $variable;

		ob_start(); 
		ob_implicit_flush(0); 
	}
	
	// Stops capturing data into a template variable (initiated with ::begin_capture()).
	//
	// Accepts:
	//	$append - if TRUE, captured data is appended to the current value of the template variable
	function end_capture($append=false) {
		if ($append) {
			$this->append($this->capturing,ob_get_contents());
		} else {
			$this->assign($this->capturing,ob_get_contents());
		}
		ob_end_clean(); 	
	}
	
	function preg_lookup($matches) {
		return $this->lookup($matches[1]);
	}

	// Determines whether an expression is a value or a variable (depending on whether or
	// not it is quoted) and returns the unquoted string or parsed variable.
	//
	// Accepts:
	//	$expression - the expression to evaluate
	//
	// Returns:
	//	The unquoted string or parsed variable.
	function var_or_lit($expression) {
		if (substr($expression,0,1)=="\"") {
			$lit = substr($expression,1,strlen($expression)-2);
			
			// interpret any variables inside the value
			$lit = preg_replace("/\%([0-9A-Za-z]{2})/e", "''.chr(hexdec('\\1')).''", $lit);
//			$lit = preg_replace("/\{(.*?)\}/e", "\$this->lookup('\\1')", $lit);
			$lit = preg_replace_callback("/\{(.*?)\}/", array(&$this,"preg_lookup"), $lit);

			// %7B = [
			// %7D = ]
			
			return $lit;
		} else {
			return $this->lookup($expression);
		}
	}
	
	
	// Used internally to evaluate conditional expressions contained
	// in variables during parsing.
	//
	// Accepts:
	//	$expression - the expression to evaluate
	//
	//	This takes the form of {?VARNAME[operator]VALUE?IFTRUE:IFFALSE}
	//	eg: ?BOB="Harf"?"Equal!":"Not equal!"		or
	//			?BOB=ANOTHERVAR?"Equal":NOT_EQUAL
	//
	//	VARNAME must specify a valid variable name.
	//	VALUE, IFTRUE, and IFFALSE are considered variables if unquoted,
	//	or literal text if they are "surrounded in double-quotes".
	//
	//	Operator may include <, >, <=, >=, =, or ==
	//		(= and == are both valid and are interpreted identically)
	//
	//	If including special characters (including {VARIABLES}) inside a
	//	literal IFTRUE or IFFALSE, they should be converted to hexadecimal
	//	in the form %xx before use in an expression.
	//
	//	For example, this will NOT work:
	//		?BOB=MYVALUE?"Equal!":"Not equal to {MYVALUE}"
	//
	//	It should be:
	//		?BOB=MYVALUE?"Equal!":"Not equal to %7BMYVALUE%7D"
	//
	//	Literal percent (%) characters should be escaped as: %25
	//
	// Returns:
	//	The result of the evaluated expression
  /*
	function evaluate_expression($expression) {
		$expression = stripslashes($expression);
		preg_match("/^\?([A-Za-z0-9_-]+)([\>|\<|\=]?[\=]?)(\".*\"|[A-Za-z0-9_]+)\?(\".*\"|[A-Za-z0-9_]+)\:(\".*\"|[A-Za-z0-9_]+)/",$expression,$match);
//		variable names can have digits in them!
//		preg_match("/^\?([A-Za-z_-]+)([\>|\<|\=]?[\=]?)(\".*\"|[A-Za-z_]+)\?(\".*\"|[A-Za-z_]+)\:(\".*\"|[A-Za-z_]+)/",$expression,$match);
		list(,$queryvar,$operator,$against,$iftrue,$iffalse) = $match;

		$queryvar = $this->lookup($queryvar);
		$against = $this->var_or_lit($against);
		
		//echo "[$queryvar / $against]";

		switch ($operator) {
			case "==":
			case "=": 	$istrue = ($queryvar==$against); break;
			case "<": 	$istrue = ($queryvar<$against); break;
			case ">": 	$istrue = ($queryvar>$against); break;
			case "<=": 	$istrue = ($queryvar<=$against); break;
			case ">=": 	$istrue = ($queryvar>=$against); break;
			default:		return "?OPERATOR?($operator)";
		}
		if ($istrue) {
			return $this->var_or_lit($iftrue);
		} else {
			return $this->var_or_lit($iffalse);
		}
	}
	  */

	// Used internally to look up variables to be replaced during parsing.
	//
	// Accepts:
	//	$variable - the name of the variable to retrieve a value for
	//
	// Returns:
	//	The value of the variable as set by ::assign() or ::append()	
	function lookup($variable) {
		if (substr($variable,0,1)==" ") { return "{".$variable."}"; } // not to be parsed!
		
		$x = substr($variable,0,1);
		if ($x=="=") {
			// gettext translation
//			$variable = stripslashes($variable);
			if (preg_match("/^\=\"(.*?)\"(?:\,(.*?))?$/",$variable,$match)) {
				list(,$msg,$arguments) = $match;
			} else {
				$msg = $this->lookup(substr($variable,1));
			}
			
/*			
			if (strpos($msg,'settings are')!==false ){
				var_dump($arguments);
				die($msg);
				
			}
*/			
			
			if ($this->internal_i18n) {
				$msg = __($msg);
			} else {
				$msg = _($msg);
			}
			if ($arguments) {
		      	$arguments .= ",";
		        preg_match_all("/(=?\".*?\"|[0-9]+|=?\\\$[A-Za-z0-9|\[\]\\\$_\.]+)\,/",$arguments,$args,PREG_PATTERN_ORDER);
				
		        $args = $args[1];
		        foreach ($args as $k=>$v) {
		        	$translate_arg = (substr($v,0,1)=='=');
		        	if ($translate_arg) $v = substr($v,1);

		        	$v = $this->evaluate_expression($v);
		        	
		        	if ($translate_arg) {
		        		if ($this->internal_i18n) {
		        			$v = __($v);
		        		} else {
		        			$v = _($v);
		        		}
		        	}
		        	
		        	$args[$k] = $v;
		        }
		      	$msg = @vsprintf($msg,$args);
			}
			$res = $msg;

		} elseif ($x=="$") {
			// variable
			$transform = "";
			
			// remove the $
			$variable = substr($variable,1);
			
			$p = strpos($variable,"|");
			if ($p!==false) {
				$transform = substr($variable,$p+1);
				$variable = substr($variable,0,$p);
			}
			
			
			// if the variable is, for example, {$foo[$bar]}, parse out the portion(s) in brackets...
			// essentially, if $bar = harf, this will be changed to {$foo.harf}, then parsed below
			while(($p = strpos($variable,"["))!==false) {
				$q = strpos($variable,"]");
				if ($q<$p) break; // prevent problems on weirdness like $foo]bar or something
				
				$subvar = substr($variable,$p+1,$q-$p-1);
				$subvar = $this->evaluate_expression($subvar);
				
				$var_pre = substr($variable,0,$p);
				$var_post = substr($variable,$q+1);
				$variable = $var_pre.".".$subvar.$var_post;
			}
			
			
			// if the variable is {$array.element}, we want the "array" portion in lowercase
			// but the "element" portion must retain its case (as array keys are case sentitive)
			if (($p = strpos($variable,"."))!==false) {
				$v = substr($variable,0,$p);
				$variable = strtolower($v).substr($variable,$p);
			} else {
				$variable = strtolower($variable);
			}

			$varset = false;
			
			// if variable contains periods, it's referencing elements of an array (eg: {$client.name})
			if (strpos($variable,".")!==false) {
				$keys = explode(".",$variable);
				
				switch($keys[0]) {
					case '_constants':
						$varset = @defined($keys[1]);
						$res = $varset? @constant($keys[1]) : '';
						break;
					default:
						$res = $this->variables[$keys[0]];
						$varset = isset($this->variables[$keys[0]]);
						
						if ($varset) {
							$needclosebracket = false;
							$bracketkey = "";
							
							for ($i=1; $i<count($keys); $i++) {
								$key = $keys[$i];
								
								// the following line allows things like $document.elements.$elementno.name
								if (substr($key,0,1)=="$") $key = $this->lookup($key); 
								if (is_object($res)) {
									$res = $res->$key;
								} else {
									$res = $res[$key];
								}
							}
						}
				}
			} else {
				$varset = isset($this->variables[$variable]);
				$res = $this->variables[$variable];	
			}
			if (!$varset) {
				// variable wasn't set!
				$this->error = "Undefined variables encountered during parsing";
				$this->warnings .= "Template variable {$variable} undefined";
				if ($this->display_undefined)
					$res = "{Undefined:".strtoupper($variable)."}";
			} else {
				if ($transform) {
					$res = $this->transform($transform,$res);
				}
			}
		} elseif ($x=="*") {
			if (substr($variable,-1)=="*") $res="";
		} else {
  			$res = "{".$variable."}";
  		}
		return $res;
	}

	function mysql_timestamp_to_time($dt) {
		if ($dt=="00000000000000") { return "None"; }
	    $yr = substr($dt,0,4);
	    $mo = substr($dt,4,2);
	    $dy = substr($dt,6,2);
	    $hr = substr($dt,8,2);
	    $mn = substr($dt,10,2);
	    $sc = substr($dt,12,2);
	    return mktime($hr,$mn,$sc,$mo,$dy,$yr);
	}

	function mysql_datetime_to_time($dt) {
	    if ($dt=="0000-00-00 00:00:00") { return "None"; }
	    $yr = substr($dt,0,4);
	    $mo = substr($dt,5,2);
	    $dy = substr($dt,8,2);
	    $hr = substr($dt,11,2);
	    $mn = substr($dt,14,2);
	    $sc = substr($dt,17,2);
	    return mktime($hr,$mn,$sc,$mo,$dy,$yr);
	}

	function mysql_time_transform($datetime,$method,$data) {
		switch($datetime) {
			case 3:
				$dt = (int) $data;
				break;
			case 2:
				$dt = time();
				break;
			case 1:
				$dt = $this->mysql_datetime_to_time($data);
				break;
			default:
				$dt = $this->mysql_timestamp_to_time($data);
				break;
		}
		
		$datestyle = strtolower($method[1]);
		if (!$datestyle) $datestyle="verbose";
		if ($datestyle=="full") {
			$dateformat = "l, F d, Y";
			$timeformat = "h:i:sa";
			$monthformat = "F, Y";
		} if ($datestyle=="verbose") {
			$dateformat = "M d, Y";
			$timeformat = "h:i:sa";
			$monthformat = "M, Y";
		} elseif ($datestyle=="numeric") {
			$dateformat = "m-d-Y";
			$timeformat = "H:i:s";
			$monthformat = "m/Y";
		} elseif ($datestyle=="verbosenosecs") {
			$dateformat = "M d, Y";
			$timeformat = "h:ia";
			$monthformat = "M, Y";
		} elseif ($datestyle=="formatted") {
			// Shift the command and date style off of the beginning of the array
			array_shift($method);
			array_shift($method);
			// any colons beyond the first are intended as part of the date string, so re-implode
			// the array
			$datestr = implode(":",$method);
			// replace any underscores with spaces
			$datestr = str_replace("_"," ",$datestr);
		} elseif ($datestyle=="unix") {
			return $dt;
		}
		
		if ($datestyle!="formatted") {
			$datedetails = strtolower($method[2]);
			if (!$datedetails) $datedetails="full";
			switch($datedetails) {
				case "full":
				  	$datestr = "$dateformat $timeformat";
				    break;
				case "date":
				  	$datestr = $dateformat;
				    break;
				case "monthyear":
				  	$datestr = $monthformat;
				    break;
				case "time":
				  	$datestr = $timeformat;
				    break;
			}
		}
		return @date($datestr,$dt);
	}
	
	function date_select($data) {
		// {transform dateselect}basevarname|datetime:allownull:showtime:noday:minyear=2003:maxyear=2007|2003-04-04 00:00:00{/transform}
		list($basename,$flagdata,$date) = explode("|",$data,3);

		$flags = explode(":",$flagdata);
		$allownull = in_array("allownull",$flags);
		$datetype = array_shift($flags);
		$options = array();
		
		foreach ($flags as $k=>$flag) {
			if (strpos($flag,'=')!==false) {
				list($flagname,$flagvalue) = explode('=',$flag);
				if (substr($flagvalue,0,1)=='$') $flagvalue = $this->lookup($flagvalue);
				$options[$flagname] = $flagvalue;
			}
		}
		
		if (!$options['minyear']) $options['minyear'] = 2004;
		if (!$options['maxyear']) $options['maxyear'] = 2012;
		
		if ($date=="now") {
			$date = getdate(time());
		} elseif (!$date) {
			$date = array(
				"mon"=>-1,
				"mday"=>-1,
				"year"=>-1,
				"hours"=>-1,
				"minutes"=>-1
			);
		} else {
			if (substr($date,0,1)=='$') $date = $this->lookup($date);
			switch($datetype) {
				case "datetime":
					$time = $this->mysql_datetime_to_time($date);
					break;
				case "timestamp":
					$time = $this->mysql_timestamp_to_time($date);
					break;
				case "unix":
					$time = (int) $date;
					break;
				default:
					return "Invalid date type: $datetype";
					break;
			}
			$date = getdate($time);
		}
		
		
		$i18nfunc = $this->internal_i18n ? '__' : '_';
		
		$months = array(
			$i18nfunc("Jan"),
			$i18nfunc("Feb"),
			$i18nfunc("Mar"),
			$i18nfunc("Apr"),
			$i18nfunc("May"),
			$i18nfunc("Jun"),
			$i18nfunc("Jul"),
			$i18nfunc("Aug"),
			$i18nfunc("Sep"),
			$i18nfunc("Oct"),
			$i18nfunc("Nov"),
			$i18nfunc("Dec")
		);
		
		$output = "";
		if (!in_array("timeonly",$flags)) {

			if (in_array("nomonth",$flags)) {
				$output .= "<input type='hidden' name='{$basename}_month' value='1'>\n";
			} else {
				$output = "<select name='{$basename}_month' size='1'>\n";
				if ($allownull) $output .= "<option value='0' /> ---\n";
				foreach ($months as $k=>$month) {
					$output .= "<option value='".($k+1)."'".($k+1==$date["mon"]?" selected='selected'":"")." /> $month\n";
				}
				$output .= "</select>\n";
			}
	
			if (in_array("noday",$flags)) {
				$output .= "<input type='hidden' name='{$basename}_day' value='1'>\n";
			} else {
				$output .= "<select name='{$basename}_day' size='1'>\n";
				if ($allownull) $output .= "<option value='0' /> --\n";
				for ($i=1; $i<32; $i++) {
					$output .= "<option value='$i'".($i==$date["mday"]?" selected='selected'":"")." /> $i\n";
				}
				$output .= "</select>\n";
			}
			
			if (in_array("noyear",$flags)) {
				$output .= "<input type='hidden' name='{$basename}_year' value='".date('Y')."'>\n";
			} else {
				$output .= "<select name='{$basename}_year' size='1'>\n";
				if ($allownull) $output .= "<option value='0' /> ----\n";
	
				for ($i=$options['minyear']; $i<=$options['maxyear']; $i++) {
					$output .= "<option value='$i'".($i==$date["year"]?" selected='selected'":"")." /> $i\n";
				}
				$output .= "</select>\n";
			}
		}

		if (in_array("showtime",$flags) || in_array("timeonly",$flags)) {
			$houronly = in_array("houronly",$flags);
			$ampm = in_array("ampm",$flags);
			$anytime = in_array("anytime",$flags);
			
			$output .= "&nbsp;<select name='{$basename}_hour' size='1'>\n";
			if ($allownull) $output .= "<option value='' /> ".($anytime ? "Any Time" : "--")."\n";
			
			for ($i=0; $i<24; $i++) {
				$h = $i;
				$a = "a";
				if ($ampm && $houronly) {
					if ($h==0) {
						$h += 12;
					} elseif ($h==12) {
						$a = "p";
					} elseif ($h>12) {
						$h -= 12;
						$a = "p";
					}
				}
				$timeformat = ($h<10?"0":"").$h.($houronly?":00":"").($ampm?"{$a}m":"");
				
				$output .= "<option value='$i'".($i==$date["hours"]?" selected='selected'":"")." /> $timeformat\n";
			}

			$output .= "</select>\n";
			
			if (!$houronly) {
				$output .= " : <select name='{$basename}_min' size='1'>\n";
				if ($allownull) $output .= "<option value='' /> --\n";
				for ($i=0; $i<60; $i++) {
					$output .= "<option value='$i'".($i==$date["minutes"]?" selected='selected'":"")." /> ".($i<10?"0":"").$i."\n";
				}
				$output .= "</select>\n";
			}
		}
		
		return $output;
		
	}
	
	// Note: this is intended to be called by the user in the script
	// that is making use of the this class.  If you've included a
	// {transform dateselect}varname|...{/transform} in your template, you 
	// can call $this->parse_date_select("varname") to retrieve a
	// UNIX timestamp of the passed value (or 0 if null)
	function parse_date_select($basename) {
		$mo = (int) $_REQUEST[$basename."_month"];
		$dy = (int) $_REQUEST[$basename."_day"];
		$yr = (int) $_REQUEST[$basename."_year"];
		$hr = (int) $_REQUEST[$basename."_hour"];
		$mn = (int) $_REQUEST[$basename."_min"];
		
//		echo "[$basename/$mo/$dy/$yr/$hr/$mn]";
		
		if ($mo<=0 || $dy<=0 || $yr<=0) return 0;
		
		return mktime($hr,$mn,0,$mo,$dy,$yr);
	}
	
	function arithmetic_op($variable,$operand,$operator,$postprocess,$postprocessinfo) {
		if (!is_numeric($operand)) $operand = $this->evaluate_expression($operand);
		switch($operator) {
			case "and": $res = ($variable and $operand); break;
			case "xor": $res = ($variable xor $operand); break;
			case "or": $res = ($variable or $operand); break;
			case "mod": $res = $variable % $operand; break;
			case "add": $res = $variable + $operand; break;
			case "sub": $res = $variable - $operand; break;
			case "mul": $res = $variable * $operand; break;
			case "div": $res = ($operand!=0) ? $variable / $operand : '(DIV0)'; break;
			default:
				return 0;
		}
		
		switch($postprocess) {
			case "floor": return floor($res);
			case "ceil": return ceil($res);
			case "round": return round($res,(int) $postprocessinfo);
			default: return $res;
		}
	}

	function transform($method,$data) {
		
		// check for multiple chained transforms
		if (strpos($method,"|")!==false) { 
			// if found, explode $method and call self once for each method
			$transforms = explode("|",$method);
			foreach ($transforms as $k=>$method) {
				$data = $this->transform($method,$data);
			}
			return $data;
		}
		$method = explode(":",$method);
		switch(strtolower($method[0])) {
			case "ucfirst":
				$output = ucfirst($data);
				break;
			case "strtolower":
				$output = strtolower($data);
				break;
			case "strtoupper":
				$output = strtoupper($data);
				break;
			case "ucwords":
				$output = ucwords($data);
				break;
			case "urlencode":
				$output = urlencode($data);
				break;
			case "urldecode":
				$output = urldecode($data);
				break;
			case "htmlentities":
				$output = htmlentities($data);
				break;
			case "addslashes":
				$output = addslashes($data);
				break;
			case "stripslashes":
				$output = stripslashes($data);
				break;
			case "striptags":
			case "strip_tags":
				$output = strip_tags($data);
				break;
			case "count":
				$output = is_array($data) ? count($data) : 0;
				break;
			case "abs":
				$output = abs($data);
				break;
			case "round":
				$precision = (int) $method[1];
				$output = round($data,$precision);
				break;
			case "floor":
				$output = floor($data);
				break;
			case "ceil":
				$output = ceil($data);
				break;
			case "filesize":
				$precision = (int) $method[1];
				$data = (int) $data;
				if ($data>1024*1024*1024) {
					$data = round($data / 1024*1024*1024,$precision).'G';
				} elseif ($data>1024*1024) {
					$data = round($data / 1024*1024,$precision).'M';
				} elseif ($data>1024) {
					$data = round($data / 1024,$precision).'K';
				}
				return $data;
				break;
			case "substr":
				if(count($method)==2) {
					$output = substr($data,(int) $method[1]);
				} else {
					$output = substr($data,(int) $method[1],(int) $method[2]);
				}
				break;
			case "preg_replace":
				$output = preg_replace(urldecode($method[1]),$method[2],$data);
				break;
			case "str_replace":
				
				$keyword = trim($method[1]);
				if ( (substr($keyword,0,1)!='$') && (substr($keyword,0,1)!='"') ) $keyword = "\"$keyword\"";
				$keyword = $this->evaluate_expression($keyword);

				$replacement = trim($method[2]);
				if ( (substr($replacement,0,1)!='$') && (substr($replacement,0,1)!='"') ) $replacement = "\"$replacement\"";
				$replacement = $this->evaluate_expression($replacement);

				$replacement = preg_replace_callback("/\{(.*?)\}/", array(&$this,"preg_lookup"), $replacement);

				$output = str_replace($keyword,$replacement,$data);
				break;
			case "preg_match":
				$output = preg_match(urldecode($method[1]),$data);
				break;
			case "contains":
				$keyword = preg_replace(array('/^"/','/"$/'),"",$method[1]);
				$output = (strpos($data,$keyword)!==false);
				break;
			case "default":
				$fallback = $method[1];
				$c = substr($fallback,0,1);
				if ($c=='$' || $c=='=') $fallback = $this->lookup($fallback);

				$output = strlen($data) ? $data : $fallback;
				break;				
			case "sprintf":
				$format = preg_replace(array('/^"/','/"$/'),"",$method[1]);
				$output = sprintf($format,$data);
				break;
			case "mysqldatetime":
				$output = $this->mysql_time_transform(1,$method,$data);
				break;
			case "mysqltimestamp":
				$output = $this->mysql_time_transform(0,$method,$data);
				break;
			case "unixtimestamp":
				$output = $this->mysql_time_transform(3,$method,$data);
				break;
			case "gettime":
				$output = $this->mysql_time_transform(2,$method,$data);
				break;
			case "yesno":
				$output = ((int) $data>0?"Yes":"No");
				break;
			case "truefalse":
				$output = ((int) $data>0?"True":"False");
				break;
			case "null":
				$output = $data;
				break;
			case "noquotes":
				$output = str_replace("\"","&quot;",$data);
				break;
			case "nbsp":
				$output = str_replace(' ',"&nbsp;",$data);
				break;
			case "ellipsis":
				$maxlen = (int) $method[1];
				if (strlen($data)>$maxlen) $data = substr($data,0,$maxlen-3)."...";
				$output = $data;
				break;
			case "midellipsis":
				$maxlen = (int) $method[1];
				$endingchars = (int) $method[2];
				if (!$endingchars) $endingchars = 8;
				if (strlen($data)>$maxlen) {
					$ending = substr($data,-$endingchars);
					$data = substr($data,0,$maxlen-3-$endingchars)." ... " . $ending;
				}
				$output = $data;
				break;
			case "dateselect":
				$output = $this->date_select($data);
				break;
			case "random":
				$output = rand();
				break;
			case "nl2br":
				$output = nl2br($data);
				break;
			case "base64_encode":
				$output = base64_encode($data);
				break;
			case "chr":
				$output = chr($data);
				break;
			case "ord":
				$output = ord($data);
				break;
			case "or":
			case "and":
			case "xor":
			case "mod":
			case "add":
			case "sub":
			case "mul":
			case "div": 
				$output = $this->arithmetic_op($data,$method[1],strtolower($method[0]),$method[2],$method[3]); 
				break;
			case "vardump":
				// eg: {transform vardump}something{/transform} performs var_dump($something)
				ob_start();
				var_dump($this->lookup('$'.$data));
				$output = "<pre>\n".ob_get_contents()."</pre>";
				ob_end_clean();
				break;
			case "in_keys":
				$arrayname = $method[1];
				$array = $this->lookup('$'.$arrayname);
				
				return isset($array[$data]);
				break;
			case "in_array":
				$arrayname = $method[1];
				$array = $this->lookup('$'.$arrayname);
				
				return in_array($data,$array);
				break;
			case "range":
				$lo = $method[1];
				$hi = $method[2];
				$output = range($lo,$hi);
				break;
			default:
		  		if (!defined("DT_NO_CUSTOMTRANSFORMS")) {
					if (is_array($this->transforms)) {
						foreach ($this->transforms as $name=>$func) {
							array_shift($method);
							if (is_array($func)) {
								$fclass = &$func[0];
								$fmethod = &$func[1];
								if (is_object($fclass) && method_exists($fclass,$fmethod)) {
									$output = $fclass->$fmethod($data,$method);
								} else {
									$output = "[Error: Custom transform method ".get_class($fclass)."->{$fmethod}() does not exist]";
								}
							} else {
								if (function_exists($func)) {
									$output = $func($data,$method);
								} else {
									$output = "[Error: Custom transform function {$func}() does not exist]";
								}
							}
						}
					}
				}			
			
		}
		return $output;
	}

	function preg_compare($matches) {
		return $this->compare($matches[1],$matches[2],$matches[3],$matches[4]);
	}

	function parse_tags($s) {
		// replace any variables
		
		if (!defined("DT_NO_CONDITIONALS")) {
//		    $s = preg_replace("/\{compare (\\\$[A-Za-z0-9\[\]\\\$_\.]+|\".*?\"|[0-9]+)\,(\\\$[A-Za-z0-9\[\]\\\$_\.]+|\".*?\"|[0-9]+),(\\\$[A-Za-z0-9\[\]\\\$_\.]+|\".*?\"|[0-9]+),(\\\$[A-Za-z0-9\[\]\\\$_\.]+|\".*?\"|[0-9]+)\}/ie","\$this->compare('\\1','\\2','\\3','\\4')",$s);
		    $s = preg_replace_callback("/\{compare (\\\$[A-Za-z0-9\[\]\\\$_\.]+|\".*?\"|[0-9]+)\,(\\\$[A-Za-z0-9\[\]\\\$_\.]+|\".*?\"|[0-9]+),(\\\$[A-Za-z0-9\[\]\\\$_\.]+|\".*?\"|[0-9]+),(\\\$[A-Za-z0-9\[\]\\\$_\.]+|\".*?\"|[0-9]+)\}/i",array(&$this,"preg_compare"),$s);
		}
		
//		$s = preg_replace("/\{(.*?)\}/e", "\$this->lookup('\\1')", $s);
		$s = preg_replace_callback("/\{(.*?)\}/", array(&$this,"preg_lookup"), $s);
		// make any transformations
		
		$s = preg_replace("/\{\*(.*?)\*\}/","",$s);
		
		if (!defined("DT_NO_TRANSFORMS")) {
		  	$s = preg_replace("/\{transform (.*?)\}([\s\S]*?)\{\/transform\}/ie","\$this->transform('\\1','\\2')",$s);
		}
		return $s;
	}

	function evaluate_expression($expr) {
		if (preg_match("/^\"(.*?)\"$/",$expr,$matches)) {
			return $matches[1];
		
		} elseif (preg_match("/^(\\\$[A-Za-z0-9\[\]\\\$_\.]+|\".*?\"|[0-9]+)([\+|\-|\/|\*])(\\\$[A-Za-z0-9\[\]\\\$_\.]+|\".*?\"|[0-9]+)$/",$expr,$matches)) {
			return "expression";
		
		} elseif (substr($expr,0,1)=="$") {
			return $this->lookup($expr);
			/*
			$expr = strtolower(substr($expr,1));
			return $this->variables[$expr];
			*/
		
		} elseif (is_numeric($expr)) {
			return (int) $expr;
		
		} else {
			// eh?! invalid expression!
			return "";
		
		}
	}

	function evaluate_condition($condition) {
		$this->debug_conditions = false;
		
//  	$condition = "\$naughty==\$nice";

//	We made this change so that things like {if $txn.description|contains:"My string">0} would be possible
//		if (preg_match("/^(\\\$[A-Za-z0-9\[\]\\\$_\.\|\:]+|\".*?\"|[0-9]+)([\>|\<|\=]?[\=]{0,2}|\!\=)(\\\$[A-Za-z0-9\[\]\\\$_\.\|\:]+|\".*?\"|[0-9]+)$/",$condition,$matches)) {
		if (
			preg_match(
				"/^".
					"(\\\$[A-Za-z0-9\[\]\\\$_\.\|\:\\\"\s]+|\".*?\"|[0-9]+)". 	// expr1
					"(?:".
//						"([\>|\<|\=]?[\=]{0,2}|\!\=)". 								// operator
						"([\>\<\=]{1,2}|\!\=)". 									// operator
						"(\\\$[A-Za-z0-9\[\]\\\$_\.\|\:]+|\".*?\"|[0-9]+)". 		// expr2
					")?".
				"$/"
				,
				$condition,
				$matches
			)
		) {
			
			list(,$expr1,$operator,$expr2) = $matches;

			if ($this->debug_conditions) echo "[$expr1::$operator::$expr2]\n";
			
			$expr1 = $this->evaluate_expression($expr1);
			$expr2 = $this->evaluate_expression($expr2);
			
			if ($this->debug_conditions) echo "[$expr1::$operator::$expr2]\n";
			
			$evaltrue = false;
			// could have used eval(), but that would generate an error
			// if $operator was invalid... so this is easier.
			switch ($operator) {
				case "===":		$evaltrue = ($expr1===$expr2); break;
				case "==":
				case "=":		$evaltrue = ($expr1==$expr2); break;
				case "<":		$evaltrue = ($expr1<$expr2); break;
				case "<=":	$evaltrue = ($expr1<=$expr2); break;
				case ">":		$evaltrue = ($expr1>$expr2); break;
				case ">=":	$evaltrue = ($expr1>=$expr2); break;
				case "<>":
				case "!=":	$evaltrue = ($expr1!=$expr2); break;
				case "":	$evaltrue = $expr1; break;
				default:
					echo "[Invalid operator: $operator]";
					return false;
					// TODO: Error! invalid comparison operator
					break;
			}
	
			if ($this->debug_conditions) echo "[".($evaltrue?"true":"false")."]<br>\n";
			return $evaltrue;
		} else {
//  		echo "nope[$condition]";

			return $this->evaluate_expression($condition);
		}
	}

	function conditional($condition,$expr,$tagelse="else",$tagelseif="elseif") {
		//echo "<br /><br /><span style='color: #0000FF'>conditional((<span style='color: #000099'>$condition</span>,<span style='color: #990099'>$expr</span>,<span style='color: #009999'>$tagelse</span>))</span><br /><br />";
		//$expr = str_replace('\"','"',$expr);
		//$condition = str_replace('\"','"',$condition);
		
		//$expr = stripslashes($expr);
		//$condition = stripslashes($condition);

		$iselseif = preg_match("/^([\s\S]*?)\{".$tagelseif." (.*?)\}([\s\S]*)$/",$expr,$matches);
		if ($iselseif) {
			$expr1 = &$matches[1];
			$condelseif = $matches[2];
			$expr2 = &$matches[3];
			$iselse = true;
		} else {
			$iselse = preg_match("/^([\s\S]*)\{".$tagelse."\}([\s\S]*)$/",$expr,$matches);
			if ($iselse) {
				$expr1 = &$matches[1];
				$expr2 = &$matches[2];
			}
		}
		if (!$iselse) {
			$expr2 = &$expr;
		}
		
		//echo "<span style='color: #550000'>[[<span style='color: #FF0000'>$expr</span> ]][[ <span style='color: #FF0000'>$expr2</span>]]</span>";
		
		//echo "[<span style='color: red'>$expr1</span>]";
		//echo "[<span style='color: green'>$expr2</span>]";
		$evaltrue = $this->evaluate_condition($condition);

//		echo "=======\nif ($condition) {\n$expr1\n} else {\n$expr2\n}\nCondition: ".($evaltrue?"yes":"no")."\n=======\n";

//		echo "[$evaltrue::$iselse]<br>\n[$expr1::$expr2::$expr]";

		if ($evaltrue==($iselse>0)) {
			// if the expression evaluated to true, OR
			// the expression evaluated to false and there was no {else} tag
			return $this->parse_tags($expr1);
		} else {
			// if the expression evaluated to false, OR
			// the expression evaluated to true and there was an {else} tag
			if ($iselseif>0) {
				//return $this->conditional($condelseif,$expr2);
				return $this->conditional($condelseif,$expr2,$tagelse,$tagelseif);
			}
			return $this->parse_tags($expr2);
		}
	}

	function compare($expr1,$expr2,$data1,$data2) {
//  	echo $this->variables["existingaccount"];
//  	echo "<span style='color: red'>[$expr1/$expr2/$data1/$data2]</span>";

		$data1 = $this->evaluate_expression($data1);
		$data2 = $this->evaluate_expression($data2);
		return $this->conditional($expr1."==".$expr2,"$data1{else}$data2");
	}

	function evaluate_assignment($expression) {
		
		if (preg_match("/\\\$([A-Za-z0-9\[\]\\\$_\.]+)\=((\\\$[A-Za-z0-9\[\]\\\$_\.]+)|(\".*?\")|([0-9]+))/",$expression,$matches)) {
			list(,$variable,$assignment) = $matches;
			$assignment = $this->evaluate_expression($assignment);
			$this->assign($variable,$assignment);
			return array($variable,$assignment);
		} else {
			return array("[*INVALID_EXPRESSION*]","$expression");
		}
	}

	function loop($iterator,$records,$data) {

//		$data = stripslashes($data);
		$records = $this->lookup('$'.strtolower($records));
		$output = "";
		$iteration = 0;
		$last_key = "";
		if (is_array($records)) {
			$iterations = count($records);
		  	foreach ($records as $k=>$v) {
				$iteration++;
				$this->assign(
					"_loop",
					array(
		  				"key"=>$k,
		  				"iteration"=>$iteration,
						"iterations"=>$iterations,
		  				"odd"=>$iteration%2,
		  				"first"=>($iteration==1),
		  				"last"=>($iteration==$iterations),
		  				"lastodd"=>($iteration%2) && ($iteration==$iterations),
		  				"prev_iteration"=>$iteration-1,
		  				"next_iteration"=>$iteration+1,
		  				"prev_key"=>$last_key
					)
				);
		  		$this->assign_by_ref(
		  			$iterator,
	  				$v
		  		);
		  		
		  		$ldata = $data;
			    if (!defined("DT_NO_TRANSFORMS")) {
			    	// do a post-loop set, for variables we want to use *outside* a loop
				    $ldata = preg_replace_callback("/\{loopset\s+\\\$([A-Za-z0-9\[\]\\\$_\.]+)\}([\s\S]*?)\{\/loopset\}/i",array(&$this,"preg_set"),$ldata);
			    }
		  		
				$output .= $this->parse_tpl($ldata);
				
				$last_key = $k;
				// unset for hte next iteration
	    	}
		}
   		$this->unassign($iterator);
   		$this->unassign("_loop");
		return $output;
	}
	
	function custom_plugin($name,$func,$parameters) {
		$parameters = stripslashes($parameters);
		$parameters .= " ";
		if (!preg_match_all("/(.*?)\=(\"[^\"?]*\"|[^\s?]+)\s+/i",$parameters,$params,PREG_SET_ORDER)) {
			$params = array();
		}
		$parameter_list = array();
		
		foreach ($params as $pkey=>$param) {
			list(,$k,$v) = $param;
			$parameter_list[$k] = $this->evaluate_expression($v);
		}
		
		if (is_array($func)) {
			$fclass = &$func[0];
			$fmethod = &$func[1];
			if (is_object($fclass) && method_exists($fclass,$fmethod)) {
				$output = $fclass->$fmethod($parameter_list);
			} else {
				$output = "[Error: Custom plug-in method ".get_class($fclass)."->{$fmethod}() does not exist]";
			}
		} else {
			if (function_exists($func)) {
				$output = $func($parameter_list);
			} else {
				$output = "[Error: Custom plug-in function {$func}() does not exist]";
			}
		}
		
		return $output;
	}

	function preg_conditional_check($matches) {
		//echo "<span style='color: #999900'>[".$matches[1]."::::".$matches[2]."]</span>";
		$x = $this->conditional($matches[1],$matches[2],'otherwise','otherwisecheck');
		//echo "<span style='color: #FF9900'>[$x]</span>";
		return $x;
	}

	function preg_conditional_if($matches) {
		//echo "[<span style='color: #999900'>".$matches[1]."::::".$matches[2]."]</span>";
		return $this->conditional($matches[1],$matches[2]);
	}
	
	function parse_tpl($tpl) {
  		if (!defined("DT_NO_CONDITIONALS")) {
//			$tpl = preg_replace("/\{check (.*?)\}([\s\S]*?)\{\/check\}/ie", "\$this->conditional('\\1','\\2','otherwise','otherwisecheck')",$tpl);
			$tpl = preg_replace_callback("/\{check (.*?)\}([\s\S]*?)\{\/check\}/i", array(&$this,"preg_conditional_check"),$tpl);
//	    	echo "<hr><b>After check</b>:<br> $tpl<hr>";
		
//	    	$tpl = preg_replace("/\{if (.*?)\}([\s\S]*?)\{\/if\}/ie", "\$this->conditional('\\1','\\2')",$tpl);
	    	$tpl = preg_replace_callback("/\{if (.*?)\}([\s\S]*?)\{\/if\}/i", array(&$this,"preg_conditional_if"),$tpl);
//	    	echo "<hr><b>After if</b>:<br> $tpl<hr>";
    	}
  		if (!defined("DT_NO_CUSTOMPLUGINS")) {
			if (is_array($this->plugins)) {
				foreach ($this->plugins as $name=>$func) {
					$regex = "/\{$name\s*(.*?)\}/i";
					if (function_exists($func)) {
						$tpl = preg_replace($regex."e", "\$this->custom_plugin('$name','$func','\\1')",$tpl);
					} else {
						$tpl = preg_replace($regex, "[Error: Custom function {$func}() does not exist]",$tpl);
					}
				}
			}
		}

		return $this->parse_tags($tpl);
	}

	function set($variable,$data) {
      	$output = $this->parse_tags($data);
	    $variable = trim($variable);
    	$this->assign($variable,$output);
	}
	
	function preg_loop($matches) {
		return $this->loop($matches[1],$matches[2],$matches[3]);
	}
	
	function preg_include_template($matches) {
		return $this->include_template($matches[1]);
	}
	
	function preg_set($matches) {
		return $this->set($matches[1],$matches[2],$matches[5]);
	}
	
	// Does the actual parsing of the template.
	function parse() {
		$this->warnings = "";

	    $parsed = $this->template;
	    if (!defined("DT_NO_TRANSFORMS")) {
	    	// do a pre-loop set, in case we want to use variables *in* a loop
		    $parsed = preg_replace_callback("/\{set\s+\\\$([A-Za-z0-9\[\]\\\$_\.]+)\}([\s\S]*?)\{\/set\}/i",array(&$this,"preg_set"),$parsed);
	    }
		if (!defined("DT_NO_LOOPINC")) {
			$parsed = preg_replace_callback("/\{include\s+(?:file\=)?\"(.*?)\"\s*\/?\}/i",array(&$this,"preg_include_template"),$parsed);
	    	$parsed = preg_replace_callback("/\{loop\s+\\\$(.*?)\s*\=\s*\\\$(.*?)\}([\s\S]*?)\{\/loop\}/i",array(&$this,"preg_loop"),$parsed);
    	}
	    if (!defined("DT_NO_TRANSFORMS")) {
	    	// do a post-loop set, for variables we want to use *outside* a loop
		    $parsed = preg_replace_callback("/\{postset\s+\\\$([A-Za-z0-9\[\]\\\$_\.]+)\}([\s\S]*?)\{\/postset\}/i",array(&$this,"preg_set"),$parsed);
	    }
		$this->output = $this->parse_tpl($parsed);
		
		foreach ($this->filters as $name=>$function) {
			$this->output = $function($this->output);
		}
	}

	// Parses the template if necessary, then displays the result.
	function display($template_file,$absolute_path = false) {
		if (!$this->loaded = $this->load_template($template_file,$absolute_path)) return false;
		
		$this->parse();
		echo $this->output;

		// if caching is enabled, then cache the document
		if ($this->cache_expire_time && $this->auto_store_cache) $this->cache($this->cache_id);
		
		if (!DISABLE_TEMPLATE_CACHING && TEMPLATE_CACHE_DEBUG) {
			echo "<div align='center'>Cache miss (\"$this->cache_id\"".($this->cache_prefix?"; prefix: \"{$this->cache_prefix}\"":"").")</div>";
		}
		

		return true;
	}
	
	// Parses the template if necessary, then returns the result.
	//
	// Returns:
	//	The finished, parsed page.
	function get($template_file,$absolute_path = false) {
		if (!$this->loaded = $this->load_template($template_file,$absolute_path)) return false;
		
		$this->parse();
		return $this->output;
	}
	
	// Parses a template passed in a variable (rather than reading it from a
	// file), then returns the result.
	//
	// Returns:
	//	The finished, parsed page.	
	function get_from_var($template) {
		$this->template = $template;
		
		$this->parse();
		return $this->output;
	}
	
	// Saves the previously parsed page to the local cache.
	//
	// Accepts:
	//	$id - a unique value used to identify this cached
	//	      page on subsequent page loads
	//
	// Returns:
	//	TRUE on success, FALSE on failure
	function cache($id) {
		if ($this->nocache_perm_semaphore) {
			if (file_exists($this->nocache_perm_semaphore)) {
				$this->error = "Permanent no-cache semaphore exists; not caching page";
				return false;
			}
		}
		if ($this->nocache_temp_semaphore) {
			if (file_exists($this->nocache_temp_semaphore)) {
				if (filectime($this->nocache_temp_semaphore)+$this->nocache_temp_timeout<time()) {
					@unlink($this->nocache_temp_semaphore);
				} else {
					$this->error = "Permanent no-cache semaphore exists; not caching page";
					return false;
				}
			}
		}
		$this->nocache_perm_semaphore = $permanent;
		$this->nocache_temp_semaphore = $temporary;
		
		
		$expire_time = time() + $this->cache_expire_time;
		$cachefile = CACHE_PATH."/dtcache_".$this->cache_prefix.md5($id)."_{$expire_time}.dat";
		
		$fp = @fopen($cachefile,"w");
		if ($fp) {
			fwrite($fp,$this->output);
			fclose($fp);
			return true;
		} else {
			$this->error = "Unable to create cache file: [$cachefile]";
			return false;
		}
	}

	// Loads a cached page if a valid one exists.
	//
	// Accepts:
	//	$id - the unique identifier for the cached page
	//
	// Returns:
	//	TRUE if a valid, non-expired cached page existed, or FALSE if a new one should be generated
	function load_cache($id) {
		
		// Set the stub for the filename (eg: dtcache_ffffffffffffff_<expiretime>.dat).
		// Note that the expiry time is stored right in the filename to increase performance.
		$cachename = "dtcache_".$this->cache_prefix.md5($id)."_"; 
		$cachename_len = strlen($cachename);
		$cachefile = "";
		
		if (!is_dir(CACHE_PATH)) return false;
		
		// search the cache path for a valid cached copy of the page
		$d = dir(CACHE_PATH); 
		while (false !== ($entry = $d->read())) { 
			
			// did this filename begin with the cache filename stub?
			if (substr($entry,0,$cachename_len)==$cachename) {
				
				// extract the expiry time from the filename
				$expire_time = (int) str_replace(".dat","",substr($entry,$cachename_len));
				
				if ($expire_time > time()) {
					// if the expiry date is later than now, we've got a cache hit
					$cachefile = CACHE_PATH.$entry;
					break;
				} else {
					// otherwise, this is an expired cache file, so we may as well remove
					// it to increase performance on subsequent calls
					@unlink(CACHE_PATH.$entry);
				}
			}
		} 
		$d->close(); 

		// if a cachefile was found above, load and return it
		if ($cachefile) {
			return $this->load_contents($cachefile);
		}
		return false;
	}
	
	// Clears pages from the cache.
	//
	// Accepts:
	//	$prefix - if specified, only the pages with the specified prefix
	//		will be removed from the cache (otherwise ALL pages are removed)
	function clear_cache($prefix="") {
		$cachename = "dtcache_".$prefix;
		$cachename_len = strlen($cachename);
		
		// search the cache path for a valid cached copy of the page
		$d = dir(CACHE_PATH); 
		
		while (false !== ($entry = $d->read())) { 
			
			// did this filename begin with the cache filename stub?
			if (substr($entry,0,$cachename_len)==$cachename) {
				@unlink(CACHE_PATH.$entry);
			}
		} 
		$d->close(); 		
	}
	
	// Loads the contents of the specified file into the output buffer.
	//
	// Accepts:
	//	$filename - the name of the file to read.
	//
	// Returns:
	//	TRUE on success, FALSE on failure.
	function load_contents($filename) {
		$this->output = "";
		
		$fp = fopen($filename,"r");
		if ($fp) {
			while (!feof($fp)) {
				$this->output .= fread($fp,4096);
			}
			fclose($fp);
			
			return true;
		} else {
			$this->error = "Input file $filename not found";
			return false;
		}
	}
	
	
	// Prepares for a set of multiple-page navigation links (for result sets which
	// span multiple pages).
	//
	// $default_pagelimit is the default number of items to display per page; this
	// also returns the number of items per page the user requested.
	//
	// $itemcount is the total number of items available to be displayed.
	//
	// $baseurl is the base URL for each of the page links.
	//
	// This function prepares the template system internally for the result set,
	// and returns the index of the first item to display.
	//
	// Example:
	//
	// $my_items = get_items(); // implement get_items() yourself
	//
	// $pagelimit = 20;			// default to 20 items per page
	// $startindex = $tpl->prepare_multipage($pagelimit,count($my_items),$baseurl);
	//
	// Now you know to return $pagelimit items, starting at $startindex,
	// from your $my_items array.
	//
	// Your template should include a reference to {$_multipage.nav} to
	// display the navigation bar.
	// 
	function prepare_multipage(&$default_pagelimit,$itemcount,$baseurl,$sef = false) {
		$startindex = (int) $_REQUEST["pstart"];
		if ($startindex<0) $startindex = 0;
		
		$pagelimit = (int) $_REQUEST["plimit"];
		if (!$pagelimit) $pagelimit = $default_pagelimit;
		if (!$pagelimit) $pagelimit = 5;
		
		$default_pagelimit = $pagelimit;
		
		$this->multipage["itemcount"] = $itemcount;
		$this->multipage["pagelimit"] = $pagelimit;
		$this->multipage["currentpage"] = $currentpage = ceil($startindex / $pagelimit) + 1;
		$this->multipage["totalpages"] = $totalpages = ceil($itemcount / $pagelimit);
		
		if ($startindex>$itemcount) $startindex = $itemcount - $pagelimit;
		$this->multipage["startindex"] = $startindex = $startindex<0?0:$startindex;
		
		$eq = $sef ? '/' : '=';
		$amp = $sef ? '/' : '&amp;';
		
		$nav = "";
		$previdx = -1;
		$nextidx = -1;

		$overtenstep = 5;
		if ($totalpages>100) $overtenstep = floor($totalpages/10);

		$individualstart = floor($currentpage / $overtenstep) * $overtenstep - $overtenstep;
		if ($individualstart<0) $individualstart = 0;
		
		$individualend = $individualstart + 10;
		if ($individualend>$totalpages) {
			$individualend = $totalpages;
			if ($individualend - 10 >= 0) $individualstart = $individualend - 10;
		}
		
		/*
		$individualstart = floor($currentpage / 5) * 5 - 5; if ($individualstart<0) $individualstart = 0;
		$individualend = $individualstart + 10;
		if ($individualend>$totalpages) {
			$individualend = $totalpages;
			if ($individualend - 10 >= 0) $individualstart = $individualend - 10;
		}

		*/
		
		if ($sef) {
			if (substr($baseurl,-1)!="/") $baseurl .= "/";
		} else {
			$baseurl .= (strpos($baseurl,"?")!==false) ? "&amp;" : "?";
		}
		
		$pagenumber = 1;
		while(true) {			
			$pagestart = ($pagenumber - 1) * $pagelimit;
			
			if ($pagenumber==$currentpage) {
				$nav .= $pagenumber;
			} else {
				$nav .= "<a href=\"{$baseurl}pstart{$eq}{$pagestart}{$amp}plimit{$eq}{$pagelimit}\">".($pagenumber)."</a>";
			}
			$nav .= " | ";
	
			if ($totalpages>10) {
				if ($pagenumber<$individualstart) $pagenumber += $overtenstep;
				elseif ($pagenumber>=$individualend) $pagenumber += $overtenstep;
				else $pagenumber++;
			} else {
				$pagenumber++;
			}

			if ($pagenumber>$totalpages) break;
		}
		
 		$nav = substr($nav,0,strlen($nav)-3);
		
		if ($startindex!=0) {
			$previdx = $startindex - $pagelimit;
			if ($previdx<0) $previdx = 0;
						
			$nav = "<a href=\"{$baseurl}pstart{$eq}{$previdx}{$amp}plimit{$eq}{$pagelimit}\">{$this->page_prev}</a> | ".$nav;
		}
		if ($startindex+$pagelimit<$itemcount) {
			$nextidx = $currentpage * $pagelimit;
			
			$nav .= " | <a href=\"{$baseurl}pstart{$eq}{$nextidx}{$amp}plimit{$eq}{$pagelimit}\">{$this->page_next}</a>";
		}

		$this->multipage["nav"] = $nav;
		
		$this->assign_by_ref("_multipage",$this->multipage);
		return $startindex;
	}
	
	function load_plugin($name) {
		$filename = dirname(__FILE__)."/plugin_{$name}.php";
		if (is_readable($filename) && include($filename)) {
			$registerfunc = "dt_register_{$name}";
			if (function_exists($registerfunc)) {
				return $registerfunc($this);
			}
		}
		
		return false;
	}
	
	function push_template_dir($dir,$fallback_dir=false) {
		array_push($this->template_dirs,$this->template_dir);
		array_push($this->template_fallback_dirs,$this->template_fallback_dir);
		$this->template_dir = $dir;
		$this->template_fallback_dir = $fallback_dir;
	}
	
	function pop_template_dir() {
		$this->template_dir = array_pop($this->template_dirs);
		$this->template_fallback_dir = array_pop($this->template_fallback_dirs);
	}

} // end of class Template


// NOTE: The following functions are NOT members of the Template class,
// they are standalone functions.
// --------------------------------------------------------------------

// Automatically loads and displays a parsed template.  This is useful if you have
// static pages (containing no variables) that are inserted into a templated page layout.
//
// Accepts:
//	The parameter set is identical to that of the constructor for the Template class,
//	except that $cache_auto_display is omitted (since auto-display is assumed)
function display_template($filename,$cache_expire_time=NULL,$cache_id=NULL,$cache_allow_override=true) {
	$tpl = &new Template($cache_expire_time>0,$cache_id,true,$cache_allow_override);

	$tpl->set_cache_lifetime($cache_expire_time);
	if (!$tpl->display($filename)) {
		echo "Error: $tpl->error\n";
	}
	unset($tpl);
}

// Identical to display_template() above, except this function returns the parsed page
// rather than displaying it.
function get_template($filename,$cache_expire_time=NULL,$cache_id=NULL,$cache_allow_override=true) {
	$tpl = &new Template($cache_expire_time>0,$cache_id,true,$cache_allow_override);

	$tpl->set_cache_lifetime($cache_expire_time);
	$res = $tpl->get($filename);
	if ($res===false) {
		echo "Error: $tpl->error\n";
	}
	unset($tpl);
	
	return $res;
}

?>