<?php
/* DirecTemplate Countries Plug-in
 * Version 1.0.0
 * Copyright 2005, Steve Blinch
 * http://code.blitzaffe.com
 * ============================================================================
 *
 * Provides two new variables in DirecTemplate:
 *
 *		{$_COUNTRIES}	An array containing a list of all countries, suitable
 *						for use in <SELECT> tags using {loop}'s
 *		{$_STATES}		An array containing a list of all U.S. states and
 *						Canadian provinces, again suitable for use via {loop}'s
 *
 */
function dt_register_countries(&$tpl) {
	$states = array(
	 	"Alabama","Alaska","Arizona",
	    "Arkansas","California","Colorado","Connecticut","Delaware","District of Columbia","Florida","Georgia","Hawaii",
	    "Idaho","Illinois","Indiana","Iowa","Kansas","Kentucky","Louisiana","Maine","Maryland","Massachusetts","Michigan",
	    "Minnesota","Mississippi","Missouri","Montana","Nebraska","Nevada","New Hampshire","New Jersey","New Mexico","New York",
	    "North Carolina","North Dakota","Ohio","Oklahoma","Oregon","Pennsylvania","Rhode Island","South Carolina","South Dakota",
	    "Tennessee","Texas","Utah","Vermont","Virginia","Washington","West Virginia","Wisconsin",
	    
	    "Alberta","British Columbia","Manitoba","New Brunswick","Newfoundland","Northwest Territories","Nova Scotia",
	    "Nunavut","Ontario","Prince Edward Island","Quebec","Saskatchewan","Yukon Territory",

	    "Other"
	);
	
	$countries = array(    
		"United States","Canada","Afghanistan","Albania","Algeria","American Samoa","Andorra","Angola","Anguilla","Antarctica",
		"Antigua And Barbuda","Argentina","Armenia","Aruba","Australia","Austria","Azerbaijan","Bahamas, The","Bahrain","Bangladesh",
		"Barbados","Belarus","Belgium","Belize","Benin","Bermuda","Bhutan","Bolivia","Bosnia and Herzegovina","Botswana","Bouvet Island",
		"Brazil","British Indian Ocean Territory","Brunei","Bulgaria","Burkina Faso","Burundi","Cambodia","Cameroon","Canada","Cape Verde",
		"Cayman Islands","Central African Republic","Chad","Chile","China","China (Hong Kong S.A.R.)","China (Macau S.A.R.)",
		"Christmas Island","Cocos (Keeling) Islands","Colombia","Comoros","Congo","Congo, Democractic Republic of the","Cook Islands",
		"Costa Rica","Cote D'Ivoire (Ivory Coast)","Croatia (Hrvatska)","Cuba","Cyprus","Czech Republic","Denmark","Djibouti","Dominica",
		"Dominican Republic","East Timor","Ecuador","Egypt","El Salvador","Equatorial Guinea","Eritrea","Estonia","Ethiopia",
		"Falkland Islands (Islas Malvinas)","Faroe Islands","Fiji Islands","Finland","France","French Guiana","French Polynesia",
		"French Southern Territories","Gabon","Gambia, The","Georgia","Germany","Ghana","Gibraltar","Greece","Greenland","Grenada","Guadeloupe",
		"Guam","Guatemala","Guinea","Guinea-Bissau","Guyana","Haiti","Heard and McDonald Islands","Honduras","Hungary","Iceland","India","Indonesia",
		"Iran","Iraq","Ireland","Israel","Italy","Jamaica","Japan","Jordan","Kazakhstan","Kenya","Kiribati","Korea","Korea, North","Kuwait","Kyrgyzstan",
		"Laos","Latvia","Lebanon","Lesotho","Liberia","Libya","Liechtenstein","Lithuania","Luxembourg","Macedonia, Former Yugoslav Rep. of",
		"Madagascar","Malawi","Malaysia","Maldives","Mali","Malta","Marshall Islands","Martinique","Mauritania","Mauritius","Mayotte","Mexico",
		"Micronesia","Moldova","Monaco","Mongolia","Montserrat","Morocco","Mozambique","Myanmar","Namibia","Nauru","Nepal","Netherlands Antilles",
		"Netherlands, The","New Caledonia","New Zealand","Nicaragua","Niger","Nigeria","Niue","Norfolk Island","Northern Mariana Islands","Norway",
		"Oman","Pakistan","Palau","Panama","Papua new Guinea","Paraguay","Peru","Philippines","Pitcairn Island","Poland","Portugal","Puerto Rico","Qatar",
		"Reunion","Romania","Russia","Rwanda","Saint Helena","Saint Kitts And Nevis","Saint Lucia","Saint Pierre and Miquelon",
		"Saint Vincent And The Grenadines","Samoa","San Marino","Sao Tome and Principe","Saudi Arabia","Senegal","Seychelles","Sierra Leone",
		"Singapore","Slovakia","Slovenia","Solomon Islands","Somalia","South Africa","South Georgia & South Sandwich Isles","Spain",
		"Sri Lanka","Sudan","Suriname","Svalbard And Jan Mayen Islands","Swaziland","Sweden","Switzerland","Syria","Taiwan","Tajikistan","Tanzania",
		"Thailand","Togo","Tokelau","Tonga","Trinidad And Tobago","Tunisia","Turkey","Turkmenistan","Turks And Caicos Islands","Tuvalu","Uganda","Ukraine",
		"United Arab Emirates","United Kingdom","United States","United States Minor Outlying Islands","Uruguay","Uzbekistan","Vanuatu",
		"Vatican City State (Holy See)","Venezuela","Vietnam","Virgin Islands (British)","Virgin Islands (US)","Wallis And Futuna Islands",
		"Western Sahara","Yemen","Yugoslavia","Zambia","Other"
	);
	
	$tpl->assign("_COUNTRIES",$countries);
	$tpl->assign("_STATES",$states);
	
	return true;
}
?>