<?php
/* DirecTemplate - Simple, efficient template system
 * Version 1.1.1
 * Copyright 2003-2005, Steve Blinch
 * http://code.blitzaffe.com
 * ============================================================================
 *
 * LICENSE
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

require_once("../class_Template.php");

// instantiate the template
$tpl = &new Template();

// set the path to the template directory
$tpl->template_dir = dirname(__FILE__)."/templates/";

// In order to display dynamic text in a template, we put placeholders
// such as "{$title}" in the template file.  Then, we use $tpl->assign() to
// bind a variable to that placeholder.
//
// So if, in your template (header.tpl), you have the following:
// <title>{$title}</title>
//
// Then it will be replaced with:
// <title>DirecTemplate example</title>

// bind the words "DirecTemplate example" to the "title" placeholder
$tpl->assign("title","DirecTemplate example");
// display "header.tpl" (located in the "templates" directory)
$tpl->display("header.tpl");


// set a couple of sample strings
$name = "John Smith";
$phone = "555-555-1234";
$email = "jsmith@example.com";
$company = "John Smith & Sons";

// setup a sample array containing a number of ficticious products
$products = array(
	"purple" => array(
		"id"=>1234,
		"price"=>59.99,
		"name"=>"Purple Widget"
	),
	"blue" => array(
		"id"=>4321,
		"price"=>29.99,
		"name"=>"Blue Widget"
	),
	"red" => array(
		"id"=>2345,
		"price"=>39.99,
		"name"=>"Red Widget"
	)
);

// next, we bind the variables above to the template class
$tpl->assign("name",$name);
$tpl->assign("phone",$phone);
$tpl->assign("email",$email);
$tpl->assign("company",$company);
$tpl->assign("products",$products);

// then, display the order - please refer to order.tpl for details
$tpl->display("order.tpl");

// and finally, display the footer
$tpl->display("footer.tpl");

?>