<?php
/* DDNS Server
 * Copyright 2006, Steve Blinch
 * http://code.blitzaffe.com
 * ============================================================================
 *
 * This script is free software; you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * This script is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *	
 * You should have received a copy of the GNU General Public License along
 * with this script; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

require_once(dirname(__FILE__).'/config.php');
require_once(dirname(__FILE__).'/class_BINDInterface.php');

function set_header($header) {
	if ($_SERVER['TSHTTPD']) {
		$GLOBALS['tshttpd']->set_header($header);
	} else {
		header($header);
	}
}

function invalid_vhost() {
//	if ($_SERVER['TSHTTPD']) return false;
	
	set_header("HTTP/1.0 404 Not Found");
	echo "<html><body><h1>Not Found</h1></body></html>";
}


$bind = &new BINDInterface(BIND_CFG_PATH,BIND_CFG_PREFIX);

$hostname = $_SERVER['HTTP_HOST'];

// if the base domain is not valid, exit
if (!$bind->load_domain_by_subdomain($hostname)) return invalid_vhost();

// if the subdomain doesn't exist, exit
if (!$host = $bind->get_host($hostname)) return invalid_vhost();

// if the subdomain isn't marked as offline, exit
if (!$host['account']['offline']) return invalid_vhost();

// if the subdomain isn't marked as offline, exit
if (!$host['account']['offlineurl']) {
	echo "<html><body><h1>Host Offline</h1><p>This host is currently in offline mode.</p><p>Please come back later.</p></body></html>";
	return;
}

set_header("Location: " . $host['account']['offlineurl']);
?>