<?php
// Path to your webserver-writable BIND configuration directory
define('BIND_CFG_PATH','/etc/bind/dynamic/');

// Filename prefix for your webserver-writable zone files (base domain
// and user-provided subdomain will be appended)
define('BIND_CFG_PREFIX','db.');

// TRUE if users should be able to add "&zonecreate=email@domain.tld"
// to UPDATE queries to create new hosts on-the-fly, otherwise false.
define('ALLOW_ZONE_CREATION',true);

// Set a password here to prevent users from creating new hostnames
// unless they know the password; leave this set to false to allow
// anyone to create a new hostname (assuming ALLOW_ZONE_CREATION is true).
define('ZONE_CREATION_TOKEN','secret');

// Offline IP address; if you plan to offer "offline" fallback
// functionality, enter the IP address of the server which will
// handle fallback requests.  Note that this only works if you're
// using this script in "standalone" mode under ucspi-tcp's tcpserver
// (using the scripts under ddnssrvd/).
define('OFFLINE_IP',$_SERVER['SERVER_ADDR']);

// Specifies the amount of time DNS values are cached for.  Lower
// values will decrease the amount of downtime when your IP changes,
// but increase the load on your server.
define('DNS_CACHE_TIME',5*60);

// Set this to a list of "base" domains under which you intend to
// provide subdomains.  Note that the bind installation whose configuration
// files are referenced above in BIND_CFG_PATH must already be configured to
// serve these domains
$base_domains = array(
	'example.com',
//	'yet-another-domain.com',
);
?>
