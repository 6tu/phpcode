<?php
/* DDNS Server
 * Version 1.0.0
 * Copyright 2006, Steve Blinch
 * http://code.blitzaffe.com
 * ============================================================================
 *
 * DESCRIPTION
 *
 * This script allows you to setup your own dynamic DNS service on any server
 * running BIND v8.  It is fully compatible with the dyndns.org API, so you can
 * use any dyndns.org-compatible update client to keep your IP address
 * up-to-date (assuming your client allows you to submit updates to hosts other
 * than dyndns.org).
 *
 * This script has several benefits and several drawbacks vs. using a service
 * such as dyndns.org.
 *
 * Benefits:
 *	- You have full, in-house control over the service.
 *	- You can use your own domain name(s) without having to pay any fees.
 *	- You don't need to worry about your hostname expiring if you don't update
 *	  it (as this script doesn't handle automatic 30-day expirations)
 *
 * Drawbacks:
 *	- Services like dyndns.org are probably more reliable than your own DNS
 *	  server (due to multiple redundancy and aggressive monitoring)
 *	- You have to configure your DNS Update client to point to your own server
 *	  (which may or may not be possible with all dynamic DNS update clients)
 *  - The web UI is fairly limited at the moment (although there's nothing
 *    stopping you from improving it).
 *
 * This script also supports "offline" mode; clients can specify an alternate
 * URL to which visitors should be redirected when the client's own dynamic-IP
 * server goes offline.
 *
 * 
 * INSTALLATION
 *
 * 1) Create a directory under your BIND configuration directory and give it
 *    appropriate permissions such that the webserver user account can write
 *    to it.
 * 2) Unpack all of the DDNS Server files to the web root of the virtual host
 *    you plan to use for your web interface.  Be sure that Apache's
 *    mod_rewrite extension is installed and enabled for this host.
 * 3) Edit config.php and follow the instructions.  Be sure to configure
 *    everything.
 * 4) Edit the restart_bind script and ensure that the path to bind is correct.
 *    Make sure it's executable by root.
 * 5) Edit the zone file(s) for the domain(s) you plan to make available through
 *    your dynamic DNS service.  Add $INCLUDE directives to each one, to import
 *    the dynamic DNS data file (created by DDNS Server) for each domain.  For
 *    example, if you're using the default BIND_CFG_PATH and BIND_CFG_PREFIX
 *    from config.php.dist, and your domain was example.com, you'd add the
 *    following to your existing zone file:
 *		$INCLUDE        /etc/bind/dynamic/db.example.com
 * 6) Add a cronjob to your /etc/crontab that looks something like this:
 *    * * * * * root /path/to/this/script/restart_bind
 *
 * Next, just point your web browser to your virtual host and hopefully you'll
 * see a form allowing you to create/update your hostname.  If not, tinker with
 * it until you do. :)
 *
 *
 * RUNNING STANDALONE
 *
 * For security reasons, I personally do not have a webserver installed on my
 * primary nameserver, and I didn't want to install one just for this trivial
 * little script.
 *
 * Obviously, however, this script needs to run on the same machine as BIND.
 * To get around this problem, I use the ucspi-tcp and daemontools packages
 * (made by DJB of qmail fame, at http://cr.yp.to/ucspi-tcp.html and
 * http://cr.yp.to/daemontools.html) to run the DDNS Server as its own daemon.
 *
 * This requires some prior knowledge (and a working installation) of DJB's
 * ucspi-tcp and daemontools packages; qmail users will be right at home here.
 * If you don't already have these installed, stop here.
 *
 * To setup DDNS Server as its own daemon:
 *
 * 1) Edit the ddnssrvd/config.php configuration file and set your hostname.
 * 2) Edit ddnssrvd/service/run and make sure all of the paths are correct and
 *    the appropriate user/group exists.
 * 3) Link the ddnssrvd/service/ directory into /service so that you can control
 *    it with the "svc" command.
 *
 * From there, ddnssrvd/ddnssrvd.php will act as its own standalone micro-
 * webserver, and will service requests on the port number you configured in the
 * run file.
 *
 *
 * LICENSE
 *
 * This script is free software; you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * This script is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *	
 * You should have received a copy of the GNU General Public License along
 * with this script; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

require_once(dirname(__FILE__).'/include.php');

$tpl->assign('cancreate',defined('ALLOW_ZONE_CREATION') && ALLOW_ZONE_CREATION);
$tpl->assign('needtoken',defined('ZONE_CREATION_TOKEN') && (ZONE_CREATION_TOKEN!=false));
$tpl->assign('basedomains',$base_domains);

$tpl->display('header.tpl');
$tpl->display('form.tpl');
$tpl->display('footer.tpl');

?>