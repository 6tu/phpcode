<?php
/* DDNS Server
 * Copyright 2006, Steve Blinch
 * http://code.blitzaffe.com
 * ============================================================================
 *
 * This script is free software; you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * This script is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *	
 * You should have received a copy of the GNU General Public License along
 * with this script; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

define('NIC_INITIALIZED',true);
require(dirname(__FILE__).'/../config.php');
require_once(dirname(__FILE__).'/../class_BINDInterface.php');

function set_header($header) {
	if ($_SERVER['TSHTTPD']) {
		$GLOBALS['tshttpd']->set_header($header);
	} else {
		header($header);
	}
}

function status_exit($status) {
	$verbose_codes = array(
		'badagent'=>'Your user agent is not valid.',
		'badauth'=>'Invalid username or password.  Authentication failed.',
		'notfqdn'=>'The hostname you specified was not valid.',
		'dnserr'=>'A DNS error has occurred on our end.  We apologize for any inconvenience.',
		'!yours'=>'The specified hostname does not belong to you.',
		'nohost'=>'The specified hostname does not exist.',
		'good'=>'Your hostname has been updated.',
		'911'=>'A critical error has occurred on our end.  We apologize for any inconvenience.',
		'nochg'=>'This update was identical to your last update, so no changes were made to your hostname configuration.'
	);
	if ($_REQUEST['verbose']) {
		list($code,$msg) = explode(' ',$status,2);
		$status = $verbose_codes[$code] . ($msg?' '.$msg:'');
	}
	echo "$status\n";
	return false;
}
function yn($s) {
	$s = strtolower($s);
	if ($s=='nochg') return '-';
	return substr($s,0,1);
}

if (!$_SERVER['HTTP_USER_AGENT']) return status_exit('badagent');

list($uri,$query) = explode('?',$_SERVER['REQUEST_URI'],2);

if (!isset($_SERVER['PHP_AUTH_USER'])) {
	set_header('WWW-Authenticate: Basic realm="DNS Update"');
	set_header('HTTP/1.0 401 Unauthorized');
	return status_exit('badauth');
 }

$username = strtolower($_SERVER['PHP_AUTH_USER']);
$password = md5(strtolower($_SERVER['PHP_AUTH_PW']));

if (!strlen($_REQUEST['hostname'])) return status_exit('notfqdn');

$bind = &new BINDInterface(BIND_CFG_PATH,BIND_CFG_PREFIX);

$hostnames = explode(',',$_REQUEST['hostname']);
foreach ($hostnames as $k=>$hostname) {
	require(dirname(__FILE__).'/update.php');
}

?>