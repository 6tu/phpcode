<?php
/* DDNS Server
 * Copyright 2006, Steve Blinch
 * http://code.blitzaffe.com
 * ============================================================================
 *
 * This script is free software; you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * This script is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *	
 * You should have received a copy of the GNU General Public License along
 * with this script; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

if (!defined('NIC_INITIALIZED')) die;

$hostname = strtolower($hostname);
if (!preg_match('/^[a-z0-9\.-]+$/i',$hostname)) return status_exit('notfqdn');

$selected_basedomain = false;
$domainok = false;
reset($base_domains);
foreach ($base_domains as $m=>$basedomain) {
	if (substr($hostname,-strlen($basedomain))==$basedomain) {
		$selected_basedomain = $basedomain;
		$domainok = true;
		break;
	}
}
if (!$domainok) return status_exit('notfqdn');

$ip = $_REQUEST['myip'];
if (!preg_match('/^((?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/i',$ip)) {
	return status_exit('dnserr');
}

$hostdot = $hostname.'.';

if (!$bind->load_domain($selected_basedomain)) return status_exit('dnserr');

if (!$host = $bind->get_host($hostname)) {
	if (defined('ALLOW_ZONE_CREATION') && ALLOW_ZONE_CREATION && $_REQUEST['zonecreate']) {
		if ( defined('ZONE_CREATION_TOKEN') && (ZONE_CREATION_TOKEN!=false) && ($_REQUEST['zonetoken']!=ZONE_CREATION_TOKEN) ) {
			return status_exit('badauth');
		}

		$account['username'] = $username;
		$account['password'] = $password;
		$account['email'] = $_REQUEST['zonecreate'];

		$bind->new_host($hostname,$account);

	} else {
		return status_exit('nohost');
	}
} else {
	if ($host['account']['username']!=$username) return status_exit('!yours');
	if ($host['account']['password']!=$password) return status_exit('badauth');
}

$origacct = $bind->host['account'];
$origacct['ip'] = $bind->host['rr']['a'][0]['address'];

$mx = strtolower($_REQUEST['mx']);
if ($mx!='nochg') {
	$bind->delete_rr(false,'mx');
	if (strlen($mx)) {
		
		$backupmx = strtolower($_REQUEST['backmx']);
		if ($backupmx=='nochg') $backupmx = $bind->host['account']['backmx'];
		
		if (yn($backupmx)=='y') {
			$bind->host['account']['backmx'] = 1;
			$priority = 20;
			
			$bind->add_rr($hostdot,'mx',$ip,10,DNS_CACHE_TIME);
		} else {
			$bind->host['account']['backmx'] = 0;
			$priority = 10;
		}
		$bind->add_rr($hostdot,'mx',$mx.'.',$priority,DNS_CACHE_TIME);
		
	}
}

$bind->host['account']['offline'] = (int) (yn($_REQUEST['offline'])=='y');

if (isset($_REQUEST['offlineurl'])) {
	$offlineurl = $_REQUEST['offlineurl'];
	if (strtolower($offlineurl)!='nochg') $bind->host['account']['offlineurl'] = $offlineurl;
}
if ( $bind->host['account']['offline'] && defined('OFFLINE_IP') && OFFLINE_IP) {
	$ip = OFFLINE_IP;
}

switch(yn($_REQUEST['wildcard'])) {
	case 'y':
		$bind->set_rr('*.'.$hostdot,'a',$ip,false,DNS_CACHE_TIME);
		$bind->host['account']['wildcard'] = 1;
		break;
	case 'n':
		$bind->delete_rr('*.'.$hostdot,'a');
		$bind->host['account']['wildcard'] = 0;
		break;
}

$bind->set_rr($hostdot,'a',$ip,false,DNS_CACHE_TIME);

$newacct = $bind->host['account'];
$newacct['ip'] = $ip;

if (count($x = array_diff_assoc($newacct,$origacct))) {
	if ($bind->save_host($hostname)) {
		return status_exit('good '.$ip);
	} else {
		return status_exit('911 '.$bind->error);
	}
} else {
	return status_exit('nochg '.$ip);
}
?>