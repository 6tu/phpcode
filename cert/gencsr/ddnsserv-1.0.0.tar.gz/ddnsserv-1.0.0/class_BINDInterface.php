<?php
/* DDNS Server
 * Copyright 2006, Steve Blinch
 * http://code.blitzaffe.com
 * ============================================================================
 *
 * This script is free software; you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * This script is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *	
 * You should have received a copy of the GNU General Public License along
 * with this script; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

class BINDInterface {
	
	function BINDInterface($configpath,$configprefix) {
		$this->path = $configpath;
		if (substr($this->path,-1)!='/') $this->path .= '/';
		$this->fileprefix = $configprefix;
	}
	
	function load_domain_by_subdomain($subdomain) {
		$segments = explode('.',$subdomain);
		$n = count($segments)-1;
		while ($n>=2) {
			$domain = implode('.',array_slice($segments,-$n));

			if ($this->load_domain($domain)) return true;
			
			$n--;
		}
		
		return false;
	}
	
	function load_domain($domain) {
		$domain = preg_replace('/[^a-z0-9_\.-]+/i','',$domain);
		$this->domain = $domain;
		
		$domainfile = $this->fileprefix . $domain;
		$filename = $this->path . $domainfile;
		if (!file_exists($filename)) return false;
		
		$hostlist = @file($filename);
		if (!is_array($hostlist)) return false;
		
		foreach ($hostlist as $k=>$host) {
			$host = trim($host);
			if (!$host) continue;
			if (substr($host,0,1)==';') continue;
			list(,$pathname) = explode(' ',$host);
			
			$filename = basename($pathname);
			if (substr($filename,0,strlen($domainfile)+1)!=$domainfile.'-') continue;
			$subdomain = substr($filename,strlen($domainfile)+1) . '.' . $domain;
			
			$this->subdomains[$subdomain] = $pathname;
		}
		
		return true;
	}
	
	function get_host($hostname) {
		if (!$hostfilename = $this->subdomains[$hostname]) return false;
		
		$host = array();
		
		$hostdata = @file($hostfilename);
		if (!is_array($hostdata)) return false;
		
		foreach ($hostdata as $k=>$line) {
			
			if (preg_match('/\;\s*config\=([a-z0-9\._-]+):([a-z0-9]+):([a-z0-9\.\@_-]+):([01]):([01]):([^\:]*):([01])/i',$line,$matches)) {
				$host['account'] = array(
					'username'=>$matches[1],
					'password'=>$matches[2],
					'email'=>$matches[3],
					'wildcard'=>$matches[4],
					'backmx'=>$matches[5],
					'offlineurl'=>base64_decode($matches[6]),
					'offline'=>$matches[7],
				);
			}			
			$p = strpos($line,";");
			if ($p!==false) $line = substr($line,0,$p);
			$line = trim($line);
			if (!$line) continue;
			
			if (preg_match('/^\$ORIGIN\s+([a-z0-9\.-]+)\.$/i',$line,$matches)) $host['hostname'] = trim($matches[1]);
			if (preg_match("/^\$TTL\s+([0-9]+)/i",$line,$matches)) $host['ttl'] = $matches[1];
			
			// grab CNAME/A/NS records
			if (preg_match("/((?:\*\.)?[A-Za-z][A-Za-z0-9_\.\*-]+)?\s*(?:([0-9]+)\s*)?IN\s+(CNAME|A|NS)\s+(.*?)$/i",$line,$matches)) {
				list(,$subdomain,$ttl,$recordtype,$address) = $matches;
				$host["rr"][strtolower($recordtype)][] = array(
					"name"=>$subdomain,
					"address"=>$address,
					"ttl"=>$ttl
				);
			}
//[A-Za-z]{1}
			// grab MX records
			if (preg_match("/([A-Za-z][A-Za-z0-9_\.\*-]+)?\s*(?:([0-9]+)\s*)?IN\s+MX\s+([0-9]+)\s+(.*?)$/i",$line,$matches)) {
				list(,$subdomain,$ttl,$priority,$address) = $matches;
				$host["rr"]["mx"][] = array(
					"name"=>$subdomain,
					"address"=>$address,
					"priority"=>$priority,
					"ttl"=>$ttl
				);
			}
		}
	
		$host['subdomain'] = substr($host['hostname'],0,strlen($host['hostname'])-strlen($this->domain)-1);
	
		$this->host = $host;	
		return $host;
		
	}
	
	function new_host($hostname,$account) {
		$host = array();
		$host['account'] = $account;
		$host['hostname'] = $hostname;
		$host['new'] = true;
		$host['subdomain'] = substr($host['hostname'],0,strlen($host['hostname'])-strlen($this->domain)-1);
		$this->host = $host;
	}

	function delete_rr($name,$type) {
		$type = strtolower($type);
		
		if ($name===false) {
			unset($this->host['rr'][$type]);
		} else {
			foreach ($this->host['rr'][$type] as $k=>$record) {
				if ($record['name']==$name) unset($this->host['rr'][$type][$k]);
			}
		}
	}
	
	function set_rr($name,$type,$address,$priority=false,$ttl=false,$can_update=true) {
		$rr = array(
			"name"=>$name,
			"address"=>$address
		);
		if ($priority) $rr["priority"] = $priority;
		if ($ttl) $rr["ttl"] = $ttl;

		$updated = false;
		$type = strtolower($type);
		if (($can_update) && (is_array($this->host['rr'][$type])) ) {
			foreach ($this->host['rr'][$type] as $k=>$record) {
				if ($record['name']==$name) {
					$this->host['rr'][$type][$k] = $rr;
					$updated = true;
				} 
			}
		}
		if (!$updated) $this->host["rr"][$type][] = $rr;
	}
	
	function add_rr($name,$type,$address,$priority=false,$ttl=false) {
		$this->set_rr($name,$type,$address,$priority,$ttl,false);
	}
	
	function recordsort($a,$b) {
		$aname = preg_replace("/^\*\./","~.",$a["name"]);
		$bname = preg_replace("/^\*\./","~.",$b["name"]);
		if ($aname == $bname) return 0; 
		return ($aname < $bname) ? -1 : 1;
   	}
	
	function assemble_host() {
		$host = &$this->host;
		$rrmain = "";
		$rrsub = "";
		
		foreach ($host["rr"] as $type=>$records) {
			$type = strtoupper($type);
			$pending = "\n;\n; {$type} records\n;\n\n";
			usort($records,array(&$this,"recordsort"));
			foreach ($records as $k=>$record) {
				if ($type=="MX") {
					$recordinfo = sprintf("        IN  MX  %-8s%s\n",$record["priority"],$record["address"]);
				} else {
					$recordinfo = sprintf("        IN      %-8s%s\n",$type,$record["address"]);
				}
				if ($record["ttl"]) {
					$recordinfo = sprintf("        %-8s",$record["ttl"]).$recordinfo;
				}
				
				if ($record["name"]) {
					$rrsub .= $pending . sprintf("%-16s",$record["name"]).$recordinfo;
					$pending = "";
				} else {
					$rrmain .= "                        ".$recordinfo;
				}
			}
		}

		$res = sprintf(
"
\$ORIGIN %s.
; config=%s:%s:%s:%d:%d:%s:%d

%s

%s
",
	$host['hostname'],
	$host['account']['username'],
	$host['account']['password'],
	$host['account']['email'],
	$host['account']['wildcard'],
	$host['account']['backmx'],
	base64_encode($host['account']['offlineurl']),
	$host['account']['offline'],
	$rrmain,
	$rrsub
);
		return $res;
	}

	function save_host() {

		$hostfile = $this->path . $this->fileprefix . $this->domain . '-' . $this->host['subdomain'];

		$backupfile = $hostfile.'.bak';
		
		$hostcontent = $this->assemble_host();
		
		if (file_exists($hostfile)) {
			if (!copy($hostfile,$backupfile)) {
				$this->error = "Could not backup DNS database for " . $this->host['hostname'];
				return false;
			}
		}

		$fp = @fopen($hostfile,"w");
		if ($fp) {
			fwrite($fp,$hostcontent);
			fclose($fp);
			
			if ($this->host['new']) {
				$domainfile = $this->path . $this->fileprefix . $this->domain;
				
				$backupfile = $domainfile.'.bak';
				if (file_exists($domainfile)) {
					if (!copy($domainfile,$backupfile)) {
						$this->error = "Could not backup domain configuration file for " . $this->domain;
						return false;
					}
				}

				$fp = @fopen($domainfile,'a');
				if (!$fp) {
					$this->error = "Could not open domain configuration file for " . $this->domain;
					return false;
				}
				
				$hostinclude = '$INCLUDE ' . $hostfile . "\n";
				
				fwrite($fp,$hostinclude);
				fclose($fp);
			}
			
			
			$fp = @fopen($this->path.'.need_restart','w');
			if (!$fp) {
				$this->error = "Could not create restart semaphore file";
				return false;
			} else {
				fwrite($fp,"This file indicates that bind needs a restart; do not remove it manually.\n");
				fclose($fp);
			}
			return true;
		} else {
			$this->error = "Could not open DNS database for " . $this->host['hostname'];
			return false;
		}
		
		
	}

}
?>