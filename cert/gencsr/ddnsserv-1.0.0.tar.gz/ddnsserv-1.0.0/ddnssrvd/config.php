<?php

// If running the script in "standalone" mode (using the scripts under
// ddnssrvd/) you must specify the hostname on which the server will
// accept requests.
define('SERVER_HOSTNAME','ddns.example.com');

?>