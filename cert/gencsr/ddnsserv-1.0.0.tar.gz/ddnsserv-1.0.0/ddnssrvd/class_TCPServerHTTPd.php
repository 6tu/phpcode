<?php
/* TCPServerHTTPd Class
 * Version 1.0.0
 * Copyright 2006, Steve Blinch
 * http://code.blitzaffe.com
 * ============================================================================
 *
 * DESCRIPTION
 *
 * Provides a pure-PHP implementation of a simple HTTP server, designed to run
 * using the ucspi-tcp and daemontools packages (made by DJB of qmail fame, at
 * http://cr.yp.to/ucspi-tcp.html and http://cr.yp.to/daemontools.html).
 *
 * It can serve both regular files and normal PHP scripts.
 *
 *
 * INTRODUCTION
 *
 * For security and performance reasons, I do not have a webserver installed
 * on every one of my server machines.  Sometimes a webserver can come in handy,
 * however, to provide a simple web interface to a particular service for
 * reporting or control.
 *
 * To solve this problem, I use the ucspi-tcp and daemontools packages in
 * conjunction with the PHP commandline interpreter and this HTTP server class
 * to create custom web server applications as needed.
 *
 * This requires some prior knowledge (and a working installation) of DJB's
 * ucspi-tcp and daemontools packages; qmail users will be right at home here.
 * If you don't already have these installed, stop here.
 *
 *
 * USAGE
 *
 * To implement your own HTTP service on top of TCPServerHTTPd, you should
 * subclass TCPServerHTTPd and implement the handle_request() method and possibly
 * the initialize() method.  Refer to the comments for both methods below for
 * details.
 *
 * To setup DDNS Server as its own daemon:
 *
 * 1) Edit the ddnssrvd/config.php configuration file and set your hostname.
 * 2) Edit ddnssrvd/service/run and make sure all of the paths are correct and
 *    the appropriate user/group exists.
 * 3) Link the ddnssrvd/service/ directory into /service so that you can control
 *    it with the "svc" command.
 *
 * From there, ddnssrvd/ddnssrvd.php will act as its own standalone micro-
 * webserver, and will service requests on the port number you configured in the
 * run file.
 *
 *
 * EXAMPLE
 *
 * The following is a very simple example of a TCPServerHTTPd subclass.
 *
 * require_once(dirname(__FILE__).'/class_TCPServerHTTPd.php');
 * 
 * class SampleHTTPd extends TCPServerHTTPd {
 * 	
 * 	function SampleHTTPd() {
 * 	}
 * 	
 * 	function initialize() {
 * 		parent::initialize();
 * 		$this->server_name = 'SampleHTTPd';
 * 		$this->server_version = '1.0';
 * 		$this->content_type = 'text/plain';	
 * 		$this->document_root = dirname(__FILE__).'/htdocs/';
 * 	}
 * 	
 * 	function handle_request($uri) {
 * 		if ($uri=='/time_of_day.html') {
 * 			// send an HTTP 200 OK response and send all headers
 * 			$this->send_headers(200);
 * 			
 * 			$time = date('Y-m-d H:ia');
 * 			$this->_write_socket("<html><body>The time of day is: <strong>$time</strong></body></html>");
 * 		} else {
 * 			$this->serve_document_root($uri);
 * 		}
 * 	}	
 * }
 *
 *
 * Requesting http://<your_server_ip>/time_of_day.html will display the current
 * time of day.  Requesting any other URL will serve the appropriate file from
 * the htdocs/ subdirectory, or return a 404 Not Found error.
 *
 *
 * LICENSE
 *
 * This script is free software; you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * This script is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *	
 * You should have received a copy of the GNU General Public License along
 * with this script; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
 
require_once(dirname(__FILE__).'/class_MIMETypes.php');

class TCPServerHTTPd {

	/* This method initializes the TCPServerHTTPd instance and prepares various
	 * variables used while processing the request.
	 *
	 * Of particular interest to most subclass implementations will be:
	 * 
	 * $this->server_name
	 * $this->server_version
	 * $this->server_admin
	 * $this->content_type
	 * $this->document_root
	 *
	 * Be sure to call parent::initialize() as the first line of your
	 * ::initialize() method implementation.
	 *
	 */
	function initialize() {
		$this->server_name = 'TCPServerHTTPd';
		$this->server_version = '1.0';
		$this->server_admin = 'admin@localhost';
		$this->server_host = $_ENV['TCPLOCALIP'];
		$this->server_port = $_ENV['TCPLOCALPORT'];
		$this->client_host = $_ENV['TCPREMOTEIP'];
		$this->client_port = $_ENV['TCPREMOTEPORT'];
		$this->http_version = '1.0';
		$this->content_type = 'text/html';	
		$this->charset = 'iso-8859-1';
		$this->document_root = '';
		$this->codes = array(
			100=>"Continue",
			101=>"Switching Protocols",
			200=>"OK",
			201=>"Created",
			202=>"Accepted",
			203=>"Non-Authoritative Informatoin",
			204=>"No Content",
			205=>"Reset Content",
			206=>"Partial Content",
			300=>"Multiple Choices",
			301=>"Moved Permanently",
			302=>"Found",
			303=>"See Other",
			304=>"Not Modified",
			305=>"Use Proxy",
			307=>"Temporary Redirect",
			400=>"Bad Request",
			401=>"Unauthorized",
			402=>"Payment Required",
			403=>"Forbidden",
			404=>"Not Found",
			405=>"Method Not Allowed",
			405=>"Not Acceptable",
			407=>"Proxy Authentication Required",
			408=>"Request Timeout",
			409=>"Conflict",
			410=>"Gone",
			411=>"Length Required",
			412=>"Precondition Failed",
			413=>"Request Entity Too Large",
			414=>"Request-URI Too Long",
			415=>"Unsupported Media Type",
			416=>"Requested Range Not Satisfiable",
			417=>"Expectation Failed",
			500=>"Internal Server Error",
			501=>"Not Implemented",
			502=>"Bad Gateway",
			503=>"Service Unavailable",
			504=>"Gateway Timeout",
			505=>"HTTP Version Not Supported",
		);
		
		$this->default_indexes = array(
			'index.php',
			'index.html',
			'index.htm'
		);
		
		$this->supported_methods = array(
			'GET'	=> 'handle_get',
			'POST'	=> 'handle_post',
		);
	}

	/* Override this method in your subclass to handle the request.
	 * $uri contains the URI that was requested by the client.
	 *
	 * A very basic implementation would be simply:
	 *    $this->serve_document_root($uri);
	 *
	 * ...which would simply handle the request as a normal webserver
	 * would, using $this->document_root as the document root.
	 *
	 * Note that (unless using ::serve_document_root()) you are
	 * responsible for calling ::send_headers() or ::http_error() to
	 * send the HTTP response headers prior to sending any output.
	 *
	 * Following the headers, you should output your HTTP response.
	 */
	function handle_request($uri) {
		return $this->http_error(501);	
	}

	/* This is an internal method used to setup and prepare the HTTP server.
	 */	
	function process_request() {
		$this->initialize();

		$this->server_signature = "{$this->server_name}/{$this->server_version} Server at {$this->server_host}";
		if ($this->server_port) $this->server_signature .= " Port {$this->server_port}";
		
		$this->_open_socket();
		
		$request = rtrim($this->_read_socket());
		if (!preg_match('/^(GET|POST|HEAD|PUT|DELETE|TRACE|CONNECT) (\/[^\s]*) HTTP\/([1-9]+\.[0-9])$/',$request,$matches)) {
			return $this->http_error(400);
		}
		list(,$method,$uri,$http_version) = $matches;
		$this->http_version = $http_version;
		$this->request_method = $method;
		
		if (!$method_handler = $this->supported_methods[$method]) {
			return $this->http_error(501);
		}
		$method_handler = array(&$this,$method_handler);
		if (!is_callable($method_handler)) {
			return $this->http_error(501);
		}
		
		$this->client_headers = array();
		while (true) {
			$header = rtrim($this->_read_socket());
			if ($header=='') break;
			list($header,$value) = explode(':',$header);
			$this->client_headers[$header] = substr($value,1);
			
			if (strtolower($header)=='host') $this->http_host = trim($value);
		}

		call_user_func($method_handler,$uri);
		
		$this->_close_socket();
	}
	
	/* Parses a URI for a query string; returns an array containing the
	 * query string as the first element, and an array of key=>value pairs
	 * from the query string as the second element.
	 */
	function parse_uri($uri) {
		list($uri,$query_string) = explode('?',$uri,2);
		$this->get_query_string = $query_string;
		parse_str($query_string,$vars);
		return array($uri,$vars);
	}
	
	/* Handles an HTTP GET request for the URL specified by $uri.
	 */
	function handle_get($uri) {
		list($uri,$this->client_variables['get']) = $this->parse_uri($uri);
		$this->execute_request($uri);
	}

	/* Handles an HTTP POST request for the URL specified by $uri.
	 */
	function handle_post($uri) {
		$query_string = rtrim($this->_read_socket());
		parse_str($query_string,$this->client_variables['post']);
		
		list($uri,$this->client_variables['get']) = $this->parse_uri($uri);
		$this->execute_request($uri);
	}
	
	/* Called by handle_get() and handle_post() to pass off the request
	 * to the subclass implementation.
	 */
	function execute_request($uri) {
		$this->request_uri = $uri;
		$this->handle_request($uri);
	}
	
	/* Sends the headers to the HTTP client.  $code is the HTTP response code,
	 * and $msg is the optional message to include with the code.
	 */
	function send_headers($code,$msg = false) {
		if ($this->headers_sent) return;
		
		//$this->headers_sent = true;
		if (!$msg) $msg = $this->codes[$code];
		
		$nl = "\r\n";
		$this->_write_socket("HTTP/{$this->http_version} {$code} {$msg}".$nl);
		$this->_write_socket("Date: ".date('r').$nl);
		$this->_write_socket("Server: {$this->server_name}/{$this->server_version}".$nl);
		if ($this->http_version!='1.0') $this->_write_socket("Connection: close".$nl);
		$this->_write_socket("Content-Type: {$this->content_type}; charset={$this->charset}".$nl);
		if (is_array($this->response_headers)) {
			foreach ($this->response_headers as $key=>$value) {
				$this->_write_socket("$key: $value".$nl);
			}
		}
		$this->_write_socket($nl);
		
		return $code;
	}
	
	/* Generates the HTTP error corresponding to $code, and sends the
	 * appropriate headers to the HTTP client.
	 */
	function http_error($code) {
		$msg = $this->codes[$code];
		$response = "<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">
<HTML><HEAD>
<TITLE>{$code} {$msg}</TITLE>
</HEAD><BODY>
<H1>{$msg}</H1>
<HR>
<ADDRESS>{$this->server_signature}</ADDRESS>
</BODY></HTML>
";
		$this->content_type = 'text/html';
		$this->send_headers($code,false);
		
		echo $response;				
	}
		
	/* Executes the PHP script specified by $script_filename while attempting to
	 * simulate a proper webserver environment.
	 */
	function execute_php($script_filename,$script_uri=false,$resultcode=200) {
		$path = dirname($script_filename);
		if (!is_dir($path)) return false;
		if (!is_readable($script_filename)) return false;
		
		$this->_set_server_variables($script_filename,$script_uri);
		
		list($cookies,) = $this->_process_client_headers();
		$_COOKIE = $cookies;
		
		$_GET = $this->client_variables['get'];
		$_POST = $this->client_variables['post'];
		$_REQUEST = array_merge($_GET,$_POST);
						
		$cwd = getcwd();
		chdir($path);

		Header('Content-type: text/html');		
		$this->content_type = 'text/html';

		$this->result_code = $resultcode;
		$GLOBALS['tshttpd'] = &$this;
		
		ob_start();
		require($script_filename);
		$content = ob_get_contents();
		ob_end_clean();
		
		$this->send_headers($this->result_code);
		echo $content;
		

		chdir($cwd);
		return true;
	}


	/* This method can be used to emulate 'typical' webserver behavior.
	 * This serves up the URI specified by $uri useing the value of 
	 * $this->document_root as the document root.
	 *
	 * If $uri cannot be located, a 404 error is generated.
	 * If $uri points to a normal document (eg: HTML, text, image, etc.)
	 *   the document is served with the correct mime type.
	 * If $uri points to a PHP script, the PHP script is executed and
	 *   the output sent to the client.
	 */
	function serve_document_root($uri) {
		$script_uri = $uri;
		
		$docroot = realpath($this->document_root);
		if (substr($docroot,-1)!='/') $docroot .= '/';

		$requestedfile = realpath($docroot . substr($uri,1));
		if ($docroot==$requestedfile.'/') $requestedfile .= '/';
		if (substr($requestedfile,0,strlen($docroot))!=$docroot) {
			return $this->http_error(404);
		}
		
		if (!file_exists($requestedfile)) return $this->http_error(404);
		if (is_dir($requestedfile)) {
			if (substr($requestedfile,-1)!='/') {
				$requestedfile .= '/';
				$script_uri_path .= '/';
			}
			$found = false;
			foreach ($this->default_indexes as $k=>$indexfile) {
				if (file_exists($requestedfile . $indexfile)) {
					$requestedfile .= $indexfile;
					$script_uri .= $indexfile;
					$found = true;
					break;
				}
			}
			if (!$found) return $this->http_error(404);
		}
	
		$pi = pathinfo($requestedfile);
		$ext = $pi['extension'];
		if (in_array($ext,array('php','php4','php3'))) {
			if (!$this->execute_php($requestedfile,$script_uri)) {
				return $this->http_error(500);
			}
		} else {
			$mime = &new MIMETypes();
			$mimetype = $mime->detect_mime_type($requestedfile);
			
			// cannot POST/etc. to anything but HTML documents
			if ( ($mimetype!='text/html') && ($this->request_method!='GET') ) {
				return $this->http_error(405);
			}
			
			$this->content_type = $mimetype;
			
			$this->send_headers(200);
			
			$fp = fopen($requestedfile,'r');
			fpassthru($fp);
			fclose($fp);
		}
		
	}

	/* Processes the HTTP headers provided by the client.  Presently
	 * simply pulls out the cookies and returns them.
	 */	
	function _process_client_headers() {
		$cookies = array();
		
		foreach ($this->client_headers as $header=>$value) {
			
			// handle cookies
			if (strtolower($header)=='cookie') {
				$cookies = explode(';',$value);
				foreach ($cookies as $k=>$cookie) {
					list($k,$v) = explode('=',rtrim($cookie),2);
					$cookies[$k] = $v;
				}
			}
			
			
		}
		
		return array($cookies);
	}
	
	/* Sets all $_SERVER variables to emulate a PHP environment. */
	function _set_server_variables($script_filename,$script_name = false) {
		$script_filename = realpath($script_filename);

		if (!$this->document_root) $this->document_root = dirname(__FILE__);
		$docroot = realpath($this->document_root);
		if (substr($docroot,-1)!='/') $docroot .= '/';

		$phpself = '';
		if (substr($script_filename,0,strlen($docroot))==$docroot) $phpself = substr($script_filename,strlen($docroot)-1);
		
		if ($auth = $this->client_headers['Authorization']) {
			$p = strrpos($auth,' ');
			if ($p!==false) {
				$auth_type = substr($auth,0,$p);
				$auth = substr($auth,$p+1);
				if (strpos($auth,':')===false) $auth = base64_decode($auth);
				list($auth_user,$auth_pass) = explode(':',$auth,2);
					
			}
		}
		
		$_SERVER = array(
			'PHP_SELF'=>$phpself,
			'GATEWAY_INTERFACE'=>'',
			'SERVER_NAME'=>$this->server_host,
			'SERVER_ADDR'=>$this->server_host,
			'SERVER_PORT'=>$this->server_port,
			'SERVER_SOFTWARE'=>$this->server_name.'/'.$this->server_version,
			'SERVER_PROTOCOL'=>'HTTP/'.$this->http_version,
			'REQUEST_METHOD'=>$this->request_method,
			'QUERY_STRING'=>$this->get_query_string,
			'DOCUMENT_ROOT'=>$docroot,
			'HTTP_ACCEPT'=>$this->client_headers['Accept'],
			'HTTP_ACCEPT_CHARSET'=>$this->client_headers['Accept-Charset'],
			'HTTP_ACCEPT_ENCODING'=>$this->client_headers['Accept-Encoding'],
			'HTTP_ACCEPT_LANGUAGE'=>$this->client_headers['Accept-Language'],
			'HTTP_CONNECTION'=>$this->client_headers['Connection'],
			'HTTP_HOST'=>$this->http_host,
			'HTTP_REFERER'=>$this->client_headers['Referer'],
			'HTTP_USER_AGENT'=>$this->client_headers['User-Agent'],
			'REMOTE_ADDR'=>$this->client_host,
			'REMOTE_HOST'=>$this->client_host,
			'REMOTE_PORT'=>$this->client_port,
			'SCRIPT_FILENAME'=>$script_filename,
			'SERVER_ADMIN'=>$this->server_admin,
			'SERVER_SIGNATURE'=>$this->server_signature,
			'PATH_TRANSLATED'=>$script_filename,
			'SCRIPT_NAME'=>$script_name ? $script_name : $this->request_uri,
			'REQUEST_URI'=>$this->request_uri,
			'TSHTTPD'=>true,
		);
		if ($auth_user) $_SERVER['PHP_AUTH_USER'] = $auth_user;
		if ($auth_pass) $_SERVER['PHP_AUTH_PW'] = $auth_pass;
		if ($auth_type) $_SERVER['AUTH_TYPE'] = $auth_type;
	}
	
	/* Sets a particular header; $header should be in "Header: value" format. */
	function set_header($header) {
		if (strpos($header,':')!==false) {
			list($header,$value) = explode(':',$header,2);
			$value = ltrim($value);
			$this->response_headers[$header] = $value;
			
			switch(strtolower($header)) {
				case 'location':
					$this->result_code = 302;
					break;
			}
		} else {
			if (preg_match('/^HTTP\/([1-9]\.[0-9])\s+([0-9]+)\s+(.*?)$/i',$header,$matches)) {
				list(,$this->http_version,$this->result_code,) = $matches;
			}
		}
	}


	/* "Socket" functions used to communicate with the HTTP client.
	 */
	 
	function _open_socket() {
		$this->sock_r = @fopen('php://stdin','r');
		$this->sock_w = @fopen('php://stdout','w');
		return is_resource($this->sock_r) && is_resource($this->sock_w);
	}
	
	function _close_socket() {
		@fclose($this->sock_r);
		@fclose($this->sock_w);
	}
	
	function _read_socket($length = 10240) {
		return fgets($this->sock_r,$length);
	}
	
	function _write_socket($data) {
		return fwrite($this->sock_w,$data);
	}
	
	
}
?>
