<?php
/* DDNS Server
 * Copyright 2006, Steve Blinch
 * http://code.blitzaffe.com
 * ============================================================================
 *
 * DESCRIPTION
 *
 * This script lets you use DDNS Server as a standalone application, for use on
 * nameservers that do not already have a webserver installed.  If you have a
 * webserver installed on the same server as BIND, you do not need this script.
 *
 * Note that this script is designed to run under tcpserver (part of the
 * ucspi-tcp package made by DJB of Qmail fame, available at at 
 * http://cr.yp.to/ucspi-tcp.html).
 *
 *
 * LICENSE
 *
 * This script is free software; you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * This script is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *	
 * You should have received a copy of the GNU General Public License along
 * with this script; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

require_once(dirname(__FILE__).'/class_DDNSHTTPd.php');

$httpd = &new DDNSHTTPd();
$httpd->process_request();
?>