<?php
/* DDNS Server
 * Copyright 2006, Steve Blinch
 * http://code.blitzaffe.com
 * ============================================================================
 *
 * This script is free software; you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * This script is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *	
 * You should have received a copy of the GNU General Public License along
 * with this script; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

require_once(dirname(__FILE__).'/config.php');
require_once(dirname(__FILE__).'/class_TCPServerHTTPd.php');

class DDNSHTTPd extends TCPServerHTTPd {
	
	function DDNSHTTPd() {
	}
	
	function initialize() {
		parent::initialize();
		$this->server_name = 'DDNSHTTPd';
		$this->server_version = '1.0';
		$this->content_type = 'text/plain';	
		$this->document_root = dirname(__FILE__).'/../';
	}
	
	function handle_request($uri) {
		if ( ($this->http_host) && (defined('SERVER_HOSTNAME') && strlen(SERVER_HOSTNAME)) && ($this->http_host!=SERVER_HOSTNAME) ) {
			if (!$this->execute_php(dirname(__FILE__).'/../offline.php')) {
				return $this->http_error(500);
			}
		} elseif ($uri=='/nic/update') {
			if (!$this->execute_php(dirname(__FILE__).'/../nic/nic.php')) {
				return $this->http_error(500);
			}
		} else {
			$this->serve_document_root($uri);
		}
	}
	
}
?>