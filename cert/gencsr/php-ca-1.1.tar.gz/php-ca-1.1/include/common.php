<?

$cwd = getcwd();
$config = array(
	'config' => "$cwd/openssl/openssl.conf",
	'dir' => "$cwd/openssl/crypto",
);

function checkError($result) {
	if (!$result) {
		while (($error = openssl_error_string()) !== false) {
			if ($error == "error:0E06D06C:configuration file routines:NCONF_get_string:no value") {
				if ($nokeyError++ == 0) {
					$errors .= "One or more configuration variables could not be found (possibly non-fatal)<br/>\n";
				}
			}
			else {
				$errorCount++;
				$errors .= "Error $errorCount: $error<br/>\n";
			}
		}
	}
	if ($errorCount or (!$result and $nokeyError)) {
		print "FATAL: An error occured in the script. Possibly due to a misconfiguration.<br/>\nThe following errors were reported during execution:<br/>\n$errors";
		exit();
	}
}
	
function getSerial() {
	$fp = fopen("./openssl/crypto/serial", "r");
	list($serial) = fscanf($fp, "%x");
	fclose($fp);

	$fp = fopen("./openssl/crypto/serial", "w");
	fputs($fp, sprintf("%04X", $serial + 1) . chr(0) . chr(10) );
	fclose($fp);
	return $serial + 1;
}

function printHeaderbar() {
	global $config;
	$name = "";
	if ($org = $config['orgName']) {
		$name = "<small>For: $org.</small>";
	}
	print <<<ENDE
<div id=headerbar>
<a href="."><img src="images/phpca.png" class="logo"/></a>
<div id=header>PHP Certificate Authority<br/>$name</div>
<div class=menu><a href="index.php?area=main&stage=help">Help</a></div>
<div class=menu><a href="index.php?area=main&stage=about">About</a></div>
<div class=menu><a href="index.php?area=admin">Admin</a></div>
<div class=menu><a href="index.php">Main page</a></div>
</div>
ENDE;
}

function printHeader($title = "", $inhead = "") {
	print <<<ENDE
<html>
<head>
<title>PHP-CA: $title</title>
<script type="text/javascript" src="scripts/common.php"></script>
<link rel="stylesheet" type="text/css" href="css/basic.php"/>
<link rel="icon" type="image/x-icon" href="images/phpca.ico"/>
$inhead
</head>
<body>
ENDE;
	printHeaderbar();
	print "<div id=\"content\">\n";
}

function printFooter() {
	print <<<ENDE
</div>
</body>
</html>
ENDE;
}

?>
