
<h1>The following admin actions are available</h1>

<p>
<b>Re-issue CA Certificate</b><br/>
<form action="index.php" method="post">
<input type="hidden" name="area" value="<?=htmlspecialchars($_REQUEST['area'])?>"/>
<input type="hidden" name="stage" value="renewCert"/>
<table style="width: 350px;">
<tr><td width=100>Passphrase:<td><input type="password" name="pass"/>
<tr><td><td><input type="submit" value="Reissue CA Cert"/>
</table>
</form>
</p>

<p>
<b>Sign a Certificate Request</b><br/>
<form action="index.php" method="post">
<input type="hidden" name="area" value="<?=htmlspecialchars($_REQUEST['area'])?>"/>
<input type="hidden" name="stage" value="certSign"/>
<table style="width: 350px;">
<tr><td width=100>Passphrase:<td><input type="password" name="pass"/>
<tr><td>Name:<td><input type="text" name="name"/>
<tr><td colspan=2>Request:<br/>
<textarea name="request" cols="50" rows="6"></textarea><br/>
<tr><td><td><input type="submit" value="Sign Cert"/>
</table>
</form>
</p>

<p>
<b>Re-sign a Certificate Request</b><br/>
<form action="index.php" method="post">
<input type="hidden" name="area" value="<?=htmlspecialchars($_REQUEST['area'])?>"/>
<input type="hidden" name="stage" value="certSign"/>
<table style="width: 350px;">
<tr><td width=100>Passphrase:<td><input type="password" name="pass"/>
<tr><td>Name:<td><select name="name" rows="6">
<option value="">--- Select a certificate
<?

$dh = opendir("./openssl/crypto/requests");
while (($file = readdir($dh)) !== false) {
	if (substr($file, -4) == ".csr") {
		$name = substr($file, 0, -4);
		print "<option>$name";
	}
}

?>
</select>
<tr><td><td><input type="submit" value="Sign Cert"/>
</table>
</form>
</p>

<p>
<b>Process to generate a key+signing request:</b><br/>
<pre>
echo -n "Enter your domain name: "; read DOMAIN && \
openssl genrsa -out $DOMAIN.key 1024 && \
openssl req -new -key $DOMAIN.key -out $DOMAIN.csr && \
cat $DOMAIN.csr
</pre>
</p>

<p>
<b>My Certificate (<a href="index.php?area=main&stage=trust">open</a>)</b><br/>
<pre style="font-size: 75%;"><?=join("", file("./openssl/crypto/cacerts/cacert.pem"))?></pre>
</p>
