<?php
	/* Deutsche Sprachkonstanten */

	// Datum und Zeit
	define( DATEFORMAT,								"%m/%d/%Y" );
  define( TIMEFORMAT,								"%m/%d/%Y %H:%M" );

  // Globale Sprachkonstanten
	define( NAV_BACK,									"Back" );
	define( NAV_HOME,									"Home" );
	define( TXT_UNKNOWN,							"(unknown)" );
	define( TXT_NOT_SHOWN,						"&lt;not shown&gt;" );
	define( TXT_NO,										"no" );
	define( TXT_YES,									"yes" );
	define( TBL_CREATED,							"created" );
	define( TBL_MODIFIED,							"modified" );

  // ** Administrationsbereich ***************************************

  // Skript /admin/index.php
	define( NAV_INDEX_DEP_MANAGEMENT,	"Departements" );
	define( NAV_INDEX_USR_MANAGEMENT,	"User accounts" );
	define( NAV_INDEX_CA_PRIVKEY,			"Private key of the CA" );
	define( NAV_INDEX_CA_EDIT,				"Modify CA data" );
	define( NAV_INDEX_CA_LOG,					"Log" );
	define( NAV_INDEX_CA_CERT,				"X.509 root certificate" );
	define( NAV_INDEX_CA_CERTS,				"X.509 certificates" );
	define( NAV_INDEX_USR_DEPS,				"My departements" );
	define( NAV_INDEX_USR_PROFILE,		"My profile" );
	define( NAV_INDEX_USR_RIGHTS,			"My rights" );

	// Skript /admin/dep_list.php
	define( NAV_DEP_ADD,							"Create new departement" );
	define( DEP_LIST_TBL_SHOW_ALL,		"All departements of the CA" );
	define( DEP_LIST_TBL_SHOW,				"My departements" );
	define( DEP_LIST_TBL_DEPNAME,			"departement name" );
	define( DEP_LIST_TBL_ROOT_ACCESS,	"full access" );
	define( DEP_LIST_TBL_ADM_ACCESS,	"supervisor" );
	define( DEP_LIST_TBL_REG_ACCESS,	"registrar" );

	// Skript /admin/dep_index.php
	define( NAV_DEP_EDIT,							"Modify departement data" );
	define( NAV_DEP_DELETE,						"Delete departement" );
	define( NAV_DEP_USR_MANAGEMENT,		"User accounts" );
	define( NAV_DEP_REGS,							"Departement registrars" );
	define( NAV_DEP_NOTIFY,						"Change notifications" );
	define( NAV_DEP_LOG,							"Departement log" );
	define( NAV_DEP_X509_ADD,					"Create new X.509 certificate" );
	define( NAV_DEP_X509_MANAGEMENT,	"X.509 certificates" );
	define( NAV_DEP_CSR_MANAGEMENT,		"Sign pending CSRs" );

	// Skript /admin/user_list.php
	define( NAV_USER_ADD,							"Create new user account" );
	define( NAV_DEP_REG_ADD,					"Create new registrar" );
	define( USR_LIST_TBL_SHOW,				"All user accounts of " );
	define( USR_LIST_TBL_SHOW_ALL,		"All user accounts of the CA" );
	define( USR_LIST_TBL_SURNAME,			"Surname" );
	define( USR_LIST_TBL_LASTNAME,		"Last name" );
	define( USR_LIST_TBL_LOGIN,				"Login" );

	// Skript /admin/user_index.php
	define( NAV_USER_EDIT,						"Modify user account" );
	define( NAV_USER_DELETE,					"Delete user account" );
	define( NAV_USER_RIGHTS_VIEW,			"View access rights" );
	define( NAV_USER_RIGHTS_SET,			"Modify access rights" );
	define( NAV_USER_LOG,							"User account log" );

	// Skript /admin/x509_list.php
	define( X509_LIST_TBL_SHOW,				"X.509 certificates of " );
	define( X509_LIST_TBL_SHOW_ALL,		"All X.509 certificates of the CA" );
	define( X509_LIST_TBL_CERTNAME,		"Certificate issued to" );
	define( X509_LIST_TBL_VALIDTO,		"expires" );

	// Skript /admin/x509_view.php
	define( NAV_X509_DELETE,					"Delete certificate" );
	define( NAV_X509_RENEW,						"Renew certificate" );
	define( NAV_X509_LOG,							"Certificate log" );

	// Skript /admin/dep_csr_list.php
	define( CSR_LIST_TBL,							"Pending CSRs of " );
	define( CSR_LIST_TBL_CNAME,				"CSR issued to" );

	// Skript /admin/dep_csr_sign.php
	define( CSR_SIGN_EMAIL_SUBJECT,		"Your certification request" );

	// Sprachkonstanten für alle Skripte, in denen Schlüssel angezeigt werden
	define( NAV_KEY_DOWNLOAD_PEM,			"Download key (PEM)" );
	define( NAV_KEY_DOWNLOAD_TXT,			"Download key (TXT)" );
	define( NAV_CERT_DOWNLOAD_PEM,		"Download certificate (PEM)" );
	define( NAV_CERT_DOWNLOAD_CRT,		"Download certificate (CRT)" );

	// Sprachkonstanten für alle Skripte, die das Logbuch anzeigen
	define( NAV_LOG_SHOW_ALL,					"Show all log entries" );
	define( NAV_LOG_SHOW_CA,					"Show CA-related entries" );
	define( NAV_LOG_SHOW_DEP,					"Show departement-related entries" );
	define( NAV_LOG_SHOW_USER,				"Show user-related entries" );
	define( NAV_LOG_SHOW_CERT,				"Show certificate-related entries" );

	define( LOG_TBL_SHOW_ALL,					"All log entries" );
	define( LOG_TBL_SHOW_CA,					"CA-related entries only" );
	define( LOG_TBL_SHOW_DEP,					"Departement-related entries only" );
	define( LOG_TBL_SHOW_USER,				"User-related entries only" );
	define( LOG_TBL_SHOW_CERT,				"Certificate-related entries only" );

	define( LOG_TBL_OCCURED,					"Date" );
	define( LOG_TBL_EVENT,						"Entry" );

	// ** Öffentlicher Bereich *****************************************

	// Skript index.php
	define( NAV_INDEX_CA_DEPS,				"Departements &gt;&gt;" );
	define( NAV_CSR_ADD,							"Request X.509 certificate&gt;&gt;" );
	define( NAV_INDEX_DOWNLOAD_PEM,		"X.509 root certificate (PEM)" );
	define( NAV_INDEX_DOWNLOAD_CRT,		"X.509 root certificate (CRT)" );

	// Skript csr_add.php
	define( CSR_ADD_NOTIFY_SUBJECT,		"Your X.509 certificate request" );
	define( CSR_ADD_EMAIL_SUBJECT,		"Your X.509 certificate request" );

?>