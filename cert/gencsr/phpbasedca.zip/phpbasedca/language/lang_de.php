<?php
	/* Deutsche Sprachkonstanten */

	// Datum und Zeit
	define( DATEFORMAT,								"%d.%m.%Y" );
  define( TIMEFORMAT,								"%d.%m.%Y %H:%M" );

  // Globale Sprachkonstanten
	define( NAV_BACK,									"Zur&uuml;ck" );
	define( NAV_HOME,									"Startseite" );
	define( TXT_UNKNOWN,							"(unbekannt)" );
	define( TXT_NOT_SHOWN,						"&lt;wird nicht angezeigt&gt;" );
	define( TXT_NO,										"nein" );
	define( TXT_YES,									"ja" );
	define( TBL_CREATED,							"erstellt am" );
	define( TBL_MODIFIED,							"modifiziert am" );

  // ** Administrationsbereich ***************************************

  // Skript /admin/index.php
	define( NAV_INDEX_DEP_MANAGEMENT,	"Abteilungsverwaltung" );
	define( NAV_INDEX_USR_MANAGEMENT,	"Benutzerverwaltung" );
	define( NAV_INDEX_CA_PRIVKEY,			"Privater Schl&uuml;ssel der CA" );
	define( NAV_INDEX_CA_EDIT,				"CA-Daten &auml;ndern" );
	define( NAV_INDEX_CA_LOG,					"Logbuch" );
	define( NAV_INDEX_CA_CERT,				"X.509-Wurzelzertifikat dieser CA" );
	define( NAV_INDEX_CA_CERTS,				"X.509-Zertifikate dieser CA" );
	define( NAV_INDEX_USR_DEPS,				"Ihre Abteilungen" );
	define( NAV_INDEX_USR_PROFILE,		"Ihr pers&ouml;nliches Profil" );
	define( NAV_INDEX_USR_RIGHTS,			"Ihre Rechte auf diesem Server" );

	// Skript /admin/dep_list.php
	define( NAV_DEP_ADD,							"Neue Abteilung erstellen" );
	define( DEP_LIST_TBL_SHOW_ALL,		"Alle Abteilungen dieses CA-Servers" );
	define( DEP_LIST_TBL_SHOW,				"Ihre Abteilungen" );
	define( DEP_LIST_TBL_DEPNAME,			"Name der Abteilung" );
	define( DEP_LIST_TBL_ROOT_ACCESS,	"voller Zugriff" );
	define( DEP_LIST_TBL_ADM_ACCESS,	"Abteilungsleiter" );
	define( DEP_LIST_TBL_REG_ACCESS,	"Registrar der Abteilung" );

	// Skript /admin/dep_index.php
	define( NAV_DEP_EDIT,							"Abteilungsdaten &auml;ndern" );
	define( NAV_DEP_DELETE,						"Abteilung l&ouml;schen" );
	define( NAV_DEP_USR_MANAGEMENT,		"Benutzerverwaltung" );
	define( NAV_DEP_REGS,							"Registrare dieser Abteilung" );
	define( NAV_DEP_NOTIFY,						"Benachrichtigungen &auml;ndern" );
	define( NAV_DEP_LOG,							"Logbuch der Abteilung" );
	define( NAV_DEP_X509_ADD,					"Neues X.509-Zertifikat erstellen" );
	define( NAV_DEP_X509_MANAGEMENT,	"X.509-Zertifikate verwalten" );
	define( NAV_DEP_CSR_MANAGEMENT,		"Wartende CSRs signieren" );

	// Skript /admin/user_list.php
	define( NAV_USER_ADD,							"Neuen Benutzer erstellen" );
	define( NAV_DEP_REG_ADD,					"Neuen Registrar erstellen" );
	define( USR_LIST_TBL_SHOW,				"Alle Benutzer der Abteilung " );
	define( USR_LIST_TBL_SHOW_ALL,		"Alle Benutzer des CA-Servers" );
	define( USR_LIST_TBL_SURNAME,			"Vorname" );
	define( USR_LIST_TBL_LASTNAME,		"Nachname" );
	define( USR_LIST_TBL_LOGIN,				"Login" );

	// Skript /admin/user_index.php
	define( NAV_USER_EDIT,						"Benutzerprofil &auml;ndern" );
	define( NAV_USER_DELETE,					"Benutzer l&ouml;schen" );
	define( NAV_USER_RIGHTS_VIEW,			"Zugriffsrechte einsehen" );
	define( NAV_USER_RIGHTS_SET,			"Zugriffsrechte festlegen" );
	define( NAV_USER_LOG,							"Logbuch des Benutzers" );

	// Skript /admin/x509_list.php
	define( X509_LIST_TBL_SHOW,				"X.509-Zertifikate der Abteilung " );
	define( X509_LIST_TBL_SHOW_ALL,		"Alle X.509-Zertifikate des CA-Servers" );
	define( X509_LIST_TBL_CERTNAME,		"Zertifikat ausgestellt f&uuml;r" );
	define( X509_LIST_TBL_VALIDTO,		"l&auml;ft ab am" );

	// Skript /admin/x509_view.php
	define( NAV_X509_DELETE,					"Zertfikat l&ouml;schen" );
	define( NAV_X509_RENEW,						"Zertifikat verl&auml;ngern" );
	define( NAV_X509_LOG,							"Historie des Zertifikates" );

	// Skript /admin/dep_csr_list.php
	define( CSR_LIST_TBL,							"Wartende CSRs der Abteilung " );
	define( CSR_LIST_TBL_CNAME,				"CSR ausgestellt f&uuml;r" );

	// Skript /admin/dep_csr_sign.php
	define( CSR_SIGN_EMAIL_SUBJECT,		"Ihre Zertifizierungsanfrage" );

	// Sprachkonstanten für alle Skripte, in denen Schlüssel angezeigt werden
	define( NAV_KEY_DOWNLOAD_PEM,			"Schl&uuml;ssel herunterladen (PEM)" );
	define( NAV_KEY_DOWNLOAD_TXT,			"Schl&uuml;ssel herunterladen (TXT)" );
	define( NAV_CERT_DOWNLOAD_PEM,		"Zertifikat herunterladen (PEM)" );
	define( NAV_CERT_DOWNLOAD_CRT,		"Zertifikat herunterladen (CRT)" );

	// Sprachkonstanten für alle Skripte, die das Logbuch anzeigen
	define( NAV_LOG_SHOW_ALL,					"Gesamtes Logbuch anzeigen" );
	define( NAV_LOG_SHOW_CA,					"Speziell : CA-Daten" );
	define( NAV_LOG_SHOW_DEP,					"Speziell : Abteilungsverwaltung" );
	define( NAV_LOG_SHOW_USER,				"Speziell : Benutzerverwaltung" );
	define( NAV_LOG_SHOW_CERT,				"Speziell : Zertifikatsverwaltung" );

	define( LOG_TBL_SHOW_ALL,					"Gesamtes Logbuch" );
	define( LOG_TBL_SHOW_CA,					"Logbuch der CA-Verwaltung" );
	define( LOG_TBL_SHOW_DEP,					"Logbuch der Abteilungsverwaltung" );
	define( LOG_TBL_SHOW_USER,				"Logbuch der Benutzerverwaltung" );
	define( LOG_TBL_SHOW_CERT,				"Logbuch der Zertifikatsverwaltung" );

	define( LOG_TBL_OCCURED,					"Zeitpunkt" );
	define( LOG_TBL_EVENT,						"Logbucheintrag" );

	// ** Öffentlicher Bereich *****************************************

	// Skript index.php
	define( NAV_INDEX_CA_DEPS,				"Abteilungen dieser CA &gt;&gt;" );
	define( NAV_CSR_ADD,							"X.509-Zertifikat anfordern &gt;&gt;" );
	define( NAV_INDEX_DOWNLOAD_PEM,		"X.509-Wurzelzertifikat (PEM)" );
	define( NAV_INDEX_DOWNLOAD_CRT,		"X.509-Wurzelzertifikat (CRT)" );

	// Skript csr_add.php
	define( CSR_ADD_NOTIFY_SUBJECT,		"Neue Zertifizierungsanfrage" );
	define( CSR_ADD_EMAIL_SUBJECT,		"Ihre Zertifizierungsanfrage" );

?>