<?php
	/*
	Setup einer CA. Sollte nur nach der Installation ausgeführt werden, danach
	Löschen oder Umbenennen der Datei.
	Parameter : keine  
	*/

	require_once( "./lib/_FastTemplate.php" );
	require_once( "./lib/database.php" );
	require_once( "./lib/privatekey.php" );
	require_once( "./lib/certdata.php" );
	require_once( "./lib/ca.php" );
	require_once( "./lib/user.php" );
	require_once( "./lib/rights.php" );
	require_once( "./lib/_config.php" );
	// Sprachkonstanten laden
	require_once( "./language/lang_".LANGUAGE.".php" );
  
	$template = new FastTemplate( "./templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		// Bestätigung zum Löschen aller Daten in der Datenbank
		"confirm_delete" => "setup_confirm_delete.html",
		// Okay-Meldung über Löschen aller Datenbankinhalte
		"deleted" => "setup_ca_deleted.html",
		// Fehler : Datenbankeinstellungen funktionieren nicht
		"database_error" => "setup_database_error.html",
		// Formular zur Eingabe der CA-Daten
		"form" => "setup_ca_form.html",
		// Fehlermeldung für privaten Schlüssel
		"pkey_error" => "setup_pkey_error.html",
		// Fehlermeldung für X.509-Zertifikat
		"x509_error" => "setup_x509_error.html",
		// Fehlermeldung beim Generieren der CA
		"ca_error" => "setup_ca_error.html",
		// Fehlermeldung beim Anlegen des Admin-Kontos
		"profile_error" => "setup_profile_error.html",
		// Okay-Meldung
		"ok" => "setup_ok.html"
	) );

	// Pfade einparsen
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );
  
	// keine Navigation
	$template->assign( "{NAVIGATION}", "" );

	// Datenbankverbindung aufbauen, sofern alles richtig konfiguriert
	try {
		$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
		$db->selectDatabase( DB_DATABASE );
	} catch( Exception $e ) {
		// Fehlermeldung generieren
		$template->assign( "{ERROR}", $e->getMessage() );
		$template->parse( "{MAIN}", "database_error" );
	}

	// Testen, ob schon eine CA in der Datenbank verzeichnet ist
	if( !$template->get_assigned( "{MAIN}" ) ) try {
		$ca = new pCA_DB( $db );
	} catch( Exception $e ) { }
	if( is_object( $ca ) ) {
		// Bestätigung zum Löschen aller Daten einholen
		if( count( $_POST ) == 0 ) {
			$template->parse( "{MAIN}", "confirm_delete" );
		} else {
		// Bestätigung gegeben, alles löschen
			$toTruncate = array();
			$db->query( "SHOW TABLES;" );
			while( $data = $db->fetchRow(0) ) array_push( $toTruncate, $data );
			foreach( $toTruncate as $table )
				$db->query( "TRUNCATE ".$table.";" );
			unset( $toTruncate );
			$template->parse( "{MAIN}", "deleted" );
		}
	}

	// Formular anzeigen bzw. neue CA einrichten
	if( !$template->get_assigned( "{MAIN}") ) {
		if( count( $_POST ) == 0 ) {
			// Formular anzeigen
			$template->parse( "{MAIN}", "form" );
		} else {
			// Neue CA konfigurieren
			$db->beginTransaction();

			try {
				if( $_POST["pkey"] == "upload" )
					// Privater Schlüssel wurde hochgeladen
					$pkey = new pPrivateKey(
						file_get_contents( $_FILES["pkeyfile"]["tmp_name"] ),
						$_POST["pkeypassword"] );
				else
					// Privater Schlüssel soll generiert werden
					$pkey = new pPrivateKey( (int) $_POST["pkeylength"] );
			} catch( Exception $e ) {
				$db->endTransaction( true );	// ROLLBACK
				$template->assign( "{ERROR}", $e->getMessage() );
				$template->parse( "{MAIN}", "pkey_error" );
			}

			// X.509-Zertifikat generieren bzw. importieren
			if( !$template->get_assigned( "{MAIN}") ) try {
				if( $_POST["x509"] == "upload" )
					// Vorhandenes X.509-Zertifikat importieren
					$x509 = new pX509Cert(
								file_get_contents( $_FILES["x509file"]["tmp_name"] ) );
				else
					// Neues X.509-Zertifikat erzeugen ( nur Vorbereitung )
					$cert = new pCertData(
						$_POST["countryName"], $_POST["stateOrProvinceName"],
						$_POST["localityName"], $_POST["organizationName"],
						$_POST["organizationalUnitName"], $_POST["commonName"],
						$_POST["emailAddress"] );
			} catch( Exception $e ) {
					$db->endTransaction( true );	// ROLLBACK
					$template->assign( "{ERROR}", $e->getMessage() );
					$template->parse( "{MAIN}", "x509_error" );
			}

			// CA erzeugen
			if( !$template->get_assigned( "{MAIN}") ) try {
				if( $_POST["x509"] == "upload" )
					$ca = new pCA_DB( $_POST["caname"], $pkey, $x509 );
				else
					$ca = new pCA_DB( (string) $_POST["caname"], $cert, $pkey,
						(int) $_POST["pkeyexpire"] );
				// Passwort des privaten Schlüssels entfernen
				$ca->setPassword( "" );
				// CA in die Datenbank speichern lassen
				$ca->saveToDB( $db );
			} catch( Exception $e) {
				$db->endTransaction( true );	// ROLLBACK
				$template->assign( "{ERROR}", $e->getMessage() );
				$template->parse( "{MAIN}", "ca_error" );
			}

			// Admin-Benutzerkonto anlegen und Rechte vergeben
			if( !$template->get_assigned( "{MAIN}") ) try {
				// Benutzerkonto anlegen und in die DB speichern lassen
				$profile = new pUser( $_POST["surname"], $_POST["lastname"],
					$_POST["login"], $_POST["password"], $_POST["email"] );
				$profile->saveToDB( $db );
				// root-Rechte geben und in die DB speichern lassen
				$rights = new pRights( $profile );
				$rights->setRoot( true );
				$rights->saveToDB( $db );
			} catch( Exception $e ) {
				$db->endTransaction( true );	// ROLLBACK
				$template->assign( "{ERROR}", $e->getMessage() );
				$template->parse( "{MAIN}", "profile_error" );
			}

			// Fertig
			$db->endTransaction();		// COMMIT
			if( !$template->get_assigned( "{MAIN}") )
				$template->parse( "{MAIN}", "ok" );
		}
	}
  
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>