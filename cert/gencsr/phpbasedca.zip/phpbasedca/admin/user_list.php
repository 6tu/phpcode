<?php
	/*
	Benutzerverwaltung ( entweder für ganze CA oder für eine Abteilung )
	Parameter :
	1.	dep : ID der Abteilung, dessen Benutzer verwaltet werden sollen
	2.	(diverse Parameter aus der Tabellendarstellung)

	Hinweis : ist Parameter dep nicht gesetzt ( == 0 ), gilt die
	Benutzerverwaltung für die ganze CA ( Zugriff nur mit root-Rechten )
	*/

	// Session starten
	session_start();

	require_once( "../lib/database.php" );
	require_once( "../lib/_config.php" );
	require_once( "../lib/table.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/departement.php" );
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/navigation.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Template initialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "no_access.html",
		// Auflistung der Benutzerkonten für eine Abteilung
		"main" => "admin_user_list.html",
		// Auflistung aller Benutzerkonten ( nur root-Admins )
		"root" => "admin_user_list_all.html"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Benutzerdaten und dessen Rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Parameter auswerten; Session-Parameter haben kleinere Priorität
	$dep = ( $_REQUEST["dep"] > 0 ? $_REQUEST["dep"] :
		( $_SESSION["user_list_dep"] > 0 ? $_SESSION["user_list_dep"] : 0 ) );
	$page = ( $_REQUEST["page"] > 0 ? $_REQUEST["page"] :
		( $_SESSION["user_list_page"] > 0 ? $_SESSION["user_list_page"] : 1 ) );
	$orderby = ( $_REQUEST["orderby"] != "" ? $_REQUEST["orderby"] :
		( $_SESSION["user_list_orderby"] != "" ? $_SESSION["user_list_orderby"] :
		2 ) );
	$order = ( $_REQUEST["order"] != "" ? $_REQUEST["order"] :
		( $_SESSION["user_list_order"] != "" ? $_SESSION["user_list_order"]
		: "asc" ) );
	if( $order != "asc" && $order != "desc" ) $order = "asc";

	// Session-Variablen setzen
	$_SESSION["user_list_dep"] = $dep;
	$_SESSION["user_list_page"] = $page;
	$_SESSION["user_list_orderby"] = $orderby;
	$_SESSION["user_list_order"] = $order;

	// Navigation initialisieren und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	/*
	Anzeige der Benutzerverwaltung in drei Fällen möglich :
	1. $dep == 0 und Benutzer hat root-Rechte ( CA-Benutzerauflistung )
	2. $dep > 0 und Benutzer ist Abteilungsleiter oder root-Admin
	3. $dep > 0 und Benutzer ist Registrar
	AUSSERDEM : Abteilung darf noch nicht gelöscht sein !
	*/
	if( $rights->isRoot() && $dep == 0 )
		$case = 1;														// Fall 1
	elseif( $dep > 0 && ( $rights->isAdmin( $dep ) || $rights->isRoot() ) )
		$case = 2;														// Fall 2
	elseif( $dep > 0 && $rights->isRegistrar( $dep ) )
		$case = 3;														// Fall 3
	else $case = 0;

	// Abteilungsdaten laden, sofern nötig
	if( $case > 1 ) {
		$departement = new pDepartement( $db, (int) $dep );
		// Testen, ob Abteilung bereits gelöscht wurde
		if( $departement->isDeleted() ) $case = 0;
			else $template->assign( "{DEP_NAME}", $departement->getName() );
	}

	// Anzeige der Benutzerverwaltung
	if( $case > 0 ) {
		/*
		Navigation erweitern. Hinweis : anhand $dep wird entschieden, ob wieder
		zur Startseite ( root-Admins ) oder zur Startseite der Abteilung
		zurückgesprungen wird ( alle anderen ).
		*/
		switch( $case ) {
			case 1 : // für root-Admins
				$nav->add( NAV_BACK, "index.php", "/left-blue.gif" );
				$nav->addSeparator();
				$nav->add( NAV_USER_ADD, "user_add.php", "/add-user-blue.gif" );
				break;
			case 2 : // für Abteilungsleiter
				$nav->add( NAV_BACK, "dep_index.php?dep=$dep", "/left-blue.gif" );
				$nav->addSeparator();
				$nav->add( NAV_DEP_REG_ADD, "user_add.php?dep=$dep",
					"/add-user-blue.gif" );
				break;
			case 3 : // für Registrare
				$nav->add( NAV_BACK, "dep_index.php?dep=$dep", "/left-blue.gif" );
				break;
		}

		// Maximalanzahl an Benutzer ermitteln
		if( $case == 1 )
			$query = sprintf( "SELECT COUNT(*) FROM %s;", DB_USER_TABLE );
		else
			$query = sprintf( "SELECT COUNT(x.Auth_ID) FROM %s x JOIN %s y ON ".
				"x.Auth_ID=y.ID AND x.Departement_ID=%u;",
				DB_RIGHTS_TABLE, DB_AUTH_TABLE, $dep );
		$db->query( $query );
		$maxcount = $db->fetchRow( 0 );
		$maxpage = floor( $maxcount / LIST_USER );
		if( $maxcount % LIST_USER > 0 ) $maxpage++;
		unset( $maxcount );

		// Tabelle vorbereiten
		$table = new pTable( ( $case == 1 ? USR_LIST_TBL_SHOW_ALL :
			USR_LIST_TBL_SHOW.$departement->getName() ), $page, $maxpage );
		$table->addColumn( USR_LIST_TBL_SURNAME, "20%", true, true );
		$table->addColumn( USR_LIST_TBL_LASTNAME, "20%", true, true );
		$table->addColumn( USR_LIST_TBL_LOGIN, "20%", true, true );
		$table->addColumn( TBL_CREATED, "20%", true, true );
		$table->addColumn( TBL_MODIFIED, "20%", true, true );
		$table->setSort( $orderby, $order );

		// Query vorbereiten, um Benutzerliste zu erstellen
		$query = sprintf( "SELECT x.ID, x.surname, x.lastname, y.login, ".
			"UNIX_TIMESTAMP( x.created ), UNIX_TIMESTAMP( x.modified ) FROM %s x ".
			" JOIN %s y ON x.Auth_ID=y.ID",
			DB_USER_TABLE, DB_AUTH_TABLE );
		if( $case > 1 ) $query .= sprintf( " JOIN %s z ON y.ID=z.Auth_ID AND ".
			"z.Departement_ID=%u", DB_RIGHTS_TABLE, $dep );
		// Sortierung einfügen
		switch( $orderby ) {
			case 0  : $query .= " ORDER BY x.surname $order, y.login ASC"; break;
			case 1  : $query .= " ORDER BY x.lastname $order, y.login ASC"; break;
			case 3  : $query .= " ORDER BY x.created $order, y.login ASC"; break;
			case 4  : $query .= " ORDER BY x.modified $order, y.login ASC"; break;
			default : $query .= " ORDER BY y.login $order"; break;
		}
		// anzuzeigende Seite einfügen
		if( $page > $maxpage ) $page = $maxpage;
		$query .= sprintf( " LIMIT %u, %u;", ($page-1)*LIST_USER, LIST_USER );

		// Zeilen in die Tabelle einfügen
		$db->query( $query );
		$clicklink = "<a href=\"user_index.php?id=%u\">%s</a>";
		while( $data = $db->fetchRow() ) {
			$table->addRow( array(
				// Vor- und Nachname des Benutzers
				sprintf( $clicklink, $data[0], $data[1] ),
				sprintf( $clicklink, $data[0], $data[2] ),
				// Loginname des Benutzers
				sprintf( $clicklink, $data[0], $data[3] ),
				// Datum der Erstellung und letzte Modifikation des Benutzers
				strftime( DATEFORMAT, $data[4] ), strftime( DATEFORMAT, $data[5] )
			) );
		}

		// Tabelle in die Vorlage einparsen
		$template->assign( "{USR_TABLE}", $table->parse() );
		// Fertig
		$template->parse( "{MAIN}", ( $case == 1 ? "root" : "main" ) );
	} else $template->parse( "{MAIN}", "noaccess" );

	// Ausgabe
	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>