<?php
	/*
	Löscht einen Benutzer
	Parameter :
	1.	id : ID des Benutzers, der gelöscht werden soll
	*/

	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/navigation.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/log.php" );
	require_once( "../lib/_config.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "no_access.html",
		// Bestätigung zum Löschen einholen
		"main" => "admin_user_delete.html",
		// Okay-Meldung des Löschens
		"deleted" => "admin_user_delete_ok.html"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Benutzerdaten und dessen Rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Parameter auswerten
	$id = $_REQUEST["id"];

	// Navigation initialisieren und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	/*
	Es gibt zwei Fälle, in denen ein Benutzer gelöscht werden darf :
	1. der löschende Benutzer muss root-Rechte haben
	2. der löschende Benutzer ist Abteilungsleiiter des zu löschenden Benutzers
	UND : ein Benutzer kann sich nicht selber löschen
	*/

	if( $id > 0 && $id <> $user->getID() ) {
		// Profil des zu löschenden Benutzers laden und ins Template einparsen
		$profile = new pUser( $db, (int) $id, "" );
		$profilerights = new pRights( $db, $profile );
		$template->assign( "{USR_ID}", $id );
		$template->assign( "{USR_SURNAME}", $profile->getSurname() );
		$template->assign( "{USR_LASTNAME}", $profile->getLastname() );
		$template->assign( "{USR_LOGIN}", $profile->getLogin() );

		// Fall ermitteln ( siehe Kommentar oben )
		if( $rights->isRoot() )
			$case = 1;
		elseif( count( array_intersect( $rights->getAdminDepartements(),
			$profilerights->getRegistrarDepartements() ) ) > 0 )
			$case = 2;
		else $case = 0;

		// Benutzerlöschung zulassen, sofern Rechte dazu bestehen
		if( $case > 0 ) {
			// Löschung bestätigt ? Wenn ja, dann Benutzer löschen
			if( count( $_POST ) > 0 ) {
				$profile->deleteFromDB( $db );
				// Logbucheintrag
				$log = new pLog( $db );
				$log->logDeleteUser( $user, $profile );
				$template->parse( "{MAIN}", "deleted" );
			}
			// ansonsten Bestätigung einholen
			else {
				// Zurück-Button einblenden
				$nav->add( NAV_BACK, "user_index.php?id=$id", "/left-blue.gif" );
				$template->parse( "{MAIN}", "main" );
			}
		} else $template->parse( "{MAIN}", "noaccess" );
	} else $template->parse( "{MAIN}", "noaccess" );

	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>