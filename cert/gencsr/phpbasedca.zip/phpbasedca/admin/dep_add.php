<?php
	/*
	Erstellt eine neue Abteilung innerhalb der CA
	Parameter : keine
	*/

	require_once( "../lib/navigation.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/departement.php" );
	require_once( "../lib/log.php" );
	require_once( "../lib/_config.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "no_access.html",
		// Formular zur Eingabe der Abteilungsdaten
		"form" => "admin_dep_add.html",
		// Okay-Meldung
		"created" => "admin_dep_add_ok.html"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Benutzerdaten und dessen Rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Navigation vorbereiten und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	// Nur Benutzer mit root-Rechten dürfen neue Abteilungen erstellen
	if( $rights->isRoot() ) {
	// wenn keine Daten empfangen, dann Formular anzeigen
		if( count( $_POST ) == 0 ) {
			// Zurück-Button
			$nav->add( NAV_BACK, "dep_list.php", "/left-blue.gif" );
			// Formular anzeigen
			$template->parse( "{MAIN}", "form" );
		} else {
			// Daten sind gePOSTet, neue Abteilung generieren
			$departement = new pDepartement( $_POST["depname"] );
			// Abteilung speichern lassen
			$departement->saveToDB( $db );
			// Logbucheintrag
			$log = new pLog( $db );
			$log->logCreateDepartement( $user, $departement );
			// Fertig, Erfolgmeldung ausgeben
			$template->assign( "{DEP}", $departement->getID() );
			$template->assign( "{DEP_NAME}", $departement->getName() );
			$template->parse( "{MAIN}", "created" );
		}
	} else $template->parse( "{MAIN}", "noaccess" );

	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>