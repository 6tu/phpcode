<?php
	/*
	Setzt die Rechte eines Benutzers
	Parameter :
	1.	id : Benutzer-ID, dessen Rechte geändert werden sollen

	Hinweis : der Rücksprungpunkt wird anhand $_SESSION["backref"] bestimmt :
		a) $_SESSION["backref"] == "user_index" : Rücksprung zu user_index.php
		b) sonst : Rücksprung zu user_list.php
	Bei b) trat der Fall ein, dass ein neuer Benutzer erstellt wurde und nun
	die Rechte gesetzt wurden. Der Rücksprungpunkt muss verbogen werden.
	*/

	// Session starten
	session_start();

	require_once( "../lib/navigation.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/_config.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
	"header" => "header.html",
	"footer" => "footer.html",
	"index" => "index.html",
	"noaccess" => "no_access.html",
		// komplette Seite mit Tabellen-Grundgerüst und abteilungsübergreifende
		// Rechte sowie dem ganzem JavaScript
		"main" => "admin_user_rights_set.html",
		// Auswahlfeld für einzelne Abteilung
		"dep" => "admin_user_rights_set_dep.html",
		// Fehlermeldung beim Speichern der neuen Rechte
		"error" => "admin_user_rights_set_failed.html",
		// Okay-Meldung beim Speichern
		"saved" => "admin_user_rights_set_ok.html",
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Benutzerdaten und dessen Rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Parameter auswerten
	$id = $_REQUEST["id"];

	// Navigation vorbereiten und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	/*
	Die Zugriffsrechte eines Benutzers dürfen nur in zwei Fällen gesetzt werden :
		1. durch den Abteilungsleiter des Benutzers
		2. durch einen root-Admin
	UND : ein Benutzer kann nicht seine eigenen Rechte setzen !
	*/

	// Anzeige gestatten
	if( $id > 0 && $id <> $user->getID() ) {
		// Zugriffsrechte des anzuzeigenden Benutzers ermitteln
		if( $id == $user->getID() ) $profilerights = $rights;
			else $profilerights = new pRights( $db, (int) $id );

		// Fall ermitteln ( siehe Kommentar oben )
		if( count( array_intersect( $rights->getAdminDepartements(),	// Fall 1
			$profilerights->getRegistrarDepartements() ) ) > 0 )
			$case = 1;
		elseif( $rights->isRoot() ) // Fall 2
			$case = 2;
		else $case = 0;

		// Setzen der Zugriffsrechte zulassen, sofern Recht dazu besteht
		if( $case > 0 ) {
			// Benutzerdaten des anzuzeigenden Benutzers ermitteln
			$profile = new pUser( $db, (int) $id, "" );
			$template->assign( "{USR_SURNAME}", $profile->getSurname() );
			$template->assign( "{USR_LASTNAME}", $profile->getLastname() );
			$template->assign( "{USR_ID}", $profile->getID() );
			unset( $profile );

			// Wenn Daten gePOSTet wurden, dann neue Rechte speichern
			if( count( $_POST ) > 0 ) {
				// Root- oder normale Rechte setzen ( darf nur von einem root-Admin
				// gesetzt werden
				if( $rights->isRoot() && !empty( $_POST["ca_right"] ) ) {
					if( $_POST["ca_right"] == "root" ) $profilerights->setRoot( true );
					elseif( $_POST["ca_right"] == "normal" )
						$profilerights->setRoot( false );
				}
				// Wenn keine root-Rechte gesetzt wurden, dann Abteilungsrechte
				// speichern ( dürfen root-Admins und Abteilungsleiter )
				if( !$profilerights->isRoot() )
					foreach( $_POST as $key => $value )
					// Testen, ob Abteilung gePOSTet wurde
						if( substr( $key, 0, 4 ) == "dep_" ) {
							// ID der Abteilung extrahieren ( alles nach dem _ )
							$dep_id = (int) substr( strrchr( $key, "_" ), 1 );
							// Abteilungsrechte setzen
							if( $dep_id > 0 )
								switch( $value ) {
									case "adm"  : $profilerights->setAdmin( $dep_id ); break;
									case "reg"  : $profilerights->setRegistrar( $dep_id ); break;
									case "none" :
										$profilerights->removeAdmin( $dep_id );
										$profilerights->removeRegistrar( $dep_id );
										break;
								}
						}
				// die neuen Rechte speichern
				try {
					$profilerights->saveToDB( $db );
					// Rücksprungpunkt ( siehe Hinweise ganz oben )
					$template->assign( "{BACKREF}", ( $_SESSION["backref"] ==
						"index.php" ? "user_list.php" : $_SESSION["backref"] ) );
					$template->parse( "{MAIN}", "saved" );
				} catch( Exception $e ) {
					$template->assign( "{BACKREF}", $_SERVER["PHP_SELF"]."?id=$id" );
					$template->assign( "{ERROR}", $e->getMessage() );
					$template->parse( "{MAIN}", "error" );
				}
			}
			// ansonsten Formular anzeigen
			else {
				// Zurück-Button einsetzen ( siehe Hinweise ganz oben )
				$nav->add( NAV_BACK, ( $_SESSION["backref"] == "index.php" ?
					"user_list.php" : $_SESSION["backref"] ), "/left-blue.gif" );
				// Abteilungsübergreifende Rechte können gesetzt werden, wenn der
				// setzende Benutzer über root-Rechte verfügt
				$template->assign( "{USR_ROOT}", ( !$rights->isRoot() ? " disabled" :
					"" ) );
				$template->assign( "{CA_ROOT_RIGHT}", ( $profilerights->isRoot() ?
					" checked" : "" ) );
				$template->assign( "{CA_NORMAL_RIGHT}", ( !$profilerights->isRoot() ?
					" checked" : "" ) );
				// Rechte für die einzelnen Abteilungen ( Query zusammenbauen )
				if( $rights->isRoot() )
					$query = sprintf( "SELECT x.ID,x. name FROM %s x", DB_DEPS_TABLE );
				else
					$query = sprintf( "SELECT x.ID,x.name FROM %s x JOIN %s y ON ".
						"x.ID=y.Departement_ID JOIN %s z ON y.Auth_ID=z.Auth_ID AND ".
						"( z.User_ID=%u OR z.User_ID=%u ) GROUP BY x.name",
						DB_DEPS_TABLE, DB_RIGHTS_TABLE, DB_USER_TABLE, $user->getID(),
						$profile->getID() );
				$query .= " WHERE x.deleted=0 ORDER BY x.name;";
				// Abteilungen einparsen
				$db->query( $query );
				while( $data = $db->fetchRow() ) {
					$template->assign( "{DEP_ID}", $data[0] );
					$template->assign( "{DEP_NAME}", $data[1] );
					// Generell Einstellmöglichkeiten erlauben, sofern möglich
					$template->assign( "{DEP_ENABLED}", ( $profilerights->isRoot() ?
					" disabled" : "" ) );
					// Vorbelegung der Abteilung
					$template->assign( "{ADM_SELECT}", ( $profilerights->isAdmin( (int)
						$data[0] ) ? " checked" : "" ) );
					$template->assign( "{REG_SELECT}",
						( $profilerights->isRegistrar( (int) $data[0] ) ? " checked" :
						"" ) );
					$template->assign( "{NONE_SELECT}", ( !$profilerights->isAdmin( (int)
						$data[0] ) && !$profilerights->isRegistrar( (int) $data[0] ) ?
						" checked" : "" ) );
					// in die Tabelle inkrementell parsen
					$template->parse( "{DEP_RIGHTS}", ".dep" );
				}
				// Ausgabe
				$template->parse( "{MAIN}", "main" );
			}
		} else $template->parse( "{MAIN}", "noaccess" );
	} else $template->parse( "{MAIN}", "noaccess" );

	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>