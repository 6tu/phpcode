<?php
	/*
	Löscht ein X.509-Zertifikat
	Parameter :
	1.	key : ID des X.509-Zertifikates, das gelöscht werden soll
	*/

	require_once( "../lib/navigation.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/x509.php" );
	require_once( "../lib/csr.php" );
	require_once( "../lib/_config.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "no_access.html",
		// Bestätigungsformular zum Löschen des X.509-Zertifikates
		"confirm" => "admin_x509_delete.html",
		// Bestätigung der Löschung
		"deleted" => "admin_x509_delete_ok.html"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Benutzerdaten und dessen Rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Parameter auswerten
	$key = $_REQUEST["key"];

	// Navigation initialisieren und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	// Generelle Anzeige
	if( $key > 0 ) {
		// X.509-Zertifikat laden und Daten einparsen
		$x509 = new pX509Cert_DB( $db, (int) $key );
		$template->assign( "{X509_ID}", $x509->getID() );
		$template->assign( "{X509_NAME}", $x509->getName() );
		$template->assign( "{X509_HASH}", $x509->getHash() );
		$template->assign( "{X509_VERSION}", $x509->getVersion() );
		$template->assign( "{X509_SERIAL}", $x509->getSerial() );
		$template->assign( "{X509_COUNTRYNAME}", $x509->getCountryName() );
		$template->assign( "{X509_STATEORPROVINCENAME}",
			$x509->getStateOrProvinceName() );
		$template->assign( "{X509_LOCALITYNAME}", $x509->getLocalityName() );
		$template->assign( "{X509_ORGANIZATION}", $x509->getOrganizationName() );
		$template->assign( "{X509_COMMONNAME}", $x509->getCommonName() );
		$template->assign( "{X509_EMAIL}", $x509->getEMailAddress() );
		$template->assign( "{X509_VALID_FROM}", strftime( TIMEFORMAT,
			$x509->getValidFrom() ) );
		$template->assign( "{X509_VALID_TO}", strftime( TIMEFORMAT,
			$x509->getValidTo() ) );
		$template->assign( "{X509_CREATED}", strftime( TIMEFORMAT,
			$x509->getCreated() ) );

		// Abteilungs- und CSR-ID des Zertifikates ermitteln
		$query = sprintf( "SELECT Departement_ID, CSR_ID FROM %s WHERE ".
			"X509Cert_ID=%u", DB_CERTS_TABLE, $key );
		$db->query( $query );
		list( $dep_id, $csr_id ) = $db->fetchRow();

		// Ein X.509-Zertifikat darf nur ein root-Admin oder ein Abteilungsleiter
		// der Abteilung löschen, aus der es stammt
		if( $rights->isRoot() || $rights->isAdmin( $dep_id ) ) {

			// Sind Daten gepostet worden ? Dann X.509-Zertifikat löschen
			if( count( $_POST ) > 0 ) {
				// Transaktion starten
				$db->beginTransaction();
				try {
					// Zuerst das X.509-Zertifikat löschen
					$x509->deleteFromDB( $db );
					// und dann ggf. die CSR dazu
					if( $csr_id > 0 ) {
						$csr = new pCSR_DB( $db, (int) $csr_id );
						$csr->deleteFromDB( $db );
					}
					// Transaktion beenden
					$db->endTransaction();		// COMMIT
					// Löschen beendet; Löschen bestätigen
					$template->parse( "{MAIN}", "deleted" );
				} catch( Exception $e ) {
					$db->endTransaction( true );	// ROLLBACK
					throw $e;
				}
			}
			// Ansonsten Bestätigung zum Löschen anzeigen
			else {
				$nav->add( NAV_BACK, "x509_view.php?key=$key", "/left-blue.gif" );
				$template->parse( "{MAIN}", "confirm" );
			}
		}
	}
	// ansonsten Fehlermeldung
	if( !$template->get_assigned( "{MAIN}" ) )
	$template->parse( "{MAIN}", "noaccess" );

	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>