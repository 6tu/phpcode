<?php
	/*
	Lädt ein X.509-Zertifikat herunter
	Parameter :
	1. key            : ID des X.509-Zertifikates, das heruntergeladen wird
	2. format = "crt" : Download als Base64-kodiertes Zertifikat ohne Zusätze
	   format = "pem" : Download als ASCII-Datei mit Zusatzinformationen

	Hinweis : bei $key == 0 wird das X-509-Wurzelzertifikat der CA genutzt.
	*/

	// Parameter auswerten
	$format = $_REQUEST["format"];
	$key = $_REQUEST["key"];


	require_once( "../lib/database.php" );
	require_once( "../lib/_config.php" );
	require_once( "../lib/x509.php" );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	try {
	// X.509-Zertifikat laden und an den Browser senden
	if( $key <= 0 ) {
		// CA und dessen X.509-Zertifikat laden
		require_once( "../lib/ca.php" );
		$ca = new pCA_DB( $db );
		$x509 = $ca->getX509Cert();
		// Header senden
		header( "Content-Type: application/x-x509-ca-cert" );
	} else {
		// ansonsten Benutzerzertifikat laden
		$x509 = new pX509Cert_DB( $db, (int) $key );
		header( "Content-Type: application/x-x509-user-cert" );
	}

	switch( $format ) {
		case "pem" :
			header( "Content-Disposition: attachment; filename=x509Cert.pem" );
			print $x509->export();
			break;
		default :
			header( "Content-Disposition: attachment; filename=x509Cert.crt" );
			print $x509->export( true );
			break;
		}
	} catch( Exeception $e ) {
		print "Fehler beim Herunterladen des Zertifikates.";
	}

?>