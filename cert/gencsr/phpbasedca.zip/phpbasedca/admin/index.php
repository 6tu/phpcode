<?php
	/*
	Startseite der CA-Administration
	Parameter : keine
	*/

	// Session starten und alle Session-Inhalte löschen
	session_start(); session_unset();
  
	require_once( "../lib/navigation.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/ca.php" );
	require_once( "../lib/_config.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Rücksprungpunkt setzen
	$_SESSION["backref"] = $_SERVER["PHP_SELF"];
  
	// Template intialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		// Grundstruktur der Startseite
		"main" => "admin_index.html",
		// Datenbankinformationen über den CA-Server ( nur für root-Admins )
		"serverinfo" => "admin_index_serverinfo.html",
		// Informationen über den CA-Server ( für alle )
		"cainfo" => "admin_index_cainfo.html",
		// Benutzerdaten ( Vor- und Nachname usw. )
		"profile" => "admin_index_profile.html",
		// Ausstehende Aufgaben für Registrare und Abteilungsleiter
		"task" => "admin_index_task.html",
		// keine ausstehenden Aufgaben
		"no_task" => "admin_index_notask.html"
	) );
  
	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );
  
	// Benutzerdaten und dessen Rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Navigation initialisieren und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );
  
	// Menü für einen root-Admin erweitern
	if( $rights->isRoot() ) {
		$nav->add( NAV_INDEX_DEP_MANAGEMENT, "dep_list.php", "/sitemap-blue.gif" );
		$nav->add( NAV_INDEX_USR_MANAGEMENT, "user_list.php", "/user-group2.gif" );
		$nav->add( NAV_INDEX_CA_PRIVKEY, "ca_privkey_view.php",
			"/home-page-red.gif" );
		$nav->add( NAV_INDEX_CA_EDIT, "ca_edit.php", "/home-page-yellow.gif" );
		$nav->add( NAV_INDEX_CA_LOG, "ca_log.php", "/search-icon-blue.gif" );
		$nav->addSeparator();
	}
	// Allgemeine Menüpunkte für alle
	$nav->add( NAV_INDEX_CA_CERT, "ca_x509_view.php", "/home-page-blue.gif" );
	$nav->add( NAV_INDEX_CA_CERTS, "x509_list.php", "/edit-blue.gif" );
	// Für root-Admins macht es keinen Sinn, persönliche Abteilungen anzuzeigen,
	// da sie eh Zugriff auf alles haben
	if( !$rights->isRoot() )
		$nav->add( NAV_INDEX_USR_DEPS, "dep_list.php", "/sitemap-blue.gif" );
	$nav->add( NAV_INDEX_USR_PROFILE, "user_profile.php?id=".$user->getID(),
		"/user-comment-blue.gif" );
	$nav->add( NAV_INDEX_USR_RIGHTS, "user_rights_view.php?id=".$user->getID(),
		"/user-login-red.gif" );
  
	// Wenn root-Rechte bestehen, dann Serverübersicht generieren
	if( $rights->isRoot() ) {
		// Gesamtanzahl an Abteilungen ermitteln
		$db->query( sprintf( "SELECT COUNT(*) FROM %s WHERE deleted=0",
			DB_DEPS_TABLE ) );
		$template->assign( "{DEP_COUNT}", $db->fetchRow( 0 ) );
		// Gesamtanzahl an root-Admin ermitteln
		$query = sprintf( "SELECT COUNT( DISTINCT Auth_ID) FROM %s WHERE ISNULL( ".
			"Departement_ID );", DB_RIGHTS_TABLE );
		$db->query( $query );
		$template->assign( "{ROOT_COUNT}", $db->fetchRow( 0 ) );
		// Gesamtanzahl an Abteilungsadmins ermitteln
		$query = sprintf( "SELECT COUNT(DISTINCT x.Auth_ID) FROM %s x JOIN %s y ".
			"ON x.Departement_ID=y.ID AND y.deleted=0 AND x.registrar=0;",
			DB_RIGHTS_TABLE, DB_DEPS_TABLE );
		$db->query( $query );
		$template->assign( "{ADM_COUNT}", $db->fetchRow( 0 ) );
		// Gesamtanzahl an Registraren ermitteln
		$query = sprintf( "SELECT COUNT(DISTINCT x.Auth_ID) FROM %s x JOIN %s y ".
			"ON x.Departement_ID=y.ID AND y.deleted=0 AND x.registrar=1;",
			DB_RIGHTS_TABLE, DB_DEPS_TABLE );
		$db->query( $query );
		$template->assign( "{REG_COUNT}", $db->fetchRow( 0 ) );
		// Gesamtanzahl an Benutzern ermitteln
		$query = sprintf( "SELECT COUNT(*) FROM %s WHERE Auth_ID IS NOT NULL;",
			DB_USER_TABLE );
		$db->query( $query );
		$template->assign( "{USR_COUNT}", $db->fetchRow( 0 ) );
		// Anzahl der wartenden CSRs ermitteln
		$query = sprintf( "SELECT COUNT(*) FROM %s x JOIN %s y ON ".
			"x.Departement_ID=y.ID AND y.deleted=0;", DB_CSRS_TABLE, DB_DEPS_TABLE );
		$db->query( $query );
		$template->assign( "{CSR_COUNT}", $db->fetchRow( 0 ) );
		// Anzahl der gespeicherten X.509-Zertifikate ermitteln
		$db->query( sprintf( "SELECT COUNT(*) FROM %s", DB_X509_TABLE ) );
		$template->assign( "{X509_COUNT}", $db->fetchRow( 0 )-1 );
		// Fertig
		$template->parse( "{SERVER_INFO}", "serverinfo" );
	} else $template->assign( "{SERVER_INFO}", "" );
  
	// Informationen über die CA einparsen
	$ca = new pCA_DB( $db );
	$template->assign( "{CA_SERIAL}", $ca->getSerial() );
	$template->assign( "{CA_COUNTRYNAME}", $ca->getCountryName() );
	$template->assign( "{CA_STATEORPROVINCENAME}",
		$ca->getStateOrProvinceName() );
	$template->assign( "{CA_LOCALITYNAME}", $ca->getLocalityName() );
	$template->assign( "{CA_ORGANIZATION}", $ca->getOrganizationName() );
	$template->assign( "{CA_COMMONNAME}", $ca->getCommonName() );
	$template->assign( "{CA_EMAIL}", $ca->getEMailAddress() );
	$template->assign( "{CA_CREATED}",
		strftime( TIMEFORMAT, $ca->getCreated() ) );
	$template->assign( "{CA_MODIFIED}",
		strftime( TIMEFORMAT, $ca->getModified() ) );
	$template->parse( "{CA_INFO}", "cainfo" );
  
	// Benutzerdaten ermitteln und einparsen
	$template->assign( "{USR_SURNAME}", $user->getSurname() );
	$template->assign( "{USR_LASTNAME}", $user->getLastname() );
	$template->assign( "{USR_EMAIL}", $user->getEMail() );
	$template->assign( "{USR_ROOT}", ( $rights->isRoot() ? TXT_YES : TXT_NO ) );
	$template->assign( "{USR_DEPS}", $rights->getAdminCount() );
	$template->assign( "{USR_REGS}", $rights->getRegistrarCount() );
	$template->parse( "{USR_PROFILE}", "profile" );

	// Aufgaben ermitteln und einparsen
	$query = sprintf( "SELECT a.ID, a.name FROM %s a JOIN %s b ON a.ID=".
		"b.Departement_ID AND a.deleted=0 JOIN %s c ON a.ID=c.Departement_ID ".
		"JOIN %s d ON c.Auth_ID=d.Auth_ID AND d.ID=%u;",
		DB_DEPS_TABLE, DB_CSRS_TABLE, DB_RIGHTS_TABLE, DB_USER_TABLE,
		$user->getID() );
	$db->query( $query );
	$deps = array();
	while( $data = $db->fetchRow() ) {
		list( $dep_id, $dep_name ) = $data;
		array_push( $deps, sprintf( "<a href=\"dep_index.php?dep=%u\">%s</a>",
			$dep_id, $dep_name ) );
	}
	if( count( $deps ) > 0 ) {
		$template->assign( "{CSR_DEPS}", implode( ", ", $deps ) );
		$template->parse( "{USR_TASKS}", "task" );
	} else $template->parse( "{USR_TASKS}", "no_task" );

	$template->parse( "{MAIN}", "main" );
	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>