<?php
	/*
	Listet die CSR-Anfragen an eine Abteilung zur Signierung auf.
	Parameter :
	1.	dep : ID der Abteilung, dessen CSR-Anfragen aufgelistet werden sollen
	2.	(diverse Parameter aus der Tabellenauflistung)
	*/

	// Session starten
	session_start();

	require_once( "../lib/navigation.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_config.php" );
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/csr.php" );
	require_once( "../lib/departement.php" );
	require_once( "../lib/table.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "no_access.html",
		// Auflistung der wartenden CSRs
		"main" => "admin_dep_csr_list.html",
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Benutzerdaten und dessen Rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Parameter auswerten
	$dep = $_REQUEST["dep"];
	// Weiter mit den Tabellenparametern
	$page = ( $_REQUEST["page"] > 0 ? $_REQUEST["page"] :
		( $_SESSION["dep_csr_list_page"] > 0 ? $_SESSION["dep_csr_list_page"] :
		1 ) );
	$orderby = ( $_REQUEST["orderby"] > 0 ? $_REQUEST["orderby"] :
		( $_SESSION["dep_csr_list_orderby"] > 0 ?
		$_SESSION["dep_csr_list_orderby"] : 0 ) );
	$order = ( $_REQUEST["order"] != "" ? $_REQUEST["order"] :
		( $_SESSION["dep_csr_list_order"] != "" ? $_SESSION["dep_csr_list_order"] :
		"asc" ) );
	if( $order != "asc" && $order != "desc" ) $order = "asc";
	// Parameter in die Session speichern
	$_SESSION["dep_csr_list_page"] = $page;
	$_SESSION["dep_csr_list_orderby"] = $orderby;
	$_SESSION["dep_csr_list_order"] = $order;

	// Navigation vorbereiten und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	// Abteilungsdaten laden
	$departement = new pDepartement( $db, (int) $dep );

	// Anzeige der Liste von wartenden CSRs, sofern Recht besteht
	if( !$departement->isDeleted() && ( $rights->isRoot() ||
		$rights->isAdmin( $dep ) || $rights->isRegistrar( $dep ) ) ) {

		// Abteilungsdaten in das Template einparsen
		$template->assign( "{DEP_ID}", $dep );
		$template->assign( "{DEP_NAME}", $departement->getName() );

		// Zurück-Button
		$nav->add( NAV_BACK, "dep_index.php?dep=$dep", "/left-blue.gif" );
		// Maximalanzahl an anzeigbaren CSRs der Abteilung ermitteln
		$query = sprintf( "SELECT COUNT(*) FROM %s WHERE Departement_ID=%u;",
			DB_CSRS_TABLE, $dep );
		$db->query( $query );
		$maxcount = $db->fetchRow( 0 );
		$maxpage = floor( $maxcount / LIST_CSRS );
		if( $maxcount % LIST_CSRS <> 0 ) $maxpage++;

		// Tabelle mit den anzeigbaren X.509-Zertifikaten generieren
		$table = new pTable( CSR_LIST_TBL.$departement->getName, $page, $maxpage );
		$table->addColumn( CSR_LIST_TBL_CNAME, "70%", true, false );
		$table->addColumn( TBL_CREATED, "30%", true, true );
		$table->setSort( $orderby, $order );

		// Query für die CSRs der Abteilung zusammenbauen
		$query = sprintf( "SELECT x.ID, x.commonName, UNIX_TIMESTAMP( x.created ".
			") FROM %s x JOIN %s y ON x.ID=y.CSR_ID AND y.Departement_ID=%u",
			DB_CSR_TABLE, DB_CSRS_TABLE, $dep );
		// Sortierung und angezeigte Seite einfügen
		switch( $orderby ) {
			case 1  :
				$query .= " ORDER BY x.created $order, x.commonName ASC"; break;
			default :
				$query .= " ORDER BY x.commonName $order, x.created ASC"; break;
		}
		// anzuzeigende Seite in den Query einfügen
		$query .= sprintf( " LIMIT %u,%u;", ($page-1)*LIST_CSRS, LIST_CSRS );
		// CSRs der Abteilung aus der Datenbank lesen
		$db->query( $query );
		// Ergebnisse in die Tabelle einparsen
		while( $data = $db->fetchRow() ) {
			list( $ID, $commonname, $created ) = $data;
			// Zeile in die Tabelle einfügen
			$table->addRow( array(
			sprintf( "<a href=\"dep_csr_sign.php?id=%u\">%s</a>",
				$ID, $commonname ), strftime( TIMEFORMAT, $created )
			) );
		}
		// Tabelle einparsen und gesamte Seite parsen
		$template->assign( "{CSR_TABLE}", $table->parse() );
		$template->parse( "{MAIN}", "main" );
	} else $template->parse( "{MAIN}", "noaccess" );

	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>