<?php
	/*  
	Lädt einen privaten Schlüssel aus der Session des Benutzers herunter
	Parameter :
	1. format = "txt" : Download im Textformat
	   format = "pem" : Download im PEM-Format ( Standard )
	( siehe Skript dep_x509_add.php, dort wird der private Schlüssel generiert )
	*/
	
	// Session starten
	session_start();
	
	// Parameter auswerten
	$format = $_REQUEST["format"];
	
	// Header setzen
	header( "Content-Type: text/plain" );
	switch( $format ) {
	case "txt" : 
		header( "Content-Disposition: attachment; filename=privkey.txt" );
		break;
	default :
		header( "Content-Disposition: attachment; filename=privkey.pem" );
		break;
	}
	
	// privaten Schlüssel an den Browser senden
	$pkey = $_SESSION["dep_x509_add_pkey"];
	if( !empty( $pkey ) )	print $pkey;
	else print "Sorry, nothing to output";
?>