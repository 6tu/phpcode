<?php
	/*
	Listet Abteilungen je nach Benutzerrechten auf
	Parameter :
	1. (diverse Parameter aus der Tabellenauflistung)

	Hinweis : Wenn der Benutzer root-Rechte hat, werden alle Abteilungen
	aufgelistet, ansonsten nur die persönlichen. Das hat den Grund, da
	root-Admins eh Zugriff auf alles haben.
	*/

	// Session starten
	session_start();

	require_once( "../lib/navigation.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/departement.php" );
	require_once( "../lib/table.php" );
	require_once( "../lib/_config.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "no_access.html",
		// Auflistung der persönlichen Abteilungen
		"main" => "admin_dep_list.html",
		// AUflistung aller Abteilungen ( nur für root-Admins )
		"root" => "admin_dep_list_all.html"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Benutzerdaten und dessen Rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Parameter auswerten
	$page = ( $_REQUEST["page"] > 0 ? $_REQUEST["page"] :
		( $_SESSION["dep_list_page"] > 0 ? $_SESSION["dep_list_page"] : 1 ) );
	$orderby = ( $_REQUEST["orderby"] > 0 ? $_REQUEST["orderby"] :
		( $_SESSION["dep_list_orderby"] > 0 ? $_SESSION["dep_list_orderby"] :
		0 ) );
	$order = ( $_REQUEST["order"] != "" ? $_REQUEST["order"] :
		( $_SESSION["dep_list_order"] != "" ? $_SESSION["dep_list_order"] :
		"asc" ) );
	if( $order != "asc" && $order != "desc" ) $order = "asc";
	// Parameter in die Session speichern
	$_SESSION["dep_list_page"] = $page;
	$_SESSION["dep_list_orderby"] = $orderby;
	$_SESSION["dep_list_order"] = $order;

	// Navigation vorbereiten, Pfade einparsen und Zurück-Button einfügen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );
	$nav->add( NAV_BACK, "index.php", "/left-blue.gif" );

	// Navigation erweitern
	if( $rights->isRoot() ) {
		$nav->addSeparator();
		$nav->add( NAV_DEP_ADD, "dep_add.php", "/add-page-blue.gif" );
	}

	// Maximalanzahl an anzeigbaren Abteilungen ermitteln
	$query = sprintf( "SELECT COUNT(x.ID) FROM %s x", DB_DEPS_TABLE );
	// Wenn keine root-Rechte, dann persönliche Abteilungen anzeigen
	if( !$rights->isRoot() )
	$query .= sprintf( " JOIN %s y ON x.ID=y.Departement_ID JOIN %s z ON ".
		"y.Auth_ID=z.Auth_ID AND z.ID=%u",
		DB_RIGHTS_TABLE, DB_USER_TABLE, $user->getID() );
	// Nur aktive ( nicht gelöschte ) Abteilungen werden angezeigt
	$query .= " WHERE x.deleted=0;";
	$db->query( $query );
	$maxcount = $db->fetchRow( 0 );
	$maxpage = floor( $maxcount / LIST_DEPS );
	if( $maxcount % LIST_DEPS <> 0 ) $maxpage++;

	// Tabelle mit den anzeigbaren Abteilungen generieren
	if( $rights->isRoot() ) {
		$table = new pTable( DEP_LIST_TBL_SHOW_ALL, $page, $maxpage );
		$table->setCaption( "<img src=\"".IMAGE_PATH."/restrict-page-green.gif\">".
			" = ".DEP_LIST_TBL_ROOT_ACCESS );
	} else {
		$table = new pTable( DEP_LIST_TBL_SHOW, $page, $maxpage );
		$table->setCaption( "<img src=\"".IMAGE_PATH."/restrict-page-orange.".
			"gif\"> = ".DEP_LIST_TBL_ADM_ACCESS." <img src=\"".IMAGE_PATH.
			"/restrict-page-blue.gif\"> = ".DEP_LIST_TBL_REG_ACCESS );
	}
	$table->addColumn( DEP_LIST_TBL_DEPNAME, "60%", true, false );
	$table->addColumn( TBL_CREATED, "20%", true, true );
	$table->addColumn( TBL_MODIFIED, "20%", true, true );
	$table->setSort( $orderby, $order );

	// Query für die anzeigbare Abteilungen zusammenbauen
	if( $rights->isRoot() )
		$query = sprintf( "SELECT x.ID, x.name, UNIX_TIMESTAMP( x.created ), ".
			"UNIX_TIMESTAMP( x.modified ), 2 FROM %s x", DB_DEPS_TABLE );
	else
		$query = sprintf( "SELECT x.ID, x.name, UNIX_TIMESTAMP( x.created ), ".
			"UNIX_TIMESTAMP( x.modified ), y.registrar FROM %s x JOIN %s y ON ".
			"x.ID=y.Departement_ID JOIN %s z ON y.Auth_ID=z.Auth_ID AND z.ID=%u",
			DB_DEPS_TABLE, DB_RIGHTS_TABLE, DB_USER_TABLE, $user->getID() );
	// Nur aktive ( nicht gelöschte ) Abteilungen werden angezeigt
	$query .= " WHERE x.deleted=0 ORDER BY";
	// Sortierung und angezeigte Seite einfügen
	switch( $orderby ) {
		case 1  : $query .= " x.created $order, x.name ASC"; break;
		case 2  : $query .= " x.modified $order, x.name ASC"; break;
		default : $query .= " x.name $order"; break;
	}
	// anzuzeigende Seite in den Query einfügen
	$query .= sprintf( " LIMIT %u,%u;", ($page-1)*LIST_DEPS, LIST_DEPS );
	// Abteilungen aus der Datenbank lesen
	$db->query( $query );
	// Abteilungen in die Tabelle einparsen
	while( $data = $db->fetchRow() ) {
		list( $ID, $name, $created, $modified, $registrar ) = $data;
		// Spalte 1 : Icon mit den Zugriffsrechten
		switch( $registrar ) {
			case 0 : // Abteilungsleiter
				$icon = IMAGE_PATH."/restrict-page-orange.gif"; break;
			case 1 : // Registrar
				$icon = IMAGE_PATH."/restrict-page-blue.gif"; break;
			case 2 : // volle Rechte, siehe den Query
				$icon = IMAGE_PATH."/restrict-page-green.gif"; break;
		}
		// Schritt 2 : finales Setzen der Zeile
		$table->addRow( array(
			sprintf( "<img src=\"%s\"><a href=\"dep_index.php?dep=%u\">%s</a>",
				$icon, $ID, $name ),
			strftime( DATEFORMAT, $created ), strftime( DATEFORMAT, $modified )
		) );
	}

	// Tabelle einparsen
	$template->assign( "{DEPS_TABLE}", $table->parse() );
	$template->parse( "{MAIN}", ( $rights->isRoot() ? "root" : "main" ) );

	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>