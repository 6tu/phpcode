<?php
	/*
	Anzeige des Logbuches für ein X.509-Zertifikat
	Parameter :
	1. key : ID des X.509-Zertifikates, dessen Historie eingesehen werden soll
	2. ( diverse Parameter aus der Tabellenauflistung )

	Dieses Skript zeigt die Historie eines X.509-Zertifikates. Es kann von allen
	Benutzer eingesehen werden.
	*/
  
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_config.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/x509.php" );
	require_once( "../lib/navigation.php" );
	require_once( "../lib/table.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );
  
	// Template initialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "noaccess.html",
		// Hauptseite des Logbuches
		"main" => "admin_x509_log.html",
		// mögliche Einträge im Logbuch
		"ca_modify" => "log_ca_modify.html",
		"departement_create" => "log_dep_create.html",
		"departement_modify" => "log_dep_modify.html",
		"departement_delete" => "log_dep_delete.html",
		"departement_grant" => "log_dep_notify.html",
		"user_create" => "log_user_create.html", 
		"user_modify" => "log_user_modify.html",
		"user_delete" => "log_user_delete.html",
		"user_grant_root" => "log_user_grant_root.html",
		"user_grant_admin" => "log_user_grant_admin.html",
		"user_grant_registrar" => "log_user_grant_registrar.html",
		"user_revoke_root" => "log_user_grant_root.html",
		"user_revoke_admin" => "log_user_grant_admin.html",
		"user_revoke_registrar" => "log_user_grant_registrar.html",
		"cert_create" => "log_cert_create.html",
		"cert_delete" => "log_cert_delete.html",
		"cert_grant" => "log_cert_grant.html",
		"cert_revoke" => "log_cert_revoke.html",
		"cert_renew" => "log_cert_renew.html"
	) );
  
	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );
  
	// Benutzerdaten und -rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );
  
	// Parameter auswerten
	$key = $_REQUEST["key"];
	$page = ( $_REQUEST["page"] > 0 ? $_REQUEST["page"] : 1 );
	$order = $_REQUEST["order"];
	if( ($order != "asc") && ($order != "desc") ) $order = "desc";
	$orderby = $_REQUEST["orderby"];
  
	// Navigation initialisieren und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );
  
	if( $key > 0 ) {
		// X.509-Zertifikat laden und dessen Daten einparsen
		$x509 = new pX509Cert_DB( $db, (int) $key );
		$template->assign( "{X509_COMMONNAME}", $x509->getCommonName() );
  
		// Zurück-Button
		$nav->add( NAV_BACK, "x509_view.php?key=$key", "/left-blue.gif" );
	
		// Maximalanzahl an anzeigbaren Seiten ermitteln
		$query = sprintf( "SELECT COUNT(*) FROM %s WHERE ref_X509Cert_ID=%u",
			DB_LOG_TABLE, $key );
		$db->query( $query );
		$maxcount = $db->fetchRow( 0 );
		$maxpage = floor( $maxcount / LIST_LOG );
		if( $maxcount % LIST_LOG <> 0 ) $maxpage++;
		unset( $maxcount );
	
		$table = new pTable( LOG_TBL_SHOW_ALL, $page, $maxpage );
		// Spalten je nach $facility in die Tabelle einfügen
		$table->addColumn( LOG_TBL_OCCURED, "20%", true, true );
		$table->addColumn( LOG_TBL_EVENT, "80%", false, false );
		$table->setSort( $orderby, $order );
	
		// Logbuch abhängig von $order und $orderby durchsuchen
		$query = sprintf( "SELECT UNIX_TIMESTAMP( a.occured ), a.facility, ".
			"a.action, a.additional, b.ID, b.surname, b.lastname, c.ID, c.name, ".
			"d.ID, d.surname, d.lastname, e.ID, e.commonName, f.ID, f.commonName ".
			"FROM %s a JOIN %s b ON a.User_ID=b.ID LEFT JOIN %s c ON ".
			"a.ref_Departement_ID=c.ID LEFT JOIN %2\$s d ON a.ref_User_ID=d.ID ".
			"LEFT JOIN %s e ON a.ref_CSR_ID=e.ID LEFT JOIN %s f ON ".
			"a.ref_X509Cert_ID=f.ID WHERE a.ref_X509Cert_ID=%u",
			DB_LOG_TABLE, DB_USER_TABLE, DB_DEPS_TABLE, DB_CSR_TABLE,
			DB_X509_TABLE, $key );
		/*
		Der obige Query sieht schlimmer aus, als er ist. Vom Prinzip her werden
		alle ref_*-Felder mit einem LEFT JOIN verbunden und die nötigsten Angaben
		herausgezogen.
		*/
		// Sortierung einfügen
		$query .= " ORDER BY a.occured $order";
		// Anzuzeigende Seite
		$query .= sprintf( " LIMIT %u,%u;", ($page-1)*LIST_LOG, LIST_LOG );
		// Query ausführen
		$db->query( $query );
	
		// Daten in die Tabelle einsetzen
		while( $data = $db->fetchRow() ) {
			// Schritt 1 : Variablenwerte prüfen
			foreach( $data as $key => $value )
				if( empty( $value ) ) $data[$key] = TXT_UNKNOWN;
			// Schritt 2 : Logbuchdaten einparsen
			$template->assign( "{LOG_OCCURED}", strftime( TIMEFORMAT, $data[0] ) );
			$template->assign( "{LOG_FACILITY}", $data[1] );
			$template->assign( "{LOG_ACTION}", $data[2] );
			$template->assign( "{LOG_ADDITIONAL}", $data[3] );
			$template->assign( "{LOG_USR_ID}", $data[4] );
			$template->assign( "{LOG_USR_SURNAME}", $data[5] );
			$template->assign( "{LOG_USR_LASTNAME}", $data[6] );
			$template->assign( "{REF_DEP_ID}", $data[7] );
			$template->assign( "{REF_DEP_NAME}", $data[8] );
			$template->assign( "{REF_USR_ID}", $data[9] );
			$template->assign( "{REF_USR_SURNAME}", $data[10] );
			$template->assign( "{REF_USR_LASTNAME}", $data[11] );
			$template->assign( "{REF_CSR_ID}", $data[12] );
			$template->assign( "{REF_CSR_COMMONNAME}", $data[13] );
			$template->assign( "{REF_X509_ID}", $data[14] );
			$template->assign( "{REF_X509_COMMONNAME}", $data[15] );
			// Schritt 3 : Logbucheintrag generieren
			$log_template = sprintf( "%s_%s", $data[1], $data[2] );
			if( $data[1] == "user" && ( $data[2] == "grant" ||
				$data[2] == "revoke" ) )
				$log_template .= sprintf( "_%s", $data[3] );
			$template->parse( "{ENTRY}", $log_template );
			if( !$template->get_assigned( "{ENTRY}" ) )
				$template->assign( "{ENTRY}", TXT_UNKNOWN );
			// Schritt 3 : Tabellenzeile einfügen
			$table->addRow( array( strftime( TIMEFORMAT, $data[0] ),
				$template->get_assigned( "{ENTRY}" ) ) );
		}
	
		// Tabelle verarbeiten und einparsen
		$template->assign( "{LOG_TABLE}", $table->parse() );
		// Fertig
		$template->parse( "{MAIN}", "main" );
	} else $template->parse( "{MAIN}", "noaccess" );

	// Ausgabe
	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>