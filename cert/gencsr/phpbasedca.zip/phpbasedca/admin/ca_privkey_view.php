<?php
	/*
	Zeigt den privaten Schlüssel einer CA
	Parameter : keine
	*/

	require_once( "../lib/navigation.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/ca.php" );
	require_once( "../lib/privatekey.php" );
	require_once( "../lib/_config.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"main" => "admin_ca_pkey_view.html",
		"noaccess" => "no_access.html"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Benutzerdaten und dessen Rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Navigation vorbereiten und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	// Privater Schlüssel nur root-Admins zeigen
	if( $rights->isRoot() ) {
		// Zurück-Button
		$nav->add( NAV_BACK, "index.php", "/left-blue.gif" );
		// Navigation erweitern
		$nav->addSeparator();
		$nav->add( NAV_KEY_DOWNLOAD_PEM, "ca_privkey_download.php?format=pem",
			"/download-page-blue.gif" );
		$nav->add( NAV_KEY_DOWNLOAD_TXT, "ca_privkey_download.php?format=txt",
			"/download-page-blue.gif" );
		// Generelle Daten der CA auslesen und einparsen
		$ca = new pCA_DB( $db );
		$template->assign( "{CA_NAME}", $ca->getName() );
		// Privaten Schlüssel auslesen und wiedergeben
		$pkey = $ca->getPrivkey();
		$template->assign( "{CA_PKEY}", $pkey->export() );
		switch( $pkey->getKeytype() ) {
			case OPENSSL_KEYTYPE_RSA :
				$template->assign( "{PKEY_TYPE}", "RSA" ); break;
			case OPENSSL_KEYTYPE_DSA :
				$template->assign( "{PKEY_TYPE}", "DSA" ); break;
			case OPENSSL_KEYTYPE_DH :
				$template->assign( "{PKEY_TYPE}", "DH" ); break;
			default: $template->assign( "{PKEY_TYPE}", TXT_UNKNOWN ); break;
		}
		$template->assign( "{PKEY_BITS}", $pkey->getKeyLength() );
	} else $template->parse( "{MAIN}", "noaccess" );

	$template->parse( "{MAIN}", "main" );
	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>