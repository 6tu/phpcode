<?php
	/*
	Änderung des persönliches Profils eines Benutzers
	Parameter :
	1.	id : ID des zu ändernden Benutzers
	2.	backref : Rücksprungaddresse für den Zurück-Button ( aus der Session )
	*/

	// Session starten
	session_start();

	require_once( "../lib/navigation.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/log.php" );
	require_once( "../lib/_config.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "no_access.html",
		// Formular zum Bearbeiten/Anzeigen des Benutzerkontos
		"main" => "admin_user_profile.html",
		// Bestätigung des Speichern
		"saved" => "admin_user_profile_ok.html",
		// Fehlermeldung, wenn Login bereits vergeben ist
		"exist" => "admin_user_exist.html"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Benutzerdaten und dessen Rechte laden, der ändern will
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Parameter auswerten
	$id = $_REQUEST["id"];

	// Navigation initialisieren und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	/*
	Das Profil eines Benutzers kann nur in drei Fällen bearbeitet werden :
	1.	durch den Benutzer selbst ( nur Änderung der eMail-Adresse & Passwort )
	2.	der ändernde Benutzer muß Abteilungsrechte für den zu ändernden
			Benutzer haben ( Änderung des Namen, der eMail-Addresse & Passwort ),
			d.h. ein Abteilungsleiter kann ein Registrar derselben Abteilung ändern
	3.	der ändernde Benutzer hat root-Rechte ( darf alles ändern )
	*/
	if( $id > 0 ) {
		// Das zu ändernde Profil ( Benutzerdaten ) und dessen Rechte laden
		if( $id == $user->getID() ) {
			$profile = $user;
			$profilerights = $rights;
		} else {
			$profile = new pUser( $db, (int) $id, "" );
			$profilerights = new pRights( $db, $profile );
		}
		// Profildaten in das Template einparsen
		$template->assign( "{ID}", $profile->getID() );
		$template->assign( "{USR_SURNAME}", $profile->getSurname() );
		$template->assign( "{USR_LASTNAME}", $profile->getLastname() );
		$template->assign( "{USR_EMAIL}", $profile->getEMail() );
		$template->assign( "{USR_LOGIN}", $profile->getLogin() );
		// Zugriffskontrolle, $case wird für das spätere Layout gebraucht
		if( $rights->isRoot() )	// Fall 3
			$case = 3;
		elseif( count( array_intersect( $rights->getAdminDepartements(),
			$profilerights->getRegistrarDepartements() ) ) > 0 )	// Fall 2
			$case = 2;
		elseif( $profile->getID() == $user->getID() ) // Fall 1
			$case = 1;
		else $case = 0;

		// Anzeige des Formulars oder Speicherung der neuen Daten
		if( $case > 0 ) {

			// Sind Daten gepostet worden ? Dann Speicherung der neuen Daten
			if( count( $_POST ) > 0 ) {
				// den Namen dürfen nur root- und Abteilungsadmins neu setzen
				if( $case > 1 ) {
					if( !empty( $_POST["surname"] ) )
						$profile->setSurname( $_POST["surname"] );
					if( !empty( $_POST["lastname"] ) )
						$profile->setLastname( $_POST["lastname"] );
				}
				// eMail-Adresse darf jeder ändern
				if( !empty( $_POST["email"] ) ) $profile->setEMail( $_POST["email"] );
				// Den Login darf nur ein root-Admin ändern
				if( $case == 3 && !empty( $_POST["login"] ) && $_POST["login"] <>
					$profile->getLogin() ) $profile->setLogin( $_POST["login"] );
				// Passwort darf jeder ändern
				if( !empty( $_POST["password"] ) )
					$profile->setPassword( $_POST["password"] );
				try {
					$profile->saveToDB( $db );
					// Logbucheintrag setzen
					$log = new pLog( $db );
					$log->logModifyUser( $user, $profile );
					// Fertig
					$template->assign( "{BACKREF}", $_SESSION["backref"] );
					$template->parse( "{MAIN}", "saved" );
				} catch( Exception $e ) {
					// Fehlermeldung anzeigen und Formular neu ausfüllen lassen
					$template->assign( "{BACKREF}", $_SERVER["PHP_SELF"]."?id=$id" );
					$template->parse( "{MAIN}", "exist" );
				}
			}

			// Ansonsten Formular anzeigen
			if( !$template->get_assigned( "{MAIN}" ) ) {
				// Navigation erweitern
				$nav->add( NAV_BACK, $_SESSION["backref"], "/left-blue.gif" );
				// Loginfeld darf nur ein root-Admin ausfüllen
				$template->assign( "{USR_ROOT}", ( $case == 3 &&
					$id <> $user->getID()? "" : " disabled" ) );
				// Vor- und Nachnamen dürfen nur root- oder Abteilungs-Admin ausfüllen
				$template->assign( "{USR_ADM}", ( $case > 1 ? "" : " disabled" ) );
				$template->parse( "{MAIN}", "main" );
			}
		}
	}
	// Wenn bis hierher nichts angezeigt wurde, dann Fehlermeldung
	if( !$template->get_assigned( "{MAIN}" ) )
		$template->parse( "{MAIN}", "noaccess" );

	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>