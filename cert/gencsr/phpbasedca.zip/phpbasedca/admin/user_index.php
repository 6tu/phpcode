<?php
	/*
	Startseite eines Benutzerkontos; ggf. Administrationsmöglichkeiten
	Parameter :
	1.	id : ID des Benutzers, der angezeigt werden soll
	*/

	// Session starten und Rücksprungaddresse setzen
	session_start();
	$_SESSION["backref"] = $_SERVER["PHP_SELF"]."?id=".$_REQUEST["id"];

	require_once( "../lib/navigation.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/ca.php" );
	require_once( "../lib/_config.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "no_access.html",
		// Startseite eines Benutzerkontos
		"main" => "admin_user_index.html",
		// Eintrag in die Auflistung der Abt., wo Benutzer Zugriffsrechte hat
		// mit und ohne Benachrichtung für die Abteilung
		"member" => "admin_user_index_member1.html",
		"member_notify" => "admin_user_index_member2.html",
		// keine Einträge in der Auflistung
		"nomember" => "admin_user_index_nomember.html"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Benutzerdaten und dessen Rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Parameter auswerten
	$id = $_REQUEST["id"];

	// Navigation vorbereiten und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	/*
	Die Startseite des Benutzerkontos ist drei Fällen zulässig :
	1. der Benutzer hat root-Rechte
	2. der Benutzer ist Abteilungsleiter des anzuzeigenden Benutzers
	3. der Benutzer ist Registrar in der Abteilung des anzuzeigenden Benutzers
	*/
	if( $id > 0 ) {
		// Daten des zu anzuzeigenden Benutzers laden
		$profile = new pUser( $db, (int) $id, "" );
		$profilerights = new pRights( $db, $profile );
		// Fallunterscheidung
		if( $rights->isRoot() )									// Fall 1
			$case = 1;
		elseif( count( array_intersect( $rights->getAdminDepartements(),
			$profilerights->getRegistrarDepartements() ) ) > 0 )	// Fall 2
			$case = 2;
		elseif( count( array_intersect( $rights->getRegistrarDepartements(),
			$profilerights->getRegistrarDepartements() ) ) > 0 )	// Fall 3
			$case = 3;
		else $case = 0;

		if( $case > 0 ) {
			// Navigation erweitern
			$nav->add( NAV_BACK, "user_list.php", "/left-blue.gif" );
			$nav->add( NAV_HOME, "index.php", "/home-icon5.gif" );
			// Administrationsmöglichkeiten für root-Admins und Abteilungsleiter
			if( $case == 1 || $case == 2 ) {
				$nav->addSeparator();
				$nav->add( NAV_USER_EDIT, "user_profile.php?id=$id",
					"/user-comment-blue.gif" );
				// Eigenes Benutzerkonto darf nicht selber gelöscht werden
				if( $profile->getID() <> $user->getID() )
					$nav->add( NAV_USER_DELETE, "user_delete.php?id=$id",
						"/remove-user-red.gif" );
				$nav->add( NAV_USER_RIGHTS_VIEW, "user_rights_view.php?id=$id",
					"/user-login-blue.gif" );
				// Für das eigene Benutzerkonto keine Rechtefestlegung
				if( $profile->getID() <> $user->getID() )
					$nav->add( NAV_USER_RIGHTS_SET, "user_rights_set.php?id=$id",
						"/user-login-red.gif" );
				// Logbuch
				$nav->add( NAV_USER_LOG, "user_log.php?id=$id",
					"/search-icon-blue.gif" );
			}

			// Mitgliedschaften und Benachrichtungen ermitteln
			$query = sprintf( "SELECT x.name,y.registrar,y.notify FROM %s x JOIN ".
				"%s y ON x.ID=y.Departement_ID JOIN %s z ON y.Auth_ID=z.Auth_ID AND ".
				"z.ID=%u ORDER BY x.name;",
				DB_DEPS_TABLE, DB_RIGHTS_TABLE, DB_USER_TABLE, $id );
			$db->query( $query );
			while( $data = $db->fetchRow() ) {
				list( $dep_name, $registrar, $notify ) = $data;
				$template->assign( "{DEP_NAME}", $dep_name );
				$template->parse( ( $registrar > 0 ? "{REG_DEPS}" : "{ADM_DEPS}" ),
					".member".( $notify == 1 ? "_notify" : "" ) );
			}
			// Wenn keine Mitgliedschaften, dann so anzeigen
			if( !$template->get_assigned( "{ADM_DEPS}" ) )
				$template->parse( "{ADM_DEPS}", "nomember" );
			if( !$template->get_assigned( "{REG_DEPS}" ) )
				$template->parse( "{REG_DEPS}", "nomember" );

			// Generelle Benutzerdaten einparsen
			$template->assign( "{USR_SURNAME}", $profile->getSurname() );
			$template->assign( "{USR_LASTNAME}", $profile->getLastname() );
			$template->assign( "{USR_LOGIN}", ( $case != 3 ? $profile->getLogin() :
				TXT_NOT_SHOWN ) );
			$template->assign( "{USR_ROOT}", ( $case != 3 ?
				( $profilerights->isRoot() ? TXT_YES : TXT_NO ) :
					TXT_NOT_SHOWN ) );
			$template->assign( "{USR_EMAIL}", $profile->getEMail() );
			$template->assign( "{USR_CREATED}", strftime( TIMEFORMAT,
				$profile->getCreated() ) );
			$template->assign( "{USR_MODIFIED}", strftime( TIMEFORMAT,
				$profile->getModified() ) );
			// Ausgabe
			$template->parse( "{MAIN}", "main" );
		} else $template->parse( "{MAIN}", "noaccess" );
	} else $template->parse( "{MAIN}", "noaccess" );

	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>