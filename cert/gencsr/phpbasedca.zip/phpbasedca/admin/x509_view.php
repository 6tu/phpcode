<?php
	/*
	Zeigt ein X.509-Zertifikat an
	Parameter :
		1.	key : ID des X.509-Zertifikates, das angezeigt werden soll
	*/

	require_once( "../lib/navigation.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/departement.php" );
	require_once( "../lib/x509.php" );
	require_once( "../lib/_config.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "no_access.html",
		// Anzeige der X.509-Zertifikatsdaten
		"main" => "admin_x509_view.html",
		// Hinweismeldung, dass noch 60 Tage bis Ablauf verbleiben
		"valid" => "x509_view_valid.html",
		// Hinweismeldung, dass Zertifikat bereits abgelaufen ist
		"invalid" => "x509_view_invalid.html"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Parameter auswerten
	$key = $_REQUEST["key"];

	// Benutzerdaten und Rechte aus der Datenbank lesen
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Navigation vorbereiten und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	// Seite anzeigen, wenn die Schlüssel-ID ok ist
	if( $key > 0 ) {

		// X.509-Zertifikat laden
		$x509 =  new pX509Cert_DB( $db, (int) $key );
		// Weitergehende Informationen über das Zertifikat aus der Datenbank lesen
		$query = sprintf( "SELECT x.Departement_ID, x.User_ID, DATEDIFF( ".
			"CURDATE(), y.valid_to ) FROM %s x JOIN %s y ON y.ID=x.X509Cert_ID ".
			"AND x.X509Cert_ID=%u;",
			DB_CERTS_TABLE, DB_X509_TABLE, $key );
		$db->query( $query );
		list( $dep_id, $profile_id, $daysleft ) = $db->fetchRow();
		// Abteilungsdaten laden und einparsen, sofern möglich
		$template->assign( "{DEP_NAME}", TXT_UNKNOWN );
		if( $dep_id > 0 ) {
			$departement = new pDepartement( $db, (int) $dep_id );
			if( !$departement->isDeleted() )
				$template->assign( "{DEP_NAME}", $departement->getName() );
			unset( $departement );
		}
		// Wenn Benutzerdaten verfügbar, dann diese laden und einparsen
		$template->assign( "{USR_SURNAME}", TXT_UNKNOWN );
		$template->assign( "{USR_LASTNAME}", "" );
		if( $profile_id > 0 ) {
			$profile = new pUser( $db, (int) $profile_id, "" );
			if( !$profile->isDeleted() ) {
				$template->assign( "{USR_SURNAME}", $profile->getSurname() );
				$template->assign( "{USR_LASTNAME}", $profile->getLastname() );
			}
			unset( $profile );
		}
		// Anzahl der verbleibende Tage einparsen
		$template->assign( "{X509_DAYS_LEFT}", $daysleft*(-1) );

		// Zurück-Button einsetzen und Downloadmöglichkeiten geben
		$nav->add( NAV_BACK, "x509_list.php", "/left-blue.gif" );
		$nav->addSeparator();
		$nav->add( NAV_CERT_DOWNLOAD_PEM, "x509_download.php?key=$key&".
			"format=pem", "/download-page-blue.gif" );
		$nav->add( NAV_CERT_DOWNLOAD_CRT, "x509_download.php?key=$key&".
			"format=crt", "/download-page-blue.gif" );
		// Logbuch ( Historie ) des X.509-Zertifikates
		$nav->addSeparator();
		$nav->add( NAV_X509_LOG, "x509_log.php?key=$key",
			"/search-icon-blue.gif" );
		// root-Admins und Abteilungsleiter dürfen das Zertifikat auch löschen
		if( $rights->isRoot() || $rights->isAdmin( (int) $dep_id ) ) {
			$nav->addSeparator();
			$nav->add( NAV_X509_DELETE, "x509_delete.php?key=$key",
				"/delete-comment-red.gif" );
		}

		// Ablaufdatum überprüfen, ggf. Hinweis einparsen
		if( $daysleft < -60 )
			$template->assign( "{X509_VALID}", "" );
		elseif( $daysleft >= -60 ) {
			// Navigation um Menüpunkt "Zertifikat erneuern" erweitern
			if( $rights->isRoot() || $rights->isAdmin( $dep_id ) ||
				$rights->isRegistrar( $dep_id ) )
				$nav->add( NAV_X509_RENEW, "x509_renew.php?key=$key",
					"/add-comment-orange.gif" );
				// Hinweis über Ablaufdatum einblenden
				$template->parse( "{X509_VALID}", ( $daysleft >= 0 ? "invalid" :
					"valid" ) );
		}

		// Zertifikatsdaten einparsen
		$template->assign( "{X509_NAME}", $x509->getName() );
		$template->assign( "{X509_HASH}", $x509->getHash() );
		$template->assign( "{X509_VERSION}", $x509->getVersion() );
		$template->assign( "{X509_SERIAL}", $x509->getSerial() );
		$template->assign( "{X509_COUNTRYNAME}", $x509->getCountryName() );
		$template->assign( "{X509_STATEORPROVINCENAME}",
			$x509->getStateOrProvinceName() );
		$template->assign( "{X509_LOCALITYNAME}", $x509->getLocalityName() );
		$template->assign( "{X509_ORGANIZATION}", $x509->getOrganizationName() );
		$template->assign( "{X509_COMMONNAME}", $x509->getCommonName() );
		$template->assign( "{X509_EMAIL}", $x509->getEMailAddress() );
		$template->assign( "{X509_VALID_FROM}", strftime( TIMEFORMAT,
			$x509->getValidFrom() ) );
		$template->assign( "{X509_VALID_TO}", strftime( TIMEFORMAT,
			$x509->getValidTo() ) );
		$template->assign( "{X509_CREATED}", strftime( TIMEFORMAT,
			$x509->getCreated() ) );
		// Daten der ausstellenden CA einparsen
		$issuer = $x509->getIssuer();
		$template->assign( "{ISSUER_COUNTRYNAME}", $issuer->getCountryName() );
		$template->assign( "{ISSUER_STATEORPROVINCENAME}",
			$issuer->getStateOrProvinceName() );
		$template->assign( "{ISSUER_LOCALITYNAME}", $issuer->getLocalityName() );
		$template->assign( "{ISSUER_ORGANIZATION}",
			$issuer->getOrganizationName() );
		$template->assign( "{ISSUER_COMMONNAME}", $issuer->getCommonName() );
		$template->assign( "{ISSUER_EMAIL}", $issuer->getEMailAddress() );
		// Rohdaten des Zertifikates
			$template->assign( "{X509}", $x509->export( true ) );

		// Fertig
		$template->parse( "{MAIN}", "main" );
	} else $template->parse( "{MAIN}", "noaccess" );

	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>