<?php
	/*
	Startseite einer Abteilung der CA; ggf. Administrationsmöglichkeiten
	Parameter :
	1.	dep : ID der Abteilung, die angezeigt werden soll
	*/

	// Session starten, um die Session-Daten von dep_x509_add zu löschen;
	// insbesondere private Schlüssel
	session_start();
	unset( $_SESSION["dep_x509_add_pkey"] );

	require_once( "../lib/navigation.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/departement.php" );
	require_once( "../lib/table.php" );
	require_once( "../lib/_config.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "no_access.html",
		// Hauptseite
		"main" => "admin_dep_index.html",
		// Hinweismeldung, wenn CSR zum Signieren warten
		"csr" => "admin_dep_index_csr.html",
		// Tabelleneintrag als Abteilungsleiter oder Registrar
		// ohne Benachrichtigung
		"member" => "dep_index_member1.html",
		// Tabelleneintrag als Abteilungsleiter oder Registrar
		// mit Benachrichtigung
		"member_notify" => "dep_index_member2.html",
		// Tabelleneintrag ohne Text
		"nomember" => "dep_index_nomember.html"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Benutzerdaten und dessen Rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Parameter auswerten
	$dep = $_REQUEST["dep"];

	// Navigation vorbereiten und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	// Abteilungsdaten laden
	$departement = new pDepartement( $db, (int) $dep );

	// Nur root-Admin, Registrare und Abteilungsleiter der Abteilung dürfen
	// in das Hauptmenü der Abteilung, sofern sie noch nicht gelöscht
	if( !$departement->isDeleted() && ( $rights->isRoot() ||
		$rights->isAdmin( $dep ) || $rights->isRegistrar( $dep ) ) ) {

		// Navigation erweitern
		$nav->add( NAV_HOME, "index.php", "/home-icon5.gif" );
		$nav->add( NAV_BACK, "dep_list.php", "/left-blue.gif" );
		$nav->addSeparator();
		if( $rights->isRoot() || $rights->isAdmin( $dep ) ) {
			$nav->add( NAV_DEP_EDIT, "dep_edit.php?dep=$dep",
				"/edit-page-blue.gif" );
			if( $rights->isRoot() )
			$nav->add( NAV_DEP_DELETE, "dep_delete.php?dep=$dep",
				"/delete-page-red.gif" );
			$nav->add( NAV_DEP_USR_MANAGEMENT, "user_list.php?dep=$dep",
				"/user-group2.gif" );
			$nav->add( NAV_DEP_NOTIFY, "dep_notify.php?dep=$dep",
				"/email-orange.gif" );
		} else {
			// Registrare dürfen auch Liste der Benutzer sehen, allerdings keine
			// Administrationsmöglichkeiten
			$nav->add( NAV_DEP_REGS, "user_list.php?dep=$dep", "/user-group2.gif" );
		}
	  // Normales Menü für alle
		$nav->add( NAV_DEP_LOG, "dep_log.php?dep=$dep", "/search-icon-blue.gif" );
		$nav->addSeparator();
		$nav->add( NAV_DEP_X509_ADD, "dep_x509_add.php?dep=$dep",
			"/add-comment-blue.gif" );
		$nav->add( NAV_DEP_X509_MANAGEMENT, "x509_list.php?dep=$dep",
			"/edit-blue.gif" );
		$nav->add( NAV_DEP_CSR_MANAGEMENT, "dep_csr_list.php?dep=$dep",
			"/edit-comment-blue.gif" );

		// Gesamtanzahl der Benutzer der Abteilung ermitteln
		$query = sprintf( "SELECT COUNT( DISTINCT Auth_ID ) FROM %s WHERE ".
			"Departement_ID=%u;", DB_RIGHTS_TABLE, $dep );
		$db->query( $query );
		$template->assign( "{USR_COUNT}", $db->fetchRow( 0 ) );
		// Gesamtanzahl an Benutzern mit Abteilungsrechten ermitteln
		$query = sprintf( "SELECT COUNT( DISTINCT Auth_ID ) FROM %s WHERE ".
			"Departement_ID=%u AND registrar=0;", DB_RIGHTS_TABLE, $dep );
		$db->query( $query );
		$template->assign( "{ADM_COUNT}", $db->fetchRow( 0 ) );
		// Gesamtanzahl an Registraren der Abteilung ermitteln
		$query = sprintf( "SELECT COUNT( DISTINCT Auth_ID ) FROM %s WHERE ".
			"Departement_ID=%u AND registrar=1;", DB_RIGHTS_TABLE, $dep );
		$db->query( $query );
		$template->assign( "{REG_COUNT}", $db->fetchRow( 0 ) );
		// Anzahl der wartenden CSRs der Abteilung ermitteln
		$query = sprintf( "SELECT COUNT(*) FROM %s WHERE Departement_ID=%u;",
			DB_CSRS_TABLE, $dep );
		$db->query( $query );
		$csr = $db->fetchRow( 0 );
		// Wenn CSRs zum Signieren warten, dann Hinweis einparsen
		if( $csr > 0 ) {
			$template->assign( "{DEP_ID}", $departement->getID() );
			$template->assign( "{CSR_COUNT}", $csr );
			$template->parse( "{DEP_CSR}", "csr" );
		} else $template->assign( "{DEP_CSR}", "" );
		// Anzahl der X.509-Zertifikate der Abteilung ermitteln
		$query = sprintf( "SELECT COUNT(*) FROM %s WHERE Departement_ID=%u;",
			DB_CERTS_TABLE, $dep );
		$db->query( $query );
		$template->assign( "{X509_COUNT}", $db->fetchRow( 0 ) );
		// Generelle Daten der CA auslesen und einparsen
		$template->assign( "{DEP_NAME}", $departement->getName() );
		$template->assign( "{DEP_CREATED}", strftime( TIMEFORMAT,
			$departement->getCreated() ) );
		$template->assign( "{DEP_MODIFIED}", strftime( TIMEFORMAT,
			$departement->getModified() ) );
		// Namen der Abteilungsleiter und Registrare ermitteln und einparsen
		$query = sprintf( "SELECT x.surname,x.lastname,x.email,z.registrar,".
			"z.notify FROM %s x JOIN %s y ON x.Auth_ID=y.ID JOIN %s z ON ".
			"y.ID=z.Auth_ID AND z.Departement_ID=%u ORDER BY z.registrar ASC, ".
			"x.lastname ASC, x.surname ASC;",
			DB_USER_TABLE, DB_AUTH_TABLE, DB_RIGHTS_TABLE, $dep );
		$db->query( $query );
		while( $data = $db->fetchRow() ) {
			list( $surname, $lastname, $email, $registrar, $notify ) = $data;
			$template->assign( "{USR_SURNAME}", $surname );
			$template->assign( "{USR_LASTNAME}", $lastname );
			$template->assign( "{USR_EMAIL}", $email );
			// Je nach Rechten in die Abteilungsleiter- oder Registrarliste einfügen
			$template->parse( "{DEP_".( $registrar == 1 ? "REGS" : "ADM" )."}",
				".member".( $notify == 1 ? "_notify" : "" ) );
		}
		// Keine Abteilungsleiter verzeichnet ?
		if( !$template->get_assigned( "{DEP_ADM}" ) )
			$template->parse( "{DEP_ADM}", "nomember" );
		// Keine Registrare verzeichnet ?
		if( !$template->get_assigned( "{DEP_REGS}" ) )
			$template->parse( "{DEP_REGS}", "nomember" );

		// Ausgabe
		$template->parse( "{MAIN}", "main" );

	} else $template->parse( "{MAIN}", "noaccess" );

	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>