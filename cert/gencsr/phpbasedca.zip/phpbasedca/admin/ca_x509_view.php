<?php
	/*
	Zeigt das X.509-Zertifikat der CA an
	Parameter : keine

	Die Anzeige des X.509-Wurzelzertifikates ist unkritisch, daher kann sie
	jeder einsehen.
	*/

	require_once( "../lib/navigation.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/ca.php" );
	require_once( "../lib/x509.php" );
	require_once( "../lib/_config.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		// Anzeige der X.509-Wurzelzertifikatsdaten
		"main" => "admin_ca_x509_view.html"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Navigation vorbereiten und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	// Navigationsmenü zusammenbauen
	$nav->add( NAV_BACK, "index.php", "/left-blue.gif" );
	$nav->addSeparator();
	$nav->add( NAV_CERT_DOWNLOAD_PEM, "x509_download.php?format=pem",
		"/download-page-blue.gif" );
	$nav->add( NAV_CERT_DOWNLOAD_CRT, "x509_download.php?format=crt",
		"/download-page-blue.gif" );

	// X.509-Zertifikat kann jeder einsehen
	$ca = new pCA_DB( $db );
	$x509 = $ca->getX509Cert();
	// Zertifikatsdaten einparsen
	$template->assign( "{CA_NAME}", $ca->getName() );
	$template->assign( "{X509_NAME}", $x509->getName() );
	$template->assign( "{X509_HASH}", $x509->getHash() );
	$template->assign( "{X509_VERSION}", $x509->getVersion() );
	$template->assign( "{X509_SERIAL}", $x509->getSerial() );
	$template->assign( "{X509_COUNTRYNAME}", $x509->getCountryName() );
	$template->assign( "{X509_STATEORPROVINCENAME}",
		$x509->getStateOrProvinceName() );
	$template->assign( "{X509_LOCALITYNAME}", $x509->getLocalityName() );
	$template->assign( "{X509_ORGANIZATION}", $x509->getOrganizationName() );
	$template->assign( "{X509_COMMONNAME}", $x509->getCommonName() );
	$template->assign( "{X509_EMAIL}", $x509->getEMailAddress() );
	$template->assign( "{X509_VALID_FROM}", strftime( TIMEFORMAT,
		$x509->getValidFrom() ) );
	$template->assign( "{X509_VALID_TO}", strftime( TIMEFORMAT,
		$x509->getValidTo() ) );
	// Daten der ausstellenden CA einparsen
	$issuer = $x509->getIssuer();
	$template->assign( "{ISSUER_COUNTRYNAME}", $issuer->getCountryName() );
	$template->assign( "{ISSUER_STATEORPROVINCENAME}",
		$issuer->getStateOrProvinceName() );
	$template->assign( "{ISSUER_LOCALITYNAME}", $issuer->getLocalityName() );
	$template->assign( "{ISSUER_ORGANIZATION}", $issuer->getOrganizationName() );
	$template->assign( "{ISSUER_COMMONNAME}", $issuer->getCommonName() );
	$template->assign( "{ISSUER_EMAIL}", $issuer->getEMailAddress() );
	// Rohdaten des Zertifikates
	$template->assign( "{X509}", $x509->export( true ) );

	$template->parse( "{MAIN}", "main" );
	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>