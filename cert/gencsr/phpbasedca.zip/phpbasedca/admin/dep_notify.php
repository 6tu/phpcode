<?php
	/*
	Verwalten der Benachrichtungen bei einer CSR in einer Abteilung
	Parameter :
	1. dep : ID der Abteilung, dessen Benachrichtungseinstellungen geändert
		werden sollen
	*/
  
	require_once( "../lib/navigation.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/departement.php" );
	require_once( "../lib/_config.php" );
	require_once( "../lib/log.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );
  
	// Template intialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "no_access.html",
		// Formular ( Grundgerüst ) zum Einstellen der Benachrichtungen
		"form" => "admin_dep_notify.html",
		// Eintrag in der Liste ( Abteilungsleiter )
		"row_adm" => "admin_dep_notify_adm.html",
		// Eintrag in der Liste ( Registrare )
		"row_reg" => "admin_dep_notify_reg.html",
		// keine Abteilungsleiter oder Registrare in der Abteilung
		"row_none" => "admin_dep_notify_none.html",
		// Okay-Meldung beim Speichern der Einstellungen
		"saved" => "admin_dep_notify_ok.html"
	) );
  
	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Benutzerdaten und dessen Rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Parameter auswerten
	$dep = $_REQUEST["dep"];

	// Navigation initialisieren und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );
  
	// Abteilung laden
	$departement = new pDepartement( $db, (int) $dep );

	// Änderungen an den Benachrichtigungen dürfen nur root-Admins und
	// Abteilungsleiter, sofern Abteilung noch nicht gelöscht
	if( !$departement->isDeleted() && ( $rights->isRoot() ||
		$rights->isAdmin( $dep ) ) ) {
		// Abteilungsdaten in das Template einparsen
		$template->assign( "{DEP_ID}", $dep );
		$template->assign( "{DEP_NAME}", $departement->getName() );

		// Formular anzeigen, sofern keine Daten gePOSTet
		if( count( $_POST ) == 0 ) {
			// Zurück-Button
 			$nav->add( NAV_BACK, "dep_index.php?dep=$dep", "/left-blue.gif" );
			// Liste der Abteilungsleiter und Registrare der Abteilung sowie
			// deren Benachrichtungsstatus ermitteln
			$query = sprintf( "SELECT x.Auth_ID, x.registrar, x.notify, y.surname, ".
				"y.lastname FROM %s x JOIN %s y ON x.Auth_ID=y.Auth_ID AND ".
				"x.Departement_ID=%u ORDER BY x.registrar, y.lastname, y.surname;",
				DB_RIGHTS_TABLE, DB_USER_TABLE, $dep );
			$db->query( $query );
			while( $data = $db->fetchRow() ) {
				list( $auth_id, $registrar, $notify, $surname, $lastname ) = $data;
				$template->assign( "{AUTH_ID}", $auth_id );
				$template->assign( "{USR_SURNAME}", $surname );
				$template->assign( "{USR_LASTNAME}", $lastname );
				$template->assign( "{NOTIFY}", ( $notify > 0 ? " checked" : "" ) );
				$template->parse( "{MEMBER_LIST}", ( $registrar > 0 ? ".row_adm" :
					".row_reg" ) );
			}
			// Testen, ob überhaupt Zeilen in der Auflistung vorhanden sind
			if( !$template->get_assigned( "{MEMBER_LIST}" ) )
				$template->parse( "{MEMBER_LIST}", "row_none" );
			$template->assign( "{DISABLED}", ( $db->countRows() == 0 ? " disabled" :
				"" ) );
			// Formular anzeigen
			$template->parse( "{MAIN}", "form" );
		}
		// Daten aus dem Formular, dann Speicherung in die DB
		elseif( count( $_POST ) > 0 ) {
			// Benachrichtungen extrahieren und in die DB speichern
			foreach( $_POST as $key => $value )
				if( strtolower( substr( $key,0,4 ) ) == "auth" ) {
					$auth_id = substr( strrchr( $key, "_" ), 1 );
					if( $auth_id > 0 ) {
						$query = sprintf( "UPDATE %s SET notify=%u WHERE Auth_ID=%u AND ".
						"Departement_ID=%u;",
						DB_RIGHTS_TABLE, ( empty( $value ) ? 0 : 1 ), $auth_id, $dep );
					$db->query( $query );
					}
				}
			// Logbuch führen
			$log = new pLog( $db );
			$log->logNotifyDepartement( $user, $departement );
			// Fertig
			$template->parse( "{MAIN}", "saved" );
		} 

	} else $template->parse( "{MAIN}", "noaccess" );
  
	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>