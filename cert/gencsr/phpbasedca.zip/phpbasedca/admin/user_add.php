<?php
	/*
	Erstellt ein neuen Benutzer/Registrar
	Parameter :
	1.	dep :
			ID der Abteilung, in der ein Registrar erstellt werden soll.
			Wird aus der Session gewonnen.

	Hinweis : Wenn
	a) 	dep > 0 und Benutzer ist Abteilungsleiter oder root-Admin, dann Registrar
			für die Abteilung erstellen ( sofern Abteilung noch nicht gelöscht )
	b)	dep = 0 und Benutzer ist root-Admin, dann allg. Benutzer erstellen
	*/

	// Session starten
	session_start();

	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_config.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/departement.php" );
	require_once( "../lib/log.php" );
	require_once( "../lib/navigation.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Session starten
	session_start();

	// Template initialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "no_access.html",
		// Formular, um allg. Benutzer zu erstellen
		"form_root" => "admin_user_add_root.html",
		"saved_root" => "admin_user_add_root_ok.html",
		// Formular, um Registrar zu erstellen
		"form_reg" => "admin_user_add_reg.html",
		"saved_reg" => "admin_user_add_reg_ok.html",
		// Fehlermeldung, wenn Login bereits vergeben ist
		"exist" => "admin_user_exist.html"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Benutzerdaten und dessen Rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Navigation initialisieren und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	// Abteilung herausfinden
	$dep = $_SESSION["user_list_dep"];

	// Fallunterscheidung ( siehe Hinweis ganz oben )
	if( $dep > 0 && ( $rights->isRoot() || $rights->isAdmin( $dep ) ) )
		$case = 1;	// Fall a
	elseif( $dep == 0 && $rights->isRoot() )
		$case = 2;	// Fall b
	else $case = 0;

	// Abteilungsdaten laden und in das Template einparsen, sofern nötig
	if( $case == 1 ) {
		$departement = new pDepartement( $db, (int) $dep );
		// Testen, ob Abteilung schon gelöscht
		if( $departement->isDeleted() ) $case = 0;
			else $template->assign( "{DEP_NAME}", $departement->getName() );
	}

	// Benutzer hinzufügen, wenn Rechte dazu bestehen
	if( $case > 0 ) {

		// Wenn keine Daten gePOSTet wurden, dann Formular anzeigen
		if( count( $_POST ) == 0 ) {
			// Zurück-Button einfügen
			$nav->add( NAV_BACK, "user_list.php", "/left-blue.gif" );
			// Formular anzeigen, je nach Fall
			$template->parse( "{MAIN}", "form_".( $case == 1 ? "reg" : "root" ) );
		}
		// ansonsten neuen Benutzer/Registrar anlegen
		else {
			try {
				// Neues Benutzerkonto erstellen
				$newprofile = new pUser( $_POST["surname"], $_POST["lastname"],
					$_POST["login"], $_POST["password"], $_POST["email"] );
				$newprofile->saveToDB( $db );
				// Logbucheintrag
				$log = new pLog( $db );
				$log->logCreateUser( $user, $newprofile );
				// Als Registrar eintragen, sofern vorgesehen
				if( $case == 1 ) {
					$newrights = new pRights( $newprofile );
					$newrights->setRoot( false );
					$newrights->setRegistrar( $departement->getID() );
					// Benachrichtigungsoption
					if( $_POST["notify"] == "yes" )
						$newrights->setNotify( $departement->getID() );
					$newrights->saveToDB( $db );
					// Logbucheintrag
					$log->logGrantRegistrar( $user, $newprofile, $departement );
				}
				// Okay-Meldung vorbereiten
				$template->assign( "{USR_ID}", $newprofile->getID() );
				$template->assign( "{USR_SURNAME}", $newprofile->getSurname() );
				$template->assign( "{USR_LASTNAME}", $newprofile->getLastname() );
				$template->assign( "{USR_LOGIN}", $newprofile->getLogin() );
				// Okay-Meldung ausgeben, je nach Fall
				$template->parse( "{MAIN}", "saved_".( $case == 1 ? "reg" : "root" ) );
			} catch( Exception $e ) {
				$template->assign( "{BACKREF}", $_SERVER["PHP_SELF"] );
				$template->parse( "{MAIN}", "exist" );
			}
		}
	} else $template->parse( "{MAIN}", "noaccess" );

	// Ausgabe
	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>