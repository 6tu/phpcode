<?php
	/*
	Listet X.509-Zertifikate auf; entweder für eine spezielle Abteilung oder
	alle ( bei root-Rechten aus dem Hauptmenü )
	Parameter :
	1.	dep : ID der Abteilung, dessen X.509-Zert. aufgelistet werden sollen
	2.	(diverse Parameter aus der Tabellenauflistung)

	Hinweis : der Parameter $dep ist optional.
	*/

	// Session starten
	session_start();

	require_once( "../lib/navigation.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/table.php" );
	require_once( "../lib/departement.php" );
	require_once( "../lib/_config.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "no_access.html",
		// Alle X.509-Zertifikate einer Abteilung auflisten
		"list_dep" => "admin_x509_list.html",
		// Komplett alle X.509-Zertifikate auflisten
		"list_all" => "admin_x509_list_all.html"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Benutzerdaten und dessen Rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Parameter auswerten
	$dep = ( $_REQUEST["dep"] > 0 ? $_REQUEST["dep"] :
		( $_SESSION["x509_list_dep"] > 0 ? $_SESSION["x509_list_dep"] : 0 ) );
	// Weiter mit den Tabellenparametern
	$page = ( $_REQUEST["page"] > 0 ? $_REQUEST["page"] :
		( $_SESSION["x509_list_page"] > 0 ? $_SESSION["x509_list_page"] : 1 ) );
	$orderby = ( $_REQUEST["orderby"] > 0 ? $_REQUEST["orderby"] :
		( $_SESSION["x509_list_orderby"] > 0 ? $_SESSION["x509_list_orderby"] :
		0 ) );
	$order = ( $_REQUEST["order"] != "" ? $_REQUEST["order"] :
		( $_SESSION["x509_list_order"] != "" ? $_SESSION["x509_list_order"] :
		"asc" ) );
	if( $order != "asc" && $order != "desc" ) $order = "asc";
	// Parameter in die Session speichern
	$_SESSION["x509_list_dep"] = $dep;
	$_SESSION["x509_list_page"] = $page;
	$_SESSION["x509_list_orderby"] = $orderby;
	$_SESSION["x509_list_order"] = $order;

	// Navigation vorbereiten und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	/*
	Anzeige der Liste von X.509-Zertifikate in zwei Fällen möglich :
	1. 	dep = 0, dann Auflistung aller Zertifikate
	2. 	dep > 0 und Benutzer ist root-Admin, Abteilungsleiter oder Registrar
			der Abteilung, dann alle X.509-Zertifikate der Abteilung auflisten,
			sofern sie nicht gelöscht ist
	*/
	// Fallunterscheidung
	if( $dep == 0 )
		$case = 1;		// Fall 1
	elseif( $dep > 0 && ( $rights->isRoot() || $rights->isAdmin( $dep ) ||
		$rights->isRegistrar( $dep ) ) )
		$case = 2;
	else $case = 0;	// Fall 2

	// Abteilungsdaten laden, sofern nötig
	if( $case == 2 ) {
		$departement = new pDepartement( $db, (int) $dep );
		// Testen, ob Abteilung schon gelöscht wurde
		if( !$departement->isDeleted() ) {
			$template->assign( "{DEP_ID}", $dep );
			$template->assign( "{DEP_NAME}", $departement->getName() );
		} else $case = 0;
	}

	// Anzeige der Liste, sofern Recht besteht
	if( $case > 0 ) {

		// Zurück-Button
		$nav->add( NAV_BACK, ( $case == 1 ? "index.php" :
			"dep_index.php?dep=$dep" ), "/left-blue.gif" );
		// Maximalanzahl an anzeigbaren X.509-Zertifikaten ermitteln
		$query = sprintf( "SELECT COUNT(x.X509Cert_ID) FROM %s x JOIN %s y ".
			"ON x.Departement_ID=y.ID",
			DB_CERTS_TABLE, DB_DEPS_TABLE );
		// wenn für eine Abteilung angefordert, dann Suche einschränken
		if( $case == 2 )
			$query .= sprintf( " WHERE y.ID=%u AND y.deleted=0;", $dep );
		$db->query( $query );
		$maxcount = $db->fetchRow( 0 );
		$maxpage = floor( $maxcount / LIST_CERTS );
		if( $maxcount % LIST_CERTS <> 0 ) $maxpage++;

		// Tabelle mit den anzeigbaren X.509-Zertifikaten generieren
		$table = new pTable( ( $case == 1 ? X509_LIST_TBL_SHOW_ALL :
			X509_LIST_TBL_SHOW.$departement->getName() ), $page, $maxpage );
		$table->addColumn( X509_LIST_TBL_CERTNAME, "60%", true, false );
		$table->addColumn( TBL_CREATED, "20%", true, true );
		$table->addColumn( X509_LIST_TBL_VALIDTO, "20%", true, true );
		$table->setSort( $orderby, $order );

		// Query für die anzeigbare Zertifikate zusammenbauen
		$query = sprintf( "SELECT x.X509Cert_ID, y.commonName, UNIX_TIMESTAMP( ".
			"y.created ), UNIX_TIMESTAMP( y.valid_to ), DATEDIFF( CURDATE(), ".
			"y.valid_to ) FROM %s x JOIN %s y ON x.X509Cert_ID=y.ID JOIN %s z ON ".
			"x.Departement_ID=z.ID",
			DB_CERTS_TABLE, DB_X509_TABLE, DB_DEPS_TABLE );
			// wenn für eine Abteilung angefordert, dann Suche einschränken
		if( $case == 2 )
			$query .= sprintf( " WHERE z.ID=%u AND z.deleted=0", $dep );
		// Sortierung und angezeigte Seite einfügen
		switch( $orderby ) {
			case 1  :
				$query .= " ORDER BY y.created $order, y.commonName ASC"; break;
			case 2  :
				$query .= " ORDER BY y.valid_to $order, y.commonName ASC"; break;
			default :
				$query .= " ORDER BY y.commonName $order, y.valid_to DESC"; break;
		}
		// anzuzeigende Seite in den Query einfügen
		$query .= sprintf( " LIMIT %u,%u;", ($page-1)*LIST_CERTS, LIST_CERTS );
		// Zertifikate aus der Datenbank lesen
		$db->query( $query );
		// Zertifikate in die Tabelle einparsen
		while( $data = $db->fetchRow() ) {
			list( $ID, $commonname, $created, $valid_to, $daysleft ) = $data;
			// Farben nach dem Ablaufdatum
			if( $daysleft >= -60 && $daysleft < 0 )	// Noch 60 Tage bis Ablauf
				$valid_to = "<span class=\"hinweis\">".strftime( DATEFORMAT,
				$valid_to )."</span>";
			elseif( $daysleft >= 0 )								// Zertifikat abgelaufen
				$valid_to = "<span class=\"fehler\">".strftime( DATEFORMAT,
					$valid_to )."</span>";
			else $valid_to = strftime( DATEFORMAT, $valid_to );
			// Zeile in die Tabelle einfügen
			$table->addRow( array(
				sprintf( "<a href=\"x509_view.php?key=%u\">%s</a>", $ID, $commonname ),
				strftime( DATEFORMAT, $created ), $valid_to ) );
		}
		// Tabelle einparsen und gesamte Seite parsen
		$template->assign( "{X509_TABLE}", $table->parse() );
		$template->parse( "{MAIN}", ( $case == 1 ? "list_all" : "list_dep" ) );
	} else $template->parse( "{MAIN}", "noaccess" );


	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>