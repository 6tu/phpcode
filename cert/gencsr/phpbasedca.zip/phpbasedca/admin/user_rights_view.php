<?php
	/*
	Zeigt die Rechte eines Benutzers an
	Parameter :
	1.	id : Benutzer-ID, dessen Rechte angezeigt werden sollen
	2.	backref : Rücksprungaddresse für den Zurück-Button ( aus der Session )
	*/
	session_start();

	require_once( "../lib/navigation.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/_config.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "no_access.html",
		// komplette Seite mit Tabellen-Grundgerüst
		"main" => "admin_user_rights_view.html",
		// Abteilungsübergreifende Rechte ( einzelne Tabellenzeile )
		"root" => "admin_user_rights_view_root.html",
		"normal" => "admin_user_rights_view_normal.html",
		// Abteilungsspezifische Rechte ( einzelne Tabellenzeile )
		// ohne Benachrichtung für die Abteilung
		"admin" => "admin_user_rights_view_adm1.html",
		"registrar" => "admin_user_rights_view_reg1.html",
		// Abteilungsspezifische Rechte mit ( einzelne Tabellenzeile )
		// mit Benachrichtigung für die Abteilung
		"admin_notify" => "admin_user_rights_view_adm2.html",
		"registrar_notify" => "admin_user_rights_view_reg2.html"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Benutzerdaten und dessen Rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Parameter auswerten
	$id = $_REQUEST["id"];

	// Navigation vorbereiten und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	/*
	Die Zugriffsrechte eines Benutzers werden nur in drei Fällen angezeigt :
		1.	dem Benutzer selber
		2.	dem Abteilungsleiter der Abteilung, in der Benutzer Mitglied ist
		3.	einem root-Admin
	*/
	if( $id > 0 ) {
		// Zugriffsrechte des anzuzeigenden Benutzers
		if( $id == $user->getID() ) $profilerights = $rights;
			else $profilerights = new pRights( $db, (int) $id );
		// Rechte prüfen, die Rechte des anzuzeigenden Benutzers anzuzeigen
		if( $id == $user->getID() )	// Fall 1
			$case = 1;
		elseif( count( array_intersect( $rights->getAdminDepartements(),
			$profilerights->getRegistrarDepartements() ) ) > 0 )	// Fall 2
			$case = 2;
		elseif( $rights->isRoot() )	// Fall 3
			$case = 3;
		else $case = 0;

		// Anzeige der Zugriffsrechte, sofern ein Recht dazu besteht
		if( $case > 0 ) {
			// Navigation erweitern
			$nav->add( NAV_BACK, $_SESSION["backref"], "/left-blue.gif" );
			// Benutzerdaten des anzuzeigenden Benutzers ermitteln
			$profile = new pUser( $db, (int) $id, "" );
			$template->assign( "{USR_SURNAME}", $profile->getSurname() );
			$template->assign( "{USR_LASTNAME}", $profile->getLastname() );
			unset( $profile );
			// Abteilungsübergreifende Rechte anzeigen
			$template->parse( "{RIGHTS_TABLE}", ( $profilerights->isRoot() ?
				".root" : ".normal" ) );
			// Query vorbereiten, um die Rechte an den Abteilungen anzuzeigen
			if( $profilerights->isRoot() )
				$query = sprintf( "SELECT x.name FROM %s x", DB_DEPS_TABLE );
			else
			$query = sprintf( "SELECT x.name,y.registrar,y.notify FROM %s x JOIN ".
					"%s y ON x.ID=y.Departement_ID JOIN %s z ON y.Auth_ID=z.Auth_ID ".
					"AND z.ID=%u",
					DB_DEPS_TABLE, DB_RIGHTS_TABLE, DB_USER_TABLE, $id );
			// Gelöschte Abteilungen ausklammern, sie existieren nur fürs Logbuch
			$query .= " WHERE x.deleted=0 ORDER BY x.name;";
			// Query auführen, um die Abteilungsrechte des Benutzers anzuzeigen
			$db->query( $query );
			while( $data = $db->fetchRow() ) {
			/*
			Hier könnte eine Abfrage der Benutzerrechte des aktiven Benutzers
			geschehen, ob er überhaupt die Rechte für die jeweilige Abteilung hat.
			Per SQL-Query wäre das zu schwer.
			*/
				list( $dep_name, $registrar, $notify ) = $data;
				$template->assign( "{DEP_NAME}", $dep_name );
				$template->parse( "{RIGHTS_TABLE}", ( $registrar == 0 ? ".admin" :
					".registrar" ).( !$profilerights->isRoot() && $notify == 1 ?
					"_notify" : "" ) );
			}
			// Ausgabe
			$template->parse( "{MAIN}", "main" );
		}
	}
	// Wenn bis hierher keine Ausgabe, dann Fehler
	if( !$template->get_assigned( "{MAIN}" ) )
	$template->parse( "{MAIN}", "noaccess" );

	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>