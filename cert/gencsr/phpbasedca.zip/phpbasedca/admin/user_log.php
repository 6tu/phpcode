<?php
	/*
	Anzeige des Logbuches für einen Benutzer
	Parameter :
	1. id : ID des Benutzers, dessen Logbuch eingesehen werden soll
	2. facility : Einschränkung auf bestimmte Aspekte der Verwaltung
	3. ( diverse Parameter aus der Tabellenauflistung )
  
	Dieses Skript zeigt das Logbuch für einen bestimmte Benutzer an und kann
	auf nur aus der Startseite des Benutzerkontos aufgerufen werden. Einsicht
	haben root-Admins, der Benutzer selber und dessen Abteilungsleiter.
	*/
  
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_config.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/navigation.php" );
	require_once( "../lib/table.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );
  
	// Template initialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "noaccess.html",
		// Hauptseite des Logbuches
		"main" => "admin_user_log.html",
		// mögliche Einträge im Logbuch
		"ca_modify" => "log_ca_modify.html",
		"departement_create" => "log_dep_create.html",
		"departement_modify" => "log_dep_modify.html",
		"departement_delete" => "log_dep_delete.html",
		"departement_grant" => "log_dep_notify.html",
		"user_create" => "log_user_create.html", 
		"user_modify" => "log_user_modify.html",
		"user_delete" => "log_user_delete.html",
		"user_grant_root" => "log_user_grant_root.html",
		"user_grant_admin" => "log_user_grant_admin.html",
		"user_grant_registrar" => "log_user_grant_registrar.html",
		"user_revoke_root" => "log_user_grant_root.html",
		"user_revoke_admin" => "log_user_grant_admin.html",
		"user_revoke_registrar" => "log_user_grant_registrar.html",
		"cert_create" => "log_cert_create.html",
		"cert_delete" => "log_cert_delete.html",
		"cert_grant" => "log_cert_grant.html",
		"cert_revoke" => "log_cert_revoke.html",
		"cert_renew" => "log_cert_renew.html"
	) );
  
	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );
  
	// Benutzerdaten und -rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );
  
	// Parameter auswerten
	$id = $_REQUEST["id"];
	$facility = $_REQUEST["facility"];
	$page = ( $_REQUEST["page"] > 0 ? $_REQUEST["page"] : 1 );
	$order = $_REQUEST["order"];
	if( ($order != "asc") && ($order != "desc") ) $order = "desc";
	$orderby = $_REQUEST["orderby"];
  
	// Navigation initialisieren und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );
  
	// Benutzerkonto des anzuzeigenden Benutzers laden
	$profile = new pUser( $db, (int) $id, "" );
	// Dessen Rechte laden
	$profilerights = new pRights( $db, $profile );
  
	// root-Admins, der Benutzer selber und dessen Abteilungsleiter dürfen in
	// das Logbuch des Benutzers einsehen
	if( $rights->isRoot() || $profile->getID() == $user->getID() ||
		count( array_intersect( $rights->getAdminDepartements(),
		$profilerights->getRegistrarDepartements() ) ) > 0 ) {
		// Benutzerdaten einparsen
		$template->assign( "{USR_SURNAME}", $profile->getSurname() );
		$template->assign( "{USR_LASTNAME}", $profile->getLastname() );
		// Zurück-Button
		$nav->add( NAV_BACK, "user_index.php?id=$id", "/left-blue.gif" );
		// Navigation erweitern
		$nav->addSeparator();
		$nav->add( NAV_LOG_SHOW_ALL, "user_log.php?id=$id",
			"/search-icon-blue.gif" );
		$nav->add( NAV_LOG_SHOW_CA, "user_log.php?id=$id&facility=ca",
			"/home-page-orange.gif" );
		$nav->add( NAV_LOG_SHOW_DEP, "user_log.php?id=$id&facility=dep",
			"/sitemap-blue.gif" );
		$nav->add( NAV_LOG_SHOW_USER, "user_log.php?id=$id&facility=user",
			"/user-group2.gif" );
		$nav->add( NAV_LOG_SHOW_CERT, "user_log.php?id=$id&facility=cert",
			"/edit-blue.gif" );

		// Maximalanzahl an anzeigbaren Seiten ermitteln ( abhängig von $facility )
		$query = sprintf( "SELECT COUNT(*) FROM %s", DB_LOG_TABLE );
		switch( $facility ) {
			case "ca" :
				$query .= sprintf( " WHERE facility='ca' AND User_ID=%u;", id ); break;
			case "dep" :
				$query .= sprintf( " WHERE facility='departement' AND ( User_ID=%u ".
				"OR ref_User_ID=%1\$u );", $id ); break;
			case "user" :
				$query .= sprintf( " WHERE facility='user' AND ( User_ID=%u OR ".
					"ref_User_ID=%1\$u );", $id ); break;
			case "cert" :
				$query .= sprintf( " WHERE facility='cert' AND ( User_ID=%u OR ".
					"ref_User_ID=%1\$u );", $id ); break;
			default :
				$query .= sprintf( " WHERE User_ID=%u OR ref_User_ID=%1\$u;", $id );
			break;
		}
		$db->query( $query );
		$maxcount = $db->fetchRow( 0 );
		$maxpage = floor( $maxcount / LIST_LOG );
		if( $maxcount % LIST_LOG <> 0 ) $maxpage++;
		unset( $maxcount );
	
		// Tabelle je nach $facility initialisieren
		switch( $facility ) {
			case "ca"   : $tabletitle = LOG_TBL_SHOW_CA; break;
			case "dep"  : $tabletitle = LOG_TBL_SHOW_DEP; break;
			case "user" : $tabletitle = LOG_TBL_SHOW_USER; break;
			case "cert" : $tabletitle = LOG_TBL_SHOW_CERT; break;
			default     : $tabletitle = LOG_TBL_SHOW_ALL; break;
		}
		$table = new pTable( $tabletitle, $page, $maxpage );
		// Spalten je nach $facility in die Tabelle einfügen
		$table->addColumn( LOG_TBL_OCCURED, "20%", true, true );
		$table->addColumn( LOG_TBL_EVENT, "80%", false, false );
		$table->setSort( $orderby, $order );
	
		// Logbuch abhängig von $facility, $order und $orderby durchsuchen
		$query = sprintf( "SELECT UNIX_TIMESTAMP( a.occured ), a.facility, ".
			"a.action, a.additional, b.ID, b.surname, b.lastname, c.ID, c.name, ".
			"d.ID, d.surname, d.lastname, e.ID, e.commonName, f.ID, f.commonName ".
			"FROM %s a JOIN %s b ON a.User_ID=b.ID LEFT JOIN %s c ON ".
			"a.ref_Departement_ID=c.ID LEFT JOIN %2\$s d ON a.ref_User_ID=d.ID ".
			"LEFT JOIN %s e ON a.ref_CSR_ID=e.ID LEFT JOIN %s f ON ".
			"a.ref_X509Cert_ID=f.ID",
			DB_LOG_TABLE, DB_USER_TABLE, DB_DEPS_TABLE, DB_CSR_TABLE,
			DB_X509_TABLE );
		/*
		Der obige Query sieht schlimmer aus, als er ist. Vom Prinzip her werden
		alle ref_*-Felder mit einem LEFT JOIN verbunden und die nötigsten Angaben
		herausgezogen.
		*/
		// Einschränkungen einsetzen
		switch( $facility ) {
			case "ca" :
				$query .= sprintf( " WHERE a.facility='ca' AND a.User_ID=%u",
					id ); break;
			case "dep" :
				$query .= sprintf( " WHERE a.facility='departement' AND ( a.User_ID=".
					"%u OR a.ref_User_ID=%1\$u )", $id ); break;
			case "user" :
				$query .= sprintf( " WHERE a.facility='user' AND ( a.User_ID=%u OR ".
					"a.ref_User_ID=%1\$u )", $id ); break;
			case "cert" :
				$query .= sprintf( " WHERE a.facility='cert' AND ( a.User_ID=%u OR ".
				"a.ref_User_ID=%1\$u )", $id ); break;
			default :
				$query .= sprintf( " WHERE a.User_ID=%u OR a.ref_User_ID=%1\$u", $id );
			break;
		}
		// Sortierung einfügen
		$query .= " ORDER BY a.occured $order";
		// Anzuzeigende Seite
		$query .= sprintf( " LIMIT %u,%u;", ($page-1)*LIST_LOG, LIST_LOG );
		// Query ausführen
		$db->query( $query );
	
		// Daten in die Tabelle einsetzen
		while( $data = $db->fetchRow() ) {
			// Schritt 1 : Variablenwerte prüfen
			foreach( $data as $key => $value )
				if( empty( $value ) ) $data[$key] = TXT_UNKNOWN;
			// Schritt 2 : Logbuchdaten einparsen
			$template->assign( "{LOG_OCCURED}", strftime( TIMEFORMAT, $data[0] ) );
			$template->assign( "{LOG_FACILITY}", $data[1] );
			$template->assign( "{LOG_ACTION}", $data[2] );
			$template->assign( "{LOG_ADDITIONAL}", $data[3] );
			$template->assign( "{LOG_USR_ID}", $data[4] );
			$template->assign( "{LOG_USR_SURNAME}", $data[5] );
			$template->assign( "{LOG_USR_LASTNAME}", $data[6] );
			$template->assign( "{REF_DEP_ID}", $data[7] );
			$template->assign( "{REF_DEP_NAME}", $data[8] );
			$template->assign( "{REF_USR_ID}", $data[9] );
			$template->assign( "{REF_USR_SURNAME}", $data[10] );
			$template->assign( "{REF_USR_LASTNAME}", $data[11] );
			$template->assign( "{REF_CSR_ID}", $data[12] );
			$template->assign( "{REF_CSR_COMMONNAME}", $data[13] );
			$template->assign( "{REF_X509_ID}", $data[14] );
			$template->assign( "{REF_X509_COMMONNAME}", $data[15] );
			// Schritt 3 : Logbucheintrag generieren
			$log_template = sprintf( "%s_%s", $data[1], $data[2] );
			if( $data[1] == "user" && ( $data[2] == "grant" ||
				$data[2] == "revoke" ) )
				$log_template .= sprintf( "_%s", $data[3] );
			$template->parse( "{ENTRY}", $log_template );
			if( !$template->get_assigned( "{ENTRY}" ) )
				$template->assign( "{ENTRY}", TXT_UNKNOWN );
			// Schritt 3 : Tabellenzeile einfügen
			$table->addRow( array( strftime( TIMEFORMAT, $data[0] ),
				$template->get_assigned( "{ENTRY}" ) ) );
		}

		// Tabelle verarbeiten und einparsen
		$template->assign( "{LOG_TABLE}", $table->parse() );
		// Fertig
		$template->parse( "{MAIN}", "main" );
	} else $template->parse( "{MAIN}", "noaccess" );

	// Ausgabe
	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>