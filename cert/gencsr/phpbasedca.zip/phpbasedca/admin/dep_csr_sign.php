<?php
	/*
	Signiert oder lehnt eine CSR ab ( für eine bestimmte Abteilung )
	Parameter :
	1.	id : ID der CSR, die signiert oder abgelehnt werden soll

	Hinweis : Signieren bedeutet, dass aus der CSR ein X.509-Zertifikat generiert
	wird. Eine Ablehnung bedeutet, dass die CSR mit einer Begründung gelöscht
	wird.
	*/

	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_config.php" );
	require_once( "../lib/navigation.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/csr.php" );
	require_once( "../lib/ca.php" );
	require_once( "../lib/departement.php" );
	require_once( "../lib/log.php" );
	require_once( "../lib/mail.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "no_access.html",
		// Formular zum Signieren oder Ablehnen der CSR
		"form" => "admin_dep_csr_sign.html",
		// Okay-Meldung bei Signierung der CSR
		"signed" => "admin_dep_csr_sign_signed.html",
		// Meldung bei Abweisung der CSR
		"rejected" => "admin_dep_csr_sign_rejected.html",
		// eMail-Nachricht bei Signierung der CSR
		"email_signed" => "email_csr_signed.txt",
		// eMail-Nachricht bei Abweisung der CSR
		"email_rejected" => "email_csr_rejected.txt"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Parameter auswerten
	$id = $_REQUEST["id"];

	// Benutzerdaten und Rechte aus der Datenbank lesen
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Navigation vorbereiten und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	// Seite anzeigen, wenn die Schlüssel-ID der CSR ok ist
	if( $id > 0 ) {

		// CSR-Daten laden und einparsen
		$csr =  new pCSR_DB( $db, (int) $id );
		$template->assign( "{CSR_ID}", $id );
		$template->assign( "{CSR_COUNTRYNAME}", $csr->getCountryName() );
		$template->assign( "{CSR_STATEORPROVINCENAME}",
			$csr->getStateOrProvinceName() );
		$template->assign( "{CSR_LOCALITYNAME}", $csr->getLocalityName() );
		$template->assign( "{CSR_ORGANIZATION}", $csr->getOrganizationName() );
		$template->assign( "{CSR_ORGANIZATIONALUNITNAME}",
			$csr->getOrganizationalUnitName() );
		$template->assign( "{CSR_COMMONNAME}", $csr->getCommonName() );
		$template->assign( "{CSR_EMAIL}", $csr->getEMailAddress() );
		$template->assign( "{CSR_CREATED}", strftime( TIMEFORMAT,
			$csr->getCreated() ) );

		// Abteilung der wartenden CSR aus der Datenbank ermitteln
		$query = sprintf( "SELECT Departement_ID FROM %s WHERE CSR_ID=%u;",
			DB_CSRS_TABLE, $id );
		$db->query( $query );
		list( $dep_id ) = $db->fetchRow();

		if( $dep_id > 0 ) {
			// Daten der Abteilung aus der Datenbank lesen und einparsen
			$departement = new pDepartement( $db, (int) $dep_id );
			$template->assign( "{DEP_NAME}", $departement->getName() );
			$template->assign( "{DEP_ID}", $dep_id );

			// Wenn keine Daten gePOSTet wurden, Anzeige des Formulars
			if( count( $_POST ) == 0 ) {
				// Zurück-Button einsetzen
				$nav->add( NAV_BACK, "dep_csr_list.php?dep=$dep_id",
					"/left-blue.gif" );
				// Formular anzeigen
				$template->parse( "{MAIN}", "form" );
			} else {
				// CA-Daten laden
				$ca = new pCA_DB( $db );
				$template->assign( "{CA_NAME}", $ca->getName() );
				// CSR abgelehnt oder soll signiert werden ?
				if( $_POST["decision"] == "sign" ) {
					// CSR ist akzeptiert worden
					$db->beginTransaction();
					try {
						// CSR wird durch die CA signiert
						$x509 = $ca->sign( $csr, (int) $_POST["days"] );
						// X.509-Zertifikat in die Datenbank speichern lassen
						$x509_db = new pX509Cert_DB( $x509->export() );
						$x509_db->saveToDB( $db );
						// das neue X.509-Zertifikat vermerken
						$departement->unregisterCSR( $db, $csr );
						$departement->registerX509Cert( $db, $csr, $x509_db, $user );
						// neue Seriennummer der CA speichern lassen
						$ca->saveToDB( $db );
						// Logbuch-Eintragungen
						$log = new pLog( $db );
						$log->logSignCSR( $user, $csr, $departement, $x509_db,
						$x509_db->getSerial() );
						// eMail versenden ( mit Zertifikat als Anhang )
						$mail = new pMail();
						$mail->setFrom( sprintf( "%s %s <%s>", $user->getSurname(),
							$user->getLastName(), $user->getEMail() ) );
						$mail->addRecipient( "", $csr->getEMailAddress() );
						$mail->setSubject( CSR_SIGN_EMAIL_SUBJECT );
						$template->assign( "{X509_SERIAL}", $x509_db->getSerial() );
						$template->parse( "{EMAIL_MESSAGE}", "email_signed" );
						$mail->setMessage( $template->get_assigned( "{EMAIL_MESSAGE}" ) );
						$mail->addFile( "x509_cert.pem", "application/x-x509-user-cert",
							$x509_db->export() );
						$mail->addFile( "x509_cert.crt", "application/x-x509-user-cert",
							$x509_db->export( true ) );
						$mail->addFile( "x509_cert.der", "application/x-x509-user-cert",
							$x509_db->export() );
						$mail->send();
						// Transaktion abschliessen
						$db->endTransaction();			// COMMIT
						// Okay-Meldung geben
						$template->parse( "{MAIN}", "signed" );
					} catch( Exception $e ) {
						$db->endTransaction( true );	// ROLLBACK
						throw $e;
					}
				} elseif( $_POST["decision"] == "reject" ) {
					// CSR ist abgelehnt worden, daher CSR abmelden
					$departement->unregisterCSR( $db, $csr );
					// Logbuch-Eintrag
					$log = new pLog( $db );
					$log->logDenyCSR( $user, $csr, $departement, $_POST["reason"] );
					// eMail versenden
					$mail = new pMail();
					$mail->setFrom( sprintf( "%s %s <%s>", $user->getSurname(),
						$user->getLastName(), $user->getEMail() ) );
					$mail->addRecipient( "", $csr->getEMailAddress() );
					$mail->setSubject( CSR_SIGN_EMAIL_SUBJECT );
					$template->assign( "{REASON}", $_POST["reason"] );
					$template->parse( "{EMAIL_MESSAGE}", "email_rejected" );
					$mail->setMessage( $template->get_assigned( "{EMAIL_MESSAGE}" ) );
					$mail->send();
					// Meldung geben
					$template->parse( "{MAIN}", "rejected" );
				}
			}
		}
	}
	// ansonsten Fehlermeldung
	if( !$template->get_assigned( "{MAIN}" ) )
	$template->parse( "{MAIN}", "noaccess" );

	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>