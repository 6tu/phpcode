<?php
	/*
	Änderung der Daten einer Abteilung
	Parameter :
	1.	dep : ID der Abteilung, die geändert werden soll
	*/

	require_once( "../lib/navigation.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/departement.php" );
	require_once( "../lib/log.php" );
	require_once( "../lib/_config.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "no_access.html",
		// Formular zur Eingabe der Abteilungsdaten
		"form" => "admin_dep_edit.html",
		// Vorschau der Abteilungsdaten
		"preview" => "admin_dep_edit_preview.html",
		// Okay-Meldung bei Speicherung
		"saved" => "admin_dep_edit_ok.html"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Benutzerdaten und dessen Rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Parameter auswerten
	$dep = $_REQUEST["dep"];

	// Navigation initialisieren und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	// Abteilung laden
	$departement = new pDepartement( $db, (int) $dep );

	// Änderung an den Abteilungsdaten dürfen nur Benutzer mit root- oder
	// Abteilungsrechten, sofern Abteilung nicht gelöscht
	if( !$departement->isDeleted() && ( $rights->isRoot() ||
		$rights->isAdmin( $dep ) ) ) {
		// Abteilungsdaten in das Template einparsen
		$template->assign( "{DEP_ID}", $dep );
		$template->assign( "{DEP_NAME}", $departement->getName() );
		$template->assign( "{DEP_DESC}", $departement->getDescription() );

		/*
		Hinweis : wenn Daten gePOSTet wurden, gibt es drei Möglichkeiten
		1. Speicherung der Daten in der DB ( $_POST["save"] <> "" )
		2. Vorschau der Daten ( $_POST["preview"] <> "" )
		3. Zurück von der Vorschau ins Formular ( $_POST["back"] <> "" )
		*/

		// Vorschau gewünscht ? Dann Vorschau der Daten
		if( (count( $_POST ) > 0) && (!empty( $_POST["preview"] )) ) {
			// Name der Abteilung
			if( !empty( $_POST["dep_name"] ) )
				$template->assign( "{DEP_NAME}", $_POST["dep_name"] );
			// Beschreibung der Abteilung ( BBCOde )
			if( !empty( $_POST["dep_desc"] ) )
				$template->assign( "{DEP_DESC}", $_POST["dep_desc"] );
			// Beschreibung der Abteilung ( BBCode geparset )
			require_once( "../lib/bbcodeparser.php" );
			$parser = new pBBParser( $_POST["dep_desc"] );
			$template->assign( "{DEP_PARSED_DESC}", $parser->parse() );
			// Vorschau anzeigen
			$template->parse( "{MAIN}", "preview" );
		}

		// Zurück aus der Vorschau ? Dann Daten der Abteilung neu setzen
		elseif( (count( $_POST ) > 0) && (!empty( $_POST["back"] )) ) {
			// Name der Abteilung
			if( !empty( $_POST["dep_name"] ) )
				$template->assign( "{DEP_NAME}", $_POST["dep_name"] );
			// Beschreibung der Abteilung ( BBCOde )
			if( !empty( $_POST["dep_desc"] ) )
				$template->assign( "{DEP_DESC}", $_POST["dep_desc"] );
		}

		// Daten aus dem Formular, dann Speicherung in die DB
		elseif( (count( $_POST ) > 0) && (!empty( $_POST["save"] )) ) {
			// Neuen Namen setzen
			if( !empty( $_POST["dep_name"] ) )
				$departement->setName( $_POST["dep_name"] );
			// Beschreibung setzen
			$departement->setDescription( $_POST["dep_desc"] );
			// Abteilung speichern lassen
			$departement->saveToDB( $db );
			// Logbucheintrag speichern
			$log = new pLog( $db );
			$log->logModifyDepartement( $user, $departement );
			// Fertig
			$template->parse( "{MAIN}", "saved" );
		}

		// Ansonsten Formular anzeigen
		if( !$template->get_assigned( "{MAIN}" ) ) {
			// Zurück-Button
			$nav->add( NAV_BACK, "dep_index.php?dep=$dep", "/left-blue.gif" );
			// Nur root-Admins dürfen den Abteilungsnamen ändern
			$template->assign( "{USR_ROOT}", ( !$rights->isRoot() ? " disabled" :
				"" ) );
			// Formular anzeigen
			$template->parse( "{MAIN}", "form" );
		}
	}
	// ansonsten Fehlermeldung
	else $template->parse( "{MAIN}", "noaccess" );

	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>