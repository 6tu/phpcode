<?php
	/*
	Lädt den privaten Schlüssel der CA herunter
	Parameter :
	1.	format = "pem" : PEM-kodierte Ausgabe ( Standardeinstellung )
			format = "txt" : einfache Text-Ausgabe
	*/

	// Parameter auswerten
	$format = $_REQUEST["format"];

	switch( $format ) {
		case "txt" :
			header( "Content-Type: text/plain" );
			header( "Content-Disposition: attachment; filename=privkey.txt" );
			break;
		default :
			header( "Content-Type: text/plain" );
			header( "Content-Disposition: attachment; filename=privkey.pem" );
			break;
	}

	require_once( "../lib/database.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/ca.php" );
	require_once( "../lib/privatekey.php" );
	require_once( "../lib/_config.php" );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Benutzerdaten und dessen Rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Nur root-Admins dürfen den Schlüssel herunterladen
	if( $rights->isRoot() ) {
		// CA und dessen privaten Schlüssel laden
		$ca = new pCA_DB( $db );
		$pkey = $ca->getPrivkey();
		print $pkey->export();
	} else print "Sorry, no access.";

?>