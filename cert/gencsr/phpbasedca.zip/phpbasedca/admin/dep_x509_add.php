<?php
	/*
	Erstellt eine CSR für eine Abteilung und signiert sie durch die CA
	Parameter :
	1.	dep : ID der Abteilung, in der ein X.509-Zertifikat erzeugt werden soll
	*/
	session_start();

	require_once( "../lib/navigation.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/privatekey.php" );
	require_once( "../lib/csr.php" );
	require_once( "../lib/certdata.php" );
	require_once( "../lib/log.php" );
	require_once( "../lib/ca.php" );
	require_once( "../lib/departement.php" );
	require_once( "../lib/x509.php" );
	require_once( "../lib/_config.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "no_access.html",
		// Formular zum Generieren eines X.509-Zertifikates
		"form" => "admin_dep_x509_add.html",
		// X.509-Zertifikat erfolgreich generiert
		"download" => "admin_dep_x509_add_ok.html"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Benutzerdaten und dessen Rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Parameter laden
	$dep = $_REQUEST["dep"];

	// Navigation vorbereiten und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	// Abteilungsdaten laden und in das Template einparsen
	try {
		$departement = new pDepartement( $db, (int) $dep );
		// Testen, ob Abteilung als gelöscht markiert wurde
		if( !$departement->isDeleted() ) {
			$template->assign( "{DEP_ID}", $dep );
			$template->assign( "{DEP_NAME}", $departement->getName() );
		} else $dep = -1;
	} catch( Exception $e ) {
		$dep = -1;
	}

	// root-Admins, Abteilungsleiter und Registrare der Abteilung können neue
	// X.509-Zertifikate erstellen, sofern Abteilung nicht gelöscht
	if( $dep > 0 && ( $rights->isRoot() || $rights->isAdmin( $dep ) ||
		$rights->isRegistrar( $dep ) ) ) {

		// wenn keine Daten gePOSTet, dann Formular anzeigen
		if( count( $_POST ) == 0 ) {
			// Daten der CA laden, um Vorbelegungen im Formular vorzunehmen
			$ca = new pCA_DB( $db );
			$template->assign( "{X509_COUNTRYNAME}", $ca->getCountryName() );
			$template->assign( "{X509_STATEORPROVINCENAME}",
				$ca->getStateOrProvinceName() );
			$template->assign( "{X509_LOCALITYNAME}", $ca->getLocalityName() );
			$template->assign( "{X509_ORGANIZATIONNAME}",
				$ca->getOrganizationName() );
			$template->assign( "{X509_ORGANIZATIONALUNITNAME}",
			$departement->getName() );
			$template->assign( "{X509_COMMONNAME}", "" );
			$template->assign( "{X509_EMAIL}", "" );
		}
		// X.509-Zertifikat generieren
		else {
			$db->beginTransaction();
			try {
				// Privaten Schlüssel generieren und in die Session speichern
				$pkey = new pPrivateKey( (int) $_POST["keylength"] );
				$_SESSION["dep_x509_add_pkey"] = $pkey->export();
				// CSR generieren und in die Datenbank speichern
				$csrdata = new pCertData(
					$_POST["countryName"], $_POST["stateOrProvinceName"],
					$_POST["localityName"], $_POST["organizationName"],
					$_POST["organizationalUnitName"], $_POST["commonName"],
					$_POST["emailAddress"] );
				$csr = $pkey->generateCSR( $csrdata );
				// Workaround, um CSR in die Datenbank speichern zu können
				$csr_db = new pCSR_DB( $csr );
				$csr_db->saveToDB( $db );
				// Logbucheintrag für die CSR
				$log = new pLog( $db );
				$log->logCreateCSR( $user, $csr_db, $departement );
				// Signieren und Zertifikat in die DB speichern
				$ca = new pCA_DB( $db );
				$x509 = $ca->sign( $csr, (int) $_POST["days"] );
				$x509_db = new pX509Cert_DB( $x509->export() );
				$x509_db->saveToDB( $db );
				$template->assign( "{X509_ID}", $x509_db->getID() );
				// Zertifikat für die Abteilung vermerken
				$departement->registerX509Cert( $db, $csr_db, $x509_db, $user );
				// Logbucheintrag für das neue X.509-Zertifikat
				$log->logSignCSR( $user, $csr_db, $departement, $x509_db,
					$ca->getSerial() );
				// Seriennummer der CA speichern
				$ca->saveToDB( $db );
				// Fertig, Bestätigung ausgeben
				$db->endTransaction();			// COMMIT
				$template->parse( "{MAIN}", "download" );
			} catch( Exception $e ) {
				$db->endTransaction( true );	// ROLLBACK
				throw $e;
			}
		}
		// Wenn bis hier nichts eingeparset, dann Formular anzeigen
		if( !$template->get_assigned( "{MAIN}" ) ) {
			// Zurück-Button einfügen
			$nav->add( NAV_BACK, "dep_index.php?dep=$dep", "/left-blue.gif" );
			// Formular anzeigen
			$template->parse( "{MAIN}", "form" );
		}
	}
	if( !$template->get_assigned( "{MAIN}" ) )
	$template->parse( "{MAIN}", "noaccess" );

	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>