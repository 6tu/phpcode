<?php
	/*
	Bearbeitet die Daten der CA; Zugang nur für root-Admins
	Parameter : keine
	*/

	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_config.php" );
	require_once( "../lib/ca.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/log.php" );
	require_once( "../lib/navigation.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Templates initialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "no_access.html",
		// Eingabeformular für die CA_Daten
		"form" => "admin_ca_edit.html",
		// Okay-Meldung der Speicherung
		"saved" => "admin_ca_edit_ok.html",
		// Vorschau der CA-Daten
		"preview" => "admin_ca_edit_preview.html"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Navigation initialisieren und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	// Benutzerdaten und dessen Rechte lesen
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Bearbeitung der CA-Daten nur für root-Admins zulassen
	if( $rights->isRoot() ) {
		// Daten der CA laden und einparsen
		$ca = new pCA_DB( $db );
		$template->assign( "{CA_NAME}", $ca->getName() );
		$template->assign( "{CA_DESC}", $ca->getDescription() );

		/*
		Hinweis : Daten können auf drei Arten gePOSTet werden :
		1. aus dem Formular ( $_POST["save"] <> "" ) zum Speichern in die DB
		2. zur Vorschau der Daten ( $_POST["preview"] <> "" )
		3. aus der Vorschau zurück zum Formular ( $_POST["back"] <> "" )
		*/

		// Variante 1 : Speicherung in die Datenbank
		if( (count( $_POST ) > 0) && (!empty( $_POST["save"] )) ) {
			// Namen der CA neu setzen, wenn notwendig
			if( !empty( $_POST["ca_name"] ) && $_POST["ca_name"] <> $ca->getName() )
			$ca->setName( $_POST["ca_name"] );
			// Beschreibung der CA setzen
			$ca->setDescription( $_POST["ca_desc"] );
			// CA-Daten speichern und Logbucheintrag setzen
			$ca->saveToDB( $db );
			$log = new pLog( $db );
			$log->logModifyCA( $user );
			// Fertig, OK-Meldung geben
			$template->parse( "{MAIN}", "saved" );
		}
		// Variante 2 : Vorschau der Daten
		elseif( (count( $_POST ) > 0) && (!empty( $_POST["preview"] )) ) {
			// Namen der CA
			if( !empty( $_POST["ca_name"] ) )
				$template->assign( "{CA_NAME}", $_POST["ca_name"] );
			// geparsete Beschreibung der CA
			require( "../lib/bbcodeparser.php" );
			$parser = new pBBParser( ( !empty( $_POST["ca_desc"] ) ?
			$_POST["ca_desc"] : $ca->getDescription() ) );
			$template->assign( "{CA_PARSED_DESC}", $parser->parse() );
			// Beschreibung der CA in BBCode
			if( !empty( $_POST["ca_desc"] ) )
				$template->assign( "{CA_DESC}", $_POST["ca_desc"] );
			// Vorschau anzeigen
			$template->parse( "{MAIN}", "preview" );
		}
		// Variante 3 : Aus der Vorschau zurück
		elseif( (count( $_POST ) > 0) && (!empty( $_POST["back"] )) ) {
			// CA-Namen neu setzen
			if( !empty( $_POST["ca_name"] ) )
				$template->assign( "{CA_NAME}", $_POST["ca_name"] );
			// Beschreibung der CA in BBCode neu setzen
			if( !empty( $_POST["ca_desc"] ) )
				$template->assign( "{CA_DESC}", $_POST["ca_desc"] );
		}

		// ansonsten Anzeige des Eingabeformulars
		if( !$template->get_assigned( "{MAIN}" ) ) {
			// Zurück-Button einfügen
			$nav->add( NAV_BACK, "index.php", "/left-blue.gif" );
			$template->parse( "{MAIN}", "form" );
		}
	} else $template->parse( "{MAIN}", "noaccess" );

	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>