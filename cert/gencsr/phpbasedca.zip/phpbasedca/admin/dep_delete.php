<?php
	/*
	Löscht eine Abteilung ( nur für root-Admins )
	Parameter :
	1.	dep : ID der Abteilung, die geändert werden soll
	*/

	require_once( "../lib/navigation.php" );
	require_once( "../lib/database.php" );
	require_once( "../lib/_FastTemplate.php" );
	require_once( "../lib/user.php" );
	require_once( "../lib/rights.php" );
	require_once( "../lib/departement.php" );
	require_once( "../lib/log.php" );
	require_once( "../lib/_config.php" );
	// Sprachkonstanten laden
	require_once( "../language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "../templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		"noaccess" => "no_access.html",
		// Bestätigung zur Löschung der Abteilung
		"main" => "admin_dep_delete.html",
		// Okay-Meldung der Löschung
		"deleted" => "admin_dep_delete_ok.html"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Benutzerdaten und dessen Rechte laden
	$user = new pUser( $db, $_SERVER["PHP_AUTH_USER"], $_SERVER["PHP_AUTH_PW"] );
	$rights = new pRights( $db, $user );

	// Parameter auswerten
	$dep = $_REQUEST["dep"];

	// Navigation initialisieren und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	// Abteilung laden
	$departement = new pDepartement( $db, (int) $dep );

	// Eine Abteilung darf nur ein root-Admin löschen, sofern Abteilung noch
	// nicht gelöscht
	if( !$departement->isDeleted() && $rights->isRoot() ) {
		// Abteilungsdaten in das Template einparsen
		$template->assign( "{DEP_NAME}", $departement->getName() );
		$template->assign( "{DEP}", $dep );

		// Sind Daten gepostet worden ? Dann Abteilung löschen
		if( count( $_POST ) > 0 ) {
			$db->beginTransaction();
			try {
				// Schritt 1 : alle Benutzernamen/Passwort-Paare löschen
				$query = sprintf( "DELETE FROM %s USING %1\$s, %s WHERE %1\$x.ID=".
					"%2\$s.Auth_ID AND %2\$s.Departement_ID=%u;",
					DB_AUTH_TABLE, DB_RIGHTS_TABLE, $dep );
				$db->query( $query );
				// Schritt 2 : alle wartenden CSRs löschen
				$query = sprintf( "DELETE FROM %s WHERE Departement_ID=%u;",
					DB_CSRS_TABLE, $dep );
				$db->query( $query );
				// Schritt 3 : Abteilung als gelöscht markieren
				$departement->deleteFromDB( $db );
				$db->endTransaction();			// COMMIT
				// Logbucheintrag
				$log = new pLog( $db );
				$log->logDeleteDepartement( $user, $departement );
				// Fertig
				$template->parse( "{MAIN}", "deleted" );
			} catch( Exception $e ) {
				$db->endTransaction( true );	// ROLLBACK
				throw $e;
			}
		}
		// Ansonsten Formular anzeigen
		else {
			$nav->add( NAV_BACK, "dep_index.php?dep=$dep", "/left-blue.gif" );
			$template->parse( "{MAIN}", "main" );
		}
	}
	// ansonsten Fehlermeldung
	else $template->parse( "{MAIN}", "noaccess" );

	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>