<?php
	/*
	Erstellt eine CSR für eine Abteilung
	Parameter :
	1. dep : ID der Abteilung, in der eine CSR erzeugt werden soll (optional)
	*/
	session_start();

	require_once( "./lib/navigation.php" );
	require_once( "./lib/database.php" );
	require_once( "./lib/_FastTemplate.php" );
	require_once( "./lib/privatekey.php" );
	require_once( "./lib/csr.php" );
	require_once( "./lib/certdata.php" );
	require_once( "./lib/departement.php" );
	require_once( "./lib/ca.php" );
	require_once( "./lib/_config.php" );
	require_once( "./lib/mail.php" );
	// Sprachkonstanten laden
	require_once( "./language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "./templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		// Formular zur Eingabe der CSR-Daten und der Daten des privaten Schlüssel
		"form" => "csr_add.html",
		// Auswahlliste der Abteilungen
		"depselect" => "csr_add_depselect.html",
		// Download des privaten Schlüssels und Bestätigung
		"download" => "csr_add_ok.html",
		// Fehlermeldung, wenn keine Abteilungen in der Datenbank verzeichnet sind
		"no_deps" => "deps_not_found.html",
		// Fehlermeldung, wenn keine CA in der Datenbank verzeichnet ist
		"not_found" => "ca_not_found.html",
		// Benachrichtung an die Registrare
		"csr_notify" => "email_csr_notify.txt",
		// Bestätigungs-eMail
		"csr_add" => "email_csr_add.txt"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Parameter laden
	$dep = $_REQUEST["dep"];

	// Navigation vorbereiten und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	try {
		// CA aus der Datenbank lesen und Daten einparsen
		$ca = new pCA_DB( $db );
		$template->assign( "{CA_NAME}", $ca->getName() );
	} catch( Exception $e ) {
		$template->parse( "{MAIN}", "not_found" );
  }
	// Wenn keine Fehlermeldung vorliegt, weitermachen
	if( !$template->get_assigned( "{MAIN}" ) ) {
		// Sind Daten aus dem Formular gePOSTet worden ?
		if( count( $_POST ) > 0 ) {
			// Privaten Schlüssel generieren und in die Session exportieren
			$privkey = new pPrivateKey( (int) $_POST["keylength"] );
			$privkey->setPassword( $_POST["keypassword"] );
			$_SESSION["csr_add_pkey"] = $privkey->export();
			// Sonderzeichen und Umlaute filtern
			foreach( $_POST as $key => $data )
				$_POST[$key] = str_replace( array( "Ä","Ü","Ö","ä","ü","ö","ß" ),
					array( "Ae", "Ue", "Oe", "ae", "ue", "oe", "ss" ), $data );
			// CSR generieren
			$csrdata = new pCertData(
				$_POST["countryName"], $_POST["stateOrProvinceName"],
				$_POST["localityName"], $_POST["organizationName"],
				$_POST["organizationalUnitName"], $_POST["commonName"],
				$_POST["emailAddress"] );
			$csr = $privkey->generateCSR( $csrdata );
			$csr_db = new pCSR_DB( $csr );
			$csr_db->saveToDB( $db );
			// CSR in die Datenbank speichern und für die Abteilung vermerken
			$departement = new pDepartement( $db, (int) $_POST["dep"] );
			$departement->registerCSR( $db, $csr_db );
			// gemeinsam benutzte Templates-Variablen für die Mails setzen
			$template->assign( "{CSR_COUNTRYNAME}", $csr_db->getCountryName() );
			$template->assign( "{CSR_STATEORPROVINCENAME}",
				$csr_db->getStateOrProvinceName() );
			$template->assign( "{CSR_LOCALITYNAME}", $csr_db->getLocalityName() );
			$template->assign( "{CSR_ORGANIZATION}",
			$csr_db->getOrganizationName() );
			$template->assign( "{CSR_ORGANIZATIONALUNITNAME}",
				$csr_db->getOrganizationalUnitName() );
			$template->assign( "{CSR_COMMONNAME}", $csr_db->getCommonName() );
			$template->assign( "{CSR_CREATED}", strftime( TIMEFORMAT,
				$csr_db->getCreated() ) );
			$template->assign( "{DEP_NAME}", $departement->getName() );
			// die Registrare benachrichtigen
			$query = sprintf( "SELECT x.surname,x.lastname,x.email FROM %s x JOIN ".
				"%s y ON x.Auth_ID=y.ID JOIN %s z ON z.Auth_ID=y.ID WHERE ".
				"z.Departement_ID=%u AND z.notify=1;",
				DB_USER_TABLE, DB_AUTH_TABLE, DB_RIGHTS_TABLE, $departement->getID() );
			$db->query( $query );
			if( $db->countRows() > 0 ) {
				$mail = new pMail();
				$mail->setFrom( sprintf( "%s <%s>", $ca->getName(),
					$ca->getEMailAddress() ) );
				// die Empfänger eintragen
				while( $data = $db->fetchRow() ) {
					list( $surname, $lastname, $address ) = $data;
					if( !empty( $address ) )
						$mail->addRecipient( "$surname $lastname", $address );
				}
				$mail->setSubject( CSR_ADD_NOTIFY_SUBJECT );
				$template->parse( "{MESSAGE}", "csr_notify" );
				$mail->setMessage( $template->get_assigned( "{MESSAGE}" ) );
				// Mail versenden
				$mail->send();
				unset( $mail );
			}
			// Bestätigungsmail versenden
			$mail = new pMail();
			$mail->setFrom( sprintf( "%s <%s>", $ca->getName(),
				$ca->getEMailAddress() ) );
			$mail->addRecipient( "", $csr_db->getEMailAddress() );
			$mail->setSubject( CSR_ADD_EMAIL_SUBJECT );
			$template->parse( "{MESSAGE}", "csr_add" );
			$mail->setMessage( $template->get_assigned( "{MESSAGE}" ) );
			$mail->addFile( "csr.txt", "text/plain", $csr_db->getCSR() );
			$mail->send();
			// Ausgabe des Download-Formulars
			$template->assign( "{CSR_EMAIL}", $_POST["emailAddress"] );
			$template->assign( "{BACKREF}", $_SESSION["backref"] );
			$template->parse( "{MAIN}", "download" );
		}

		// keine Daten gePOSTet, dann Formular vorbelegen
		else {
			// Daten der CA nehmen, um Vorbelegungen im Formular vorzunehmen
			$template->assign( "{CSR_COUNTRYNAME}", $ca->getCountryName() );
			$template->assign( "{CSR_STATEORPROVINCENAME}",
				$ca->getStateOrProvinceName() );
			$template->assign( "{CSR_LOCALITYNAME}", $ca->getLocalityName() );
			$template->assign( "{CSR_ORGANIZATIONNAME}",
				$ca->getOrganizationName() );
			$template->assign( "{CSR_ORGANIZATIONALUNITNAME}",
				$ca->getOrganizationalUnitName() );
			$template->assign( "{CSR_COMMONNAME}", "" );
			$template->assign( "{CSR_EMAIL}", "" );
		}

		// Abteilungen aus der Datenbank laden und einparsen, wenn nötig
		if( !$template->get_assigned( "{MAIN}" ) ) {
			$query = sprintf( "SELECT x.ID,x.name FROM %s x JOIN %s y ON ".
				"x.ID=y.Departement_ID AND x.deleted=0 ORDER BY x.name ASC, x.ID ASC;",
				DB_DEPS_TABLE, DB_RIGHTS_TABLE );
			$db->query( $query );
			// Testen, ob überhaupt Abteilungen verfügbar sind
			if( $db->countRows() > 0 ) {
				while( $data = $db->fetchRow() ) {
					list( $dep_id, $dep_name ) = $data;
					$template->assign( "{DEP_NAME}", $dep_name );
					$template->assign( "{DEP_ID}", $dep_id );
					$template->assign( "{DEP_SELECTED}", ( $dep_id != $dep ? "" :
						" selected" ) );
					$template->parse( "{DEP_SELECT}", ".depselect" );
				}
			} else $template->parse( "{MAIN}", "no_deps" );
		}

		// Formular anzeigen, wenn benötigt
		if( !$template->get_assigned( "{MAIN}" ) ) {
			// Zurück-Button einfügen
			$nav->add( NAV_BACK, $_SESSION["backref"], "/left-blue.gif" );
			// Formular anzeigen
			$template->parse( "{MAIN}", "form" );
		}
	}

	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>