<?php
	/*
	Startseite einer Abteilung der CA im öffentlichen Bereich
	Parameter :
	1. dep : ID der Abteilung, die angezeigt werden soll
	*/

	// Session starten, um die Session-Daten von csr_add zu löschen;
	// insbesondere private Schlüssel
	session_start();
	unset( $_SESSION["csr_add_pkey"] );

	require_once( "./lib/database.php" );
	require_once( "./lib/_config.php" );
	require_once( "./lib/_FastTemplate.php" );
	require_once( "./lib/ca.php" );
	require_once( "./lib/departement.php" );
	require_once( "./lib/bbcodeparser.php" );
	require_once( "./lib/navigation.php" );
	// Sprachkonstanten laden
	require_once( "./language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "./templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		// Startseite einer Abteilung im öffentlichen Bereich
		"main" => "dep_index.html",
		"member" => "dep_index_member1.html",
		"no_member" => "dep_index_nomember.html",
		// CA nicht gefunden, Fehlermeldung
		"not_found" => "ca_not_found.html"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Parameter auswerten
	$dep = $_REQUEST["dep"];

	// Navigation vorbereiten und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	try {
		// Daten der CA laden und einparsen
		$ca = new pCA_DB( $db );
		$template->assign( "{CA_NAME}", $ca->getName() );
		unset( $ca );
		// Daten der Abteilung laden und einparsen
		$departement = new pDepartement( $db, (int) $dep );
		// Vorher testen, ob Abteilung gelöscht wurde
		if( !$departement->isDeleted() ) {
			$template->assign( "{DEP_NAME}", $departement->getName() );
			$template->assign( "{DEP_CREATED}", strftime( TIMEFORMAT,
				$departement->getCreated() ) );
			$template->assign( "{DEP_MODIFIED}", strftime( TIMEFORMAT,
				$departement->getModified() ) );
		} else $template->parse( "{MAIN}", "not_found" );
	} catch( Exception $e ) {
		$template->parse( "{MAIN}", "not_found" );
	}

	// Wenn keine Fehlermeldung vorliegt, dann weitermachen
	if( !$template->get_assigned( "{MAIN}" ) ) {

		// Rücksprungadresse setzen
		$_SESSION["backref"] = $_SERVER["PHP_SELF"]."?dep=$dep";

		// Navigationsmenü erweitern
		$nav->add( NAV_HOME, "index.php", "/home-icon5.gif" );
		$nav->add( NAV_BACK, "dep_list.php", "/left-blue.gif" );
		$nav->addSeparator();
		$nav->add( NAV_CSR_ADD, "csr_add.php?dep=$dep", "/add-comment-blue.gif" );

		// Beschreibung der Abteilung (BBCode) als HTML einparsen
		$bbcode = new pBBParser( $departement->getDescription() );
		$template->assign( "{DEP_DESC}", $bbcode->parse() );
		unset( $bbcode );

		// Abteilungsleiter und Registrare der Abteilung ermitteln
		$query = sprintf( "SELECT x.surname,x.lastname,x.email,z.registrar ".
			"FROM %s x JOIN %s y ON x.Auth_ID=y.ID JOIN %s z ON y.ID=z.Auth_ID ".
			"AND z.Departement_ID=%u ORDER BY z.registrar ASC,x.lastname ASC, ".
			"x.surname ASC;",
			DB_USER_TABLE, DB_AUTH_TABLE, DB_RIGHTS_TABLE, $dep );
		$db->query( $query );
		while( $data = $db->fetchRow() ) {
			list( $surname, $lastname, $email, $registrar ) = $data;
			// Vor- und Nachnamen sowie E-Mail-Adresse einparsen
			$template->assign( "{USR_SURNAME}", $surname );
			$template->assign( "{USR_LASTNAME}", $lastname );
			$template->assign( "{USR_EMAIL}", $email );
			// Wenn Registrar, dann in die Registrar-Tabelle einparsen
			if( $registrar == 1 )
				$template->parse( "{DEP_REGS}", ".member" );
			elseif( $registrar == 0 )
				$template->parse( "{DEP_ADM}", ".member" );
		}
		// Keine Abteilungsleiter verzeichnet ?
		if( !$template->get_assigned( "{DEP_ADM}" ) )
			$template->parse( "{DEP_ADM}", "no_member" );
		// Keine Registrare verzeichnet ?
		if( !$template->get_assigned( "{DEP_REGS}" ) )
			$template->parse( "{DEP_REGS}", "no_member" );

		// Ausgabe
		$template->parse( "{MAIN}", "main" );
	}

	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>