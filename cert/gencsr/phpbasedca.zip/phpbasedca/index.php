<?php
	/*
	Öffentliche Startseite der CA
	Parameter : keine
	*/

	// Session starten und alle Session-Inhalte löschen
	session_start(); session_unset();
	// Rücksprungaddresse setzen
	$_SESSION["backref"] = $_SERVER["PHP_SELF"];

	require_once( "./lib/_FastTemplate.php" );
	require_once( "./lib/database.php" );
	require_once( "./lib/_config.php" );
	require_once( "./lib/ca.php" );
	require_once( "./lib/navigation.php" );
	require_once( "./lib/bbcodeparser.php" );
	// Sprachkonstanten laden
	require_once( "./language/lang_".LANGUAGE.".php" );

	$template = new FastTemplate( "./templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		// Startseite einer CA
		"main" => "ca_index.html",
		// Fehlermeldung, wenn keine CA in der Datenbank ist
		"not_found" => "ca_not_found.html"
  ) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Navigation vorbereiten und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	// Testen, ob eine CA in der Datenbank verzeichnet ist. Wenn ja, dann
	// Startseite anzeigen
	try {
		// CA-Daten aus der Datenbank lesen
		$ca = new pCA_DB( $db );
	} catch( Exception $e ) {
		// Fehler beim Laden der CA, Fehlermeldung anzeigen
		$template->parse( "{MAIN}", "not_found" );
	}
	// Wenn keine Fehlermeldung vorliegt, dann weitermachen
	if( !$template->get_assigned( "{MAIN}" ) ) {
		// CA-Daten einparsen
		$template->assign( "{CA_NAME}", $ca->getName() );
		$template->assign( "{CA_COUNTRYNAME}", $ca->getCountryName() );
		$template->assign( "{CA_STATEORPROVINCENAME}",
			$ca->getStateOrProvinceName() );
		$template->assign( "{CA_LOCALITYNAME}", $ca->getLocalityName() );
		$template->assign( "{CA_ORGANIZATIONNAME}", $ca->getOrganizationName() );
		$template->assign( "CA_ORGANIZATIONALUNITNAME}",
			$ca->getOrganizationalUnitName() );
		$template->assign( "CA_COMMONNAME}", $ca->getCommonName() );
		$template->assign( "CA_EMAIL}", $ca->getEMailAddress() );
		// Beschreibung der CA ( BBCode ) als HTML ausgeben
		$bbcode = new pBBParser( $ca->getDescription() );
		$template->assign( "{CA_DESC}", $bbcode->parse() );
		unset( $bbcode );

		// Navigationsmenü
		$nav->add( NAV_INDEX_CA_DEPS, "dep_list.php", "/sitemap-blue.gif" );
		$nav->add( NAV_CSR_ADD, "csr_add.php", "/add-comment-blue.gif" );
		$nav->addSeparator();
		$nav->add( NAV_INDEX_CA_CERT, "x509_view.php", "/home-page-blue.gif" );
		$nav->add( NAV_INDEX_DOWNLOAD_PEM, "x509_download.php?format=pem",
			"/download-page-blue.gif" );
		$nav->add( NAV_INDEX_DOWNLOAD_CRT, "x509_download.php?format=crt",
			"/download-page-blue.gif" );

		// Anzahl der Abteilungen ermitteln und einparsen
		$query = sprintf( "SELECT COUNT( DISTINCT x.Departement_ID) FROM %s x ".
			"JOIN %s y ON x.Departement_ID=y.ID AND y.deleted=0;",
			DB_RIGHTS_TABLE, DB_DEPS_TABLE );
		$db->query( $query );
		$template->assign( "{DEPS_COUNT}", $db->fetchRow(0) );

		// Anzahl der Abteilungsleiter ermitteln und einparsen
		$query = sprintf( "SELECT COUNT( DISTINCT Auth_ID) FROM %s x JOIN %s y ".
			"ON x.Departement_ID=y.ID AND y.deleted=0 AND x.registrar=0;",
			DB_RIGHTS_TABLE, DB_DEPS_TABLE );
		$db->query( $query );
		$template->assign( "{ADM_COUNT}", $db->fetchRow(0) );

		// Anzahl der Registrare ermitteln und einparsen
		$query = sprintf( "SELECT COUNT( DISTINCT Auth_ID) FROM %s x JOIN %s y ".
			"ON x.Departement_ID=y.ID AND y.deleted=0 AND x.registrar=1;",
			DB_RIGHTS_TABLE, DB_DEPS_TABLE );
		$db->query( $query );
		$template->assign( "{REG_COUNT}", $db->fetchRow(0) );

		// Ausgabe
		$template->parse( "{MAIN}", "main" );
	}

	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>