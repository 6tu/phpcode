<?php
	/*
	Listet alle Abteilungen der CA auf
	Parameter :
	1. (diverse Parameter aus der Tabellenauflistung)
	*/

	// Session starten
	session_start();

	require_once( "./lib/_FastTemplate.php" );
	require_once( "./lib/database.php" );
	require_once( "./lib/_config.php" );
	require_once( "./lib/table.php" );
	require_once( "./lib/navigation.php" );
	require_once( "./lib/ca.php" );
	// Sprachkonstanten laden
	require_once( "./language/lang_".LANGUAGE.".php" );

	// Template intialisieren
	$template = new FastTemplate( "./templates/".LANGUAGE );
	$template->define( array(
		"header" => "header.html",
		"footer" => "footer.html",
		"index" => "index.html",
		// Seite mit der Abteilungsliste
		"main" => "dep_list.html",
		// keine CA gefunden, daher keine Abteilungsauflistung
		"not_found" => "ca_not_found.html"
	) );

	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );

	// Navigation vorbereiten und Pfade einparsen
	$nav = new pNavigation( IMAGE_PATH );
	$template->assign( "{IMAGE_PATH}", IMAGE_PATH );
	$template->assign( "{INCLUDE_PATH}", INCLUDE_PATH );

	try {
		// Daten der CA einparsen
		$ca = new pCA_DB( $db );
		$template->assign( "{CA_NAME}", $ca->getName() );
	} catch( Exception $e ) {
		$template->parse( "{MAIN}", "not_found" );
	}

	// Wenn keine Fehlermeldung vorliegt, dann weitermachen
	if( !$template->get_assigned( "{MAIN}" ) ) {
		// Zurück-Button einfügen
		$nav->add( NAV_BACK, "index.php", "/left-blue.gif" );

		// Parameter auswerten
		$page = ( $_REQUEST["page"] > 0 ? $_REQUEST["page"] :
			( $_SESSION["dep_list_page"] > 0 ? $_SESSION["dep_list_page"] : 1 ) );
		$orderby = ( $_REQUEST["orderby"] > 0 ? $_REQUEST["orderby"] :
			( $_SESSION["dep_list_orderby"] > 0 ? $_SESSION["dep_list_orderby"] :
			0 ) );
		$order = ( $_REQUEST["order"] != "" ? $_REQUEST["order"] :
			( $_SESSION["dep_list_order"] != "" ? $_SESSION["dep_list_order"] :
			"asc" ) );
		if( $order != "asc" && $order != "desc" ) $order = "asc";
		// Parameter in die Session speichern
		$_SESSION["dep_list_page"] = $page;
		$_SESSION["dep_list_orderby"] = $orderby;
		$_SESSION["dep_list_order"] = $order;

		// Maximalanzahl an anzeigbaren Abteilungen ermitteln
		$query = sprintf( "SELECT COUNT(x.Departement_ID) FROM %s x JOIN %s y ON ".
			"x.Departement_ID=y.ID GROUP BY x.Departement_ID",
			DB_RIGHTS_TABLE, DB_DEPS_TABLE );
		$db->query( $query );
		$maxcount = $db->fetchRow( 0 );
		$maxpage = floor( $maxcount / LIST_DEPS );
		if( $maxcount % LIST_DEPS <> 0 ) $maxpage++;

		// Tabelle mit den anzeigbaren Abteilungen generieren
		$table = new pTable( DEP_LIST_TBL_SHOW_ALL, $page, $maxpage );
		$table->addColumn( DEP_LIST_TBL_DEPNAME, "100%", true, false );
		$table->setSort( $orderby, $order );

		// Query für die anzeigbare Abteilungen zusammenbauen
		$query = sprintf( "SELECT y.ID, y.name FROM %s x JOIN %s y ON ".
			"x.Departement_ID=y.ID AND y.deleted=0 ORDER BY y.name $order",
			DB_RIGHTS_TABLE, DB_DEPS_TABLE );
		// anzuzeigende Seite in den Query einfügen
		$query .= sprintf( " LIMIT %u,%u;", ($page-1)*LIST_DEPS, LIST_DEPS );
		// Abteilungen aus der Datenbank lesen
		$db->query( $query );
		// Abteilungen in die Tabelle einparsen
		while( $data = $db->fetchRow() ) {
			list( $ID, $name ) = $data;
			// Abteilungsname und Link in die Tabelle einfügen
			$table->addRow( array(
			sprintf( "<a href=\"dep_index.php?dep=%u\">%s</a>", $ID, $name ) ) );
		}

		// Tabelle einparsen und fertig
		$template->assign( "{DEPS_TABLE}", $table->parse() );
		$template->parse( "{MAIN}", "main" );
	}

	$template->assign( "{NAVIGATION}", $nav->parse() );
	$template->parse( "{HEADER}", "header" );
	$template->parse( "{FOOTER}", "footer" );
	$template->parse( PAGE, "index" );
	$template->FastPrint( PAGE );
?>