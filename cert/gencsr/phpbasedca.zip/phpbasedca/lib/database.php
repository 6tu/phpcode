<?php

	// Klasse für Datenbankfehler ( erbt von Exception )
	class eDatabase extends Exception {
		protected $query = "";

		public function __construct( $message, $query, $code = 0 ) {
			// Query speichern
			$this->query = $query;
			// geerbten Konstruktor aufrufen
			parent::__construct( $message, $code );
		}

		public function __toString() {
			$error = "Database error ".$this->code.": ";
			switch( $this->code ) {
				case 1  :
					$error .= "No connection to database server ({$this->query})"; break;
				case 2  :
					$error .= "Cannot connect to database ({$this->query})"; break;
				case 3  : $error .= "Not connected to database server"; break;
				case 4  : $error .= "Cannot begin transaction"; break;
				case 5  : $error .= "Cannot end transaction"; break;
				case 6  : $error .= "Query is epmty"; break;
				case 7  : $error .= "Database error in query '{$this->query}'"; break;
				case 8  : $error .= "No data to fetch"; break;
				default : $error = parent::__toString(); break;
			}
			// mySQL-Fehlermeldung sowie Zeile und Fehlerskript anhängen
			$error .= " [{$this->message}] in {$this->file} on line {$this->line}\n";
			// Trace anhängen
			$error .= "Trace : ".$this->getTraceAsString();
			return $error;
		}
	}

	// Klasse für den Datenbankzugriff ( für mySQL )
	class pDatabase {
		protected $handle;
		protected $data;
		protected $transaction = false;
		private $server = "";
		private $user = "";
		private $database = "";

		function __construct( $server = "localhost", $user = "", $password = "" ) {
		// Konstruktor
			$this->server = "";
			$this->user = "";
			$this->handle = @mysql_connect( $server, $user, $password );
			if( !is_resource( $this->handle ) )
				throw new eDatabase( mysql_error(), "Server: $server Login: $login ".
					"Password: $password", 1  );
			$this->server = $server;
			$this->user = $user;
			return true;
		}

		function __destruct() {
		// Destruktor
			if( is_resource( $this->handle ) ) @mysql_close( $this->handle );
			return true;
		}

		// get-Methoden

		final function getServer() { return $this->server; }
		final function getUser() { return $this->user; }
		final function getDatabase() { return $this->database; }
		final function connected() { return is_resource( $this->handle ); }
		final function transactional() { return $this->transaction; }

		// Klassenmethoden

		function selectDatabase( $database = "" ) {
		// Wählt eine Datenbank aus
			if( !$this->connected() ) throw new eDatabase( mysql_error(), "", 3 );
			if( !mysql_select_db( $database, $this->handle ) )
				throw new eDatabase( mysql_error(), $database, 2 );
			$this->database = $database;
			return true;
		}

		function beginTransaction() {
			// Mit Datenbank verbunden ?
			if( !$this->connected() ) throw new eDatabase( mysql_error(), "", 3 );
			// Bereits Transaktion gestartet ? Wenn ja, dann Transaktion beenden
			if( $this->transactional() ) $this->endTransaction();
			// Transaktion starten
			if( @mysql_query( "START TRANSACTION;" ) === true ) {
				$this->transaction = true;
				return true;
			} else
				throw new eDatabase( mysql_error(), "", 4 );
		}

		function endTransaction( $rollback = false ) {
			// Mit Datenbank verbunden ?
			if( !$this->connected() ) throw new eDatabase( mysql_error(), "", 3 );
			// Bereits Transaktion beendet ? Dann aufhören
			if( !$this->transactional() ) return true;
			// ROLLBACK oder COMMIT zum Beenden der Transaktion angeordnet ?
			if( $rollback ) {
				if( @mysql_query( "ROLLBACK;" ) === true ) {
					$this->transaction = false;
					return true;
				} else throw new eDatabase( mysql_error(), "", 5 );
			} else {
				if( @mysql_query( "COMMIT;" ) === true ) {
					$this->transaction = false;
					return true;
				} else throw new eDatabase( mysql_error(), "", 5 );
			}
			return false;
		}

		function query( $query = "" ) {
		// Setzt einen Query an die Datenbank ab
			// Wenn die Anfrage leer ist, Fehlermeldung absetzen
			if( empty( $query ) ) throw new eDatabase( "", "", 6 );
			// Mit Datenbank verbunden ?
			if( !$this->connected() ) throw new eDatabase( mysql_error(), "", 3 );
			// Anfrage ausführen
			$query_data = @mysql_query( $query, $this->handle );
			// Anfrage erfolgreich ausgeführt ?
			if( $query_data === false ) {
				// Rollback, sobald ein Fehler in der Transaktion auftritt
				if( $this->transactional ) $this->endTransaction( true );
				// Fehlermeldung
				throw new eDatabase( mysql_error(), $query, 7 );
			}
			// Ansosnten Resultat speichern
			if( is_resource( $this->data ) ) mysql_free_result( $this->data );
			$this->data = $query_data;
			return true;
		}

		function fetchRow( $index = -1 ) {
			// Mit Datenbank verbunden ?
			if( !$this->connected() ) throw new eDatabase( mysql_error(), "", 3 );
			// Daten zum Abholen ?
			if( !is_resource( $this->data ) ) throw new eDatabase( "", "", 8 );
			// Daten abholen
			if( $index > -1 ) {
				$row = mysql_fetch_row( $this->data );
				if( $row === false ) return false;
				return $row[$index];
			} else return mysql_fetch_row( $this->data );
		}

		function fetchArray( $column = "" ) {
			// Mit Datenbank verbunden ?
			if( !$this->connected() ) throw new eDatabase( mysql_error(), "", 3 );
			// Daten zum Abholen ?
			if( !is_resource( $this->data ) ) throw new eDatabase( "", "", 8 );
			// Daten abholen
			if( !empty( $column ) ) {
				$row = mysql_fetch_array( $this->data );
				if( $row === false ) return false;
				return $row[$column];
			} else return mysql_fetch_array( $this->data );
		}

		function countRows() {
			// Daten zum Zählen ?
			if( !is_resource( $this->data ) ) throw new eDatabase( "", "", 8 );
			return mysql_num_rows( $this->data );
		}

		function seek( $index = 0 ) {
			// Daten zum Setzen des Zeilenzeigers ?
			if( !is_resource( $this->data ) ) throw new eDatabase( "", "", 8 );
			return @mysql_data_seek( $this->data, $index );
		}

		function lastInsertID() {
			// Mit Datenbank verbunden ?
			if( !$this->connected() ) throw new eDatabase( mysql_error(), "", 3 );
			return mysql_insert_id( $this->handle );
		}

		function affectedRows() {
			// Mit Datenbank verbunden ?
			if( !$this->connected() ) throw new eDatabase( mysql_error(), "", 3 );
			return @mysql_affected_rows( $this->handle );
		}

	}
?>