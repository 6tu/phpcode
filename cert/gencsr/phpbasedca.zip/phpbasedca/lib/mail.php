<?php
	// Fehlerklasse für die Klasse pMail
	class eMail extends Exception {

		final function __toString() {
			$error = "pMail error : ";
			switch( $this->code ) {
				case 1 : $error .= "Recipient-address is empty"; break;
				case 2 : $error .= "From-address is empty"; break;
				case 3 : $error .= "file name is empty in attachement"; break;
				case 4 : $error .= "file type is empty in attachement"; break;
				case 5 : $error .= "no content in attachement"; break;
				default : $error = parent::__toString(); break;
			}
			// Trace anhängen
			$error .= "Trace : ".$this->getTraceAsString();
			return $error;
		}

	}

	// Klasse zum Versenden von eMails
	class pMail {
		protected $to = array();		// Empfänger der eMail
		protected $from = "";				// Absender der eMail
		protected $replyto = "";		// Antwort-Addresse
		protected $subject = "";		// Titel der eMail
		protected $message;					// Der eigentlichen Nachrichtentext
		protected $files = array();	// angehangene Dateien

		// Konstruktor
		final function __construct() {
			$this->to = array();
			$this->files = array();
		}

		// get-Methoden, alle public /////////////////////////////////////

		final function getTo() { return $this->to; }
		final function getFrom() { return $this->from; }
		final function getReplyTo() { return $this->replyto; }
		final function getSubject() { return $this->subject; }
		final function getMessage() { return $this->message; }
		final function getFiles() { return $this->files; }

		// set-Methoden, alle public /////////////////////////////////////

		final function addRecipient( $name = "", $address = "" ) {
		// Fügt einen neuen Empfänger in die Empfängerliste ein
			if( empty( $address ) ) throw new eMail( "", 1 );
			// Testen, ob Addresse in der Liste
			foreach( $this->to as $key => $value )
				if( strtoupper( $value["address"] ) == strtoupper( $address ) )
					return false;
			// Addresse nicht in der Liste, also einfügen
			array_push( $this->to, array( "name" => $name, "address" => $address ) );
			return true;
		}

		final function setFrom( $from = "" ) {
		// Setzt das "From:"-Feld
			if( empty( $from ) ) throw new eMail( "", 2 );
			$this->from = $from;
		}

		final function setReplyTo( $replyto = "" ) {
			$this->replyto = $replyto;
		}

		final function setSubject( $subject = "" ) {
			$this->subject = $subject;
		}

		final function setMessage( $message = "" ) {
			$this->message = $message;
		}

		final function addFile( $filename = "", $filetype = "", $content = "" ) {
			if( empty( $filename ) ) throw new eMail( "", 3 );
			if( empty( $filetype ) ) throw new eMail( "", 4 );
			if( empty( $content ) ) throw new eMail( "", 5 );
			// Prüfen, ob Anhang schon vorhanden ist
			foreach( $this->files as $key => $value )
				if( strtoupper( $filename ) == strtoupper( $value["filename"]  ) &&
					strtoupper( $filetype ) == strtoupper( $value["filetype"] ) )
					return false;
			// Anhang noch nicht verzeichnet, also dies tun
			array_push( $this->files, array( "filename" => $filename,
				"filetype" => $filetype, "content" => $content ) );
			return true;
		}

		// Mail-Funktionen ///////////////////////////////////////////////

		final function send() {
		// Sendet die eMail ab
			// Schritt 1 : Empfängerliste zusammenbauen
			$to = array();
			foreach( $this->to as $key => $value )
				if( empty( $value["name"] ) && !empty( $value["address"] ) )
					array_push( $to, $value["address"] );
				elseif( !empty( $value["name"] ) && !empty( $value["address"] ) )
					array_push( $to, sprintf( "%s <%s>", $value["name"],
						$value["address"] ) );
			$to = implode( ", ", $to );
			// Schritt 2 : Zusätzliche Header zusammenbauen
			$header = "From: ".$this->from."\r\n";
			if( !empty( $this->replyto ) )
				$header .= "Reply-To: ".$this->replyto."\r\n";
			// Wenn Dateianhänge, dann Nachrichtentext modifizieren usw.
			if( count( $this->files ) > 0 ) {
				// Trenner generieren
				$boundary = md5( uniqid( time() ) );
				// Header erweitern
				$header .= "MIME-Version: 1.0\r\n";
				$header .= "Content-Type: multipart/mixed; boundary=$boundary\r\n\n";
				$header .= "This is a multipart MIME-encoded message.\n\n";
				// Den Nachrichtentext als Teil kennzeichnen und erweitern
				$this->message = "--$boundary\n".
					"Content-Type: text/plain\n".
					"Content-Transfer-Encoding: 8bit\n\n".
					$this->message;
				// Die Dateien anhängen
				foreach( $this->files as $key => $value ) {
					$this->message .= "\n--$boundary\n";
					$this->message .= "Content-Type: ".$value["filetype"]."; name=".
					$value["filename"]."\n";
					$this->message .= "Content-Transfer-Encoding: base64\n";
					$this->message .= "Content-Disposition: attachement; filename=".
					$value["filename"]."\n\n";
					$this->message .= chunk_split( base64_encode( $value["content"] ) ).
					"\n";
				}
				// Nachricht abschliessen
				$this->message .= "--$boundary--";
			}
			// Schlussendlich Mail versenden
			return @mail( $to, $this->subject, $this->message, $header );
		}

	}
?>