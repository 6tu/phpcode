<?php

	// Klasse zur Verwaltung des Navigationsmenüs
	class pNavigation {
		protected $items = array();
		protected $imagepath = "";

		final function __construct( $imagepath = "" ) {
			$this->clear();
			$this->items = array();
			$this->imagepath = $imagepath;
		}

		final function __destruct() {
			$this->clear();
		}

		final function clear() {
			foreach( $this->items as $index => $item ) unset( $item );
		}

		final function add( $value = "", $link = "", $image = "" ) {
			array_push( $this->items, array( $value, $link, $image ) );
		}

		final function addSeparator() {
			$this->add( "", "", "" );
		}

		final function remove( $index ) {
			unset( $this->items[$index] );
		}

		final function parse() {
			$output = "";
			foreach( $this->items as $index => $item ) {
				list( $value, $link, $image ) = $item;
				// Schritt 1 : <TR> und <TD> beginnen
				$output .= "\t<tr>\n\t\t<td class=\"navitem\"";
				// Schritt 2 : onclick-Ereignis einfügen, wenn Link angegeben
				if( !empty( $link ) )
					$output .= sprintf( "\t\t\tonclick=\"location.href='%s'\"\n",
						$link );
				// Schritt 3 : Hover-Effekt einfügen, sofern nötig
				if( !empty( $value ) && !empty( $link ) )
					$output .= "\t\t\tonmouseover=\"this.className='navitem_hover'\"\n".
						"\t\t\tonmouseout=\"this.className='navitem'\"";
				// Schritt 4 : <TD> beenden
				$output .= ">\n";
				// Schritt 5 : Bild einfügen
				if( !empty( $image ) )
					$output .= sprintf( "\t\t\t<image src=\"%s%s\">",
						$this->imagepath, $image );
				// Schritt 6 : Text oder Linie einfügen
				$output .= ( empty( $value ) ? "<hr>" : $value );
				// Fertig, <TD> und <TR> abschliessen
				$output .= "\n\t\t</td>\n\t</tr>\n";
			}
			return $output;
		}
	}
?>