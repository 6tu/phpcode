<?php
	require_once( "database.php" );

	// Klasse für einen Benutzer (immer mit DB-Zugriff)
	class pUser {
		protected $ID;				// ID des Benutzers in der Datenbank
		protected $Auth_ID;		// ID des Benutzernamen/Passwort-Paares
		protected $surname;		// Vorname des Benutzers
		protected $lastname;	// Nachname des Benutzers
		protected $login;			// Login für die Website
		protected $password;	// dazugehöriges Passwort
		protected $email;			// eMail-Addresse
		protected $created;		// Zeitpunkt der Erstellung
		protected $modified;	// Zeitpunkt der letzten Änderung

		// Konstruktor
		function __construct() {
			$constructor_error = false;
			switch( func_num_args() ) {
				case 3 :
					// Aus der Datenbank lesen
					list( $arg1, $arg2, $arg3 ) = func_get_args();
					if( get_class( $arg1 ) == "pDatabase" && ( is_integer( $arg2 ) ||
						is_string( $arg2 ) ) && is_string( $arg3 ) )
						return $this->loadFromDB( $arg1, $arg2, $arg3 );
					else $constructor_error = true;
					break;
				case 4 :
					// normaler Konstruktor ohne Angabe der eMail-Addresse
					list( $arg1, $arg2, $arg3, $arg4 ) = func_get_args();
					$this->setSurname( $arg1 );
					$this->setLastname( $arg2 );
					$this->setLogin( $arg3 );
					$this->setPassword( $arg4 );
					$this->setEMail( "" );
					return true;
					break;
				case 5 :
					// normaler Konstruktor mit Angabe der eMail-Addresse
					list( $arg1, $arg2, $arg3, $arg4, $arg5 ) = func_get_args();
					$this->setSurname( $arg1 );
					$this->setLastname( $arg2 );
					$this->setLogin( $arg3 );
					$this->setPassword( $arg4 );
					$this->setEMail( $arg5 );
					return true;
					break;
				default : $constructor_error = true; break;
			}
			if( $constructor_error )
				throw new Exception( "pUser : Fehlerhafter Konstruktor" );
		}

		// get/set-Methoden
		final function isDeleted() {
			return ( $this->ID > 0 && $this->Auth_ID == 0 );
		}
		final function getID() { return $this->ID; }
		final function getSurname() { return $this->surname; }
		final function getLastname() { return $this->lastname; }
		final function getLogin() { return $this->login; }
		final function getPassword() { return $this->password; }
		final function getEMail() { return $this->email; }
		final function getCreated() { return $this->created; }
		final function getModified() { return $this->modified; }

		final function setSurname( $surname ) {
			if( empty( $surname ) )
				throw new Exception( "pUser : Vorname ist leer" );
			$this->surname = $surname;
		}
		final function setLastname( $lastname ) {
			if( empty( $lastname ) )
				throw new Exception( "pUser : Nachname ist leer" );
			$this->lastname = $lastname;
		}

		final function setLogin( $login ) {
			if( empty( $login ) )
				throw new Exception( "pUser : Login ist leer" );
			$this->login = $login;
		}

		final function setPassword( $password ) {
			if( empty( $password ) )
				throw new Exception( "pUser : Passwort ist leer" );
			$this->password = $password;
		}

		final function setEMail( $email ) { $this->email = $email; }

		// Datenbanksachen

		final function loadFromDB( pDatabase $db, $ID, $password ) {
		// ID kann eine numerische ID oder ein Benutzername sein
			if( $ID <= 0 && empty( $ID ) )
				throw new Exception( "pUser : Benutzer-ID ist Null" );
			$query = sprintf( "SELECT x.ID, x.Auth_ID, x.surname, x.lastname, ".
				"y.login, x.email, UNIX_TIMESTAMP( x.created ), UNIX_TIMESTAMP( ".
				"x. modified ) FROM %s x JOIN %s y ON x.Auth_ID=y.ID",
				DB_USER_TABLE, DB_AUTH_TABLE );
			if( is_integer( $ID ) )
				$query .= sprintf( " WHERE x.ID=%u", $ID );
			elseif( is_string( $ID ) )
				$query .= sprintf( " WHERE y.login='%s'", $ID );
			// Passwort checken, wenn möglich
			if( !empty( $password ) )
				$query .= sprintf( " AND y.password=MD5('%s');", $password );
			$db->query( $query );
			if( ( $data = $db->fetchRow() ) === false )
				throw new Exception( "pUser : Laden des Benutzers fehlgeschlagen" );
			$this->ID = $data[0];
			$this->Auth_ID = $data[1];
			$this->setSurname( $data[2] );
			$this->setLastname( $data[3] );
			$this->setLogin( $data[4] );
			if( empty( $password ) ) $this->password = "";
				else $this->setPassword( $password );
			$this->setEMail( $data[5] );
			$this->created = $data[6];
			$this->modified = $data[7];
			return true;
		}

		final function saveToDB( pDatabase $db ) {
			$db->beginTransaction();
			try {
				if( $this->getID() == 0 ) {
					// Benutzer neu anlegen
					// Zuerst Benutzernamen/Passwort-Paar speichern
					$query = sprintf( "INSERT INTO %s ( login,password ) VALUES ( ".
						"'%s', MD5( '%s' ) );",
						DB_AUTH_TABLE, $this->getLogin(), $this->getPassword() );
					$db->query( $query );
					$auth_id = $db->lastInsertID();
					// Benutzerdatensatz anlegen
					$query = sprintf( "INSERT INTO %s ( Auth_ID, surname, lastname, ".
						"email, created, modified ) VALUES ( %u, '%s', '%s', NULLIF( ".
						"'%s', '' ), NOW(), NOW() );",
						DB_USER_TABLE, $auth_id, $this->getSurname(), $this->getLastname(),
						$this->getEMail() );
					$db->query( $query );
					$this->ID = $db->lastInsertID();
					$this->Auth_ID = $auth_id;
					$db->endTransaction();		// COMMIT
					// Fertig, alles gutgegangen
					$this->created = time();
					$this->modified = time();
				} else {
					// Bereits existierenden Benutzer speichern
					// Login/Passwort-Paar speichern
					$query = sprintf( "UPDATE %s SET login='%s', password=MD5( '%s' ) ".
						"WHERE ID=%u;",
						DB_AUTH_TABLE,  $this->getLogin(), $this->getPassword(),
						$this->Auth_ID );
					$db->query( $query );
					// Benutzerdaten speichern
					$query = sprintf( "UPDATE %s SET Auth_ID=%u, surname='%s', ".
						"lastname='%s', email=NULLIF( '%s', '' ), modified=NOW() ".
						"WHERE ID=%u;",
						DB_USER_TABLE, $this->Auth_ID, $this->getSurname(),
						$this->getLastname(), $this->getEMail(), $this->getID() );
					$db->query( $query );
					// Alles gut gelaufen, COMMITen
					$db->endTransaction();		// COMMIT
					$this->modified = time();
				}
			} catch( Exception $e ) {
				$db->endTransaction( true );	// ROLLBACK
				throw $e;
			}
			return true;
		}

		final function deleteFromDB( pDatabase $db, $realdelete = false ) {
			if( !$realdelete && !$this->isDeleted() ) {
				$query = sprintf( "DELETE FROM %s WHERE ID=%u;",
					DB_AUTH_TABLE, $this->Auth_ID );
				$db->query( $query );
				$this->Auth_ID = 0;
			} elseif( $realdelete && $this->getID() > 0 ) {
				$query = sprintf( "DELETE FROM %s WHERE ID=%u;",
					DB_USER_TABLE, $this->getID() );
				$db->query( $query );
				$this->Auth_ID = 0;
				$this->ID = 0;
			}
			return ( $db->affectedRows() == 1 );
		}

	}
?>