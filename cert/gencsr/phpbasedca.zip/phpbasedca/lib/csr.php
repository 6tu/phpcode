<?php
	require_once( "certdata.php" );
	require_once( "database.php" );

	// Klasse zur Verwaltung einer CSR (ohne Datenbank)
	class pCSR extends pCertData {
		protected $csr_string;		// exportierter CSR-String, siehe pPrivateKey

		// Konstruktor
		public function __construct() {
			if( func_num_args() == 8 ) {
				list( $arg1, $arg2, $arg3, $arg4, $arg5, $arg6, $arg7, $arg8 ) =
					func_get_args();
				// Grunddaten setzen in der Vaterklasse ( pCertData )
				parent::__construct( $arg1, $arg2, $arg3, $arg4, $arg5, $arg6,
					$arg7 );
				// CSR-String laden
				$this->setCSR( $arg8 );
			} else
				throw new Exception( "pCSR : Falsche Konstruktorparameter" );
		}

		// get/set-Methoden
		protected function setCSR( $csr ) {
			if( empty( $csr ) )
				throw new Exception( "pCSR : CSR-Zeichenkette ist leer" );
			$this->csr_string = $csr;
		}
		final function getCSR() { return $this->csr_string; }

	}

	// Klasse zur Verwaltung einer CSR ( mit Datenbankzugriff )
	class pCSR_DB extends pCSR {
		protected $ID = 0;				// ID der CSR in der Datenbank
		protected $created = 0;		// Zeitpunkt der Erstellung
		protected $modified = 0;	// Zeitpunkt der letzten Änderung

		final function __construct() {
		// Konstruktor
			$constructor_error = false;
			switch( func_num_args() ) {
				case 1 :
					// mit Daten aus einer pCSR erzeugen
					$arg1 = func_get_arg( 0 );
					if( get_class( $arg1 ) == "pCSR" ) {
						parent::__construct(
							$arg1->getCountryName(),				// Grunddaten
							$arg1->getStateOrProvinceName(),
							$arg1->getLocalityName(),
							$arg1->getOrganizationName(),
							$arg1->getOrganizationalUnitName(),
							$arg1->getCommonName(),
							$arg1->getEMailAddress(),
							$arg1->getCSR() );					// CSR als Klartext
					} else $constructor_error = true;
					break;
				case 2 :
					list( $arg1, $arg2 ) = func_get_args();
					// Daten aus der Datenbank laden
					if( get_class( $arg1 ) == "pDatabase" && is_integer( $arg2 ) )
						return $this->loadFromDB( $arg1, $arg2 );
					else $constructor_error = true;
					break;
				case 8 :
					list( $arg1, $arg2, $arg3, $arg4, $arg5, $arg6, $arg7, $arg8 ) =
						func_get_args();
					parent::__construct( $arg1, $arg2, $arg3, $arg4, $arg5, $arg6,
						$arg7, $arg8 );
					break;
				default : $constructor_error = true; break;
			}
			if( $constructor_error )
				throw new Exception( "pCSR_DB : Falsche Konstruktorparameter" );
		}

		// Datenbanksachen

		final function getID() { return $this->ID; }
		final function getCreated() { return $this->created; }
		final function getModified() { return $this->modified; }

		function saveToDB( pDatabase $db ) {
			if( $this->getID() == 0 ) {
				$query = sprintf( "INSERT INTO %s ( csrdata, countryName, ".
					"stateOrProvinceName, localityName, organizationName, ".
					"organizationalUnitName, commonName, emailAddress, created, ".
					"modified ) VALUES ( '%s', ".str_repeat( "'%s', ", 7 ).
					"NOW(), NOW() );",
					DB_CSR_TABLE, $this->getCSR(), $this->getCountryName(),
					$this->getStateOrProvinceName(), $this->getLocalityName(),
					$this->getOrganizationName(), $this->getOrganizationalUnitName(),
					$this->getCommonName(), $this->getEmailAddress() );
				$db->query( $query );
				$this->ID = $db->lastInsertID();
				$this->created = time();
				$this->updated = time();
				return true;
			} else {
				$query = sprintf( "UPDATE %s SET csrdata='%s', countryName='%s', ".
					"stateOrProvinceName='%s', localityName='%s', ".
					"organizationName='%s', organizationalUnitName='%s', ".
					"commonName='%s', emailAddress='%s', modified=NOW() ".
					"WHERE ID=%u;",
					DB_CSR_TABLE, $this->getCSR(), $this->getCountryName(),
					$this->getStateOrProvinceName(), $this->getLocalityName(),
					$this->getOrganizationName, $this->getOrganizationalUnitName(),
					$this->getCommonName(), $this->getEmailAddress(), $this->getID() );
				$db->query( $query );
				$this->updated = time();
				return true;
			}
		}

		function loadFromDB( pDatabase $db, $ID = 0 ) {
			if( $ID <= 0 )
				throw new Exception( "pCSR_DB : ID der CSR ist Null" );
			$query = sprintf( "SELECT csrdata, countryName, stateOrProvinceName, ".
				"localityName, organizationName, organizationalUnitName, ".
				"commonName, emailAddress, UNIX_TIMESTAMP( created ), ".
				"UNIX_TIMESTAMP( modified ) FROM %s WHERE ID=%u;",
				DB_CSR_TABLE, $ID );
			$db->query( $query );
			if( ( $data = $db->fetchRow() ) === false )
				throw new Exception( "pCSR_DB : Laden der CSR-Daten fehlgeschlagen" );
			$this->setCSR( $data[0] );
			$this->setCountryName( $data[1] );
			$this->setStateOrProvinceName( $data[2] );
			$this->setLocalityName( $data[3] );
			$this->setOrganizationName( $data[4] );
			$this->setOrganizationalUnitName( $data[5] );
			$this->setCommonName( $data[6] );
			$this->setEmailAddress( $data[7] );
			$this->ID = $ID;
			$this->created = $data[8];
			$this->modified = $data[9];
			return true;
		}

		function deleteFromDB( pDatabase $db ) {
			if( $this->getID() <= 0 )
				throw new Exception( "pCSR_DB : Löschen einer Null-ID" );
			$query = sprintf( "DELETE FROM %s WHERE ID=%s;",
				DB_CSR_TABLE, $this->getID() );
			$db->query( $query );
			return ( $db->affectedRows == 1 );
		}
	}
?>