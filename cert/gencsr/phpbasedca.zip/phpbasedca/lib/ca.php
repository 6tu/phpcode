<?php
	require_once( "database.php" );
	require_once( "certdata.php" );
	require_once( "privatekey.php" );
	require_once( "csr.php" );
	require_once( "x509.php" );
	require_once( "user.php" );

	// Klasse für eine CA (ohne Datenbankzugriff)
	class pCA extends pCertData {
		// Metadaten
		protected $name;					// Name der CA
		protected $description;		// Beschreibung der CA
		// interne Ressourcen
		protected $x509cert;			// X.509-Zertifkat der CA
		protected $privkey;				// Privater Schlüssel der CA
		protected $serial = 1;		// Seriennummer für Zertifikate

		public function __construct() {
			$constructor_error = false;
			switch( func_num_args() ) {
				// Hinweis : erster Parameter ist immer Name der CA !
				case 3 :
					list( $arg1, $arg2, $arg3 ) = func_get_args();
					$this->setName( $arg1 );
					// Neue CA generieren ( mit Standard-Verfallsdatum )
					if( get_class( $arg2 ) == "pCertData" && get_class( $arg3 ) ==
						"pPrivateKey" ) return $this->generate( $arg2, $arg3 );
					elseif( get_class( $arg2 ) == "pPrivateKey" && get_class( $arg3) ==
						"pX509Cert" ) return $this->import( $arg2, $arg3 );
					else $constructor_error = true;
					break;
				case 4 :
					list( $arg1, $arg2, $arg3, $arg4 ) = func_get_args();
					$this->setName( $arg1 );
					// Neue CA generieren ( mit Verfallsdatum )
					if( get_class( $arg2 ) == "pCertData" && get_class( $arg3 ) ==
						"pPrivateKey" && is_integer( $arg4 ) )
						return $this->generate( $arg2, $arg3, $arg4 );
					else $constructor_error = true;
					break;
				default : $constructor_error = true; break;
			}
			if( $constructor_error )
				throw new Exception( "pCA : Falsche Konstruktorparameter" );
		}

		final function __destruct() {
			if( is_object( $this->x509cert ) ) unset( $this->x509cert );
			if( is_object( $this->privkey ) ) unset( $this->privkey );
		}

		// get-Methoden
		final function getName() { return $this->name; }
		final function getDescription() { return $this->description; }
		final function getPrivkey() { return new pPrivateKey(
			$this->privkey->export() ); }
		final function getX509Cert() { return new pX509Cert(
			$this->x509cert->export() ); }
		final function getSerial() { return $this->serial; }

		// set-Methoden
		final function setName( $ca_name ) {
			if( empty( $ca_name ) )
				throw new Exception( "pCA : Name der CA ist leer" );
			$this->name = $ca_name;
		}
		final function setDescription( $description ) {
			$this->description = $description;
		}
		final function setPassword( $password ) {
			$this->privkey->setPassword( $password );
		}

		// Private Methoden

		private function import( pPrivateKey $pkey, pX509Cert $x509 ) {
			// Erstellt eine neue CA aus dem privaten Schlüssel $pkey und dem
			// dazugehörigem X.509-Zertifikat $x509
			if( openssl_x509_check_private_key( $x509->export(), $pkey->export() )) {
				// interne Eigenschaften löschen
				if( is_object( $this->x509cert ) ) unset( $this->x509cert );
				if( is_object( $this->privkey ) ) unset( $this->privkey );
				// Privaten Schlüssel übernehmen
				$this->privkey = $pkey;
				// X.509-Zertifikat reimportieren ( Workaround: kein Downcast in PHP )
				$this->x509cert = new pX509Cert_DB( $x509->export() );
				// CA-Grunddaten aus dem Zertifikat entnehmen
				$this->setCountryName( $x509->getCountryName() );
				$this->setStateOrProvinceName( $x509->getStateOrProvinceName() );
				$this->setLocalityName( $x509->getLocalityName() );
				$this->setOrganizationName( $x509->getOrganizationName() );
				$this->setOrganizationalUnitName( $x509->getOrganizationalUnitName() );
				$this->setCommonName( $x509->getCommonName() );
				$this->setEmailAddress( $x509->getEmailAddress() );
				// Seriennummer um eins erhöht aus dem X.509-Zertifikat setzen
				$this->serial = $x509->getSerial()+1;
			} else
				// Privater Schlüssel und X.509-Zertifikat passen nicht
				throw new Exception( "pCA : Import fehlgeschlagen. Privater Schlüssel".
					" passt nicht zum X.509-Zertifikat" );
			return true;
		}

		private function generate( pCertData $csrdata, pPrivateKey $pkey,
			$days = 1825 ) {
			// Generiert aus Grunddaten und einem privaten Schlüssel das
			// selbsignierte Root-Zertifikat der CA mit der Maximalgültigkeit $days
			if( $days < 1 ) $days = 1825;
			$csr = $pkey->generateCSR( $csrdata );
			// selbstsigniertes X.509-Zertifikat mit Seriennummer 0 erstellen
			$cacert = openssl_csr_sign( $csr->getCSR(), null,
				openssl_pkey_get_private( $pkey->export() ), $days );
			if( !is_resource( $cacert ) )
				throw new Exception( "pCA : Generieren fehlgeschlagen" );
			// Alle Daten der CA löschen
			if( is_object( $this->x509cert ) ) unset( $this->x509cert );
			// X509-Zertifikat reimportieren ( Workaround : kein Downcast in PHP ! )
			$reimport = "";
			openssl_x509_export( $cacert, $reimport, false );
			$this->x509cert = new pX509Cert_DB( $reimport );
			// Privaten Schlüssel
			$this->privkey = $pkey;
			// Daten setzen
			$this->setCountryName( $csrdata->getCountryName() );
			$this->setStateOrProvinceName( $csrdata->getStateOrProvinceName() );
			$this->setLocalityName( $csrdata->getLocalityName() );
			$this->setOrganizationName( $csrdata->getOrganizationName() );
			$this->setOrganizationalUnitName(
				$csrdata->getOrganizationalUnitName() );
			$this->setCommonName( $csrdata->getCommonName() );
			$this->setEmailAddress( $csrdata->getEmailAddress() );
			$this->serial = 1;
			// Fertig
			return true;
		}

		// Öffentliche Methoden

		final function sign( pCSR $csr, $days = 365, $serial = 0 ) {
			// Signiert eine CSR mit dem Wurzelzertifikat und gibt ein X.509-
			// Zertifikat zurück
			// Hinweis : der Parameter serial sollte nur im Notfall genutzt werden !
			if( !is_object( $this->x509cert ) )
				throw new Exception( "pCA : Kein Wurzelzertifikat zum Signieren" );
			if( !is_object( $this->privkey ) )
				throw new Exception( "pCA : Kein privater Schlüssel zum Signieren" );
			if( $days < 1 ) $days = 365;
			// Signieren, $serial als Seriennummer nutzen, sofern möglich
			$usrcert = openssl_csr_sign( $csr->getCSR(), $this->x509cert->export(),
			$this->privkey->export(), $days, array(),
				( $serial > 0 ? $serial : $this->serial ) );
			if( !is_resource( $usrcert ) )
				throw new Exception( "pCA : Signieren fehlgeschlagen" );
			$reimport = "";
			openssl_x509_export( $usrcert, $reimport, false );
			$x509 = new pX509Cert( $reimport );
			openssl_x509_free( $usrcert );
			// Seriennummer erhöhen, wenn nötig
			if( $serial == 0 ) $this->serial = $this->serial+1;
			return $x509;
		}
	}

	// Erweiterung der Klasse pCA für den Datenbankzugriff
	class pCA_DB extends pCA {
		protected $created = 0;		// Zeitpunkt der Erstellung der CA
		protected $modified = 0;	// Zeitpunkt der letzten Bearbeitung

		// geerbten Konstruktor überschreiben
		final function __construct() {
			$constructor_error = false;
			switch( func_num_args() ) {
				case 1 :
					// CA aus der Datenbank laden ( ohne Passwort für den privaten
					// Schlüssel )
					list( $arg1 ) = func_get_args();
					if( get_class( $arg1 ) == "pDatabase"  )
						return $this->loadFromDB( func_get_arg(0) );
					else $constructor_error = true;
					break;
				case 2 :
					list( $arg1, $arg2 ) = func_get_args();
					// CA aus der Datenbank laden ( mit Passwort für den privaten
					// Schlüssel )
					if( get_class( $arg1 ) == "pDatabase" && is_string( $arg2 ) )
						return $this->loadFromDB( $arg1, $arg2 );
					else $constructor_error = true;
					break;
				case 3 :
					list( $arg1, $arg2, $arg3 ) = func_get_args();
					// Geerbten Konstruktor aufrufen
					parent::__construct( $arg1, $arg2, $arg3 ); break;
				case 4 :
					list( $arg1, $arg2, $arg3, $arg4 ) = func_get_args();
					// Geerbten Konstruktor aufrufen
					parent::__construct( $arg1, $arg2, $arg3, $arg4 ); break;
				default : $constructor_error = true; break;
			}
			if( $constructor_error )
				throw new Exception( "pCA_DB : Fehlerhafte Konstruktorparameter" );
		}

		final function getCreated() { return $this->created; }
		final function getModified() { return $this->modified; }

		final function loadFromDB( pDatabase $db, $password = "" ) {
			$query = sprintf( "SELECT X509Cert_ID, privkey, name, description, ".
				"serial, UNIX_TIMESTAMP( created ), UNIX_TIMESTAMP( modified ) ".
				"FROM %s LIMIT 1", DB_CA_TABLE );
			$db->query( $query );
			if( ( $data = $db->fetchRow() ) === false )
				throw new Exception( "pCA : Laden der CA fehlgeschlagen" );
			// X.509-Zertifikat der CA laden
			if( is_object( $this->x509cert ) ) unset( $this->x509cert );
			$this->x509cert = new pX509Cert_DB( $db, (int) $data[0] );
			// Privaten Schlüssel der CA laden
			if( is_object( $this->privkey ) ) unset( $this->privkey );
			$this->privkey = new pPrivateKey( (string) $data[1],
				(string) $password );
			// Name und Beschreibung laden
			$this->setName( $data[2] );
			$this->setDescription( $data[3] );
			// Seriennummer laden
			$this->serial = $data[4];
			// Zeitdaten laden
			$this->created = $data[5];
			$this->modified = $data[6];
			// Grunddaten der CA lesen ( aus dem Issuer-Feld des X.509-Zertifikates )
			$issuer = $this->x509cert->getIssuer();
			$this->setCountryName( $issuer->getCountryName() );
			$this->setStateOrProvinceName( $issuer->getStateOrProvinceName() );
			$this->setLocalityName( $issuer->getLocalityName() );
			$this->setOrganizationName( $issuer->getOrganizationName() );
			$this->setOrganizationalUnitName( $issuer->getOrganizationalUnitName() );
			$this->setCommonName( $issuer->getCommonName() );
			$this->setEmailAddress( $issuer->getEmailAddress() );
			return true;
		}

		final function saveToDB( pDatabase $db ) {
			if( !is_object( $this->x509cert ) )
				throw new Exception( "pCA : Kein Wurzelzertifikat zum Speichern" );
			if( !is_object( $this->privkey ) )
				throw new Exception( "pCA : Kein privater Schlüssel zum Speichern" );
			// Transaktion starten
			$db->beginTransaction();
			try {
				// X.509-Zertifikat speichern lassen
				$this->x509cert->saveToDB( $db );
				// Alle Daten aus der CA-Tabelle löschen
				$query = sprintf( "TRUNCATE %s;", DB_CA_TABLE );
				$db->query( $query );
				// CA in der Datenbank speichern
				$query = sprintf( "INSERT INTO %s ( X509Cert_ID, privkey, ".
					"name, description, serial, created, modified ) VALUES ( ".
					"%u, '%s', '%s', NULLIF( '%s', '' ), %u, %s, NOW() );",
					DB_CA_TABLE, $this->x509cert->getID(), $this->privkey->export(),
					$this->getName(), $this->getDescription(), $this->getSerial(),
					( $this->getCreated() == 0 ? "NOW()" : "FROM_UNIXTIME( ".
					$this->getCreated()." )" ) );
				$db->query( $query );
				if( $this->getCreated() == 0 ) $this->created = time();
				$this->modified = time();
				$db->endTransaction();			// Commit
				return true;
			} catch( Exception $e ) {
				// Fehlerfall, also Transaktion abbrechen
				$db->endTransaction( true );	// Rollback
				return false;
			}
		}

		final function deleteFromDB( pDatabase $db ) {
			$db->beginTransaction();
			try {
				// X.509-Zertifikat löschen lassen
				$this->x509cert->deleteFromDB( $db );
				// Als letztes diese CA löschen
				$query = sprintf( "TRUNCATE %s;", DB_CA_TABLE );
				$db->query( $query );
				$db->endTransaction( false );		// COMMIT
				return true;
			} catch( Exception $e ) {
				$db->endTransaction( true );	// ROLLBACK
				throw $e;
				return false;
			}
		}

	}
?>