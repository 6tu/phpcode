<?php
	// Editor-Komponente
	
  function do_parse_url( $action, $attributes, $content, $params, 
  	&$node_object ) {
  	if( $action == "validate" ) return true;
	return sprintf( "<a href=\"%s\">%s</a>",
	  htmlspecialchars( ( !isset( $attributes["default"] ) ? $content : 
		$attributes["default"] ) ), htmlspecialchars( $content ) );
  }

  function do_convertlinebreaks( $text ) {
	return preg_replace( "/\015\012|\015|\012/", "\n", $text );
  }
	
  function do_stripcontents( $text ) {
	return preg_replace ("/[^\n]/", '', $text);
  }

  function do_parse_img( $action, $attributes, $content, $params, 
	$node_object ) {
	if( $action == "validate") return true;
	return 
	  sprintf( "<img src=\"%s\" alt=\"\">", htmlspecialchars( $content ) );
  }

  require_once( "_stringparser.php" );
  require_once( "_bbcode.php" );

  class pBBParser {
	private $text;				// Quelltext für späteres Parsen
	private $parser;			// Parser-Klasse
	
	function __construct( $text = "" ) {
	  $this->setText( $text );
	  $this->parser = new StringParser_BBCode();
	  // Parser-Initialisierung
	  $this->initialize();
	}
	
	function __destruct() {
	  unset( $this->text );
	  unset( $this->parser );
	}
	
	function getText() { return $this->text; }
	function setText( $text ) { $this->text = $text; }
	
	private function initialize() {
	  $this->parser->addFilter( STRINGPARSER_FILTER_PRE, 
		"$this->convertlinebreaks" );
	  $this->parser->addParser( array( "block", "inline", "link", "listitem" ),
		"htmlspecialchars" );
	  $this->parser->addParser( array( "block", "inline", "link", "listitem" ),
		"nl2br" );
	  $this->parser->addParser( "list", "do_stripcontents" );

	  $this->parser->addCode( "b", "simple_replace", null, array( 
		"start_tag" => "<span class=\"fett\">", "end_tag" => "</span>" ),
		"inline", array( "listitem", "block", "inline", "link" ), array() );
	  $this->parser->addCode( "i", "simple_replace", null, array( 
		"start_tag" => "<span class=\"kursiv\">", "end_tag" => "</span>" ),
		"inline", array( "listitem", "block", "inline", "link" ), array() );
	  $this->parser->addCode( "u", "simple_replace", null, 
		array( "start_tag" => "<span class=\"unterstrichen\">", 
		"end_tag" => "</span>" ), "inline", array( "listitem", "block",
		"inline", "link" ), array() );
	  $this->parser->addCode( "url", "usecontent?", "do_parse_url", 
		array( "usecontent_param" => "default" ), "link", 
		array( "listitem", "block", "inline" ), array( "link" ) );
	  $this->parser->addCode( "link", "usecontent?", 
		"do_parse_url", array(), "link", 
		array( "listitem", "block", "inline" ), array( "link" ) );
	  $this->parser->addCode( "img", "usecontent", "do_parse_img", array(),
		"image", array( "listitem", "block", "inline", "link" ), array() );
	  $this->parser->addCode( "bild", "usecontent", "do_parse_img", array(),
		"image", array( "listitem", "block", "inline", "link" ), array() );
	  $this->parser->setOccurrenceType( "img", "image" );
	  $this->parser->setOccurrenceType( "bild", "image" );
	  $this->parser->setMaxOccurrences( "image", 2 );
	  $this->parser->addCode( "list", "simple_replace", null, 
		array( "start_tag" => "<ul>", "end_tag" => "</ul>"),
		"list", array( "block", "listitem" ), array() );
	  $this->parser->addCode( "*", "simple_replace", null, 
		array( "start_tag" => "<li>", "end_tag" => "</li>"), "listitem",
		array( "list" ), array() );
	  $this->parser->setCodeFlag( "*", "closetag", BBCODE_CLOSETAG_OPTIONAL );
	  $this->parser->setCodeFlag( "*", "paragraphs", false );
	  $this->parser->setCodeFlag( "list", "paragraph_type", 
		BBCODE_PARAGRAPH_BLOCK_ELEMENT );
	  $this->parser->setCodeFlag( "list", "opentag.before.newline", 
		BBCODE_NEWLINE_DROP );
	  $this->parser->setCodeFlag( "list", "closetag.before.newline", 
		BBCODE_NEWLINE_DROP );
	  $this->parser->setParagraphHandlingParameters( "\n\n", "", "" );
	  $this->parser->setRootParagraphHandling( true );
	  $this->parser->setGlobalCaseSensitive( false );
	}
	
	function parse() {
		return $this->parser->parse( $this->text );
	}
	
  }

?>
