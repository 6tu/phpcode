<?php
	require_once( "database.php" );
	require_once( "user.php" );

	// Rechteverwaltung eines Benutzers (immer mit DB-Zugriff)
	class pRights {
		protected $User_ID = 0;							// ID des Benutzers
		protected $is_root = false;					// Benutzer hat root-Rechte
		protected $departements = array();	// Abteilungsrechte
		protected $registrars = array();		// Abteilungen, nur mit Registratur
		protected $notifies = array();			// Abteilungen mit Benachrichtigungen

		final function __construct() {
			$constructor_error = false;
			switch( func_num_args() ) {
				case 1 :
					list( $arg1 ) = func_get_args();
					// Rechte eines Benutzerkontos laden
					if( get_class( $arg1 ) == "pUser" ) $this->User_ID = $arg1->getID();
						else $constructor_error = true;
					break;
				case 2 :
					list( $arg1, $arg2 ) = func_get_args();
					// Rechte eines Benutzerkontos laden ( mit ID )
					if( get_class( $arg1 ) == "pDatabase" && is_integer( $arg2 ) )
						return $this->loadFromDB( $arg1, $arg2 );
					// Rechte eines Benutzerskontos laden ( mit Benutzer )
					elseif( get_class( $arg1 ) == "pDatabase" && get_class( $arg2 ) ==
					"pUser" )
						return $this->loadFromDB( $arg1, $arg2->getID() );
					else $constructor_error = true;
				default : $constructor_error = true; break;
			}
			if( $constructor_error )
				throw new Exception( "pRights : Falscher Konstruktor" );
		}

		final function __destruct() {
			unset( $this->departements );
			unset( $this->registrars );
			unset( $this->notifies );
		}

		// get/set-Methoden
		final function getUserID() { return $this->User_ID; }
		final function isRoot() { return $this->is_root; }
		final function setRoot( $root = false ) { $this->is_root = $root; }
		final function isAdmin( $departement = 0 ) {
			if( $departement == 0 ) return false;
				else return in_array( $departement, $this->departements );
		}
		final function setAdmin( $departement = 0 ) {
			if( $departement <= 0 || $this->isAdmin( $departement ) ) return false;
			// Falls noch Registrar für $departement, dann Registratur löschen
			$this->removeRegistrar( $departement );
			// Abteilungsleiter-Rechte setzen
			array_push( $this->departements, $departement );
			return true;
		}
		final function removeAdmin( $departement = 0 ) {
			$id = array_search( $departement, $this->departements );
			if( $id !== false ) unset( $this->departements[$id] );
		}
		final function getAdminDepartements() {
			$result = $this->departements;
			return $result;
		}

		final function isRegistrar( $departement = 0 ) {
			if( $departement == 0 ) return false;
			else return in_array( $departement, $this->registrars );
		}
		final function setRegistrar( $departement = 0 ) {
			if( $departement <= 0 || $this->isRegistrar( $departement ) )
			return false;
			// Falls Abteilungsleiter für $departement, dann dieses Recht löschen
			$this->removeAdmin( $departement );
			// Registratur eintragen
			array_push( $this->registrars, $departement );
			return true;
		}
		final function removeRegistrar( $departement = 0 ) {
			$id = array_search( $departement, $this->registrars );
			if( $id !== false ) unset( $this->registrars[$id] );
		}
		final function getRegistrarDepartements() {
			$result = $this->registrars;
			return $result;
		}

		final function setNotify( $departement = 0 ) {
			// Prüfen, ob für die Abteilung Rechte bestehen
			if( !$this->isAdmin( $departement ) &&
				!$this->isRegistrar( $departement ) ) return false;
			// Benachrichtigung setzen
			if( !$this->isNotified( $departement ) )
			array_push( $this->notifies, $departement );
		}
		final function isNotified( $departement = 0 ) {
			if( $departement == 0 ) return false;
				else return in_array( $departement, $this->notifies );
		}
		final function removeNotify( $departement = 0 ) {
			$id = array_search( $departement, $this->notifies );
			if( $id !== false ) unset( $this->notifies[$id] );
		}

		final function getAdminCount() { return count( $this->departements ); }
		final function getRegistrarCount() { return count( $this->registrars ); }

		// Datenbanksachen
		final function loadFromDB( pDatabase $db, $ID = 0 ) {
			if( $ID <= 0 ) throw new Exception( "pRights : ID ist Null" );
			// Administrationsrechte lesen
			$query = sprintf( "SELECT x.Departement_ID, x.registrar, x.notify, ".
				"z.deleted FROM %s x JOIN %s y ON x.Auth_ID=y.Auth_ID AND y.ID=%u ".
				"LEFT JOIN %s z ON x.Departement_ID=z.ID AND z.deleted=0 ORDER BY ".
				"y.ID, x.Departement_ID;",
				DB_RIGHTS_TABLE, DB_USER_TABLE, $ID, DB_DEPS_TABLE );
			$db->query( $query );
			$this->departements = array();
			$this->registrars = array();
			while( $data = $db->fetchRow() ) {
				list( $dep_id, $registrar, $notify, $deleted ) = $data;
				// Testen auf root-Rechte
				if( $dep_id == 0 && !$this->isRoot() ) {
					$this->setRoot( true );
					break;
				}
				// Testen, ob Abteilungs-Admin
				elseif( $dep_id > 0 && $deleted == 0 && $registrar == 0 )
					$this->setAdmin( $dep_id );
				// Testen, ob Registrar
				elseif( $dep_id > 0 && $deleted == 0 && $registrar > 0 )
					$this->setRegistrar( $dep_id );
				// Benachrichtung für die Abteilung ?
				if( $deleted == 0 && $notify > 0 ) $this->setNotify( $dep_id );
			}
			// Fertig
			$this->User_ID = $ID;
			return true;
		}

		final function saveToDB( pDatabase $db ) {
			if( $this->getUserID() == 0 )
				throw new Exception( "pRights : Null-ID beim Speichern der Rechte" );
			$db->beginTransaction();
			try {
				// ID des Benutzernamen/Passwort-Paares ermitteln
				$query = sprintf( "SELECT Auth_ID FROM %s WHERE ID=%u;",
					DB_USER_TABLE, $this->getUserID() );
				$db->query( $query );
				$auth_id = $db->fetchRow(0);
				// Wenn Benutzer noch aktiv, dann Rechte speichern
				if( $auth_id > 0 ) {
					// Alle Rechte löschen
					$this->deleteFromDB( $db );
					// root-Rechte speichern
					if( $this->isRoot() ) {
						$query = sprintf( "INSERT INTO %s VALUES ( %u, NULL, 0, 0 );",
							DB_RIGHTS_TABLE, $auth_id );
						$db->query( $query );
					} else {
						// Rechte an Abteilungen speichern
						foreach( $this->departements as $index => $departement ) {
							$query = sprintf( "INSERT INTO %s VALUES ( %u, %u, 0, %u ) ON ".
								"DUPLICATE KEY UPDATE registrar=0;",
								DB_RIGHTS_TABLE, $auth_id, $departement,
								$this->isNotified( $departement ) );
							$db->query( $query );
						}
						// Registraturen speichern
						foreach( $this->registrars as $index => $departement ) {
							$query = sprintf( "INSERT INTO %s VALUES ( %u, %u, 1, %u ) ON ".
								"DUPLICATE KEY UPDATE registrar=1;",
								DB_RIGHTS_TABLE, $auth_id, $departement,
								$this->isNotified( $departement ) );
							$db->query( $query );
						}
					}
					// Benutzer wurde modifiziert, also Datum speichern
					$query = sprintf( "UPDATE %s SET modified=NOW() WHERE ID=%u;",
						DB_USER_TABLE, $this->getUserID() );
					$db->query( $query );
				}
				// Transaktion beenden
				$db->endTransaction( false );	// COMMIT
			} catch( Exception $e ) {
				$db->endTransaction( true );	// ROLLBACK
				return false;
			}
			return true;
		}

		final function deleteFromDB( pDatabase $db ) {
			if( $this->getUserID() == 0 )
				throw new Exception( "pRights : Null-ID beim Löschen der Rechte" );
			// Alle Rechte löschen
			$query = sprintf( "DELETE FROM %s USING %1\$s, %s WHERE %1\$s.Auth_ID=".
				"%2\$s.Auth_ID AND %2\$s.ID=%u;",
				DB_RIGHTS_TABLE, DB_USER_TABLE, $this->getUserID() );
			$db->query( $query );
			return true;
		}

	}
?>