<?php
	// Klasse zur Darstellung einer Tabelle
	class pTable {
		protected $title = "";				// Tabellenname
		protected $columns = array();	// Spaltenköpfe
		protected $rows = array();		// Datenzeilen
		protected $maxpage;						// Maximalanzahl an Seiten
		protected $page;							// aktuell angezeigte Seite
		protected $sortcolumn = -1;		// Spalte, nach der sortiert wurde
		protected $sortdirection;			// Sortierrichtung
		protected $params = array();	// Zusätzliche Parameter
		protected $caption = "";			// Tabellenüberschrift ( optional )

		final function __construct( $title = "", $page = 1, $maxpage = 1 ) {
			$this->title = $title;
			$this->page = ( $page > $maxpage ? $maxpage : $page );
			$this->maxpage = $maxpage;
		}

		final function addColumn( $title, $width = "10%", $clickable = false,
			$center = true ) {
			array_push( $this->columns, array(
				"title" => $title,
				"width" => $width,
				"clickable" => $clickable,
				"center" => $center
			) );
		}

		final function addRow( $row ) {
			if( is_array( $row ) && count( $row) == count( $this->columns ) )
				array_push( $this->rows, $row );
		}

		final function setCaption( $caption ) {
			$this->caption = $caption;
		}

		final function setSort( $index = 0, $direction = "asc" ) {
			$this->sortcolumn = $index;
			$this->sortdirection = ( $direction == "asc" || $direction == "desc" ?
				$direction : "asc" );
		}
		final function addParam( $name, $param ) {
			if( !empty( $name ) && !empty( $param ) )
				array_push( $this->params, "$name=$param" );
		}

		// Ausgabe
		final function parse() {
			$output = "<table class=\"liste\" cellpadding=\"0\" cellspacing=\"0\"".
				"border=\"0\">\n";
			// ( optional ) : Tabellenüberschrift ( für Legenden usw. )
			if( !empty( $this->caption ) )
				$output .= "<caption>".$this->caption."</caption>\n";
			// 1. Name der Tabelle
			$output .= sprintf( "<tr>\n\t<td colspan=\"5\" class=\"title\">%s</td>".
				"\n</tr>\n", $this->title );
			// 2. Datenbereich der Tabelle
			$output .= "<tr>\n\t<td colspan=\"5\" class=\"data\">\n";
			$output .= "\t<table class=\"data\">\n";
			// 2.a) Spaltenköpfe
			$extraparams = implode( "&", $this->params );
			if( !empty( $extraparams ) ) $extraparams .= "&";
			$output .= "\t<thead>\n\t<tr>\n";
			foreach( $this->columns as $index => $column ) {
				$output .= sprintf( "\t\t<th style=\"width:%s\"", $column["width"] );
				if( $column["clickable"] ) $output .= sprintf( " onclick=\"location.".
					"href='%s?%sorderby=%s&order=%s&page=%u'\"",
					$_SERVER["PHP_SELF"], $extraparams, $index,
					( $index == $this->sortcolumn ? ( $this->sortdirection == "asc" ?
						"desc" : "asc" ) : "asc" ), $this->page );
				$output .= sprintf( ">%s%s</th>\n",
					( $index == $this->sortcolumn ? ( $this->sortdirection == "asc" ?
						"&dArr;" : "&uArr;" ) : "" ), $column["title"] );
			};
			$output .= "\t</tr>\n\t</thead>\n\t<tfoot></tfoot>\n";
			// 2.b) Datenzeilen
			$output .= "\t<tbody>\n";
			if( count( $this->rows ) == 0 )
				$output .= sprintf( "\t<tr>\n\t\t<td colspan=\"%s\" style=\"text-".
				"align: center;\">Es sind keine Daten zum Anzeigen vorhanden.</td>".
				"\n\t</tr>\n", count( $this->columns ) );
			else
				foreach( $this->rows as $index => $row ) {
					$output .= "\t<tr>\n";
					foreach( $row as $index2 => $rowitem )
						$output .= sprintf( "\t\t<td%s>".$rowitem."</td>\n",
							( $this->columns[$index2]["center"] ? " style=\"text-align: ".
							"center;\"" : "" ) );
					$output .= "\t</tr>\n";
				}
			$output .= "\t</tbody>\n\t</table>\n";
			// 3. Fusszeile mit Navigation
			$output .= "<tr>\n";
			for( $i = 1; $i <= 5; $i++ ) {
				switch( $i ) {
					case 1 :
						$link = ( $this->page > 1 ? sprintf( " onclick=\"location.href='".
							"%s?%sorderby=%u&order=%s&page=1'\"", $_SERVER["PHP_SELF"],
							$extraparams, $this->sortcolumn, $this->sortdirection ) : "" );
						$title = "&lt;&lt;";
						$width = 10;
						break;
					case 2 :
						$link = ( $this->page > 1 ? sprintf( " onclick=\"location.href='".
							"%s?%sorderby=%u&order=%s&page=%u'\"", $_SERVER["PHP_SELF"],
							$extraparams, $this->sortcolumn, $this->sortdirection,
							$this->page-1 ) : "" );
						$title = "&lt;";
						$width = 10;
						break;
					case 3 :
						$link = sprintf( "onclick=\"location.href='%s?%sorderby=%u".
							"&order=%s&page=%u'\"", $_SERVER["PHP_SELF"],
							$extraparams, $this->sortcolumn, $this->sortdirection,
							$this->page );
						$title = sprintf( "%u / %u", $this->page, $this->maxpage );
						$width = 60;
						break;
					case 4 :
						$link = ( $this->page < $this->maxpage ? sprintf( " onclick=\"".
							"location.href='%s?%sorderby=%u&order=%s&page=%u'\"",
							$_SERVER["PHP_SELF"], $extraparams, $this->sortcolumn,
							$this->sortdirection, $this->page+1 ) : "" );
						$title = "&gt;";
						$width = 10;
						break;
					case 5 :
						$link = ( $this->page < $this->maxpage ? sprintf( " onclick=\"".
							"location.href='%s?%sorderby=%u&order=%s&page=%u'\"",
							$_SERVER["PHP_SELF"], $extraparams, $this->sortcolumn,
							$this->sortdirection, $this->maxpage ) : "" );
						$title = "&gt;&gt;";
						$width = 10;
						break;
				}
				$output .= sprintf( "\t<td class=\"nav\" style=\"width:%u%%\"%s>%s".
					"</td>\n", $width, $link, $title );
			}
			$output .= "</tr>\n";
			// Fertig
			$output .= "</table>\n";
			return $output;
		}

	}
?>