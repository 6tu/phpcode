<?php
	require_once( "database.php" );
	require_once( "csr.php" );
	require_once( "x509.php" );
	require_once( "user.php" );
	require_once( "ca.php" );

	// Klasse für eine Abteilung einer CA (immer mit DB-Zugriff)
	class pDepartement {
		// Metadaten
		protected $name;						// Name der Abteilung
		protected $description;			// Beschreibung der Abteilung
		// Datenbank
		protected $ID = 0;					// ID der Abteilung in der Datenbank
		protected $deleted = false;	// Abteilung gelöscht oder nicht
		protected $created = 0;			// Zeitpunkt der Erstellung der Abteilung
		protected $modified = 0;		// Zeitpunkt der letzten Bearbeitung

		// Konstruktor
		final function __construct() {
			$constructor_error = false;
			switch( func_num_args() ) {
				case 1 :
					list( $arg1 ) = func_get_args();
					// Name der Abteilung, aber keine Beschreibung
					$this->setName( $arg1 );
					$this->setDescription( "" );
					return true;
				case 2 :
					list( $arg1, $arg2 ) = func_get_args();
					// 1. Möglichkeit : Abteilung aus der Datenbank lesen
					if( get_class( $arg1 ) == "pDatabase" && is_integer( $arg2 ) ) {
						return $this->loadFromDB( $arg1, $arg2 );
						// 2. Möglichkeit : Name der Abteilung und Beschreibung
					} elseif( is_string( $arg1 ) && is_string( $arg2 ) ) {
						$this->setName( $arg1 );
						$this->setDescription( $arg2 );
						return true;
					} else $constructor_error = true;
					break;
				default : $constructor_error = true; break;
			}
			if( $constructor_error )
				throw new Exception( "pDepartement : Fehlerhafter Konstruktor" );
		}

		// set-Funktionen
		final function setName( $dep_name ) {
			if( empty( $dep_name ) )
				throw new Exception( "pDepartement : Name der Abteilung ist leer" );
			$this->name = $dep_name;
		}
		final function setDescription( $description ) {
			$this->description = $description;
		}
		// get-Funktionen
		final function getID() { return $this->ID; }
		final function getName() { return $this->name; }
		final function getDescription() { return $this->description; }
		final function isDeleted() { return $this->deleted; }
		final function getCreated() { return $this->created; }
		final function getModified() { return $this->modified; }

		// Datenbanksachen

		final function registerX509Cert( pDatabase $db, pCSR_DB $csr,
			pX509Cert_DB $x509, pUser $user ) {
			// Registriert ein X.509-Zertifikat für die Abteilung
			if( $this->getID() <= 0 )
				throw new Exception( "pDepartement : ID der Abteilung ist Null" );
			if( $csr->getID() <= 0 )
				throw new Exception( "pDepartement : ID der CSR ist Null" );
			if( $x509->getID() <= 0 )
				throw new Exception( "pDepartement : ID des Zertififikates ist Null" );
			if( $user->getID() <= 0 )
				throw new Exception( "pDepartement : Benutzer-ID ist Null" );
			// Datenbanktransaktion starten
			$db->beginTransaction();
			try {
				// X.509-Zertifikat für die Abteilung vermerken
				$query = sprintf( "INSERT INTO %s VALUES( %u,NULLIF( %u, 0 ) ".
					",%u, NULLIF( %u, 0 ) ) ON DUPLICATE KEY UPDATE CSR_ID=NULLIF( ".
					"%3\$u, 0 ), User_ID=NULLIF( %5\$u, 0 );",
					DB_CERTS_TABLE, $this->getID(), $csr->getID(), $x509->getID(),
					$user->getID() );
				$db->query( $query );
				// Fertig
				$db->endTransaction();			// COMMIT
				return true;
			} catch( Exception $e ) {
				$db->endTransaction( true );	// ROLLBACK
				return false;
			}
		}

		final function registerCSR( pDatabase $db, pCSR_DB $csr ) {
		// Vermerkt eine CSR für die Abteilung zum Signieren
			if( $this->getID() <= 0 )
				throw new Exception( "pDepartement : ID der Abteilung ist Null" );
			if( $csr->getID() <= 0 )
				throw new Exception( "pDepartement : ID der CSR ist Null" );
			// Datenbanktransaktion starten
			$db->beginTransaction();
			try {
				// CSR für die Abteilung vermerken
				$query = sprintf( "INSERT INTO %s VALUES( %u, %u );",
					DB_CSRS_TABLE, $this->getID(), $csr->getID() );
				$db->query( $query );
				// Fertig
				$db->endTransaction();			// COMMIT
				return true;
			} catch( Exception $e ) {
				$db->endTransaction( true );	// ROLLBACK
				return false;
			}
		}

		final function unregisterCSR( pDatabase $db, pCSR_DB $csr ) {
			if( $this->getID() <= 0 )
				throw new Exception( "pDepartement : ID der Abteilung ist Null" );
			if( $csr->getID() <= 0 )
				throw new Exception( "pDepartement : ID der CSR ist Null" );
			// Datenbanktransaktion starten
			$db->beginTransaction();
			try {
				// CSR für die Abteilung entfernen
				$query = sprintf( "DELETE FROM %s WHERE Departement_ID=%u AND ".
					"CSR_ID=%u;",
					DB_CSRS_TABLE, $this->getID(), $csr->getID() );
				$db->query( $query );
				// Fertig
				$db->endTransaction();			// COMMIT
				return true;
			} catch( Exception $e ) {
				$db->endTransaction( true );	// ROLLBACK
				return false;
			}
		}

		final function loadFromDB( pDatabase $db, $ID ) {
			if( $ID <= 0 )
				throw new Exception( "pDepartement : ID der Abteilung ist Null" );
			$query = sprintf( "SELECT name, description,  deleted, UNIX_TIMESTAMP( ".
				"created ), UNIX_TIMESTAMP( modified ) FROM %s WHERE ID=%u;",
				DB_DEPS_TABLE, $ID );
			$db->query( $query );
			if( ( $data = $db->fetchRow() ) === false )
				throw new Exception( "pDepartement : Laden fehlgeschlagen" );
			$this->setName( $data[0] );
			$this->setDescription( $data[1] );
			$this->deleted = ( $data[2] == "1" );
			$this->created = $data[3];
			$this->modified = $data[4];
			$this->ID = $ID;
			return true;
		}

		final function saveToDB( pDatabase $db ) {
			if( $this->getID() == 0 ) {
				$query = sprintf( "INSERT INTO %s ( name, description, deleted, ".
					"created, modified ) VALUES ( '%s', NULLIF( '%s', '' ), 0, NOW(), ".
					"NOW() );",
					DB_DEPS_TABLE, $this->getName(), $this->getDescription() );
				$db->query( $query );
				$this->ID = $db->lastInsertID();
				$this->created = time();
				$this->modified = time();
				return true;
			} else {
				$query = sprintf( "UPDATE %s SET name='%s', description=NULLIF( '%s',".
					" '' ), deleted=%u, modified=NOW() WHERE ID=%s;",
					DB_DEPS_TABLE, $this->getName(), $this->getDescription(),
					( $this->isDeleted() ? 1 : 0 ), $this->getID() );
				$db->query( $query );
				$this->modified = time();
				return true;
			}
			return false;
		}

		final function deleteFromDB( pDatabase $db, $realdelete = false ) {
			if( $this->getID() == 0 )
				throw new Exception( "pDepartement : Null-ID beim Löschen" );
			if( !$realdelete && !$this->isDeleted() ) {
				$query = sprintf( "UPDATE %s SET deleted=1 WHERE ID=%u;",
					DB_DEPS_TABLE, $this->getID() );
				$db->query( $query );
				$this->deleted = true;
			} elseif( $realdelete ) {
				$query = sprintf( "DELETE FROM %s WHERE ID=%u",
					DB_DEPS_TABLE, $this->getID() );
				$db->query( $query );
			}
			return ( $db->affectedRows() == 1 );
		}

	}
?>