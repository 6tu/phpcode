<?php
	require_once( "certdata.php" );
  
	// Klasse zum Verwalten eines kompletten X.509-Zertifikates
	class pX509Cert extends pCertData {
		protected $handle;			// Ressource des X.509-Zertifikates
		protected $name;				// Name des Zertifikats
		protected $hash;				// Hash des Zertifikats
		protected $version;			// Version bei der Generierung
		protected $serial;			// Seriennummer
		protected $valid_from;	// Unix-Zeitstempel gültig ab
		protected $valid_to;		// Unix-Zeitstempel gültig bis
		protected $issuer;			// Grunddaten der ausstellenden CA
		protected $purposes;		// Verwendungszweck des Zertifikates
	
		function __construct() {
			if( func_num_args() == 1 ) {
				list( $arg1 ) = func_get_args();
				// Import eines Zertifikates
				if( $this->import( $arg1 ) ) return $this->parse();
					else return false;
			} else
				throw new Exception( "pX509Cert : Fehlerhafte Konstruktorparameter" );
		}
	
		final function __destruct() {
			if( is_resource( $this->handle ) ) openssl_x509_free( $this->handle );
		}

		// get-Methoden
  
		final function getName() { return $this->name; }
		final function getHash() { return $this->hash; }
		final function getVersion() { return $this->version; }
		final function getSerial() { return $this->serial; }
		final function getValidFrom() { return $this->valid_from; }
		final function getValidTo() { return $this->valid_to; }
		final function getIssuer() { return $this->issuer; }
		final function getPurposes() { return $this->purposes; }

		// Private Methoden
	
		protected function import( $cert ) {
		// Privat : Import eines Zertifikates aus einer Zeichenkette oder ähnliches
			$newhandle = openssl_x509_read( $cert );
			if( !is_resource( $newhandle ) ) return false;
			if( is_resource( $this->handle ) ) openssl_x509_free( $this->handle );
			$this->handle = $newhandle;
			return true;
		}
	
		protected function parse() {
		// Privat : Parset die Daten des Zertifikates aus und setzt die Objekt-
		// eigenschaften dementsprechend
			if( !is_resource( $this->handle ) )
				throw new Exception( "pX509Cert : Keine Ressource zum Parsen" );
			$data = openssl_x509_parse( $this->handle, false );
			// Daten des Zertifikates
			$this->name = $data["name"];
			$this->hash = $data["hash"];
			$this->version = $data["version"];
			$this->serial = $data["serialNumber"];
			$this->valid_from = $data["validFrom_time_t"];
			$this->valid_to = $data["validTo_time_t"];
			// Eigene Grunddaten
			$this->setCountryName( $data["subject"]["countryName"] );
			$this->setStateOrProvinceName( $data["subject"]["stateOrProvinceName"] );
			$this->setLocalityName( $data["subject"]["localityName"] );
			$this->setOrganizationName( $data["subject"]["organizationName"] );
			$this->setOrganizationalUnitName(
				$data["subject"]["organizationalUnitName"] );
			$this->setCommonName( $data["subject"]["commonName"] );
			$this->setEmailAddress( $data["subject"]["emailAddress"] );
			// Grunddaten der CA, die das Zertifkat ausgestellt hat
			if( is_object( $this->issuer ) ) unset( $this->issuer );
			$this->issuer = new pCertData(
				$data["issuer"]["countryName"],
				$data["issuer"]["stateOrProvinceName"],
				$data["issuer"]["localityName"],
				$data["issuer"]["organizationName"],
				$data["issuer"]["organizationalUnitName"],
				$data["issuer"]["commonName"],
				$data["issuer"]["emailAddress"] );
			$this->purposes = array();
			foreach( $data["purposes"] as $purposes )
				if( $purposes[1] == "1" ) array_push( $this->purposes, $purposes[2] );
			return true;
		}

		// Öffentliche Methoden
	
		final function export( $notext = false ) {
			// Exportiert das Zertifikat in eine Zeichenkette
			if( !is_resource( $this->handle ) )
				throw new Exception( "pX509Cert : Keine Ressource zum Exportieren" );
			$exportcert = "";
			if( !openssl_x509_export( $this->handle, $exportcert, $notext ) )
				throw new Exception( "pX509Cert : Export fehlgeschlagen" );
			return $exportcert;
		}

  }

	class pX509Cert_DB extends pX509Cert {
		protected $ID = 0;				// ID des Datensatzes in der Datenbank
		protected $created = 0;		// Zeitpunkt der Erstellung
		protected $modified = 0;	// Zeitpunkt der letzten Modifikation
  
		// geerbten Konstruktor erweitern
		final function __construct() {
			$constructor_error = false;
			switch( func_num_args() ) {
				case 1 :
					list( $arg1 ) = func_get_args();
					// Bei einem Parameter die Vaterklasse nutzen
					return parent::__construct( $arg1 );
					break;
				case 2 :
					// Auslesen aus der Datenbank
					list( $arg1, $arg2 ) = func_get_args();
					if( get_class( $arg1 ) == "pDatabase" && is_integer( $arg2 ) )
						return $this->loadFromDB( $arg1, $arg2 );
					else $constructor_error = true;
					break;
				default : $constructor_error = true; break;
			}
			if( $constructor_error )
				throw new Exception( "pX509Cert_DB : Fehlerhafter Konstruktor" );
		}
	
		final function exchange( pX509Cert $x509 ) {
		// Tauscht das Zertifikat aus. Wird nur gebraucht, um ein X.509-Zertifikat
		// zu erneuern
			return $this->import( $x509->export() );
		}

		// Datenbanksachen
  
		final function getID() { return $this->ID; }
		final function getCreated() { return $this->created; }
		final function getModified() { return $this->modified; }
  
		final function loadFromDB( pDatabase $db, $ID ) {
			// Lädt ein X.509-Zertifikat aus der Datenbank
			if( $ID <= 0 )
				throw new Exception( "pX509Cert_DB : Null-ID beim Laden" );
			if( is_resource( $this->handle ) ) openssl_x509_free( $this->handle );
			$query = sprintf( "SELECT certdata, UNIX_TIMESTAMP( created ), ".
				"UNIX_TIMESTAMP( modified ) FROM %s WHERE ID=%s;",
				DB_X509_TABLE, $ID );
			$db->query( $query );
			if( ( $data = $db->fetchRow() ) === false )
				throw new Exception( "pX509Cert_DB : Laden fehlgeschlagen" );
			if( $this->import( $data[0] ) ) {
				$this->parse();
				$this->ID = $ID;
				$this->created = $data[1];
				$this->modified = $data[2];
				return true;
			} else
				throw new Exception( "pX509Cert_DB : Import fehlgeschlagen" );
			return false;
		}
	
		final function saveToDB( pDatabase $db ) {
		// Speichert das X.509-Zertifikat in die Datenbank
			if( !is_resource( $this->handle ) )
				throw new Exception( "pX509Cert_DB : Kein Zertifikat zum Speichern" );
			if( $this->getID() == 0 ) {
				// Neues Zertifikat in die DB speichern
				$query = sprintf( "INSERT INTO %s ( certdata, name, hash, version, ".
					"serial, valid_from, valid_to, purpose, countryName, ".
					"stateOrProvinceName, localityName, organizationName, ".
					"organizationalUnitName, commonName, emailAddress, created, ".
					"modified ) VALUES ( '%s', '%s', '%s', %u, %u, FROM_UNIXTIME( %s".
					" ), FROM_UNIXTIME( %s ), ".str_repeat( "'%s', ", 8 )." NOW(), ".
					"NOW() );",
					DB_X509_TABLE, $this->export(), $this->getName(), $this->getHash(),
					$this->getVersion(), $this->getSerial(), $this->getValidFrom(),
					$this->getValidTo(), implode( ",", $this->getPurposes() ),
					$this->getCountryName(), $this->getStateOrProvinceName(),
					$this->getLocalityName(), $this->getOrganizationName(),
					$this->getOrganizationalUnitName(), $this->getCommonName(),
					$this->getEmailAddress() );
				$db->query( $query );
				$this->ID = $db->lastInsertID();
				$this->created = time();
				$this->modified = time();
				return true;
			} else {
				// Bestehenden Datensatz ändern
				$query = sprintf( "UPDATE %s SET certdata='%s', name='%s', hash='%s'".
					", version=%u, serial=%u, valid_from=FROM_UNIXTIME( %s ), ".
					"valid_to=FROM_UNIXTIME( %s ), purpose='%s', countryName='%s', ".
					"stateOrProvinceName='%s', localityName='%s', organizationName='%s'".
					", organizationalUnitName='%s', commonName='%s', emailAddress='%s',".
					" modified=NOW() WHERE ID=%u;",
					DB_X509_TABLE, $this->export(), $this->getName(), $this->getHash(),
					$this->getVersion(), $this->getSerial(), $this->getValidFrom(),
					$this->getValidTo(), implode( ",", $this->getPurposes() ),
					$this->getCountryName(), $this->getStateOrProvinceName(),
					$this->getLocalityName(), $this->getOrganizationName(),
					$this->getOrganizationalUnitName(), $this->getCommonName(),
					$this->getEmailAddress(), $this->getID() );
				$db->query( $query );
				$this->modified = time();
				return true;
			}
			return false;
		}
	
		final function deleteFromDB( pDatabase $db ) {
		// Löscht das X.509-Zertifikat aus der Datenbank
			if( $this->getID() <= 0 )
				throw new Exception( "pX509Cert_DB : Null-ID beim Löschen" );
			$query = sprintf( "DELETE FROM %s WHERE ID=%s;",
				DB_X509_TABLE, $this->getID() );
			$db->query( $query );
			return ( $db->affectedRows() == 1 );
		}
	
	}

?>