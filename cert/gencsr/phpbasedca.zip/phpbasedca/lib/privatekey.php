<?php
	require_once( "certdata.php" );
	require_once( "csr.php" );

	// Klasse zum Speichern eines privaten Schlüssels ( ohne DB-Zugriff )
	class pPrivateKey {
		protected $handle;					// Ressource für openssl
		protected $password = "";		// Passwort für den privaten Schlüssel
		protected $type;						// Typ des Schlüssels ( RSA, DSA, DH )
		protected $keybits;					// Schlüssellänge in Bits
	
		function __construct() {
			$constructor_error = false;
			switch( func_num_args() ) {
				case 1 :
					list( $arg1 ) = func_get_args();
					if( is_string( $arg1 ) )
						// Import eines PEM-kodierten privaten Schlüssel ( ohne Passwort )
						return $this->import( $arg1 );
					elseif( is_integer( $arg1 ) )
						// Es soll ein neuer privater Schlüssel generiert werden. Die
						// Schlüssellänge ist im Parameter gegeben
						return $this->generate( $arg1 );
					else $constructor_error = true;
				break;
				case 2 :
					list( $arg1, $arg2 ) = func_get_args();
					if( is_string( $arg1 ) && is_string( $arg2 ) )
						// Import eines PEM-kodierten privaten Schlüssel ( mit Passwort )
						return $this->import( $arg1, $arg2 );
					else $constructor_error = true;
					break;
				default : $constructor_error = true;
			}
			if( $constructor_error )
				throw new Exception( "pPrivateKey : Konstruktorparameter falsch" );
		}
	
		function __destruct() {
			if( is_resource( $this->handle ) ) openssl_free_key( $this->handle );
		}

		// get/set-Methoden
		final function setPassword( $password ) { $this->password = $password; }
		final function getPassword() { return $this->password; }
		final function getKeytype() { return $this->type; }
		final function getKeyLength() { return $this->keybits; }
	
		// Private Methoden
  
		protected function import( $key, $password = "" ) {
			// Privat : Import eines Schlüssels aus einer Zeichenkette
			$newkey = ( empty( $password ) ? openssl_pkey_get_private( $key ) :
				openssl_pkey_get_private( $key, $password ) );
			if( is_resource( $newkey ) ) {
				if( is_resource( $this->handle ) ) openssl_free_key( $this->handle );
				$this->handle = $newkey;
				$this->setPassword( $password );
				// Informationen aus dem Schlüssel extrahieren
				$info = openssl_pkey_get_details( $this->handle );
				$this->type = $info["type"];
				$this->keybits = $info["bits"];
				unset( $info );
				return true;
			} else
				throw new Exception( "Import des privaten Schlüssel fehlgeschlagen");
		}

		protected function generate( $keylength = 1024 ) {
			// Privat : Generierung eines neuen Schlüssels
			if( !in_array( $keylength, array( 512, 1024, 2048 ) ) )
				$keylength = 1024;
			$key = openssl_pkey_new( array( "private_key_bits" => $keylength ) );
			if( is_resource( $key ) ) {
				if( is_resource( $this->handle ) ) openssl_free_key( $this->handle );
				$this->handle = $key;
				// Informationen über den neuen Schlüssel eintragen
				$this->type = OPENSSL_KEYTYPE_RSA;
				$this->keybits = $keylength;
				return true;
			} else
				throw new Exception( "Generieren des privaten Schlüssel ".
					"fehlgeschlagen");
		}

		// Öffentliche Methoden

		final function export() {
			// Exportiert den privaten Schlüssel in eine Zeichenkette
			if( !is_resource( $this->handle ) )
				throw new Exception( "pPrivateKey : Ressource zum Exportieren" );
			$exportstring = "";
			$result = ( empty( $this->password ) ? openssl_pkey_export(
			$this->handle, $exportstring ) : openssl_pkey_export( $this->handle,
				$exportstring, $this->password ) );
			if( !$result )
				throw new Exception( "pPrivateKey : Export fehlgeschlagen" );
			return $exportstring;
		}

		final function generateCSR( pCertData $data ) {
		// Generiert eine neue CSR aus den Grunddaten $certdata
			if( !is_resource( $this->handle ) )
				throw new Exception( "pPrivateKey : Keine Ressource für CSR" );
			$dn = array(
				"countryName" => $data->getCountryName(),
				"stateOrProvinceName" => $data->getStateOrProvinceName(),
				"localityName" => $data->getLocalityName(),
				"organizationName" => $data->getOrganizationName(),
				"organizationalUnitName" => $data->getOrganizationalUnitName(),
				"commonName" => $data->getCommonName(),
				"emailAddress" => $data->getEmailAddress() );
			$csr = openssl_csr_new( $dn, $this->handle );
			if( !is_resource( $csr ) )
				throw new Exception( "pPrivateKey : CSR-Erzeugung fehlgeschlagen" );
			$csr_output = "";
			if( !openssl_csr_export( $csr, $csr_output, false ) )
				throw new Exception( "pPrivateKey : CSR-Export fehlgeschlagen" );
			$result = new pCSR( $data->getCountryName(),
				$data->getStateOrProvinceName(), $data->getLocalityName(),
				$data->getOrganizationName(), $data->getOrganizationalUnitName(),
				$data->getCommonName(), $data->getEmailAddress(), $csr_output );
		  return $result;
		}
	
  }
  
?>