<?php
	// Klasse pLog zum Führen eines Logbuches
	
	require_once( "database.php" );
	require_once( "user.php" );
	require_once( "departement.php" );

	class pLog {
		protected $db;
	
		function __construct( pDatabase $db ) { $this->db = $db; }
	
		// Logging, die ganze CA betreffend //////////////////////////////
	
		function logModifyCA( pUser $user ) {
		// Der Benutzer $user hat die Daten der CA geändert
			try {
				$query = sprintf( "INSERT INTO %s ( occured, User_ID, facility, ".
					"action ) VALUES( NOW(), %u, 'ca', 'modify' );",
					DB_LOG_TABLE, $user->getID() );
				$this->db->query( $query );
				return $this->db->lastInsertID();
			} catch( Exception $e ) {
				return false;
			}
		}

		// Logging, eine Abteilung betreffend ////////////////////////////
	
		function logCreateDepartement( pUser $user, pDepartement
			$ref_departement ) {
		// Der Benutzer $user hat die Abteilung $ref_departement erstellt
			try {
				$query = sprintf( "INSERT INTO %s ( occured, User_ID, facility, ".
					"action, ref_Departement_ID ) VALUES( NOW(), %u, 'departement', ".
					"'create', %u );",
					DB_LOG_TABLE, $user->getID(), $ref_departement->getID() );
				$this->db->query( $query );
				return $this->db->lastInsertID();
			} catch( Exception $e ) {
				return false;
			}	
		}
	
		function logModifyDepartement( pUser $user, pDepartement
			$ref_departement ) {
		// Der Benutzer $user hat die Daten der Abteilung $ref_departement geändert
			try {
				$query = sprintf( "INSERT INTO %s ( occured, User_ID, facility, ".
					"action, ref_Departement_ID ) VALUES( NOW(), %u, 'departement', ".
					"'modify', %u );",
					DB_LOG_TABLE, $user->getID(), $departement->getID() );
				$this->db->query( $query );
				return $this->db->lastInsertID();
			} catch( Exception $e ) {
				return false;
			}	
		}
	
		function logDeleteDepartement( pUser $user, pDepartement
			$ref_departement ) {
		// Der Benutzer $user hat die Abteilung $ref_departement gelöscht
			try {
				$query = sprintf( "INSERT INTO %s ( occured, User_ID, facility, ".
					"action, ref_Departement_ID ) VALUES( NOW(), %u, 'departement', ".
					"'delete', %u );",
					DB_LOG_TABLE, $user->getID(), $ref_departement->getID() );
				$this->db->query( $query );
				return $this->db->lastInsertID();
			} catch( Exception $e ) {
				return false;
			}	
		}

		function logNotifyDepartement( pUser $user, pDepartement
			$ref_departement ) {
		// Der Benutzer $user hat die Benachrichtigungseinstellungen der
		// Abteilung $departement geändert
			try {
				$query = sprintf( "INSERT INTO %s ( occured, User_ID, facility, ".
					"action, ref_Departement_ID ) VALUES( NOW(), %u, 'departement', ".
					"'grant', %u );",
					DB_LOG_TABLE, $user->getID(), $ref_departement->getID() );
				$this->db->query( $query );
				return $this->db->lastInsertID();
			} catch( Exception $e ) {
				return false;
			}				
		}
	
		// Logging, die Benutzerverwaltung betreffend ////////////////////
	
		function logCreateUser( pUser $user, pUser $ref_user ) {
		// Der Benutzer $user hat den Benutzer $ref_user erstellt
			try {
				$query = sprintf( "INSERT INTO %s ( occured, User_ID, facility, ".
					"action, ref_User_ID ) VALUES( NOW(), %u, 'user', 'create', %u );",
					DB_LOG_TABLE, $user->getID(), $ref_user->getID() );
				$this->db->query( $query );
				return $this->db->lastInsertID();
			} catch( Exception $e ) {
				return false;
			}	
		}
	
		function logModifyUser( pUser $user, pUser $ref_user ) {
		// Der Benutzer $user hat den Benutzer $ref_user geändert ( z.B.
		// Benutzernamen und/oder Passwort
			try {
				$query = sprintf( "INSERT INTO %s ( occured, User_ID, facility, ".
					"action, ref_User_ID ) VALUES( NOW(), %u, 'user', 'modify', %u );",
					DB_LOG_TABLE, $user->getID(), $ref_user->getID() );
				$this->db->query( $query );
				return $this->db->lastInsertID();
			} catch( Exception $e ) {
				return false;
			}	
		}

		function logDeleteUser( pUser $user, pUser $ref_user ) {
		// Der Benutzer $user hat den Benutzer $ref_user gelöscht, d.h.
		// ihm die Authentifizierungsmöglichkeiten genommen
			try {
				$query = sprintf( "INSERT INTO %s (occured, User_ID, facility, ".
					"action, ref_User_ID ) VALUES( NOW(), %u, 'user', 'delete', %u );",
					DB_LOG_TABLE, $user->getID(), $ref_user->getID() );
				$this->db->query( $query );
				return $this->db->lastInsertID();
			} catch( Exception $e ) {
				return false;
			}	
		}
	
		function logGrantRoot( pUser $user, pUser $ref_user ) {
		// Der Benutzer $user hat dem Benutzer $ref_user root-Rechte gegeben
			try {
				$query = sprintf( "INSERT INTO %s ( occured, User_ID, facility, ".
					"action, ref_User_ID, additional ) VALUES( NOW(), %u, 'user', ".
					"'grant', %u, 'root' );",
					DB_LOG_TABLE, $user->getID(), $ref_user->getID() );
				$this->db->query( $query );
				return $this->db->lastInsertID();
			} catch( Exception $e ) {
				return false;
			}
		}

		function logRevokeRoot( pUser $user, pUser $ref_user ) {
		// Der Benutzer $user hat dem Benutzer $ref_user root-Rechte genommen
			try {
				$query = sprintf( "INSERT INTO %s ( occured, User_ID, facility, ".
					"action, ref_User_ID, additional ) VALUES( NOW(), %u, 'user', ".
					"'revoke', %u, 'root' );",
					DB_LOG_TABLE, $user->getID(), $ref_user->getID() );
				$this->db->query( $query );
				return $this->db->lastInsertID();
			} catch( Exception $e ) {
				return false;
			}	
		}

		function logGrantAdmin( pUser $user, pUser $ref_user, pDepartement
			$ref_departement ) {
			// Der Benutzer $user hat den Benutzer $ref_user für die Abteilung
			// $ref_departement als Abteilungsleiter vorgesehen
			try {
				$query = sprintf( "INSERT INTO %s ( occured, User_ID, facility, ".
					"action, ref_User_ID, ref_Departement_ID, additional ) VALUES( ".
					"NOW(), %u, 'user', 'grant', %u, %u, 'admin' );",
					DB_LOG_TABLE, $user->getID(), $ref_user->getID(),
					$departement->getID() );
				$this->db->query( $query );
				return $this->db->lastInsertID();
			} catch( Exception $e ) {
				return false;
			}
		}

		function logRevokeAdmin( pUser $user, pUser $ref_user, pDepartement
			$ref_departement ) {
		// Der Benutzer $user hat dem Benutzer $ref_user die Abteilungsleiterrechte
		// für die Abteilung $ref_departement genommen
			try {
				$query = sprintf( "INSERT INTO %s ( occured, User_ID, facility, ".
					"action, ref_User_ID, ref_Departement_ID, additional ) VALUES( ".
					"NOW(), %u, 'user', 'revoke', %u, %u, 'admin' );",
					DB_LOG_TABLE, $user->getID(), $ref_user->getID(),
					$departement->getID() );
				$this->db->query( $query );
				return $this->db->lastInsertID();
			} catch( Exception $e ) {
				return false;
			}
		}

		function logGrantRegistrar( pUser $user, pUser $ref_user, pDepartement
			$ref_departement ) {
		// Der Benutzer $user hat den Benutzer $ref_user für die Abteilung
		// $ref_departement als Registrar eingesetzt
			try {
				$query = sprintf( "INSERT INTO %s ( occured, User_ID, facility, ".
					"action, ref_User_ID, ref_Departement_ID, additional ) VALUES( ".
					"NOW(), %u, 'user', 'grant', %u, %u, 'registrar' );",
					DB_LOG_TABLE, $user->getID(), $ref_user->getID(),
					$departement->getID() );
				$this->db->query( $query );
				return $this->db->lastInsertID();
			} catch( Exception $e ) {
				return false;
			}	
		}

		function logRevokeRegistrar( pUser $user, pUser $ref_user, pDepartement
			$ref_departement ) {
			// Der Benutzer $user hat dem Benutzer $ref_user die Registrarrechte
			// für die Abteilung $ref_departement genommen
			try {
				$query = sprintf( "INSERT INTO %s ( occured, User_ID, facility, ".
					"action, ref_User_ID, ref_Departement_ID, additional ) VALUES( ".
					"NOW(), %u, 'user', 'revoke', %u, %u, 'registrar' );",
					DB_LOG_TABLE, $user->getID(), $ref_user->getID(),
					$departement->getID() );
				$this->db->query( $query );
				return $this->db->lastInsertID();
			} catch( Exception $e ) {
				return false;
			}	
		}

	// Logging, die Zertifikatsverwaltung betreffend /////////////////
	
		function logCreateCSR( pUser $user, pCSR_DB $ref_csr, pDepartement
			$ref_departement ) {
		// Der Benutzer $user hat die CSR $csr in der Abteilung $ref_departement
		// erstellt, um sie signieren zu lassen
			try {
				$query = sprintf( "INSERT INTO %s ( occured, User_ID, facility, ".
					"action, ref_CSR_ID, ref_Departement_ID ) VALUES( NOW(), %u, ".
					"'cert', 'create', %u, %u );",
					DB_LOG_TABLE, $user->getID(), $ref_csr->getID(),
					$ref_departement->getID() );
				$this->db->query( $query );
				return $this->db->lastInsertID();
			} catch( Exception $e ) {
				return false;
			}	
		}

		function logDenyCSR( pUser $user, pCSR_DB $ref_csr, pDepartement
			$ref_departement, $reason = "" ) {
		// Der Benutzer $user hat die CSR $csr abgewiesen ( nicht signiert ),
		// und damit die CSR gelöscht. Der Grund steht in additional
			try {
				$query = sprintf( "INSERT INTO %s ( occured, User_ID, facility, ".
					"action, ref_CSR_ID, ref_Departement_ID, additional ) VALUES( NOW(),".
					"%u, 'cert', 'revoke', %u, %u, NULLIF( '%s','' ) );",
					DB_LOG_TABLE, $user->getID(), $ref_csr->getID(),
					$ref_departement->getID(), $reason );
				$this->db->query( $query );
				return $this->db->lastInsertID();
			} catch( Exception $e ) {
				return false;
			}
		}
	
		function logSignCSR( pUser $user, pCSR_DB $ref_csr, pDepartement
			$ref_departement, pX509Cert_DB $ref_x509, $serial = 0 ) {
		/*
		Der Benutzer $user hat die CSR $ref_csr in der Abteilung $ref_departement
		signiert und das X.509-Zertifikat $ref_x509 mit der Seriennumer $serial
		ausgestellt
		*/
			try {
				// Signierung eintragen
				$query = sprintf( "INSERT INTO %s ( occured, User_ID, facility, ".
					"action, ref_CSR_ID, ref_Departement_ID, ref_X509Cert_ID, ".
					"additional ) VALUES( NOW(), %u, 'cert', 'grant', %u, %u, %u, '%u'".
					" );",
					DB_LOG_TABLE, $user->getID(), $ref_csr->getID(),
					$ref_departement->getID(), $ref_x509->getID(), $serial );
				$this->db->query( $query );
				$id = $this->db->lastInsertID();
				// CSR-Datensatz aktualisieren, sodass er später besser anzeigbar ist
				$query = sprintf( "UPDATE %s SET ref_X509Cert_ID=%u WHERE facility=".
					"'cert' AND action='create' AND ref_CSR_ID=%u;",
					DB_LOG_TABLE, $id, $ref_csr->getID() );
				$this->db->query( $query );
				// Fertig
				return $id;
			} catch( Exception $e ) {
				return false;
			}	
		}

		function logRenewX509( pUser $user, pX509Cert_DB $ref_x509, $days = 0 ) {
		// Der Benutzer $user hat das X.509-Zertifikat $ref_x509 erneuert. Die
		// Tage werden in "additional" gespeichert
			try {
				$query = sprintf( "INSERT INTO %s ( occured, User_ID, facility, ".
					"action, ref_X509Cert_ID, additional ) VALUES( NOW(), %u, 'cert', ".
					"'renew', %u, %u );",
					DB_LOG_TABLE, $user->getID(), $ref_x509->getID(), $days );
				$this->db->query( $query );
				return $this->db->lastInsertID();
			} catch( Exception $e ) {
				return false;
			}	
		}
	
		function logDeleteX509( pUser $user, pX509Cert_DB $ref_x509 ) {
		// Der Benutzer $user hat das X.509-Zertifikat $ref_x509 gelöscht
			try {
				$query = sprintf( "INSERT INTO %s ( occured, User_ID, facility, ".
					"action, ref_X509Cert_ID ) VALUES( NOW(), %u, 'cert', 'delete', %u ".
					");",
					DB_LOG_TABLE, $user->getID(), $ref_x509->getID() );
				$this->db->query( $query );
				return $this->db->lastInsertID();
			} catch( Exception $e ) {
				return false;
			}	
		}
	
	}
?>