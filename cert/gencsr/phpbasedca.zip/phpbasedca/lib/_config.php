<?php
	// Spracheinstellungen
	define( LANGUAGE,				"de" );

	// Pfade
	define( IMAGE_PATH,				"/phpbasedca/images" );		// relativ im Webserver !
	define( INCLUDE_PATH,			"/phpbasedca/includes" );	// relativ im Webserver !

	// Konfiguration für den mySQL-Zugang
	define( DB_SERVER,				"localhost" );
	define( DB_USERNAME,			"root" );
	define( DB_PASSWORD,			"phpCA" );
	define( DB_DATABASE,			"phpCA" );

	// Tabellenname
	define( DB_CSR_TABLE,			"csr" );							// Speicherung der CSRs
	define( DB_X509_TABLE,			"x509" );							// X.509-Zertifikate
	define( DB_CA_TABLE,			"ca" );								// Daten der CA
	define( DB_USER_TABLE,			"users" );						// alle Benutzer
	define( DB_AUTH_TABLE,			"auth" );							// Authentifizierung
	define( DB_CERTS_TABLE,			"departement_x509" );	// Zuordnung Abteilung-X509
	define( DB_CSRS_TABLE,			"departement_csr" );	// Zuordnung Abteilung-CSR
	define( DB_DEPS_TABLE,			"departements" );			// Abteilungen einer CA
	define( DB_RIGHTS_TABLE,		"rights" );						// allg. Admin-Rechte
	define( DB_LOG_TABLE,			"log" );							// Logbuch

	// Listengrenzen für die Tabellen
	define( LIST_DEPS,				50 );
	define( LIST_USER,				50 );
	define( LIST_CERTS,				50 );
	define( LIST_CSRS,				50 );
	define( LIST_LOG,				50 );

?>