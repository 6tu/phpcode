<?php
	// Fehlerklasse für pCertData
	class eCertData extends Exception {

		final function __toString() {
			$error = "pCertData error : ";
			switch( $this->code ) {
				case 1 : $error .= "constructor error"; break;
				case 2 : $error .= "empty countryName"; break;
				case 3 : $error .= "empty stateOrProvinceName"; break;
				case 4 : $error .= "empty localityName"; break;
				case 5 : $error .= "empty organizationName"; break;
				case 6 : $error .= "empty organizationalUnitName"; break;
				case 7 : $error .= "empty commonName"; break;
				case 8 : $error .= "empty emailAddress"; break;
				default : $error = parent::__toString(); break;
			}
			// Trace anhängen
			$error .= "Trace : ".$this->getTraceAsString();
			return $error;
		}

	}

	// Klasse zum Speichern für Grunddaten
	class pCertData {
		// nachfolgend Grunddaten eines Zertifikates oder einer CSR
		protected $countryName = "";
		protected $stateOrProvinceName = "";
		protected $localityName = "";
		protected $organizationName = "";
		protected $organizationalUnitName = "";
		protected $commonName = "";
		protected $emailAddress = "";

		function __construct() {
		// Konstruktor
			if( func_num_args() == 7 ) {
				list( $arg1, $arg2, $arg3, $arg4, $arg5, $arg6, $arg7 ) =
					func_get_args();
				$this->setCountryName( $arg1 );
				$this->setStateOrProvinceName( $arg2 );
				$this->setLocalityName( $arg3 );
				$this->setOrganizationName( $arg4 );
				$this->setOrganizationalUnitName( $arg5 );
				$this->setCommonName( $arg6 );
				$this->setEmailAddress( $arg7 );
			} else throw new eCertData( "", 1 );
		}

		// set-Funktionen, alle protected

		protected function setCountryName( $countryName ) {
			if( empty( $countryName ) ) throw new eCertData( "", 2 );
			$this->countryName = $countryName;
		}

		protected function setStateOrProvinceName( $stateOrProvinceName ) {
			if( empty( $stateOrProvinceName ) ) throw new eCertData( "", 3 );
			$this->stateOrProvinceName = $stateOrProvinceName;
		}

		protected function setLocalityName( $localityName ) {
			if( empty( $localityName ) ) throw new eCertData( "", 4 );
			$this->localityName = $localityName;
		}

		protected function setOrganizationName( $organizationName ) {
			if( empty( $organizationName ) ) throw new eCertData( "", 5 );
			$this->organizationName = $organizationName;
		}

		protected function setOrganizationalUnitName( $organizationalUnitName ) {
			if( empty( $organizationalUnitName ) ) throw new eCertData( "", 6 );
			$this->organizationalUnitName = $organizationalUnitName;
		}

		protected function setCommonName( $commonName ) {
			if( empty( $commonName ) ) throw new eCertData( "", 7 );
			$this->commonName = $commonName;
		}

		protected function setEmailAddress( $emailAddress ) {
			if( empty( $emailAddress ) ) throw new eCertData( "", 8 );
			$this->emailAddress = $emailAddress;
		}

		// get-Funktionen, alle public

		final function getCountryName() { return $this->countryName; }
		final function getStateOrProvinceName() {
			return $this->stateOrProvinceName; }
		final function getLocalityName() { return $this->localityName; }
		final function getOrganizationName() { return $this->organizationName; }
		final function getOrganizationalUnitName() {
			return $this->organizationalUnitName; }
		final function getCommonName() { return $this->commonName; }
		final function getEmailAddress() { return $this->emailAddress; }

	}
?>