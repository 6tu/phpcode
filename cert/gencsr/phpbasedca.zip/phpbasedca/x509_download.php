<?php
	/*
	Lädt das X.509-Zertifikat der CA herunter
	Parameter :
	1.	format = "crt" : Download als Base64-kodiertes Zertifikat ohne Zusätze
			format = "pem" : Download als ASCII-Datei mit Zusatzinformationen
	*/
  
	// Parameter auswerten
	$format = $_REQUEST["format"];

	switch( $format ) {
		case "pem" :
			header( "Content-Type: application/x-x509-ca-cert" );
			header( "Content-Disposition: attachment; filename=x509Cert.pem" );
			break;
		default :
			header( "Content-Type: application/x-x509-ca-cert" );
			header( "Content-Disposition: attachment; filename=x509Cert.crt" );
			break;
 	}

	require_once( "./lib/database.php" );
	require_once( "./lib/_config.php" );
	require_once( "./lib/x509.php" );
	require_once( "./lib/ca.php" );
  
	// Datenbankverbindung aufbauen
	$db = new pDatabase( DB_SERVER, DB_USERNAME, DB_PASSWORD );
	$db->selectDatabase( DB_DATABASE );
  
	try {
		// X.509-Zertifikat der CA laden und an den Browser senden
		$ca = new pCA_DB( $db );
		$x509 = $ca->getX509Cert();
		switch( $format ) {
			case "pem" : print $x509->export(); break;
			default    : print $x509->export( true ); break;
		}
	} catch( Exeception $e ) {
		print "Fehler beim Herunterladen des Zertifikates.";
	}
  
?>