// BB-Code

// Ermittelt den markierten Text; 1. Parameter gibt das <TEXTAREA>-Feld an
function getSelText( textarea ) {
	var editor = document.getElementById( textarea );
	// IE
	if( document.selection ) {
		return document.selection.createRange().text;
	// Gecko
	} else if( window.getSelection ) {
		var anfang = editor.selectionStart;
		var ende = editor.selectionEnd;
		if( ende ) return editor.value.substring( anfang, ende );
	}
	return "";
}

// Fügt Text ein; 1. Parameter gibt das <TEXTAREA>-Feld an
function addText( textarea, aTag, eTag, aText ) {
	var editor = document.getElementById( textarea );
	// Schauen, ob Text selektiert ist, der ersetzt werden muss
	if( document.selection ) {
		// IE Style
		var range = document.selection.createRange();
		var insText = range.text;
		if( insText.length == 0 ) insText = aText;
		range.text = aTag+insText+eTag;
		range = document.selection.createRange();
		( insText.length == 0 ) ? range.move( 'character', -eTag.length ) :
			range.moveStart( 'character', aTag.length+insText.length+eTag.length );
		range.select();
	} else if( window.getSelection ) {
		// Gecko Style
		var start = editor.selectionStart;
		var ende = editor.selectionEnd;
		var insText = editor.value.substring( start, ende );
		if( insText.length == 0 ) insText = aText;
		editor.value = editor.value.substr( 0, start )+aTag+insText+eTag+
			editor.value.substr( ende );
		var pos = ( insText.length == 0 ) ? start+aTag.length : start+aTag.length+
			insText.length+eTag.length;
		editor.selectionStart = pos;
		editor.selectionEnd = pos;
	}
	editor.focus();
}

// Eingabe eines einfachen BBCodes ( [B], [I], [U] )
function simpleCode( textarea, aCode ) {
	var editor = document.getElementById( textarea );
	editor.focus();
	insertText = prompt( 'Geben Sie den Text ein :'+'\n['+aCode+']<Text>[/'+
		aCode+']', getSelText( textarea) );
	if( ( insertText != null ) && ( insertText != '' ) )
		addText( textarea, '['+aCode+']', '[/'+aCode+']', insertText );
}

// Eingabe einer eMail-Adresse
function emailCode( textarea ) {
	var aText = getSelText( textarea );
	linkText = prompt( 'Geben Sie den Verknüpfungstext ein :', aText );
	linkURL = prompt( 'Geben Sie eine E-Mail-Adresse ein :', 'mailto:' );
	if( ( linkURL != null ) && ( linkURL != '' ) ) {
		if( ( linkText != null ) && ( linkText != '' ) ) {
			addText( textarea, '[link='+linkURL+']', '[/link]', linkText );
		} else {
			addText( textarea, '[link]', '[/link]', linkURL );
		}
	}
}

// Eingabe einer URL
function urlCode( textarea ) {
	var aText = getSelText( textarea );
	linkText = prompt( 'Geben Sie den Verknüpfungstext ein :', aText );
	linkURL = prompt( 'Geben Sie eine URL ein :', 'http://' );
	if( ( linkURL != null ) && ( linkURL != '' ) ) {
		if( ( linkText != null ) && ( linkText != '' ) ) {
			addText( textarea, '[url='+linkURL+']', '[/url]', linkText );
		} else {
			addText( textarea, '[link]', '[/link]', linkURL );
		}
	}
}

// Eingabe einer Liste
function listCode( textarea ) {
	var aText = "";
	var aList = "";
	do {
		aText = prompt( 'Geben Sie einen Listenpunkt ein. Zum Beenden das '+
			'Eingabefeld leer lassen.', '' );
		if( ( aText != null ) && ( aText != '' ) ) aList = aList+'[*]'+aText;
	} while( ( aText != null ) && ( aText != '' ) );
	if( aList != '' ) addText( textarea, '[list]', '[/list]', aList );
}