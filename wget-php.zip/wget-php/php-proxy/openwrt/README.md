Makefile for openwrt package build   
So far config json file in /etc/php-proxy/php-proxy.json is not used,feature will be fixed 
