<?php
// print_r($argv);
$parameter = array('-f', '-u');
if(empty($argv[1]) or !in_array($argv[1], $parameter)) die("\r\n    usage: php nojs.php -f file or -u url");
if(empty($argv[2])) die("\r\n    û��⵽�ڶ�����������Ӧ����һ���ļ�����URL");
$dir = getcwd();
$time = date('YmdH'); // $time = date('YmdHis');
if($argv[1] === '-f') $file = $argv[2];

# ���������ļ�
$mime = '';
if($argv[1] === '-u'){
    $url = $argv[2];
    $fn_key = str_pad(crc32($url), 10, '0'); # CRC32�������: 8-9-10λ
    $info_url = parse_url($url);
    if(!empty($info_url['path'])) $info_path = pathinfo($info_url['path']);
    else $info_path = '';
    if(!empty($info_path['filename'])) $file = $time .'-'. $info_path['filename'];
    else $file = $time .'-'. $fn_key;
    if(!empty($info_path['extension'])) $ext = $info_path['extension'];
    else $ext = '';
    # wget�����޺�׺�ļ������ļ�
    $cmd = 'wget --html-extension --adjust-extension -O '. $file .' '. $url .' 2>&1';
    exec($cmd, $out, $status);
    // print_r($out);
    foreach($out as $key => $value){
        if($key > 11) break;
        echo '['. $key .'] => '. $value ."\r\n";
        if(strpos($value, 'Length') !== false) $mime = substr($value, strrpos($value, '[')+1, -1);
        if(strpos($value, 'Saving to') !== false){
            $file1 = substr($value, strpos($value, "'")+1, -1);
            rename($file, $file1);
            $file = $file1;
        }
    }
    if(empty($mime)) die('û��⵽ Mime Type �������ܴ��ڴ��������ֹ');
    if($mime != 'text/html'){
        $ext = mime2ext($mime);
        rename($file, $file .'.'. $ext);
        $file .= '.'. $ext;
    }
    # �����ѹ���������ѹ�������ļ���
    if(strpos($file, 'html.gz') !== false and $mime == 'text/html'){
        $html = file_get_contents("compress.zlib://". $file);
        unlink($file);
        $file = substr($file, 0, -3);
        file_put_contents($file, $html);
    }
}

# ���������ļ�
$html = file_get_contents($file);
$mime = mime_content_type($file);
if($mime === 'text/html'){
    $search = array("'<script[^>]*?>.*?</script>'si",     # ȥ��javascript
                    "'<style[^>]*?>.*?</style>'si",       # ȥ��css
                    "'<meta[/!]*?[^<>]*?>'si",            # ȥ��meta
                    );
    $replace = array("", "", "",);

    $html = preg_replace("'<script[^>]*?>.*?</script>'si", '', $html);
    $html = preg_replace('/\r/', '', $html);
    $html = preg_replace('/\t/', '    ', $html);
    $html = beautify_html($html);
    file_put_contents($file, $html);
}

$ext = mime2ext($mime);
if($ext === 'htm') $ext = 'html';
$info_path = pathinfo($file);
$file1 = $info_path['filename'] .'.'. $ext;
rename($file, $file1);

echo "\r\n    all done\r\n";


/**
 * ============================ �������֣������޸� ============================
 */
# HTML ��ʽ��
function beautify_html($html){
    require_once 'php\beautify-html.php';
    $beautify_config = array(
        'indent_inner_html' => false,
        'indent_char' => " ",
        'indent_size' => 2,
        'wrap_line_length' => 32786,
        'unformatted' => ['code', 'pre'],
        'preserve_newlines' => false,
        'max_preserve_newlines' => 32786,
        'indent_scripts'    => 'normal', // keep|separate|normal
        );
    $beautify = new Beautify_Html($beautify_config);
    $html = $beautify->beautify($html);
    return $html;
}

function mime2ext($mime){
    $ext2mime = array(
            "dwg"        =>    "application/acad",
            "ez"         =>    "application/andrew-inset",
            "ccad"       =>    "application/clariscad",
            "drw"        =>    "application/drafting",
            "tsp"        =>    "application/dsptype",
            "dxf"        =>    "application/dxf",
            "epub"       =>    "application/epub+zip",
            "gz"         =>    "application/gzip",
            "unv"        =>    "application/i-deas",
            "jar"        =>    "application/java-archive",
            "json"       =>    "application/json",
            "jsonld"     =>    "application/ld+json",
            "hqx"        =>    "application/mac-binhex40",
            "cpt"        =>    "application/mac-compactpro",
            "pot"        =>    "application/mspowerpoint",
            "pps"        =>    "application/mspowerpoint",
            "ppt"        =>    "application/mspowerpoint",
            "ppz"        =>    "application/mspowerpoint",
            "doc"        =>    "application/msword",
            "bin"        =>    "application/octet-stream",
            "class"      =>    "application/octet-stream",
            "dms"        =>    "application/octet-stream",
            "exe"        =>    "application/octet-stream",
            "lha"        =>    "application/octet-stream",
            "lzh"        =>    "application/octet-stream",
            "oda"        =>    "application/oda",
            "ogx"        =>    "application/ogg",
            "pdf"        =>    "application/pdf",
            "ai"         =>    "application/postscript",
            "eps"        =>    "application/postscript",
            "ps"         =>    "application/postscript",
            "prt"        =>    "application/pro_eng",
            "rtf"        =>    "application/rtf",
            "set"        =>    "application/set",
            "stl"        =>    "application/SLA",
            "smi"        =>    "application/smil",
            "smil"       =>    "application/smil",
            "sol"        =>    "application/solids",
            "step"       =>    "application/STEP",
            "stp"        =>    "application/STEP",
            "vda"        =>    "application/vda",
            "azw"        =>    "application/vnd.amazon.ebook",
            "mpkg"       =>    "application/vnd.apple.installer+xml",
            "mif"        =>    "application/vnd.mif",
            "xul"        =>    "application/vnd.mozilla.xul+xml",
            "xlc"        =>    "application/vnd.ms-excel",
            "xll"        =>    "application/vnd.ms-excel",
            "xlm"        =>    "application/vnd.ms-excel",
            "xls"        =>    "application/vnd.ms-excel",
            "xlw"        =>    "application/vnd.ms-excel",
            "eot"        =>    "application/vnd.ms-fontobject",
            "ppt"        =>    "application/vnd.ms-powerpoint",
            "odp"        =>    "application/vnd.oasis.opendocument.presentation",
            "ods"        =>    "application/vnd.oasis.opendocument.spreadsheet",
            "odt"        =>    "application/vnd.oasis.opendocument.text",
            "pptx"       =>    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            "xlsx"       =>    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "docx"       =>    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "rar"        =>    "application/vnd.rar",
            "vsd"        =>    "application/vnd.visio",
            "7z"         =>    "application/x-7z-compressed",
            "abw"        =>    "application/x-abiword",
            "bcpio"      =>    "application/x-bcpio",
            "bz"         =>    "application/x-bzip",
            "bz2"        =>    "application/x-bzip2",
            "vcd"        =>    "application/x-cdlink",
            "pgn"        =>    "application/x-chess-pgn",
            "cpio"       =>    "application/x-cpio",
            "csh"        =>    "application/x-csh",
            "dcr"        =>    "application/x-director",
            "dir"        =>    "application/x-director",
            "dxr"        =>    "application/x-director",
            "dvi"        =>    "application/x-dvi",
            "arc"        =>    "application/x-freearc",
            "pre"        =>    "application/x-freelance",
            "spl"        =>    "application/x-futuresplash",
            "gtar"       =>    "application/x-gtar",
            "gz"         =>    "application/x-gzip",
            "hdf"        =>    "application/x-hdf",
            "xhtml"      =>    "application/xhtml+xml",
            "php"        =>    "application/x-httpd-php",
            "ipx"        =>    "application/x-ipix",
            "ips"        =>    "application/x-ipscript",
            "js"         =>    "application/x-javascript",
            "skd"        =>    "application/x-koan",
            "skm"        =>    "application/x-koan",
            "skp"        =>    "application/x-koan",
            "skt"        =>    "application/x-koan",
            "latex"      =>    "application/x-latex",
            "lsp"        =>    "application/x-lisp",
            "scm"        =>    "application/x-lotusscreencam",
            "cdf"        =>    "application/x-netcdf",
            "nc"         =>    "application/x-netcdf",
            "sh"         =>    "application/x-sh",
            "shar"       =>    "application/x-shar",
            "swf"        =>    "application/x-shockwave-flash",
            "sit"        =>    "application/x-stuffit",
            "sv4cpio"    =>    "application/x-sv4cpio",
            "sv4crc"     =>    "application/x-sv4crc",
            "tar"        =>    "application/x-tar",
            "tcl"        =>    "application/x-tcl",
            "tex"        =>    "application/x-tex",
            "texi"       =>    "application/x-texinfo",
            "texinfo"    =>    "application/x-texinfo",
            "roff"       =>    "application/x-troff",
            "t"          =>    "application/x-troff",
            "tr"         =>    "application/x-troff",
            "man"        =>    "application/x-troff-man",
            "me"         =>    "application/x-troff-me",
            "ms"         =>    "application/x-troff-ms",
            "ustar"      =>    "application/x-ustar",
            "src"        =>    "application/x-wais-source",
            "zip"        =>    "application/zip",
            "aac"        =>    "audio/aac",
            "au"         =>    "audio/basic",
            "snd"        =>    "audio/basic",
            "kar"        =>    "audio/midi",
            "mid"        =>    "audio/midi",
            "midi"       =>    "audio/midiaudio/x-midi",
            "mp2"        =>    "audio/mpeg",
            "mp3"        =>    "audio/mpeg",
            "mpga"       =>    "audio/mpeg",
            "oga"        =>    "audio/ogg",
            "opus"       =>    "audio/opus",
            "tsi"        =>    "audio/TSP-audio",
            "wav"        =>    "audio/wav",
            "weba"       =>    "audio/webm",
            "aif"        =>    "audio/x-aiff",
            "aifc"       =>    "audio/x-aiff",
            "aiff"       =>    "audio/x-aiff",
            "ram"        =>    "audio/x-pn-realaudio",
            "rm"         =>    "audio/x-pn-realaudio",
            "rpm"        =>    "audio/x-pn-realaudio-plugin",
            "ra"         =>    "audio/x-realaudio",
            "wav"        =>    "audio/x-wav",
            "pdb"        =>    "chemical/x-pdb",
            "xyz"        =>    "chemical/x-pdb",
            "otf"        =>    "font/otf",
            "ttf"        =>    "font/ttf",
            "woff"       =>    "font/woff",
            "woff2"      =>    "font/woff2",
            "bmp"        =>    "image/bmp",
            "ras"        =>    "image/cmu-raster",
            "gif"        =>    "image/gif",
            "ief"        =>    "image/ief",
            "jpeg"       =>    "image/jpeg",
            "png"        =>    "image/png",
            "svg"        =>    "image/svg+xml",
            "tif"        =>    "image/tiff",
            "tiff"       =>    "image/tiff",
            "ico"        =>    "image/vnd.microsoft.icon",
            "webp"       =>    "image/webp",
            "pnm"        =>    "image/x-portable-anymap",
            "pbm"        =>    "image/x-portable-bitmap",
            "pgm"        =>    "image/x-portable-graymap",
            "ppm"        =>    "image/x-portable-pixmap",
            "rgb"        =>    "image/x-rgb",
            "xbm"        =>    "image/x-xbitmap",
            "xpm"        =>    "image/x-xpixmap",
            "xwd"        =>    "image/x-xwindowdump",
            "iges"       =>    "model/iges",
            "igs"        =>    "model/iges",
            "mesh"       =>    "model/mesh",
            "msh"        =>    "model/mesh",
            "silo"       =>    "model/mesh",
            "vrml"       =>    "model/vrml",
            "wrl"        =>    "model/vrml",
            "ics"        =>    "text/calendar",
            "css"        =>    "text/css",
            "csv"        =>    "text/csv",
            "htm"        =>    "text/html",
            "html"       =>    "text/html",
            "js"         =>    "text/javascript",
            "mjs"        =>    "text/javascript",
            "asc"        =>    "text/plain",
            "c"          =>    "text/plain",
            "cc"         =>    "text/plain",
            "py"         =>    "text/plain",
            "php"        =>    "text/plain",
            "f"          =>    "text/plain",
            "f90"        =>    "text/plain",
            "h"          =>    "text/plain",
            "hh"         =>    "text/plain",
            "m"          =>    "text/plain",
            "txt"        =>    "text/plain",
            "rtx"        =>    "text/richtext",
            "rtf"        =>    "text/rtf",
            "sgm"        =>    "text/sgml",
            "sgml"       =>    "text/sgml",
            "tsv"        =>    "text/tab-separated-values",
            "xml"        =>    "text/xml",
            "etx"        =>    "text/x-setext",
            "3gp"        =>    "video/3gpp",
            "3g2"        =>    "video/3gpp2",
            "ts"         =>    "video/mp2t",
            "mpeg"       =>    "video/mpeg",
            "mpg"        =>    "video/mpeg",
            "ogv"        =>    "video/ogg",
            "mov"        =>    "video/quicktime",
            "qt"         =>    "video/quicktime",
            "viv"        =>    "video/vnd.vivo",
            "vivo"       =>    "video/vnd.vivo",
            "webm"       =>    "video/webm",
            "fli"        =>    "video/x-fli",
            "avi"        =>    "video/x-msvideo",
            "movie"      =>    "video/x-sgi-movie",
            "mime"       =>    "www/mime",
            "ice"        =>    "x-conference/x-cooltalk",
        );
    $mime = strtolower($mime);
    if(array_search($mime, $ext2mime)) return array_search($mime, $ext2mime);
    else return 'null';
}

