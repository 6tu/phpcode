﻿<?php
	session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>生成网址</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" href="jquery/QapTcha.jquery.css" type="text/css" />

	<style type="text/css">
		form{margin:300px;width:500px}
		label{float:left;clear:both;width:100px;margin-top:10px}
		input{float:left; height:90px; font-size:18px; color:#35517c; margin-top:10px}
		.clr{clear:both}
		.notice {background-color:#d8e6fc;color:#35517c;border:1px solid #a7c3f0;padding:10px}

		.code {
			margin:30px;
			border:1px solid #F0F0F0;
			background-color:#F8F8F8;
			padding:10px;
			color:#777;
		}
	</style>
	
	<script type="text/javascript" src="jquery/jquery.js"></script>
	<script type="text/javascript" src="jquery/jquery-ui.js"></script>
	<script type="text/javascript" src="jquery/jquery.ui.touch.js"></script>
	<script type="text/javascript" src="jquery/QapTcha.jquery.js"></script>
	
</head>
<body>



<form method="post" action="">
<table>
	<tr>
		<td><div class="clr"></div></td> <td width=10px  ></td>
		<td><input type="hidden" name="validate" id="validate" /></td>
	</tr><tr>
		<td><div id="QapTcha"></div></td> <td width=10px  ></td>
		<td align="right"><input type="submit" name="submit"  value="   生成网址 " /></td>
	</tr>
	<script type="text/javascript"> $('#QapTcha').QapTcha({}); </script>
</table>
</form>
<br>


<?php

$check='b46d1900d0a894591916ea94ea91bd2c';// 设置的统一秘钥
// if form is submit
if(isset($_POST['submit']))
{
    //$_SERVER['SERVER_NAME'] 自己测试；需要特定域名的话，设置下即可，比如www.baidu.com,设置后必须指定服务器端IP,换了服务器就不行了
    $signature=md5(gethostbyname($_SERVER['SERVER_NAME']).$_POST['validate'].$check);//md5(md5(加密获取当前域名的服务器端IP+时间戳+统一秘钥))
    $response = '';
	if(isset($_SESSION['iQapTcha']) && hash_equals($signature,$_SESSION['iQapTcha']))
	{
		//$response .= '验证成功';

		$host = 'hao369.info';
		$len = rand(5, 30);
		$rand_str = rand_char($len);
		$url = 'http://' . $rand_str .'.'. $host .'/'. rand(1000, 9999);
		
		// 改写 .htaccess 的例子
		/*
		$htaccess = 'RewriteEngine on'. "\r\n";
		$htaccess .= 'RewriteCond %{HTTP_HOST} ^*.hao369.info$'. "\r\n";
		$htaccess .= 'RewriteCond %{REQUEST_URI} !^/dongtaiwang/'. "\r\n";
		$htaccess .= 'RewriteCond %{REQUEST_FILENAME} !-f'. "\r\n";
		$htaccess .= 'RewriteCond %{REQUEST_FILENAME} !-d'. "\r\n";
		$htaccess .= 'RewriteRule ^(.*)$ /dongtaiwang/$1'. "\r\n";
		$htaccess .= 'RewriteCond %{HTTP_HOST} ^*.hao369.info$'. "\r\n";
		$htaccess .= 'RewriteRule ^(/)?$ dongtaiwang/index.php [L]'. "\r\n";
		
		file_put_contents('.htaccess', $htaccess);
		*/
		
		$response .= customize_flush() . '<script>window.location.href="' . $url .'";</script>';
		
		unset($_SESSION['iQapTcha']);//销毁
	}
	else $response .= '';

	echo $response;
}

//当没这个函数时候启用，PHP5.6以上才会有---{{
if(!function_exists('hash_equals')) {
    function hash_equals($str1, $str2) {
        if(strlen($str1) != strlen($str2)) {
            return false;
        } else {
            $res = $str1 ^ $str2;
            $ret = 0;
            for($i = strlen($res) - 1; $i >= 0; $i--) $ret |= ord($res[$i]);
            return !$ret;
        }
    }
}
    //----}}
function customize_flush(){
    if(php_sapi_name() === 'cli'){
	return true;
	}else{
        echo(str_repeat(' ',256));
        // check that buffer is actually set before flushing
        if (ob_get_length()){           
            @ob_flush();
            @flush();
            @ob_end_flush();
        }   
        @ob_start();
	}
}

function rand_char($n=4) { 
    $rand = '';
    for($i = 0;$i < $n;$i++ ){
        $base = 62;
        $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	    $rand .= $chars[mt_rand(1, $base) - 1];
	}
	return $rand;
}

?>

</body>
</html>
