<?php

define('APP_DEBUG', false);
define('APP_PATH', './Application/');
require './ThinkPHP/ThinkPHP.php';


