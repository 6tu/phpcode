<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
    <head>
        <link href="/thinkphp-vcode/Public/js/pluge-js/css/drag.css" rel="stylesheet" type="text/css"/>
        <style>
            .gt_cut_fullbg_slice {
                float: left;
                width: 13px;
                height: 58px;
                margin: 0 !important;
                border: 0px;
                padding: 0 !important;
                background-image: url("/thinkphp-vcode/<?php echo ($pg_bg); ?>");
            }
            .xy_img_bord{
                -webkit-box-shadow:0 0 15px #0CC;
                -moz-box-shadow:0 0 15px #0CC;
                box-shadow:0 0 15px #0CC;
            }
            #xy_img{
                background-image: url(<?php echo ($ico_pic['url']); ?>);z-index: 999;width: <?php echo ($ico_pic['w']); ?>px;height:<?php echo ($ico_pic['h']); ?>px;position: relative;
            }
            input{
                border:1px solid #ccc;padding:5px 3px;margin:20px 0 20px 160px
            }
        </style>
    </head>
    <body>

	
	<br><br><br><br><br><br><br><br><br><br><br><br>
        <form class="form form-horizontal" action="<?php echo U('login/get_data');?>" method="post" id="form-login">
            <div class="row cl put_val">
                
                <div class="formControls col-8">
                    <input id="if_admin_name" name="if_admin_name" type="hidden" placeholder="账户" class="input-text size-L" value="guest">
                </div>
            </div>
            <div class="row cl put_val">
                
                <div class="formControls col-8">
                    <input id="if_admin_password" name="if_admin_password" type="hidden" placeholder="密码" class="input-text size-L" value="guest">
                </div>
            </div>


            <div class="row put_val" style="padding-left: 189px;">
                <div style="width: 260px;height: 116px;" id="Verification" >
                    <?php if(is_array($left_pic)): $i = 0; $__LIST__ = $left_pic;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i; $left_symbol = $vo[0] == 0 ?'':'-'; $right_symbol = $vo[1] == 0 ?'':'-'; ?>
                        <div class="gt_cut_fullbg_slice" style="background-position:<?php echo ($left_symbol); echo ($vo[0]); ?>px <?php echo ($right_symbol); echo ($vo[1]); ?>px;"></div><?php endforeach; endif; else: echo "" ;endif; ?>


                    <?php if(is_array($right_pic)): $i = 0; $__LIST__ = $right_pic;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i; $left_symbol = $vo[0] == 0 ?'':'-'; $right_symbol = $vo[1] == 0 ?'':'-'; ?>
                        <div  class="gt_cut_fullbg_slice" style="background-position:<?php echo ($left_symbol); echo ($vo[0]); ?>px  <?php echo ($right_symbol); echo ($vo[1]); ?>px;"></div><?php endforeach; endif; else: echo "" ;endif; ?>

                    <div style="top: <?php echo($y_point);?>px;left: 0px;display: none;border: 1px solid white" id="xy_img" class="xy_img_bord"></div>
                </div>
                <div id="drag" style="width: 260px;"></div>
            </div>
        </form>

        <script src="/thinkphp-vcode/Public/js/jquery.js"></script>
        <script src="/thinkphp-vcode/Public/js/pluge-js/js/drag.js" type="text/javascript"></script>
        <script>
            $('#drag').drag();
        </script>
    </body>
</html>