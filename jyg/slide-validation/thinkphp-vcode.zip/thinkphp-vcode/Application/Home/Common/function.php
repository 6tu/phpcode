<?php

function is_weixin() {
    if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) {
        return 1;
    } else {
        return 0;
    }
}

?>
