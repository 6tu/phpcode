
下载地址
http://aruba.ysuo.org/soft/jyg.zip
https://yadi.sk/d/Q0_DjmoN3JdTSm

演示地址 http://aruba.ysuo.org/soft/jyg/?admin

加入了 jquery.touch.js 文件，支持触摸屏，支持智能手机

目录要有写权限，莫非不能改写文件

修改完URL，等3秒会自动返回主页面，如果没有返回就手动返回


随机二级域名 关闭开关 只能用替换网址的办法
比如你用 http://g.cn 就关闭了随机二级域名
如果你用 http://$rand_str.hao369.info/$num 这个的格式就打开了随机二级域名。
.hao369.info/ 别加空格，别忘记了两个小点，也别忘记了 / ,这个格式是固定的，输错就相当输错了网址

最后一点，加入了   同一IP是否每次都要都要验证的开关，需要则去掉下行的 注释，不需要则加上注释 //
session_destroy();