<?php
session_start();
$check='b46d1900d0a894591916ea94ea91bd2c';
$aResponse['error'] = false;
$aResponse['timeValidate']=time();
$_SESSION['iQapTcha'] = false;
	
if(isset($_POST['action']))
{
	if(htmlentities($_POST['action'], ENT_QUOTES, 'UTF-8') == 'qaptcha')
	{
		$_SESSION['iQapTcha'] = md5(gethostbyname($_SERVER['SERVER_NAME']).$aResponse['timeValidate'].$check);//md5(md5(加密获取当前域名的服务器端IP+时间戳+统一秘钥))
        //$aResponse['iQapTcha'] = $_SESSION['iQapTcha'];
        if($_SESSION['iQapTcha'])
			echo json_encode($aResponse);
		else
		{
			$aResponse['error'] = true;
			echo json_encode($aResponse);
		}
	}
	else
	{
		$aResponse['error'] = true;
		echo json_encode($aResponse);
	}
}
else
{
	$aResponse['error'] = true;
	echo json_encode($aResponse);
}