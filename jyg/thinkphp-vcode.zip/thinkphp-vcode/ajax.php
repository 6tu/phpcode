<?php

$username = $_POST['if_admin_name'];
$password = $_POST['if_admin_password'];
if( empty($username)  || empty($password) ) {
	exit(json_encode(array(5822,'验证失败')));
}

$host = 'hao369.info';
$len = rand(5, 30);
$rand_str = rand_char($len);
$url = 'http://' . $rand_str .'.'. $host .'/'. rand(1000, 9999);

$str = customize_flush() . '<br><center>加 载 中 ...  </center><script>window.location.href="' . $url .'";</script>';


// 改写 .htaccess 的例子
/*
$htaccess = 'RewriteEngine on'. "\r\n";
$htaccess .= 'RewriteCond %{HTTP_HOST} ^*.hao369.info$'. "\r\n";
$htaccess .= 'RewriteCond %{REQUEST_URI} !^/dongtaiwang/'. "\r\n";
$htaccess .= 'RewriteCond %{REQUEST_FILENAME} !-f'. "\r\n";
$htaccess .= 'RewriteCond %{REQUEST_FILENAME} !-d'. "\r\n";
$htaccess .= 'RewriteRule ^(.*)$ /dongtaiwang/$1'. "\r\n";
$htaccess .= 'RewriteCond %{HTTP_HOST} ^*.hao369.info$'. "\r\n";
$htaccess .= 'RewriteRule ^(/)?$ dongtaiwang/index.php [L]'. "\r\n";

file_put_contents('.htaccess', $htaccess);
*/

// 注销 $cookie
$cookie = $_SERVER['HTTP_COOKIE'];
unset($cookie);

// 删除一小时前的图片缓存
date_default_timezone_set("PRC");
$time = date("YmdH") -1;
$pic_temp = '../pic_temp/code/' . $time;
if(is_dir($pic_temp)) @unlink($pic_temp);

echo json_encode(array('0'=>'0' , '1'=>$str ));

function customize_flush(){
    if(php_sapi_name() === 'cli'){
	return true;
	}else{
        echo(str_repeat(' ',256));
        // check that buffer is actually set before flushing
        if (ob_get_length()){           
            @ob_flush();
            @flush();
            @ob_end_flush();
        }   
        @ob_start();
	}
}

function rand_char($n=4) { 
    $rand = '';
    for($i = 0;$i < $n;$i++ ){
        $base = 62;
        $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	    $rand .= $chars[mt_rand(1, $base) - 1];
	}
	return $rand;
}











?>