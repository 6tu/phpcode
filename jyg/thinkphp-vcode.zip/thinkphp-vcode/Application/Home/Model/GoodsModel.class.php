<?php

namespace Home\Model;

use Think\Model;

class GoodsModel extends Model {

    public $tableName = "ads";

    function getSkuLists($skus) { //商品规格
//        $skus_pics = $detail['sku_upload_pic'] ? json_decode($detail['sku_upload_pic'], true) : "";
        $sku_names = array();
        $sku_item_num = count(explode("_", $skus[0]['ids']));
        for ($i = 0; $i < $sku_item_num; $i++) {
            $j = 0;
            $sku_ids_arr = "";
            $sku_names_arr = "";
            foreach ($skus as $v) {
                $sku_ids = explode("_", $v['ids']);
                $sku_names = array_unique(array_filter(explode("_", $v['names'])));

                $sku_ids_arr[] = $sku_ids[$i];
                $sku_names_arr[] = $sku_names[$i];
            }
            $skus_lists[$i]['ids'] = array_unique(array_filter($sku_ids_arr));
            $skus_lists[$i]['names'] = array_unique(array_filter($sku_names_arr));

            $pid = getSingleField($skus_lists[$i]['ids'][0], "goods_standard", "pid");
            $skus_lists[$i]['pname'] = getSingleField($pid, "goods_standard", "name");
        }
        return $skus_lists;
    }
    function getCat() {
        $cats = M("goods_cat")->field("id,name,code")->where("pid = 0 AND is_show = 1")->order("ord ASC")->select();
        foreach ($cats as $k => $v) {
            $cats[$k]['sub'] = M("goods_cat")->field("id,name")->where("is_show = 1 AND pid ='" . $v['id'] . "'")->order("ord ASC")->select();
        }
        return $cats;
    }

}
?>

