<?php

namespace Home\Controller;

use Think\Controller;

class IndexController extends Controller {

    public function index() {
           import("Common.Org.XSVerification");
        $XSVerification = new  \XSVerification();  // 加载类 XSVerification.class.php
        $data = $XSVerification->getOkPng();
        $temp = array_chunk($data['data'],20);
        $this->assign('left_pic',$temp[0]);
        $this->assign('right_pic',$temp[1]);
        $this->assign('pg_bg',$data['bg_pic']);
        $this->assign('ico_pic',$data['ico_pic']);
        $this->assign('y_point',$data['y_point']);
        session("XSVer_VAL_SUM",1);
             $this->assign('y_point',$data['y_point']);
        $this->display();

    }

}
