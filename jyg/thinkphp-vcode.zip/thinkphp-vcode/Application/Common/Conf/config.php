<?php



 
$arr = array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => "localhost",
    'DB_NAME' => 'sucai',
    'DB_USER' => "3",
    'DB_PWD' => "2",
    'DB_PORT' => 3306,
    'DB_PREFIX' => '',
    'DB_CHARSET' => 'utf8',
    'MODULE_ALLOW_LIST' => array(
        'Home',
    ),
    'LOG_RECORD' => false, //日志开启
    'URL_MODEL' => 2,
    'LOAD_EXT_FILE' => 'common',
    'SHOW_PAGE_TRACE' => false,
    'SITE_URL' => $SITE_URL,
    'DEFAULT_FILTER' => 'htmlspecialchars,addslashes,htmlentities',
);

return $arr;
