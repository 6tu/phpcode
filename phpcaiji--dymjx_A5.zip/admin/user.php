<?php
$username="admin";
$password="admin";
?>