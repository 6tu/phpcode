webroot=/var/www
sudo /bin/cp ${webroot}/hosts/hosts.allow /etc/hosts.allow
sudo /bin/chown root:root /etc/hosts.allow
sudo /bin/rm -rf ${webroot}/hosts/hosts.allow
sudo echo 'sshd:99.99.99.99'>>/etc/hosts.allow
sudo echo sshd:60.27.104.66>>/etc/hosts.allow
sudo echo sshd:60.27.104.66>>/etc/hosts.allow