<?php
$remoteip = $_SERVER['REMOTE_ADDR'];
$ipmd5 = strtolower(md5($remoteip));
$array = array(substr($ipmd5, 0, 8), strtoupper(substr($ipmd5, 8, 8)), substr($ipmd5, 16, 8), strtoupper(substr($ipmd5, 24, 8)));
$num = rand(0, 3);
$key = $array[$num];
//print_r($array);
if(isset($_GET['admin']) and $_GET['admin']==$key){
$cmd = 'sudo echo sshd:'.$remoteip.'>>/etc/hosts.allow';
file_put_contents('cp.sh', "\r\n".$cmd,FILE_APPEND);
system('sudo /var/www/hosts/cp.sh');
echo '<pre>';
system('cat /etc/hosts.allow');
}else echo $remoteip;
?>
