<?php 
function get_msg($path) { 
$handle = opendir($path); 
while ($filename = readdir($handle)) { 
echo "<BR><br>".$path. "/"."<a href=$filename>".$filename."</a>"; 
} 
closedir($handle); 
} 
get_msg("."); 
?>
