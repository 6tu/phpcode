<? $reg_user = 'admin'; $reg_pass = '0000000'; ?>
