<?
include "./class.upload.php";
$img = new Upload;
$img->info();
?>