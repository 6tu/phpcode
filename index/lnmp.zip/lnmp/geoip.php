<?php
    header("Content-type: text/html; charset=utf-8");
    echo '数据库信息: ' . geoip_database_info(GEOIP_COUNTRY_EDITION) ." <br>\r\n";
    echo '客户机 IP : ' . $_SERVER['REMOTE_ADDR'] ." <br>\r\n";
    echo 'IP 归属地 : ' . geoip_country_code3_by_name($_SERVER['REMOTE_ADDR']) ." <br>\r\n";
?>
