<?php

session_start(); 
//如果token为空则生成一个token  
if(!isset($_SESSION['token']) || $_SESSION['token']=='') {  
    set_token();  
} 

set_time_limit(11);
header("Content-type:text/html;charset=UTF-8");
date_default_timezone_set('Asia/Shanghai');
$home = '/var/www';
$python = '/usr/local/bin/python';
$gplaycli = '/usr/local/bin/gplaycli';
$wwwdir = '/opt/www/app';
$gappsdir = '/opt/www/app/gapps';
$usergappsdir = $gappsdir . md5($_SERVER["REMOTE_ADDR"]);
$hl = '&hl=' . lang();
if(!isset($_POST['id']) && empty($_POST['id'])){
    echo html();
    exit(0);
}
/*
if(isset($_POST['id'])){  
    if(!valid_token()){  
        echo "token error";  
    }else{  
        echo '成功提交:'.$_POST['id'];
        exit(0);
    }  
} 
// 以上为防止刷新表单
*/

$appid = $_POST['id'];
//$token = $_POST['token'];
if(strstr($appid, '/')){
    $url = parse_url($appid);
    if(isset($url['query']) && strstr($url['query'], 'id=')){
        $appid = substr($url['query'], strpos($url['query'], "=") + 1);
        $appid = str_replace('=', '', $appid);
    }else{
        echo 'URL不合法哦';
        exit(0);
    }
}
$appid = str_replace(' ', '', $appid);
$id_url = 'https://play.google.com/store/apps/details?id=' . $appid;
$search_url = 'https://play.google.com/store/search?q=' . urlencode($appid) . $hl;
//浏览器中汉语转码
if(strstr(get_info($id_url), '404')){
//    $res = get_content($search_url);
//    echo $res;
    echo html()."<br>\r\n<br>";
    echo '<pre>';
    $command = $python . ' ' . $gplaycli . ' -s ' . $appid . ' -n 20';
    system($command, $ret);

    exit(0);
}
echo '<';
$command = $python . ' ' . $gplaycli . ' -d ' . $appid . ' -f ' . $gappsdir;
//echo $command;
$lastline = system($command, $ret);
echo '>';
echo html()."<br>\r\n<br>";
($ret == 0) or die('<b> 服务器故障:  ' . $appid . ' 不能下载</b>');

//for(;;){
//for($i = 1; $i < 11; $i++){

    if(strstr($lastline, 'complete')){
        $link = ' <a href=./gapps/' . $appid . '.apk>' . $appid . '</a>';
        $link = ' <a href=down.php?appid=./gapps/' . $appid . '.apk   target="_black" >' . $appid . '</a>';
        echo "<p><center>" . $link . "</center>";
    }
//    sleep(1);
//    echo "<br>\r\n" . $i.' ';
//      if($i == 10){
//      echo '服务器响应缓慢，应用正在后台下载，稍后将下载到  ./gapps/';
//      }
    //ob_flush();
    //flush();  
//}

//include('./gapps/index.php');

system('cd gapps && ls -lt  $retval>./ls.txt');
##  分析文件
$ls = file_get_contents('./gapps/ls.txt');
$ls = str_replace("\n", "ruanhuiche", $ls);
$ls = preg_replace("/[\s]+/is", " ", $ls);
$en = explode("ruanhuiche", $ls);
$body = '';
foreach($en as $line){
    if(strstr($line, ".apk")){
        $es = explode(" ", $line);
        
$file = '<a href=down.php?appid=./gapps/' . $es['8'] . ' target="_black" >' . $es['8'] . '</a>';
        $size = formatBytes($es['4']);
                $date = $es['5'] . $es['6'] . ' , ' . $es['7'];
        $date = month2CN($date);
        $body .= '                  <tr><td style="width: 400px;"> ' . $file . '</td><td>' . $size . '</td><td>' . $date . '</td></tr>' . "\r\n";
    }
}
$head = '<p><h4>已从 GooglePlay 下载的文档</h4> <table style="width:800px; border-collapse: collapse;" >'."\r\n" ; #align="center"
$footer = "</table></body></html>";
echo $head.$body.$footer;

##  相关函数
function set_token() {  
    $_SESSION['token'] = md5(microtime(true));  
}  
  
function valid_token() {  
    $return = $_REQUEST['token'] === $_SESSION['token'] ? true : false;  
    set_token();  
    return $return;  
}  
  


function month2CN($str){
    $lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 4);
    if(preg_match("/zh/i", $lang)){
        $str = str_replace(array("Jan", "Feb", "Mar", "Apr", "may", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"),
                           array("1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"),
                                                   $str);
                $str = str_replace(" , ", "日 , ", $str);
    }
    return $str;
}
function formatBytes($size){
    $units = array(' B', ' K', ' M', ' G', ' T');
    for($i = 0;$size >= 1024 && $i < 4;$i++)$size /= 1024;
    return round($size, 2) . $units[$i];
}
function html(){
    $html = '<html><head><meta http-equiv="Content-Type" content="text/html;charset=GBK"/>'."\r\n"
	. '<title>下载 GOOGLE 市场中的 APP   APK Downloader [Latest]</title></head>'."\r\n"
	. '<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />'."\r\n"
	. '<meta name="keywords" content="Google Play Store,app,谷歌电子市场在线下载" />'."\r\n"
	. '<meta name="description" content="谷歌电子市场在线下载" />'."\r\n"
	. '<body><br/><br/><center><h2>下载 GOOGLE 市场中的 APP </h2><table with=80%>'."\r\n"
	. '<form action="' . $_SERVER['PHP_SELF'] . '" method="POST" enctype="multipart/form-data" >'."\r\n"
	. '<input type="hidden" name="token" value="' .$_SESSION['token'] .'">  '."\r\n"
	. '<table style="width:800px; border-collapse: collapse;">'
        . '<tr><td width=500 height=40 >APK名称或者 Google Play URL </td><td><a href="https://play.google.com/" >Visit Play Store</a></td></tr>'."\r\n"
	. '<tr><td width=500 height=10 ><small>com.evozi.deviceid 或者 https://play.google.com/store/apps/details?id=com.evozi.deviceid</small></td></tr>' ."\r\n"
	. '<tr><td><input type="text" name="id" value="" style="width:600px;height:50px" /></td></tr>' ."\r\n"
	. '<tr><td><input type="hidden" name="packagename" value="1234567890" style="width:600px;height:50px" /></td></tr>'."\r\n"
	. '<tr><td><center><input type="submit" value="发送" style="width:200px;height:40px" /></center></td></tr>'."\r\n"
	. '</table></form></center>';
    return $html;
}
function get_content($url){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $res = curl_exec($ch);
    curl_close($ch);
    return $res;
}
function get_info($url){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_exec($ch);
    if(!curl_errno($ch)){
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    }
    curl_close($ch);
    return $http_code;
}
function lang(){
    if(!isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])){
	    $lang = 'en-US,en';
	}else{
		$lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
	}
    $lang = explode(',', $lang);
    if(strstr($lang[0], 'q=')){
        $hl = $lang[1];
        $hl = str_replace(';', '', $hl);
    }else{
        $hl = $lang[0];
    }
	return $hl;
}
?>

