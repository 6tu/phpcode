# htpasswd Generator

This htpasswd password encryption applet is written in JavaScript, so the entire process runs within your browser. Nothing is transmitted to any server, we take your privacy and security serious.

