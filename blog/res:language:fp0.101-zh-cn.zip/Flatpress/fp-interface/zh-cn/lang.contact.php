<?php

	$lang['contact'] = array(
		'head'		=> '联系我们',
		'descr'		=> '您可以通过下面的表单联系我们。如果您希望得到回复请别忘了填上您的Email。',
		'fieldset1'	=> '用户',
		'name'		=> '昵称 (*)',
		'email'		=> 'Email:',
		'www'		=> 'Web:',
		'cookie'	=> '记住我的设置',
		'fieldset2'	=> '您的消息',
		'comment'	=> '消息 (*):',
		'fieldset3'	=> '发送',
		'submit'	=> '发送',
		'reset'		=> '重置',
		
	);
	
	$lang['contact']['error'] = array(
		'name'		=> '请输入昵称',
		'email'		=> '请输入有效的Email地址',
		'www'		=> '请输入有效的 URL',
		'content'	=> '请输入消息正文',
	);
	
	$lang['contact']['msgs'] = array(
		1	=> '消息发送成功',
		-1	=> '无法发送消息',
	);
	
?>