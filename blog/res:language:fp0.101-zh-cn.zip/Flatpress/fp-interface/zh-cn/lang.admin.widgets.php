<?php

	$lang['admin']['widgets']['submenu']['default'] = '板块管理';
	$lang['admin']['widgets']['submenu']['raw'] 	= '板块管理 (源代码)';

	/* default action */
	
	$lang['admin']['widgets']['default'] = array(
		'head'		=> '板块管理 (<em>实验性支持</em>)',
		
		'descr'		=> 	' <a class="hint" '.
						'href="http://wiki.flatpress.org/doc:widgets" title="What is a Widget?">'.
						'板块(Widget)</a> 是可以显示数据或与用户交互的动态组件。
						<strong>主题</strong> 可以改变您博客的外观，板块则可以 
						<strong>扩展</strong> 其布局和功能。</p>

						<p>板块可以拖动至主题的特定区域中，这些区域被称为
						<strong>板块分组</strong>。分组的数量和名称因您所选的主题不同而不同。</p>

						<p>FlatPress 自带多个板块: 登录域、搜索框等。</p>
						
						<p>每个板块都由对应的 <a class="hint" '.
						'href="http://wiki.flatpress.org/doc:plugins" title="What is a Widget?">插件</a> 支撑。',
						
		'availwdgs'	=> '可用板块',
		'trashcan'	=> '拖放到此组可以从页面中删除对应板块。',
		
		'themewdgs' => '当前主题的板块分组',
		'themewdgsdescr' => '您当前使用的主题允许您使用以下板块分组：',
		'oldwdgs'	=> '其他分组',
		'oldwdgsdescr' =>'下列板块分组似乎似乎并不属于以上列出的任何分组，'.
						'可能是上一个主题中遗留下来的。',
		
		'submit'	=> '保存修改',

	);
	
	$lang['admin']['widgets']['default']['stdsets'] = array(
		'top'		=> '顶部栏',
		'bottom'	=> '底部栏',
		'left'		=> '左边栏',
		'right'		=> '右边拦',
	);
	
	$lang['admin']['widgets']['default']['msgs'] = array(
		1	=> '设置保存成功',
		-1	=> '保存设置时发生错误，请重试。',
	);


	
	/* "raw" panel */	
	
	$lang['admin']['widgets']['raw'] = array(
		'head'		=> '板块管理 (<em>代码编辑器</em>)',
		'descr'		=> '<a class="hint" '.
						'href="http://wiki.flatpress.org/doc:plugins" title="What is a Widget?">'.
						'板块 (Widget)</a> 是 <a class="hint" '.
						'href="http://wiki.flatpress.org/doc:plugins" title="What is a plugin?">'.
						'插件</a> 的可视部分，您可以将这些板块布置到博客页面的特定区域( <em>板块分组(WidgetSets)</em>) 。</p>'.
						'<p>本页为 <strong>源代码</strong> 编辑器；高级用户和无法使用Javascript的用户可能更喜欢直接编辑代码',
						
		'fset1'		=> '编辑器',
		'fset2'		=> '应用更改',
		'submit'	=> '应用',

	);
	
	
	$lang['admin']['widgets']['raw']['msgs'] = array(
		1	=> '设置保存成功',
		-1	=> '保存设置时发生错误。可能有多种原因造成:例如您的文件可能有语法错误。',
	);

		

	/* system errors */
		
	$lang['admin']['widgets']['errors'] = array(
		'generic'	=> '板块 <strong>%s</strong> 未注册，将被忽略。 '.
 				'请检查<a href="admin.php?p=plugin">插件面板</a>中对应的插件是否已经开启。'

	);
	
?>
