<?php

	$lang['admin']['static']['submenu'] = array(
		'list'		=> '管理静态内容',
		'write'		=> '新建静态页面'
	);

	
	/* main panel */
		
	$lang['admin']['static']['list'] = array(
	
		'head'		=> '静态页面',
		'descr'		=> '请选择要编辑的页面或 <a href="admin.php?p=static&amp;action=write">创建新页面</a>。',
	
		'sel'		=> 'Sel', // checkbox
		'date'		=> '日期',
		'name'		=> '页面',
		'title'		=> '标题',
		'author'	=> '作者',
		
		'action'	=> '动作',
		'act_view'	=> '查看',
		'act_del'	=> '删除',
		'act_edit'	=> '编辑'		
	);
	
	$lang['admin']['static']['list']['msgs'] = array(
		1	=> '页面保存成功',
		-1	=> '保存页面时发生错误。',
		2	=> '页面删除成功',
		-2	=>	 '删除页面时发生错误。',
	);

	/* write panel */

	$lang['admin']['static']['write'] = 
	array(
		'head'		=> '静态页面发布',
		'descr'		=> '通过编辑表单发布页面',
		'fieldset1'	=> '编辑',
		'subject'	=> '主题 (*):',
		'content'	=> '内容 (*):',
		'fieldset2'	=> '提交',
		'pagename'	=> '页面名称 (*):',
		'submit'	=> '发布',
		'preview'	=> '预览',

		'delfset'	=> '删除',
		'deletemsg'	=> '删除此页',
		'del'		=> '删除',
		'success'	=> '页面发布成功',
		'otheropts'	=> '其他选项',
	);
	
	$lang['admin']['static']['write']['error'] = array(
		'subject'	=> '主题不能为空',
		'content'	=> '文章内容不能为空',
		'id'		=> '无效 ID'
	);
	
	
	/* delete action */	
	$lang['admin']['static']['delete'] = array(
		'head'		=> "删除页面", 
		'descr'		=> '您要删除如下页面:',
		'preview'	=> '预览',
		'confirm'	=> '确定执行吗?',
		'fset'		=> '删除',
		'ok'		=> '是, 删除此页',
		'cancel'	=> '否, 返回控制面板',
		'err'		=> '指定的页面不存在',
	
	);
	
	
		
?>
