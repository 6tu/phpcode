<?php

	$lang['admin']['panel']['main'] = 'Main';
	
	$lang['admin']['main']['default'] = array(
		'head'		=> '欢迎使用控制面板!',
		'descr'		=> '请选择操作',
		
		'op1'		=> '新文章',
		'op1d'		=> '撰写新文章。',
		'op2'		=> '文章',
		'op2d'		=> '显示、管理所有文章。',
		'op3'		=> '板块 (Widget)',
		'op3d'		=> '管理侧边栏、顶部工具栏、底边栏等页面板块。',
		'op4'		=> '插件',
		'op4d'		=> '安装、启用、禁用插件。',
		'op5'		=> '配置',
		'op5d'		=> '自定义 FlatPress 的设置',
		'op6'		=> '维护',
		'op6d'		=> '清理或恢复 FlatPress',
		
	);
?>
