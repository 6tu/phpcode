<?php

	
	$lang['admin']['themes']['submenu'] = array(
		'default'	=> '主题',
		'style'		=> '样式',
	);
	
	/* default panel action (change theme) */
	
	$lang['admin']['themes']['default'] = array(
		'head1'		=> '当前主题',
		
		'head2'		=> '可用主题',
		'descr'		=> '请选择您希望使用的主题',
		
		'nodescr'	=> '无描述',
		'noauthor'	=> '作者未知',

	);
	
	$lang['admin']['themes']['default']['msgs'] = array(
		1 => '主题更换成功。',
		-1 => '更换主题时发生错误。',
		-2 => '您所选择的主题不存在。'
	);
	
	
	/* select style */
	
	$lang['admin']['themes']['style'] = array(
		'head1'		=> '当前样式',
		
		'head2'		=> '可用样式',
		'descr'		=> '请选择您希望与当前主题搭配使用的样式。',
		
		'nodescr'	=> '无描述',
		'noauthor'	=> '作者未知',
	);
	
	$lang['admin']['themes']['style']['msgs'] = array(
		1 => '样式更换成功。',
		-1 => '更换样式时发生错误。',
		-2 => '您所选择的样式不存在。'
	);
	
	
?>
