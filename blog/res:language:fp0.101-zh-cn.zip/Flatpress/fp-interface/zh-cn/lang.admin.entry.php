<?php


	$lang['admin']['entry']['submenu'] = 
	array (
		'list'		=> '文章管理',
		'write'		=> '撰写文章',
		'cats'		=> '管理分类'
	);


	/* default action */
	
	$lang['admin']['entry']['list'] = 
	array(
		'head'		=> '文章管理',
		'descr'		=> '请选择要操作的文章 或 <a href="admin.php?p=entry&amp;action=write">添加新文章</a>'.
					'<br /><a href="admin.php?p=entry&amp;action=cats">编辑分类</a>',
		'filter'	=> '文章过滤: ',
		'nofilter'	=> '显示全部',
		'filterbtn'	=> '过滤',
		'sel'		=> 'Sel', // checkbox
		'date'		=> '日期',
		'title'		=> '标题',
		'author'	=> '作者',
		'comms'		=> '#评论', // comments
		'action'	=> '动作',
		'act_del'	=> '删除',
		'act_view'	=> '查看',
		'act_edit'	=> '编辑'
	);
	
	/* write action */
	$lang['admin']['entry']['write'] = 
	array(
		'head'		=> '撰写文章',
		'descr'		=> '在下面的框格中编辑您的文章。',
		'uploader'	=> '上传文件',
		'fieldset1'	=> '编辑',
		'subject'	=> '主题 (*):',
		'content'	=> '内容 (*):',
		'fieldset2'	=> '提交',
		'submit'	=> '发布',
		'preview'	=> '预览',
		'savecontinue'	=> '保存并继续',
		'archive'	=> '归档',
		'nocategories'	=> '尚未设置任何分类。'.
					'请先 <a href="#save">保存</a> 您的文章。'.
					'然后到文章主面板中 <a href="admin.php?p=entry&amp;action=cats">创建您的'. 
					'分类</a> 。',
		'saveopts'	=> '保存设置',
		'success'	=> '文章发布成功',
		'otheropts'	=> '其他设置',
		'commmsg'	=> '管理文章的评论',
		'delmsg'	=> '删除此文章',
		//'back'		=> 'Back discarding changes',
	);
	

	$lang['admin']['entry']['list']['msgs'] = array(
		1	=> '文章保存成功',
		-1	=> '文章保存出错',
		2	=> '文章删除成功',
		-2	=> '文章删除出错',
	);

	
	$lang['admin']['entry']['write']['error'] = array(
		'subject'	=> '请填写文章主题',
		'content'	=> '请填写文章内容',
	);
	
	$lang['admin']['entry']['write']['msgs'] = array(
		1	=> '文章保存成功',
		-1	=> '错误: 您的文章保存失败',
		-2	=> '错误: 无法保存文章，文章索引可能已经损坏',
		-3	=> '错误: 您的文章已保存为草稿',
		-4	=> '错误: 您的文章已保存为草稿; 文章索引可以已经损坏',
		'draft'=> '您正在编辑 <strong>草稿</strong> 文章'
	);

	
	/* comments */
	
	$lang['admin']['entry']['commentlist'] = 
	array(
		'head'		=> "文章评论 ", 
		'descr'		=> '选择要删除的评论',
		'sel'		=> 'Sel',
		'content'	=> '内容',
		'date'		=> '日期',
		'author'	=> '作者',
		'email'		=> 'Email',
		'ip'		=> 'IP',
		'actions'	=> '操作',
		'act_edit'	=> '编辑',
		'act_del'	=> '删除',
		'act_del_confirm' => '确认删除此评论?',
		'nocomments'	=> '此文章尚无评论。',
		
	
	);

	$lang['admin']['entry']['commentlist']['msgs'] =
	array(
		1	=> '评论删除成功',
		-1	=> '删除评论时发生错误',
		
	);

	$lang['admin']['entry']['commedit'] = 
	array(
		'head'		=> "编辑文章评论", 
		'content'	=> '内容',
		'date'		=> '日期',
		'author'	=> '作者',
		'www'		=> 'Web Site',
		'email'		=> 'Email',
		'ip'		=> 'IP',
		'loggedin'	=> '登录用户',
		'submit'	=> '保存'
		
	
	);

	$lang['admin']['entry']['commedit']['msgs'] =
	array(
		1	=> '评论编辑成功',
		-1	=> '编辑评论时发生错误',
	);
	
	/* delete action */
	
	$lang['admin']['entry']['delete'] = 
	array(
		'head'		=> '删除文章', 
		'descr'		=> '您要删除一下文章:',
		'preview'	=> '预览',
		'confirm'	=> '确认继续?',
		'fset'		=> '删除',
		'ok'		=> '是, 删除此文章',
		'cancel'	=> '否, 返回文章面板',
		'err'		=> '指定的文章不存在',
	
	);
	
	/* category mgmt */
	
	$lang['admin']['entry']['cats'] =
	array(
		'head'		=> '编辑文章分类',
		'descr'		=> '<p>请通过下面的表单编辑您的文章分类。 </p><p>分类应遵循如下格式 "分类名称: <em>分类编号</em>"。用短横线设置所属关系。</p>
		
	<p>例如:</p>
	<pre>
综合 :1
新闻 :2
--公告 :3
--活动 :4
----其他 :5
技术 :6
	</pre>',
		'clear'		=> '删除所有分类',
	
		'fset1'		=> '编辑器',
		'fset2'		=> '应用更改',
		'submit'	=> '保存'
	);
	
	$lang['admin']['entry']['cats']['msgs'] = array(
		
		1	=> '分类保存成功',
		-1	=> '分类保存时发生错误',
		2	=> '分类清除成功',
		-2	=> '清空分类时发成错误',
		-3 	=> '分类编号只能是非0的正整数'

	);
	
	
		
?>
