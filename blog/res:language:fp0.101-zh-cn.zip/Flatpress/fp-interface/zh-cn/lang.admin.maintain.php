<?php
	
	$lang['admin']['panel']['maintain'] = '维护';

	$lang['admin']['maintain']['default'] = array(
		'head'		=> '维护',
		'descr'		=> '当 FlatPress 正常使用中出现问题时，请打开维护。'.
					'这里的工具可能解决问题，但有时也不一定。',
		'opt0'		=> '&laquo; 返回主面板',
		'opt1'		=> '重建索引',
		'opt2'		=> '清空主题和模板缓存',
		'opt3'		=> '恢复文件属性',
		'opt4'		=> '显示PHP信息',
		'opt5'		=> '检查更新',

		'chmod_info'	=> "以下文件的属性 <strong>无法</strong>
					重置为 0777; 可能php进程并非文件的所有者。
					通常情况下您可以忽略此提示。",
		
	);
	
	$lang['admin']['maintain']['default']['msgs'] = array(
		1		=> '操作完成'
	);
	
	$lang['admin']['maintain']['updates'] = array(
		'head'	=> '更新',
		'list'	=> '<ul>
		<li>您的 FlatPress 版本为 <big>%s</big></li>
		<li> FlatPress 最新的稳定版为 <big><a href="%s">%s</a></big></li>
		<li> FlatPress 最新的测试版为 <big><a href="%s">%s</a></big></li>
		</ul>',
		'notice'=>'提示:'
		
	);
	
	
	
	$lang['admin']['maintain']['updates']['msgs'] = array(
		1		=> '有可用更新!',
		2		=> '您的版本已经为最新',
		-1		=> '无法获取更新信息'
	);

?>
