<?php

	$lang['comments']['mail'] = <<<MAIL
你好 %toname%，

"%fromname%" %frommail% 刚刚对文章 "%entrytitle%" 发表了评论。

下面是您文章的评论链接:
%commentlink%

下面是回复的评论:
***************
%content%
***************

祝一切顺利,
%blogtitle%

MAIL;

?>
