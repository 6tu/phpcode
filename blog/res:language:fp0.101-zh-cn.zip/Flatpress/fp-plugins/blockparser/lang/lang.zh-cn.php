<?php
	
	$lang['admin']['widgets']['submenu']['blockparser'] = 'BlockParser Widgets';
	
	$lang['admin']['widgets']['blockparser'] = array(
		'head'		=> 'BlockParser Widgets',
		'description'	=> 'BlockParser 插件可以利用静态页面创建板块。 </p><p>
		从列表中选择一个或多个静态页面，来生成相应的板块。</p><p>
		每个 <a href="?p=static&amp;action=write">新静态页面</a> 都会显示在列表中。',

		'id'		=> '静态页面',
		'title'		=> '标题',
		'action'	=> '动作',
		'enable'	=> '启用',
		'disable'	=> '禁用',
		'edit'		=> '编辑',
		
	);
	$lang['admin']['widgets']['blockparser']['msgs'] = array(
		1		=> '板块生成成功。请通过 <a href="?p=widgets">板块面板</a> 添加到博客中。',
		-1		=> '无法创建指定板块。',
		2		=> '板块禁用: 请不要忘记从 <a href="?p=widgets">板块面板</a>中删除对其的引用!',
		-2		=> '板块禁用失败。'
	);
	
?>
