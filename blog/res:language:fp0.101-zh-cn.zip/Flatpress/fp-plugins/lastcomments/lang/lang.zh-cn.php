<?php
	// cimangi Aggiunta traduzione stringhe
	$lang['plugin']['lastcomments'] = array(
		
		'last'				=> '最近',
		'comments'			=> '个评论',
		'no_comments'		=> '无评论',
		'no_new_comments'	=> '无最新评论'
		
	);

?>