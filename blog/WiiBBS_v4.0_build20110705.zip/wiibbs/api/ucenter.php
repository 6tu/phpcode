<?php
final class Ucenter_api {
  	public function __construct($registry) {
		$this->db = $registry->get('db');
  	}

    /**
     *  用户登录函数
     *
     * @access  public
     * @param   string  $username
     * @param   string  $password
     *
     * @return void
     */
	
    public function login($username, $password)
    {
		list($uid, $uname, $pwd, $email, $repeat) = $this->uc_call("uc_user_login", array($username, $password));
        $uname = addslashes($uname);
        if($uid > 0)
        {
            //检查用户是否存在,不存在直接放入用户表

			$sql2="select * from ".DB_TABLE_PREFIX."user where user_id=".$uid;
			$result2=$this->db->query($sql2);
			$row2=$result2->row;
			if ($row2){
				$uid_exist=$uid;
			
			}else{
				$uid_exist="";
			}
			
			$sql2="select * from ".DB_TABLE_PREFIX."user where user_account='".$username."'";
			$result2=$this->db->query($sql2);
			$row2=$result2->row;
			if($row2)
			{
				$sart=$row2['user_salt'];
				$name_exist=$row2['user_id'];
			}else{
				$sort="";
				$name_exist="";
			}
			
			$sql2="select * from ".DB_TABLE_PREFIX."user where user_account='".$username."' and user_password='".md5(md5($password).$sart)."'";
			$result2=$this->db->query($sql2);
			$row2=$result2->row;
			if($row2)
			{
				$user_exist=$row2['user_id'];
			}else{
				$user_exist="";
			}

            if (empty($user_exist))
            {
				
				 $sart=rand(1000,9999);
				if(empty($name_exist))
                {
                 
					if (empty($uid_exist)){
						$sqlStr="insert into ".DB_TABLE_PREFIX."user(user_id,user_account,user_password,user_regtime,user_level,user_grade,user_salt,user_email) values(".$uid.",'".$username."','".md5(md5($password).$sart)."','".date('Y-m-d H:i:s')."','0',1,'".$sart."','".$email."')";
						if ($this->db->query($sqlStr)){
						}else{
								  $flag=4; //出现意外
								return $flag;
						
						}
					}else{
						$sqlStr="insert into ".DB_TABLE_PREFIX."user(user_account,user_password,user_regtime,user_level,user_grade,user_salt,user_email) values('".$username."','".md5(md5($password).$sart)."','".date('Y-m-d H:i:s')."','0',1,'".$sart."','".$email."')";
						if ($this->db->query($sqlStr)){
						}else{
							//return $sqlStr;
								  $flag=5; //出现意外
								return $flag;
						
						}
					}
                }
                else 
                {
                   
					$sqlStr="update ".DB_TABLE_PREFIX."user set user_password='".md5(md5($password).$sart)."' where user_id=".$uid;
					if (!$this->db->query($sqlStr)){
						  $flag=6;  //出现意外
							return $flag;
					}
                }
            }
			
           $this->uc_call("uc_user_synlogin", array($uid));
		   $flag=3;  //登陆成功
            return $flag;
			
        }
        elseif($uid == -1)
        {
            $flag=1;  //用户名不正确
            return $flag;
        }
        elseif ($uid == -2)
        {
           $flag=2;  //密码不正确
            return $flag;
        }
        else
        {
             $flag=7;  //出现意外
            return $flag;
        }
    }

    /**
     * 用户退出
     *
     * @access  public
     * @param
     *
     * @return void
     */
    public function logout()
    {
        $this->uc_call("uc_user_synlogout");   //同步退出
        return true;
    }

	

    /*添加用户*/
   public  function add_user($username, $password, $email,$mobile='')
    {
		/* 检测用户名 */
		$result=0;
        if ($this->check_user($username))
        {
            $result=1; //用户已被注册
            return $result;
        }
        $uid = $this->uc_call("uc_user_register", array($username, $password, $email));
		
        if ($uid <= 0)
        {
             $result=2; //注册失败
			  return $result;
        }
        else
        {
            $sql2="select * from ".DB_TABLE_PREFIX."user where user_id=".$uid;
			$result2=$this->db->query($sql2);
			$row2=$result2->row;
			if ($row2){
				$uid_exist=$uid;
			
			}else{
				$uid_exist="";
			}
			
			//注册成功，插入用户表
			$ip=$_SERVER['REMOTE_ADDR'];
            $reg_date = date('Y-m-d H:i:s');
			$rand=rand(1000,9999);
			$pw2=md5(md5($password).$rand);
			if (empty($uid_exist)){
				$sql="insert into ".DB_TABLE_PREFIX."user(user_id,user_account,user_password,user_email,user_regtime,user_mobile,user_salt,user_level,user_grade,user_ip) values (".$uid.",'".$username."','".$pw2."','".$email."','".$reg_date."','".$mobile."','".$rand."','0',1,'".$ip."')";
				if ($this->db->query($sql)){
			   
				 $flag=3; //注册成功
				  return $flag;
				}else{
				  $flag=4; //注册成功
				  return $flag;
				}
			}else{
				$sql="insert into ".DB_TABLE_PREFIX."user(user_account,user_password,user_email,user_regtime,user_mobile,user_salt,user_level,user_grade,user_board,user_ip) values ('".$username."','".$pw2."','".$email."','".$reg_date."','".$mobile."','".$rand."','0',1,'|0|','".$ip."')";
				if ($this->db->query($sql)){
			   
				 $flag=3; //注册成功
				  return $flag;
				}else{
				  $flag=4; //注册成功
				  return $flag;
				}

			}
        }
		
    }

    /**
     *  检查指定用户是否存在及密码是否正确
     *
     * @access  public
     * @param   string  $username   用户名
     *
     * @return  int
     */
    public function check_user($username, $password = null)
    {
		$userdata = $this->uc_call("uc_user_checkname", array($username));
        if ($userdata == 1)
        {
            return false;
        }
        else
        {
            return  true;
        }
    }


    




	    /**
     * 检测Email是否合法
     *
     * @access  public
     * @param   string  $email   邮箱
     *
     * @return  blob
     */

	
    /* 编辑用户信息 */
   public  function edit_user($cfg, $forget_pwd = '0')
    {   
		$real_username = $cfg['username'];
        $cfg['username'] = addslashes($cfg['username']);
        $set_str = '';
        $valarr =array('email'=>'user_email','mobile'=>'user_mobile','name'=>'user_name','nickname'=>'user_nickname','sex'=>'user_sex','address'=>'user_address');
        foreach ($cfg as $key => $val)
        {
            if ($key == 'username' || $key == 'password' || $key == 'old_password' || $key =='email2')
            {
                continue;
            }
            $set_str .= $valarr[$key] . '=' . "'$val',";
        }
        $set_str = substr($set_str, 0, -1);
        if (!empty($set_str))
        {
            //$sql = "UPDATE " . $GLOBALS['ecs']->table('users') . " SET $set_str  WHERE user_name = '$cfg[username]'";
			$sql_r="update ".DB_TABLE_PREFIX."user set $set_str  where user_account='$cfg[username]'";
			$this->db->query($sql_r);
        }

        if (!empty($cfg['email']))
        {
			if($cfg['email']!=$cfg['email2'])
			{
				$ucresult = $this->uc_call("uc_user_edit", array($cfg['username'], '', '', $cfg['email'], 1));
				if ($ucresult > 0 )
				{
					
					$sqlstr="update ".DB_TABLE_PREFIX."user set user_email='".$cfg['email']."',user_mobile='".$cfg['mobile']."',user_name='".$cfg['name']."',user_nickname='".$cfg['nickname']."',user_sex='".$cfg['sex']."',user_address='".$cfg['address']."' where user_account='".$real_username."'";
					if($this->db->query($sqlstr)){
						$flag = 1; //修改email 成功
					}else{
						$flag = 2; //修改email 不成功
					}
					return $flag;
				}
				else
				{
				   

					 $flag = 2; //修改email 不成功
					return $flag;
				}
			}
			return 1;
          
        }
        if (!empty($cfg['old_password']) && !empty($cfg['password']) && $forget_pwd == 0)
        {
           
			$ucresult = $this->uc_call("uc_user_edit", array($real_username, $cfg['old_password'], $cfg['password'], ''));
            if ($ucresult > 0 )
            {
				//修改密码
				$rand=rand(1000,9999);
				$sql="update ".DB_TABLE_PREFIX."user set user_password='".md5(md5($cfg['password']).$rand)."',user_salt=".$rand." where user_account='".$real_username."'";
				$this->db->query($sql);
                 $flag = 3; //修改密码成功
				return $flag;
            }
            else
            {
                $flag = 4; //修改密码不成功
				return $flag;
            }
        }
        elseif (!empty($cfg['password']) && $forget_pwd == 1)
        {
            $ucresult = $this->uc_call("uc_user_edit", array($real_username, '', $cfg['password'], '', '1'));
            if ($ucresult > 0 )
            {
                $rand=rand(1000,9999);
				$md5Pw=md5(md5($cfg['password']).$rand);
				$sqlt="update ".DB_TABLE_PREFIX."user set user_password='".$md5Pw."',user_salt=".$rand." where user_account='".$real_username."'";
				$this->db->query($sqlt);
				$flag=5;
				return $flag;
            }
        }

       
    }






	/**
	 * 调用UCenter的函数
	 *
	 * @param   string  $func
	 * @param   array   $params
	 *
	 * @return  mixed
	 */
	public  function uc_call($func, $params=null)
	{
		if (!function_exists($func))
		{
			include_once(ROOT_PATH.'uc_client/client.php');
		}

		$res = call_user_func_array($func, $params);


		return $res;
	}
}

?>