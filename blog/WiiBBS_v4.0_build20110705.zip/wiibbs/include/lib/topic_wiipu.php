<?php

/**
 * topic_wiipu.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

class Topic extends User{
  	public function __construct($registry) {
		$this->db = $registry->get('db');
		$this->sysFun=$registry->get('funcSysten');
		$this->session = $registry->get('session');
  	}
	/*
		* function insertTopic 发帖函数
		* @param $data=array('title'=>'','content'=>'','wiibbsUser'=>'','db'='','upload'='','bdCheck'=>'')
		*  return 1 重复发 2 成功 3 出错
	*/	
  	public function insertTopic($data=array()) {
    	$time=date("Y-m-d H:i:s");
		$sql="select topic_id,topic_posttime from ".DB_TABLE_PREFIX."topic where topic_title='".$data['title']."' and datediff(now(),topic_posttime)=0 and topic_user='".$data['wiibbsUser']."'";
		$query_select=$this->db->query($sql) or die ('错误');
		$list=$query_select->rows;
		foreach($list as $row){
			$postTime=$row['topic_posttime'];

			if ($this->sysFun->DateDiff('n', $postTime, $time)<=1){
				return 1;
			}
		}
		$sqlStr="insert into ".DB_TABLE_PREFIX."topic(topic_title,topic_content,topic_user,topic_board,topic_posttime,topic_updatetime,topic_status) values('".$data['title']."','".$data['content']."','".$data['wiibbsUser']."',".$data['bd'].",'".$time."','".$time."','".$data['bdCheck']."')";
		if ($this->db->query($sqlStr)){
			$id=$this->db->getLastId();
			if (!empty($data['upload'])){
				
				//插入附件
				$this->insertFile(0,$data,$id);
			}
			return 2;
		}else
			return 3;
  	}

	/*
		* function editTopic() 修改帖子
		* $data=array('title'=>'','content'=>'','wiibbsUser'=>'','db'='','upload'='','bdCheck'=>'')
		* return true 成功 false 失败
	*/	
  	public function editTopic($data=array()) {
    	$time=date("Y-m-d H:i:s");
		$sql="select * from ".DB_TABLE_PREFIX."topic where topic_id=".$data['topicID']." and topic_board=".$data['bd']." and topic_user='".$data['wiibbsUser']."'";
		$query=$this->db->query($sql);
		$row=$query->row;
		if ($row){
			if(!empty($data['upload']))
			{
				$sql_file="select * from ".DB_TABLE_PREFIX."file where file_topic=".$data['topicID']." and file_sort='0'";
				$query_file=$this->db->query($sql_file);
				$row_file=$query_file->row;
				if ($row_file){
					if (file_exists(ROOT_PATH."userfiles/attach/".$row_file['file_url'])){
						@unlink(ROOT_PATH."userfiles/attach/".$row_file['file_url']);
					}
					if (file_exists(ROOT_PATH."userfiles/high/".$row_file['file_url'])){
						@unlink(ROOT_PATH."userfiles/high/".$row_file['file_url']);
					}
					if (file_exists(ROOT_PATH."userfiles/small/".$row_file['file_url'])){
						@unlink(ROOT_PATH."userfiles/small/".$row_file['file_url']);
					}
					if (file_exists(ROOT_PATH."userfiles/smaller/".$row_file['file_url'])){
						@unlink(ROOT_PATH."userfiles/smaller/".$row_file['file_url']);
					}
					//修改附件
					$this->updateFile(0,$data['topicID'],$data);
				}else{
					$this->insertFile(0,$data,$data['topicID']);
				}
			}
			$sqlStr="update ".DB_TABLE_PREFIX."topic set topic_title='".$data['title']."',topic_content='".$data['content']."',topic_edittime='".$time."' where topic_id=".$data['topicID']." and topic_board=".$data['bd']." and topic_user='".$data['wiibbsUser']."'";
			
			if ($this->db->query($sqlStr))
				return true;
			else
				return false;
		}else{
			return false;
		}
  	}
	/*
		* function getTopicList() 获得帖子列表
		* @param $board 版块id 如果不需要则为空就可以
		* @param $isTop 为空显示所有帖子
		* @param $status 
		* @param $orderField 排序的字段
		* @param $orderValue 排序值 asc or desc
		* @param $hot 精华帖子 值为1表示要查询精华帖子为空在不需要这个条件
		* @param $keyword 搜索关键字  
	*/
	public function getTopicList($board,$isTop,$start='',$end='',$orderField='topic_updatetime',$orderValue='desc',$status='0',$hot='',$keyword=''){
		$sql="select * from ".DB_TABLE_PREFIX."topic where  topic_status='".$status."'";
		if (!empty($board)){
			$sql.=" and  topic_board=".$board;
		}
		if ($isTop!==''){
			$sql.=" and  topic_istop='".$isTop."'";
		}
		if (!empty($hot)){
			$sql.=" and  topic_isgood=1";
		}
		if (!empty($keyword)){
			$sql.=" and  topic_title  like '%".$keyword."%'";
		}
		$sql.=" order by $orderField $orderValue";
		if (!empty($end)){
			if ($start<0) $start=0;
			$sql.=" limit $start,$end";
		}
		$query=$this->db->query($sql);
		return $query->rows;
	}

	/*
		* function getTopicList() 获得帖子列表
		* @param $board 版块id 如果不需要则为空就可以
		* @param $isTop 为空显示所有帖子
		* @param $status 
		* @param $orderField 排序的字段
		* @param $orderValue 排序值 asc or desc
		* @param $hot 精华帖子 值为1表示要查询精华帖子为空在不需要这个条件
		* @param $keyword 搜索关键字  
	*/
	public function getTopicCount($board,$isTop,$status='0',$hot='',$keyword=''){
		$sql="select topic_id from ".DB_TABLE_PREFIX."topic where  topic_status='".$status."'";
		if (!empty($board)){
			$sql.=" and  topic_board=".$board;
		}
		if ($isTop!==''){
			$sql.=" and  topic_istop='".$isTop."'";
		}
		if (!empty($hot)){
			$sql.=" and  topic_isgood=1";
		}
		if (!empty($keyword)){
			$sql.=" and  topic_title  like '%".$keyword."%'";
		}
		$query=$this->db->query($sql);
		return $query->num_rows;
	}


	/*
		* function getTopicFileByTopicID() 获得帖子的附件
		* @param $topicID 帖子ID
	*/
	public function getTopicFileByTopicID($topicID,$type){
		$sql="select * from ".DB_TABLE_PREFIX."file where  file_topic=".$topicID." and file_sort='".$type."' order by file_addtime desc";
		$query=$this->db->query($sql);
		return $query->rows;
	}
	/*
		* function getTopicByID_BD() 根据帖子ID跟所属的版块ID获得帖子
		* @param $id 帖子id
		* @param $bd 版块ID 
		* 如果没有记录返回false 有记录返回记录集
	*/
	public function getTopicByID_BD($id,$bd){
		$sqlStr="select * from ".DB_TABLE_PREFIX."topic where topic_board=".$bd." and topic_id=".$id;
		$query_topic=$this->db->query($sqlStr);
		return $query_topic->row;
	}

	
	/*
		* function getTopicReplyList() 获得帖子回复列表
		* @param $board 版块id 
		* @param $topicID 帖子ID
		* @param $orderField 排序的字段
		* @param $orderValue 排序值 asc or desc
	*/
	public function getTopicReplyList($board,$topicID,$start,$end,$orderField='reply_id',$orderValue='desc'){
		$sql="select reply_content,reply_user,reply_posttime,reply_id from ".DB_TABLE_PREFIX."reply  where reply_board=".$board." and reply_topic=".$topicID ;
		$sql.=" order by $orderField $orderValue";
		if (!empty($end)){
			if ($start<0) $start=0;
			$sql.=" limit $start,$end";
		}
		$query=$this->db->query($sql);
		return $query->rows;
	}

	public function getTopicReplyCount($board,$topicID){
		$sql="select reply_content,reply_user,reply_posttime,reply_id,user_id from ".DB_TABLE_PREFIX."reply,".DB_TABLE_PREFIX."user where reply_board=".$board." and reply_topic=".$topicID ." and user_account=reply_user";
		$query=$this->db->query($sql);
		return $query->num_rows;
	}
	/*
		* function delTopic() 删除帖子
		* @param $board 版块id 
		* @param $topicID 帖子ID
		* @param $manager 是否是管理员
		* @parsm $userGroup 是否是版主
		* @parsm $wiibbsUser 登陆用户
		* return 4 非法操作 2 成功 1 没有删除的权限
		
	*/
	public function delTopic($topicID,$board,$manager,$userGroup,$wiibbsUser){
		//检查该帖子是否存在
		$myself=false;
		$row_topic=$this->getTopicByID_BD($topicID,$board);
		if ($row_topic){
			If ($row_topic['topic_user']!=$wiibbsUser){
				if (!($manager || $userGroup))
					return 1;  
			}else{
				$myself=true;
			}
			if ($myself)
				$type='';
			else if ($manager || $userGroup)
				$type=1;
			//删除附件
			$this->delTopicFile($topicID);
			
			//扣除该帖子用户的积分
			if (!empty($type)){
				$tUser=$row_topic['topic_user'];
				if ($tUser!='Guest'){
					$this->sysFun->updateUserScore($tUser,scoreUserReply,"-1");
				}
			}
			//删除所有回复的附件
			$this->delReplyUploadByTopicID($topicID);
			//删除回复
			$this->delReplyByID_topID($topicID);
			//删除帖子
			$this->delTopicByID($topicID,$board);
			return 2;  //成功
		}else{
			return 4;  //非法操作
		}
	}

	/*
		* function delReply() 删除帖子的某一条回复
		* @param $board 版块id 
		* @param $topicID 帖子ID
		* @param $replyID 回复ID
		* @param $type 删除类型 1 管理员跟版主 为空则是自己
		* return 4 非法操作 2 成功
	*/

	public function delReply($topicID,$board,$replyID,$manager,$userGroup,$userName){
		$myself=false;
		//检查该帖子是否存在
		$row_topic=$this->getTopicByID_BD($topicID,$board);
		if ($row_topic){
			//检查该帖子的回复是否存在
			$row_reply=$this->getrReplyByReID($replyID);
			if ($row_reply){
				If ($row_reply['reply_user']!=$userName){
					if (!($manager || $userGroup))
						return 1;  
				}else{
					$myself=true;
				}
				if ($myself)
					$type='';
				else if ($manager || $userGroup)
					$type=1;
				$sql_file="select file_url from ".DB_TABLE_PREFIX."file where file_topic=$replyID and file_sort='1'";
				$query_file=$this->db->query($sql_file);
				$row_file=$query_file->row;
				if ($row_file){
					//删除回复的附件
					$filename=ROOT_PATH."userfiles/attach/".$row_file['file_url'];
					@unlink($filename);
				}
				$sql_file="delete from ".DB_TABLE_PREFIX."file where file_topic=$replyID and file_sort='1'";
				$this->db->query($sql_file);
				//修改该帖子的回复数
				$this->updateTopicReplyCount($topicID);
				//扣除该帖子用户的积分
				if (!empty($type)){
					$tUser=$row_topic['topic_user'];
					if ($tUser!='Guest'){
						$this->sysFun->updateUserScore($tUser,scoreUserReply,"-1");
					}
				}
				
				//删除该回复
				$this->delReplyByID_topID($topicID,$replyID);
				return 2;  //成功
			}else{
				return 4;  //非法操作
			}
		}else{
			return 4;  //非法操作
		}
	}
	/*
		* function getrReplyByReID 得到回复的记录，检查是否存在此回复
	*/
	private function getrReplyByReID($replyID){
		$sql_r="select * from  ".DB_TABLE_PREFIX."reply where reply_id=".$replyID;
		$query=$this->db->query($sql_r);
		return $query->row;
	}
	/*
		* function updateTopicReplyCount 修改帖子的回复数
	*/
	private function updateTopicReplyCount($topicID){
		$sql_r="update ".DB_TABLE_PREFIX."topic set topic_recount=topic_recount-1 where topic_id=".$topicID;
		$this->db->query($sql_r);
	}
	/*
		* function delReplyByID_topID 删除回复
		* @param $topicID 帖子ID
		* @param $replyID 帖子回复
	*/
	private function delReplyByID_topID($topicID='',$replyID=''){
		$sql_r="delete from ".DB_TABLE_PREFIX."reply where 1=1";
		if (!empty($topicID))
			$sql_r.=" and reply_topic=".$topicID;
		if (!empty($replyID))
			$sql_r.=" and reply_id=".$replyID;
		$this->db->query($sql_r);
	}

	/*
		* function delTopicByID 删除帖子
		* @param $topicID 帖子ID
		* @param $board 版块
	*/

	private function delTopicByID($topicID,$board){
		$sql_r="delete from ".DB_TABLE_PREFIX."topic where topic_id=".$topicID." and topic_board=".$board;
		$this->db->query($sql_r);
	}
	/*
		* function delReplyUploadByTopicID 删除回复的附件
		* @param $topicID 帖子ID
	*/
	private function delReplyUploadByTopicID($topicID){
		$sql_file="select * from ".DB_TABLE_PREFIX."reply where reply_topic=".$topicID;
		$query_r=$this->db->query($sql_file);
		$rows=$query_r->rows;
		foreach ($rows as $value){
			$sql_select="select * from ".DB_TABLE_PREFIX."file where file_topic=".$value['reply_id']." and file_sort='1'";
			$query_select=$this->db->query($sql_select);
			$list_select=$query_select->rows;
			foreach ($list_select as $row_select){
				$filename=ROOT_PATH."userfiles/attach/".$row_select['file_url'];
				@unlink($filename);
			}
			$sql_del="delete from ".DB_TABLE_PREFIX."file where file_topic=".$value['reply_id']." and file_sort='1'";
			$this->db->query($sql_del);
		}
	}


	/*
		* functiondelTopicFile 删除帖子的附件
		* @param $topicID 帖子ID
	*/

	private function delTopicFile($topicID){
		$sql_r="select * from ".DB_TABLE_PREFIX."file where file_topic=".$topicID." and file_sort='0'";
		$query_r=$this->db->query($sql_r);
		$row=$query_r->rows;
		foreach ($row as $value){
			if (file_exists(ROOT_PATH."userfiles/attach/".$value['file_url'])){
				@unlink(ROOT_PATH."userfiles/attach/".$value['file_url']);
			}
			if (file_exists(ROOT_PATH."userfiles/high/".$value['file_url'])){
				@unlink(ROOT_PATH."userfiles/high/".$value['file_url']);
			}
			if (file_exists(ROOT_PATH."userfiles/small/".$value['file_url'])){
				@unlink(ROOT_PATH."userfiles/small/".$value['file_url']);
			}
			if (file_exists(ROOT_PATH."userfiles/smaller/".$value['file_url'])){
				@unlink(ROOT_PATH."userfiles/smaller/".$value['file_url']);
			}
		}
		$sql_d="delete from ".DB_TABLE_PREFIX."file where file_topic=".$topicID." and file_sort='0'";
		$this->db->query($sql_d);
	}


	/*
		* function topTopic()  设置置顶帖子函数
		* return false 失败 true 成功
	*/
	

	public function setTopTopic($topicID,$board){
		$sql="select topic_istop,topic_user from ".DB_TABLE_PREFIX."topic where topic_istop='0' and topic_id=".$topicID." and topic_board=".$board."";
		$query_topic=$this->db->query($sql);
		$row=$query_topic->row;
		if ($row){
			$tUser=$row["topic_user"];
			$result=$this->editTopicTop(1,$topicID,$board);
			if ($result){
				$this->sysFun->updateUserScore($tUser,scoreUserTop,"1");
				return true;
			}else{
				return false;
			}
			
		}else{
			return false;
		}
		
	}

	/*
		* function cancelTopTopic()  取消置顶帖子函数
		* return false 失败 true 成功
	*/
	

	public function cancelTopTopic($topicID,$board){
		$sql="select topic_istop,topic_user from ".DB_TABLE_PREFIX."topic where topic_istop='1' and topic_id=".$topicID." and topic_board=".$board."";
		$query_topic=$this->db->query($sql);
		$row=$query_topic->row;
		if ($row){
			$result=$this->editTopicTop(0,$topicID,$board);
			if ($result){
				return true;
			}else{
				return false;
			}
			
		}else{
			return false;
		}	
	}

	/*
		* function allTopTopic()  设置总置顶帖子函数
		* return false 失败 true 成功
	*/
	

	public function setAllTopTopic($topicID,$board){
		$sql="select topic_istop,topic_user from ".DB_TABLE_PREFIX."topic where topic_istop<>'2' and topic_id=".$topicID." and topic_board=".$board."";
		$query_topic=$this->db->query($sql);
		$row=$query_topic->row;
		if ($row){
			$tUser=$row["topic_user"];
			$result=$this->editTopicTop(2,$topicID,$board);
			if ($result){
				$this->sysFun->updateUserScore($tUser,scoreUserTopAll,"1");
				return true;
			}else{
				return false;
			}
			
		}else{
			return false;
		}
	}

	/*
		* function cancelAllTopTopic()  取消总置顶帖子函数
		* return false 失败 true 成功
	*/
	

	public function cancelAllTopTopic($topicID,$board){
		$sql="select topic_istop,topic_user from ".DB_TABLE_PREFIX."topic where topic_istop='2' and topic_id=".$topicID." and topic_board=".$board."";
		$query_topic=$this->db->query($sql);
		$row=$query_topic->row;
		if ($row){
			
			$result=$this->editTopicTop(0,$topicID,$board);
			if ($result){
				return true;
			}else{
				return false;
			}
			
		}else{
			return false;
		}	
	}
	
	/*
		* function editTopicTop()  修改置顶的状态
		* @param $value 置顶的值
		* return false 失败 true 成功
	*/
	private function editTopicTop($value,$topicID,$board){
		$sqlStr="update ".DB_TABLE_PREFIX."topic set topic_isTop='".$value."' where topic_id=".$topicID." and topic_board=".$board;
		return $this->db->query($sqlStr);
	}
	/*
		* function lockTopic()  锁定
		* return false 失败 true 成功
	*/

	public function lockTopic($topicID,$board){
		//检查是否没被锁定;
		if ($this->checkLockTopic('0',$topicID,$board)){
			if ($this->editLockTopic('1',$topicID,$board)){
				return true;
			}else{
				return false;
			}
		
		}else{
			return false;
		}
	}

	/*
		* function editTopicTop()  修改置顶的状态
		* @param $value 置顶的值
		* return false 失败 true 成功
	*/

	public function cancelLockTopic($topicID,$board){
		//检查是否没被锁定;
		if ($this->checkLockTopic('1',$topicID,$board)){
			if ($this->editLockTopic('0',$topicID,$board)){
				return true;
			}else{
				return false;
			}
		
		}else{
			return false;
		}
	}

	/*
		* function checkLockTopic()  根据值查帖子是否锁定
		* @param $value 锁定的值
		* return false 失败 true 成功
	*/
	public function checkLockTopic($value,$topicID,$board){
		$sqlStr="select topic_islock from ".DB_TABLE_PREFIX."topic where topic_islock='".$value."' and topic_id=".$topicID." and topic_board=".$board;
		$query_lock=$this->db->query($sqlStr);
		$row_lock=$query_lock->row;
		if ($row_lock)
			return true;
		else
			return false;
	}

	/*
		* function editLockTopic()  修改锁定的状态
		* @param $value 锁定的值
		* return false 失败 true 成功
	*/
	private function editLockTopic($value,$topicID,$board){
		$sqlStr="update ".DB_TABLE_PREFIX."topic set topic_islock='".$value."' where topic_id=".$topicID." and topic_board=".$board;
		return $this->db->query($sqlStr);
	}

	/*
		* function digestTopic()  设置为精华帖子
		* return false 失败 true 成功
	*/

	public function digestTopic($topicID,$board){
		//检查是否是普通帖子;
		$row=$this->getTopicByGood(0,$topicID,$board);
		if ($row){
			if ($this->editDigestTopic(1,$topicID,$board)){
				$tUser=$row["topic_user"];
				$this->sysFun->updateUserScore($tUser,scoreUserGood,"1");
				return true;
			}else{
				return false;
			}
		
		}else{
			return false;
		}
	}

	/*
		* function cancelDigestTopic()  取消帖子的精华状态
		* return false 失败 true 成功
	*/

	public function cancelDigestTopic($topicID,$board){
		//检查是否是精华帖子;
		$row=$this->getTopicByGood(1,$topicID,$board);
		if ($row){
			if ($this->editDigestTopic(0,$topicID,$board)){
				return true;
			}else{
				return false;
			}
		
		}else{
			return false;
		}
	}

	/*
		* function getTopicByGood()  根据topic_isGood得到帖子
		* @param $value topic_isGood的值
	*/
	private function getTopicByGood($value,$topicID,$board){
		$sqlStr="select topic_isgood,topic_user from ".DB_TABLE_PREFIX."topic where topic_isgood=".$value." and topic_id=".$topicID." and topic_board=".$board;
		$query_lock=$this->db->query($sqlStr);
		return $query_lock->row;
	}

	/*
		* function editDigestTopic()  修改topic_isGood的状态
		* @param $value 锁定的值
		* return false 失败 true 成功
	*/
	private function editDigestTopic($value,$topicID,$board){
		$sqlStr="update ".DB_TABLE_PREFIX."topic set topic_isgood=".$value." where topic_id=".$topicID." and topic_board=".$board;
		return $this->db->query($sqlStr);
	}

	/*
		* function insertTopicReply()  添加帖子的回复
		* @param $data  $data=array('content'=>'','topicID'=>'','wiibbsUser'=>'','db'='','f_name'='')
		* return 3 失败 2 成功 1 已经发布一次
	*/
	public function insertTopicReply($data=array()){
		$time=date('Y-m-d H:i:s');
		$time=date("Y-m-d H:i:s");
		$sql="select reply_id,reply_posttime from ".DB_TABLE_PREFIX."reply where reply_topic='".$data['topicID']."' and datediff(now(),reply_posttime)=0 and reply_content='".$data['content']."' and reply_user='".$data['wiibbsUser']."'";
		$query_select=$this->db->query($sql) or die ('错误');
		$list=$query_select->rows;
		foreach($list as $row){
			$postTime=$row['reply_posttime'];

			if ($this->sysFun->DateDiff('n', $postTime, $time)<=1){
				return 1;
			}
		}
		$sqlStr="insert into ".DB_TABLE_PREFIX."reply(reply_content,reply_user,reply_board,reply_topic,reply_posttime) values('".$data['content']."','".$data['wiibbsUser']."',".$data['bd'].",".$data['topicID'].",'".$time."')";
		if ($this->db->query($sqlStr)){
			$id=$this->db->getLastId();
			//插入附件
			if (!empty($data['upload'])) $this->insertFile(1,$data,$id);
			
			$sqlStr="update ".DB_TABLE_PREFIX."topic set topic_updatetime='".$time."',topic_recount=topic_recount+1 where topic_board=".$data['bd']." and topic_id=".$data['topicID'];
			$this->db->query($sqlStr);
			$this->sysFun->updateUserScore($data['wiibbsUser'],scoreUserReply,"1");
			$t_row=$this->getTopicByID_BD($data['topicID'],$data['bd']);
			if ($t_row) $user=$t_row['topic_user'];
			if ($user!='Guest'){
				$title=NOTICETITLE;
				$url='topicshow.php?bd='.$data['bd'].'&amp;id='.$data['topicID'].'&amp;t=r';
				$this->sysFun->sendNotice($title,$url,$user,'1');
			}
			return 2;
		}else
			return 3;
	}

	/*
		* function insertFile()  插入附件
		* @param $data  
		* @param $type  0 发帖 1 回帖
	*/

	private function insertFile($type,$data=array(),$id){
		$time=date('Y-m-d H:i:s');
		$sql_rr="insert into ".DB_TABLE_PREFIX."file(file_topic,file_addtime,file_url,file_type,file_name,file_size,file_sort) values (".$id.",'".$time."','".$data['upload']."','".$data['type']."','".$data['fileName']."','".$data['fileSize']."','".$type."')";
		$this->db->query($sql_rr);
	}

	/*
		* function updateFile()  修改附件
		* @param $data  
		* @param $type  0 发帖 1 回帖
		* @param $topicID 修改的帖子或回复的ID
	*/

	private function updateFile($type,$topicID,$data){
		$sql_rr="update ".DB_TABLE_PREFIX."file set file_url='".$data['upload']."',file_type='".$data['type']."',file_name='".$data['fileName']."',file_size='".$data['fileSize']."' where file_topic=".$topicID." and file_sort='".$type."'";
		$this->db->query($sql_rr);
		
	}
	/*
		* function getFileListByID()  根据ID得到附件  
		* @param $type  0 发帖 1 回帖
		* @param $id  帖子或回复的ID
	*/
	public function getFileListByID($type,$id){
		$sql_rr="select * from ".DB_TABLE_PREFIX."file  where file_topic=".$id." and file_sort='".$type."'";
		$query_rr=$this->db->query($sql_rr);
		return $query_rr->rows;
	}

	/*
		* function getAllTopTopic()  得带总置顶的帖子
	*/
	public function getAllTopTopic(){
		$topicList=$this->getTopicList('',2);
		if ($topicList){
			foreach($topicList as $row){
				$file=$this->getFileListByID(0,$row['topic_id']);
				 echo "<div class='caption'><span class='key'>[".S_TOP."]</span>";
				if($row["topic_isgood"]=="1") echo "<span class='key'>[".S_GOOD."]</span>";
				if($file) echo "<span class='key'>[".S_FILE."]</span>";
				echo " <a href=\"topicshow.php?bd=".$row["topic_board"]."&amp;id=".$row["topic_id"]."&amp;rnd=".rand()."\" data-ajax='false'>".$row["topic_title"]."</a>";
				if($row['topic_user']!="Guest") {
					$userRow=$this->getUserByAccount($row["topic_user"]);
					if (empty($userRow['user_nickname']))
						$user_name=$row['topic_user'];
					else
						$user_name=$userRow['user_nickname'];
					echo " <a href='user.php?id=".$row['topic_user']."&amp;url=".urlencode($this->sysFun->getUrl())."'>".$user_name."</a>";
				}else{ 
					echo ' Guest';
				} 
				echo " <span class='explain'>".$row["topic_recount"].S_REPLY.$row["topic_viewcount"].S_SEE."</span></div>";
			}
		}else{
			echo "<div class='caption'>".NOTOPIC."</div>";
		}
	}

	/*
		* function getAllTopTopicWml()  得带总置顶的帖子
	*/
	public function getAllTopTopicWml(){
		$topicList=$this->getTopicList('',2);
		if ($topicList){
			foreach($topicList as $row){
				$file=$this->getFileListByID(0,$row['topic_id']);
				 echo "<p>[".S_TOP."]";
				if($row["topic_isgood"]=="1") echo "[".S_GOOD."]";
				if($file) echo "[".S_FILE."]";
				echo " <a href=\"topicshow.php?bd=".$row["topic_board"]."&amp;id=".$row["topic_id"]."&amp;rnd=".rand()."\" data-ajax='false'>".$row["topic_title"]."</a>";
				if($row['topic_user']!="Guest") {
					$userRow=$this->getUserByAccount($row["topic_user"]);
					if (empty($userRow['user_nickname']))
						$user_name=$row['topic_user'];
					else
						$user_name=$userRow['user_nickname'];
					echo " <a href='user.php?id=".$row['topic_user']."&amp;url=".urlencode($this->sysFun->getUrl())."'>".$user_name."</a>";
				}else{ 
					echo ' Guest';
				} 
				echo " ".$row["topic_recount"].S_REPLY.$row["topic_viewcount"].S_SEE."</p>";
			}
		}else{
			echo "<p>".NOTOPIC."</p>";
		}
	}
	/*
		* function getAllTopTopic_r()  得带总置顶的帖子
	*/
	public function getAllTopTopic_r(){
		$topicList=$this->getTopicList('',2);
		if ($topicList){
			foreach($topicList as $row){
				$file=$this->getFileListByID(0,$row['topic_id']);
				 echo "<div class='caption'><span class='key'>[".S_TOP."]</span>";
				if($row["topic_isgood"]=="1") echo "<span class='key'>[".S_GOOD."]</span>";
				if($file) echo "<span class='key'>[".S_FILE."]</span>";
				echo " <a href=\"topicshow.php?bd=".$row["topic_board"]."&amp;id=".$row["topic_id"]."&amp;rnd=".rand()."\" data-ajax='false'>".$row["topic_title"]."</a>";
				if($row['topic_user']!="Guest") {
					$userRow=$this->getUserByAccount($row["topic_user"]);
					if (empty($userRow['user_nickname']))
						$user_name=$row['topic_user'];
					else
						$user_name=$userRow['user_nickname'];
					echo " <a href='user.php?id=".$row['topic_user']."&amp;url=".urlencode($this->sysFun->getUrl())."'>".$user_name."</a>";
				}else{ 
					echo ' Guest';
				} 
				echo " <span class='explain'>".$row["topic_recount"].S_REPLY.$row["topic_viewcount"].S_SEE."</span></div>";
			}
		}
	}

	public function getAllTopTopic3g_r(){
		$topicList=$this->getTopicList('',2);
		if ($topicList){
			foreach($topicList as $row){
				$file=$this->getFileListByID(0,$row['topic_id']);
				if ($row['topic_user']!='Guest'){
					$userRow=$this->getUserByAccount($row['topic_user']);
					if (!empty($userRow['user_photo'])){
						$user_hesrder=NETURL."/userfiles/header/pic/".$userRow['user_photo'];
					}else{
						if ($userRow['user_sex']=='1')
							$user_hesrder=NETURL."/userfiles/header/1.gif";
						else
							$user_hesrder=NETURL."/userfiles/header/0.gif";
					}
					
				}else
					$user_hesrder=NETURL."/userfiles/header/guest.gif";
				echo "<li>";
				
				echo "<a href=\"topicshow.php?bd=".$row["topic_board"]."&amp;id=".$row["topic_id"]."&amp;rnd=".rand()."\" data-ajax='false'><h3>".$row["topic_title"]." </h3>";
				echo "<p> ".S_TOP;
				if($row["topic_isgood"]=="1") echo " ".S_GOOD ;
				if($file) echo " ".S_FILE;
				echo substr($row['topic_updatetime'],0,10);
				echo "	</p>";
				echo "<span class=\"ui-li-count\">".$row["topic_recount"]."/".$row["topic_viewcount"]."</span>";
				echo "</a>";
				echo "</li>";
			}
		}
	}

	/*
		* function getAllTopTopic_rWml()  得带简版总置顶的帖子
	*/
	public function getAllTopTopic_rWml(){
		$topicList=$this->getTopicList('',2);
		if ($topicList){
			foreach($topicList as $row){
				$file=$this->getFileListByID(0,$row['topic_id']);
				 echo "<p>[".S_TOP."]";
				if($row["topic_isgood"]=="1") echo "[".S_GOOD."]";
				if($file) echo "[".S_FILE."]";
				echo " <a href=\"topicshow.php?bd=".$row["topic_board"]."&amp;id=".$row["topic_id"]."&amp;rnd=".rand()."\" data-ajax='false'>".$row["topic_title"]."</a>";
				if($row['topic_user']!="Guest") {
					$userRow=$this->getUserByAccount($row["topic_user"]);
					if (empty($userRow['user_nickname']))
						$user_name=$row['topic_user'];
					else
						$user_name=$userRow['user_nickname'];
					echo " <a href='user.php?id=".$row['topic_user']."&amp;url=".urlencode($this->sysFun->getUrl())."'>".$user_name."</a>";
				}else{ 
					echo ' Guest';
				} 
				echo " ".$row["topic_recount"].S_REPLY.$row["topic_viewcount"].S_SEE."</p>";
			}
		}
	}


	/*
		* function getTopTopic()  得带置顶的帖子
	*/
	public function getTopTopic($board){
		$topicList=$this->getTopicList($board,1);
		if ($topicList){
			foreach($topicList as $row){
				$file=$this->getFileListByID(0,$row['topic_id']);
				 echo "<div class='caption'><span class='key'>[".S_TOP."]</span>";
				if($row["topic_isgood"]=="1") echo "<span class='key'>[".S_GOOD."]</span>";
				if($file) echo "<span class='key'>[".S_FILE."]</span>";
				echo " <a href=\"topicshow.php?bd=".$row["topic_board"]."&amp;id=".$row["topic_id"]."&amp;rnd=".rand()."\" data-ajax='false'>".$row["topic_title"]."</a>";
				if($row['topic_user']!="Guest") {
					$userRow=$this->getUserByAccount($row["topic_user"]);
					if (empty($userRow['user_nickname']))
						$user_name=$row['topic_user'];
					else
						$user_name=$userRow['user_nickname'];
					echo " <a href='user.php?id=".$row['topic_user']."&amp;url=".urlencode($this->sysFun->getUrl())."'>".$user_name."</a>";
				}else{ 
					echo ' Guest';
				} 
				echo " <span class='explain'>".$row["topic_recount"].S_REPLY.$row["topic_viewcount"].S_SEE."</span></div>";
			}
		}
	}

	public function getTopTopic3g($board){
		$topicList=$this->getTopicList($board,1);
		if ($topicList){
			foreach($topicList as $row){
				$file=$this->getFileListByID(0,$row['topic_id']);
				if ($row['topic_user']!='Guest'){
					$userRow=$this->getUserByAccount($row['topic_user']);
					if (!empty($userRow['user_photo'])){
						$user_hesrder=NETURL."/userfiles/header/pic/".$userRow['user_photo'];
					}else{
						if ($userRow['user_sex']=='1')
							$user_hesrder=NETURL."/userfiles/header/1.gif";
						else
							$user_hesrder=NETURL."/userfiles/header/0.gif";
					}
					
				}else
					$user_hesrder=NETURL."/userfiles/header/guest.gif";
				echo "<li>";
				//echo "<img class=\"ui-li-thumb\"  src=\"".$user_hesrder."\" width=\"115\" height=\"115\"  alt=\"".$row['topic_user']."\">";
				echo "<a href=\"topicshow.php?bd=".$row["topic_board"]."&amp;id=".$row["topic_id"]."&amp;rnd=".rand()."\" data-ajax='false'><h3>".$row["topic_title"]." </h3>";
				echo "<p> ".S_TOP;
				if($row["topic_isgood"]=="1") echo " ".S_GOOD ;
				if($file) echo " ".S_FILE;
				echo substr($row['topic_updatetime'],0,10);
				echo "	</p>";
				echo "<span class=\"ui-li-count\">".$row["topic_recount"]."/".$row["topic_viewcount"]."</span>";
				echo "</a>";
				echo "</li>";
			}
		}
	}

	/*
		* function getTopTopic()  得带置顶的帖子
	*/
	public function getTopTopicWml($board){
		$topicList=$this->getTopicList($board,1);
		if ($topicList){
			foreach($topicList as $row){
				$file=$this->getFileListByID(0,$row['topic_id']);
				 echo "<p>[".S_TOP."]";
				if($row["topic_isgood"]=="1") echo "[".S_GOOD."]";
				if($file) echo "[".S_FILE."]";
				echo " <a href=\"topicshow.php?bd=".$row["topic_board"]."&amp;id=".$row["topic_id"]."&amp;rnd=".rand()."\">".$row["topic_title"]."</a>";
				if($row['topic_user']!="Guest") {
					$userRow=$this->getUserByAccount($row["topic_user"]);
					if (empty($userRow['user_nickname']))
						$user_name=$row['topic_user'];
					else
						$user_name=$userRow['user_nickname'];
					echo " <a href='user.php?id=".$row['topic_user']."&amp;url=".urlencode($this->sysFun->getUrl())."'>".$user_name."</a>";
				}else{ 
					echo ' Guest';
				} 
				echo " ".$row["topic_recount"].S_REPLY.$row["topic_viewcount"].S_SEE."</p>";
			}
		}
	}

	/*
		* function getTopic()  得带所有的的帖子
	*/
	public function getTopic($board,$top,$start='',$end='',$page='1',$key='',$orderField='topic_updatetime',$orderValue='desc',$status='0',$hot='',$keyword=''){
		$topicList=$this->getTopicList($board,$top,$start,$end,$orderField,$orderValue,$status,$hot,$keyword);
		if ($topicList){
			foreach($topicList as $row){
				$file=$this->getFileListByID(0,$row['topic_id']);
				echo "<div class='caption'>";
				if($row["topic_isgood"]=="1") echo "<span class='key'>[".S_GOOD."]</span>";
				if($file) echo "<span class='key'>[".S_FILE."]</span>";
				if (empty($key)){
					echo " <a href=\"topicshow.php?bd=".$row["topic_board"]."&amp;id=".$row["topic_id"]."&amp;rnd=".rand()."\" >".$row["topic_title"]."</a>";
				}else{
					echo " <a href=\"topicshow.php?bd=".$row["topic_board"]."&amp;id=".$row["topic_id"]."&amp;rnd=".rand()."&amp;key=".$key."\">".$row["topic_title"]."</a>";
				}
				if($row['topic_user']!="Guest") {
					$userRow=$this->getUserByAccount($row["topic_user"]);
					if (empty($userRow['user_nickname']))
						$user_name=$row['topic_user'];
					else
						$user_name=$userRow['user_nickname'];
					echo " <a href='user.php?id=".$row['topic_user']."&amp;url=".urlencode($this->sysFun->getUrl())."'>".$user_name."</a>";
				}else{ 
					echo ' Guest';
				} 
				echo " <span class='explain'>".$row["topic_recount"].S_REPLY.$row["topic_viewcount"].S_SEE."</span></div>";
			}
		}else{
			echo "<div class='caption'>".NOTOPIC."</div>";
		}
	}

	public function getTopic3g($board,$top,$start='',$end='',$page='1',$key='',$orderField='topic_updatetime',$orderValue='desc',$status='0',$hot='',$keyword=''){
		$topicList=$this->getTopicList($board,$top,$start,$end,$orderField,$orderValue,$status,$hot,$keyword);
		if ($topicList){
			foreach($topicList as $row){
				$file=$this->getFileListByID(0,$row['topic_id']);
				if ($row['topic_user']!='Guest'){
					$userRow=$this->getUserByAccount($row['topic_user']);
					if (!empty($userRow['user_photo'])){
						$user_hesrder=NETURL."/userfiles/header/pic/".$userRow['user_photo'];
					}else{
						if ($userRow['user_sex']=='1')
							$user_hesrder=NETURL."/userfiles/header/1.gif";
						else
							$user_hesrder=NETURL."/userfiles/header/0.gif";
					}
					
				}else
					$user_hesrder=NETURL."/userfiles/header/guest.gif";
				echo "<li>";
				
				echo "<a href=\"topicshow.php?bd=".$row["topic_board"]."&amp;id=".$row["topic_id"]."&amp;rnd=".rand()."\" data-ajax='false'><h3>".$row["topic_title"]." </h3>";
				echo "<p> ";
				if($row["topic_isgood"]=="1") echo " <span style='color:red;'>".S_GOOD."</span>" ;
				if($file) echo " <span style='color:red; '>".S_FILE."</span>";
				echo substr($row['topic_updatetime'],0,10);
				echo "	</p>";
				echo "<span class=\"ui-li-count\">".$row["topic_recount"]."/".$row["topic_viewcount"]."</span>";
				echo "</a>";
				echo "</li>";
			}
		}
	}

	/*
		* function getTopicWml()  得带所有的的帖子
	*/
	public function getTopicWml($board,$top,$start='',$end='',$page='1',$key='',$orderField='topic_updatetime',$orderValue='desc',$status='0',$hot='',$keyword=''){
		$topicList=$this->getTopicList($board,$top,$start,$end,$orderField,$orderValue,$status,$hot,$keyword);
		if ($topicList){
			foreach($topicList as $row){
				$file=$this->getFileListByID(0,$row['topic_id']);
				echo "<p>";
				if($row["topic_isgood"]=="1") echo "[".S_GOOD."]";
				if($file) echo "[".S_FILE."]";
				echo " <a href=\"topicshow.php?bd=".$row["topic_board"]."&amp;id=".$row["topic_id"]."&amp;rnd=".rand()."&amp;key=".$key."\">".$row["topic_title"]."</a>";
				if($row['topic_user']!="Guest") {
					$userRow=$this->getUserByAccount($row["topic_user"]);
					if (empty($userRow['user_nickname']))
						$user_name=$row['topic_user'];
					else
						$user_name=$userRow['user_nickname'];
					echo " <a href='user.php?id=".$row['topic_user']."&amp;url=".urlencode($this->sysFun->getUrl())."'>".$user_name."</a>";
				}else{ 
					echo ' Guest';
				} 
				echo " ".$row["topic_recount"].S_REPLY.$row["topic_viewcount"].S_SEE."</p>";
			}
		}else{
			echo "<p>".NOTOPIC."</p>";
		}
	}
	/*
		* function getTopicByAccount()  得到某个用户的帖子
		* @param $status   0 审核的 1未审核的 2 所有的
	*/
	public function getTopicByAccount($start='',$end='',$page='1',$status){
		$topicList=$this->getTopicListByAccount($start,$end,$status);
		if ($topicList){
			foreach($topicList as $row){
				$file=$this->getFileListByID(0,$row['topic_id']);
				echo "<div class='caption'>";
				if($row["topic_isgood"]=="1") echo "<span class='key'>[".S_GOOD."]</span>";
				if($file) echo "<span class='key'>[".S_FILE."]</span>";
				echo " <a href=\"topicshow.php?bd=".$row["topic_board"]."&amp;id=".$row["topic_id"]."&amp;rnd=".rand()."\">".$row["topic_title"]."</a>";
				if($status!=2)
				{
					if($row['topic_user']!="Guest") {
						$userRow=$this->getUserByAccount($row["topic_user"]);
						if (empty($userRow['user_nickname']))
							$user_name=$row['topic_user'];
						else
							$user_name=$userRow['user_nickname'];
						echo " <a href='user.php?id=".$row['topic_user']."&amp;url=".urlencode($this->sysFun->getUrl())."'>".$user_name."</a>";
					}else{ 
						echo ' Guest';
					} 
				}
				echo " <span class='explain'>".$row["topic_recount"].S_REPLY.$row["topic_viewcount"].S_SEE."</span></div>";
			}
		}else{
			echo "<div class='caption'>".NOTOPIC."</div>";
		}
	}


	/*
		* function getTopicByAccount()  得到某个用户的帖子
		* @param $status   0 审核的 1未审核的 2 所有的
	*/
	public function getTopicByAccount3g($start='',$end='',$page='1',$status){
		$topicList=$this->getTopicListByAccount($start,$end,$status);
		if ($topicList){
			foreach($topicList as $row){
				$file=$this->getFileListByID(0,$row['topic_id']);
				echo "<div class='caption'>";
				if($row["topic_isgood"]=="1") echo "<span class='key'>[".S_GOOD."]</span>";
				if($file) echo "<span class='key'>[".S_FILE."]</span>";
				echo " <a href=\"topicshow.php?bd=".$row["topic_board"]."&amp;id=".$row["topic_id"]."&amp;rnd=".rand()."\" data-ajax='false'>".$row["topic_title"]."</a>";
				if($status!=2)
				{
					if($row['topic_user']!="Guest") {
						$userRow=$this->getUserByAccount($row["topic_user"]);
						if (empty($userRow['user_nickname']))
							$user_name=$row['topic_user'];
						else
							$user_name=$userRow['user_nickname'];
						echo " <a href='user.php?id=".$row['topic_user']."&amp;url=".urlencode($this->sysFun->getUrl())."'>".$user_name."</a>";
					}else{ 
						echo ' Guest';
					} 
				}
				echo " <span class='explain'>".$row["topic_recount"].S_REPLY.$row["topic_viewcount"].S_SEE."</span></div>";
			}
		}else{
			echo "<div class='caption'>".NOTOPIC."</div>";
		}
	}

	/*
		* function getTopicByAccountWml()  得到简版某个用户的帖子
		* @param $status   0 审核的 1未审核的 2 所有的
	*/
	public function getTopicByAccountWml($start='',$end='',$page='1',$status){
		$topicList=$this->getTopicListByAccount($start,$end,$status);
		if ($topicList){
			foreach($topicList as $row){
				$file=$this->getFileListByID(0,$row['topic_id']);
				echo "<p>";
				if($row["topic_isgood"]=="1") echo "[".S_GOOD."]";
				if($file) echo "[".S_FILE."]";
				echo " <a href=\"topicshow.php?bd=".$row["topic_board"]."&amp;id=".$row["topic_id"]."&amp;rnd=".rand()."\">".$row["topic_title"]."</a>";
				if($status!=2)
				{
					if($row['topic_user']!="Guest") {
						$userRow=$this->getUserByAccount($row["topic_user"]);
						if (empty($userRow['user_nickname']))
							$user_name=$row['topic_user'];
						else
							$user_name=$userRow['user_nickname'];
						echo " <a href='user.php?id=".$row['topic_user']."&amp;url=".urlencode($this->sysFun->getUrl())."'>".$user_name."</a>";
					}else{ 
						echo ' Guest';
					} 
				}
				echo " ".$row["topic_recount"].S_REPLY.$row["topic_viewcount"].S_SEE."</p>";
			}
		}else{
			echo "<p>".NOTOPIC."</p>";
		}
	}

	/*
		* function updateTopicViewCount()  修改帖子的浏览次数
		* @param $board  版块
		* @param $topicID  帖子ID
	*/

	public function updateTopicViewCount($board,$topicID){
		$sql="update ".DB_TABLE_PREFIX."topic set topic_viewcount=topic_viewcount+1 where topic_board=".$board." and topic_id=".$topicID;
		$this->db->query($sql);
	}

	/*
		* function checkTopic()  审核帖子
		* @param $topicID  帖子ID
	*/

	public function checkTopic($topicID){
		$sql="update ".DB_TABLE_PREFIX."topic set topic_status='0' where topic_id=".$topicID;
		if ($this->db->query($sql))
			return true;
		else
			return false;
		
	}

	/*
		* function getCheckTopic()  得带所有未审核帖子
	*/
	public function getCheckTopic($board,$top,$start='',$end='',$page='1',$orderField='topic_updatetime',$orderValue='desc',$status='0',$hot='',$keyword=''){
		$topicList=$this->getTopicList($board,$top,$start,$end,$orderField,$orderValue,$status,$hot,$keyword);
		if ($topicList){
			foreach($topicList as $row){
				echo "<div class='caption'>";
				echo " <a href=\"topiccheck.php?bd=".$row["topic_board"]."&amp;id=".$row["topic_id"]."&amp;rnd=".rand()."&amp;page=".$page."\">".$row["topic_title"]."</a>";
				if($row['topic_user']!="Guest") {
					$userRow=$this->getUserByAccount($row["topic_user"]);
						if (empty($userRow['user_nickname']))
							$user_name=$row['topic_user'];
						else
							$user_name=$userRow['user_nickname'];
					echo " <a href='user.php?id=".$row['topic_user']."&amp;url=".urlencode($this->sysFun->getUrl())."'>".$user_name."</a>";
				}else{ 
					echo ' Guest';
				} 
				echo " </div>";
			}
		}else{
			echo "<div class='caption'>".NOTOPIC."</div>";
		}
	}

	public function getCheckTopic3g($board,$top,$start='',$end='',$page='1',$orderField='topic_updatetime',$orderValue='desc',$status='0',$hot='',$keyword=''){
		$topicList=$this->getTopicList($board,$top,$start,$end,$orderField,$orderValue,$status,$hot,$keyword);
		if ($topicList){
			foreach($topicList as $row){
				if ($row['topic_user']!='Guest'){
					$userRow=$this->getUserByAccount($row['topic_user']);
					if (!empty($userRow['user_photo'])){
						$user_hesrder=NETURL."/userfiles/header/pic/".$userRow['user_photo'];
					}else{
						if ($userRow['user_sex']=='1')
							$user_hesrder=NETURL."/userfiles/header/1.gif";
						else
							$user_hesrder=NETURL."/userfiles/header/0.gif";
					}
					
				}else
					$user_hesrder=NETURL."/userfiles/header/guest.gif";
				echo "<li>";
				echo "<img class=\"ui-li-thumb\"  src=\"".$user_hesrder."\" width=\"115\" height=\"115\"  alt=\"".$row['topic_user']."\">";
				echo "<a href=\"topiccheck.php?bd=".$row["topic_board"]."&amp;id=".$row["topic_id"]."&amp;rnd=".rand()."&amp;page=".$page."\"><h3>".$row["topic_title"]." </h3>";
				echo "<p> ";
				echo substr($row['topic_updatetime'],0,10);
				echo "	</p>";
				echo "</a>";
				echo "</li>";
			}
		}else{
			echo "<li><h3>".NOTOPIC."</h3></li>";
		}
	}
	/*
		* function moveTopic()  转移帖子
		* @param $board  版块
		* @param $topicID  帖子IDs
	*/
	public function moveTopic($board,$topicID){
		$sql="update ".DB_TABLE_PREFIX."topic set topic_board=".$board." where topic_id=".$topicID;
		$this->db->query($sql);
		$sql3="update ".DB_TABLE_PREFIX."reply set reply_board=".$board." where reply_topic=".$topicID;
		$this->db->query($sql3);
	}


	/*
		* function getTopicListByAccountt() 得到某个用户的帖子
		* @param $status  2 全部
	*/
	public function getTopicListByAccount($start='',$end='',$status='0'){
		$sql="select topic_id,topic_title,topic_recount,topic_viewcount,topic_board,topic_isgood,topic_user from ".DB_TABLE_PREFIX."topic where topic_user='".$this->session->data[WiiBBS_ID."wiibbsUser"]."' ";
		if ($status!=2){
			
			$sql.=" and  topic_status='".$status."'";
		}
		
		$sql.=" order by topic_id desc";
		if (!empty($end)){
			if ($start<0) $start=0;
			$sql.=" limit $start,$end";
		}
		$query=$this->db->query($sql);
		return $query->rows;
	}

	/*
		* function getTopicCountByAccount() 获得某个用户的帖子数量
		* @param $status  2 全部 0 审核 1 未审核
	*/
	public function getTopicCountByAccount($status='0'){
		$sql="select topic_id  from ".DB_TABLE_PREFIX."topic where topic_user='".$this->session->data[WiiBBS_ID."wiibbsUser"]."' ";
		if ($status!=2){
			
			$sql.=" and  topic_status='".$status."'";
		}
		$query=$this->db->query($sql);
		return $query->num_rows;
	}


	/*
		* function getHotTopicList() 获得热门帖子
		* @param $startrow开始位置
		* @param $pagesize 每页显示多少行
	*/

	public function getHotTopicList($startrow,$pagesize){
		$sql="select topic_id,topic_title,topic_recount,topic_viewcount,topic_board,topic_isgood from ".DB_TABLE_PREFIX."topic where topic_istop='0' and date_format(topic_posttime,'%Y-%m')='".date('Y-m')."' and topic_status='0' order by topic_recount desc,topic_viewcount desc,topic_id desc limit $startrow,$pagesize";
		$query=$this->db->query($sql);
		return $query->rows;
	}
	
	/*
		* function searchTopic() 搜索帖子
		* @param $key 关键字
	*/
	public function searchTopic($key,$startRow,$pagesize)
	{
		$sql="select  topic_id,topic_title,topic_board from ".DB_TABLE_PREFIX."topic where topic_title like '%".$key."%' order by topic_posttime desc limit $startRow,$pagesize";
		$query=$this->db->query($sql);
		return $query->rows;
	}

	/*
		* function getFileById() 根据id 得到文件的信息
		* @param $id 文件id
	*/

	public function getFileById($id){
		$sql="select * from ".DB_TABLE_PREFIX."file where file_id=".$id;
		$query=$this->db->query($sql);
		return $query->row;

	}
}
?>