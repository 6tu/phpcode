<?php

/**
 * keyword_wiipu.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	class KeyWord{
		function __construct($registry)
		{
			$this->db=$registry->get('db');
		}
		
		/**
		* function searchKey()查询关键字是否存在
		* @param $key 为要查询的关键字
		* return true 存在 false 不存在
		*/
		function searchKey($key)
		{
			$sql="select keyword_id from ".DB_TABLE_PREFIX."keyword where keyword_name='".$key."'";
			$query=$this->db->query($sql);
			if($query->row)
			{
				return true;
			}else{
				return false;
			}
		}
		
		/**
		* function updateKey() 更新关键字
		* @param $key 要更新的关键字
		*/
		function updateKey($key)
		{
			$sql="update ".DB_TABLE_PREFIX."keyword set keyword_count=keyword_count+1,keyword_lasttime='".date('Y-m-d H:i:s')."' where keyword_name='".$key."'";
			$this->db->query($sql);
		}
		
		/**
		* function addKey() 添加一个关键字
		* @param $key 要添加的关键字
		*/
		function addKey($key)
		{
			$sql="insert into ".DB_TABLE_PREFIX."keyword(keyword_name,keyword_count,keyword_lasttime) values ('".$key."',1,'".date('Y-m-d H:i:s')."')";
			$this->db->query($sql);
		}

		/**
		* function getKeyList()获得关键字列表
		* @param $limit 要显示的条数
		*/
		function getKeyList($limit='')
		{
			$sql="select * from ".DB_TABLE_PREFIX."keyword where keyword_index='1' order by keyword_count desc limit ".$limit;
			$query=$this->db->query($sql);
			return $query->rows;
		}

		/**
		* function operateKey()对关键字key的操作
		*/
		function operateKey($key)
		{
			if($this->searchKey($key))
			{
				$this->updateKey($key);
			}else{
				$this->addKey($key);
			}
		}
	}
?>