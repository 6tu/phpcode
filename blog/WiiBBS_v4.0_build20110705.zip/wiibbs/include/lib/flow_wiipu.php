<?php

/**
 * flow_wiipu.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	class Flow{
		function __construct($registry)
		{
			$this->db=$registry->get('db');
		}
		
		/**
		*	updateTodyCount()更新今日流量
		*/
		function updateTodyCount()
		{
			$sql="select * from wiibbs_counter where counter_type='day'";
			$query=$this->db->query($sql);
			if($query->row["counter_date"]==date('Y-m-d')){
				$sql_co="update wiibbs_counter set counter_number=counter_number+1,counter_date='".date('Y-m-d')."' where counter_type='day'";
			  }else{
				$sql_co="update wiibbs_counter set counter_number=1,counter_date='".date('Y-m-d')."' where counter_type='day'";
			  }
			 $this->db->query($sql_co);
		}

		/**
		*	updateAllCount()更新总流量
		*/
		function updateAllCount(){
			$sql_c="update wiibbs_counter set counter_number=counter_number+1 where counter_type='total'";
			$this->db->query($sql_c);
		}

		/**
		*	updateOnlinePerson()更新在线人数
		*/
		function updateOnlinePerson()
		{
			$ip_c=$_SERVER['REMOTE_ADDR']; 
			$sql_c="select * from wiibbs_online where online_ip='".$ip_c."'";
			$query=$this->db->query($sql_c);
			$date=date('Y-m-d H:i:s');
			if(!$query->row){
				$sql_co="insert into wiibbs_online(online_ip,online_time) values('".$ip_c."','".$date."')";
			}else{
				$sql_co="update wiibbs_online set online_time='".$date."' where online_ip='".$ip_c."'";
			}
			$this->db->query($sql_co);
			$this->deleteOutTime($date);
		}

		/**
		*	deleteOutTime()删除超时的在线人数
		*/
		function deleteOutTime($date)
		{
			$sql_c="delete from wiibbs_online where (UNIX_TIMESTAMP('".$date."')-UNIX_TIMESTAMP(online_time))>1800";
			$this->db->query($sql_c);
		}

		/**
		* 
		*/
		function updateFlow()
		{
			$this->updateTodyCount();
			$this->updateAllCount();
			$this->updateOnlinePerson();
		}
	}
?>