<?php

/**
 * msg_wiipu.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	class Msg{
		function __construct($registry)
		{
			$this->db=$registry->get('db');
			$this->session = $registry->get('session');
			$this->ucenter = $registry->get('ucenter');
			$this->sysFun=$registry->get('funcSysten');
		}
		
		/**
		* function addInbox()添加一封收件信息
		* $arr为列名=>列值
		*/
		function addInbox($arr)
		{
			$sql="insert into ".DB_TABLE_PREFIX."msg (msg_send,msg_received,msg_title,msg_content,msg_addtime,msg_isreader,msg_isreply,msg_side) values ('".$this->session->data[WiiBBS_ID."wiibbsUser"]."','".$arr['msg_received']."','".$arr['msg_title']."','".$arr['msg_content']."','".date('Y-m-d H:i:s')."','0','0','1')";
			$this->db->query($sql);
		}

		/**
		* function addOubbox()添加一封发件信息
		* $arr为列名=>列值
		*/
		function addOutbox($arr)
		{
			$sql="insert into ".DB_TABLE_PREFIX."msg (msg_send,msg_received,msg_title,msg_content,msg_addtime,msg_isreader,msg_isreply,msg_side) values ('".$this->session->data[WiiBBS_ID."wiibbsUser"]."','".$arr['msg_received']."','".$arr['msg_title']."','".$arr['msg_content']."','".date('Y-m-d H:i:s')."','0','0','0')";
			$this->db->query($sql);
		}

		/**
		* function deleteBox();
		* $type=0 删除发件箱 $type=1 删除收件箱
		*/
		function deleteBox($id,$type)
		{
			$sql="delete from ".DB_TABLE_PREFIX."msg where msg_id=".$id." and msg_side='".$type."'"	;
			if($this->db->query($sql))
			{
				return true;
			}else{
				return false;
			}
		}

		/**
		*	function getBoxCount()获得邮箱数目
		*/
		function getBoxCount($type)
		{
			if($type=='send')
			{
				$where="msg_send='".$this->session->data[WiiBBS_ID."wiibbsUser"]."' and msg_side=0";
			}else if($type=='receive')
			{
				$where="msg_received='".$this->session->data[WiiBBS_ID."wiibbsUser"]."' and msg_side=1";
			}else if($type=='new')
			{
				$where="msg_received='".$this->session->data[WiiBBS_ID."wiibbsUser"]."' and msg_side=1 and msg_isreader=0";
			}
			$sql="select * from ".DB_TABLE_PREFIX."msg where ".$where;
			$result=$this->db->query($sql);
			return $result->num_rows;
		}

		/**
		*	function getBoxList()获得邮箱列表
		*/
		function getBoxList($startRow,$pageSize,$type)
		{
			if($type=='send')
			{
				$where="msg_send='".$this->session->data[WiiBBS_ID."wiibbsUser"]."' and msg_side=0";
			}else if($type=='receive')
			{
				$where="msg_received='".$this->session->data[WiiBBS_ID."wiibbsUser"]."' and msg_side=1";
			}else if($type=='new')
			{
				$where="msg_received='".$this->session->data[WiiBBS_ID."wiibbsUser"]."' and msg_side=1 and msg_isreader=0";
			}
			$sql="select * from ".DB_TABLE_PREFIX."msg where ".$where." order by msg_id desc limit $startRow,$pageSize";
			$query=$this->db->query($sql);
			return $query->rows;
		}

		/**
		* function getMsgById()根据id获得相应的msg
		* return false不存在
		*/
		function getMsgById($id)
		{
			$sql="select * from ".DB_TABLE_PREFIX."msg where msg_id=".$id;
			$query=$this->db->query($sql);
			if($query->row)
			{
				return $query->row;
			}else{
				return false;
			}
		}

		/**
		* function updateMsgById() 根据id更新相应的msg
		*/
		function updateMsgById($id)
		{
			$sql="update ".DB_TABLE_PREFIX."msg set msg_isreader=1,msg_isreadertime='".date('Y-m-d H:i:s')."' where msg_id=".$id;
			$this->db->query($sql);
		}

		/**
		*	deletMsgById()删除
		*/
		function deletMsgById($id)
		{
			$sql="delete from ".DB_TABLE_PREFIX."msg where msg_id=".$id;
			$this->db->query($sql);
		}
	}
?>