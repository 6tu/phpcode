<?php

/**
 * notice_wiipu.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

class Notice {
  	public function __construct($registry) {
		$this->db = $registry->get('db');
		$this->sysFun=$registry->get('funcSysten');
		$this->session = $registry->get('session');
  	}

	/*
		* function getNoticeCount 得到最后的路径
		* @param $status 0 未读 1已读
	*/	
  	public function getNotice($type) {
		$sql="select notice_url,notice_count from ".DB_TABLE_PREFIX."notice where notice_user='".$this->session->data[WiiBBS_ID."wiibbsUser"]."'";
		$sql.=" and notice_status='0' and notice_type='".$type."' order by notice_id desc limit 1";
		$query_select=$this->db->query($sql);
		return $query_select->row;
  	}

	public function updateNoticeState($type){
		$sql="update ".DB_TABLE_PREFIX."notice set notice_status='1' where notice_user='".$this->session->data[WiiBBS_ID."wiibbsUser"]."' and notice_type='".$type."'";
		$this->db->query($sql);
	}


}
?>