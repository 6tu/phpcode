<?php

/**
 * link_wiipu.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

class Links {
  	public function __construct($registry) {
		$this->db = $registry->get('db');
  	}

	/*
		* function getLinkList() 版块列表
		* @param $index 为空是所有 1为首页的
		* 如果没有记录返回false 有记录返回记录集
	*/
	public function getLinkList($index=''){
		$sqlStr="select * from ".DB_TABLE_PREFIX."link";
		if (!empty($index)) $sqlStr.=" where link_index='1'";
		$sqlStr.=" order by link_order asc,link_id desc";
		$query_topic=$this->db->query($sqlStr);
		return $query_topic->rows;
	}


}
?>