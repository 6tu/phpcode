<?php

/**
 * stat_wiipu.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	class wiiStat{
		function __construct($registry)
		{
			$this->db=$registry->get('db');
		}
		
		/**
		* getOnlineCount()返回在线人数
		*/
		function getOnlineCount()
		{
			$sql="select count(online_ip) as ct from wiibbs_online";
			$query=$this->db->query($sql);
			return $query->row['ct'];
		}

		/**
		*	getMemberCount() 获得在线会员
		*/
		function getMemberCount()
		{
			$sql="select count(user_id) as ct from wiibbs_user";
			$query=$this->db->query($sql);
			return $query->row['ct'];
		}

		/**
		*	getTopicCount() 获得主题数
		*/
		function getTopicCount()
		{
			$sql="select count(topic_id) as ct from wiibbs_topic";
			$query=$this->db->query($sql);
			return $query->row['ct'];
		}

		/**
		*	getReplyCount() 获得回复帖子数目
		*/
		function getReplyCount()
		{
			$sql="select count(reply_id) as ct from wiibbs_reply";
			$query=$this->db->query($sql);
			return $query->row['ct'];
		}

		/**
		*	getReplyCount() 获得帖子数目
		*/
		function getCensusCount()
		{
			return $this->getTopicCount()+$this->getReplyCount();
		}

		/**
		*	getTodayCount() 获得今日流量
		*/
		function getTodayCount()
		{
			$sql="select counter_number from wiibbs_counter where counter_type='day'";
			$query=$this->db->query($sql);
			return $query->row['counter_number'];
		}

		/**
		*	getAllCount() 获得总访问流量
		*/
		function getAllCount()
		{
			$sql="select counter_number from wiibbs_counter where counter_type='total'";
			$query=$this->db->query($sql);
			return $query->row['counter_number'];
		}
	}
?>