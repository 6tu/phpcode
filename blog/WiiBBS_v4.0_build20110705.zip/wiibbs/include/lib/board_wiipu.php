<?php

/**
 * board_wiipu.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

class Board {
  	public function __construct($registry) {
		$this->db = $registry->get('db');
		$this->sysFun=$registry->get('funcSysten');
  	}

	/*
		* function getBoardByID() 根据版块ID获得版块信息
		* @param $id id
		* 如果没有记录返回false 有记录返回记录集
	*/
	public function getBoardByID($id){
		$sqlStr="select * from ".DB_TABLE_PREFIX."board where  board_id=".$id;
		$query_topic=$this->db->query($sqlStr);
		return $query_topic->row;
	}

	/*
		* function getBoardList() 版块列表
		* @param $class 分类的ID
		* 如果没有记录返回false 有记录返回记录集
	*/
	public function getBoardList($class='',$board=''){
		$sqlStr="select board_id,board_name,board_pic from ".DB_TABLE_PREFIX."board where 1=1";
		if (!empty($class)) $sqlStr.=" and board_class=".$class;
		if (!empty($board)) $sqlStr.=" and board_id<>".$board;
		$sqlStr.=" order by board_order asc,board_id desc";
		$query_topic=$this->db->query($sqlStr);
		return $query_topic->rows;
	}

	/*
		* function getBoardClassList() 版块分类列表
		* 如果没有记录返回false 有记录返回记录集
	*/
	public function getBoardClassList(){
		$sqlStr="select boardclass_name,boardclass_id,boardclass_pic from ".DB_TABLE_PREFIX."boardclass order by boardclass_order asc,boardclass_id desc";
		$query_topic=$this->db->query($sqlStr);
		return $query_topic->rows;
	}

	/*
		* function getUsergroup() 得到版块的版主
		* @param $board 版块ID
	*/
	public function getUsergroup($board){
		$rowsList=$this->getUsergroupList($board);
		if ($rowsList){
			foreach($rowsList as $row){
				echo "<a href='user.php?id=".$row['user_account']."&amp;url=".urlencode($this->sysFun->getUrl())."'>".$row['user_account']."</a> ";
			}
		
		}else{
			echo "暂无版主";
		}
	}

	/*
		* function isCheckUsergroup() 检查某个用户是否是某个版块的版主
		* @param $board 版块ID
		* @patam $userName 用户名称
	*/

	public function isCheckUsergroup($userName,$board){
		$sqlStr="select user_id from ".DB_TABLE_PREFIX."user,".DB_TABLE_PREFIX."usergroup where user_account='".$userName."' and usergroup_board=".$board."  and usergroup_user=user_id";
		$query_user=$this->db->query($sqlStr);
		return $query_user->row;
	}

	/*
		* function getUsergroupList() 得到版块的版主列表
		* @param $board 版块ID
	*/

	public function getUsergroupList($board){
		$sqlStr="select user_id,user_name,user_account from ".DB_TABLE_PREFIX."user,".DB_TABLE_PREFIX."usergroup where usergroup_board=".$board." and usergroup_user=user_id";
		$query_user=$this->db->query($sqlStr);
		return $query_user->rows;
	}

}
?>