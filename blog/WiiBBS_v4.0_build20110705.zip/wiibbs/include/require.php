<?php

/**
 * require.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
require_once(PATH.'lib/document_wiipu.php');
require_once(PATH.'lib/function_common.php');
require_once(PATH.'lib/topic_wiipu.php');
require_once(PATH.'lib/board_wiipu.php');
require_once(ROOT_PATH.'lang/'.LANGUAGE.'/common.php');
require_once(ROOT_PATH.'lang/'.LANGUAGE.'/topic.php');
require_once(ROOT_PATH.'lang/'.LANGUAGE.'/function.php');
require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
?>