<?php 
$version='v4.0';
$updateTime='2011-06-22 07:22:35';
$subversion='2011004';
?>