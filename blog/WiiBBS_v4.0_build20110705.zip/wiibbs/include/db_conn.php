<?php
	header("content-type:text/html;charset=utf-8");
	error_reporting(0);
	session_start();
	ob_start();
	define('PATH', str_replace('\\', '/', substr(__FILE__, 0, -11)));  //往前文件所在的文件夹 E:/ljx/p/php/wiibbs/include/
	define('ROOT_PATH', str_replace('include/', '', PATH));  //根目录 E:/ljx/p/php/wiibbs/
	define('DIR_DATABASE', PATH.'lib/');
	if (!file_exists(ROOT_PATH."include/config.php")){
		header("location: install/index.php");
		exit();
	}else{
		if(file_exists(ROOT_PATH."install"))
			rename("install","__".md5("install".rand(100,999)));
	}
	$_ = array();
	require_once(PATH.'config.php');
	require_once(PATH.'lib/mysql.php');
	require_once(PATH.'lib/db_common.php'); 
	require_once(PATH.'func_common.php'); 
	require_once(PATH.'lib/registry_wiipu.php'); 
	require_once(PATH.'lib/session_wiipu.php'); 
	require_once(PATH.'lib/user_wiipu.php'); 
	require_once(PATH.'lib/notice_wiipu.php');
	require_once(PATH.'version.php');
	require_once(PATH.'lib/flow_wiipu.php'); 
	// Database 
	$db = new DB(DB_DRIVER,DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
	$registry = new Registry();
	$registry->set('db', $db);

	//设置网站的皮肤跟语言
	define('THEMES', 'color.css'); //皮肤
	define('LANGUAGE', 'zh-cn'); //语言

	require_once(PATH.'require.php'); 

	//在线流量更新类
	$flow=new Flow($registry);

	//函数类
	$funcSysten=new funcSystem($registry);
	$registry->set('funcSysten', $funcSysten);

	//session
	$session=new Session($registry);
	$registry->set('session', $session);
	//通知类
	$noticeClass=new Notice($registry);
	//当前的样式跟皮肤文件
	$registry->set('themes', THEMES);
	$registry->set('language', LANGUAGE);
	//网站的meta信息
	$registry->set('meta_Author', $_['meta_Author']);
	//网站的根目录
	$registry->set('root_path', ROOT_PATH);
	//网站的根目录
	$registry->set('root_path', ROOT_PATH);
	$registry->set('site_version',$version);
	//本本的文件夹
	$folder_3g='3g';
	$folder_color='color';
	$folder_simple='simple';

	$registry->set('folder_3g', "3g");
	$registry->set('folder_color', "color");
	$registry->set('folder_simple', "simple");
	$registry->set('site_url', NETURL);
	//ucenter整合用的变量`
	if(file_exists(PATH.'ucenter_key.php'))
	{
		require_once(PATH.'ucenter_key.php');
		define('UC_CLIENT_ROOT', ROOT_PATH.'uc_client/');
		include_once(UC_CLIENT_ROOT.'client.php');
		require_once(ROOT_PATH."api/ucenter.php");
		$ucenter=new Ucenter_api($registry);
		$registry->set('ucenter', $ucenter);
	}
	//用户类
	$wiibbsUser=new User($registry);
	if (!file_exists(ROOT_PATH."cache/config.php")){
		$sqlStr="select * from ".DB_TABLE_PREFIX."site limit 0,1";
		$query = $db->query($sqlStr) or die (ERROR_SELECTSQL);
		$row = $query->row;
		if($row){
			$str.="<?php \n";
			$str.="define('SITENAME', '".$row["site_name"]."');//网站名称\n";
			$str.="define('SITELOGO', '".$row["site_logo"]."');//logo\n";
			$str.="define('SITEWIDTH', '".$row["site_width"]."');//网站宽带\n";
			$str.="define('SITECOUNT', '".$row["site_count"]."');//是否显示论坛统计\n";
			$str.="define('MAILSMTP', '".$row["site_mailsmtp"]."');//SMTP服务器\n";
			$str.="define('MAILACCOUNT', '".$row["site_mailaccount"]."');//Email帐号\n";
			$str.="define('MAILAPASSWORD', '".$row["site_mailpassword"]."');//Email密码\n";
			$str.="define('MAILADDRESS', '".$row["site_mailaddress"]."');//Email地址\n";
			$str.="define('SITECODE', '".$row["site_code"]."');//统计代码\n";
			$str.="define('SITEFILTER', '".$row["site_filter"]."');//过滤关键词\n";
			$str.="define('SITETIMEZONE', '".$row["site_timezone"]."');//时区\n";
			$str.="define('SITEEXPRESS', '".$row["site_express"]."');//是否开启表情\n";
			$str.="define('SITEUBB', '".$row["site_ubb"]."');//是否开启ubb\n";
			$str.="define('SITEEMAIL', '0');//是否注册email\n";
			$str.="define('SITEPHONE', '0');//是否注册手机\n";
			$str.="?>";
			$fp=fopen(ROOT_PATH."cache/config.php","a");
			fwrite($fp,$str);
			fclose($fp);
			
		}else{
			echo ERROR_SETINITIALIZE;
			EXIT;
		}
	
	}
	require_once(ROOT_PATH.'config.php');
	require_once(ROOT_PATH.'cache/config.php');

	@date_default_timezone_set(SITETIMEZONE);
	//网站的名称
	$registry->set('site_name', SITENAME);
	//html类
	$Document = new Document($registry);
	$board= new Board($registry);
	$topic= new Topic($registry);
	
?>