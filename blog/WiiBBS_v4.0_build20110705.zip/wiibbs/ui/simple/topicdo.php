<?php

/**
 * topicdo.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
define('THISPATHROOT', str_replace('ui/simple/topicdo.php', '', str_replace('\\', '/', __FILE__)));
require_once(THISPATHROOT.'include/db_conn.php');
$session->data['setUrl']=getUrl();
require_once('usercheck.php');
require_once('checklogin.php');
$action=sqlReplace(trim($_GET["do"]));
$rcode=intval(rand()*1000);
switch($action){
	case "check":
		$id=trim($_GET["id"]);
		$id=intval($id);
		$result=$topic->checkTopic($id);
		if($result)
		{
			alertInfo($_['alert_successCheck'],'topicchecklist.php?bd='.$bd);
		}else{
			alertInfo($_['alert_errorCheck'],'topicchecklist.php?bd='.$bd);
		}
	break;
	case "edit":
		$id=sqlReplace(Trim($_GET["id"]));
		$id=intval($id);
		$title=sqlReplace(Trim($_POST["title"]));
		$content=HTMLEncode($_POST["content"]);
		if (SITEFILTER!=''){
		$filter=str_replace("，",',',SITEFILTER);
		$filters=explode(",",$filter);
		for($i=0;$i<count($filters);$i++)
		{
			if(strpos($title.$content,$filters[$i])>-1)
			{
				alertInfo($_['alert_filter'],'topicedit.php?bd='.$bd.'&amp;id='.$id);
			}
		}
	}	
		if(empty($title)||empty($content)){
			alertInfo($_['alert_contentNull_r'],'topicedit.php?bd='.$bd.'&amp;id='.$id);
		}
		$data=array(
		'topicID'=>$id,
		'title'=>$title,
		'content'=>$content,
		'wiibbsUser'=>$userName,
		'bd'=>$bd,
		);
		$result=$topic->editTopic($data);
		if($result){
			alertInfo($_['alert_postEdit'],'board.php?bd='.$bd);
		}else{
			alertInfo($_['alert_errorEdit'],'topicedit.php?bd='.$bd.'&amp;id='.$id);
		}
		break;
	case "del":
		$id=sqlReplace(Trim($_GET["id"]));
		$id=intval($id);
		$t=empty($_GET["t"])?'':sqlReplace(Trim($_GET["t"]));
		header("location:".NETURL."/ui/".$folder_simple."/topicdeal.php?act=del&bd=".$bd."&id=".$id."&t=".$t);
		exit();
	break;


}
?>