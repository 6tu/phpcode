<?php

/**
 * topicedit.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/simple/topicedit.php', '', str_replace('\\', '/', __FILE__)));
	require_once("topwml.php");
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	require_once('checklogin.php');
	$header_title=$_['header_editTopic'];
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
<?php
	$id=sqlReplace(Trim($_GET["id"]));
	$id=intval($id);
	$row=$topic->getTopicByID_BD($id,$bd);
	If(!$row){
		alertInfo('信息已被删除','index.php');
	}Else{
		$title=$row["topic_title"];
		$content=$row["topic_content"];
	}
?>
	<card id="top" title="<?php echo $_['header_editTopic'];?>">
		<p><?php require_once('noticeinc.php');?></p>
		<p><a href="index.php"><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['header_editTopic']?></p>
		<p>
			<p>
				<p><?php echo $_['text_topicTitle']?>：<input name="title" type="text" value="<?php echo $title?>"/></p>
				<p><?php echo $_['text_topicContent']?>：<input type="text" name="content" value="<?php echo $content?>" /></p>
			</p>
			<p>
				<anchor title="<?php echo $_['header_editTopic']?>"><?php echo $_['btn_do']?>
					<go href="topicdo.php?do=edit&amp;id=<?php echo $id?>&amp;bd=<?php echo $_GET["bd"]?>" method="post" accept-charset="utf-8">
						<postfield name="title" value="$(title)" />
						<postfield name="content" value="$(content)" />
					</go>
				</anchor>
			</p>
		</p>
		<p><?php echo $_['text_topicinfo']?></p>
		<p><?php echo $_['btn_goback']?>[<a href="board.php?bd=<?php echo $bd?>&amp;rnd=<?php echo rand();?>"><?php echo $bdName?></a>]</p>
		<?php 
			$session->data['setSkipUrl']=getUrl();
			require_once('boardswitch.php');
		?>
		<?php require_once('bottom.php');?>
	</card>
</wml>