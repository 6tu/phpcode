<?php

/**
 * stat.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/simple/stat.php', '', str_replace('\\', '/', __FILE__)));
	require_once("topwml.php");
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/applications.php');
	require_once(THISPATHROOT.'include/lib/stat_wiipu.php');
	if(SITECOUNT!=1)
	{
		alertInfo($_['tip_pageExpired'],'index.php');
	}
	$stat=new wiiStat($registry);
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
	<card id="top" title="<?php echo $_['text_Lcount']?>">
		<p><?php require_once('noticeinc.php');?></p>
		<p><?php require_once('logininc.php');?></p>
		<p><a href="index.php"><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_Lcount']?></p>
		<p><?php echo $_['text_online'];?>：<?php echo $stat->getOnlineCount();?></p>
		<p><?php echo $_['text_memberCount'];?>：<?php echo $stat->getMemberCount();?></p>
		<p><?php echo $_['text_topicCount'];?>：<?php echo $stat->getTopicCount();?> </p>
		<p><?php echo $_['text_cenusCount'];?>：<?php echo $stat->getCensusCount();?></p>
		<p><?php echo $_['text_todayFlow'];?>：<?php echo $stat->getTodayCount();?> </p>
		<p><?php echo $_['text_allFlow'];?>：<?php echo $stat->getAllCount();?></p>
		<?php require_once('bottom.php');?>
	</card>
</wml>