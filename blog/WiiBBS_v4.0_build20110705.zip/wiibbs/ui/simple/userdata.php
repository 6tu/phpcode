<?php

/**
 * userdata.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/simple/userdata.php', '', str_replace('\\', '/', __FILE__)));
	require_once("topwml.php");
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	require_once('usercheck.php');
	$user=$wiibbsUser->getUserByAccount();
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
	<card id="top" title="<?php echo $_['text_myStuff'];?>">
		<p><?php require_once('noticeinc.php');?></p>
		<p><a href='index.php'><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_myStuff'];?></p>
		<p><?php echo $_['text_nikeName'];?>：<?php echo $user['user_nickname']?></p>
		<p><?php echo $_['text_score'];?>：<?php echo $user['user_score']?></p>
		<p><?php echo $_['text_grade'];?>：<?php echo $user['user_grade']?></p>
		<p><?php echo $_['text_regTime'];?>：<?php echo $user['user_regtime']?></p>
		<p><?php echo $_['text_logCount'];?>：<?php echo $user['user_logincount']?></p>
		<p><?php echo $_['text_lastLoginTime'];?>：<?php echo $user['user_lastlogin']?></p>
		<p>[<a href='userdeatils.php?url=<?php echo urlencode($funcSysten->getUrl());?>'><?php echo $_['text_details'];?></a>]  [<a href='usercenter.php'><?php echo $_['btn_goback']?></a>]</p>
		<?php 
			$session->data['setSkipUrl']=getUrl();
			require_once('boardswitch.php');
		?>
		<?php require_once("bottom.php");?>
	</card>
</wml>