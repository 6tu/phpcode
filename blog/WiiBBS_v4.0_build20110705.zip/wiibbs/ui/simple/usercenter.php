<?php

/**
 * usercenter.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/simple/usercenter.php', '', str_replace('\\', '/', __FILE__)));
	require_once("topwml.php");
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo($_['tip_returnlogin'],'login.php');
	}
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
	<card id="top" title="<?php echo $_['text_userCenter'];?>">
		<p><?php require_once('noticeinc.php');?></p>
		<p><a href="index.php"><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_userCenter'];?></p>
		<p><b><?php echo $_['text_myBox'];?></b></p>
		<p><a href='msg_send.php?url=<?php echo urlencode($funcSysten->getUrl());?>'><?php echo $_['text_writeBox'];?></a></p>
		<p><a href='msg_list.php?act=new'><?php echo $_['text_unredBox'];?></a></p>
		<p><a href='msg_list.php?act=receive'><?php echo $_['text_inBox'];?></a></p>
		<p><a href='msg_list.php?act=send'><?php echo $_['text_outBox'];?></a></p>
		<p><b><?php echo $_['text_myStuff'];?></b></p>
		<p><a href='userdata.php'><?php echo $_['text_myStuff'];?></a></p>
		<p><a href='useredit.php'><?php echo $_['text_editStuff'];?></a></p>
		<p><a href='userpassword.php'><?php echo $_['text_editPwd'];?></a></p>
		<p><b><?php echo $_['text_myTopic'];?></b></p>
		<p><a href='mytopic.php'><?php echo $_['text_mySendTopic'];?></a></p>
		<?php require_once('bottom.php');?>
	</card>
</wml>