<?php

/**
 * search.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/simple/search.php', '', str_replace('\\', '/', __FILE__)));
	require_once("topwml.php");
	require_once(THISPATHROOT.'include/lib/keyword_wiipu.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/applications.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	$keyword=new KeyWord($registry);
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
	<card id="top" title="<?php echo $_['text_searchTopic']?>">
		<p><?php require_once('noticeinc.php');?></p>
		<p><?php require_once('logininc.php');?></p>
		<p><a href="index.php"><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_searchTopic'];?></p>
		<input type='text' name='search'/>
		<anchor  title="<?php echo $_['btn_search'];?>"><?php echo $_['btn_search'];?> 
			<go href="search.php" method="get" accept-charset="utf-8"> 
				<postfield name="search" value="$(search)"/> 
			</go> 
		</anchor> 
		<?php
		$filterResult=false;
		$search=empty($_GET['search'])?'':sqlReplace(trim($_GET['search']));
		if(!empty($search))
		{
			if (SITEFILTER!=''){
				$filter=str_replace("，",',',SITEFILTER);
				$filters=explode(",",$filter);
				for($i=0;$i<count($filters);$i++)
				{
					if(strpos($search,$filters[$i])>-1)
					{
						
						$filterResult=true;
						
					}
				}
			}
			
			if (!$filterResult){
			$keyword->operateKey($search);
			$topicList=$topic->searchTopic($search,0,10);
			if (count($topicList)>1)
				echo "<p><b>“".$search."”".$_['tip_search']."</b></p>";
			
				foreach($topicList as $top)
				{
				?>
					<p> <a href="topicshow.php?bd=<?php echo $top["topic_board"]?>&amp;id=<?php echo  $top["topic_id"]?>&amp;rnd=<?php echo rand();?>"><?php echo  $top["topic_title"]?></a></p>
			<?php
				}
				}else{
					alertInfo_simple($_['alert_filter_r'],'search.php');
				}
		  }else{
				
				$keyList=$keyword->getKeyList(10);
				
				foreach($keyList as $key)
				{
					echo "<p><a href='search.php?search=".$key['keyword_name']."'>".$key['keyword_name']."</a></p>";
				}
			}
		
			?>
		<?php require_once('bottom.php');?>
	</card>
</wml>
