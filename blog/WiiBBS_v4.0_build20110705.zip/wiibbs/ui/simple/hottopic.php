<?php

/**
 * hottopic.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/simple/hottopic.php', '', str_replace('\\', '/', __FILE__)));
	require_once("topwml.php");
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/applications.php');
	$session->data['setUrl']=getUrl();
	$session->data['setSkipUrl']=getUrl();
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
	<card id="top" title="<?php echo $_['text_HotTopic']?>">
		<p><?php require_once("noticeinc.php");?></p>
		<p><?php require_once("logininc.php");?></p>
		<p><?php require_once("tab.php");?></p>
		<?php
			$topics=$topic->getHotTopicList(0,10);
			if(count($topics)<1)
			{
				echo "<p>".$_['tip_noHotTopic']."</p>";
			}
			for($i=0;$i<count($topics);$i++)
			{
			?>
				<p><?php echo ($i+1)."."; if($topics[$i]["topic_isgood"]=="1"){ echo "[".S_GOOD."]";}?><?php if($topic->getFileListByID(0,$topics[$i]['topic_id'])) echo "[".S_FILE."]"; ?><a href="topicshow.php?bd=<?php echo $topics[$i]["topic_board"]?>&amp;id=<?php echo $topics[$i]["topic_id"]?>&amp;rnd=<?php echo rand()?>"><?php echo $topics[$i]["topic_title"]?></a> <?php echo $topics[$i]["topic_recount"].S_REPLY.$topics[$i]["topic_viewcount"].S_SEE?></p>
		<?php
			}
		?>
		<?php require_once('bottom.php');?>
	</card>
</wml>