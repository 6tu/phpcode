<?php

/**
 * userdeatils.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/simple/userdeatils.php', '', str_replace('\\', '/', __FILE__)));
	require_once("topwml.php");
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	$header_title=$_['text_details'];
	 $userName=$wiibbsUser->checkISlogin();
	 if (empty($userName)){
		header("location:".NETURL."/ui/".$folder_color."/error.php?err=139");	
		exit();
	 }
	$uid=empty($_GET['uid'])?'':sqlReplace(trim($_GET['uid']));
	$url=sqlReplace(trim($_GET['url']));
	$user=$wiibbsUser->getUserByAccount($uid);
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
	<card id="top" title="<?php echo $_['text_details'];?>">
		<p><?php require_once('noticeinc.php');?></p>
		<p><a href='index.php'><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_details'];?></p>
		<p><?php echo $_['text_nikeName'];?>：<?php echo $user['user_nickname']?></p>
		<p><?php echo $_['text_account'];?>：<?php echo $user['user_account']?></p>
		<p><?php echo $_['text_name'];?>：<?php echo $user['user_name']?></p>
		<p><?php echo $_['text_score'];?>：<?php echo $user['user_score']?></p>
		<p><?php echo $_['text_grade'];?>：<?php echo $user['user_grade']?></p>
		<p><?php echo $_['text_sex'];?>：<?php  if($user['user_sex']==1){
			echo $_['text_man']; }else if($user['user_sex']==2){ echo $_['text_women'];} ?></p>
		<p><?php echo $_['text_brith'];?>：<?php echo $user['user_birthday']?></p>
		<p><?php echo $_['text_mobile'];?>：<?php echo $user['user_mobile']?></p>
		<p><?php echo $_['text_email'];?>：<?php echo $user['user_email']?></p>
		<p><?php echo $_['text_qq'];?>：<?php echo $user['user_qq']?></p>
		<p><?php echo $_['text_sina'];?>：<?php echo $user['user_sina']?></p>
		<p><?php echo $_['text_province'];?>：<?php echo $user['user_province']?></p>
		<p><?php echo $_['text_city'];?>：<?php echo $user['user_city']?></p>
		<p><?php echo $_['text_address'];?>：<?php echo $user['user_address']?></p>
		<p><?php echo $_['text_regTime'];?>：<?php echo $user['user_regtime']?></p>
		<p><?php echo $_['text_logCount'];?>：<?php echo $user['user_logincount']?></p>
		<p><?php echo $_['text_lastLoginTime'];?>：<?php echo $user['user_lastlogin']?></p>
		<p>[<a href='<?php echo $url;?>'><?php echo $_['btn_goback']?></a>]</p>
		<?php require_once("bottom.php");?>
	</card>
</wml>