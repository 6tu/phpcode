<?php

/**
 * topicreplylist.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/simple/topicreplylist.php', '', str_replace('\\', '/', __FILE__)));
	require_once("topwml.php");
	require_once(THISPATHROOT.'include/lib/ubb_common.php');
	require_once(THISPATHROOT.'include/lib/image_common.php');
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
<?php
	If(empty($userName)){
		If($bdType!=4){
			require_once('checklogin.php');
		} 
	}
	$id=sqlReplace(trim($_GET["id"]));
	if(!empty($_GET['t'])){
		$t=sqlReplace(trim($_GET["t"]));
	}else{
		$t="desc";
	}
	$row=$topic->getTopicByID_BD($id,$bd);
	If(!$row){
		alertInfo($_['alert_noNEW'],'index.php');
	}Else{
		$topicLock=$row["topic_islock"];
		$topicTitle=$row["topic_title"];
	}
	$header_title=$_['text_comment'].$topicTitle;
?>
<card id="top" title="<?php echo $header_title;?>">
<?php require_once('noticeinc.php');?>
<?php require_once('logininc.php');?>
<p>
	<a href="index.php"><?php echo $_['text_index']?></a> &gt;&gt; <a href="board.php?bd=<?php echo $bd?>&amp;rnd=<?php echo rand();?>"><?php echo $bdName?></a> &gt;&gt; <?php echo $_['text_comment']?>
	<p>
		<b> 
			<a href='topicreplylist.php?t=asc&amp;bd=<?php echo $bd?>&amp;id=<?php echo $id?>'>[<?php echo $_['text_orderASC']?>]</a> <a href='topicreplylist.php?t=desc&amp;bd=<?php echo $bd?>&amp;id=<?php echo $id?>'>[<?php echo $_['text_orderDESC']?>]</a>
		</b>
	</p>
</p>
<p>
	<?php If($topicLock=="0"){?>
		<input inputmode="user predictOn" name="content" value="<?php echo $_['text_contentDefault']?>"/> 
		<anchor  title="<?php echo $_['text_reply'];?>"><?php echo $_['text_reply'];?> 
			<go href="topicreplydo.php?do=post&amp;bd=<?php echo $bd?>&amp;id=<?php echo $id?>&amp;key=list" method="post" accept-charset="utf-8"> 
				<postfield name="content" value="$(content)"/> 
			</go> 
		</anchor>
	<?php }?>
</p>
<?php
	$page=(empty($_GET['page']))?"":$_GET['page'];
	if (empty($page)||!is_numeric($page))$page=1;
	
	//查询平常帖子
	$pagesize=15;
	$startRow=0;
	$startRow=($page-1)*$pagesize;
	$rscount=$topic->getTopicReplyCount($bd,$id);
	if ($rscount%$pagesize==0)
		$pagecount=$rscount/$pagesize;
	else
		$pagecount=ceil($rscount/$pagesize);
	$replyList=$topic->getTopicReplyList($bd,$id,$startRow,$pagesize,'reply_id',$t);
	$i=1;
	if($t=='asc'){	
		$sub=($page-1)*$pagesize+1;
	}else{
		$sub=$rscount-($page-1)*$pagesize;
	}
	foreach($replyList as $row){
		if ($i%2==0)
			$class="remarksodd";
		else
			$class="remarks";
		echo "<p>";
		echo $sub.".";
		If($row["reply_user"]!="Guest"){
			$userRow=$wiibbsUser->getUserByAccount($row["reply_user"]);
			$petName=$userRow['user_nickname'];
			if (!empty($petName))
				$replyUser=$petName;
			else
				$replyUser=$row["reply_user"];
			echo "<a href=\"user.php?id=".$row["reply_user"]."&amp;url=".urlencode($funcSysten->getUrl())."\">".$replyUser."</a> ";
		}else{
			echo $row["reply_user"]." ";
		}
		echo $row["reply_posttime"];
		If($row["reply_user"]==$userName || $manager || $userGroup)
			echo " [<a href=\"topicreplydo.php?do=del&amp;bd=".$bd."&amp;id=".$id."&amp;rid=".$row["reply_id"]."&amp;key=list\">删</a>]<br/><br/>";
			$content=$row["reply_content"];
			echo $content ;
					
		echo "</p>";
		$i++;
		if($t=='asc')
		{
			$sub++;
		}else{
			$sub--;
		}
				
		}
	if ($pagecount>1){
		echo showPage1('topicreplylist.php?t='.$t.'&amp;bd='.$bd.'&amp;id='.$id,$page,$pagesize,$rscount,$pagecount);
	}
?>
<p>
	<?php echo $_['btn_goback']?>[<a href="board.php?bd=<?php echo $bd?>&amp;rnd=<?php echo rand();?>"><?php echo $bdName?></a>]
</p>
<?php 
	$session->data['setSkipUrl']=getUrl();
	require_once('boardswitch.php');
?>
<?php require_once('bottom.php');?>
</card>
</wml>