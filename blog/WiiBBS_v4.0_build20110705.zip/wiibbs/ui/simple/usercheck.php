<?php

/**
 * usercheck.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	$bd=empty($_GET["bd"])?0:sqlReplace($_GET["bd"]);
	if ($bd>0){
		$row=$board->getBoardByID($bd);
		if(!$row){
			alertInfo("版面不存在或已被删除！","index.php");
			exit();
		 }else{
			$bdName=$row["board_name"];
			$bdDesc=$row["board_desc"];
			$bdType=$row["board_type"];
			$bdAdmin=$row["board_admin"];
			$bdUsers=$row["board_users"];
			$bdUsers=explode("|",$row["board_users"]);
			$bdCheck=$row["board_ischeck"];
			$upload=$row["board_upload"];
			$boardcategory=$row['board_category'];
			$boardClass=$row['board_class'];
		 }
	}else{
		$bdName='';
		$bdCheck='';
	}
  $userGroup=$board->getUsergroupList($bd);
  foreach($userGroup as $rows){
	$comm="|";
	$bdAdmin.=$comm.$rows['user_account'];
  }
  $userName=$wiibbsUser->checkISlogin();
  If(!empty($userName)){
		$row=$wiibbsUser->getUserByAccount();
		if ($row){
			$userVip=$row["user_isvip"];
			$userLevel=$row["user_level"];
		}
  }else{
	$userVip='';
	$userLevel='';
  }
  if ($bd>0){

	 If($bdType!="0"){
		If(empty($userName)){
			If($bdType!=4 && $bdType!=6){
				header("location:".NETURL."/ui/".$folder_simple."/error.php?err=139");	
				exit();
			}
		}Else{
			if(($bdType=="2") && ($userVip=="0")){
				header("location:".NETURL."/ui/".$folder_simple."/error.php?err=140");	
				exit();
			}
			If(($bdType=="3") && ($userLevel<="1")){
				header("location:".NETURL."/ui/".$folder_simple."/error.php?err=141");	
				exit();
			}
				
			if(!empty($bdAdmin)){
				$wiibbs_admin=explode("|",$bdAdmin);
			}else{
				$wiibbs_admin="";
			}
			if(!in_array($userName,$bdUsers) && $bdType=="5"){
				if(!in_array($userName,$wiibbs_admin)){
				header("location:".NETURL."/ui/".$folder_simple."/error.php?err=204");
				exit();
				}
			}
		}
	 }
  }
	$manager=false;
	$userGroup=false;
	
	If ($userLevel=="2"){
		$manager=true;
		$userGroup=true;
	}
	if ($board->isCheckUsergroup($userName,$bd)) $userGroup=true;

?>