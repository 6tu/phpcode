<?php

/**
 * login.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/simple/login.php', '', str_replace('\\', '/', __FILE__)));
	require_once("topwml.php");
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	$header_title=$_['text_memberLogin'];
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
	<card id="top" title="<?php echo $_['text_memberLogin']?>">
		<p><a href="index.php"><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_memberLogin']?></p>
		<p><b><?php echo $_['text_memberLogin']?>  <a href='register.php'><?php echo $_['text_userRegister'];?></a></b></p>
		<p>
			<p><?php echo $_['text_accountoremail'];?>：<input  type='text' name='account'/></p>
			<p>　　 　　　 <?php echo $_['text_password'];?>：<input   type='password' name='pwd'/></p>
			<p>
				<anchor  title="<?php echo $_['btn_search'];?>"><?php echo $_['btn_login'];?> 
					<go href="userlogin_do.php" method="post" accept-charset="utf-8"> 
						<postfield name="account" value="$(account)"/> 
						<postfield name="pwd" value="$(pwd)"/> 
					</go> 
				</anchor>
			　<a href='usergetpw.php'><?php echo $_['btn_forgetpw'];?></a></p>
			<p>
				<?php echo $_['tip_tips'];?><br/>
				<?php echo $_['tip_login1'];?><br/>
				<?php echo $_['tip_login2'];?><br/>
			</p>
		</p>
		<?php require_once('bottom.php');?>
	</card>
</wml>