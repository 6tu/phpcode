<?php

/**
 * header.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
 
		if(SITELOGO!=''){
			$imagesize=getimagesize(NETURL."/".SITELOGO);
			$width=$imagesize[0];
			$height=$imagesize[1];
			echo "<img src='".NETURL."/".SITELOGO."' alt='".SITENAME."' width='".$width."' height='".$height."'/>";
		}else{
			echo SITENAME;
		}		
	?>