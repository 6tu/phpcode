<?php

/**
 * topicshow.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/simple/topicshow.php', '', str_replace('\\', '/', __FILE__)));
	require_once("topwml.php");
	require_once(THISPATHROOT.'include/lib/ubb_common.php');
	require_once(THISPATHROOT.'include/lib/image_common.php');
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
<?php
	$id=sqlReplace(Trim($_GET["id"]));
	$key = (empty($_GET["key"]))?"":$_GET['key'];
	$t = (empty($_GET["t"]))?"":$_GET['t'];  
	if (!empty($t)) $noticeClass->updateNoticeState(1);
	$id=intval($id);
	$url="id=".$id."&amp;bd=".$bd;
	
	$row=$topic->getTopicByID_BD($id,$bd);
	If(!$row){
		alertInfo($_['alert_noNEW'],'index.php');
	}Else{
		$title=$row["topic_title"];
		$content=$row["topic_content"];
		$view=$row["topic_viewcount"]+1;
		$addTime=$row["topic_posttime"];
		$editTime=$row["topic_edittime"];
		$reCount=$row["topic_recount"];
		$isLock=$row["topic_islock"];
		$isTop=$row["topic_istop"];
		$poster=$row["topic_user"];
		$isGood = $row["topic_isgood"];
	}
	//判断权限
	$myself=false;
	If ($poster==$userName && $poster!='Guest')  $myself=true;
	$header_title=$title;
	if ($poster!='Guest'){
		$userRow=$wiibbsUser->getUserByAccount($poster);
		$petName=$userRow['user_nickname'];
	}
?>
<card id="top" title="<?php echo $header_title;?>">
<p><?php require_once('noticeinc.php');?>
<?php require_once('logininc.php');?></p>

<p><a href="index.php"><?php echo $_['text_index']?></a> &gt;&gt; <a href="board.php?bd=<?php echo $bd?>&amp;rnd=<?php echo rand();?>"><?php echo $bdName?></a></p>

<p>
	<b><?php echo $title?></b>
	<p><?php If($poster!="Guest"){?><a href="user.php?id=<?php echo $poster?>&amp;url=<?php echo urlencode($funcSysten->getUrl())?>"><?php if (!empty($petName)) echo $petName;else echo $poster;?></a><?php }else{?><?php echo $poster?><?php }?><?php echo $_['text_write']?> <?php echo $addTime?></p>
	<p><?php if ($myself || $manager || $userGroup){?>[<a href="topicdo.php?bd=<?php echo $bd?>&amp;id=<?php echo $id?>&amp;do=del"><?php echo $_['text_topicdel']?></a>]<?php }?><?php If($myself){?>  [<a href="topicedit.php?bd=<?php echo $bd?>&amp;id=<?php echo $id?>"><?php echo $_['text_topicEdit']?></a>] <?php }?>
	</p>
 <?php
	//帖子内容分页
	mb_internal_encoding("UTF-8");
	$all=(empty($_GET["all"]))?"":$_GET['all'];
	$logtextx=$content;
	//没有换行的原因
	$logtextx=$logtextx;
	//开始分页  
	if(!empty($_GET["page"]))  $page=(empty($_GET["page"]))?"":$_GET["page"]; 
	$PageLength=900;
	$CLength=mb_strLen($logtextx);
	//$str=cutstr($logtextx,$CLength);
	if($CLength%$PageLength==0){
		$pagecount=$CLength/$PageLength;
	}else{
		$pagecount=(intval($CLength/$PageLength))+1;
	}
	if(!isset($page))
	{
		$page=1;
	}
	if(($page<1) || (is_null($page))) 
		$page=1; 
	if($page>$pagecount) $Page=$pagecount; 
	if($page==1){
		$a=0; 
		//修改浏览次数
		$topic->updateTopicViewCount($bd,$id);
	}elseif($page>1){ 
		$a=($page-1)*$PageLength; 
	}
	If($all=="all"){
		$wen=mb_substr($logtextx,$a);
	}Else{
		$wen=mb_substr($logtextx,$a,$PageLength); 
	} 
	echo "<p>".$wen."</p>"; 
	if($pagecount>1)
	{
		echo "<p>"; 
		echo morePage("topicshow.php?".$url,$page,$PageLength,$CLength,$pagecount);
		echo "</p>"; 
	}
 ?>
	<p><a href='topicpost.php?bd=<?php echo $bd?>&amp;key=post'>[<?php echo $_['text_postTopic']?>]</a></p>
</p>
<b><?php echo $_['text_comment'];?></b>
<p>
	<?php
		$replyList=$topic->getTopicReplyList($bd,$id,0,4);
		$i=1;
		$sub=0;
		foreach($replyList as $row){
			if ($i%2==0)
				$class="remarksodd";
			else
				$class="remarks";
			echo "<p>";
			echo $reCount-$sub.".";
			If($row["reply_user"]!="Guest"){
				$userRow=$wiibbsUser->getUserByAccount($row["reply_user"]);
				$petName=$userRow['user_nickname'];
				if (!empty($petName))
					$replyUser=$petName;
				else
					$replyUser=$row["reply_user"];
				echo "<a href=\"user.php?id=".$row["reply_user"]."&amp;url=".urlencode($funcSysten->getUrl())."\">".$replyUser."</a> ";
			}else{
				echo $row["reply_user"]." ";
			}
			echo $row["reply_posttime"];
			If($row["reply_user"]==$userName || $manager || $userGroup)
				echo " [<a href=\"topicreplydo.php?do=del&amp;bd=".$bd."&amp;id=".$id."&amp;rid=".$row["reply_id"]."\">".$_['text_topicdel']."</a>]";
			$content=$row["reply_content"];
			echo "<p>".$content."</p>" ;
			echo "</p>";
			$i++;
			$sub++;
		}
	?>
	<a href='topicreplylist.php?bd=<?php echo $bd?>&amp;id=<?php echo $id?>'><?php echo $_['text_morecomment']?>（<?php echo $reCount?>）</a>
</p>
<p>
	<?php If($isLock=="0"){?>
		<p>
			<input name="content" value="<?php echo $_['text_contentDefault'];?>" /><br/>
		</p>
		<p>
			<anchor  title="<?php echo $_['btn_search'];?>"><?php echo $_['text_comment'];?>
				<go href="topicreplydo.php?do=post&amp;bd=<?php echo $bd?>&amp;id=<?php echo $id?>&amp;key=show" method="post">
					<postfield name="content" value="$(content)" />
				</go>
			</anchor>
		</p>
	<?php
		}
	?>	
</p>
<p>
	<?php echo $_['btn_goback']?>[<a href="board.php?bd=<?php echo $bd?>&amp;rnd=<?php echo rand();?>"><?php echo $bdName?></a>]<?php If($key=="good") echo $_['btn_goback']."[<a href='board.php?bd=".$bd."&amp;key=good'>".$_['text_good']."</a>]"; ?>
</p>
<?php 
	$session->data['setSkipUrl']=getUrl();
	require_once('boardswitch.php');
?>
<?php require_once('bottom.php');?>
</card>
</wml>