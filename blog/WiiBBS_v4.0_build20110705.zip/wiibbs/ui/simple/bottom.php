<?php

/**
 * bottom.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

?><p>&lt;<?php echo $_['text_simple']?> <a href='<?php echo NETURL?>/index.php?key=color'><?php echo $_['text_color']?></a> <a href='<?php echo NETURL?>/index.php?key=3g'><?php echo $_['text_3g']?></a>&gt;</p>
		<p>
			<a href='index.php'><?php echo $_['text_index']?></a> <?php if(empty($session->data[WiiBBS_ID."wiibbsUser"])){ ?><a href='login.php'><?php echo $_['text_login']?></a> <a href='register.php'><?php echo $_['text_reg']?></a><?php }else {?><a href='usercenter.php'><?php echo $_['text_userCenter']?></a> <?php }?> 
			 <anchor>
				<?php echo $_['text_toTop']?>
				<go href="#top"></go>
			 </anchor>
			<br />
			<a href="boardlist.php" ><?php echo $_['text_board'];?></a> <?php if(SITECOUNT==1){?><a href='stat.php'><?php echo $_['text_census']?></a><?php }?> <a href='search.php'><?php echo $_['text_search']?></a> <a href='linklist.php'><?php echo $_['text_link']?></a> <br />
			<?php echo SITENAME?> [<?php echo date('m-d H:i');?>]<br />
		</p>
		
	<?php
		$flow->updateFlow();
	?>