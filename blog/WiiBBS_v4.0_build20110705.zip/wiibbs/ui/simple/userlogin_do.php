<?php

/**
 * userlogin_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/simple/userlogin_do.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	$account=sqlReplace(trim($_POST['account']));
	checkData($account,$_['text_accountoremail'],1,'login.php');
	$password=sqlReplace(trim($_POST['pwd']));
	checkData($password,$_['text_password'],1,'login.php');
	if (empty($session->data['setUrl']))
		$backUrl='index.php';
	else
		$backUrl=str_replace("&","&amp;",$session->data['setUrl']);
	$cookie=empty($_POST['cookie'])?1:sqlReplace(trim($_POST['cookie']));
	$result=$wiibbsUser->login($account,$password,$cookie);
	switch($result)
	{
		case '1':
			alertInfo($_['tip_AEexist'],'login.php');
		break;
		case '2':
			alertInfo($_['tip_pwderror'],'login.php');
		break;
		case '3':
			alertInfo($_['suc_login'],$backUrl);
		break;
		case '4':
			alertInfo($_['tip_exception'],'login.php');
		break;
		default:
			alertInfo($_['tip_exception'],'login.php');
		
	}
	
?>