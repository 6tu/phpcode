<?php

/**
 * usergetpw2.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/simple/usergetpw2.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	$account=sqlReplace(trim($_GET['account']));
	$vercode=sqlReplace(trim($_GET['vercode']));
	$result=$wiibbsUser->getUserByVercode($account,$vercode);
	if(!$result)
	{
		echo $_['tip_expired'];
		exit;
	}
	header ("Content-Type: text/vnd.wap.wml");
	echo "<?xml version=\"1.0\"?>\n"
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
	<card id="top" title="<?php echo $_['text_forgetPwd'];?>">
		<p><a href="index.php"><?php echo $_['text_index']?></a> &gt;&gt;<?php echo $_['text_forgetPwd'];?></p>
		<p><a href='login.php'><?php echo $_['text_memberLogin']?></a>  <a href='register.php'><?php echo $_['text_userRegister'];?></a></p>
		<p>　<?php echo $_['text_newPwd']?>：<input  type='password' name='pwd1'/></p>
		<p><?php echo $_['text_confirmPwd']?>：<input  type='password' name='pwd2'/></p>
		<p>
			<anchor title="<?php echo $_['btn_submit'];?>"><?php echo $_['btn_submit'];?> 
				<go href="usergetpw_do.php?act=step2" method="post" accept-charset="utf-8"> 
					<postfield name="pwd1" value="$(pwd1)"/> 
					<postfield name="pwd2" value="$(pwd2)"/> 
					<postfield name="account" value="<?php echo $account;?>"/> 
					<postfield name="vercode" value="<?php echo $vercode;?>"/> 
				</go> 
			</anchor>
		</p>
		<p>
			<?php echo $_['tip_commom'];?>：<br/>
			<?php echo $_['tip_forgetPw21'];?><br/>
			<?php echo $_['tip_forgetPw22'];?> <br/>
			<?php echo $_['tip_forgetPw23'];?> <br/>
		</p>
		<?php require_once("bottom.php");?>
	</card>
</wml>
