<?php

/**
 * board.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/simple/board.php', '', str_replace('\\', '/', __FILE__)));
	require_once("topwml.php");
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	$session->data['setSkipUrl']=getUrl();
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
<?php
$key=(empty($_GET["key"]))?"":sqlReplace($_GET['key']);
	If($key=="good"){
		$title = " &gt;&gt; ".$_['text_good'];
		$title1 = " - ".$_['text_good'];
		$good = 1;
	}Else{
		$title ="";
		$good = "";
		$title1='';
	} 
	$header_title= $bdName.$title1;
?>
<card id="top" title="<?php echo $header_title?>">
<p><?php require_once('noticeinc.php');?></p>
<p><?php require_once('logininc.php');?></p>
<p><a href="index.php"><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $bdName.$title?></p>
<p><?php echo $_['text_moderator']?>：<?php $board->getUsergroup($bd)?><br/><br/><a href='topicpost.php?bd=<?php echo $bd?>&amp;key=post'>[<?php echo $_['text_postTopic']?>]</a>  <?php if (empty($key)) {?><a href='board.php?key=good&amp;bd=<?php echo $bd?>'>[<?php echo $_['text_good']?>]</a><?php }else{?>[<a href="board.php?bd=<?php echo $bd?>"><?php echo $_['text_all']?></a>]<?php }?> <?php if($bdCheck=="1" && ($userGroup || $manager)) echo " <a href='topicchecklist.php?bd=".$bd."'>[".$_['text_check']."]</a>";?></p>
<?php
	if (empty($key)){
		$page=(empty($_GET['page']))?"":$_GET['page'];
		if (empty($page)||!is_numeric($page))$page=1;
		If($page==1){
			//总置顶帖子
			$allTop=$topic->getAllTopTopic_rWml();
			//置顶帖子
			$top=$topic->getTopTopicWml($bd);
		}
		//查询平常帖子
		$pagesize=15;
		$startRow=0;
		$startRow=($page-1)*$pagesize;
		$rscount=$topic->getTopicCount($bd,0);
		if ($rscount%$pagesize==0)
			$pagecount=$rscount/$pagesize;
		else
			$pagecount=ceil($rscount/$pagesize);
		$topicList=$topic->getTopicWml($bd,0,$startRow,$pagesize,$page);
		if ($pagecount>1){
			echo showPage1('board.php?bd='.$bd,$page,$pagesize,$rscount,$pagecount);
		}
			
	}else{   //精华帖
		$page=(empty($_GET['page']))?"":$_GET['page'];
		if (empty($page)||!is_numeric($page))$page=1;
		$pagesize=15;
		$startRow=0;
		$startRow=($page-1)*$pagesize;
		$rscount=$topic->getTopicCount($bd,'',0,1);
		if ($rscount%$pagesize==0)
			$pagecount=$rscount/$pagesize;
		else
			$pagecount=ceil($rscount/$pagesize);
		$topicList=$topic->getTopicWml($bd,'',$startRow,$pagesize,$page,$key,'topic_updatetime','desc','0',1,$keyword='');
		if ($pagecount>1){
			echo showPage1('board.php?key='.$key.'&amp;bd='.$bd,$page,$pagesize,$rscount,$pagecount);
		}
	}		
?>
<?php require_once('boardswitch.php');?>
<?php require_once('bottom.php');?>
</card>
</wml>