<?php

/**
 * topicpost.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/simple/topicpost.php', '', str_replace('\\', '/', __FILE__)));
	require_once("topwml.php");
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	If($bdType!=4){
	  require_once('checklogin.php');
	  if ($bdType==6){  //检查咨询版面的权限
		if (!$manager){
			alertInfo($_['alert_adminBoard'],'board.php?bd='.$bd);
		}
	  }
	}
	$header_title=$_['text_postTopic'];
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>

<card id="top" title="<?php echo $header_title;?>">
<p><?php require_once('noticeinc.php');?></p>
<p><a href="index.php"><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_postTopic']?></p>
<p>
	<p>
		<p><?php echo $_['text_topicTitle']?>：<input inputmode="user predictOn" name="title" type="text"/></p>
		<p><?php echo $_['text_topicContent']?>：<input type="text" name="content" /></p>
	</p>
	<p>
		<anchor  title="<?php echo $_['btn_search'];?>"><?php echo $_['text_postTopic']?>
			<go href="topicpostdo.php?bd=<?php echo $bd?>" method="post" accept-charset="utf-8">
				<postfield name="title" value="$(title)" />
				<postfield name="content" value="$(content)" />
			</go>
		</anchor>
	</p>
</p>
<p><?php echo $_['btn_goback']?>[<a href="board.php?bd=<?php echo $bd?>&amp;rnd=<?php echo rand();?>"><?php echo $bdName?></a>]</p>
<?php 
			$session->data['setSkipUrl']=getUrl();
			require_once('boardswitch.php');
		?>
<?php require_once('bottom.php');?>
</card>
</wml>