<?php

/**
 * index.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/simple/boardlist.php', '', str_replace('\\', '/', __FILE__)));
	require_once("topwml.php");
	$POSITION_BOARD="on";
	$session->data['setSkipUrl']=getUrl();
	$session->data['setUrl']=getUrl();
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
	<card id="top" title="<?php echo SITENAME?>">
		<p><?php echo SITENAME?></p>
		<p><?php require_once("noticeinc.php");?></p>
		<p><?php require_once("logininc.php");?></p>
		<p><?php require_once("tab.php");?></p>
		
		<p>
		<?php
			$classList=$board->getBoardClassList();
			foreach ($classList as $row){
				echo "<p><b>".$row['boardclass_name']."</b></p>";
				$boardList=$board->getBoardList($row['boardclass_id']);
				foreach($boardList as $rows){
					echo "<p><a href='board.php?bd=".$rows['board_id']."'>".$rows['board_name']."</a></p>";
				}
			}
		?>
		</p>
		<?php require_once('bottom.php');?>
	</card>
</wml>