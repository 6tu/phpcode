<?php
	define('THISPATHROOT', str_replace('ui/simple/boardjump.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	$board=sqlReplace(trim($_POST['board']));
	header("location:".NETURL."/ui/simple/board.php?bd=".$board."");
?>