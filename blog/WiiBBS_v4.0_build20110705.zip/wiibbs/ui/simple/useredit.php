<?php

/**
 * useredit.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/simple/useredit.php', '', str_replace('\\', '/', __FILE__)));
	require_once("topwml.php");
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo($_['tip_returnlogin'],'login.php');
	}
	$user=$wiibbsUser->getUserByAccount();
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
	<card id="top" title="<?php echo $_['text_editStuff'];?>">
		<p><?php require_once('noticeinc.php');?></p>
		<p><a href='index.php'><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_editStuff'];?></p>
		<p><?php echo $_['text_nikeName'];?>：<input  type='text' name='nikename' value="<?php echo $user['user_nickname']?>"/></p>
		<p><?php echo $_['text_name'];?>：<input  type='text' name='name' value="<?php echo $user['user_name']?>"/></p>
		<p><?php echo $_['text_email'];?>：<input type='text' name='email' value="<?php echo $user['user_email']?>"/></p>
		<p><?php echo $_['text_sex'];?>：
			<select ivalue='<?php echo $user['user_name']?>' name='sex'>
				<option value="0"><?php echo $_['tip_select']?></option>
				<option value="1"><?php echo $_['text_man']?></option>
				<option value="2"><?php echo $_['text_women'];?></option>
			</select>
		</p>
		<p><?php echo $_['text_province'];?>：<input  type='text' name='province' value="<?php echo $user['user_province']?>"/></p>
		<p><?php echo $_['text_city'];?>：<input type='text' name='city' value="<?php echo $user['user_city']?>"/></p>
		<p><?php echo $_['text_address'];?>：<input type='text' name='address' value="<?php echo $user['user_address']?>"/></p>
		<p><?php echo $_['text_brith'];?>：<input type='text' name='brith' value="<?php echo $user['user_birthday']?>"/></p>
		<p><?php echo $_['text_qq'];?>：<input type='text' name='qq' value="<?php echo $user['user_qq']?>"/></p>
		<p><?php echo $_['text_mobile'];?>：<input type='text' name='mobile' value="<?php echo $user['user_mobile']?>"/></p>
		<p><?php echo $_['text_sina'];?>：<input type='text' name='sina' value="<?php echo $user['user_sina']?>"/></p>
		<p>
			<anchor title="<?php echo $_['btn_register'];?>"><?php echo $_['btn_submit'];?>
				<go href="user_do.php?act=edit" method="post" accept-charset="utf-8"> 
					<postfield name="nikename" value="$(nikename)"/> 
					<postfield name="name" value="$(name)"/> 
					<postfield name="email" value="$(email)"/>
					<postfield name="sex" value="$(sex)"/> 
					<postfield name="province" value="$(province)"/> 
					<postfield name="city" value="$(city)"/> 
					<postfield name="address" value="$(address)"/> 
					<postfield name="brith" value="$(brith)"/> 
					<postfield name="qq" value="$(qq)"/> 
					<postfield name="mobile" value="$(mobile)"/> 
					<postfield name="sina" value="$(sina)"/> 
				</go> 
			</anchor>
			[<a href='usercenter.php'><?php echo $_['btn_goback'];?></a>]
		</p>
	<?php require_once('bottom.php');?>
	</card>
</wml>