<?php

/**
 * userpassword.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/simple/userpassword.php', '', str_replace('\\', '/', __FILE__)));
	require_once("topwml.php");
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo($_['tip_returnlogin'],'login.php');
	}
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
	<card id="top" title="<?php echo $_['text_editPwd'];?>">
		<p><?php require_once('noticeinc.php');?></p>
		<p><a href='index.php'><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_editPwd'];?></p>
		<p><?php echo $_['text_oldPwd'];?>：<input type='password' name='oldPw'/></p>
		<p><?php echo $_['text_newPwd'];?>：<input type='password' name='newPw'/></p>
		<p><?php echo $_['text_rePwd'];?>：<input type='password' name='rePw'/></p>
		<p>
			<anchor title="<?php echo $_['btn_register'];?>"><?php echo $_['btn_submit'];?> 
				<go href="user_do.php?act=pw" method="post" accept-charset="utf-8"> 
					<postfield name="oldPw" value="$(oldPw)"/> 
					<postfield name="newPw" value="$(newPw)"/> 
					<postfield name="rePw" value="$(rePw)"/> 
				</go> 
			</anchor>
			[<a href='usercenter.php'><?php echo $_['btn_goback'];?></a>]
		</p>
	<?php require_once('bottom.php');?>
	</card>
</wml>