<?php

/**
 * topiccheck.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/simple/topiccheck.php', '', str_replace('\\', '/', __FILE__)));
	require_once("topwml.php");
	require_once(THISPATHROOT.'include/lib/ubb_common.php');
	require_once(THISPATHROOT.'include/lib/image_common.php');
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	require_once('checklogin.php');
	if (!($manager || $userGroup)) alertInfo($_['alert_noCheckLimit'],'board.php?bd='.$bd);
	$header_title=$_['text_check'];
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
<?php
	$id=sqlReplace(Trim($_GET["id"]));
	$id=intval($id);
	$url="id=".$id."&amp;bd=".$bd;
	$row=$topic->getTopicByID_BD($id,$bd);
	If(!$row){
		alertInfo($_['alert_noNEW'],'index.php');
	}Else{
		$title=$row["topic_title"];
		$content=$row["topic_content"];
		$addTime=$row["topic_posttime"];
		$poster=$row["topic_user"];
	}
?>
	<card id="top" title="<?php echo $header_title?>">
		<?php require_once('noticeinc.php');?>
		<?php require_once('logininc.php');?>
		<p><a href="index.php"><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_check']?></p>
		<b><?php echo $title?></b>
		<p><?php If($poster!="Guest"){?><a href="user.php?id=<?php echo $poster?>&amp;url=<?php echo urlencode(getUrl())?>"><?php echo $poster;?></a><?php }else{?><?php echo $poster;}?><?php echo $_['text_write']?> <?php echo $addTime?> </p>
		
		<p>[<a href="topicdo.php?id=<?php echo $id;?>&amp;do=check&amp;bd=<?php echo $bd;?>"><?php echo $_['btn_checkTopic']?></a>][<a href="#"><?php echo $_['text_topicdel']?></a>]</p>
		<?php
			//帖子内容分页
			if(SITEUBB=="1")
				{
					$ubbcode = new UBBCode();
					$content=$ubbcode->encode($content); 
				}
			mb_internal_encoding("UTF-8");
			$all=(empty($_GET["all"]))?"":$_GET['all'];
			$logtextx=$content;
			//没有换行的原因
			$logtextx=$logtextx;
			//开始分页  
			if(!empty($_GET["page"]))  $page=(empty($_GET["page"]))?"":$_GET["page"]; 
			$PageLength=900;
			$CLength=mb_strLen($logtextx);
			//$str=cutstr($logtextx,$CLength);
			if($CLength%$PageLength==0){
				$pagecount=$CLength/$PageLength;
			}else{
				$pagecount=(intval($CLength/$PageLength))+1;
			}
			if(!isset($page))
			{
				$page=1;
			}
			if(($page<1) || (is_null($page))) 
				$page=1; 
			if($page>$pagecount) $Page=$pagecount; 
			if($page==1){
				$a=0; 
				//修改浏览次数
				$topic->updateTopicViewCount($bd,$id);
			}elseif($page>1){ 
				$a=($page-1)*$PageLength; 
			}
			$url2=$url."&amp;page=".$page;
			If($all=="all"){
				$wen=mb_substr($logtextx,$a);
			}Else{
				$wen=mb_substr($logtextx,$a,$PageLength); 
			} 
			echo "<p>".$wen."</p>"; 
			if($pagecount>1)
			{
				echo "<p>";
				echo morePage("topiccheck.php?".$url2,$page,$PageLength,$CLength,$pagecount);
				echo "</p>"; 
			}
			$fileList=$topic->getFileListByID(0,$id);
			foreach ($fileList as $row){
				echo "<p>";
				$funcSysten->downFile($row,$url2);
				echo "</p>";
				
			}
		?>
		<?php 
			$session->data['setSkipUrl']=getUrl();
			require_once('boardswitch.php');
		?>
		<?php require_once('bottom.php');?>
	</card>
</wml>