<?php

/**
 * topwml.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once(THISPATHROOT.'include/db_conn.php');
	header ("Content-Type: text/vnd.wap.wml");
	echo "<?xml version=\"1.0\"?>\n";
?>