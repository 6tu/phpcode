<?php

/**
 * msg_send.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/simple/msg_send.php', '', str_replace('\\', '/', __FILE__)));
	require_once("topwml.php");
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo($_['tip_returnlogin'],'login.php');
	}
	$uid=empty($_GET['uid'])?'':sqlReplace(trim($_GET['uid']));
	$url=sqlReplace($_GET['url']);
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
	<card id="top" title="<?php echo $_['text_writeBox'];?>">
		<p><?php require_once('noticeinc.php');?></p>
		<p><a href='index.php'><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_writeBox'];?></p>
		<p><b><?php echo $session->data[WiiBBS_ID."wiibbsUser"]?> [<a href='usercenter.php'><?php echo $_['text_userCenter']?></a>]</b></p>
		<p><?php echo $_['text_receiver'];?>：<input  type='text' name='receiver' value="<?php echo $uid;?>"/></p>
		<p>　<?php echo $_['text_title'];?>：<input type="text" name="title"/></p>
		<p>　<?php echo $_['text_content'];?>：<input type='text' name="content"/></p>
		<p>
			<anchor title="<?php echo $_['btn_submit'];?>"><?php echo $_['btn_submit'];?> 
				<go href="msg_do.php?act=add" method="post" accept-charset="utf-8"> 
					<postfield name="receiver" value="$(receiver)"/> 
					<postfield name="url" value="<?php echo $url;?>"/> 
					<postfield name="title" value="$(title)"/> 
					<postfield name="content" value="$(content)"/> 
				</go> 
			</anchor>
		</p>
		<p>
			<?php echo $_['tip_commom'];?>:<br/>
			<?php echo $_['tip_send1'];?><br/>
			<?php echo $_['tip_send2'];?><br/>
			<?php echo $_['tip_send3'];?><br/>
		</p>
		<p>[<a href='<?php echo $url;?>'><?php echo $_['btn_goback'];?></a>]</p>
		<?php require_once('bottom.php');?>
	</card>
</wml>