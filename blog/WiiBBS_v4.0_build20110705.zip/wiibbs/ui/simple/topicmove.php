<?php

/**
 * topicmove.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/simple/topicmove.php', '', str_replace('\\', '/', __FILE__)));
	require_once("topwml.php");
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	require_once('checklogin.php');
	if (!($manager || $userGroup)) alertInfo($_['alert_noLimit'],'index.php');
	$header_title=$_['header_moveTopic'];
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
<?php
	$id=sqlReplace(Trim($_GET["id"]));
	$id=intval($id);
	$row=$topic->getTopicByID_BD($id,$bd);
	If(!$row){
		alertInfo($_['alert_noNEW'],'index.php');
	}Else{
		$title=$row["topic_title"];
		$content=$row["topic_content"];
	}
?>
	<card id="top" title="<?php echo $_['header_moveTopic']?>">
		<p><?php require_once('noticeinc.php');?></p>
		<p><a href="index.php"><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['header_moveTopic']?></p>
		<p>
			<p><?php echo $_['text_checkBoard']?>：
				<select name="bd">
				<?php
				$bList=$board->getBoardList('',$bd);
				If(!$bList){
					echo "<option value='0'>".$_['text_noBoard'] ."</option>";
				}Else{
					foreach($bList as $row){
				?>
					<option value="<?php echo $row["board_id"]?>" ><?php echo $row["board_name"]?></option>
				<?php
					}
				}
				?>
				</select></p>
				<p>
					<anchor title="<?php echo $_['header_moveTopic']?>"><?php echo $_['btn_move']?>
						<go href="topicdo.php?id=<?php echo $id?>&amp;do=move" method="post" accept-charset="utf-8">
							<postfield name="bd" value="$(bd)" />
						</go>
					</anchor>
				</p>
		</p>
		<p><?php echo $_['btn_goback']?>[<a href="board.php?bd=<?php echo $bd?>&amp;rnd=<?php echo rand();?>"><?php echo $bdName?></a>]</p>
		<?php 
			$session->data['setSkipUrl']=getUrl();
			require_once('boardswitch.php');
		?>
		<?php require_once('bottom.php');?>
	</card>
</wml>