<?php

/**
 * topicreplydo.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
define('THISPATHROOT', str_replace('ui/simple/topicreplydo.php', '', str_replace('\\', '/', __FILE__)));
require_once(THISPATHROOT.'include/db_conn.php');
require_once(THISPATHROOT.'include/lib/image_common.php');
require_once('usercheck.php');
If(empty($userName)){
		If($bdType==4){
			$userName="Guest";
		}else{
			 require_once('checklogin.php');
		} 
	}
$action=sqlReplace(trim($_GET["do"]));
$rcode=rand(10,1000);
If($action=="post"){
	$id=sqlReplace(Trim($_GET["id"]));
	$id=intval($id);
	$db1=sqlReplace(trim($_GET['bd']));
	$key=sqlReplace($_GET["key"]);
	if ($key=='list')
		$url='topicreplylist.php';
	else
		$url='topicshow.php';
	$content=HTMLEncode($_POST["content"]);
	$result=$topic->checkLockTopic(1,$id,$bd);
	If($result){
		alertInfo($_['alert_lock'],$url.'?bd='.$bd.'&amp;r='.$rcode.'&amp;id='.$id);
		exit;
	}
	if (SITEFILTER!=''){
		$filter=str_replace("，",',',SITEFILTER);
		$filters=explode(",",$filter);
		for($i=0;$i<count($filters);$i++)
		{
			if(strpos($content,$filters[$i])>-1)
			{
				alertInfo($_['alert_filter'],$url.'?bd='.$bd.'&amp;r='.$rcode.'&amp;id='.$id);
			}
		}
	}
	
	if(empty($content)){
		alertInfo($_['alert_contentNull'],$url.'?bd='.$bd.'&amp;r='.$rcode.'&amp;id='.$id);
	}
	
	$data=array(
	'topicID'=>$id,
	'content'=>$content,
	'wiibbsUser'=>$userName,
	'bd'=>$bd,
	);
	$result=$topic->insertTopicReply($data);
	if($result==2){
		alertInfo($_['alert_postreply'],$url.'?bd='.$bd.'&amp;r='.$rcode.'&amp;id='.$id);
	}else if ($result==1){
		alertInfo($_['alert_postRepeat'],$url.'?bd='.$bd.'&amp;r='.$rcode.'&amp;id='.$id);
	}else{
		alertInfo($_['alert_errorreply'],$url.'?bd='.$bd.'&amp;r='.$rcode.'&amp;id='.$id);
	}
}
If($action=="del"){
	$id=sqlReplace(Trim($_GET["id"]));
	$id=intval($id);
	$rid=sqlReplace(Trim($_GET["rid"]));
	$rid=intval($rid);
	$key=empty($_GET['key'])?'':sqlReplace($_GET['key']);
	header("location:".NETURL."/ui/".$folder_simple."/topicdeal.php?act=delReply&bd=".$bd."&id=".$id."&rid=".$rid."&key=".$key);
}
?>