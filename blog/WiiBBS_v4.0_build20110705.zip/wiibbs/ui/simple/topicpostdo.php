<?php

/**
 * topicpostdo.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/simple/topicpostdo.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(THISPATHROOT.'include/lib/image_common.php');
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	if($bd===0)
	{
		exit();
	}
	If(empty($userName)){
		If($bdType==4){
			$userName="Guest";
		}else{
			 require_once('checklogin.php');
		} 
	}
	$title=sqlReplace(Trim($_POST["title"]));
	$content=HTMLEncode(trim($_POST["content"]));
	$sina=empty($_POST["sina"])?'':sqlReplace(Trim($_POST["sina"]));
	if (SITEFILTER!=''){
		$filter=str_replace("，",',',SITEFILTER);
		$filters=explode(",",$filter);
		for($i=0;$i<count($filters);$i++)
		{
			if(strpos($title.$content,$filters[$i])>-1)
			{
				alertInfo($_['alert_filter'],'topicpost.php?bd='.$bd.'&amp;key=post');
			}
		}
	}	
	If((strLen($title)<1) || (strLen($content)<1)){
		alertInfo($_['alert_contentNull_r'],'topicpost.php?bd='.$bd.'&amp;key=post');
	}
	$data=array(
	'title'=>$title,
	'content'=>$content,
	'wiibbsUser'=>$userName,
	'bd'=>$bd,
	'bdCheck'=>$bdCheck,
	);
	$result=$topic->insertTopic($data);
	
	if($result==2){
		if (!empty($sina)){
			$sql="select topic_id from ".DB_TABLE_PREFIX."topic where topic_title='".$title."' and datediff(now(),topic_posttime)=0 order by topic_id desc limit 1";
			$query=$db->query($sql);
			$row=$query->row;
			if ($row){
				$id=$row['topic_id'];
				$url=NETURL."/ui/color/topicshow.php?bd=".$bd."&id=".$id;
				$share=$title;
				echo "<script type='text/javascript'>";
				echo "window.open('http://v.t.sina.com.cn/share/share.php?title='+encodeURIComponent('".$share."')+'&amp;url='+encodeURIComponent('".$url."')+'&amp;source=bbs','_blank','width=450,height=400');";
				echo  "</script>";
			}
		}
		alertInfo($_['alert_postSucc'],'board.php?bd='.$bd);
	}else if ($result==3){
		alertInfo($_['alert_postFail'],'index.php');
	}else if ($result==1)
		alertInfo($_['alert_repeatPost'],'board.php?bd='.$bd);
?>