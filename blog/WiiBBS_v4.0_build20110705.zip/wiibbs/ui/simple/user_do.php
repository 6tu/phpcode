<?php

/**
 * user_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/simple/user_do.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	require_once(THISPATHROOT.'include/lib/image_common.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo($_['tip_returnlogin'],'login.php');
	}
	$act=sqlReplace(trim($_GET['act']));
	switch($act)
	{
		case 'edit':
			$arr['user_nickname']=empty($_POST['nikename'])?'':sqlReplace(trim($_POST['nikename']));
			$arr['user_name']=empty($_POST['name'])?'':sqlReplace(trim($_POST['name']));
			$arr['user_email']=empty($_POST['email'])?'':sqlReplace(trim($_POST['email']));
			$arr['user_sex']=empty($_POST['sex'])?'':sqlReplace(trim($_POST['sex']));
			$arr['user_province']=empty($_POST['province'])?'':sqlReplace(trim($_POST['province']));
			$arr['user_city']=empty($_POST['city'])?'':sqlReplace(trim($_POST['city']));
			$arr['user_address']=empty($_POST['address'])?'':sqlReplace(trim($_POST['address']));
			$arr['user_birthday']=empty($_POST['brith'])?'':sqlReplace(trim($_POST['brith']));
			$arr['user_qq']=empty($_POST['qq'])?'':sqlReplace(trim($_POST['qq']));
			$arr['user_mobile']=empty($_POST['mobile'])?'':sqlReplace(trim($_POST['mobile']));
			$arr['user_sina']=empty($_POST['sina'])?'':sqlReplace(trim($_POST['sina']));
			if(!empty($arr['user_nickname']))
			{
				if($wiibbsUser->checkNickname2($arr['user_nickname']))
				{
					alertInfo($_['tip_nikenameExists'],'useredit.php');
				}
			}
			if(!empty($arr['user_email']))
			{
								
				if (!eregi("^[_\.0-9a-z-]+@([0-9a-z][0-9a-z-]+\.)+[a-z]{2,4}$",$arr['user_email'])){
				   alertInfo($_['tip_emailFormat'],'useredit.php');
				 }
				if($wiibbsUser->checkEmail2($arr['user_email']))
				{
					alertInfo($_['tip_emailExists'],'useredit.php');
				}
			}
			if(!empty($arr['user_mobile']))
			{
				if (!eregi("^1[3|5|8][0-9]{9}$",$arr['user_mobile'])){
				   alertInfo($_['tip_mobileFormat'],'useredit.php');
				 }
				if($wiibbsUser->checkMobile2($arr['user_mobile']))
				{
					alertInfo($_['tip_mobileExists'],'useredit.php');
				}
			}
			$result=$wiibbsUser->updateUser($arr);
			if($result==1)
			{
				alertInfo($_['suc_editUser'],'useredit.php');
			}else if($result==2)
			{
				alertInfo($_['error_editUser'],'useredit.php');
			}
			break;
		case 'pw':
			$pw=empty($_POST['oldPw'])?'':sqlReplace(trim($_POST['oldPw']));
			checkData($pw,$_['text_oldPwd'],1,'userpassword.php');
			$newPw=empty($_POST['newPw'])?'':sqlReplace(trim($_POST['newPw']));
			checkData($pw,$_['text_newPwd'],1,'userpassword.php');
			$rePw=empty($_POST['rePw'])?'':sqlReplace(trim($_POST['rePw']));
			checkData($pw,$_['text_rePwd'],1,'userpassword.php');
			if($newPw!=$rePw)
			{
				alertInfo($_['tip_noequalPw'],'userpassword.php');
			}
			$result=$wiibbsUser->login($session->data[WiiBBS_ID."wiibbsUser"],$pw,1);
			if($result!=3)
			{
				alertInfo($_['tip_errorOldPwd'],'userpassword.php');
			}
			$result=$wiibbsUser->updatePassword($pw,$newPw);
			if($result!=3)
			{
				alertInfo($_['error_eidtPw'],'userpassword.php');
			}
			alertInfo($_['suc_editPw'],'userpassword.php');
			break;
		case 'upload':
			$f_name=$_FILES['file']['name'];
			$f_size=$_FILES['file']['size'];
			$f_tmpName=$_FILES['file']['tmp_name'];
			if(!empty($f_name))
			{	
				$f_ext=strtolower(preg_replace('/.*\.(.*[^\.].*)*/iU','\\1',$f_name));
				$f_exts=explode("|",'gif|jpg|png');
				if(!in_array($f_ext,$f_exts))
				{
					alertInfo($_['error_fileFormat'],'uploadheader.php');
				}
				if($f_size>40*1024)
				{
					alertInfo($_['error_fileSizeOut'],'uploadheader.php');
				}
				$file_name=date('YmdHis').".".$f_ext;
				$filename=ROOT_PATH."userfiles/header/initial/".$file_name;
				$newfilename=ROOT_PATH."userfiles/header/pic/".$file_name;
				move_uploaded_file ($f_tmpName,$filename);
				$t = new ThumbHandler();
				$t->setSrcImg($filename);
				$t->setDstImg($newfilename);
				$t->createImg(50,50);
				$arr['user_photo']=$file_name;
				$result=$wiibbsUser->updateUser($arr);
				if($result==1)
				{
					alertInfo($_['suc_upload'],'uploadheader.php');
				}else{
					alertInfo($_['error_upload'],'uploadheader.php');
				}
			}
	}
?>