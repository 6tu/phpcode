<?php

/**
 * tab.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

?>
<p>

		
					<?php echo $_['text_switch'];?>：<select name="board">
						<?php
							$boardList=$board->getBoardList($boardClass,$bd);
							foreach ($boardList as $row){
								echo "<option value='".$row['board_id']."'";
								echo">".$row['board_name']."</option>";
							}
						?>
					</select>
			
				<anchor  title="<?php echo $_['text_skip'];?>"><?php echo $_['text_skip'];?>
					<go href="boardjump.php" method="post" accept-charset="utf-8"> 
						<postfield name="board" value="$(board)"/> 
					</go> 
				</anchor>
</p>