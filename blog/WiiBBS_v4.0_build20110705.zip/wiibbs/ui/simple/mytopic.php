<?php

/**
 * mytopic.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/simple/mytopic.php', '', str_replace('\\', '/', __FILE__)));
	require_once("topwml.php");
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo($_['tip_returnlogin'],'login.php');
	}
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
	<card id="top" title="<?php echo $_['text_mySendTopic'];?>">
		<p><?php require_once('noticeinc.php');?></p>
		<p><?php require_once('logininc.php');?></p>
		<p><a href='index.php'><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_mySendTopic'];?></p>
		<?php
			$page=(empty($_GET['page']))?"":$_GET['page'];
			if (empty($page)||!is_numeric($page))$page=1;
			$pagesize=15;
			$startRow=0;
			$startRow=($page-1)*$pagesize;
			$rscount=$topic->getTopicCountByAccount(2);
			if ($rscount%$pagesize==0)
				$pagecount=$rscount/$pagesize;
			else
				$pagecount=ceil($rscount/$pagesize);
				$topicList=$topic->getTopicByAccountWml($startRow,$pagesize,$page,2);
			if ($pagecount>1){
				echo showPage1('mytopic.php',$page,$pagesize,$rscount,$pagecount);
			}
		?>
	<?php require_once('bottom.php');?>
	</card>
</wml>
