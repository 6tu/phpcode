<?php

/**
 * logininc.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

		if(date('H')<12)
		{
			echo $_['text_goodMorning'];
		}else{
			echo $_['text_goodAfternoon'];
		}
		if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
		{
			echo $_['text_tourist'].",".$_['text_welcome'];
			echo "<a href='login.php'>".$_['btn_login']."</a>/<a href='register.php'>".$_['btn_register']."</a>";
		}else{
			echo "<a href='usercenter.php'>".$session->data[WiiBBS_ID."wiibbsUser"]."</a>,<a href='userquit.php'>".$_['text_quit']."</a>";
		}
	?>