<?php

/**
 * auto.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

define('THISPATHROOT', str_replace('ui/3g/auto.php', '', str_replace('\\', '/', __FILE__)));
require_once(THISPATHROOT.'include/db_conn.php');
require_once(ROOT_PATH.'lang/'.LANGUAGE.'/applications.php');
require_once('htmltop.php');
$rcode=intval(rand()*1000);

$url=(empty($_GET["url"]))?"":$_GET['url'];
$id=(empty($_GET["id"]))?"":$_GET['id'];
$key=(empty($_GET["key"]))?"":$_GET['key'];
$bd=(empty($_GET["bd"]))?"":$_GET['bd'];
$uid=(empty($_GET["uid"]))?"":$_GET['uid'];
if(!empty($_GET['db']))
{
$db=$_GET['db'];
}else{
$db="";
}

$skipUrl="boardlist.php";

$WPErr=array();
$WPErr[100]="<p>".$_['alert_noLimit']."</p><meta http-equiv='refresh' content='3;url=topicshow.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicshow.php?bd=".$bd."&amp;id=".$id."' data-role='button' data-ajax='false'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[101]="<p>".$_['alert_noLimit']."</p><meta http-equiv='refresh' content='3;url=topiccheck.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topiccheck.php?bd=".$bd."&amp;id=".$id."' data-role='button'   data-inline='true' data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";

$WPErr[102]="<p>".$_['alert_noNEW']."</p><meta http-equiv='refresh' content='3;url=index.php' />
		".FUNCTION_AUTO."<a href='index.php' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[104]="<p>".$_['alert_postFail']."</p><meta http-equiv='refresh' content='3;url=topicshow.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicshow.php?bd=".$bd."&amp;id=".$id."' data-ajax='false' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[105]="<p>".$_['alert_postFail']."</p><meta http-equiv='refresh' content='3;url=topiccheck.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topiccheck.php?bd=".$bd."&amp;id=".$id."' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[106]="<p>".$_['alert_noLimit']."</p><meta http-equiv='refresh' content='3;url=topicreplylist.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicreplylist.php?bd=".$bd."&amp;id=".$id."' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[107]="<p>".$_['alert_postdel']."！</p><meta http-equiv='refresh' content='3;url=topicreplylist.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicreplylist.php?bd=".$bd."&amp;id=".$id."' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[108]="<p>".$_['alert_errordel']."！</p><meta http-equiv='refresh' content='3;url=topicreplylist.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicreplylist.php?bd=".$bd."&amp;id=".$id."' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[109]="<p>".$_['alert_filter']."</p><meta http-equiv='refresh' content='3;url=topicedit.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicedit.php?bd=".$bd."&amp;id=".$id."' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[110]="<p>".$_['alert_contentNull_r']."</p><meta http-equiv='refresh' content='3;url=topicedit.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicedit.php?bd=".$bd."&amp;id=".$id."' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[111]="<p>".$_['alert_adminBoard']."</p><meta http-equiv='refresh' content='3;url=board.php?bd=".$bd."' />
		".FUNCTION_AUTO."<a href='board.php?bd=".$bd."' data-role='button' data-ajax='false'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[112]="<p>".$_['alert_postEdit']."</p><meta http-equiv='refresh' content='3;url=topicedit.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicedit.php?bd=".$bd."&amp;id=".$id."' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";

$WPErr[113]="<p>".$_['alert_adminBoard']."</p><meta http-equiv='refresh' content='3;url=board.php?bd=".$bd."' />
		".FUNCTION_AUTO."<a href='board.php?bd=".$bd."' data-role='button' data-ajax='false'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[114]="<p>".$_['alert_filter']."</p><meta http-equiv='refresh' content='3;url=topicpost.php?bd=".$bd."' />
		".FUNCTION_AUTO."<a href='topicpost.php?bd=".$bd."' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[115]="<p>".$_['alert_titleNull']."</p><meta http-equiv='refresh' content='3;url=topicpost.php?bd=".$bd."' />
		".FUNCTION_AUTO."<a href='topicpost.php?bd=".$bd."' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[116]="<p>".$_['alert_contentNull_r']."</p><meta http-equiv='refresh' content='3;url=topicpost.php?bd=".$bd."' />
		".FUNCTION_AUTO."<a href='topicpost.php?bd=".$bd."' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[117]="<p>".$_['alert_postSucc']."</p><meta http-equiv='refresh' content='3;url=board.php?bd=".$bd."' />
		".FUNCTION_AUTO."<a href='board.php?bd=".$bd."' data-role='button' data-ajax='false'  data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[118]="<p>".$_['alert_postFail']."</p><meta http-equiv='refresh' content='3;url=index.php' />
		".FUNCTION_AUTO."<a href='index.php' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[119]="<p>".$_['alert_repeatPost']."</p><meta http-equiv='refresh' content='3;url=board.php?bd=".$bd."' />
		".FUNCTION_AUTO."<a href='board.php?bd=".$bd."' data-role='button' data-ajax='false'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[120]="<p>".$_['alert_postdo']."</p><meta http-equiv='refresh' content='3;url=topicshow.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicshow.php?bd=".$bd."&amp;id=".$id."' data-ajax='false' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[121]="<p>".$_['alert_postFail']."</p><meta http-equiv='refresh' content='3;url=topicshow.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicshow.php?bd=".$bd."&amp;id=".$id."' data-role='button' data-ajax='false'  data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[122]="<p>".$_['alert_noLimit']."</p><meta http-equiv='refresh' content='3;url=topicshow.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicshow.php?bd=".$bd."&amp;id=".$id."' data-role='button' data-ajax='false'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[123]="<p>".$_['alert_postdo']."</p><meta http-equiv='refresh' content='3;url=topicshow.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicshow.php?bd=".$bd."&amp;id=".$id."' data-role='button' data-ajax='false'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[124]="<p>".$_['alert_postFail']."</p><meta http-equiv='refresh' content='3;url=topicshow.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicshow.php?bd=".$bd."&amp;id=".$id."' data-role='button' data-ajax='false'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[125]="<p>".$_['alert_noLimit']."</p><meta http-equiv='refresh' content='3;url=topicshow.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicshow.php?bd=".$bd."&amp;id=".$id."' data-role='button' data-ajax='false'  data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[126]="<p>".$_['alert_noCheckBorder']."</p><meta http-equiv='refresh' content='3;url=index.php' />
		".FUNCTION_AUTO."<a href='index.php' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[127]="<p>".$_['alert_noboard']."</p><meta http-equiv='refresh' content='3;url=index.php' />
		".FUNCTION_AUTO."<a href='index.php' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[128]="<p>".$_['alert_boardvip']."</p><meta http-equiv='refresh' content='3;url=index.php' />
		".FUNCTION_AUTO."<a href='index.php' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[129]="<p>".$_['alert_noLimit']."！</p><meta http-equiv='refresh' content='3;url=".$skipUrl."' />";
$WPErr[130]="<p>".$_['alert_noLimit']."！</p><meta http-equiv='refresh' content='3;url=".$skipUrl."' />";
$WPErr[131]="<p>".$_['alert_noNEW']."</p><meta http-equiv='refresh' content='3;url=".$skipUrl."' />
		".FUNCTION_AUTO."<a href='".$skipUrl."' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[132]="<p>".$_['alert_noLimit']."</p><meta http-equiv='refresh' content='3;url=board.php?bd=".$bd."' />
		".FUNCTION_AUTO."<a href='board.php?bd=".$bd."' data-role='button' data-ajax='false'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[133]="<p>".$_['alert_successCheck']."</p><meta http-equiv='refresh' content='3;url=topicchecklist.php?bd=".$bd."' />
		".FUNCTION_AUTO."<a href='topicchecklist.php?bd=".$bd."' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[134]="<p>".$_['alert_errorCheck']."</p><meta http-equiv='refresh' content='3;url=topicchecklist.php?bd=".$bd."' />
		".FUNCTION_AUTO."<a href='topicchecklist.php?bd=".$bd."' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[135]="<p>".$_['alert_lock']."</p><meta http-equiv='refresh' content='3;url=topicshow.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicshow.php?bd=".$bd."&amp;id=".$id."' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[136]="<p>".$_['alert_filter']."</p><meta http-equiv='refresh' content='3;url=topicreplyadd.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicreplyadd.php?bd=".$bd."&amp;id=".$id."' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[137]="<p>".$_['alert_contentNull']."</p><meta http-equiv='refresh' content='3;url=topicreplyadd.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicreplyadd.php?bd=".$bd."&amp;id=".$id."' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[138]="<p>".$_['alert_postreply']."</p><meta http-equiv='refresh' content='3;url=topicshow.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicshow.php?bd=".$bd."&amp;id=".$id."' data-role='button' data-ajax='false'   data-inline='true' data-theme='b' data-transition='slidedown' data-inline='true'>".FUNCTION_CLICK."</a>";
$WPErr[139]="<p>".$_['alert_errorreply']."</p><meta http-equiv='refresh' content='3;url=topicreplyadd.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicreplyadd.php?bd=".$bd."&amp;id=".$id."' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown' data-inline='true'>".FUNCTION_CLICK."</a>";

$WPErr[140]="<p>".$_['alert_boardLogin']."</p><a href='register.php?key=".$key."&amp;id=".$id."&amp;bd=".$bd."&amp;uid=".$uid."' data-ajax='false' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown' data-inline='true'>".$_['text_m_reg']."</a> <a href='login.php?key=".$key."&amp;id=".$id."&amp;bd=".$bd."&amp;uid=".$uid."' data-role='button' data-ajax='false'   data-inline='true' data-theme='b' data-transition='slidedown' data-inline='true'>".$_['text_m_login']."</a>";
$WPErr[143]="<p>".$_['tip_returnlogin']."</p><a href='register.php?key=".$key."&amp;id=".$id."&amp;bd=".$bd."&amp;uid=".$uid."' data-ajax='false'  data-role='button' data-inline='true' data-theme='b' data-transition='slidedown' data-inline='true'>".$_['text_m_reg']."</a><a href='login.php?key=".$key."&amp;id=".$id."&amp;bd=".$bd."&amp;uid=".$uid."' data-role='button' data-ajax='false' data-inline='true' data-theme='b' data-transition='slidedown' data-inline='true'>".$_['text_m_login']."</a>";

$WPErr[144]="<p>".$_['tip_pageExpired']."</p><meta http-equiv='refresh' content='3;url=more.php' />";

$WPErr[145]="<p>".$_['alert_noLimit']."</p><meta http-equiv='refresh' content='3;url=".$skipUrl."' />".FUNCTION_AUTO."<a href='".$skipUrl."' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown' data-inline='true'>".FUNCTION_CLICK."</a>";
$WPErr[146]="<p>".$_['alert_noCheckBorder']."</p><meta http-equiv='refresh' content='3;url=topicshow.php?bd=".$bd."&amp;id=".$id."' />".FUNCTION_AUTO."<a href='topicshow.php?bd=".$bd."&amp;id=".$id."' data-role='button' data-ajax='false'   data-inline='true' data-theme='b' data-transition='slidedown' data-inline='true'>".FUNCTION_CLICK."";

$WPErr[147]="<p>".$_['alert_errorEdit']."</p><meta http-equiv='refresh' content='3;url=topicedit.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicedit.php?bd=".$bd."&amp;id=".$id."' data-role='button'   data-inline='true' data-theme='b' data-transition='slidedown'>".FUNCTION_CLICK."</a>";
$WPErr[148]="<p>".$_['alert_postRepeat']."</p><meta http-equiv='refresh' content='3;url=topicshow.php?bd=".$bd."&amp;id=".$id."' />
		".FUNCTION_AUTO."<a href='topicshow.php?bd=".$bd."&amp;id=".$id."' data-role='button' data-ajax='false'   data-inline='true' data-theme='b' data-transition='slidedown' data-inline='true'>".FUNCTION_CLICK."</a>";

?>

<body> 

<div data-role="page">

	<div data-role="header" data-position="fixed" data-theme="b">
		<a href="index.html" data-rel="back"><?php echo $_['btn_back']?></a>
		<h1><?php echo $_['text_promptTopic']?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext">home</a>
	</div>

	<div data-role="content" data-theme="c">
		<?php echo $WPErr[Trim($_GET["auto"])]?>
		  
		</div>
	
</div><!-- /page -->


</body>
</html>

