<?php

/**
 * userpassword.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/userpassword.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	$header_title=$_['text_editPwd'];
	require_once('htmltop.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo3g($_['tip_returnlogin'],'login.php');
	}
?>
<body> 
<script type="text/javascript">
	function jqmSimpleMessage(message) {
		$("<div class='ui-loader ui-overlay-shadow ui-body-b ui-corner-all'><h1>" + message + "</h1></div>")
			.css({
				display: "block",
				opacity: 0.96,
				top: window.pageYOffset+100
			})
			.appendTo("body").delay(800)
			.fadeOut(400, function(){
				$(this).remove();
			});
	}
	$(document).ready(function(){
		$("#submit").click(function(){
			var pwd1=$("#password").val();
			var pwd2=$("#password2").val();
			var pwd3=$("#rePw").val();
			if (pwd1==''){ 
				jqmSimpleMessage('<?php echo $_['alert_oldPWD']?>');
				$("#password").focus();
				return false;
			}
			if (pwd2==''){
				jqmSimpleMessage('<?php echo $_['alert_forgetPw21'];?>');
				$("#password2").focus();
				return false;
			}
			if (pwd3==''){
				jqmSimpleMessage('<?php echo $_['alert_forgetPw22'];?>');
				$("#rePw").focus();
				return false;
			}
			if (pwd2!=pwd3){
				jqmSimpleMessage('<?php echo $_['alert_forgetPw23'];?>');
				return false;
			}
			$.ajax({
				url:"user_do.php",
				type:'get',
				data:{
					'oldPw':pwd1,
					'newPw':pwd2,
					'rePw':pwd3,
					'act':'pw'
				},
				success:function(rt){
					if (rt=="O"){
						jqmSimpleMessage('<?php echo $_['tip_errorOldPwd'];?>');
						
					}else if (rt=="E"){
						jqmSimpleMessage('<?php echo $_['error_eidtPw'];?>');
					}else if (rt=="S"){
						jqmSimpleMessage('<?php echo $_['suc_editPw'];?>');
					}
				}
			});
			return false;
		});
	});
</script>

<div data-role="page" id="album-list">

	<div data-role="header" data-position="fixed" data-theme="b">
		<a href="usercenter.php" data-rel="back"><?php echo $_['btn_goback'];?></a>
		<h1><?php echo $_['text_editPwd']?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext"></a>
	</div>
	<div data-role="content">
		<form  data-ajax="false">
			<div data-role="fieldcontain">
				<label for="password">　<?php echo $_['text_oldPwd'];?>：</label>
				<input type="password" name="oldPw" id="password"/>
			</div>

			<div data-role="fieldcontain">
				<label for="password2">　<?php echo $_['text_newPwd'];?>：</label>
				<input type="password" name="newPw" id="password2"/>
			</div>

			<div data-role="name">
				<label for="rePw">　<?php echo $_['text_rePwd'];?>：</label>
				<input type="password" name="rePw" id="rePw"/>
			</div>

			<div data-role="name">
				<label for="name">&nbsp;</label>
				<input type="submit" data-theme="b" data-inline="true" value="<?php echo $_['btn_submit']?>" id="submit"/>
			</div>
		</form> 
	</div><!-- /content -->	
	<div data-role="footer" data-position="fixed">
		<?php require_once('bottom.php');?>
	</div><!-- /footer -->
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>
