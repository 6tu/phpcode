<?php

/**
 * uploadheader.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/uploadheader.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	$header_title=$_['text_upload'];
	require_once('htmltop.php');
	require_once('usercheck.php');
	$user=$wiibbsUser->getUserByAccount();
?>
<body> 
<script type="text/javascript">
 function jqmSimpleMessage(message) {
		$("<div class='ui-loader ui-overlay-shadow ui-body-b ui-corner-all'><h1>" + message + "</h1></div>")
			.css({
				display: "block",
				opacity: 0.96,
				top: window.pageYOffset+100
			})
			.appendTo("body").delay(800)
			.fadeOut(400, function(){
				$(this).remove();
			});
	}
	function ajaxFileUpload()
	{
		$("#loading")
		.ajaxStart(function(){
			$(this).show();
		})
		.ajaxComplete(function(){
			$(this).hide();
		});

		$.ajaxFileUpload
		(
			{
				url:'header_picup.php',
				secureuri:false,
				fileElementId:'fileToUpload',
				dataType: 'json',
				data:{name:'logan', id:'id'},
				success: function (data, status)
				{
					data=data.replace('<pre>','');
					data=data.replace('</pre>','');
					var info=data.split('||');
					if(info[0]=="E")
						jqmSimpleMessage(info[1]);
					else{
						document.getElementById('upinfo').innerHTML=info[2];
						document.getElementById('upfile').value=info[2];
						jqmSimpleMessage("上传成功");
						 location.reload();
					}
				},
				error: function (data, status, e)
				{
					alert(e);
				}
			}
		)
		return false;
	}
	

	
	</script>
<div data-role="page" id="album-list">

	<div data-role="header" data-position="fixed" data-theme="b">
		
		<h1><?php echo $_['text_upload'];?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext">home</a>
	</div>
	<div data-role="content">
		<?php
				if(!empty($user['user_photo'])&&file_exists(ROOT_PATH.'userfiles/header/pic/'.$user['user_photo']))
				{
					$imgs=getimagesize(ROOT_PATH.'userfiles/header/pic/'.$user['user_photo']);
					echo "<p><img src='".NETURL.'/userfiles/header/pic/'.$user['user_photo']."' width='".$imgs[0]."' height='".$imgs[1]."'/></p>";
				}
			?>
		<form action="user_do.php?act=upload" method="post" enctype="multipart/form-data" data-ajax="false">
			
				<div data-role="fieldcontain">
						<label for="name"><?php echo $_['text_fileUp']?>；</label>
						<span id="loading" style="display:none;"><img src="themes/images/loading.gif" width="16" height="16" alt="loading" /></span><span id="upinfo" style="color:blue;"></span><input id="upfile" name="upfile" value="" type="hidden" /><input id="fileToUpload" type="file" name="fileToUpload" style="height:24px;" />

					</div>
				
			<div data-role="fieldcontain">
				<label for="textarea">&nbsp;</label>
				<input type="submit" data-theme="b" data-inline="true" value="<?php echo $_['btn_upload']?>" onclick="return ajaxFileUpload();">

			</div>
		
		</form> 
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>
