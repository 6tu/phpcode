<?php

/**
 * msg_reply.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/msg_reply.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	require_once(THISPATHROOT.'include/lib/msg_wiipu.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo($_['tip_returnlogin'],'login.php');
	}
	$msg=new Msg($registry);
	$act=sqlReplace(trim($_GET['act']));
	$id=sqlReplace(trim($_GET['id']));
	$message=$msg->getMsgById($id);
	if(!$message)
	{
		alertInfo($_['tip_nomsg'],'msg_list.php?act='.$act);
	}
	$header_title=$_['text_writeBox'];
	require_once('htmltop.php');
?>
<body> 
<script type="text/javascript">
	function jqmSimpleMessage(message) {
		$("<div class='ui-loader ui-overlay-shadow ui-body-b ui-corner-all'><h1>" + message + "</h1></div>")
			.css({
				display: "block",
				opacity: 0.96,
				top: window.pageYOffset+100
			})
			.appendTo("body").delay(800)
			.fadeOut(400, function(){
				$(this).remove();
			});
	}
	$(document).ready(function(){
		$("#submit").click(function(){
			var name=$("#receiver").val();
			var title=$("#title").val();
			var content=$("#content").val();
			if (name==''){ 
				jqmSimpleMessage('<?php echo $_['tip_Receivernull']?>');
				$("#receiver").focus();
				return false;
			}
			if (title==''){
				jqmSimpleMessage('<?php echo $_['tip_titlenull'];?>');
				$("#title").focus();
				return false;
			}
			if (content==''){
				jqmSimpleMessage('<?php echo $_['tip_contentnull'];?>');
				return false;
			}
			$.ajax({
				url:"msg_do.php",
				type:'get',
				data:{
					'receiver':name,
					'title':title,
					'content':content,
					'act':'reply',
				},
				success:function(rt){
					if (rt=="S"){
						jqmSimpleMessage('<?php echo $_['suc_reply'];?>');
						
					}
				},error:function(rt){
					alert(rt);
				}
			});
			return false;
		});
	});
</script>
<div data-role="page" id="album-list">

	<div data-role="header" data-position="fixed" data-theme="b">
		<a href="usercenter.php" data-rel="back"><?php echo $_['btn_goback'];?></a>
		<h1><?php echo $_['text_writeBox']?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext"></a>
	</div>
	<div data-role="content">
		<form action="" data-ajax="false">
			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_receiver'].$message['msg_send'];?>：</label>
				<input type="text" name="receiver" id="receiver" value="<?php echo $message['msg_send'];?>"/>
			</div>
			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_title'];?>：</label>
				<input type="text" name="title" id="title" value="<?php echo $message['msg_title']?>"/>
			</div>

			<div data-role="fieldcontain">
				<label for="textarea"><?php echo $_['text_content'];?>：</label>
				<textarea cols="40" rows="8" name="content" id="content" value="<?php echo $_['text_content'];?>"></textarea>

			</div>
			<div data-role="fieldcontain">
				<label for="textarea"> </label>
				<input type="submit" data-theme="b" data-inline="true" value="<?php echo $_['btn_submit']?>" id="submit" data-ajax="false"/>
			</div>
		</form> 
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

