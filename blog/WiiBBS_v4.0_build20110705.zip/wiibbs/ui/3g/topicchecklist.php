<?php

/**
 * topicchecklist.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/topicchecklist.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	require_once('checklogin.php');
	if (!($manager || $userGroup)){
		header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=132&bd=".$bd);	
		exit;
	}
	$header_title=$_['text_checkTopic'];
	require_once('htmltop.php');
?>
<body> 
<div data-role="page" id="album-list" >

	<div data-role="header" data-position="fixed" data-theme="b">
		<a  data-rel="back"><?php echo $_['btn_back']?></a>
		<h1><?php echo $_['text_checkTopic']?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext">home</a>
	</div>
	
	
	<div data-role="content">
		<div data-role="controlgroup" data-type="horizontal" >
			<a href="board.php?key=good&amp;bd=<?php echo $bd?>" data-ajax='false' data-role="button" ><?php echo $_['text_good']?></a>
			<a href="board.php?bd=<?php echo $bd?>" data-ajax='false' data-role="button" ><?php echo $_['text_all']?></a>
			<a href="topicpost.php?bd=<?php echo $bd?>&amp;key=post" data-role="button"><?php echo $_['text_postTopic']?></a> 
			<?php if($bdCheck=="1") echo " <a href='topicchecklist.php?bd=".$bd."' data-role='button' data-theme=\"b\">".$_['text_check']."</a>";?>
		</div>
		
		<ul data-role="listview" data-theme="d"  data-inset="true">

		<?php
				$page=(empty($_GET['page']))?"":$_GET['page'];
				if (empty($page)||!is_numeric($page))$page=1;
				$pagesize=15;
				$startRow=0;
				$startRow=($page-1)*$pagesize;
				$rscount=$topic->getTopicCount($bd,'',0,1);
				if ($rscount%$pagesize==0)
					$pagecount=$rscount/$pagesize;
				else
					$pagecount=ceil($rscount/$pagesize);
				$topicList=$topic->getCheckTopic3g($bd,'0',$startRow,$pagesize,$page,'topic_updatetime','desc','1','',$keyword='');
			
		?>
		</ul>
		<?php 
			if ($pagecount>1){
					echo showPage1('topicchecklist.php?bd='.$bd,$page,$pagesize,$rscount,$pagecount);
			}
		?>
		
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

