<?php

/**
 * usercenter.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/usercenter.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	require_once(THISPATHROOT.'include/lib/msg_wiipu.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo3g($_['tip_returnlogin'],'login.php');
	}
	require_once('htmltop.php');
	$msg=new Msg($registry);
	$unredboxcount=$msg->getBoxCount('new');
	$inboxcount=$msg->getBoxCount('receive');
	$outboxcount=$msg->getBoxCount('send');
?>
<body> 

<div data-role="page" id="album-list">

	<div data-role="header" data-position="fixed" data-theme="b">
		<a href="index.php" data-rel="back"><?php echo $_['btn_back']?></a>
		<h1><?php echo $_['text_userCenter'];?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext">home</a>
	</div>
	<div data-role="content">
		<ul data-role="listview" data-inset="true" data-theme="d">
				<li><a href="msg_send.php" data-ajax="false"><?php echo $_['text_writeBox'];?></a></li>
				<li><a href="msg_list.php?act=new" data-ajax="false"><?php echo $_['text_unredBox'];?></a><span class="ui-li-count"><?php echo $unredboxcount;?></span></li>
				<li><a href="msg_list.php?act=receive" data-ajax="false"><?php echo $_['text_inBox'];?></a><span class="ui-li-count"><?php echo $inboxcount;?></span></li>
				<li><a href="msg_list.php?act=send" data-ajax="false"><?php echo $_['text_outBox'];?></a><span class="ui-li-count"><?php echo $outboxcount;?></span></li>
		</ul>
		<ul data-role="listview" data-inset="true" data-theme="d">
				<li><a href="userdata.php" data-ajax="false"><?php echo $_['text_myStuff'];?></a></li>
				<li><a href="useredit.php" data-ajax="false"><?php echo $_['text_editStuff'];?></a></li>
				<li><a href="userpassword.php" data-ajax="false"><?php echo $_['text_editPwd'];?></a></li>
				<li><a href="uploadheader.php" data-ajax="false"><?php echo $_['text_upload']?></a></li>
		</ul>
		<ul data-role="listview" data-inset="true" data-theme="d">
				<li><a href="userquit.php"><?php echo $_['btn_exit'];?></a></li>
		</ul>
	</div><!-- /content -->	
	<div data-role="footer" data-position="fixed">
			<?php require_once('bottom.php');?>
	</div><!-- /footer -->
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

