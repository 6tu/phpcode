<?php

/**
 * more.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/more.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once('htmltop.php');
?>
<body> 

<div data-role="page" id="album-list">
	<div data-role="header" data-position="fixed" data-theme="b">
		<a  data-rel="back"><?php echo $_['btn_back']?></a>
		<h1><?php echo $_['text_more']?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext">home</a>
	</div>
	<div data-role="content">
		<ul data-role="listview" data-inset="true" data-theme="d">
				<li><a href='<?php echo NETURL?>/index.php?key=simple' data-ajax="false"><?php echo $_['text_simple']?></a></li>
				<li><a href='<?php echo NETURL?>/index.php?key=color' data-ajax="false"><?php echo $_['text_color']?></a></li>
				<li data-icon="check" data-theme="c"><a href="index.php" ><?php echo $_['text_3g']?></a></li>
		</ul>
		<ul data-role="listview" data-inset="true" data-theme="d">
				<li><a href="topichot.php"><?php echo $_['btn_hotTopic']?></a></li>
				<li><a href="topic.php?key=new"><?php echo $_['btn_newTopic']?></a></li>
				<li><a href="topic.php?key=top"><?php echo $_['text_TopicAll']?></a></li>
		</ul>
		<ul data-role="listview" data-inset="true" data-theme="d">
				<li><a href="search.php"><?php echo $_['text_search']?></a></li>
			<?php if(SITECOUNT==1){?>
				<li><a href="stat.php"><?php echo $_['text_census']?></a></li>	
			<?php }?>
		</ul>
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

