<?php

/**
 * topicreplydo.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
define('THISPATHROOT', str_replace('ui/3g/topicreplydo.php', '', str_replace('\\', '/', __FILE__)));
require_once(THISPATHROOT.'include/db_conn.php');
require_once(THISPATHROOT.'include/lib/image_common.php');
require_once('usercheck.php');
If(empty($userName)){
		If($bdType==4){
			$userName="Guest";
		}else{
			 require_once('checklogin.php');
		} 
}
$action=sqlReplace(trim($_GET["do"]));

If($action=="del"){
	$id=sqlReplace(Trim($_GET["id"]));
	$id=intval($id);
	$rid=sqlReplace(Trim($_GET["rid"]));
	$rid=intval($rid);
	$key=empty($_GET['key'])?'':sqlReplace($_GET['key']);
	header("location:".NETURL."/ui/".$folder_color."/topicdeal.php?act=delReply&bd=".$bd."&id=".$id."&rid=".$rid."&key=".$key);
}
?>