<?php

/**
 * mytopic.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/mytopic.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	
	$header_title= $_['text_mySendTopic'];
	$_SESSION["infoPics"]='';
	require_once('htmltop.php');
?>
<body> 
<div data-role="page" id="album-list" >

	<div data-role="header" data-position="fixed" data-theme="b">
		<a  data-rel="back"><?php echo <?php echo $_['btn_back']?>?></a>
		<h1><?php echo $_['text_mySendTopic']?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext">home</a>
	</div>
	<div data-role="content">
		
		<ul data-role="listview" data-theme="d"  data-inset="true">

		<?php
			$page=(empty($_GET['page']))?"":$_GET['page'];
				if (empty($page)||!is_numeric($page))$page=1;
				$pagesize=15;
				$startRow=0;
				$startRow=($page-1)*$pagesize;
				$rscount=$topic->getTopicCountByAccount(2);
				if ($rscount%$pagesize==0)
					$pagecount=$rscount/$pagesize;
				else
					$pagecount=ceil($rscount/$pagesize);
					$topicList=$topic->getTopicByAccount($startRow,$pagesize,$page,2);
		?>
		</ul>
		<?php 
			if ($pagecount>1){
				echo showPage2('mytopic.php',$page,$pagesize,$rscount,$pagecount);
			}
		?>
		
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->
</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

