<?php

/**
 * userdata.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/3g/userdata.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	
	$header_title=$_['text_memberInformation'];
	require_once('htmltop.php');
	require_once('usercheck.php');
	$id=sqlReplace(trim($_GET['id']));
	$url=sqlReplace(trim($_GET['url']));
	$user=$wiibbsUser->getUserByAccount($id);
?>
 <body>
		<div data-role="page" id="album-list">

		<div data-role="header" data-position="fixed" data-theme="b">
			<a href="index.html" data-rel="back"><?php echo $_['btn_back']?></a>
			<h1><?php echo $_['text_memberInformation'];?></h1>
			<a href="index.php" data-icon="home" data-iconpos="notext">home</a>
		</div>
		
		
		<div data-role="content">
			
			<ul data-role="listview" data-inset="true" data-theme="d">
					<li><?php echo $_['text_nikeName'];?>：<?php echo $user['user_nickname']?></li>
					<li><?php echo $_['text_score'];?>：<?php echo $user['user_score']?></li>
					<li><?php echo $_['text_grade'];?>：<?php echo $user['user_grade']?></li>
					<li><?php echo $_['text_regTime'];?>：<?php echo $user['user_regtime']?></li>
					<li><?php echo $_['text_logCount'];?>：<?php echo $user['user_logincount']?></li>
					<li><?php echo $_['text_lastLoginTime'];?>：<?php echo $user['user_lastlogin']?></li>
			</ul>
			<p>
				<a href="userdeatils.php?uid=<?php echo $user['user_account']?>" data-role="button" data-inline="true" data-theme="b"><?php echo $_['text_details']?></a> 
			</p>
		</div><!-- /content -->	
		<?php require_once('bottom.php');?>
		
	</div><!-- /page -->
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>