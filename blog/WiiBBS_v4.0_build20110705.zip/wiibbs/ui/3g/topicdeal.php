<?php

/**
 * topicdeal.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/topicdeal.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	require_once('checklogin.php');
	$header_title=$_['header_delTopic'];
	require_once('htmltop.php');
	$act=sqlReplace(trim($_GET["act"]));
	$rcode=intval(rand()*1000);
?>
<body> 

<div data-role="page">

	<div data-role="header" data-theme="d" data-position="inline">
			<h1>Dialog</h1>

	</div>

	<div data-role="content" data-theme="c">
		<?php
			switch ($act){
				case 'del';
					$id=sqlReplace(Trim($_GET["id"]));
					$id=intval($id);
					$t=empty($_GET["t"])?'':sqlReplace(Trim($_GET["t"]));
					if (empty($t))
						$url='topicshow.php';
					else
						$url='topiccheck.php';
					echo "<p>";
					echo $_['text_sureDel'].'</p>';
					echo "<a href='topicdo.php?do=doDel&amp;bd=".$bd."&amp;id=".$id."&amp;t=".$t."' data-ajax=\"false\"  data-role=\"button\"  data-theme=\"b\" data-inline='true'   data-transition=\"slidedown\">".$_['btn_certain']."</a> <a href='".$url."?bd=".$bd."&amp;id=".$id."' data-role=\"button\" data-rel=\"back\" data-theme=\"c\" data-inline='true' data-direction=\"reverse\" data-ajax='false'>".$_['btn_cancel']."</a>";
				break;
				case 'move';
					$bd=sqlReplace(Trim($_GET["bd"]));
					$oldbd=sqlReplace(Trim($_GET["oldbd"]));
					echo "<p>";
					echo $_['alert_successMove'].'</p>';
					echo "<a href='board.php?bd=".$oldbd."' data-inline='true' data-ajax='false' data-role=\"button\" data-theme=\"b\">".$_['text_oldBorder']."</a> <a href='board.php?bd=".$bd."' data-role=\"button\" data-inline='true' data-theme=\"b\">".$_['text_newBorder']."</a>";

				break;
				case 'delReply';
					$id=sqlReplace(Trim($_GET["id"]));
					$rid=sqlReplace(Trim($_GET["rid"]));
					
					$url='topicreplylist.php';
					echo "<p>";
					echo $_['text_sureDelReply'].'</p>';
					echo "<a href='topicdo.php?do=doDelReply&amp;bd=".$bd."&amp;id=".$id."&amp;rid=".$rid."' data-inline='true' data-role=\"button\" data-ajax=\"false\" >".$_['btn_certain']."</a> <a href='".$url."?bd=".$bd."&amp;id=".$id."' data-inline='true' data-role=\"button\" data-rel=\"back\" data-theme=\"c\" data-direction=\"reverse\">".$_['btn_cancel']."</a>";
					echo '</div>';
				break;
			}
		?>
		 
	</div>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

