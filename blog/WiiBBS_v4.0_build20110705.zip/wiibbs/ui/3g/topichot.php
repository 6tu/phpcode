<?php

/**
 * topicchot.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/topichot.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/applications.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/topic.php');
	$header_title=$_['text_HotTopic'];
	require_once('htmltop.php');
?>
<body> 
<div data-role="page" id="album-list">

	<div data-role="header" data-position="fixed" data-theme="b">
		<a  data-rel="back"><?php echo $_['btn_back']?></a>
		<h1><?php echo $_['text_HotTopic']?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext">home</a>
	</div>
	
	<div data-role="content">

		<div data-role="controlgroup" data-type="horizontal" >
			<a href="topichot.php" data-role="button" data-theme="b"><?php echo $_['btn_hotTopic']?></a>
			<a href="topic.php?key=new" data-role="button"><?php echo $_['btn_newTopic']?></a>
			<a href="topic.php?key=top" data-role="button"><?php echo $_['text_topicAlltop']?></a>
		</div>

		<ol data-role="listview" data-theme="d"  data-inset="true">
		<?php
			$topics=$topic->getHotTopicList(0,10);
			if(count($topics)<1)
			{
				echo "<li>".$_['tip_noHotTopic']."</li>";
			}
			for($i=0;$i<count($topics);$i++)
			{
		?>
			<li><a href="topicshow.php?bd=<?php echo $topics[$i]["topic_board"]?>&amp;id=<?php echo $topics[$i]["topic_id"]?>&amp;rnd=<?php echo rand()?>" data-ajax='false'><?php echo $topics[$i]["topic_title"]?></a> <span class="ui-li-count"><?php echo $topics[$i]["topic_recount"]."/".$topics[$i]["topic_viewcount"]?></span></li>
		<?php
			}
		?>
			</ol>
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

