<?php

/**
 * search.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/3g/search.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(THISPATHROOT.'include/lib/keyword_wiipu.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/applications.php');
	
	$header_title=$_['text_searchTopic'];
	require_once('htmltop.php');
	$keyword=new KeyWord($registry);
?>
<body> 

<div data-role="page" id="album-list">

	<div data-role="header" data-position="fixed" data-theme="b">
		<a href="index.php" data-rel="back"><?php echo $_['btn_back']?></a>
		<h1> <?php echo $_['text_searchTopic']?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext">home</a>
	</div>
	<div data-role="content">
		<form action="search.php" method="get">
			<div data-role="fieldcontain">
				<input type="search" name="search" id="search" value="" />
			</div>
			<div data-role="fieldcontain">
				<label for="textarea">&nbsp;</label>
				<input type="submit" data-theme="b" data-inline="true" value="<?php echo $_['btn_search']?>">

			</div>
		
		</form> 
		<ul data-role="listview" data-theme="d"  data-inset="true" data-divider-theme='b'>
		<?php
			$search=empty($_GET['search'])?'':sqlReplace(trim($_GET['search']));
			if (SITEFILTER!=''){
				$filter=str_replace("，",',',SITEFILTER);
				$filters=explode(",",$filter);
				for($i=0;$i<count($filters);$i++)
				{
					if(strpos($search,$filters[$i])>-1)
					{
						alertInfo($_['alert_filter_r'],'search.php');
					}
				}
			}
			if(!empty($search))
			{
				$keyword->operateKey($search);
				$page=(empty($_GET['page']))?"":$_GET['page'];
				if (empty($page)||!is_numeric($page))$page=1;
				
				$pagesize=15;
				$startRow=0;
				$startRow=($page-1)*$pagesize;
				$rscount=$topic->getTopicCount('','','0','',$search);
				if ($rscount%$pagesize==0)
					$pagecount=$rscount/$pagesize;
				else
					$pagecount=ceil($rscount/$pagesize);
				if ($rscount>0)
					echo "<li data-role='list-divider'>“".$search."”".$_['tip_search']."</li>";
				 $topicList=$topic->getTopic3g('','',$startRow,$pagesize,$page,'','topic_updatetime','desc',0,'',$search);
				
			}else{
				
				$keyList=$keyword->getKeyList(10);
				
				foreach($keyList as $key)
				{
					echo "<li><a href='search.php?search=".$key['keyword_name']."'>".$key['keyword_name']."</a><span class=\"ui-li-count\">".$key['keyword_count']."</span></li>";
				}
			}
		?>
		</ul>
		<?php
			if (!empty($search)){
				if ($pagecount>1){

					echo showPage2('search.php?search='.$search,$page,$pagesize,$rscount,$pagecount);
				}
			}
		?>
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>


