<?php
	define('THISPATHROOT', str_replace('ui/3g/boardjump.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	$board=sqlReplace(trim($_POST['board']));
	header("location:".NETURL."/ui/3g/board.php?bd=".$board."");
?>