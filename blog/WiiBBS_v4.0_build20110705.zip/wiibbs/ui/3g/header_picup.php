<?php
/**
 * 首页Flash图片上传 flash_picup.php
 *
 * @version       v0.02
 * @create time   2011-5-19
 * @update time   2011-6-3
 * @author        jiangting
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 */
header("content-type:text/html;charset=utf-8");
define('THISPATHROOT', str_replace('ui/3g/header_picup.php', '', str_replace('\\', '/', __FILE__)));
require_once(THISPATHROOT.'include/db_conn.php');
require_once(THISPATHROOT.'include/lib/image_common.php');

	$info = "";
	$fileElementName = 'fileToUpload';
	if(!empty($_FILES[$fileElementName]['error']))
	{
		switch($_FILES[$fileElementName]['error'])
		{

			case '1':
				$info = 'E||'.$_['error_up1'];
				break;
			case '3':
				$info = 'E||'.$_['error_up2'];
				break;
			case '4':
				$info = 'E||'.$_['error_up3'];
				break;
			case '6':
				$info = 'E||'.$_['error_up4'];
				break;
			case '7':
				$info = 'E||'.$_['error_up5'];
				break;
			default:
				$info = 'E||'.$_['error_up6'];
		}
	}elseif(empty($_FILES[$fileElementName]['tmp_name']) || $_FILES[$fileElementName]['tmp_name'] == 'none'){
		$info = 'E||'.$_['error_up3'];
	}else{
		$f_name=$_FILES[$fileElementName]['name'];
		$f_name_1=$_FILES[$fileElementName]['name'];
		$f_size=$_FILES[$fileElementName]['size'];
		$f_tmpName=$_FILES[$fileElementName]['tmp_name'];

		$f_ext=strtolower(preg_replace('/.*\.(.*[^\.].*)*/iU','\\1',$f_name));
		$f_exts=explode("|",'gif|jpg|png');
		$checkExt=true;
		foreach ($f_exts as $v){
			if ($f_ext==$v){
				$checkExt=false;
				break;
			}
		}
		
		if ($checkExt){
			$info = 'E||'.$_['alert_type1'].attachType.$_['alert_type2'];
		}else{
			if ($f_size>40*1024){
				$info = 'E||'.$_['error_fileSizeOut'];
			}else{
				$random= rand(100,999); 
				$f_fullname= time().$random.".".$f_ext;
				$f_path=ROOT_PATH."userfiles/header/initial/".$f_fullname;
				$f_path_r="userfiles/header/initial/".$f_fullname;

				if (copy($f_tmpName,$f_path)){
					if($f_ext=="jpg"){
						$t = new ThumbHandler();
						$newfilename=ROOT_PATH."userfiles/header/pic/".$f_fullname;
						$t = new ThumbHandler();
						$t->setSrcImg($f_path);
						$t->setDstImg($newfilename);
						$t->createImg(115,115);
						
					}
					$arr['user_photo']=$f_fullname;
				
					$result=$wiibbsUser->updateUser($arr);
					if($result==1)
					{
						$info = "S||".$f_path_r."||".$f_fullname;
					}else{
						$info = "E||".$_['error_upload'];
					}
				}else{
					$info = 'E||'.$_['error_up7'];
				}
			}
		}
		@unlink($_FILES[$fileElementName]);
	}
	echo $info;
?>