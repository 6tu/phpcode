<?php

/**
 * topicmove.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/topicmove.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	require_once('checklogin.php');
	if (!($manager || $userGroup)) alertInfo($_['alert_noLimit'],'index.php');
	$header_title=$_['header_moveTopic'];
	require_once('htmltop.php');
	$id=sqlReplace(Trim($_GET["id"]));
	$id=intval($id);
	$row=$topic->getTopicByID_BD($id,$bd);
	If(!$row){
		header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=102");
		exit;
	}Else{
		$title=$row["topic_title"];
		$content=$row["topic_content"];
	}
?>
<body> 

<div data-role="page" id="album-list">

	<div data-role="header" data-position="fixed" data-theme="b">
		<h1><?php echo $_['header_moveTopic']?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext">home</a>
	</div>
	<div data-role="content">
		<form action="topicdo.php?id=<?php echo $id?>&amp;do=move" method="post" data-ajax="false">
			<div data-role="fieldcontain">
				<label for="select-choice-1" class="select"><?php echo $_['text_checkBoard']?>:</label>
				<select name="bd" id="select-choice-1">
					<?php
						$bList=$board->getBoardList('',$bd);
						If(!$bList){
							echo "<option value='0'>".$_['text_noBoard'] ."</option>";
						}Else{
							foreach($bList as $row){
					?>
							<option value="<?php echo $row["board_id"]?>" ><?php echo $row["board_name"]?></option>
					<?php
							}
						}
					?>
				</select>
			</div>

			<div data-role="fieldcontain">
				<label for="textarea">&nbsp;</label>
				<input type="submit" data-theme="b" data-inline="true" value="<?php echo $_['btn_move']?>">

			</div>
			
			<INPUT inputmode="user predictOn" type="hidden" name="oldbd" value="<?php echo $bd?>">
		</form> 
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

