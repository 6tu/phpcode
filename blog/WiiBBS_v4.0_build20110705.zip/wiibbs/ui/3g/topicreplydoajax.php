<?php

/**
 * topicdo.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

define('THISPATHROOT', str_replace('ui/3g/topicreplydoajax.php', '', str_replace('\\', '/', __FILE__)));
require_once(THISPATHROOT.'include/db_conn.php');
require_once('usercheck.php');
require_once('checklogin.php');
$action=sqlReplace(trim($_GET["act"]));
switch($action){
	case "del":
		$id=trim($_GET["id"]);
		$rid=trim($_GET["rid"]);
		$id=intval($id);
		$result=$topic->delReply($id,$bd,$rid,$manager,$userGroup,$userName);
		echo $result;
	break;
}
?>