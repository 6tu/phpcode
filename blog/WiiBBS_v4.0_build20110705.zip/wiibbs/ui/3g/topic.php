<?php

/**
 * topic.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/3g/topic.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/applications.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/topic.php');
	$header_title=$_['text_HotTopic'];
	require_once('htmltop.php');
	$key=(empty($_GET["key"]))?"new":sqlReplace($_GET['key']);
	If($key=="new"){
		$title = $_['btn_hotTopic'];
	}Else{
		$title =$_['text_TopicAll'];
	} 
	$header_title= $title1;
	require_once('htmltop.php');
?>
<body> 
<div data-role="page" id="album-list" >

	<div data-role="header" data-position="fixed" data-theme="b">
		<a  data-rel="back"><?php echo $_['btn_back']?></a>
		<h1><?php echo $title?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext">home</a>
	</div>
	
	
	<div data-role="content">
		<div data-role="controlgroup" data-type="horizontal" >
			<a href="topichot.php" data-role="button" ><?php echo $_['btn_hotTopic']?></a>
			<a href="topic.php?key=new" data-role="button" <?php if ($key=="new") echo "data-theme=\"b\""?>><?php echo $_['btn_newTopic']?></a>
			<a href="topic.php?key=top" data-role="button" <?php if ($key=="top") echo "data-theme=\"b\""?>><?php echo $_['text_topicAlltop']?></a>
		</div>
		
		<ul data-role="listview" data-theme="d"  data-inset="true">

		<?php
			if ($key=="top"){
				
					
				$allTop=$topic->getAllTopTopic3g_r();
					
			}else{
				$topicList=$topic->getTopic3g('',0,0,10,1);
			}
				
		?>
		</ul>
		
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

