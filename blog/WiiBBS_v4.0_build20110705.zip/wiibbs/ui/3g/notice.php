<?php

/**
 * notice.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/notice.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	require_once(THISPATHROOT.'include/lib/msg_wiipu.php');
	$session->data['setUrl']=getUrl();
	$userName=$wiibbsUser->checkISlogin();
	 require_once('checklogin.php');
	require_once('htmltop.php');
	$row_r=$noticeClass->getNotice(1);
		if ($row_r){
			$replyCount=$row_r['notice_count'];
			$url_notice=$row_r['notice_url'];
		}else{
			$replyCount=0;
			$url_notice='';
		}
		$row_m=$noticeClass->getNotice(2);
		if ($row_m){
			$mailCount=$row_m['notice_count'];
		}else{
			$mailCount=0;
		}
?>
<body> 

<div data-role="page" id="album-list">

	<div data-role="header" data-position="fixed" data-theme="b">
		<a href="index.php" data-rel="back"><?php echo $_['btn_goback'];?></a>
		<h1><?php echo $_['text_notice']?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext"></a>
	</div>	
	<div data-role="content">
		
		<ul data-role="listview" data-theme="d"  data-inset="true" >
		<?php
			if ($mailCount>0){
					echo "<li><a href='msg_list.php?act=new' data-ajax='false'>".$_['text_noticeHave'].$mailCount.$_['text_noticeEmial']."</a></li>";
				}
				if ($replyCount>0){
					echo "<li><a href=\"".$url_notice."\" class='notice' data-ajax='false'>".$_['text_noticeHave'].$replyCount.$_['text_noticeReply']."</a></li>";
				}
		?>
			
			
		</ul>

	</div><!-- /content -->	
		<?php require_once('bottom.php');?>

	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

