<?php

/**
 * register.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/register.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	
	$header_title=$_['text_userRegister'];
	require_once('htmltop.php');
	
?>
<body> 
<script type="text/javascript">
	function jqmSimpleMessage(message) {
		$("<div class='ui-loader ui-overlay-shadow ui-body-b ui-corner-all'><h1>" + message + "</h1></div>")
			.css({
				display: "block",
				opacity: 0.96,
				top: window.pageYOffset+100
			})
			.appendTo("body").delay(800)
			.fadeOut(400, function(){
				$(this).remove();
			});
	}

	$(document).ready(function(){
		$("#submit").click(function(){
			var name=$("#name").val();
			var pass=$("#password").val();
			var pass1=$("#password1").val();
			if (name==''){ 
				jqmSimpleMessage('<?php echo $_['alert_account']?>');
				$("#name").focus();
				return false;
			}
			if (pass==''){
				jqmSimpleMessage('<?php echo $_['alert_pwd'];?>');
				$("#password").focus();
				return false;
			}
			if (pass1==''){
				jqmSimpleMessage('<?php echo $_['alert_pwd1'];?>');
				$("#password1").focus();
				return false;
			}
			if (pass1!=pass){
				jqmSimpleMessage('<?php echo $_['alert_pwd2'];?>');
				$("#password").focus();
				return false;
			}
			$.ajax({
				url:"register_do.php",
				type:'post',
				data:{
					'account':name,
					'pwd':pass,
					'pwd2':pass1
				},
				success:function(rt){
					if (rt=="F"){
						jqmSimpleMessage('<?php echo $_['tip_forbidAccount'];?>');
						$("#name").focus();
						
					}else if (rt=="A"){
						jqmSimpleMessage('<?php echo $_['tip_accounLength'].accountMinLength.$_['tip_to'].accountMaxLength.$_['tip_center'];?>');
					}else if (rt=="B"){
						jqmSimpleMessage('<?php echo $_['tip_allowNum'];?>');
					}else if (rt=="C"){
						jqmSimpleMessage('<?php echo $_['tip_allowLetter'];?>');
					}else if (rt=="D"){
						jqmSimpleMessage('<?php echo $_['tip_allowCommon'];?>');
					}else if (rt=="1"){
						jqmSimpleMessage('<?php echo $_['tip_accountexist'];?>');
					}else if (rt==2){
						jqmSimpleMessage('<?php echo $_['tip_updateEmail'];?>');
					}else if (rt==3){
						jqmSimpleMessage('<?php echo $_['suc_register_3g'];?>');
						location.href='login.php';
					}else if (rt==4){
						jqmSimpleMessage('<?php echo $_['error_register'];?>');
					}else if (rt==5){
						jqmSimpleMessage('<?php echo $_['tip_timeOut'];?>');
					}else if (rt==6){
						jqmSimpleMessage('<?php echo $_['tip_timeOut'];?>');
					}else{
						jqmSimpleMessage('<?php echo $_['tip_exception'];?>');
					}
				},
				error:function(XMLHttpRequest, textStatus, errorThrown){
					alert(textStatus);
				}
			});
			return false;
		});
	});
</script>
<div data-role="page" id="album-list">

	<div data-role="header" data-position="fixed" data-theme="b">
		<a href="index.php" data-rel="back"><?php echo $_['btn_goback'];?></a>
		<h1><?php echo $_['text_userRegister'];?></h1>
		<a href="login.php" data-icon="arrow-r" data-iconpos="right" data-ajax="false"><?php echo $_['btn_login'];?></a>
	</div>
	<div data-role="content">
		<div id="information" style="color:red;" ></div>
		<form  method="post" data-ajax="false">
			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_account'];?>：</label>
				<input type="text" name="account" id="name" />
			</div>
			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_password'];?>：</label>
				<input type="password" name="pwd" id="password" />
			</div>
			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_confirmPwd'];?>：</label>
				<input type="password" name="pwd2" id="password1" />
			</div>
			<div data-role="fieldcontain">
				<label for="name"> </label>
				<input type="submit" data-theme="b" data-inline="true" value="<?php echo $_['btn_register']?>" id="submit"/>
			</div>
		
		</form> 
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>
