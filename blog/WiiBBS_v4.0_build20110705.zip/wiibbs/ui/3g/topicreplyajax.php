<?php

/**
 * topicreplydo.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
define('THISPATHROOT', str_replace('ui/3g/topicreplyajax.php', '', str_replace('\\', '/', __FILE__)));
require_once(THISPATHROOT.'include/db_conn.php');
require_once(THISPATHROOT.'include/lib/image_common.php');
require_once('usercheck.php');
If(empty($userName)){
		If($bdType==4){
			$userName="Guest";
		}else{
			 require_once('checklogin.php');
		} 
}

	$id=sqlReplace(Trim($_GET["id"]));
	$id=intval($id);
	$db1=sqlReplace(trim($_GET['bd']));
	$content=HTMLEncode($_GET["content"]);
	$file=empty($_GET['file'])?'':sqlReplace($_GET["file"]);
	$f_size=empty($_GET['f_size'])?'':sqlReplace($_GET["f_size"]);
	$f_name=empty($_GET['f_name'])?'':sqlReplace($_GET["f_name"]);
	$f_ext=empty($_GET['f_ext'])?'':sqlReplace($_GET["f_ext"]);
	$result=$topic->checkLockTopic(1,$id,$bd);
	If($result){
		echo "R";
		exit;
	}
	if (SITEFILTER!=''){
		$filter=str_replace("，",',',SITEFILTER);
		$filters=explode(",",$filter);
		for($i=0;$i<count($filters);$i++)
		{
			if(strpos($content,$filters[$i])>-1)
			{
					echo "F";
					exit;
	
			}
		}
	}
	
	
	$data=array(
	'topicID'=>$id,
	'content'=>$content,
	'wiibbsUser'=>$userName,
	'bd'=>$bd,
	'upload'=>$file,
	'type'=>$f_ext,
	'fileName'=>str_replace(".".$f_ext,'',$f_name),
	'fileSize'=>$f_size
	);
	$result=$topic->insertTopicReply($data);
	echo $result;
	

?>