<?php

/**
 * login.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/3g/login.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	
	$header_title=$_['text_memberLogin'];
	require_once('htmltop.php');
	if (empty($session->data['setUrl']))
		$backUrl='index.php';
	else
		$backUrl=$session->data['setUrl'];
?>
<body> 
<script type="text/javascript">
	function jqmSimpleMessage(message) {
		$("<div class='ui-loader ui-overlay-shadow ui-body-b ui-corner-all'><h1>" + message + "</h1></div>")
			.css({
				display: "block",
				opacity: 0.96,
				top: window.pageYOffset+100
			})
			.appendTo("body").delay(800)
			.fadeOut(400, function(){
				$(this).remove();
			});
	}
	$(document).ready(function(){
		$("#submit").click(function(){
			var name=$("#name").val();
			var pass=$("#password").val();
			if (name==''){ 
				jqmSimpleMessage('<?php echo $_['alert_account']?>');
				$("#name").focus();
				return false;
			}
			if (pass==''){
				jqmSimpleMessage('<?php echo $_['alert_pwd'];?>');
				$("#password").focus();
				return false;
			}
			$.ajax({
				url:"userlogin_do.php",
				type:'post',
				data:{
					'account':name,
					'pwd':pass
				},
				success:function(rt){
					if (rt==1){
						jqmSimpleMessage('<?php echo $_['tip_AEexist'];?>');
						$("#name").focus();
						
					}else if (rt==2){
						jqmSimpleMessage('<?php echo $_['tip_pwderror'];?>');
						$("#password").focus();
					}else if (rt==3){
						jqmSimpleMessage('<?php echo $_['success_login'];?>');
						location.href='<?php echo $backUrl;?>';
					}else{
						jqmSimpleMessage('<?php echo $_['tip_exception_3g'];?>');
					}
				}
			});
			return false;
		});
	});
</script>

<div data-role="page" id="album-list">

	<div data-role="header" data-position="fixed" data-theme="b">
		<a href="index.php" data-rel="back"><?php echo $_['btn_goback'];?></a>
		<h1><?php echo $_['text_memberLogin']?></h1>
		<a href="register.php" data-icon="arrow-r" data-iconpos="right"><?php echo $_['btn_register'];?></a>
	</div>
	
	<div data-role="content">
		<div id="information" style="color:red;"></div>
		<form action="" method="post" data-ajax="false">
			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_accountoremail_3g'];?>：</label>
				<input type="text" name="account" id="name" />
			</div>
			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_password'];?>：</label>
				<input type="password" name="pwd" id="password" />
			</div>
			<div data-role="fieldcontain">
				<label for="name"> </label>
				<input type="submit" data-theme="b" data-inline="true" value="<?php echo $_['btn_login']?>" id="submit"/>
				<a href="usergetpw.php" data-role="button" data-inline="true" data-ajax="false"><?php echo $_['btn_forgetpw']?></a>
			</div>
		
		</form> 
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>
