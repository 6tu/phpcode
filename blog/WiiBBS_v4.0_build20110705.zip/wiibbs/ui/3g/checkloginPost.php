<?php

/**
 * checklogin.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
 define('THISPATHROOT', str_replace('ui/3g/checkloginPost.php', '', str_replace('\\', '/', __FILE__)));
require_once(THISPATHROOT.'include/db_conn.php');
$bd=sqlReplace($_GET["bd"]);
$row=$board->getBoardByID($bd);
if($row){	
	$bdType=$row["board_type"];
 }
 $userName=$wiibbsUser->checkISlogin();

 If($bdType!=4){
	  if (empty($userName)){
			echo "E";
			exit;
		}
		$row=$wiibbsUser->getUserByAccount();
		if ($row){
			$userVip=$row["user_isvip"];
			$userLevel=$row["user_level"];
		}
		$manager=false;
		$userGroup=false;
		
		If ($userLevel=="2"){
			$manager=true;
			//$userGroup=true;
		}
		//if ($board->isCheckUsergroup($userName,$bd)) $userGroup=true;
	  if ($bdType==6){  //�����ѯ�����Ȩ��
		if (!$manager){
			header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=111&bd=".$bd);
			echo "Z";
			exit;
		}
	  }
	  echo "S";
}else{
	echo "S";
}

?>