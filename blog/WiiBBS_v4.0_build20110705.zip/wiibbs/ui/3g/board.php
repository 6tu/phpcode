<?php

/**
 * board.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/3g/board.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once('htmltop.php');
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	$session->data['setSkipUrl']=getUrl();
	$key=(empty($_GET["key"]))?"":sqlReplace($_GET['key']);
	If($key=="good"){
		$title = "&gt;&gt;".$_['text_good'];
		$title1 = " - ".$_['text_good'];
		$good = 1;
	}Else{
		$title ="";
		$good = "";
		$title1='';
	} 
	$header_title= $bdName.$title1;
	require_once('htmltop.php');
	
?>
<body> 
<script type="text/javascript">
 function jqmSimpleMessage(message) {
		$("<div class='ui-loader ui-overlay-shadow ui-body-b ui-corner-all'><h1>" + message + "</h1></div>")
			.css({
				display: "block",
				opacity: 0.96,
				top: window.pageYOffset+100
			})
			.appendTo("body").delay(800)
			.fadeOut(400, function(){
				$(this).remove();
			});
	}
	


		function skipPost(){	
			$.ajax({
				url:"checkloginPost.php",
				type:'get',
					data:{
						bd:<?php echo $bd;?>
					},
				success:function(rt){
					if (rt=="E"){
						jqmSimpleMessage('<?php echo $_['tip_returnlogin'];?>');
					}else if (rt=="z"){
						jqmSimpleMessage('<?php echo $_['alert_adminBoard'];?>');
					
					}else{
						userCheck();
					}
				},
				error:function(XMLHttpRequest, textStatus, errorThrown){
					alert(XMLHttpRequest+"D");
				}
			});
			return false;
			
		}


	function userCheck(){
				$.ajax({
					url:"usercheck3g.php",
					type:'get',
					data:{
						bd:<?php echo $bd;?>
					},
					success:function(rt){
						if (rt=="A"){
							jqmSimpleMessage('<?php echo $_['alert_noNEW'];?>');
						}else if (rt=="B"){
							jqmSimpleMessage('<?php echo $_['alert_boardLogin'];?>');
						}else if (rt=="C"){
							jqmSimpleMessage('<?php echo $_['alert_noLimit'];?>');
							
						}else if (rt=="D"){
							jqmSimpleMessage('<?php echo $_['alert_noLimit'];?>');
						}else if (rt=="F"){
							jqmSimpleMessage('<?php echo $_['alert_noLimit'];?>');
						}else{
							location.href='topicpost.php?bd=<?php echo $bd?>';
						}
					},
					error:function(XMLHttpRequest, textStatus, errorThrown){
						alert(textStatus);
					}
				});
				return false;
			}
	</script>
<div data-role="page" id="album-list" >

	<div data-role="header" data-position="fixed" data-theme="b">
		<a href='index.php'  data-role="button"><?php echo $_['btn_back']?></a>
		<h1><?php echo $bdName?></h1>
		<a  data-role="button" data-ajax="false" onClick="return skipPost()"><?php echo $_['text_postTopic'];?></a>
	</div>
	
	
	<div data-role="content">
		
		<div data-role="controlgroup" data-type="horizontal" >
			<a href="board.php?key=good&amp;bd=<?php echo $bd?>" data-ajax='false' data-role="button" <?php If($key=="good") echo "data-theme='b'"?> ><?php echo $_['text_good'];?></a>
			<a href="board.php?bd=<?php echo $bd?>" data-ajax='false' data-role="button" <?php If(empty($key)) echo "data-theme='b'"?>><?php echo $_['text_all'];?></a>
			
			<?php if($bdCheck=="1" && ($userGroup || $manager)) echo " <a href='topicchecklist.php?bd=".$bd."' data-role='button'>".$_['text_check']."</a>";?>
		</div>
		
		<ul data-role="listview" data-theme="d"  data-inset="true">

		<?php
			if (empty($key)){
				$page=(empty($_GET['page']))?"":$_GET['page'];
				if (empty($page)||!is_numeric($page))$page=1;
				If($page==1){
					//总置顶帖子
					$allTop=$topic->getAllTopTopic3g_r();
					//置顶帖子
					$top=$topic->getTopTopic3g($bd);
				}
				//查询平常帖子
				$pagesize=15;
				$startRow=0;
				$startRow=($page-1)*$pagesize;
				$rscount=$topic->getTopicCount($bd,0);
				if ($rscount%$pagesize==0)
					$pagecount=$rscount/$pagesize;
				else
					$pagecount=ceil($rscount/$pagesize);
				$topicList=$topic->getTopic3g($bd,0,$startRow,$pagesize,$page);
				
			
			}else{   //精华帖
				$page=(empty($_GET['page']))?"":$_GET['page'];
				if (empty($page)||!is_numeric($page))$page=1;
				$pagesize=15;
				$startRow=0;
				$startRow=($page-1)*$pagesize;
				$rscount=$topic->getTopicCount($bd,'',0,1);
				if ($rscount%$pagesize==0)
					$pagecount=$rscount/$pagesize;
				else
					$pagecount=ceil($rscount/$pagesize);
				$topicList=$topic->getTopic3g($bd,'',$startRow,$pagesize,$page,$key,'topic_updatetime','desc','0',1,$keyword='');
				
			}
		
		?>
		</ul>
		<?php 
			if (empty($key)){
				if ($pagecount>1){

					echo showPage2('board.php?bd='.$bd,$page,$pagesize,$rscount,$pagecount);
				}
			}else{
				if ($pagecount>1){
					echo showPage2('board.php?key='.$key.'&amp;bd='.$bd,$page,$pagesize,$rscount,$pagecount);
				}
			}
		?>
		
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

