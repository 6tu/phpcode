<?php

/**
 * useredit.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/useredit.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	$header_title=$_['text_editStuff'];
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo3g($_['text_editStuff'],'login.php');
	}
	$header_title=$_['text_editStuff'];
	require_once('htmltop.php');
	$user=$wiibbsUser->getUserByAccount();
?>
<body> 
<script type="text/javascript">
	function jqmSimpleMessage(message) {
		$("<div class='ui-loader ui-overlay-shadow ui-body-b ui-corner-all'><h1>" + message + "</h1></div>")
			.css({
				display: "block",
				opacity: 0.96,
				top: window.pageYOffset+100
			})
			.appendTo("body").delay(800)
			.fadeOut(400, function(){
				$(this).remove();
			});
	}
	$(document).ready(function(){
		$("#submit").click(function(){
			var nikename=$("#nikename").val();
			var name=$("#name").val();
			var email=$("#email").val();
			var sex=$("input[name='sex']:checked").val();
			var province=$("#province").val();
			var city=$("#city").val();
			var address=$("#address").val();
			var brith=$("#brith").val();
			var qq=$("#qq").val();
			var mobile=$("#mobile").val();
			var sina=$("#sina").val();
			
			$.ajax({
				url:"user_do.php",
				type:'get',
				data:{
					'nikename':nikename,
					'name':name,
					'email':email,
					'sex':sex,
					'province':province,
					'city':city,
					'address':address,
					'brith':brith,
					'qq':qq,
					'mobile':mobile,
					'sina':sina,
					'act':'edit'
					
				},
				success:function(rt){
					if (rt=="A"){
						jqmSimpleMessage('<?php echo $_['tip_nikenameExists'];?>');
						
					}else if (rt=="B"){
						jqmSimpleMessage('<?php echo $_['tip_emailFormat'];?>');
					}else if (rt=="C"){
						jqmSimpleMessage('<?php echo $_['tip_emailExists'];?>');
					}else if (rt=="D"){
						jqmSimpleMessage('<?php echo $_['tip_mobileFormat'];?>');
					}else if (rt=="F"){
						jqmSimpleMessage('<?php echo $_['tip_mobileExists'];?>');
					}else if (rt=="S"){
						jqmSimpleMessage('<?php echo $_['suc_editUser'];?>');
					}else{
						jqmSimpleMessage('<?php echo $_['error_editUser'];?>');
					}
				}
			});
			return false;
		});
	});
</script>

<div data-role="page" id="album-list">

	<div data-role="header" data-position="fixed" data-theme="b">
		<a href="index.html" data-rel="back"><?php echo $_['btn_goback'];?></a>
		<h1><?php echo $_['text_editStuff'];?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext"></a>
	</div>
	<div data-role="content">
		<form   data-ajax="false" >
			<div data-role="fieldcontain">
				<label for="nikename"><?php echo $_['text_nikeName'];?>：</label>
				<input type="text" name="nikename" id="nikename"  value='<?php echo $user['user_nickname']?>'/>
			</div>
			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_name'];?>：</label>
				<input type="text" name="name" id="name" value="<?php echo $user['user_name']?>"  />
			</div>

			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_email'];?>：</label>
				<input type="text" name="email" id="email" value="<?php echo $user['user_email']?>"  />
			</div>

			<div data-role="fieldcontain">
				<fieldset data-role="controlgroup" data-type="horizontal">
					<label for="name"><?php echo $_['text_sex'];?>：</label>
						<input type="radio" name="sex"  id="radio-view-a" value="1"  <?php if($user['user_sex']==1){ echo "checked='checkde'";}?>/>
						<label for="radio-view-a"><?php echo $_['text_man'];?></label>

						<input type="radio" name="sex" id="radio-view-b" value="2"  <?php if($user['user_sex']==2){ echo "checked='checkde'";}?>/>
						<label for="radio-view-b"><?php echo $_['text_women'];?></label>
				</fieldset>
			</div>

			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_province'];?>：</label>
				<input type="text" name="province" id="province" value="<?php echo $user['user_province']?>"  />
			</div>

			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_city'];?>：</label>
				<input type="text" name="city" id="city" value="<?php echo $user['user_city']?>"  />
			</div>

			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_address'];?>：</label>
				<input type="text" name="address" id="address" value="<?php echo $user['user_address']?>"  />
			</div>

			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_brith'];?>：</label>
				<input type="text" name="brith" id="brith" value="<?php echo $user['user_birthday']?>"  />
			</div>

			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_qq'];?>：</label>
				<input type="text" name="qq" id="qq" value="<?php echo $user['user_qq']?>"  />
			</div>

			
			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_mobile'];?>：</label>
				<input type="text" name="mobile" id="mobile" value="<?php echo $user['user_mobile']?>"  />
			</div>

			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_sina'];?>：</label>
				<input type="text" name="sina" id="sina" value="<?php echo $user['user_sina']?>"  />
			</div>
			
			<div data-role="fieldcontain">
				<label for="name">&nbsp;</label>
				<input type="submit" data-inline="true" value="<?php echo $_['btn_submit']?>" data-theme="b" id="submit">
			</div>
		
		</form> 
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

