<?php

/**
 * topicdo.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

define('THISPATHROOT', str_replace('ui/3g/topicdo.php', '', str_replace('\\', '/', __FILE__)));
require_once(THISPATHROOT.'include/db_conn.php');
$session->data['setUrl']=getUrl();
require_once('usercheck.php');
require_once('checklogin.php');
$action=sqlReplace(trim($_GET["do"]));
$rcode=intval(rand()*1000);
switch($action){
	case "check":
		$id=trim($_GET["id"]);
		$id=intval($id);
		$result=$topic->checkTopic($id);
		if($result)
		{
			header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=133&bd=".$bd);
			exit;
		}else{
			header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=134&bd=".$bd);
			exit;
		}
	break;
	case "edit":
		$id=sqlReplace(Trim($_GET["id"]));
		$id=intval($id);
		$title=sqlReplace(Trim($_POST["title"]));
		$content=HTMLEncode($_POST["content"]);
		$sina=empty($_POST["sina"])?'':sqlReplace(Trim($_POST["sina"]));
		if (SITEFILTER!=''){
		$filter=str_replace("，",',',SITEFILTER);
		$filters=explode(",",$filter);
		for($i=0;$i<count($filters);$i++)
		{
			if(strpos($title.$content,$filters[$i])>-1)
			{
				header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=109&bd=".$bd."&id=".$id);
				exit;
			}
		}
	}	
		if(empty($title)||empty($content)){
			header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=110&bd=".$bd."&id=".$id);
			exit;
		}
		$f_name=$_FILES['file']['name'];
		$f_name_1=$_FILES['file']['name'];
		$f_size=$_FILES['file']['size'];
		$f_tmpName=$_FILES['file']['tmp_name'];
		$filename="";
		if(!empty($f_name))
		{	
			$f_ext=strtolower(preg_replace('/.*\.(.*[^\.].*)*/iU','\\1',$f_name));
			$f_exts=explode("|",attachType);
			$checkExt=false;
			foreach ($f_exts as $v)
				if ($f_ext==$v){
				$checkExt=true;
				break;
				}
			if (!$checkExt) die ($_['alert_type1'].attachType.$_['alert_type2']."。【<a href='topicedit.php?bd=".$bd."&amp;id=".$id."'>".$_['btn_goback']."</a>】");
			if ($f_size>attachSize*1024) die ($_['alert_type3'].attachSize."k。【<a href='topicedit.php?bd=".$bd."&amp;id=".$id."'>".$_['btn_goback']."</a>】");

			$date=date('YmdHis');
			$f_name=$date.".".$f_ext;
			$filename=ROOT_PATH."userfiles/attach/".$f_name;
			if(file_exists($filename))
			{
				$filename=ROOT_PATH."userfiles/attach/".rand().$f_name;
			}
			@copy($f_tmpName,$filename);
			if($f_ext=='jpg'){
				$newfilename=ROOT_PATH."userfiles/high/".$f_name;
				$t = new ThumbHandler();
				$t->setSrcImg($filename);
				$t->setDstImg($newfilename);
				$t->createImg(320,480);
				$newfilename=ROOT_PATH."userfiles/small/".$f_name;
				$t = new ThumbHandler();
				$t->setSrcImg($filename);
				$t->setDstImg($newfilename);
				$t->createImg(240,320);
				$newfilename=ROOT_PATH."userfiles/smaller/".$f_name;
				$t = new ThumbHandler();
				$t->setSrcImg($filename);
				$t->setDstImg($newfilename);
				$t->createImg(128,160);
			}
		}
		$data=array(
		'topicID'=>$id,
		'title'=>$title,
		'content'=>$content,
		'wiibbsUser'=>$userName,
		'bd'=>$bd,
		'upload'=>$f_name,
		'type'=>$f_ext,
		'fileName'=>str_replace(".".$f_ext,'',$f_name_1),
		'fileSize'=>$f_size
		);
		$result=$topic->editTopic($data);
		if($result){
			if (!empty($sina)){
				
					$url=NETURL."/ui/color/topicshow.php?bd=".$bd."&id=".$id;
					$share=$title;
					echo "<script type='text/javascript'>";
					echo "window.open('http://v.t.sina.com.cn/share/share.php?title='+encodeURIComponent('".$share."')+'&amp;url='+encodeURIComponent('".$url."')+'&amp;source=bbs','_blank','width=450,height=400');";
					echo  "</script>";
			}
			header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=112&bd=".$bd."&id=".$id);
			exit;
		}else{
			header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=147&bd=".$bd."&id=".$id);
			exit;
		}
		break;
	case "del":
		$id=sqlReplace(Trim($_GET["id"]));
		$id=intval($id);
		$t=empty($_GET["t"])?'':sqlReplace(Trim($_GET["t"]));
		header("location:".NETURL."/ui/".$folder_color."/topicdeal.php?act=del&bd=".$bd."&id=".$id."&t=".$t);
		exit();
	break;
	case "top":
		If($manager || $userGroup){
			$id=sqlReplace(Trim($_GET["id"]));
			$id=intval($id);
			$result=$topic->setTopTopic($id,$bd);
			If($result){
				header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=120&bd=".$bd."&id=".$id);
				exit;
			}else{
				header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=121&bd=".$bd."&id=".$id);
				exit;
			}
			
		}Else{
			header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=122&bd=".$bd."&id=".$id);
			exit;
		}
		break;
	case "ctop":
		If($manager || $userGroup){
			$id=sqlReplace(Trim($_GET["id"]));
			$id=intval($id);
			$result=$topic->cancelTopTopic($id,$bd);
			If($result){
				header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=123&bd=".$bd."&id=".$id);
				exit;
			}else{
				header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=124&bd=".$bd."&id=".$id);
				exit;
			}
		}Else{
			header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=125&bd=".$bd."&id=".$id);
			exit;
		}
		break;
	case "topAll":
		If($manager){
			$id=sqlReplace(Trim($_GET["id"]));
			$id=intval($id);
			$result=$topic->setAllTopTopic($id,$bd);
			If($result){
				header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=123&bd=".$bd."&id=".$id);
				exit;
			}else{
				header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=124&bd=".$bd."&id=".$id);
				exit;
			}
		}Else{
			header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=125&bd=".$bd."&id=".$id);
			exit;
		}
		break;
	case "ctopAll":
		If($manager){
			$id=sqlReplace(Trim($_GET["id"]));
			$id=intval($id);
			$result=$topic->cancelAllTopTopic($id,$bd);
			If($result){
				header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=123&bd=".$bd."&id=".$id);
				exit;
			}else{
				header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=124&bd=".$bd."&id=".$id);
				exit;
			}
		}Else{
			header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=125&bd=".$bd."&id=".$id);
			exit;
		}
		break;
	case "lock":
		If($manager || $userGroup){
			$id=sqlReplace(Trim($_GET["id"]));
			$id=intval($id);
			$result=$topic->lockTopic($id,$bd);
			If($result){
				header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=123&bd=".$bd."&id=".$id);
				exit;
			}else{
				header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=124&bd=".$bd."&id=".$id);
				exit;
			}
		}Else{
			header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=125&bd=".$bd."&id=".$id);
			exit;
		}
		break;
	case "clock":
		If($manager || $userGroup){
			$id=sqlReplace(Trim($_GET["id"]));
			$id=intval($id);
			$result=$topic->cancelLockTopic($id,$bd);
			If($result){
				header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=123&bd=".$bd."&id=".$id);
				exit;
			}else{
				header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=124&bd=".$bd."&id=".$id);
				exit;
			}
		}Else{
			header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=125&bd=".$bd."&id=".$id);
			exit;
		}
		break;
	case "hot":
		If($manager || $userGroup){
			$id=sqlReplace(Trim($_GET["id"]));
			$id=intval($id);
			$result=$topic->digestTopic($id,$bd);
			If($result){
				header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=123&bd=".$bd."&id=".$id);
				exit;
			}else{
				header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=124&bd=".$bd."&id=".$id);
				exit;alertInfo($_['alert_postFail'],'topicshow.php?bd='.$bd.'&amp;s='.$rcode.'&amp;id='.$id);
			}
		}Else{
			header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=125&bd=".$bd."&id=".$id);
			exit;
		}
		break;
	case "chot":
		If($manager || $userGroup){
			$id=sqlReplace(Trim($_GET["id"]));
			$id=intval($id);
			$result=$topic->cancelDigestTopic($id,$bd);
			If($result){
				header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=123&bd=".$bd."&id=".$id);
				exit;
			}else{
				header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=124&bd=".$bd."&id=".$id);
				exit;
			}
		}Else{
			header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=125&bd=".$bd."&id=".$id);
			exit;
		}
		break;
	case "move":
		$bd = intval($_POST["bd"]);
		$oldbd = intval($_POST["oldbd"]);
		$id = sqlReplace(trim($_GET["id"]));
		If($bd == 0){
			header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=146&bd=".$bd."&id=".$id);
			exit;
		 }
		
		$topic->moveTopic($bd,$id);
		header("location:".NETURL."/ui/".$folder_3g."/topicdeal.php?act=move&bd=".$bd."&oldbd=".$oldbd);
		break;
	case 'doDel':
			$id=sqlReplace(Trim($_GET["id"]));
			$id=intval($id);
			$t=empty($_GET["t"])?'':sqlReplace(Trim($_GET["t"]));
			if (empty($t)){
				$url='topicshow.php';
				$url_1='board.php';
			}else{
				$url='topiccheck.php';
				$url_1='topicchecklist.php';
			}
			$result=$topic->delTopic($id,$bd,$manager,$userGroup,$userName);
			if ($result==1){
				if (empty($t)){
					header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=100&bd=".$bd."&id=".$id);
					exit;
				}else{
					header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=101&bd=".$bd."&id=".$id);
					exit;
				}
			}else if ($result==2){
				header("location:".NETURL."/ui/".$folder_3g."/".$url_1."?bd=".$bd);
				exit();
			}else if ($result==4){
				if (empty($t)){
					header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=104&bd=".$bd."&id=".$id);
					exit;
				}else{
					header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=105&bd=".$bd."&id=".$id);
					exit;
				}
			}
		break;
		case 'doDelReply':
			$id=sqlReplace(Trim($_GET["id"]));
			$rid=sqlReplace(Trim($_GET["rid"]));
			$key=sqlReplace(Trim($_GET["key"]));
			
			$url='topicreplylist.php';
			$result=$topic->delReply($id,$bd,$rid,$manager,$userGroup,$userName);
			if ($result==1){
				header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=106&bd=".$bd."&id=".$id);
				exit;
				
			}else if ($result==2){
				header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=107&bd=".$bd."&id=".$id);
				exit;
			}else if ($result==4){
				header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=108&bd=".$bd."&id=".$id);
				exit;
			}
		break;

}
?>