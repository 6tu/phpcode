<?php

/**
 * msg_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/3g/msg_do.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(THISPATHROOT.'include/lib/msg_wiipu.php');
	
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo3g3g($_['tip_returnlogin'],'login.php');
	}
	$act=sqlReplace(trim($_GET['act']));
	$msg=new Msg($registry);
	switch($act)
	{
		case 'add':
			$arr['msg_received']=sqlReplace(trim($_GET['receiver']));
			$arr['msg_title']=sqlReplace(trim($_GET['title']));
			$arr['msg_content']=sqlReplace(trim($_GET['content']));
			if(!$wiibbsUser->checkAccount($arr['msg_received']))
			{
				echo "N";
				exit;
			}
			if($arr['msg_received']==$session->data[WiiBBS_ID."wiibbsUser"])
			{
				echo "M";
				exit;
			}
			$msg->addInbox($arr);
			$msg->addOutbox($arr);
			$title="���µ�վ����";
			$url='';
			$funcSysten->sendNotice($title,$url,$arr['msg_received'],'2');
			echo "S";
			exit;
			break;
		case 'del':
			$id=sqlReplace(trim($_GET['id']));
			$msg->deletMsgById($id);
			echo "S";
			break;
		case 'reply':
			$arr['msg_received']=sqlReplace(trim($_GET['receiver']));
			$arr['msg_title']=sqlReplace(trim($_GET['title']));
			$arr['msg_content']=sqlReplace(trim($_GET['content']));
			$msg->addInbox($arr);
			$msg->addOutbox($arr);
			echo "S";
			break;

	}
?>