<?php

/**
 * topicreplylistmore.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/topicreplylistmore.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(THISPATHROOT.'include/lib/ubb_common.php');
	require_once(THISPATHROOT.'include/lib/image_common.php');
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	If(empty($userName)){
		If($bdType!=4){
			require_once('checklogin.php');
		} 
	}
	$id=sqlReplace(trim($_GET["id"]));
	$row=$topic->getTopicByID_BD($id,$bd);
	If(!$row){
		header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=102");
		exit;
	}Else{
		$topicLock=$row["topic_islock"];
		$topicTitle=$row["topic_title"];
	}
	$header_title=$_['text_comment'].$topicTitle;
	require_once('htmltop.php');
?>
<body> 
<script type="text/javascript">
 function jqmSimpleMessage(message) {
		$("<div class='ui-loader ui-overlay-shadow ui-body-b ui-corner-all'><h1>" + message + "</h1></div>")
			.css({
				display: "block",
				opacity: 0.96,
				top: window.pageYOffset+100
			})
			.appendTo("body").delay(800)
			.fadeOut(400, function(){
				$(this).remove();
			});
	}
	
		function skipReply(){	
			$.ajax({
				url:"checklogin3g.php",
				type:'get',
					data:{
						bd:<?php echo $bd;?>
					},
				success:function(rt){
					if (rt=="E"){
						jqmSimpleMessage('<?php echo $_['tip_returnlogin'];?>');
					
					}else{
						userCheck();
					}
				},
				error:function(XMLHttpRequest, textStatus, errorThrown){
					alert(XMLHttpRequest+"D");
				}
			});
			return false;
			
		}


	function userCheck(){
				$.ajax({
					url:"usercheck3g.php",
					type:'get',
					data:{
						bd:<?php echo $bd;?>
					},
					success:function(rt){
						if (rt=="A"){
							jqmSimpleMessage('<?php echo $_['alert_noNEW'];?>');
						}else if (rt=="B"){
							jqmSimpleMessage('<?php echo $_['alert_boardLogin'];?>');
						}else if (rt=="C"){
							jqmSimpleMessage('<?php echo $_['alert_noLimit'];?>');
							
						}else if (rt=="D"){
							jqmSimpleMessage('<?php echo $_['alert_noLimit'];?>');
						}else if (rt=="F"){
							jqmSimpleMessage('<?php echo $_['alert_noLimit'];?>');
						}else{
							location.href='topicreplyadd.php?bd=<?php echo $bd?>&id=<?php echo $id?>';
						}
					},
					error:function(XMLHttpRequest, textStatus, errorThrown){
						alert(textStatus);
					}
				});
				return false;
			}
			function delReply(id){
			if(confirm('确定删除吗？')){
				$.ajax({
					url:"topicreplydoajax.php",
					type:'get',
					data:{
						'rid':id,
						'id':<?php echo $id?>,
						'bd':<?php echo $bd;?>,
						'act':'del'
					},
					success:function(rt){
						if (rt==1){
							jqmSimpleMessage('<?php echo $_['alert_noLimit'];?>');
							
						}else if (rt==2){
							jqmSimpleMessage('<?php echo $_['alert_postdel'];?>');
							location.reload();
						}else if (rt==4){
							jqmSimpleMessage('<?php echo $_['alert_errordel'];?>');
						}
					},error:function(rt){
						alert(rt);
					}
				});
				return false;
			}
		}
	</script>
<div data-role="page" id="album-list">

	<div data-role="header" data-position="fixed" data-theme="b">
		<a href="board.php?bd=<?php echo $bd?>" data-ajax='false' data-role="button"><?php echo $_['text_topicList']?></a>
		<h1><?php echo $_['text_replyList']?></h1>
		<a   data-role="button" data-ajax="false"  onClick="skipReply()"><?php echo $_['text_comment']?></a>
	</div>
	<div data-role="content">
		<ul data-role="listview" data-inset="true" data-theme="c" data-split-theme="d" data-split-icon="delete">
		<?php
				$page=(empty($_GET['page']))?"":$_GET['page'];
				if (empty($page)||!is_numeric($page))$page=1;
				
				//查询平常帖子
				$pagesize=15;
				$startRow=0;
				$startRow=($page-1)*$pagesize;
				$rscount=$topic->getTopicReplyCount($bd,$id);
				if ($rscount%$pagesize==0)
					$pagecount=$rscount/$pagesize;
				else
					$pagecount=ceil($rscount/$pagesize);
				$replyList=$topic->getTopicReplyList($bd,$id,$startRow,$pagesize,'reply_id','desc');
				foreach($replyList as $row){
					echo "<li data-theme=\"b\" data-icon=\"delete\">";
					If($row["reply_user"]!="Guest"){
						$userRow=$wiibbsUser->getUserByAccount($row["reply_user"]);
						$petName=$userRow['user_nickname'];
						if (!empty($petName))
							$replyUser=$petName;
						else
							$replyUser=$row["reply_user"];
						echo "<a href=\"user.php?id=".$row["reply_user"]."&amp;url=".urlencode($funcSysten->getUrl())."\" >".$replyUser." ";
					}else{
						echo "<a>".$row["reply_user"]." ";
					}
					echo $_['text_write'].$row["reply_posttime"]."</a>";
					If($row["reply_user"]==$userName || $manager || $userGroup)
						echo " <a href='javascript:void(0);' onClick='return delReply(".$row["reply_id"].")' data-role=\"button\" data-rel=\"dialog\" data-transition=\"slidedown\">del</a>";
					//读取到的内容转换成图片
					echo "</li>";
					$content=$row["reply_content"];
					/*
					if(SITEEXPRESS=="1"){
						for($j=1;$j<16;$j++)
						{
							$content=str_replace(ImageEncode($j),ImageDecode(ImageEncode($j)),$content);
						}
					}
					*/
					if(SITEUBB=="1")
					{
						$ubbcode = new UBBCode();
						$content=$ubbcode->encode($content); 
					}
					echo "<li>".$content."</li>" ;
					
					$fileList=$topic->getFileListByID(1,$row["reply_id"]);
					if ($fileList){
						echo "<li>";
						foreach ($fileList as $row){
							$url2="id=".$id."&amp;page=".$page."&amp;bd=".$bd;
							$funcSysten->downFile($row,$url2);
							
						}
						echo "</li>";
					}
				
			}
			
		?>
		</ul>
	<?php
			if ($pagecount>1){
					echo showPage2('topicreplylistmore.php?bd='.$bd.'&amp;id='.$id,$page,$pagesize,$rscount,$pagecount);
			}
	?>
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

