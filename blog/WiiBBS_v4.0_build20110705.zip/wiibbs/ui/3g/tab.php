<?php

/**
 * tab.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

?>
<div data-role="controlgroup" data-type="horizontal" >
			<a href="index.php" data-role="button" <?php If($POSITION_INDEX=="on") echo "data-theme='b'"?>><?php echo $_['text_index'];?></a>
			<a href="hot.php" data-role="button" <?php If($POSITION_HOT=="on") echo "data-theme='b'"?>><?php echo $_['text_hotTopic'];?></a>
			<a href="boardlist.php" data-role="button" <?php if ($POSITION_BOARD=="on") echo "data-theme='b'";?>><?php echo $_['text_board'];?></a> 
			
		</div>
