<?php

/**
 * usergetpw.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/usergetpw.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	
	$header_title=$_['text_forgetPwd'];
	require_once('htmltop.php');
?>
<body> 
<script type="text/javascript">
	function jqmSimpleMessage(message) {
		$("<div class='ui-loader ui-overlay-shadow ui-body-b ui-corner-all'><h1>" + message + "</h1></div>")
			.css({
				display: "block",
				opacity: 0.96,
				top: window.pageYOffset+100
			})
			.appendTo("body").delay(800)
			.fadeOut(1500, function(){
				$(this).remove();
			});
	}
	$(document).ready(function(){
		$("#submit").click(function(){
			var name=$("#name").val();
			var email=$("#email").val();
			if (name==''){ 
				jqmSimpleMessage('<?php echo $_['alert_account']?>');
				$("#name").focus();
				return false;
			}
			if (email==''){
				jqmSimpleMessage('<?php echo $_['alert_email_null'];?>');
				$("#email").focus();
				return false;
			}else{
				var reg =  /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+((\.[a-zA-Z0-9_-]{2,3}){1,2})$/;
				if(!reg.test(email)){
					jqmSimpleMessage('<?php echo $_['alert_email_error'];?>');
					$("#email").focus();
					return false;
				}
			}	
			$.ajax({
				url:"usergetpw_do.php",
				type:'post',
				data:{
					account:name,
					email:email,
					act:'step1'
				},
				success:function(rt){
					if (rt=="S"){
						jqmSimpleMessage('<?php echo $_['suc_forgetPw1'];?>');
						
					}else if (rt=="E"){
						jqmSimpleMessage('<?php echo $_['tip_exception'];?>');
					}else if (rt=="F"){
						jqmSimpleMessage('<?php echo $_['error_forgetPw1'];?>');
					}else if (rt=="M"){
						jqmSimpleMessage('<?php echo $_['alert_not_Findpwd'];?>');
					}else if (rt=="T"){
						jqmSimpleMessage('<?php echo $_['alert_fail_sendEmail'];?>');
					}
				}
			});
			return false;
		});
	});
</script>
<div data-role="page" id="album-list">

	<div data-role="header" data-position="fixed" data-theme="b">
		<a href="index.html" data-rel="back"><?php echo $_['btn_goback'];?></a>
		<h1><?php echo $_['text_forgetPwd']?></h1>
		<a href="register.php" data-icon="arrow-r" data-iconpos="right" data-ajax="false"><?php echo $_['btn_register'];?></a>
	</div>
	<div data-role="content">
		<form action="usergetpw_do.php?act=step1" method="post" data-ajax="false">
			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_account'];?>：</label>
				<input type="text" name="account" id="name" />
			</div>
			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_email'];?>：</label>
				<input type="text" name="email" id="email" />
			</div>
			<div data-role="fieldcontain">
				<label for="name"> </label>
				<input type="submit" data-theme="b" data-inline="true" value="<?php echo $_['btn_submit']?>" id="submit"/>
			</div>
		
		</form> 
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>
