<?php

/**
 * stat.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/stat.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/applications.php');
	$header_title=$_['text_Lcount'];
	require_once('htmltop.php');
	require_once(THISPATHROOT.'include/lib/stat_wiipu.php');
	if(SITECOUNT!=1)
	{
		header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=144");
		exit;
	}
	$stat=new wiiStat($registry);
?>
<body> 
<div data-role="page" id="album-list">

	<div data-role="header" data-position="fixed" data-theme="b">
		<a href="more.php" data-rel="back"><?php echo $_['btn_back']?></a>
		<h1>统计</h1>
		<a href="index.php" data-icon="home" data-iconpos="notext">home</a>
	</div>
	<div data-role="content">
		
		<ul data-role="listview" data-inset="true" data-theme="d">
				<li><?php echo $_['text_online'];?>：</span><?php echo $stat->getOnlineCount();?></li>
				<li><?php echo $_['text_todayFlow'];?>：<?php echo $stat->getTodayCount();?> </li>
				<li><?php echo $_['text_allFlow'];?>：<?php echo $stat->getAllCount();?></li>
		</ul>
		<ul data-role="listview" data-inset="true" data-theme="d">
				<li><?php echo $_['text_memberCount'];?>：<?php echo $stat->getMemberCount();?></li>

				<li><?php echo $_['text_topicCount'];?>：</span><?php echo $stat->getTopicCount();?> </li>
				<li><?php echo $_['text_cenusCount'];?>：</span><?php echo $stat->getCensusCount();?></li>
		</ul>
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
</div><!-- /page -->
</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>


