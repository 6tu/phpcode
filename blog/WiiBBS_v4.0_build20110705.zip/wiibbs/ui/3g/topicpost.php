<?php

/**
 * topicpost.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/3g/topicpost.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	If($bdType!=4){
	  require_once('checklogin.php');
	  if ($bdType==6){  //检查咨询版面的权限
		if (!$manager){
			header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=111&bd=".$bd);
			exit;
		}
	  }
	}
	$header_title=$_['text_postTopic'];
	require_once('htmltop.php');
?>
<body> 
 <script type="text/javascript">
 function jqmSimpleMessage(message) {
		$("<div class='ui-loader ui-overlay-shadow ui-body-b ui-corner-all'><h1>" + message + "</h1></div>")
			.css({
				display: "block",
				opacity: 0.96,
				top: window.pageYOffset+100
			})
			.appendTo("body").delay(800)
			.fadeOut(400, function(){
				$(this).remove();
			});
	}
	function ajaxFileUpload()
	{
		$("#loading")
		.ajaxStart(function(){
			$(this).show();
		})
		.ajaxComplete(function(){
			$(this).hide();
		});

		$.ajaxFileUpload
		(
			{
				url:'flash_picup.php',
				secureuri:false,
				fileElementId:'fileToUpload',
				dataType: 'json',
				data:{name:'logan', id:'id'},
				success: function (data, status)
				{
					data=data.replace('<pre>','');
					data=data.replace('</pre>','');
					var info=data.split('||');
					if(info[0]=="E")
						jqmSimpleMessage(info[1]);
					else{
						$("#titleLeft").html('<?php echo $_['text_fileUp']?>:');
						document.getElementById('upinfo').innerHTML=info[5];
						document.getElementById('upfile').value=info[5];
						$("#f_size").val(info[4]);
						$("#f_ext").val(info[2]);
						$("#f_name").val(info[3]);
						jqmSimpleMessage("上传成功");
					}
				},
				error: function (data, status, e)
				{
					alert(e);
				}
			}
		)
		return false;
	}
	

	$(document).ready(function(){
		$("#submit").click(function(){
			var content=$("#content").val();
			var title=$("#title").val();
			var up=$("#isUP").val();
			var file;
			var f_ext;
			var f_size,f_name;
			if (up==1){
			 f_name=$("#f_name").val();
			 file=$("#upfile").val();
			 f_ext=$("#f_ext").val();
			 f_size=$("#f_size").val();
			 f_name=$("#f_name").val();
			}
			if (title==''){
				jqmSimpleMessage('<?php echo $_['alert_titleNull']?>');
				$("#title").focus();
				return false;
			}
			if (content==''){ 
				jqmSimpleMessage('<?php echo $_['alert_contentNull_r']?>');
				return false;
			}
			
			$.ajax({
				url:"topicpostdo.php",
				type:'get',
				data:{
					'content':content,
					'file':file,
					title:title,
					'bd':<?php echo $bd?>,
					'f_ext':f_ext,
					'f_size':f_size,
					'f_name':f_name
				},
				success:function(rt){
					if (rt=="F"){
						jqmSimpleMessage('<?php echo $_['alert_filter'];?>');
					}else if (rt=="1"){
						jqmSimpleMessage('<?php echo $_['alert_repeatPost'];?>');
					}else if (rt==2){
						jqmSimpleMessage('<?php echo $_['alert_postSucc'];?>');
						location.href='board.php?bd=<?php echo $bd;?>';
					
					}else{
						jqmSimpleMessage('<?php echo $_['alert_postFail'];?>');
					}
				},
				error:function(XMLHttpRequest, textStatus, errorThrown){
					alert(textStatus);
				}
			});
			return false;
		});
	});
	</script>
<div data-role="page" id="album-list">

	<div data-role="header" data-position="fixed" data-theme="b">
		<a href="index.html" data-rel="back"><?php echo $_['btn_back']?></a>
		<h1><?php echo $_['text_postTopic']?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext">home</a>
	</div>
	<div data-role="content">
		<form method="post" enctype="multipart/form-data" data-ajax="false">
			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_topicTitle']?>:</label>
				<input type="text" name="title" id="title" value="" />
			</div>

			<div data-role="fieldcontain">
				<label for="textarea"><?php echo $_['text_topicContent']?>:</label>
				<textarea cols="40" rows="8" name="content" id="content"></textarea>

			</div><input id="isUP"  value="<?php echo $upload;?>" type="hidden" />
			<?php
					if($upload==1)
					{
				?>	
					<div data-role="fieldcontain">
						<label for="name" id="titleLeft"></label>
						<span id="upinfo" style="color:blue;"></span><input id="upfile" name="upfile" value="" type="hidden" /><input id="f_ext"  value="" type="hidden" /><input id="f_size"  value="" type="hidden" /><input id="f_name"  value="" type="hidden" /> 

					</div>
				<?php
					}
				?>
				<!--
			<div data-role="fieldcontain">
				<fieldset data-role="controlgroup">
					<legend>&nbsp;</legend>
					<input type="checkbox" name="sina" id="checkbox-1" class="custom" value="1" />
					<label for="checkbox-1"><?php echo $_['text_topictoSina']?></label>
				</fieldset>
			</div>
			-->
			<div data-role="fieldcontain">
				<label for="textarea">&nbsp;</label>
				<?php
					if($upload==1)
					{
				?>	
				<a href="topicupload.php" data-role="button" data-rel="dialog"  data-inline="true" ><?php echo $_['text_upload_file'];?></a>
				<?php
					}
				?>
				<input type="submit" data-theme="b" data-inline="true" value="<?php echo $_['btn_do']?>" id="submit">

			</div>
		
		</form> 
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

