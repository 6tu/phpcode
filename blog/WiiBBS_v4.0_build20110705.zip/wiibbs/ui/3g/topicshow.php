<?php

/**
 * topicshow.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/3g/topicshow.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(THISPATHROOT.'include/lib/ubb_common.php');
	require_once(THISPATHROOT.'include/lib/image_common.php');
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	$id=sqlReplace(Trim($_GET["id"]));
	$key = (empty($_GET["key"]))?"":$_GET['key'];
	$t = (empty($_GET["t"]))?"":$_GET['t'];  
	if (!empty($t)) $noticeClass->updateNoticeState(1);
	$id=intval($id);
	$url="id=".$id."&amp;bd=".$bd;
	
	$row=$topic->getTopicByID_BD($id,$bd);
	If(!$row){
		header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=102");
		exit;
	}Else{
		$title=$row["topic_title"];
		$content=HTMLDecode($row["topic_content"]);
		$view=$row["topic_viewcount"]+1;
		$addTime=$row["topic_posttime"];
		$editTime=$row["topic_edittime"];
		$reCount=$row["topic_recount"];
		$isLock=$row["topic_islock"];
		$isTop=$row["topic_istop"];
		$poster=$row["topic_user"];
		$isGood = $row["topic_isgood"];
	}
	//判断权限
	$myself=false;
	If ($poster==$userName && $poster!='Guest')  $myself=true;
	$header_title=$title;
	require_once('htmltop.php');
	if ($poster!='Guest'){
		$userRow=$wiibbsUser->getUserByAccount($poster);
		$petName=$userRow['user_nickname'];
	}
?>
<body> 
<script type="text/javascript">
 function jqmSimpleMessage(message) {
		$("<div class='ui-loader ui-overlay-shadow ui-body-b ui-corner-all'><h1>" + message + "</h1></div>")
			.css({
				display: "block",
				opacity: 0.96,
				top: window.pageYOffset+100
			})
			.appendTo("body").delay(800)
			.fadeOut(400, function(){
				$(this).remove();
			});
	}
	


		function skipReply(){	
			$.ajax({
				url:"checklogin3g.php",
				type:'get',
					data:{
						bd:<?php echo $bd;?>
					},
				success:function(rt){
					if (rt=="E"){
						jqmSimpleMessage('<?php echo $_['tip_returnlogin'];?>');
					
					}else{
						userCheck();
					}
				},
				error:function(XMLHttpRequest, textStatus, errorThrown){
					alert(XMLHttpRequest+"D");
				}
			});
			return false;
			
		}


	function userCheck(){
				$.ajax({
					url:"usercheck3g.php",
					type:'get',
					data:{
						bd:<?php echo $bd;?>
					},
					success:function(rt){
						if (rt=="A"){
							jqmSimpleMessage('<?php echo $_['alert_noNEW'];?>');
						}else if (rt=="B"){
							jqmSimpleMessage('<?php echo $_['alert_boardLogin'];?>');
						}else if (rt=="C"){
							jqmSimpleMessage('<?php echo $_['alert_noLimit'];?>');
							
						}else if (rt=="D"){
							jqmSimpleMessage('<?php echo $_['alert_noLimit'];?>');
						}else if (rt=="F"){
							jqmSimpleMessage('<?php echo $_['alert_noLimit'];?>');
						}else{
							location.href='topicreplyadd.php?bd=<?php echo $bd?>&id=<?php echo $id?>';
						}
					},
					error:function(XMLHttpRequest, textStatus, errorThrown){
						alert(textStatus);
					}
				});
				return false;
			}

			function skipReplyList(){	
			$.ajax({
				url:"checklogin3g.php",
				type:'get',
					data:{
						bd:<?php echo $bd;?>
					},
				success:function(rt){
					if (rt=="E"){
						jqmSimpleMessage('<?php echo $_['tip_returnlogin'];?>');
					
					}else{
						userCheckList();
					}
				},
				error:function(XMLHttpRequest, textStatus, errorThrown){
					alert(XMLHttpRequest+"D");
				}
			});
			return false;
			
		}


	function userCheckList(){
				$.ajax({
					url:"usercheck3g.php",
					type:'get',
					data:{
						bd:<?php echo $bd;?>
					},
					success:function(rt){
						if (rt=="A"){
							jqmSimpleMessage('<?php echo $_['alert_noNEW'];?>');
						}else if (rt=="B"){
							jqmSimpleMessage('<?php echo $_['alert_boardLogin'];?>');
						}else if (rt=="C"){
							jqmSimpleMessage('<?php echo $_['alert_noLimit'];?>');
							
						}else if (rt=="D"){
							jqmSimpleMessage('<?php echo $_['alert_noLimit'];?>');
						}else if (rt=="F"){
							jqmSimpleMessage('<?php echo $_['alert_noLimit'];?>');
						}else{
							location.href='topicreplylist.php?bd=<?php echo $bd?>&id=<?php echo $id?>';
						}
					},
					error:function(XMLHttpRequest, textStatus, errorThrown){
						alert(textStatus);
					}
				});
				return false;
			}
	</script>
<div data-role="page">

	<div data-role="header" data-position="fixed"  data-theme="b" >
		<a href="board.php?bd=<?php echo $bd?>" data-role="button" data-ajax='false'><?php echo $_['btn_back']?></a>
		<h1><?php echo $bdName;?></h1>
		<a data-role="button" data-ajax="false" onClick="skipReply()"><?php echo $_['text_comment'];?></a>
	</div>
	<div data-role="content">
			<h2><strong><?php echo $title?></strong></h2>
			<p><?php If($poster!="Guest"){?><a href="user.php?id=<?php echo $poster?>&amp;url=<?php echo urlencode($funcSysten->getUrl())?>" ><?php if (!empty($petName)) echo $petName;else echo $poster;?></a><?php }else{?><?php echo $poster?><?php }?><?php echo $_['text_write']?> <?php echo $addTime?></p>
		<?php
			
			//if (!empty($userName)){
				//if ($userName==$poster || $manager || $userGroup)
		?>
			     <!--
				  <p><a href="topicmanage.php?bd=<?php echo $bd?>&amp;id=<?php echo $id?>" data-role="button" data-inline="true" data-transition="slidedown"  data-rel="dialog"><?php echo $_['text_managerTopic'];?></a></p>
				  -->
				
		 <?php
			//}
			
			//帖子内容分页
			if(SITEUBB=="1")
				{
					$ubbcode = new UBBCode();
					$content=$ubbcode->encode($content); 
				}
			echo $content;
			$fileList=$topic->getFileListByID(0,$id);
			foreach ($fileList as $row){
				echo "<p>";
				$funcSysten->downFile($row,$url);
				echo "</p>";
				
			}
			?>
			<div data-role="controlgroup" data-type="horizontal" >
				<a  data-role="button" onClick="skipReplyList()"><?php echo $_['text_replyList'];?>（<?php echo $reCount?>）</a>
				<a  data-role="button"  id="skipReply" onClick="skipReply()"   data-ajax="false"><?php echo $_['text_quickReply'];?></a>
			</div>
			
		
	</div><!-- /content -->
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>


