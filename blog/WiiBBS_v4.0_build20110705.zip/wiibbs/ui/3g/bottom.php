<?php

/**
 * bottom.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

?>	<div data-role="footer" data-position="fixed">
		<div data-role="navbar">
			<ul data-theme="c">
				<?php if(empty($session->data[WiiBBS_ID."wiibbsUser"])){ ?>
				<li><a href="index.php"  data-theme="b"><?php echo $_['text_index'];?></a></li>
				<li><a href="login.php" data-theme="b"   data-ajax="false"><?php echo $_['text_login']?></a></li>
				<li><a href="register.php" data-theme="b" data-ajax="false"><?php echo $_['text_reg']?></a></li>
				
				<?php } else{?>
				<li><a href="index.php"  data-theme="b"><?php echo $_['text_index'];?></a></li>
				<li><a href="usercenter.php" data-theme="b"   data-ajax="false"><?php echo $_['text_userCenter']?></a></li>
				<?php
					$nCount=0;
					$row_r=$noticeClass->getNotice(1);
					if ($row_r){
						$replyCount=$row_r['notice_count'];
					}else{
						$replyCount=0;
					}
					$row_m=$noticeClass->getNotice(2);
					if ($row_m){
						$mailCount=$row_m['notice_count'];
					}else{
						$mailCount=0;
					}
					if ($replyCount>0) 
						$nCount="(".$replyCount.")";
					else if ($mailCount>0)
						$nCount="(".$mailCount.")";
				?>
				<li><a href="notice.php" data-theme="b"  ><?php echo $_['text_notice']?><?php if (!empty($nCount)) echo $nCount?></a></li>
				
				<?php } ?>
				<li><a href="more.php" data-theme="b"  ><?php echo $_['text_more']?></a></li>
			</ul>
		</div><!-- /navbar -->
	</div><!-- /footer -->