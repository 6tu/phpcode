<?php

/**
 * usergetpw_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/usergetpw_do.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(THISPATHROOT.'include/lib/mail_common.php');
	require_once(THISPATHROOT.'config.php');
	
	$act=sqlReplace(trim($_POST['act']));
	switch($act)
	{
		case 'step1':
		$account=sqlReplace(trim($_POST['account']));
		$email=sqlReplace(trim($_POST['email']));
		$result=$wiibbsUser->getPw($account,$email);

		switch($result)
		{
			case '1':
				$code=$wiibbsUser->setVerCode($account);
			
				if($code)
				{
					$mailcontent="<a href='".NETURL."/ui/3g/usergetpw2.php?account=".$account."&vercode=".$code."'>".$_['btn_clickhere']."</a>".$_['text_restpw'];
					$smtp=new smtp(MAILSMTP,25,true,MAILACCOUNT,MAILAPASSWORD,MAILADDRESS);
					$subject=$_['text_mailTile'];
					$body=$mailcontent;
					$mailtype='HTML';
					if (MAILSMTP=='' || MAILACCOUNT=='' || MAILAPASSWORD=='' || MAILADDRESS==''){
						echo "M";
						exit;
					}
					$send=$smtp->sendmail($email,MAILADDRESS,$subject,$body,$mailtype);
					if (!$send){
						echo "T";
						exit;
					}
					
					echo "S";
				}else{
					echo "E";
				}
			break;
			case '2':
				echo "F";
			break;
		}
		break;
		case 'step2':
			$account=sqlReplace(trim($_POST['account']));
			$vercode=sqlReplace(trim($_POST['vercode']));
			$pw1=sqlReplace(trim($_POST['pwd1']));
			$pw2=sqlReplace(trim($_POST['pwd2']));
			if($wiibbsUser->setPw($account,$pw1))
			{
				echo "S";
			}else{
				echo "E";
			}
	}
	
?>