<?php

/**
 * msg_reply.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/msg_replay.php', '', str_replace('\\', '/', __FILE__)));
	echo THISPATHROOT;
	exit;
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	require_once(THISPATHROOT.'include/lib/msg_wiipu.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo($_['tip_returnlogin'],'login.php');
	}
	$msg=new Msg($registry);
	$act=sqlReplace(trim($_GET['act']));
	$id=sqlReplace(trim($_GET['id']));
	$message=$msg->getMsgById($id);
	if(!$message)
	{
		alertInfo($_['tip_nomsg'],'msg_list.php?act='.$act);
	}
	$header_title=$_['text_writeBox'];
	require_once('htmltop.php');
?>
<body> 

<div data-role="page" id="album-list">

	<div data-role="header" data-position="fixed" data-theme="b">
		<a href="usercenter.php" data-rel="back"><?php echo $_['btn_back'];?></a>
		<h1><?php echo $_['text_writeBox']?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext">home</a>
	</div>
	<div data-role="content">
		<form action="msg_do.php?act=reply&type=<?php echo $act;?>" method="post" data-ajax="false">
			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_receiver'].$message['msg_send'];?>：</label>
				<input type="text" name="receiver" id="receiver" value="<?php echo $message['msg_send'];?>"/>
			</div>
			<div data-role="fieldcontain">
				<label for="name">　<?php echo $_['text_title'];?>：</label>
				<input type="text" name="title" id="title" value="<?php echo $message['msg_title']?>"/>
			</div>

			<div data-role="fieldcontain">
				<label for="textarea">　<?php echo $_['text_content'];?>：</label>
				<textarea cols="40" rows="8" name="content" id="content" value="<?php echo $_['text_content'];?>"></textarea>

			</div>
			<div class="ui-body ui-body-b">
				<fieldset class="ui-grid-a">
						<button type="submit" data-theme="b"><?php echo $_['btn_submit']?></button>
				</fieldset>
			</div>
		</form> 
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

