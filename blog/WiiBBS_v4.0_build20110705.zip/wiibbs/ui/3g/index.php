<?php

/**
 * index.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/index.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once('htmltop.php');
	$session->data['setUrl']=getUrl();
	$session->data['setSkipUrl']=getUrl();
	$POSITION_INDEX="on"
?>
<body> 
<div data-role="page" id="album-list">

	<div id="wii_header" >
		<?php 
			if(SITELOGO!=''){
				$imagesize=getimagesize(NETURL."/".SITELOGO);
				$width=$imagesize[0];
				$height=$imagesize[1];
				echo "<div id='logo'><img src='".NETURL."/".SITELOGO."' alt='".SITENAME."' width='".$width."' height='".$height."'/></div>";
			}else{
				echo "<h1>".SITENAME."</h1>";
			}
		 ?>
	</div>

	<div data-role="content">
		<?php require_once('tab.php');?>
		
		<ul data-role="listview" data-theme="d"  data-inset="true" data-divider-theme="b">
			<li data-role="list-divider" > <?php echo $_['btn_newTopic']?></li>
		<?php
			
			$topicList=$topic->getTopic3g('',0,0,10,1);
				
		?>
		</ul>
		<ul data-role="listview" data-theme="d"  data-inset="true" data-divider-theme="b">
			<li data-role="list-divider" > <?php echo $_['text_recommend']?></li>
		<?php
			
			$topicList=$topic->getAllTopTopic3g_r();
				
		?>
		</ul>
	</div><!-- /content -->
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

