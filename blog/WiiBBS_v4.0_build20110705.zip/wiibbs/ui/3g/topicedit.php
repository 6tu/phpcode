<?php

/**
 * topicedit.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/topicedit.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	  require_once('checklogin.php');
	$header_title=$_['header_editTopic'];
	require_once('htmltop.php');
	$id=sqlReplace(Trim($_GET["id"]));
	$id=intval($id);
	$row=$topic->getTopicByID_BD($id,$bd);
	If(!$row){
		header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=102");
		exit;
	}Else{
		$title=$row["topic_title"];
		$content=$row["topic_content"];
	}
?>
<body> 
<div data-role="page" id="album-list">

	<div data-role="header" data-position="fixed" data-theme="b">
		
		<h1><?php echo $_['header_editTopic']?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext">home</a>
	</div>
	<div data-role="content">
		<form action="topicdo.php?do=edit&amp;id=<?php echo $id?>&amp;bd=<?php echo $_GET["bd"]?>" method="post" enctype="multipart/form-data" data-ajax="false">
			<div data-role="fieldcontain">
				<label for="name"><?php echo $_['text_topicTitle']?>；</label>
				<input type="text" name="title" id="name" value="<?php echo $title?>" />
			</div>

			<div data-role="fieldcontain">
				<label for="textarea"><?php echo $_['text_topicContent']?>；</label>
				<textarea cols="40" rows="8" name="content" id="textarea"><?php echo HTMLDecode($content)?></textarea>

			</div>
			<?php
					if($upload==1)
					{
				?>	
				<div data-role="fieldcontain">
						<label for="name"><?php echo $_['text_fileUp']?>；</label>
						<input type="file" name="file" size='18'/>

					</div>
				<?php
					}
				?>
				<!--
			<div data-role="fieldcontain">
				<fieldset data-role="controlgroup">
					<legend>&nbsp;</legend>
					<input type="checkbox" name="sina" id="checkbox-1" class="custom" value="1" />
					<label for="checkbox-1"><?php echo $_['text_topictoSina']?></label>
				</fieldset>
			</div>
			-->
			<div data-role="fieldcontain">
				<label for="textarea">&nbsp;</label>
				<input type="submit" data-theme="b" data-inline="true" value="<?php echo $_['btn_do']?>">

			</div>
		
		</form> 
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>
