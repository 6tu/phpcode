<?php

/**
 * topiccheck.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/topiccheck.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(THISPATHROOT.'include/lib/ubb_common.php');
	require_once(THISPATHROOT.'include/lib/image_common.php');
	require_once('usercheck.php');
	if (!($manager || $userGroup)){
		header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=132&bd=".$bd);	
		exit;
	}
	$header_title=$_['text_checkTopic'];
	require_once('htmltop.php');
	$id=sqlReplace(Trim($_GET["id"]));
	$id=intval($id);
	$url="id=".$id."&amp;bd=".$bd;
	$row=$topic->getTopicByID_BD($id,$bd);
	If(!$row){
		header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=102");	
		exit;
	}Else{
		$title=$row["topic_title"];
		$content=$row["topic_content"];
		$addTime=$row["topic_posttime"];
		$poster=$row["topic_user"];
		
	}
?>
<body> 

<div data-role="page">

	<div data-role="header" data-position="fixed"  data-theme="b" >
		<a data-rel="back"><?php echo $_['btn_back']?></a>
		<h1><?php echo $_['text_checkTopic']?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext">home</a>
	</div>
	<div data-role="content">
			<h2><strong><?php echo $title?></strong></h2>
			<p><?php If($poster!="Guest"){?><a href="user.php?id=<?php echo $poster?>&amp;url=<?php echo urlencode($funcSysten->getUrl())?>"><?php echo $poster?></a><?php }else{?><?php echo $poster?><?php }?><?php echo $_['text_write']?> <?php echo $addTime?></p>
		<?php
			if (!empty($userName)){
				if ($userName==$poster || $manager || $userGroup)
		?>
			      <p><a href="topiccheckmanage.php?bd=<?php echo $bd?>&amp;id=<?php echo $id?>" data-role="button" data-inline="true" data-transition="slidedown"  data-rel="dialog"><?php echo $_['text_managerTopic']?></a></p>
				
		 <?php
			}
			//帖子内容分页
			if(SITEUBB=="1")
				{
					$ubbcode = new UBBCode();
					$content=$ubbcode->encode($content); 
				}
			echo $content;
			?>
			
		
	</div><!-- /content -->
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>


