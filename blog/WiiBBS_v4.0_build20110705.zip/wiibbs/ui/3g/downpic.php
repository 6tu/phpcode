<?php

/**
 * downpic.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/3g/downpic.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once('usercheck.php');
	$header_title=$_['header_dowm'];
	require_once('htmltop.php');
	$file_id=sqlReplace(trim($_GET['filename']));
	$id=sqlReplace(trim($_GET['id']));
	$bd=sqlReplace(trim($_GET['bd']));
	$page=sqlReplace(trim($_GET['page']));
	if(empty($_GET['t'])){
		$t="";
	}else{
		$t=sqlReplace(trim($_GET['t']));
	}
	if(!empty($t)){
		$url="topicreplylist.php?id=".$id."&amp;t=".$t."&amp;page=".$page."&amp;bd=".$bd;
	}else{
		$url="topicshow.php?id=".$id."&amp;bd=".$bd."&amp;page=".$page;
	}
	if(!file_exists(ROOT_PATH."userfiles/high/".$file)){
		alertInfo($_['alert_noPic'],$url);
	}
	$row=$topic->getFileById($file_id);
	if ($row){
		$file=$row['file_url'];
	}
?>

 <body>
	<div data-role="page" id="album-list">
		<div data-role="header" data-position="fixed" data-theme="b">
		<a  data-rel="back"><?php echo $_['btn_back']?></a>
		<h1><?php echo $_['text_picDown']?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext">home</a>
	</div>
		<div data-role="content">
		<?php
			$img=getimagesize(NETURL."/userfiles/high/".$file);
			echo "<p><img src='".NETURL."/userfiles/high/".$file."' width='".$img[0]."' height='".$img[1]."'/></p>";
			echo "<p><a href='downfile.php?filename=".$file_id."&amp;type=y' data-ajax='false'>".$_['text_oldPic']."</a><br/><a href='downfile.php?filename=".$file_id."&amp;type=h' data-ajax='false'>".$_['text_highPic']."</a><br/><a href='downfile.php?filename=".$file_id."&amp;type=b' data-ajax='false'>".$_['text_smallPic']."</a><br/><a href='downfile.php?filename=".$file_id."&amp;type=s' data-ajax='false'>".$_['text_smallerPic']."</a><br/><a href='".$url."' data-ajax='false'>".$_['btn_goback']."</a> </p>";
		?>	
		</div>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>
