<?php

/**
 * msg_list.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/3g/msg_list.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	require_once(THISPATHROOT.'include/lib/msg_wiipu.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo3g($_['tip_returnlogin'],'login.php');
	}
	$msg=new Msg($registry);
	$act=empty($_GET['act'])?'new':sqlReplace(trim($_GET['act']));
	switch($act)
	{
		case 'new':
			$title=$_['text_unredBox'];
			break;
		case 'receive':
			$title=$_['text_inBox'];
			break;
		case 'send':
			$title=$_['text_outBox'];
			break;
	}
	require_once('htmltop.php');
?>
<body> 
<script type="text/javascript">
	function jqmSimpleMessage(message) {
		$("<div class='ui-loader ui-overlay-shadow ui-body-b ui-corner-all'><h1>" + message + "</h1></div>")
			.css({
				display: "block",
				opacity: 0.96,
				top: window.pageYOffset+100
			})
			.appendTo("body").delay(800)
			.fadeOut(400, function(){
				$(this).remove();
			});
	}
	
		function delMSG(id){
			if(confirm('确定删除吗？')){
				$.ajax({
					url:"msg_do.php",
					type:'get',
					data:{
						'id':id,
						'act':'del'
					},
					success:function(rt){
						if (rt=="S"){
							jqmSimpleMessage('<?php echo $_['suc_del'];?>');
							location.href='msg_list.php?act=<?php echo $act?>';
							
						}
					},error:function(rt){
						alert(rt);
					}
				});
				return false;
			}
		}
	
</script>
<div data-role="page" id="album-list">

	<div data-role="header" data-position="fixed" data-theme="b">
		<a href="usercenter.php" data-role='button'><?php echo $_['btn_goback'];?></a>
		<h1><?php echo $title;?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext"></a>
	</div>
	
	
	<div data-role="content">
		
		<ul data-role="listview" data-theme="d"  data-inset="true" data-split-theme="d" data-split-icon="delete">
			<?php
			$rscount=$msg->getBoxCount($act);
			if($rscount<1)
			{
				echo "<li>".$_['tip_noMsg']."</li>";
			}
			$pagesize=15;
			$startRow=0;
			if (empty($_GET['page'])||!is_numeric($_GET['page']))
			{
				$page=1;
			}else{
				$page=$_GET['page'];
				$startRow=($page-1)*$pagesize;
			}
			if ($rscount%$pagesize==0)
			{
				$pagecount=$rscount/$pagesize;
			}else{
				$pagecount=ceil($rscount/$pagesize);
			}
			$msgList=$msg->getBoxList($startRow,$pagesize,$act);
			foreach($msgList as $message)
			{
			?>
			<li>
				<a href="msgshow.php?id=<?php echo $message['msg_id']?>&amp;act=<?php echo $act?>" data-ajax="false"><h3><?php echo $message['msg_title']?> 
				<?php
					If($act=="receive"){ 
						echo "[";
						If(intval($message["msg_isreader"])==0){
								echo $_['text_unred']; 
						}Else{ 
								echo $_['text_hasred']; 
						}
						echo "]";
					}
				?>
				</h3></a>
				<a href="javascript:void(0);" onClick="return delMSG(<?php echo $message['msg_id']?>)" ><?php echo $_['text_topicdel'];?></a>
			</li>
			<?php } ?>
		</ul>
		<?php
			if($rscount>$pagesize)
			{
				echo showPage2('msg_list.php?act='.$act,$page,$pagesize,$rscount,$pagecount);
			}
		?>
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

