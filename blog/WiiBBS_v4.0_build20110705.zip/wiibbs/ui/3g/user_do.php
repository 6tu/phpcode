<?php

/**
 * user_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/user_do.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	
	require_once(THISPATHROOT.'include/lib/image_common.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo3g($_['tip_returnlogin'],'login.php');
	}
	$act=sqlReplace(trim($_GET['act']));
	switch($act)
	{
		case 'edit':
			$arr['user_nickname']=empty($_GET['nikename'])?'':sqlReplace(trim($_GET['nikename']));
			$arr['user_name']=empty($_GET['name'])?'':sqlReplace(trim($_GET['name']));
			$arr['user_email']=empty($_GET['email'])?'':sqlReplace(trim($_GET['email']));
			$arr['user_sex']=empty($_GET['sex'])?'':sqlReplace(trim($_GET['sex']));
			$arr['user_province']=empty($_GET['province'])?'':sqlReplace(trim($_GET['province']));
			$arr['user_city']=empty($_GET['city'])?'':sqlReplace(trim($_GET['city']));
			$arr['user_address']=empty($_GET['address'])?'':sqlReplace(trim($_GET['address']));
			$arr['user_birthday']=empty($_GET['brith'])?'':sqlReplace(trim($_GET['brith']));
			$arr['user_qq']=empty($_GET['qq'])?'':sqlReplace(trim($_GET['qq']));
			$arr['user_mobile']=empty($_GET['mobile'])?'':sqlReplace(trim($_GET['mobile']));
			$arr['user_sina']=empty($_GET['sina'])?'':sqlReplace(trim($_GET['sina']));
			if(!empty($arr['user_nickname']))
			{
				if($wiibbsUser->checkNickname2($arr['user_nickname']))
				{
					echo "A";
					exit;
				}
			}
			if(!empty($arr['user_email']))
			{
								
				if (!eregi("^[_\.0-9a-z-]+@([0-9a-z][0-9a-z-]+\.)+[a-z]{2,4}$",$arr['user_email'])){
				   echo "B";
				   exit;
				 }
				if($wiibbsUser->checkEmail2($arr['user_email']))
				{
					echo "C";
				   exit;
				}
			}
			if(!empty($arr['user_mobile']))
			{
				if (!eregi("^1[3|5|8][0-9]{9}$",$arr['user_mobile'])){
				   echo "D";
				   exit;
				 }
				if($wiibbsUser->checkMobile2($arr['user_mobile']))
				{
					echo "F";
				   exit;
				}
			}
			$result=$wiibbsUser->updateUser($arr);
			if($result==1)
			{
				echo "S";
			    exit;
			}else if($result==2)
			{
				echo "E";
				 exit;
			}
			break;
		case 'pw':
			$pw=sqlReplace(trim($_GET['oldPw']));
			$newPw=sqlReplace(trim($_GET['newPw']));
			$rePw=sqlReplace(trim($_GET['rePw']));
			$result=$wiibbsUser->login($session->data[WiiBBS_ID."wiibbsUser"],$pw,1);
			if($result!=3)
			{
				echo "O";
				exit;
			}
			$result=$wiibbsUser->updatePassword($pw,$newPw);
			if($result!=3)
			{
				echo "E";
				exit;
			}
			echo "S";
			exit;
			break;
		case 'upload':
			$f_name=$_FILES['file']['name'];
			$f_size=$_FILES['file']['size'];
			$f_tmpName=$_FILES['file']['tmp_name'];
			if(!empty($f_name))
			{	
				$f_ext=strtolower(preg_replace('/.*\.(.*[^\.].*)*/iU','\\1',$f_name));
				$f_exts=explode("|",'gif|jpg|png');
				if(!in_array($f_ext,$f_exts))
				{
					alertInfo3g($_['error_fileFormat'],'uploadheader.php');
				}
				if($f_size>40*1024)
				{
					alertInfo3g($_['error_fileSizeOut'],'uploadheader.php');
				}
				$file_name=date('YmdHis').".".$f_ext;
				$filename=ROOT_PATH."userfiles/header/initial/".$file_name;
				$newfilename=ROOT_PATH."userfiles/header/pic/".$file_name;
				move_uploaded_file ($f_tmpName,$filename);
				
				$t = new ThumbHandler();
				$t->setSrcImg($filename);
				$t->setDstImg($newfilename);
				$t->createImg(115,115);
				$arr['user_photo']=$file_name;
				
				$result=$wiibbsUser->updateUser($arr);
				
				if($result==1)
				{
					alertInfo3g($_['suc_upload'],'uploadheader.php');
				}else{
					alertInfo3g($_['error_upload'],'uploadheader.php');
				}
			}else{
				alertInfo3g($_['text_noUpload'],'uploadheader.php');
			}
	}
?>