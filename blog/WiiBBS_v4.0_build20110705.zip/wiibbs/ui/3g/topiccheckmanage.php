<?php

/**
 * topiccheckmanage.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/topiccheckmanage.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	require_once('checklogin.php');
	$id=sqlReplace(trim($_GET["id"]));
	$row=$topic->getTopicByID_BD($id,$bd);
	If(!$row){
		header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=102");
		exit;
	}Else{
		$title=$row["topic_title"];
		$isLock=$row["topic_islock"];
		$isTop=$row["topic_istop"];
		$poster=$row["topic_user"];
		$isGood = $row["topic_isgood"];
	}
	//判断权限
	$myself=false;
	If ($poster==$userName && $poster!='Guest')  $myself=true;
	$header_title=$title;
	require_once('htmltop.php');
?>
<body> 

<div data-role="page">

	<div data-role="header" data-theme="d" data-position="inline">
			<h1><?php echo $_['text_managerTopic']?></h1>

	</div>
	<div data-role="content">
		<?php
			if (!($manager || $userGroup)){
				echo "<p>".$_['alert_noLimit']."</p><a  data-role=\"button\" data-rel=\"back\" data-theme=\"c\" data-direction=\"reverse\">".$_['btn_back']."</a>";
			}else{
		?>
		<?php if ($manager || $userGroup){?>
				<a href="topicdo.php?id=<?php echo $id?>&amp;do=check&amp;bd=<?php echo $bd?>" data-role="button" data-ajax="false"   data-transition="slidedown" data-theme="b"><?php echo $_['btn_checkTopic']?></a>
				<a href="topicdeal.php?bd=<?php echo $bd?>&amp;id=<?php echo $id?>&amp;act=del&t=c" data-role="button" data-rel="dialog" data-transition="slidedown" data-theme="b"><?php echo $_['text_topicdel']?></a>  
		<?php 
			  }
			
		   }
		?>
		
	</div>
	
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

