<?php

/**
 * msgshow.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/3g/msgshow.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo3g($_['tip_returnlogin'],'login.php');
	}
	require_once(THISPATHROOT.'include/lib/msg_wiipu.php');
	require_once('htmltop.php');
	$msg=new Msg($registry);
	$act=sqlReplace(trim($_GET['act']));
	$id=sqlReplace(trim($_GET['id']));
	$message=$msg->getMsgById($id);
	if(!$message)
	{
		alertInfo3g($_['tip_nomsg'],'msg_list.php?act='.$act);
	}
	$msg->updateMsgById($id);
	$noticeClass->updateNoticeState(2);
?>
<body> 
<script type="text/javascript">
	function jqmSimpleMessage(message) {
		$("<div class='ui-loader ui-overlay-shadow ui-body-b ui-corner-all'><h1>" + message + "</h1></div>")
			.css({
				display: "block",
				opacity: 0.96,
				top: window.pageYOffset+100
			})
			.appendTo("body").delay(800)
			.fadeOut(400, function(){
				$(this).remove();
			});
	}
	$(document).ready(function(){
		$("#delMSG").click(function(){
			$.ajax({
				url:"msg_do.php",
				type:'get',
				data:{
					'id':<?php echo $id?>,
					'act':'del'
				},
				success:function(rt){
					if (rt=="S"){
						jqmSimpleMessage('<?php echo $_['suc_del'];?>');
						location.href='msg_list.php?act=<?php echo $act?>';
						
					}
				},error:function(rt){
					alert(rt);
				}
			});
			return false;
		});
	});
</script>
<div data-role="page">

	<div data-role="header" data-position="fixed"  data-theme="b" >
		<a href="#" data-rel="back"><?php echo $_['btn_goback'];?></a>
		<h1><?php echo $_['text_details']?></h1>
		<a href="msg_reply.php?id=<?php echo $id?>&amp;act=<?php echo $act?>" data-role="button"  data-ajax="false" ><?php echo $_['btn_reply']?></a>
	</div>
	<div data-role="content">
			<h2><strong><?php echo $message['msg_title']?></strong></h2>
			<p><?php echo $_['text_time'].":".$message['msg_addtime'];?></p>
			<p>
				<?php 
					$url="act=".$act."&amp;id=".$id;
					mb_internal_encoding("UTF-8");
					if(empty($_GET['all']))
					{
						$all='';
					}else{
						$all=sqlReplace(trim($_GET["all"]));
					}
					$logtextx=HTMLDecode($message['msg_content']);
					$logtextx=$logtextx;
					//开始分页  
					if(!empty($_REQUEST["Page"]))  $page=intval($_REQUEST["Page"]); 
					$PageLength=300;
					$CLength=mb_strLen($logtextx);
					//$str=cutstr($logtextx,$CLength);
					$pagecount=(intval($CLength/$PageLength))+1; 
					$page=!empty($_GET['page'])?sqlReplace(trim($_GET['page'])):1;
					if(($page<1) || (is_null($page))) $page=1; 
					if($page>$pagecount) $Page=$pagecount; 
					if($page==1){
						$a=0; 
					}elseif($page>1){ 
						$a=($page-1)*$PageLength; 
					}
					
					If($all=="all"){
						$wen=mb_substr($logtextx,$a);
					}Else{
						$wen=mb_substr($logtextx,$a,$PageLength); 
					} 
					echo "<p>".$wen."</p>"; 
					echo "<p>"; 
					If($pagecount>1){
						echo morePage('msgshow.php?'.$url,$page,$PageLength,$CLength,$pagecount);
					}
					echo "</p>"; 
				?>	
			</p>
			<div data-role="controlgroup" data-type="horizontal" >
				<?php 
					if($act=='receive'||$act=='new'){
						echo "<p>".$_['text_wirter'].$message['msg_send']."</p> <a href='msg_reply.php?id=".$message['msg_id']."&amp;act=".$act."' data-role='button' data-ajax='false'>".$_['btn_reply']."</a> <a  data-role='button' id='delMSG' data-ajax='false'>".$_['btn_del']."</a> ";
					}else if($act=='send')
					{
						echo "<p>".$_['text_receiver'].$message['msg_received']."</p> <a   data-role='button' id='delMSG' data-ajax='false'>".$_['btn_del']."</a>";
					}
				?>
			</div>
	</div><!-- /content -->
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>


