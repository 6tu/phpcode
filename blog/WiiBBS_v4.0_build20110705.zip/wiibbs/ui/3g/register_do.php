<?php

/**
 * register_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/register_do.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	
	$account=sqlReplace(trim($_POST['account']));
	$password=sqlReplace(trim($_POST['pwd']));
	$password2=sqlReplace(trim($_POST['pwd2']));
	$email=empty($_POST['email'])?"":sqlReplace(trim($_POST['email']));
	$fbarr=explode('|',FBDSTR);
	if(in_array(strtolower($account),$fbarr))
	{
		echo "F";
		exit;
	}
	if(accountCheckModule=='0')
	{
		If(strLen($account)<accountMinLength || strLen($account)>accountMaxLength){
			echo "A";
			exit;
		}
	}elseif(accountCheckModule=='1')
	{
		if(!preg_match("/^\d{".accountMinLength.",".accountMaxLength."}$/",$account))
		{
			echo "B";
			exit;
		}
	}elseif(accountCheckModule=='2')
	{
		if(!preg_match("/^[a-zA-z]{".accountMinLength.",".accountMaxLength."}$/",$account))
		{
			echo "C";
			exit;
		}
	}elseif(accountCheckModule=='3')
	{
		if(!preg_match("/^[a-zA-z0-9-]{".accountMinLength.",".accountMaxLength."}$/",$account))
		{
			echo "D";
			exit;
		}
	}
	$user=array('user_account'=>$account,'user_password'=>$password,'user_mobile'=>'','user_email'=>$email,'user_photo'=>'');
	$result=$wiibbsUser->register($user,0);
	echo $result;
	
	
?>