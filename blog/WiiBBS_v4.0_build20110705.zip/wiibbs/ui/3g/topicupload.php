<?php

/**
 * topicpost.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/3g/topicupload.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	
	$header_title=$_['text_postTopic'];
	require_once('htmltop.php');
?>
<body> 

<div data-role="page" id="album-list">

	<div data-role="header" data-position="fixed" data-theme="b">
		<h1><?php echo $_['text_upload_file'];?></h1>
		<a href="index.php" data-icon="home" data-iconpos="notext">home</a>
	</div>
	<div data-role="content">
		<form method="post" enctype="multipart/form-data" data-ajax="false">
			
			
					<div data-role="fieldcontain">
						<label for="name"><?php echo $_['text_fileUp']?>:</label>
						<span id="loading" style="display:none;"><img src="themes/images/loading.gif" width="16" height="16" alt="loading" /></span><input id="fileToUpload" type="file" name="fileToUpload" style="height:24px;" /> 

					</div>
					<div data-role="fieldcontain">
						<label for="textarea">&nbsp;</label>
						<input type="button" onclick="return ajaxFileUpload();" value="<?php echo $_['text_upload1'];?>" data-inline="true" data-ajax="false"/>

					</div>
				
				
		
		</form> 
	</div><!-- /content -->	
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

