<?php

/**
 * topicchot.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/hot.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/applications.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/topic.php');
	$header_title=$_['text_HotTopic'];
	require_once('htmltop.php');
	$POSITION_HOT="on";
?>
<body> 
<div data-role="page" id="album-list">

	<div id="wii_header" >
		<?php 
			if(SITELOGO!=''){
				$imagesize=getimagesize(NETURL."/".SITELOGO);
				$width=$imagesize[0];
				$height=$imagesize[1];
				echo "<div id='logo'><img src='".NETURL."/".SITELOGO."' alt='".SITENAME."' width='".$width."' height='".$height."'/></div>";
			}else{
				echo "<h1>".SITENAME."</h1>";
			}
		 ?>
	</div>

	
	<div data-role="content">
		<?php require_once('tab.php');?>
		

		<ul data-role="listview" data-theme="d"  data-inset="true">
		<?php
			$topics=$topic->getHotTopicList(0,10);
			if(count($topics)<1)
			{
				echo "<li>".$_['tip_noHotTopic']."</li>";
			}
			for($i=0;$i<count($topics);$i++)
			{
		?>
			<li><a href="topicshow.php?bd=<?php echo $topics[$i]["topic_board"]?>&amp;id=<?php echo $topics[$i]["topic_id"]?>&amp;rnd=<?php echo rand()?>" data-ajax='false'><?php echo $topics[$i]["topic_title"]?></a> <span class="ui-li-count"><?php echo $topics[$i]["topic_recount"]."/".$topics[$i]["topic_viewcount"]?></span></li>
		<?php
			}
		?>
			</ul>
	</div><!-- /content -->	
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

