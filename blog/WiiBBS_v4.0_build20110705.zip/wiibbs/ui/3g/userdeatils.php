<?php

/**
 * userdeatils.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/userdeatils.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	 $userName=$wiibbsUser->checkISlogin();
	 if (empty($userName)){
		header("location:".NETURL."/ui/".$folder_3g."/auto.php?auto=140");	
		exit();
	 }
	$header_title=$_['text_details'];
	require_once('htmltop.php');
	$uid=empty($_GET['uid'])?'':sqlReplace(trim($_GET['uid']));
	$url=sqlReplace(trim($_GET['url']));
	$user=$wiibbsUser->getUserByAccount($uid);
?>
 <body>
	<div data-role="page" id="album-list">

		<div data-role="header" data-position="fixed" data-theme="b">
			<a href="<?php echo $url?>" data-role="button"data-inline="true" ><?php echo $_['btn_back']?></a>
			<h1><?php echo $_['text_details'];?></h1>
			<a href="index.php" data-icon="home" data-iconpos="notext"></a>
		</div>
		
		
		<div data-role="content">
			
			<ul data-role="listview" data-inset="true" data-theme="d">
	
				<li><?php echo $_['text_nikeName'];?>：<?php echo $user['user_nickname']?></li>
				<li><?php echo $_['text_account'];?>：<?php echo $user['user_account']?></li>
				<li><?php echo $_['text_name'];?>：<?php echo $user['user_name']?></li>
				<li><?php echo $_['text_score'];?>：<?php echo $user['user_score']?></li>
				<li><?php echo $_['text_grade'];?>：<?php echo $user['user_grade']?></li>
				<li><?php echo $_['text_sex'];?>：<?php  if($user['user_sex']==1){
					echo $_['text_man']; }else if($user['user_sex']==2){ echo $_['text_women'];} ?></li>
				<li><?php echo $_['text_brith'];?>：<?php echo $user['user_birthday']?></li>
				<li><?php echo $_['text_mobile'];?>：<?php echo $user['user_mobile']?></li>
				<li><?php echo $_['text_email'];?>：<?php echo $user['user_email']?></li>
				<li><?php echo $_['text_qq'];?>：<?php echo $user['user_qq']?></li>
				<li><?php echo $_['text_sina'];?>：<?php echo $user['user_sina']?></li>
				<li><?php echo $_['text_province'];?>：<?php echo $user['user_province']?></li>
				<li><?php echo $_['text_city'];?>：<?php echo $user['user_city']?></li>
				<li><?php echo $_['text_address'];?>：<?php echo $user['user_address']?></li>
				<li><?php echo $_['text_regTime'];?>：<?php echo $user['user_regtime']?></li>
				<li><?php echo $_['text_logCount'];?>：<?php echo $user['user_logincount']?></li>
				<li><?php echo $_['text_lastLoginTime'];?>：<?php echo $user['user_lastlogin']?></li>
			</ul>
			<?php if ($uid==$session->data[WiiBBS_ID."wiibbsUser"]){?>
			<p><a href="useredit.php" data-role="button" data-inline="true"  data-theme="b" data-ajax='false'><?php echo $_['text_editUser']?></a></p>
			<?php }?>
		</div><!-- /content -->	
		<?php require_once('bottom.php');?>
		
	</div><!-- /page -->
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>