<?php

/**
 * index.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/3g/boardlist.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once('htmltop.php');
	$session->data['setUrl']=getUrl();
	$POSITION_BOARD="on"
?>
<body> 
<div data-role="page" id="album-list">

	<div id="wii_header" >
		<?php 
			if(SITELOGO!=''){
				$imagesize=getimagesize(NETURL."/".SITELOGO);
				$width=$imagesize[0];
				$height=$imagesize[1];
				echo "<div id='logo'><img src='".NETURL."/".SITELOGO."' alt='".SITENAME."' width='".$width."' height='".$height."'/></div>";
			}else{
				echo "<h1>".SITENAME."</h1>";
			}
		 ?>
	</div>

	<div data-role="content">
		<?php require_once('tab.php');?>
		<ul data-role="listview" data-theme="d"  data-inset="true" data-divider-theme="b">
		<?php
			$classList=$board->getBoardClassList();
			foreach ($classList as $row){
		?>
				<li data-role="list-divider" ><?php echo $row['boardclass_name']?></li>
		<?php
				$boardList=$board->getBoardList($row['boardclass_id']);
				foreach($boardList as $rows){	
					if (empty($rows['board_pic']))
						$boardPic="nopic.jpg";
					else
						$boardPic=$rows['board_pic'];
		?>
					<li>
						<a href="board.php?bd=<?php echo $rows['board_id']?>" data-ajax='false'>
						<img class="ui-li-thumb"  src="<?php echo NETURL."/userfiles/board/".$boardPic?>" width="115" height="115" border="0" alt="<?php echo $rows['board_name']?>">
						<h3><?php echo $rows['board_name']?></h3>

						</a>
					</li>
		<?php
				}
			}			
		?>
			
		</ul>
	</div><!-- /content -->
	<?php require_once('bottom.php');?>
	
</div><!-- /page -->


</body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

