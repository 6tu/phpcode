<?php

/**
 * topicpost.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/color/topicpost.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	If($bdType!=4){
	  require_once('checklogin.php');
	  if ($bdType==6){  //检查咨询版面的权限
		if (!$manager){
			alertInfo($_['alert_adminBoard'],'board.php?bd='.$bd);
		}
	  }
	}
	$header_title=$_['text_postTopic'];
	require_once('htmltop.php');
?>

 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<?php require_once('noticeinc.php');?>
		<div class='hf'><a href="index.php"><?php echo $_['text_index']?></a>&gt;&gt;<?php echo $_['text_postTopic']?></div>
		<div class='comment'>
			<form action="topicpostdo.php?bd=<?php echo $bd?>" method="post" enctype="multipart/form-data">
				<p><?php echo $_['text_topicTitle']?>：<input inputmode="user predictOn" name="title" type="text"/></p>
				<p><?php echo $_['text_topicContent']?>：</p>
				<p><textarea cols="30" rows="3" name="content"></textarea></p>
				<?php
					if($upload==1)
					{
				?>	
				<p><?php echo $_['text_fileUp']?>：<input inputmode="user predictOn" type="file" name="file" size='18'/></p>
				<?php
					}
				?>
				
				<p><input inputmode="user predictOn" type="submit" value="<?php echo $_['btn_do']?>"/></p>
				
			</form>
			<div class='red' >
			<?php
				if($upload==1){	
					echo $_['text_topicinfo'].attachSize."k,".$_['text_topicinfo_1'].attachType.".".$_['text_topicinfo_2'];
					if (SITEUBB=="1") echo "3、".$_['text_ubb'].".";
				}else{
					if (SITEUBB=="1") echo $_['text_ubb'];
				}
				
			?>
			</div>
		</div>
		<div class='box'><p><?php echo $_['btn_goback']?>[<a href="board.php?bd=<?php echo $bd?>&amp;rnd=<?php echo rand();?>"><?php echo $bdName?></a>]</p></div>
		<?php 
			$session->data['setSkipUrl']=getUrl();
			require_once('boardswitch.php');
		?>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>
