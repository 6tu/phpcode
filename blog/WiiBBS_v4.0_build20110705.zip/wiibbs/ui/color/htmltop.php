<?php
	$header_title=empty($header_title)?'':$header_title;
	$meta_content=$funcSysten->getHeader();
	$Document->getHtml();
	$Document->getHead($header_title,'color',$meta_content);
?>