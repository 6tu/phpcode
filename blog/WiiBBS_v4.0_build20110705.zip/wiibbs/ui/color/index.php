<?php

/**
 * index.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/color/index.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once('htmltop.php');
	$POSITION_INDEX="on";
	$session->data['setUrl']=getUrl();
	$session->data['setSkipUrl']=getUrl();
?>

 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<?php require_once('noticeinc.php');?>
		<?php require_once('logininc.php');?>
		<?php require_once('tab.php');?>
		<h1><?php echo $_['text_TopicAll']?></h1>
		<?php
			$topicList=$topic->getAllTopTopic();
		?>
		<h1><?php echo $_['btn_newTopic']?></h1>
		<?php
			$topic->getTopic('',0,0,10);
		?>
		
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>
