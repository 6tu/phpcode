<?php

/**
 * topicmove.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/color/topicmove.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	require_once('checklogin.php');
	if (!($manager || $userGroup)) alertInfo($_['alert_noLimit'],'index.php');
	$header_title=$_['header_moveTopic'];
	require_once('htmltop.php');
	$id=sqlReplace(Trim($_GET["id"]));
	$id=intval($id);
	$row=$topic->getTopicByID_BD($id,$bd);
	If(!$row){
		alertInfo($_['alert_noNEW'],'index.php');
	}Else{
		$title=$row["topic_title"];
		$content=$row["topic_content"];
	}
?>

 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<?php require_once('noticeinc.php');?>
		<div class='hf'><a href="index.php"><?php echo $_['text_index']?></a>&gt;&gt;<?php echo $_['header_moveTopic']?></div>
		<div class='comment'>
			<form action="topicdo.php?id=<?php echo $id?>&amp;do=move" method="post" >
				<p><?php echo $_['text_checkBoard']?>：
				<select name="bd">
				<?php
				$bList=$board->getBoardList('',$bd);
				If(!$bList){
					echo "<option value='0'>".$_['text_noBoard'] ."</option>";
				}Else{
					foreach($bList as $row){
				?>
					<option value="<?php echo $row["board_id"]?>" ><?php echo $row["board_name"]?></option>
				<?php
					}
				}
				?>
				</select></p>
				
				<p><INPUT inputmode="user predictOn" TYPE="hidden" NAME="oldbd" value="<?php echo $bd?>"><input inputmode="user predictOn" type="submit" value="<?php echo $_['btn_move']?>"/></p>
				
			</form>
		</div>
		<div class='box'><p><?php echo $_['btn_goback']?>[<a href="board.php?bd=<?php echo $bd?>&amp;rnd=<?php echo rand();?>"><?php echo $bdName?></a>]</p></div>
		<?php 
			$session->data['setSkipUrl']=getUrl();
			require_once('boardswitch.php');
		?>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>
