<?php
	define('THISPATHROOT', str_replace('ui/color/boardjump.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	$board=sqlReplace(trim($_POST['board']));
	header("location:".NETURL."/ui/color/board.php?bd=".$board."");
?>