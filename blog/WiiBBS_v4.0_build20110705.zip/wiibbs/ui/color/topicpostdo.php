<?php

/**
 * topicpostdo.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/color/topicpostdo.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(THISPATHROOT.'include/lib/image_common.php');
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	if($bd===0)
	{
		exit();
	}
	If(empty($userName)){
		If($bdType==4){
			$userName="Guest";
		}else{
			 require_once('checklogin.php');
		} 
	}
	$title=sqlReplace(Trim($_POST["title"]));
	$content=HTMLEncode(trim($_POST["content"]));
	$sina=empty($_POST["sina"])?'':sqlReplace(Trim($_POST["sina"]));
	if (SITEFILTER!=''){
		$filter=str_replace("，",',',SITEFILTER);
		$filters=explode(",",$filter);
		for($i=0;$i<count($filters);$i++)
		{
			if(strpos($title.$content,$filters[$i])>-1)
			{
				alertInfo($_['alert_filter'],'topicpost.php?bd='.$bd.'&amp;key=post');
			}
		}
	}
	if (strLen($title)<1) alertInfo($_['alert_titleNull'],'topicpost.php?bd='.$bd.'&amp;key=post');
	If(strLen($content)<1){
		alertInfo($_['alert_contentNull_r'],'topicpost.php?bd='.$bd.'&amp;key=post');
	}
	$f_name=$_FILES['file']['name'];
	$f_name_1=$_FILES['file']['name'];
	$f_size=$_FILES['file']['size'];
	$f_tmpName=$_FILES['file']['tmp_name'];
	$filename="";
	if(!empty($f_name))
	{	
		$f_ext=strtolower(preg_replace('/.*\.(.*[^\.].*)*/iU','\\1',$f_name));
		$f_exts=explode("|",attachType);
		$checkExt=false;
		foreach ($f_exts as $v)
			if ($f_ext==$v){
			$checkExt=true;
			break;
			}
		if (!$checkExt) die ($_['alert_type1'].attachType.$_['alert_type2']."。<a href='topicpost.php?bd=".$bd."'>".$_['btn_goback']."</a>");
		if ($f_size>attachSize*1024) die ($_['alert_type3'].attachSize."k。<a href='topicpost.php?bd=".$bd."'>".$_['btn_goback']."</a>");
		
		$date=date('YmdHis');
		$f_name=$date.".".$f_ext;
		
		$filename=ROOT_PATH."userfiles/attach/".$f_name;
		@copy($f_tmpName,$filename) or die ($_['alert_uploadFail'] );
		if($f_ext=='jpg'){
			$newfilename=ROOT_PATH."userfiles/high/".$f_name;
			$t = new ThumbHandler();
			$t->setSrcImg($filename);
			$t->setDstImg($newfilename);
			$t->createImg(320,480);
			$newfilename=ROOT_PATH."userfiles/small/".$f_name;
			$t = new ThumbHandler();
			$t->setSrcImg($filename);
			$t->setDstImg($newfilename);
			$t->createImg(240,320);
			$newfilename=ROOT_PATH."userfiles/smaller/".$f_name;
			$t = new ThumbHandler();
			$t->setSrcImg($filename);
			$t->setDstImg($newfilename);
			$t->createImg(128,160);
		}
	}
	$data=array(
	'title'=>$title,
	'content'=>$content,
	'wiibbsUser'=>$userName,
	'bd'=>$bd,
	'upload'=>$f_name,
	'bdCheck'=>$bdCheck,
	'type'=>$f_ext,
	'fileName'=>str_replace(".".$f_ext,'',$f_name_1),
	'fileSize'=>$f_size
	);
	$result=$topic->insertTopic($data);
	
	if($result==2){
		if (!empty($sina)){
			$sql="select topic_id from ".DB_TABLE_PREFIX."topic where topic_title='".$title."' and datediff(now(),topic_posttime)=0 order by topic_id desc limit 1";
			$query=$db->query($sql);
			$row=$query->row;
			if ($row){
				$id=$row['topic_id'];
				$url=NETURL."/ui/color/topicshow.php?bd=".$bd."&id=".$id;
				$share=$title;
				echo "<script type='text/javascript'>";
				echo "window.open('http://v.t.sina.com.cn/share/share.php?title='+encodeURIComponent('".$share."')+'&amp;url='+encodeURIComponent('".$url."')+'&amp;source=bbs','_blank','width=450,height=400');";
				echo  "</script>";
			}
		}
		alertInfo($_['alert_postSucc'],'board.php?bd='.$bd);
	}else if ($result==3){
		alertInfo($_['alert_postFail'],'index.php');
	}else if ($result==1)
		alertInfo($_['alert_repeatPost'],'board.php?bd='.$bd);
?>