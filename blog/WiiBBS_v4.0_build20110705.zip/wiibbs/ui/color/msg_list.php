<?php

/**
 * msg_list.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/color/msg_list.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	require_once(THISPATHROOT.'include/lib/msg_wiipu.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo($_['tip_returnlogin'],'login.php');
	}
	$msg=new Msg($registry);
	$act=sqlReplace(trim($_GET['act']));
	switch($act)
	{
		case 'new':
			$title=$_['text_unredBox'];
			break;
		case 'receive':
			$title=$_['text_inBox'];
			break;
		case 'send':
			$title=$_['text_outBox'];
			break;
	}
	$header_title=$title;
	require_once('htmltop.php');
?>
 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<?php require_once('noticeinc.php');?>
		<div class='hf'><a href='index.php'><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $title;?></div>
		<h1><?php echo $session->data[WiiBBS_ID."wiibbsUser"]?> [<a href='usercenter.php'><?php echo $_['text_userCenter']?></a>]</h1>
		<?php
			$rscount=$msg->getBoxCount($act);
			if($rscount<1)
			{
				echo "<div class='caption'>".$_['tip_noMsg']."</div>";
			}
			$pagesize=15;
			$startRow=0;
			if (empty($_GET['page'])||!is_numeric($_GET['page']))
			{
				$page=1;
			}else{
				$page=$_GET['page'];
				$startRow=($page-1)*$pagesize;
			}
			if ($rscount%$pagesize==0)
			{
				$pagecount=$rscount/$pagesize;
			}else{
				$pagecount=ceil($rscount/$pagesize);
			}
			$msgList=$msg->getBoxList($startRow,$pagesize,$act);
			foreach($msgList as $message)
			{
		?>
		<div class='caption'><a href='msgshow.php?id=<?php echo $message['msg_id']?>&amp;act=<?php echo $act?>'><?php echo $message['msg_title']?></a> 
		<?php 
			If($act=="receive"){ 
				echo "<span class='explain'>";
				If(intval($message["msg_isreader"])==0){
						echo $_['text_unred']; 
				}Else{ 
						echo $_['text_hasred']; 
				}
				echo "</span>";
			}
			?>		[<a href='msg_do.php?act=del&amp;id=<?php echo $message['msg_id']?>&amp;type=<?php echo $act;?>'><?php echo $_['btn_del']?></a>]</div>
		<?php  }
				if ($rscount>$pagesize){
					echo showPage1('msg_list.php?act='.$act,$page,$pagesize,$rscount,$pagecount);
			}			
		?>
		<div class='box'><p>[<a href='usercenter.php'><?php echo $_['btn_goback']?></a>]</p></div>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>