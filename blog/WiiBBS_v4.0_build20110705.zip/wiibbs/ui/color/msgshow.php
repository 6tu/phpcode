<?php

/**
 * msgshow.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/color/msgshow.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	$header_title=$_['text_details'];
	require_once('htmltop.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo($_['tip_returnlogin'],'login.php');
	}
	require_once(THISPATHROOT.'include/lib/msg_wiipu.php');
	$msg=new Msg($registry);
	$act=sqlReplace(trim($_GET['act']));
	$id=sqlReplace(trim($_GET['id']));
	$message=$msg->getMsgById($id);
	if(!$message)
	{
		alertInfo($_['tip_nomsg'],'msg_list.php?act='.$act);
	}
	$msg->updateMsgById($id);
	$noticeClass->updateNoticeState(2);
?>
 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<?php require_once('noticeinc.php');?>
		<div class='hf'><a href='index.php'><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_details']?></div>
		
		<div class='caption'><?php echo $message['msg_title']?><br/>
		<?php 
			if($act=='receive'||$act=='new'){
				echo $_['text_wirter'].$message['msg_send']." [<a href='msg_replay.php?id=".$message['msg_id']."&amp;act=".$act."'>".$_['btn_reply']."</a>] [<a href='msg_do.php?type=".$act."&amp;id=".$message['msg_id']."&amp;act=del'>".$_['btn_del']."</a>] ";
			}else if($act=='send')
			{
				echo $_['text_receiver'].$message['msg_received']." [<a href='msg_do.php?type=".$act."&amp;id=".$message['msg_id']."&amp;act=del'>".$_['btn_del']."</a>]";
			}
		?>
		</div>
		<p><?php echo $_['text_time'].":".$message['msg_addtime'];?></p>
		 <?php 
			$url="act=".$act."&amp;id=".$id;
			mb_internal_encoding("UTF-8");
			if(empty($_GET['all']))
			{
				$all='';
			}else{
				$all=sqlReplace(trim($_GET["all"]));
			}
			$logtextx=HTMLDecode($message['msg_content']);
			$logtextx=$logtextx;
			//开始分页  
			if(!empty($_REQUEST["Page"]))  $page=intval($_REQUEST["Page"]); 
			$PageLength=300;
			$CLength=mb_strLen($logtextx);
			//$str=cutstr($logtextx,$CLength);
			$pagecount=(intval($CLength/$PageLength))+1; 
			$page=!empty($_GET['page'])?sqlReplace(trim($_GET['page'])):1;
			if(($page<1) || (is_null($page))) $page=1; 
			if($page>$pagecount) $Page=$pagecount; 
			if($page==1){
				$a=0; 
			}elseif($page>1){ 
				$a=($page-1)*$PageLength; 
			}
			
			If($all=="all"){
				$wen=mb_substr($logtextx,$a);
			}Else{
				$wen=mb_substr($logtextx,$a,$PageLength); 
			} 
			echo "<p>".$wen."</p>"; 
			echo "<p>"; 
			If($pagecount>1){
				echo morePage('msgshow.php?'.$url,$page,$PageLength,$CLength,$pagecount);
			}
			echo "</p>"; 
        ?>
		<div class='box'><p>[<a href='msg_list.php?act=<?php echo $act;?>'><?php echo $_['btn_goback'];?></a>]</p></div>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>