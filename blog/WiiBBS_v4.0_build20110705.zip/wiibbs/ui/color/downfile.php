<?php

/**
 * downfile.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

define('THISPATHROOT', str_replace('ui/color/downfile.php', '', str_replace('\\', '/', __FILE__)));
require_once(THISPATHROOT.'include/db_conn.php');
$file_id=sqlReplace(trim($_GET['filename']));
$url=sqlReplace(trim($_GET['url']));
$f_type=empty($_GET['type'])?'':sqlReplace(trim($_GET['type']));
$row=$topic->getFileById($file_id);
if ($row){
	$file=$row['file_url'];
}else
	checkData($_['alert_nofile'],'1','topicshow.php?'.$url);
if (!empty($f_type)){
	if ($f_type=='y')
		$filename=NETURL."/userfiles/attach/".$file;
	else if ($f_type=='h')
		$filename=NETURL."/userfiles/high/".$file;
	else if ($f_type=='b')
		$filename=NETURL."/userfiles/small/".$file;
	else if ($f_type=='s')
		$filename=NETURL."/userfiles/smaller/".$file;
}else
	$filename=NETURL."/userfiles/attach/".$file;

header("Content-Type: application/force-download");
header("Content-Disposition: attachment; filename=".basename($filename)); 
readfile($filename);
?>