<?php

/**
 * index.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/color/boardlist.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once('htmltop.php');
	$POSITION_BOARD="on";
	$session->data['setSkipUrl']=getUrl();
	$session->data['setUrl']=getUrl();
?>

 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<?php require_once('noticeinc.php');?>
		<?php require_once('logininc.php');?>
		<?php require_once('tab.php');?>
		<?php
			$classList=$board->getBoardClassList();
			foreach ($classList as $row){
				echo "<h1>".$row['boardclass_name']."</h1>";
				$boardList=$board->getBoardList($row['boardclass_id']);
				foreach($boardList as $rows){
					echo "<div class='caption'><a href='board.php?bd=".$rows['board_id']."'>".$rows['board_name']."</a></div>";
				}
			}
		?>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>
