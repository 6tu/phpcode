<?php

/**
 * usercenter.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/color/usercenter.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	$header_title=$_['text_userCenter'];
	require_once('htmltop.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo($_['tip_returnlogin'],'login.php');
	}

?>
 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<?php require_once('noticeinc.php');?>
		<div class='hf'><a href="index.php"><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_userCenter'];?></div>
		<h1><?php echo $_['text_myBox'];?></h1>
		<div class='caption'><a href='msg_send.php?url=<?php echo urlencode($funcSysten->getUrl());?>'><?php echo $_['text_writeBox'];?></a></div>
		<div class='caption'><a href='msg_list.php?act=new'><?php echo $_['text_unredBox'];?></a></div>
		<div class='caption'><a href='msg_list.php?act=receive'><?php echo $_['text_inBox'];?></a></div>
		<div class='caption'><a href='msg_list.php?act=send'><?php echo $_['text_outBox'];?></a></div>
		<h1><?php echo $_['text_myStuff'];?></h1>
		<div class='caption'><a href='userdata.php'><?php echo $_['text_myStuff'];?></a></div>
		<div class='caption'><a href='useredit.php'><?php echo $_['text_editStuff'];?></a></div>
		<div class='caption'><a href='userpassword.php'><?php echo $_['text_editPwd'];?></a></div>
		<h1><?php echo $_['text_myTopic'];?></h1>
		<div class='caption'><a href='mytopic.php'><?php echo $_['text_mySendTopic'];?></a></div>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

