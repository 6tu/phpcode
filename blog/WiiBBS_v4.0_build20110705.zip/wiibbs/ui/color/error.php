<?php

/**
 * error.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

define('THISPATHROOT', str_replace('ui/color/error.php', '', str_replace('\\', '/', __FILE__)));
require_once(THISPATHROOT.'include/db_conn.php');
require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
require_once('htmltop.php');
$rcode=intval(rand()*1000);
$url=(empty($_GET["url"]))?"":$_GET['url'];
$id=(empty($_GET["id"]))?"":$_GET['id'];
$key=(empty($_GET["key"]))?"":$_GET['key'];
$bd=(empty($_GET["bd"]))?"":$_GET['bd'];
$uid=(empty($_GET["uid"]))?"":$_GET['uid'];
if(!empty($_GET['db']))
{
$db=$_GET['db'];
}else{
$db="";
}
$WPErr=array();

if (empty($session->data['setSkipUrl']))
	$skipUrl="[<a href='boardlist.php'>".$_['text_m_backBoard']."</a>]";
else
	$skipUrl="[<a href='".$session->data['setSkipUrl']."'>".$_['btn_back']."</a>]";
$WPErr[137]=$_['error_username']."<br/>[<a href='login.php?key=".$key."&amp;id=".$id."&amp;bd=".$bd."&amp;uid=".$uid."'>".$_['text_m_login']."</a>]";
$WPErr[139]=$_['alert_boardLogin']."<br/>[<a href='register.php?key=".$key."&amp;id=".$id."&amp;bd=".$bd."&amp;uid=".$uid."'>".$_['text_m_reg']."</a>]".$skipUrl;
$WPErr[140]=$_['alert_boardvip']."<br/>".$skipUrl;
$WPErr[204]=$_['alert_boardMember']." <br/> ".$skipUrl;
?>

	
 <body>
	<p><?php echo $_['text_promptTopic']?>！</p>
	<p class="red"><?php echo $WPErr[Trim($_GET["err"])]?></p>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>
