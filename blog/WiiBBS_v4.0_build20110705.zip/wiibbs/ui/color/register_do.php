<?php

/**
 * register_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/color/register_do.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	$account=sqlReplace(trim($_POST['account']));
	checkData($account,$_['text_account'],1,'register.php');
	$password=sqlReplace(trim($_POST['pwd']));
	checkData($password,$_['text_password'],1,'register.php');
	$password2=sqlReplace(trim($_POST['pwd2']));
	checkData($password2,$_['text_confirmPwd'],1,'register.php');
	if($password!=$password2)
	{
		alertInfo($_['tip_noequalPw'],'register.php');
	}
	$email=empty($_POST['email'])?"":sqlReplace(trim($_POST['email']));
	$fbarr=explode('|',FBDSTR);
	if(in_array(strtolower($account),$fbarr))
	{
		alertInfo($_['tip_forbidAccount'],'register.php');
	}
	if(accountCheckModule=='0')
	{
		If(strLen($account)<accountMinLength || strLen($account)>accountMaxLength){
			alertInfo($_['tip_accounLength'].accountMinLength.$_['tip_to'].accountMaxLength.$_['tip_center'],'register.php');
		}
	}elseif(accountCheckModule=='1')
	{
		if(!preg_match("/^\d{".accountMinLength.",".accountMaxLength."}$/",$account))
		{
			alertInfo($_['tip_allowNum'],'register.php');
		}
	}elseif(accountCheckModule=='2')
	{
		if(!preg_match("/^[a-zA-z]{".accountMinLength.",".accountMaxLength."}$/",$account))
		{
			alertInfo($_['tip_allowLetter'],'register.php');
		}
	}elseif(accountCheckModule=='3')
	{
		if(!preg_match("/^[a-zA-z0-9-]{".accountMinLength.",".accountMaxLength."}$/",$account))
		{
			alertInfo($_['tip_allowCommon'],'register.php');
		}
	}
	$user=array('user_account'=>$account,'user_password'=>$password,'user_mobile'=>'','user_email'=>$email);
	$result=$wiibbsUser->register($user,0);
	switch($result)
	{
		case '1':
			alertInfo($_['tip_accountexist'],'register.php');
		break;
		case '2':
			alertInfo($_['tip_updateEmail'],'register.php');
		break;
		case '3':
			alertInfo($_['suc_register'],'login.php');
		break;
		case '4':
			alertInfo($_['error_register'],'register.php');
		break;
		case '5':
			alertInfo($_['tip_emailexist'],'register.php');
		break;
		case '6':
			alertInfo($_['tip_timeOut'],'register.php');
		default:
			alertInfo($_['tip_exception'],'register.php');
	}
	
?>