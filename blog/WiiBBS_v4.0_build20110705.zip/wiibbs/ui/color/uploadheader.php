<?php

/**
 * uploadheader.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/color/uploadheader.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	$header_title=$_['text_upload'];
	require_once('htmltop.php');
	require_once('usercheck.php');
	$user=$wiibbsUser->getUserByAccount();
?>
 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<div class='hf'>WIIBBS论坛&gt;&gt;<?php echo $_['text_upload'];?></div>
		<div class='comment'>
			<?php
				if(!empty($user['user_photo'])&&file_exists(ROOT_PATH.'userfiles/header/pic/'.$user['user_photo']))
				{
					$imgs=getimagesize(ROOT_PATH.'userfiles/header/pic/'.$user['user_photo']);
					echo "<p><img src='".NETURL.'/userfiles/header/pic/'.$user['user_photo']."' width='".$imgs[0]."' height='".$imgs[1]."'/></p>";
				}
			?>
			<form action='user_do.php?act=upload' method='post' enctype="multipart/form-data">
				<p><input type='file' name='file'/></p>
				<p><input inputmode="user predictOn" type="submit" value="<?php echo $_['btn_upload']?>"/></p>
			</form>
			<div class='point'><?php echo $_['tip_commom'];?>:<br/>
				<?php echo $_['tip_upload1'];?><br/>
				<?php echo $_['tip_upload2'];?><br/>
			</div>
		<div class='box'><p>[<a href='usercenter.php'><?php echo $_['btn_goback'];?></a>]</p></div>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>