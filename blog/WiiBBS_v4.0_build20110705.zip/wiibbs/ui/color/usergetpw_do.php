<?php

/**
 * usergetpw_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/color/usergetpw_do.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(THISPATHROOT.'include/lib/mail_common.php');
	require_once(THISPATHROOT.'config.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	$act=sqlReplace(trim($_GET['act']));
	switch($act)
	{
		case 'step1':
		$account=sqlReplace(trim($_POST['account']));
		checkData($account,$_['text_account'],1,'usergetpw.php');
		$email=sqlReplace(trim($_POST['email']));
		checkData($email,$_['text_email'],1,'usergetpw.php');
		$result=$wiibbsUser->getPw($account,$email);
		switch($result)
		{
			case '1':
				$code=$wiibbsUser->setVerCode($account);
				if($code)
				{
					$mailcontent="<a href='".NETURL."/ui/color/usergetpw2.php?account=".$account."&vercode=".$code."'>".$_['btn_clickhere']."</a>".$_['text_restpw'];
					$smtp=new smtp(MAILSMTP,25,true,MAILACCOUNT,MAILAPASSWORD,MAILADDRESS);
					$subject=$_['text_mailTile'];
					$body=$mailcontent;
					$mailtype='HTML';
					$send=$smtp->sendmail($email,MAILADDRESS,$subject,$body,$mailtype);
					alertInfo($_['suc_forgetPw1'],'login.php');
				}else{
					alertInfo($_['tip_exception'],'usergetpw.php');
				}
			break;
			case '2':
				alertInfo($_['error_forgetPw1'],'usergetpw.php');
			break;
		}
		break;
		case 'step2':
			$account=sqlReplace(trim($_POST['account']));
			$vercode=sqlReplace(trim($_POST['vercode']));
			$pw1=sqlReplace(trim($_POST['pwd1']));
			checkData($pw1,$_['text_newPwd'],1,"usergetpw2.php?account=$account&vercode=$vercode");
			$pw2=sqlReplace(trim($_POST['pwd2']));
			checkData($pw2,$_['text_confirmPwd'],1,'usergetpw2.php?account='.$account.'&vercode='.$vercode);
			if($pw1!=$pw2)
			{
				alertInfo($_['tip_noequalPw'],'usergetpw2.php?account='.$account.'&vercode='.$vercode);
			}
			if($wiibbsUser->setPw($account,$pw1))
			{
				alertInfo($_['suc_forgetPw2'],'login.php');
			}else{
				alertInfo($_['error_forgetPw2'],'usergetpw2.php?account='.$account.'&vercode='.$vercode);
			}
	}
	
?>