<?php

/**
 * search.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/color/search.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(THISPATHROOT.'include/lib/keyword_wiipu.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/applications.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	$header_title=$_['text_searchTopic'];
	require_once('htmltop.php');
	require_once('usercheck.php');
	$keyword=new KeyWord($registry);
?>
 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<?php require_once('noticeinc.php');?>
		<?php require_once('logininc.php');?>
		<div class='hf'><a href="index.php"><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_searchTopic'];?></div>
		<div class='caption'>
			<form action='' method='get'>
				<input inputmode="user predictOn" type='text' name='search'/>
				<input inputmode="user predictOn" type='submit' value='<?php echo $_['btn_search'];?>'/>
			</form>
		</div>
		<?php
			$search=empty($_GET['search'])?'':sqlReplace(trim($_GET['search']));
			
			if(!empty($search))
			{
				if (SITEFILTER!=''){
				$filter=str_replace("，",',',SITEFILTER);
				$filters=explode(",",$filter);
				for($i=0;$i<count($filters);$i++)
				{
					if(strpos($search,$filters[$i])>-1)
					{
						alertInfo($_['alert_filter_r'],'search.php');
					}
				}
			}
				
				$keyword->operateKey($search);
				$topicList=$topic->searchTopic($search,0,10);
				if (count($topicList)>1)
					echo "<div class='caption'>“".$search."”".$_['tip_search']."</div>";
				
					foreach($topicList as $top)
					{
		?>
						<p> <a href="topicshow.php?bd=<?php echo $top["topic_board"]?>&amp;id=<?php echo  $top["topic_id"]?>&amp;rnd=<?php echo rand();?>"><?php echo  $top["topic_title"]?></a></p>
		<?php
					}
			}else{
				$keyList=$keyword->getKeyList(10);
				
				foreach($keyList as $key)
				{
					echo "<p><a href='search.php?search=".$key['keyword_name']."'>".$key['keyword_name']."</a></p>";
				}
			}
		?>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>
