<?php

/**
 * msg_send.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/color/msg_send.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo($_['tip_returnlogin'],'login.php');
	}
	$header_title=$_['text_writeBox'];
	require_once('htmltop.php');
	$uid=empty($_GET['uid'])?'':sqlReplace(trim($_GET['uid']));
	$url=sqlReplace($_GET['url']);
?>
 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<?php require_once('noticeinc.php');?>
		<div class='hf'><a href='index.php'><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_writeBox'];?></div>
		<div class='comment'>
			<form action='msg_do.php?act=add' method='post'>
				<p><?php echo $_['text_receiver'];?>：<input inputmode="user predictOn" type='text' name='receiver' value="<?php echo $uid;?>"/><input inputmode="user predictOn" type='hidden' name='url' value="<?php echo $url;?>"/></p>
				<p>　<?php echo $_['text_title'];?>：<input inputmode="user predictOn" type="text" name="title"/></p>
				<p>　<?php echo $_['text_content'];?>：</p>
				<p><textarea cols="30" rows="3" name="content"></textarea></p>
				<p><input inputmode="user predictOn" type="submit" value="<?php echo $_['btn_submit']?>"/></p>
			</form>
			<div class='point'><?php echo $_['tip_commom'];?>:<br/>
				<?php echo $_['tip_send1'];?><br/>
				<?php echo $_['tip_send2'];?><br/>
				<?php echo $_['tip_send3'];?><br/></div>
		</div>
		<div class='box'><p>[<a href='<?php echo urldecode($url);?>'><?php echo $_['btn_goback'];?></a>]</p></div>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>