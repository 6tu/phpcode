<?php

/**
 * useredit.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/color/useredit.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	$header_title=$_['text_editStuff'];
	require_once('htmltop.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo($_['tip_returnlogin'],'login.php');
	}
	$user=$wiibbsUser->getUserByAccount();
?>
 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<?php require_once('noticeinc.php');?>
		<div class='hf'><a href='index.php'><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_editStuff'];?></div>
		<div class='comment'>
			<form action='user_do.php?act=edit' method='post'>
				<p><?php echo $_['text_nikeName'];?>：<input inputmode="user predictOn" type='text' name='nikename' value="<?php echo $user['user_nickname']?>"/></p>
				<p><?php echo $_['text_name'];?>：<input inputmode="user predictOn" type='text' name='name' value="<?php echo $user['user_name']?>"/></p>
				<p><?php echo $_['text_email'];?>：<input inputmode="user predictOn" type='text' name='email' value="<?php echo $user['user_email']?>"/></p>
				<p><?php echo $_['text_sex'];?>：<?php if($user['user_sex']==1){?><input inputmode="user predictOn" type='radio' name='sex' value='1' checked/><?php echo $_['text_man']?><input inputmode="user predictOn" type='radio' name='sex' value='2'/><?php echo $_['text_women'];?><?php } else if($user['user_sex']==2){?> <input inputmode="user predictOn" type='radio' name='sex' value='1'/><?php echo $_['text_man']?><input inputmode="user predictOn" type='radio' name='sex' value='2' checked/><?php echo $_['text_women'];?><?php }else{ ?><input inputmode="user predictOn" type='radio' name='sex' value='1'/><?php echo $_['text_man']?><input inputmode="user predictOn" type='radio' name='sex' value='2'/><?php echo $_['text_women'];?><?php } ?></p>
				<p><?php echo $_['text_province'];?>：<input inputmode="user predictOn" type='text' name='province' value="<?php echo $user['user_province']?>"/></p>
				<p><?php echo $_['text_city'];?>：<input inputmode="user predictOn" type='text' name='city' value="<?php echo $user['user_city']?>"/></p>
				<p><?php echo $_['text_address'];?>：<input inputmode="user predictOn" type='text' name='address' value="<?php echo $user['user_address']?>"/></p>
				<p><?php echo $_['text_brith'];?>：<input inputmode="user predictOn" type='text' name='brith' value="<?php echo $user['user_birthday']?>"/></p>
				<p><?php echo $_['text_qq'];?>：<input inputmode="user predictOn" type='text' name='qq' value="<?php echo $user['user_qq']?>"/></p>
				<p><?php echo $_['text_mobile'];?>：<input inputmode="user predictOn" type='text' name='mobile' value="<?php echo $user['user_mobile']?>"/></p>
				<p><?php echo $_['text_sina'];?>：<input inputmode="user predictOn" type='text' name='sina' value="<?php echo $user['user_sina']?>"/></p>
				<p><input inputmode="user predictOn" type="submit" value="<?php echo $_['btn_submit']?>"/> [<a href='usercenter.php'><?php echo $_['btn_goback'];?></a>]</p>
			</form>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>