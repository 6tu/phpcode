<?php

/**
 * tab.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

?>
<p>

		<form action="boardjump.php" method="post">
					<?php echo $_['text_switch'];?>：<select name="board">
						<?php
							$boardList=$board->getBoardList($boardClass,$bd);
							foreach ($boardList as $row){
								echo "<option value='".$row['board_id']."'";
								echo">".$row['board_name']."</option>";
							}
						?>
					</select> <input inputmode="user predictOn" type="submit" value="<?php echo $_['text_skip'];?>"/>
				</form>
</p>