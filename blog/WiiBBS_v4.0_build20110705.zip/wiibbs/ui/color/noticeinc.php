<?php

/**
 * noticeinc.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	 $userName=$wiibbsUser->checkISlogin();
	if (!empty($userName)){
		
		$row_r=$noticeClass->getNotice(1);
		if ($row_r){
			$replyCount=$row_r['notice_count'];
			$url_notice=$row_r['notice_url'];
		}else{
			$replyCount=0;
			$url_notice='';
		}
		$row_m=$noticeClass->getNotice(2);
		if ($row_m){
			$mailCount=$row_m['notice_count'];
		}else{
			$mailCount=0;
		}
?>
		<div class='login'>
			<?php	
				if ($mailCount>0){
					echo "<p class='red'><a href='msg_list.php?act=new' class='notice'>".$_['text_noticeHave'].$mailCount.$_['text_noticeEmial']."</a></p>";
				}else if ($replyCount>0)
					echo "<p class='red'><a href=\"".$url_notice."\" class='notice'>".$_['text_noticeHave'].$replyCount.$_['text_noticeReply']."</a></p>";
			?>
		</div>
<?php
	}	
?>