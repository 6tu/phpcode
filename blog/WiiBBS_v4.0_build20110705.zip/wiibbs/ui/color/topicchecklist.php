<?php

/**
 * topicchecklist.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/color/topicchecklist.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	require_once('checklogin.php');
	if (!($manager || $userGroup)) alertInfo($_['alert_noLimit'],'board.php?bd='.$bd);
	$header_title=$_['text_check'];
	require_once('htmltop.php');
?>
 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<?php require_once('noticeinc.php');?>
		<?php require_once('logininc.php');?>
		<div class='hf'><a href="index.php"><?php echo $_['text_index']?></a>&gt;&gt;<a href='board.php?bd=<?php echo $bd?>'><?php echo $bdName?></a>&gt;&gt;<?php echo $_['text_check']?></div>
		<?php
				$page=(empty($_GET['page']))?"":$_GET['page'];
				if (empty($page)||!is_numeric($page))$page=1;
				$pagesize=15;
				$startRow=0;
				$startRow=($page-1)*$pagesize;
				$rscount=$topic->getTopicCount($bd,'',0,1);
				if ($rscount%$pagesize==0)
					$pagecount=$rscount/$pagesize;
				else
					$pagecount=ceil($rscount/$pagesize);
				$topicList=$topic->getCheckTopic($bd,'0',$startRow,$pagesize,$page,'topic_updatetime','desc','1','',$keyword='');
				if ($pagecount>1){
					echo showPage1('topicchecklist.php?bd='.$bd,$page,$pagesize,$rscount,$pagecount);
				}
			
		?>
		<?php 
			$session->data['setSkipUrl']=getUrl();
			require_once('boardswitch.php');
		?>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>
