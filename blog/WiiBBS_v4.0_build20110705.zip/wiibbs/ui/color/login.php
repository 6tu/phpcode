<?php

/**
 * login.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/color/login.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	$header_title=$_['text_memberLogin'];
	require_once('htmltop.php');
	
?>
 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<div class='hf'><a href="index.php"><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_memberLogin']?></div>
		<h1><?php echo $_['text_memberLogin']?>  <a href='register.php'><?php echo $_['text_userRegister'];?></a></h1>
		<div class='caption'>
			<form action='userlogin_do.php' method='post'>
				<p><?php echo $_['text_accountoremail'];?>：<input inputmode="user predictOn" type='text' name='account'/></p>
				<p>　　 　　　 <?php echo $_['text_password'];?>：<input  inputmode="user predictOn" type='password' name='pwd'/></p>
				<p><input inputmode="user predictOn" type='checkbox' name='cookie' checked="checked"  value='2' /><?php echo $_['text_remberCookie'];?></p>
				<p><input inputmode="user predictOn" type='submit' value='<?php echo $_['btn_login']?>'/>　<a href='usergetpw.php'><?php echo $_['btn_forgetpw'];?></a></p>
			</form>
			<div class='point'>
				<?php echo $_['tip_tips'];?><br/>
				<?php echo $_['tip_login1'];?><br/>
				<?php echo $_['tip_login2'];?><br/>
			</div>
		</div>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

