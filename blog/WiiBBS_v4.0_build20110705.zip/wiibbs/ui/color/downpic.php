<?php

/**
 * downpic.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/color/downpic.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once('usercheck.php');
	$header_title=$_['header_dowm'];
	require_once('htmltop.php');
	$file_id=sqlReplace(trim($_GET['filename']));
	$id=sqlReplace(trim($_GET['id']));
	$bd=sqlReplace(trim($_GET['bd']));
	$page=sqlReplace(trim($_GET['page']));
	
	if(empty($_GET['t'])){
		$t="";
	}else{
		$t=sqlReplace(trim($_GET['t']));
	}
	if(!empty($t)){
		$url="topicreplylist.php?id=".$id."&amp;t=".$t."&amp;page=".$page."&amp;bd=".$bd;
	}else{
		$url="topicshow.php?id=".$id."&amp;bd=".$bd."&amp;page=".$page;
	}
	if(!file_exists(ROOT_PATH."userfiles/high/".$file)){
		alertInfo($_['alert_noPic'],$url);
	}
	$row=$topic->getFileById($file_id);
	if ($row){
		$file=$row['file_url'];
	}
?>

 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<?php require_once('noticeinc.php');?>
		<div class='hf'><a href="index.php"><?php echo $_['text_index']?></a>&gt;&gt;<?php echo $_['text_picDown']?></div>
		<div class='comment'>
		<?php
		
			$img=getimagesize(NETURL."/userfiles/high/".$file);
			echo "<p><img src='".NETURL."/userfiles/high/".$file."' width='".$img[0]."' height='".$img[1]."'/></p>";
			echo "<p><a href='downfile.php?filename=".$file_id."&amp;type=y'>".$_['text_oldPic']."</a><br/><a href='downfile.php?filename=".$file_id."&amp;type=h'>".$_['text_highPic']."</a><br/><a href='downfile.php?filename=".$file_id."&amp;type=b'>".$_['text_smallPic']."</a><br/><a href='downfile.php?filename=".$file_id."&amp;type=s'>".$_['text_smallerPic']."</a><br/><a href='".$url."'>".$_['btn_goback']."</a> </p>";
		?>	
		</div>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>
