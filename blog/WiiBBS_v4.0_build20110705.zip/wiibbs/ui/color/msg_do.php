<?php

/**
 * msg_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/color/msg_do.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(THISPATHROOT.'include/lib/msg_wiipu.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo($_['tip_returnlogin'],'login.php');
	}
	$act=sqlReplace(trim($_GET['act']));
	$msg=new Msg($registry);
	switch($act)
	{
		case 'add':
			$url=sqlReplace(trim($_POST['url']));
			$arr['msg_received']=sqlReplace(trim($_POST['receiver']));
			checkData($arr['msg_received'],$_['text_receiver'],1,'msg_send.php?url='.$url);
			$arr['msg_title']=sqlReplace(trim($_POST['title']));
			checkData($arr['msg_title'],$_['text_title'],1,'msg_send.php?url='.$url);
			$arr['msg_content']=sqlReplace(trim($_POST['content']));
			checkData($arr['msg_content'],$_['text_content'],1,'msg_send.php?url='.$url);
			if(!$wiibbsUser->checkAccount($arr['msg_received']))
			{
				alertInfo($_['tip_noReceiver'],'msg_send.php?url='.$url);
			}
			if($arr['msg_received']==$session->data[WiiBBS_ID."wiibbsUser"])
			{
				alertInfo($_['tip_noSendSelf'],'msg_send.php?url='.$url);
			}
			$msg->addInbox($arr);
			$msg->addOutbox($arr);
			$title="���µ�վ����";
			$url='';
			$funcSysten->sendNotice($title,$url,$arr['msg_received'],'2');
			alertInfo($_['suc_send'],'msg_send.php?url='.$url);
			break;
		case 'del':
			$type=sqlReplace(trim($_GET['type']));
			$id=sqlReplace(trim($_GET['id']));
			$msg->deletMsgById($id);
			alertInfo($_['suc_del'],'msg_list.php?act='.$type);
			break;
		case 'reply':
			$id=sqlReplace(trim($_POST['id']));
			$type=sqlReplace(trim($_GET['type']));
			$arr['msg_received']=sqlReplace(trim($_POST['receiver']));
			$arr['msg_title']=sqlReplace(trim($_POST['title']));
			checkData($arr['msg_title'],$_['text_title'],1,'msg_replay.php?id='.$id.'&act='.$type);
			$arr['msg_content']=sqlReplace(trim($_POST['content']));
			checkData($arr['msg_content'],$_['text_content'],1,'msg_replay.php?id='.$id.'&act='.$type);
			$msg->addInbox($arr);
			$msg->addOutbox($arr);
			alertInfo($_['suc_reply'],'msg_list.php?act='.$type);

	}
?>