<?php

/**
 * topicdeal.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/color/topicdeal.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	require_once('checklogin.php');
	$header_title=$_['header_delTopic'];
	require_once('htmltop.php');
	$act=sqlReplace(trim($_GET["act"]));
	$rcode=intval(rand()*1000);
	switch ($act){
		case 'doDel':
			$id=sqlReplace(Trim($_GET["id"]));
			$id=intval($id);
			$t=empty($_GET["t"])?'':sqlReplace(Trim($_GET["t"]));
			if (empty($t)){
				$url='topicshow.php';
				$url_1='board.php';
			}else{
				$url='topiccheck.php';
				$url_1='topicchecklist.php';
			}
			$result=$topic->delTopic($id,$bd,$manager,$userGroup,$userName);
			if ($result==1){
				alertInfo($_['alert_noLimit'],$url.'?bd='.$bd.'&amp;id='.$id);
			}else if ($result==2){
				header("location:".NETURL."/ui/".$folder_color."/".$url_1."?bd=".$bd);
				exit();
			}else if ($result==4){
				alertInfo($_['alert_errordel'],$url.'?bd='.$bd.'&amp;id='.$id);
			}
		break;
		case 'doDelReply':
			$id=sqlReplace(Trim($_GET["id"]));
			$rid=sqlReplace(Trim($_GET["rid"]));
			$key=sqlReplace(Trim($_GET["key"]));
			if (empty($key))
				$url='topicshow.php';
			else
				$url='topicreplylist.php';
			$result=$topic->delReply($id,$bd,$rid,$manager,$userGroup,$userName);
			if ($result==1){
				alertInfo(	$_['alert_noLimit'],$url.'?bd='.$bd.'&amp;id='.$id);
			}else if ($result==2){
				alertInfo($_['alert_postdel'],$url.'?bd='.$bd.'&amp;id='.$id);
			}else if ($result==4){
				alertInfo($_['alert_errordel'],$url.'?bd='.$bd.'&amp;id='.$id);
			}
		break;
	}
?>

 <body>
		<?php
			switch ($act){
				case 'del';
					$id=sqlReplace(Trim($_GET["id"]));
					$id=intval($id);
					$t=empty($_GET["t"])?'':sqlReplace(Trim($_GET["t"]));
					if (empty($t))
						$url='topicshow.php';
					else
						$url='topiccheck.php';
					echo "<div class=\"s\"></div>";
					echo "<div class=\"nm\">";
					echo $_['text_sureDel'].'<br/><br/>';
					echo "<a href='topicdeal.php?act=doDel&amp;bd=".$bd."&amp;id=".$id."&amp;t=".$t."'>".$_['btn_certain']."</a> <a href='".$url."?bd=".$bd."&amp;id=".$id."'>".$_['btn_cancel']."</a>";
					echo '</div>';
					echo "<div class=\"s\"></div>";
				break;
				case 'move';
					$bd=sqlReplace(Trim($_GET["bd"]));
					$oldbd=sqlReplace(Trim($_GET["oldbd"]));
					echo "<div class=\"s\"></div>";
					echo "<div class=\"nm\">";
					echo $_['alert_successMove'].'<br/><br/>';
					echo "<a href='board.php?bd=".$oldbd."'>".$_['text_oldBorder']."</a> <a href='board.php?bd=".$bd."'>".$_['text_newBorder']."</a>";
					echo '</div>';
					echo "<div class=\"s\"></div>";
				break;
				case 'delReply';
					$id=sqlReplace(Trim($_GET["id"]));
					$rid=sqlReplace(Trim($_GET["rid"]));
					$key=sqlReplace(Trim($_GET["key"]));
					if (empty($key))
						$url='topicshow.php';
					else
						$url='topicreplylist.php';
					echo "<div class=\"s\"></div>";
					echo "<div class=\"nm\">";
					echo $_['text_sureDelReply'].'<br/><br/>';
					echo "<a href='topicdeal.php?act=doDelReply&amp;bd=".$bd."&amp;id=".$id."&amp;rid=".$rid."&amp;key=".$key."'>".$_['btn_certain']."</a> <a href='".$url."?bd=".$bd."&amp;id=".$id."'>".$_['btn_cancel']."</a>";
					echo '</div>';
					echo "<div class=\"s\"></div>";
				break;
			}
		?>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>

