<?php

/**
 * user.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/color/user.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	$header_title=$_['text_memberInformation'];
	require_once('htmltop.php');
	require_once('usercheck.php');
	$id=sqlReplace(trim($_GET['id']));
	$url=sqlReplace(trim($_GET['url']));
	$user=$wiibbsUser->getUserByAccount($id);
?>
 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<?php require_once('noticeinc.php');?>
		<div class='hf'><a href="index.php"><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_memberInformation'];?></div>
		<p><?php echo $_['text_nikeName'];?>：<?php echo $user['user_nickname']?></p>
		<p><?php echo $_['text_score'];?>：<?php echo $user['user_score']?></p>
		<p><?php echo $_['text_grade'];?>：<?php echo $user['user_grade']?></p>
		<p><?php echo $_['text_regTime'];?>：<?php echo $user['user_regtime']?></p>
		<p><?php echo $_['text_logCount'];?>：<?php echo $user['user_logincount']?></p>
		<p><?php echo $_['text_lastLoginTime'];?>：<?php echo $user['user_lastlogin']?></p>
		<p>[<a href='msg_send.php?uid=<?php echo $user['user_account']?>&url=<?php echo urlencode($funcSysten->getUrl());?>'><?php echo $_['text_sendMsg'];?></a>]<?php if (!empty( $userName)){?>[<a href='userdeatils.php?uid=<?php echo $user['user_account']?>&url=<?php echo urlencode($funcSysten->getUrl());?>'><?php echo $_['text_details'];?></a>]<?php }?>  [<a href='<?php echo $url?>'><?php echo $_['btn_goback']?></a>]</p>
		<?php require_once('bottom.php');?>
		</div>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>