<?php

/**
 * header.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

?><div id='header'>
	<?php 
		if(SITELOGO!=''){
			$imagesize=getimagesize(NETURL."/".SITELOGO);
			$width=$imagesize[0];
			$height=$imagesize[1];
			echo "<div id='logo'><img src='".NETURL."/".SITELOGO."' alt='".SITENAME."' width='".$width."' height='".$height."'/></div>";
		}else{
			echo "<div id='slogan'>".SITENAME."</div>";
		}		
	?>
</div>