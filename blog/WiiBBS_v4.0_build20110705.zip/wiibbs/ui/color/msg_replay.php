<?php

/**
 * msg_reply.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/color/msg_replay.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	require_once(THISPATHROOT.'include/lib/msg_wiipu.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo($_['tip_returnlogin'],'login.php');
	}
	$msg=new Msg($registry);
	$act=sqlReplace(trim($_GET['act']));
	$id=sqlReplace(trim($_GET['id']));
	$message=$msg->getMsgById($id);
	if(!$message)
	{
		alertInfo($_['tip_nomsg'],'msg_list.php?act='.$act);
	}
	$header_title=$_['text_writeBox'];
	require_once('htmltop.php');
?>
 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<?php require_once('noticeinc.php');?>
		<div class='hf'><a href='index.php'><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_writeBox'];?></div>
		<div class='comment'>
			<form action='msg_do.php?act=reply&type=<?php echo $act;?>' method='post'>
				<p><?php echo $_['text_receiver'].$message['msg_send'];?> <input inputmode="user predictOn" type='hidden' name='receiver' value='<?php echo $message['msg_send'];?>'/> <input type='hidden' name='id' value='<?php echo $id?>'></p>
				<p>　<?php echo $_['text_title'];?>：<input inputmode="user predictOn" type="text" name="title" value="回复：<?php echo $message['msg_title']?>"/></p>
				<p>　<?php echo $_['text_content'];?>：</p>
				<p><textarea cols="30" rows="3" name="content"></textarea></p>
				<p><input inputmode="user predictOn" type="submit" value="<?php echo $_['btn_submit']?>"/></p>
			</form>
			<div class='point'><?php echo $_['tip_commom'];?>:<br/>
				<?php echo $_['tip_reply1'];?><br/>
				<?php echo $_['tip_reply2'];?><br/></div>
		</div>
		<div class='box'><p>[<a href='usercenter.php'><?php echo $_['btn_goback'];?></a>]</a></p></div>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>