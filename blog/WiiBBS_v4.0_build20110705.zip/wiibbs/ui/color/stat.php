<?php

/**
 * stat.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/color/stat.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/applications.php');
	$header_title=$_['text_Lcount'];
	require_once('htmltop.php');
	require_once(THISPATHROOT.'include/lib/stat_wiipu.php');
	if(SITECOUNT!=1)
	{
		alertInfo($_['tip_pageExpired'],'index.php');
	}
	$stat=new wiiStat($registry);
?>
 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<?php require_once('noticeinc.php');?>
		<?php require_once('logininc.php');?>
		<div class='hf'><a href="index.php"><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_Lcount']?></div>
		<p><span class='explain'><?php echo $_['text_online'];?>：</span><?php echo $stat->getOnlineCount();?></p>
		<p><span class='explain'><?php echo $_['text_memberCount'];?>：</span><?php echo $stat->getMemberCount();?></p>
		<p><span class='explain'><?php echo $_['text_topicCount'];?>：</span><?php echo $stat->getTopicCount();?> </p>
		<p><span class='explain'><?php echo $_['text_cenusCount'];?>：</span><?php echo $stat->getCensusCount();?></p>
		<p><span class='explain'><?php echo $_['text_todayFlow'];?>：</span><?php echo $stat->getTodayCount();?> </p>
		<p><span class='explain'><?php echo $_['text_allFlow'];?>：</span><?php echo $stat->getAllCount();?></p>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>