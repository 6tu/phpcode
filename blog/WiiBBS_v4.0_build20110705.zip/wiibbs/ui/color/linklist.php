<?php

/**
 * linklist.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/color/linklist.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/applications.php');
	$header_title=$_['text_links'];
	require_once('htmltop.php');
	require_once('usercheck.php');
	require_once(THISPATHROOT."include/lib/link_wiipu.php");
	$links=new Links($registry);
?>
 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<?php require_once('noticeinc.php');?>
		<?php require_once('logininc.php');?>
		<div class='hf'><a href="index.php"><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_links'];?></div>
		<?php
			$linkList=$links->getLinkList();
			if(count($linkList)<1)
			{
				echo "<div class='caption'>".$_['tip_noLink']."</div>";
			}
			foreach($linkList as $link)
			{
				echo "<div class='caption'><a href='".$link['link_url']."' target='_blank'>".$link['link_title']."</a></div>";
			}
		?>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>
