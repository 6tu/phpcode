<?php

/**
 * userpassword.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/color/userpassword.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/msg.php');
	$header_title=$_['text_editPwd'];
	require_once('htmltop.php');
	if(empty($session->data[WiiBBS_ID."wiibbsUser"]))
	{
		alertInfo($_['tip_returnlogin'],'login.php');
	}
?>
 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<?php require_once('noticeinc.php');?>
		<div class='hf'><a href='index.php'><?php echo $_['text_index']?></a> &gt;&gt; <?php echo $_['text_editPwd'];?></div>
		<div class='comment'>
			<form action='user_do.php?act=pw' method='post'>
				<p><?php echo $_['text_oldPwd'];?>：<input inputmode="user predictOn" type='password' name='oldPw'/></p>
				<p><?php echo $_['text_newPwd'];?>：<input inputmode="user predictOn" type='password' name='newPw'/></p>
				<p><?php echo $_['text_rePwd'];?>：<input inputmode="user predictOn" type='password' name='rePw'/></p>
				<p><input inputmode="user predictOn" type="submit" value="<?php echo $_['btn_submit']?>"/> [<a href='usercenter.php'><?php echo $_['btn_goback'];?></a>]</p>
			</form>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>