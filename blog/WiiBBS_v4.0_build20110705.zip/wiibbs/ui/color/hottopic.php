<?php

/**
 * hottopic.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/color/hottopic.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/applications.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/topic.php');
	$header_title=$_['text_HotTopic'];
	require_once('htmltop.php');
	$POSITION_HOT="on";
?>

 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<?php require_once('noticeinc.php');?>
		<?php require_once('logininc.php');?>
		<?php require_once('tab.php');?>
		<?php
			$topics=$topic->getHotTopicList(0,10);
			if(count($topics)<1)
			{
				echo "<div class='caption'>".$_['tip_noHotTopic']."</div>";
			}
			for($i=0;$i<count($topics);$i++)
			{
		?>
			<div class='caption'><?php echo ($i+1)."."; if($topics[$i]["topic_isgood"]=="1"){ echo "<span class='key'>[".S_GOOD."]</span>";}?><?php if($topic->getFileListByID(0,$topics[$i]['topic_id'])) echo "<span class='key'>[".S_FILE."]</span>"; ?><a href="topicshow.php?bd=<?php echo $topics[$i]["topic_board"]?>&amp;id=<?php echo $topics[$i]["topic_id"]?>&amp;rnd=<?php echo rand()?>"><?php echo $topics[$i]["topic_title"]?></a> <span class="explain"><?php echo $topics[$i]["topic_recount"].S_REPLY.$topics[$i]["topic_viewcount"].S_SEE?></span></div>
		<?php
			}
		?>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>
