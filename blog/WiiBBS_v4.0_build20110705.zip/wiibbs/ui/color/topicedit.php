<?php

/**
 * topicedit.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	define('THISPATHROOT', str_replace('ui/color/topicedit.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	$session->data['setUrl']=getUrl();
	require_once('usercheck.php');
	  require_once('checklogin.php');
	$header_title=$_['header_editTopic'];
	require_once('htmltop.php');
	$id=sqlReplace(Trim($_GET["id"]));
	$id=intval($id);
	$row=$topic->getTopicByID_BD($id,$bd);
	If(!$row){
		alertInfo($_['alert_noNEW'],'index.php');
	}Else{
		$title=$row["topic_title"];
		$content=$row["topic_content"];
	}
?>

 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<?php require_once('noticeinc.php');?>
		<div class='hf'><a href="index.php"><?php echo $_['text_index']?></a>&gt;&gt;<?php echo $_['header_editTopic']?></div>
		<div class='comment'>
			<form action="topicdo.php?do=edit&amp;id=<?php echo $id?>&amp;bd=<?php echo $_GET["bd"]?>" method="post" enctype="multipart/form-data">
				<p><?php echo $_['text_topicTitle']?>：<input inputmode="user predictOn" name="title" type="text" value="<?php echo $title?>"/></p>
				<p><?php echo $_['text_topicContent']?>：</p>
				<p><textarea cols="30" rows="3" name="content"><?php echo HTMLDecode($content)?></textarea></p>
				<?php
					if($upload==1)
					{
				?>	
				<p><?php echo $_['text_fileUp']?>：<input inputmode="user predictOn" type="file" name="file" size='18'/></p>
				<?php
					}
				?>
				
				<p><input inputmode="user predictOn" type="submit" value="<?php echo $_['btn_do']?>"/></p>
				<?php
					if($upload==1)
					{
				?>	
				<p class="red"><?php echo $_['text_fileType'].attachType?>，<?php echo $_['text_fileSize'].attachSize?>k.</p>
				<?php
					}
				?>
				<?php if(SITEUBB=="1")
					echo "<p><span class='sp3'>".$_['text_ubb']."</span></p>";
				?>
			</form>
			<div class='point'>
				<?php echo $_['text_topicinfo']?>
			</div>
		</div>
		<div class='box'><p><?php echo $_['btn_goback']?>[<a href="board.php?bd=<?php echo $bd?>&amp;rnd=<?php echo rand();?>"><?php echo $bdName?></a>]</p></div>
		<?php 
			$session->data['setSkipUrl']=getUrl();
			require_once('boardswitch.php');
		?>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>
