<?php

/**
 * usergetpw2.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	define('THISPATHROOT', str_replace('ui/color/usergetpw2.php', '', str_replace('\\', '/', __FILE__)));
	require_once(THISPATHROOT.'include/db_conn.php');
	require_once(ROOT_PATH.'lang/'.LANGUAGE.'/user.php');
	$header_title=$_['text_forgetPwd'];
	require_once('htmltop.php');
	$account=sqlReplace(trim($_GET['account']));
	$vercode=sqlReplace(trim($_GET['vercode']));
	$result=$wiibbsUser->getUserByVercode($account,$vercode);
	if(!$result)
	{
		echo $_['tip_expired'];
		exit;
	}
?>
 <body>
	<div id='container'>
		<?php require_once('header.php');?>
		<div class='hf'><a href="index.php"><?php echo $_['text_index']?></a> &gt;&gt;<?php echo $_['text_forgetPwd'];?></div>
		<h1><a href='login.php'><?php echo $_['text_memberLogin']?></a>  <a href='register.php'><?php echo $_['text_userRegister'];?></a></h1>
		<div class='caption'>
			<form action='usergetpw_do.php?act=step2' method='post'>
				<p>　<?php echo $_['text_newPwd']?>：<input inputmode="user predictOn" type='password' name='pwd1'/><span></span></p>
				<p><?php echo $_['text_confirmPwd']?>：<input inputmode="user predictOn" type='password' name='pwd2'/><input inputmode="user predictOn" type='hidden' name='account' value='<?php echo $account;?>'/><input inputmode="user predictOn" type='hidden' name='vercode' value='<?php echo $vercode;?>'/></p>
				<p><input inputmode="user predictOn" type='submit' value='<?php echo $_['btn_submit'];?>'/></p>
			</form>
			<div class='point'>
			<?php echo $_['tip_commom'];?>：<br/>
			<?php echo $_['tip_forgetPw21'];?><br/>
			<?php echo $_['tip_forgetPw22'];?> <br/>
			<?php echo $_['tip_forgetPw23'];?> <br/>
			</div>
		</div>
		<?php require_once('bottom.php');?>
	</div>
 </body>
<?php
	require_once(ROOT_PATH.'include/htmlbottom.php');
?>
