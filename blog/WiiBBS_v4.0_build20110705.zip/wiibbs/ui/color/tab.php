<?php

/**
 * tab.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

?>
<div class='hf'><a href="index.php" class="tab" <?php if ($POSITION_INDEX=="on") echo "id='tab1'";?>><?php echo $_['text_index'];?></a><a href="hottopic.php" class="tab" <?php if ($POSITION_HOT=="on") echo "id='tab1'";?>><?php echo $_['text_hotTopic'];?></a><a href="boardlist.php" class="tab" <?php if ($POSITION_BOARD=="on") echo "id='tab1'";?>><?php echo $_['text_board'];?></a></div>