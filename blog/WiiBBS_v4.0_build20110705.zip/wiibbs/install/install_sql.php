﻿<?php

/**
 * install_sql.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
$sqlstr[0]="DROP TABLE IF EXISTS ".$prefix."admin";
$sqlstr[1]="DROP TABLE IF EXISTS ".$prefix."admingroup";
$sqlstr[2]="DROP TABLE IF EXISTS ".$prefix."board";
$sqlstr[3]="DROP TABLE IF EXISTS ".$prefix."boardclass";
$sqlstr[4]="DROP TABLE IF EXISTS ".$prefix."chatonline";
$sqlstr[5]="DROP TABLE IF EXISTS ".$prefix."counter";
$sqlstr[6]="DROP TABLE IF EXISTS ".$prefix."file";
$sqlstr[7]="DROP TABLE IF EXISTS ".$prefix."history";
$sqlstr[8]="DROP TABLE IF EXISTS ".$prefix."keyword";
$sqlstr[9]="DROP TABLE IF EXISTS ".$prefix."link";
$sqlstr[10]="DROP TABLE IF EXISTS ".$prefix."msg";
$sqlstr[11]="DROP TABLE IF EXISTS ".$prefix."msglog";
$sqlstr[12]="DROP TABLE IF EXISTS ".$prefix."notice";
$sqlstr[13]="DROP TABLE IF EXISTS ".$prefix."online";
$sqlstr[14]="DROP TABLE IF EXISTS ".$prefix."reply";
$sqlstr[15]="DROP TABLE IF EXISTS ".$prefix."sign";
$sqlstr[16]="DROP TABLE IF EXISTS ".$prefix."site";
$sqlstr[17]="DROP TABLE IF EXISTS ".$prefix."topic";
$sqlstr[18]="DROP TABLE IF EXISTS ".$prefix."user";
$sqlstr[19]="DROP TABLE IF EXISTS ".$prefix."usergroup";
$sqlstr[20]="CREATE TABLE `".$prefix."admin` (
	`admin_id` int(11) NOT NULL AUTO_INCREMENT,
	`admin_account` varchar(50) NOT NULL DEFAULT '',
	`admin_password` varchar(50) NOT NULL DEFAULT '',
	`admin_logintime` DATETIME NULL,
	`admin_loginip` VARCHAR(50) NULL,
	`admin_logincount` INT(10) NOT NULL DEFAULT '0',
	 `admin_group` int(4) unsigned DEFAULT NULL,
	 PRIMARY KEY (`admin_id`)
	)  DEFAULT CHARSET=utf8;";
									
$sqlstr[21]="CREATE TABLE `".$prefix."admingroup` (
	`admingroup_id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `admingroup_name` varchar(40) NOT NULL,
  `admingroup_right` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`admingroup_id`)
)DEFAULT CHARSET=utf8;";
					
$sqlstr[22]="CREATE TABLE IF NOT EXISTS `".$prefix."board` (
  `board_id` int(11) NOT NULL AUTO_INCREMENT,
  `board_name` varchar(40) DEFAULT NULL,
  `board_desc` varchar(100) DEFAULT NULL,
  `board_order` int(11) DEFAULT '0',
  `board_type` char(1) DEFAULT NULL,
  `board_admin` varchar(200) DEFAULT NULL,
  `board_users` varchar(200) DEFAULT NULL,
  `board_ischeck` char(1) DEFAULT NULL,
  `board_upload` char(1) DEFAULT NULL,
  `board_uniqid` varchar(50) DEFAULT NULL,
  `board_category` char(1) DEFAULT NULL,
  `board_pic` varchar(100) DEFAULT NULL,
  `board_class` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`board_id`)
) DEFAULT CHARSET=utf8 ;";


$sqlstr[23]="CREATE TABLE IF NOT EXISTS `".$prefix."boardclass` (
  `boardclass_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `boardclass_name` varchar(50) DEFAULT NULL,
  `boardclass_desc` varchar(150) DEFAULT NULL,
  `boardclass_order` int(4) unsigned NOT NULL DEFAULT '999',
  `boardclass_pic` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`boardclass_id`)
)  DEFAULT CHARSET=utf8 ;";

$sqlstr[24]="CREATE TABLE IF NOT EXISTS `".$prefix."chatonline` (
  `chatonline_id` int(11) NOT NULL AUTO_INCREMENT,
  `chatonline_ip` varchar(100) NOT NULL DEFAULT '',
  `chatonline_time` datetime DEFAULT NULL,
  `chatonline_user` varchar(50) DEFAULT NULL,
  `chatonline_position` int(11) DEFAULT NULL,
  `chatonline_speak` char(1) DEFAULT '1',
  PRIMARY KEY (`chatonline_id`)
) DEFAULT CHARSET=utf8 ;";

$sqlstr[25]="CREATE TABLE IF NOT EXISTS `".$prefix."counter` (
  `counter_type` varchar(50) NOT NULL DEFAULT '',
  `counter_date` date DEFAULT NULL,
  `counter_number` int(11) DEFAULT '0',
  PRIMARY KEY (`counter_type`)
) DEFAULT CHARSET=utf8;";

$sqlstr[26]="CREATE TABLE IF NOT EXISTS `".$prefix."file` (
  `file_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `file_topic` int(10) unsigned NOT NULL,
  `file_addtime` datetime DEFAULT NULL,
  `file_url` varchar(100) DEFAULT NULL,
  `file_type` varchar(8) DEFAULT NULL,
  `file_name` varchar(50) DEFAULT NULL,
  `file_size` varchar(20) DEFAULT NULL,
  `file_sort` char(1) DEFAULT NULL,
  PRIMARY KEY (`file_id`)
)  DEFAULT CHARSET=utf8 ;";

$sqlstr[27]="CREATE TABLE IF NOT EXISTS `".$prefix."history` (
  `history_id` int(11) NOT NULL AUTO_INCREMENT,
  `history_board` int(11) DEFAULT NULL,
  `history_content` text,
  `history_time` datetime DEFAULT NULL,
  PRIMARY KEY (`history_id`)
) DEFAULT CHARSET=utf8 ;";

$sqlstr[28]="CREATE TABLE IF NOT EXISTS `".$prefix."keyword` (
  `keyword_id` int(11) NOT NULL AUTO_INCREMENT,
  `keyword_name` varchar(150) DEFAULT NULL,
  `keyword_count` int(11) NOT NULL DEFAULT '0',
  `keyword_lasttime` datetime DEFAULT NULL,
  PRIMARY KEY (`keyword_id`)
)  DEFAULT CHARSET=utf8 ;";

$sqlstr[29]="CREATE TABLE IF NOT EXISTS `".$prefix."link` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `link_title` varchar(50) DEFAULT NULL,
  `link_url` varchar(100) DEFAULT NULL,
  `link_order` int(4) unsigned NOT NULL DEFAULT '999',
  `link_pic` varchar(100) DEFAULT NULL,
  `link_index` char(1) DEFAULT '0',
  PRIMARY KEY (`link_id`)
) DEFAULT CHARSET=utf8 ;";

$sqlstr[30]="CREATE TABLE IF NOT EXISTS `".$prefix."msg` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `msg_send` varchar(255) DEFAULT NULL,
  `msg_received` varchar(255) DEFAULT NULL,
  `msg_title` varchar(255) DEFAULT NULL,
  `msg_content` text,
  `msg_addtime` datetime DEFAULT NULL,
  `msg_isreader` int(11) DEFAULT '0',
  `msg_isreadertime` datetime DEFAULT NULL,
  `msg_isreply` int(11) DEFAULT '0',
  `msg_isreplytime` datetime DEFAULT NULL,
  `msg_side` int(11) DEFAULT '0',
  PRIMARY KEY (`msg_id`)
)  DEFAULT CHARSET=utf8;";

$sqlstr[31]="CREATE TABLE IF NOT EXISTS `".$prefix."msglog` (
  `msglog_id` int(11) NOT NULL AUTO_INCREMENT,
  `msglog_title` varchar(150) DEFAULT NULL,
  `msglog_content` text,
  `msglog_sendtime` datetime DEFAULT NULL,
  PRIMARY KEY (`msglog_id`)
) DEFAULT CHARSET=utf8 ;";

$sqlstr[32]="CREATE TABLE IF NOT EXISTS `".$prefix."notice` (
  `notice_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `notice_user` varchar(50) NOT NULL,
  `notice_url` varchar(200) NOT NULL,
  `notice_title` varchar(100) NOT NULL,
  `notice_addtime` datetime NOT NULL,
  `notice_type` char(1) NOT NULL,
  `notice_status` char(1) NOT NULL,
  `notice_count` int(4) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`notice_id`)
)  DEFAULT CHARSET=utf8;";

$sqlstr[33]="CREATE TABLE IF NOT EXISTS `".$prefix."online` (
  `online_ip` varchar(100) NOT NULL DEFAULT '',
  `online_time` datetime DEFAULT NULL,
  PRIMARY KEY (`online_ip`)
) DEFAULT CHARSET=utf8;";

$sqlstr[34]="CREATE TABLE IF NOT EXISTS `".$prefix."reply` (
  `reply_id` int(11) NOT NULL AUTO_INCREMENT,
  `reply_content` text,
  `reply_user` varchar(50) DEFAULT NULL,
  `reply_posttime` datetime DEFAULT NULL,
  `reply_edittime` datetime DEFAULT NULL,
  `reply_topic` int(11) DEFAULT NULL,
  `reply_board` int(11) DEFAULT NULL,
  `reply_level` int(11) DEFAULT NULL,
  PRIMARY KEY (`reply_id`)
) DEFAULT CHARSET=utf8 ;";

$sqlstr[35]="CREATE TABLE IF NOT EXISTS `".$prefix."sign` (
  `sign_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sign_user` int(10) unsigned NOT NULL,
  `sign_content` varchar(150) NOT NULL,
  `sign_addtime` datetime NOT NULL,
  `sign_expression` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`sign_id`)
) DEFAULT CHARSET=utf8 ;";

$sqlstr[36]="CREATE TABLE IF NOT EXISTS `".$prefix."site` (
  `site_logo` varchar(200) NOT NULL DEFAULT '',
  `site_width` int(11) DEFAULT NULL,
  `site_name` varchar(40) DEFAULT NULL,
  `site_mailsmtp` varchar(100) DEFAULT NULL,
  `site_mailaddress` varchar(100) DEFAULT NULL,
  `site_mailaccount` varchar(100) DEFAULT NULL,
  `site_mailpassword` varchar(100) DEFAULT NULL,
  `site_count` int(11) DEFAULT '0',
  `site_code` text,
  `site_filter` text,
  `site_timezone` varchar(100) DEFAULT NULL,
  `site_express` char(1) DEFAULT '0',
  `site_ubb` char(1) DEFAULT NULL,
  PRIMARY KEY (`site_logo`)
) DEFAULT CHARSET=utf8;";

$sqlstr[37]="CREATE TABLE IF NOT EXISTS `".$prefix."topic` (
  `topic_id` int(11) NOT NULL AUTO_INCREMENT,
  `topic_title` varchar(100) DEFAULT NULL,
  `topic_user` varchar(50) DEFAULT NULL,
  `topic_board` int(11) DEFAULT NULL,
  `topic_islock` char(1) DEFAULT '0',
  `topic_istop` char(1) DEFAULT '0',
  `topic_recount` int(11) DEFAULT '0',
  `topic_viewcount` int(11) DEFAULT '0',
  `topic_posttime` datetime DEFAULT NULL,
  `topic_updatetime` datetime DEFAULT NULL,
  `topic_edittime` datetime DEFAULT NULL,
  `topic_content` text,
  `topic_isgood` int(11) DEFAULT '0',
  `topic_status` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`topic_id`)
)  DEFAULT CHARSET=utf8;";

$sqlstr[38]="CREATE TABLE IF NOT EXISTS `".$prefix."user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_account` varchar(50) NOT NULL DEFAULT '',
  `user_password` varchar(50) NOT NULL DEFAULT '',
  `user_mobile` varchar(20) DEFAULT NULL,
  `user_email` varchar(50) DEFAULT NULL,
  `user_info` text,
  `user_regtime` datetime DEFAULT NULL,
  `user_logincount` int(11) DEFAULT '0',
  `user_lastlogin` datetime DEFAULT NULL,
  `user_score` int(11) DEFAULT '0',
  `user_grade` int(11) DEFAULT NULL,
  `user_level` char(1) DEFAULT NULL,
  `user_isvip` char(1) DEFAULT '0',
  `user_salt` int(4) DEFAULT NULL,
  `user_ip` varchar(50) DEFAULT NULL,
  `user_name` varchar(225) DEFAULT NULL,
  `user_nickname` varchar(225) DEFAULT NULL,
  `user_note` varchar(200) DEFAULT NULL,
  `user_vercode` varchar(50) DEFAULT NULL,
  `user_sex` char(1) DEFAULT NULL,
  `user_city` varchar(50) DEFAULT NULL,
  `user_province` varchar(50) DEFAULT NULL,
  `user_photo` varchar(100) DEFAULT NULL,
  `user_birthday` varchar(50) DEFAULT NULL,
  `user_qq` varchar(15) DEFAULT NULL,
  `user_sina` varchar(50) DEFAULT NULL,
  `user_intro` varchar(200) DEFAULT NULL,
  `user_address` varchar(225) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) DEFAULT CHARSET=utf8;";

$sqlstr[39]="CREATE TABLE IF NOT EXISTS `".$prefix."usergroup` (
  `usergroup_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usergroup_user` int(10) unsigned NOT NULL,
  `usergroup_board` int(10) unsigned NOT NULL,
  `usergroup_type` char(1) DEFAULT NULL,
  PRIMARY KEY (`usergroup_id`)
)  DEFAULT CHARSET=utf8  ;";


	
	$sqlstr[40]="INSERT INTO `".$prefix."admingroup` (`admingroup_id`, `admingroup_name`, `admingroup_right`) VALUES
(1, '".$_['text_superAdmin']."', '121|122|131|');";

$sqlstr[41]="INSERT INTO `".$prefix."board` (`board_id`, `board_name`, `board_desc`, `board_order`, `board_type`, `board_admin`, `board_users`, `board_ischeck`, `board_upload`, `board_uniqid`, `board_category`, `board_pic`, `board_class`) VALUES
(1, '测试版面', '', 0, '4', '', '', '0', '1', '', '1', 'nopic.jpg', 1);";

$sqlstr[42]="INSERT INTO `".$prefix."boardclass` (`boardclass_id`, `boardclass_name`, `boardclass_desc`, `boardclass_order`, `boardclass_pic`) VALUES
(1, '版面分类', NULL, 999, NULL);";

$sqlstr[43]="INSERT INTO `".$prefix."counter` (`counter_type`) VALUES
('day'),
('total');";

$sqlstr[44]="INSERT INTO `".$prefix."site` (`site_logo`, `site_width`, `site_name`, `site_mailsmtp`, `site_mailaddress`, `site_mailaccount`, `site_mailpassword`, `site_count`, `site_code`, `site_filter`, `site_timezone`, `site_express`, `site_ubb`) VALUES
('userfiles/logo/logo.jpg', 226, 'WiiBBS', '', '', '', '', 1, '', '', 'Asia/Shanghai', '1', '1');";

$sqlstr[45]="ALTER TABLE `".$prefix."keyword` ADD `keyword_index` CHAR( 1 ) NULL AFTER `keyword_lasttime;";

?>