<?php

/**
 * footer.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
require_once('inc/config.php');
require_once('../lang/'.$language.'/admin/common.php');
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> Footer </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
	<link rel="stylesheet" href="style2.css" type="text/css"/>
 </head>
 <body>
	<div class="footer">
		<div class="footerleft"><a href="http://www.wiipu.com/" target="_blank"><?php echo $_['text_wiipu']?></a> | <a href="http://wiipu.cn/u" target="_blank"><?php echo $_['text_feedback']?></a></div>
		<div class="footerright"><?php echo $_['text_com']?></div>
	</div>
 </body>
</html>
