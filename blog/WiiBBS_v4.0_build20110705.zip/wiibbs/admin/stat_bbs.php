<?php

/**
 * stat_bbs.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	require_once("inc/config.php");
	require_once("../lang/".$language."/admin/bbsstat_config.php");
	require_once("../lang/".$language."/admin/common.php");
	require_once("admincheck.php");
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_bbsstat']?> </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
 </head>
 <body>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li><span><span><a href="#" target="mainFrame"><?php echo $_['tab_bbsdata']?></a></span></span></li>
				<li class="l1"><span><span><a href="stat_visit.php" target="mainFrame"><?php echo $_['tab_visitstat']?></a></span></span></li>
				<li class="l1"><span><span><a href="stat_online.php" target="mainFrame"><?php echo $_['tab_onlinestat']?></a></span></span></li>
			</ul>
		</div>
		<div class="listintor">
			<div class="header1">
				<img src="images/square.gif" width="6" height="6" alt="" /><span><?php echo $_['text_position']?>：<?php echo $_['position_bbs']?> －&gt; <strong><?php echo $_['tab_bbsdata']?></strong></span>
			</div>
			<div class="header2"><span><?php echo $_['tab_bbsdata']?></span></div>
			<div class="fromcontent">
				<?php
					$sql="select count(user_id) as ct from ".DB_TABLE_PREFIX."user";
					$rs=mysql_query($sql);
					$row=mysql_fetch_assoc($rs);
					$userCount=$row["ct"];

					$sql="select count(online_ip) as ct from ".DB_TABLE_PREFIX."online";
					$rs=mysql_query($sql);
					$row=mysql_fetch_assoc($rs);
					$onlineCount=$row["ct"];

					$sql="select count(topic_id) as ct from ".DB_TABLE_PREFIX."topic";
					$rs=mysql_query($sql);
					$row=mysql_fetch_assoc($rs);
					$topicCount=$row["ct"];

					$sql="select count(reply_id) as ct from ".DB_TABLE_PREFIX."reply";
					$rs=mysql_query($sql);
					$row=mysql_fetch_assoc($rs);
					$replyCount=$row["ct"];
				?>
				<p><img src="images/li1.gif" alt="·" /> 注册用户数：<?php echo $userCount ?></p>
				<p><img src="images/li1.gif" alt="·" /> 当前在线会员数：<?php echo $onlineCount ?></p>
				<p><img src="images/li1.gif" alt="·" /> 帖子数：<?php echo $topicCount ?></p>
				<p><img src="images/li1.gif" alt="·" /> 回复数：<?php echo $replyCount ?></p>
			</div>
		</div>
	</div>
 </body>
</html>