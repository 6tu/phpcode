	var http_request=false;
	function createXMLHttpRequest(){
		http_request=false;
		//初始化XMLHttpRequest对象
		if(window.XMLHttpRequest){//Mozilla浏览器
			http_request=new XMLHttpRequest();
			if(http_request.overrideMimeType){//设置Mime类别
				http_request.overrideMimeType("text/xml");
			}
		}
		else if (window.ActiveXObject)
		{//IE browser
			try
			{
				http_request=new ActiveXObject("MSXML2.XMLHTTP");
			}
			catch (e)
			{
				try
				{
					http_request=new ActiveXObject("Microsoft.XMLHTTP");
				}
				catch (e)
				{
					try
					{
						http_request=new ActiveXObject("MSXML3.XMLHTTP");
					}
					catch (e)
					{
						return http_request;
					}
				}
			}
		}
		if (!http_request)
		{//异常，创建对象失败
			window.alert("不能创建XMLHttpRequest对象实例");
			return false;
		}
	}