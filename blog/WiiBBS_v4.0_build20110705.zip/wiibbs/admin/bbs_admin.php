<?php

/**
 * bbs_admin.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

?><?php require_once('inc/config.php');
require_once 'admincheck.php';
require_once('../lang/'.$language.'/admin/common.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_bbsAdmin']?> </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
    <script language="javascript">
		function checkAll(f){
			var len=f.elements.length;
			if (document.getElementById("handler").checked==true)
			{	
				for(i=0;i<len;i++){
					var e=f.elements[i];
					if (e.type=='checkbox') e.checked=true;
				}
			}
			if (document.getElementById("handler").checked==false)
			{	
				for(i=0;i<len;i++){
					var e=f.elements[i];
					if (e.type=='checkbox') e.checked=false;
				}
			}
		}
	</script>
</head>
 <body>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li><a href="bbs_admin.php" target="mainFrame" ><?php echo $_['tab_adminList']?></a> </li>
				<li class="l1"><a href="bbs_adminadd.php"><?php echo $_['tab_adminAdd']?></a> </li>
			</ul>
		</div>
		<div class="listintor">
			<form  name="listForm" method="post" action="#">
				<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" />
					<span><?php echo $_['text_position']?>：<?php echo $_['position_user'] ?> －&gt; <strong><?php echo $_['tab_adminList']?></strong></span></div>
				<div class="header2"><span><?php echo $_['tab_adminList']?></span></div>
				<div class="header3">
					<input type="checkbox" id="handler" name="handler" onClick="checkAll(this.form)"/> <strong><?php echo $_['text_selAll']?></strong><a href="javascript:if(confirm('您确定要删除吗？')){document.listForm.action='bbsadmin_do.php?act=delAll';document.listForm.submit();}"><img src="images/act_del.gif" width="14" height="14" alt="<?php echo $_['text_del']?>" /> <strong><?php echo $_['text_del']?></strong> </a>
				</div>
				<div class="content">
					<table width="100%">
						<tr class="t1">
							<td></td>
							<td><?php echo $_['text_bbsaccount'] ?></td>
							<td><?php echo $_['text_del']?></td>
						</tr>
						<?php
							$sqlStr="select * from ".DB_TABLE_PREFIX."user where user_level='2'";
							$rs=mysql_query($sqlStr);
							$rows=mysql_num_rows($rs);
							if(!$rows){
								echo "<tr><td colspan='3'>".$_['text_nodate']."！</td></tr>";
							}else{
								while($row=mysql_fetch_assoc($rs)){
							?>
							<tr>
								<td><input type="checkbox" name="id_list[]" value="<?php echo $row["user_id"]?>" /></td>
								<td><?php echo $row['user_account'];?></td>
								<td><a href="javascript:if(confirm('您确定要删除吗？')){location.href='bbsadmin_do.php?act=del&id=<?php echo $row["user_id"]?>'}"><img src="images/dot_del.gif" width="9" height="9" alt="删除" /></a></td>
							</tr>
							<?php
									}
								}
							?>
					</table>
				</div>
			</form>
		</div>
	</div>
 </body>
</html>
