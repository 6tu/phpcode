<?php

/**
 * boardclass_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once('inc/config.php');
	require_once("../lang/".$language."/admin/board_config.php");
	require_once('../lang/'.$language.'/admin/common.php');
	require_once('admincheck.php');
	
	$act=$_GET['act'];
	switch($act){
		case "add":
			$name=sqlReplace(trim($_POST["name"]));
			$desc=sqlReplace(trim($_POST["desc"]));
			if(empty($name)){
				alertInfo($_['alert_boardclassname'],'',1);
			}
			$boardClassPic=sqlReplace(trim($_FILES['file']['name']));
			if($boardClassPic==""){
				$boardClassPic=$filename1="";
				$sql="insert into ".DB_TABLE_PREFIX."boardclass(boardclass_name,boardclass_pic,boardclass_desc) values ('".$name."','".$filename1."','".$desc."')";
				if(mysql_query($sql)){
					alertInfo($_['success_boardclassadd'],'boardclass.php',0);
				}else{
					alertInfo($_['fail_boardclassadd'],'boardclass.php',0);
				}
			}else{
				$f_name=$_FILES['file']['name'];
				$f_size=$_FILES['file']['size'];
				$f_tmpName=$_FILES['file']['tmp_name'];
				$f_ext=strtolower(preg_replace('/.*\.(.*[^\.].*)*/iU','\\1',$f_name));
				$f_extList="png|jpg|gif|swf";
				$f_dir="../userfiles/boardclass";
				$f_exts=explode("|",$f_extList);
				$checkExt=false;
				foreach($f_exts as $v){
					if($f_ext==$v){
						$checkExt=true;
						break;
					}
				}
				if(!$checkExt){
					alertInfo("文件格式不在允许范围",'',1);
					exit();
				}
				if(!file_exists("$f_dir"))
				@mkdir($f_dir,0777);
				$date=date('YmdHis');
				$filename=$f_dir."/".$date.".".$f_ext;
				$filename1=$date.".".$f_ext;
				if(copy($f_tmpName,$filename)){
					$sql="insert into ".DB_TABLE_PREFIX."boardclass (boardclass_name,boardclass_pic,boardclass_desc) values ('".$name."','".$filename1."','".$desc."')";
					if(mysql_query($sql)){
						alertInfo($_['success_boardclassadd'],"boardclass.php",0);
					}else{
						alertInfo2($_['fail_boardclassadd'],"boardclassadd.php",0);
					}
				}else{
					alertInfo("未知错误，上传失败，请重新上传。",'',1);
					exit();
				}
			}
			break;

		case "edit":
			$id=sqlReplace(trim($_GET["id"]));
			checkData($id,"ID",0);
			$name=sqlReplace(trim($_POST["name"]));
			$desc=sqlReplace(trim($_POST["desc"]));
			if(empty($name)){
				alertInfo($_['alert_boardclassname'],'',1);
			}
			$sql_r = "select * from ".DB_TABLE_PREFIX."boardclass where boardclass_id=".$id;
			$result=mysql_query($sql_r);
			$rows=mysql_fetch_assoc($result);
			$boardclassPic=$rows["boardclass_pic"];
			$pic=sqlReplace(trim($_FILES['file']['name']));
			if(empty($pic)){
				$filename1=$boardclassPic;
				$sql="update ".DB_TABLE_PREFIX."boardclass set boardclass_name='".$name."',boardclass_pic='".$filename1."',boardclass_desc='".$desc."' where boardclass_id=".$id;
				if(mysql_query($sql)){
					alertInfo($_['success_boardclassedit'],"boardclass.php",0);
				}else{
					alertInfo($_['success_boardclassedit'],"",1);
				}
			}else{
				$f_name=$_FILES['file']['name'];
				$f_size=$_FILES['file']['size'];
				$f_tmpName=$_FILES['file']['tmp_name'];
				$f_ext=strtolower(preg_replace('/.*\.(.*[^\.].*)*/iU','\\1',$f_name));
				$f_extList="png|jpg|gif|swf";
				$f_dir="../userfiles/boardclass";
				$f_exts=explode("|",$f_extList);
				$checkExt=false;
				foreach($f_exts as $v){
					if($f_ext==$v){
						$checkExt=true;
						break;
					}
				}
				if(!$checkExt){
					alertInfo("文件格式不在允许范围",'boardclassedit.php?id='.$id,1);
					exit();
				}
				if(!file_exists("$f_dir"))
					@mkdir($f_dir,0777);
					$date=date('YmdHis');
					$filename=$f_dir."/".$date.".".$f_ext;
					$filename1=$date.".".$f_ext;
				if(copy($f_tmpName,$filename)){
					$sql="update ".DB_TABLE_PREFIX."boardclass set boardclass_name='".$name."',boardclass_pic='".$filename1."',boardclass_desc='".$desc."' where boardclass_id=".$id;
					if(mysql_query($sql)){
						alertInfo($_['success_boardclassedit'],"boardclass.php",0);
					}else{
						alertInfo($_['fail_boardclassedit'],"",1);
					}
				}else{
					alertInfo("未知错误，上传失败，请重新上传。",'',1);
					exit();
				}
			}
				break;

		case "del":
			$id=sqlReplace(trim($_GET["id"]));
			checkData($id,"ID",0);
			$sql="select * from ".DB_TABLE_PREFIX."boardclass where boardclass_id=".$id;
			$rs=mysql_query($sql);
			$row=mysql_fetch_assoc($rs);
			$boardclassPic=$row["boardclass_pic"];
			if(file_exists("../userfiles/boardclass/".$boardclassPic)){
				@unlink("../userfiles/boardclass/".$boardclassPic);
			}
			$sqlStr="select * from ".DB_TABLE_PREFIX."board where board_class=".$id;
			$result=mysql_query($sqlStr);
			$row1=mysql_fetch_assoc($result);
			$boardPic=$row1["board_pic"];
			if(file_exists("../userfiles/board/".$boardPic)){
				@unlink("../userfiles/board/".$boardPic);
			}
			$sql_d="delete from ".DB_TABLE_PREFIX."board where board_class=".$id;
			if(mysql_query($sql_d)){
				$sql_s="delete from ".DB_TABLE_PREFIX."boardclass where boardclass_id=".$id;
				if(mysql_query($sql_s)){
					alertInfo($_['success_boardclassdel'],'boardclass.php',0);
				}else{
					alertInfo($_['fail_boardclassdel'],'boardclass.php',0);
				}
			}else{
				alertInfo($_['fail_boardclassdel'],'boardclass.php',0);
			}
			break;
		
		case "delAll":
			if(empty($_POST["id_list"])){
				alertInfo2("请选择删除项！","boardclass.php",1);
			}
			$listall=$_POST["id_list"];
			foreach($listall as $listid){
				$sql="select * from ".DB_TABLE_PREFIX."board where board_class=".$listid;
				$result=mysql_query($sql);
				$rows=mysql_fetch_assoc($result);
				$boardPic=$rows["board_pic"];
				if(file_exists("../userfiles/board/".$boardPic)){
					@unlink("../userfiles/board/".$boardPic);
				}
				$sql2="delete from ".DB_TABLE_PREFIX."board where board_class=".$listid;
				if(!mysql_query($sql2)){
					alertInfo2("删除失败，错误编号：","",1);
				}
				$sqlstr="select * from ".DB_TABLE_PREFIX."boardclass where boardclass_id=".$listid;
				$rs=mysql_query($sqlstr);
				$row=mysql_fetch_assoc($rs);
				$boardclassPic=$row["boardclass_pic"];
				if(file_exists("../userfiles/boardclass/".$boardclassPic)){
					@unlink("../userfiles/boardclass/".$boardclassPic);
				}
				$sqlstr2="delete from ".DB_TABLE_PREFIX."boardclass where boardclass_id=".$listid;
				if(!mysql_query($sqlstr2)){
					alertInfo2("删除失败！","boardclass.php",0);
				}
			}
			alertInfo2("删除成功！","",1);
			break;

		case "update":
			$i=sqlReplace(trim($_POST["i"]));
			checkData2($i,"",0);
			for($x=1;$x<=$i;$x++){
				$tempId=sqlReplace(trim($_POST["id".$x]));
				checkData2($tempId,'ID',0);
				$tempOrder=sqlReplace(trim($_POST["order".$x]));
				checkData2($tempOrder,'ID',0);
				$sqlStr="update ".DB_TABLE_PREFIX."boardclass set boardclass_order=".$tempOrder." where boardclass_id=".$tempId."";
				if(!mysql_query($sqlStr)){
					alertInfo($_['fail_boardclasssave'],"boardclass.php",0);
				}
			}
			alertInfo($_['success_boardclasssave'],"boardclass.php",0);
			break;
	}
?>