<?php
	$language='zh-cn';
	$_ = array();
?>