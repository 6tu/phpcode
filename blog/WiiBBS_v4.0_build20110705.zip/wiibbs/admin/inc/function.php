<?php
	function getUrl(){
		$url='http://'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"];
		return ($url);
	}
	function sqlReplace($str){
	   $strResult = $str;
	   if(!get_magic_quotes_gpc()){
		 $strResult = addslashes($strResult);
	   }
	   return mbStrreplace($strResult);
	}
	function HTMLEncode($str){
		if (!empty($str)){
			$str=str_replace("&","&amp;",$str);
			$str=str_replace(">","&gt;",$str);
			$str=str_replace("<","&lt;",$str);
			$str=str_replace(CHR(32),"&nbsp;",$str);
			$str=str_replace(CHR(9),"&nbsp;&nbsp;&nbsp;&nbsp;",$str);
			$str=str_replace(CHR(9),"&#160;&#160;&#160;&#160;",$str);
			$str=str_replace(CHR(34),"&quot;",$str);
			$str=str_replace(CHR(39),"&#39;",$str);
			$str=str_replace(CHR(13),"",$str);
			$str=str_replace(CHR(10),"<br/>",$str);
		}
		return $str;
	}
	function HTMLDecode($str){
		if (!empty($str)){
			$str=str_replace("&amp;","&",$str);
			$str=str_replace("&gt;",">",$str);
			$str=str_replace("&lt;","<",$str);
			$str=str_replace("&nbsp;",CHR(32),$str);
			$str=str_replace("&nbsp;&nbsp;&nbsp;&nbsp;",CHR(9),$str);
			$str=str_replace("&#160;&#160;&#160;&#160;",CHR(9),$str);
			$str=str_replace("&quot;",CHR(34),$str);
			$str=str_replace("&#39;",CHR(39),$str);
			$str=str_replace("",CHR(13),$str);
			$str=str_replace("<br/>",CHR(10),$str);
			$str=str_replace("<br>",CHR(10),$str);
		}
		return $str;
	}
	function DateDiff($part, $begin, $end){
		$diff = strtotime($end) - strtotime($begin);
		switch($part){
			case "y": $retval = bcdiv($diff, (60 * 60 * 24 * 365)); break;
			case "m": $retval = bcdiv($diff, (60 * 60 * 24 * 30)); break;
			case "w": $retval = bcdiv($diff, (60 * 60 * 24 * 7)); break;
			case "d": $retval = bcdiv($diff, (60 * 60 * 24)); break;
			case "h": $retval = bcdiv($diff, (60 * 60)); break;
			case "n": $retval = bcdiv($diff, 60); break;
			case "s": $retval = $diff; break;
		}
		return $retval;
	}
	function alertInfo($info,$url,$type){
		switch($type){
			case 0:
				echo "<script language='javascript'>alert('".$info."');location.href='".$url."'</script>";
				exit;
				break;
			case 1:
				echo "$info<br/>【<a href='".$url."'>返回</a>】";
				exit;
				break;
		}
	}
	function alertInfo2($info,$url,$type){
		switch($type){
			case 0:
				echo "<script language='javascript'>alert('".$info."');location.href='".$url."'</script>";
				exit;
				break;
			case 1:
				echo "<script language='javascript'>alert('".$info."');history.back(-1);</script>";
				exit;
				break;
		}
	}
	function checkData($data,$name,$type){
		switch($type){
			case 0:
				if(!preg_match('/^\d*$/',$data)){
					alertInfo2("非法参数".$name,'',1);
					exit();
				}
				break;
			case 1:
				if(empty($data)){
					alertInfo2($name."不能为空","",1);
					exit();
				}
				break;
		}
		return $data;
	}
	function checkData2($data,$name,$type){
		switch($type){
			case 0:
				if(!preg_match('/^\d*$/',$data)){
					alertInfo2("非法参数".$name,'',1);
					exit();
				}
				break;
			case 1:
				if(empty($data)){
					alertInfo2($name."不能为空","",1);
					exit();
				}
				break;
		}
		return $data;
	}

 function mbStrreplace($content,$to_encoding="UTF-8",$from_encoding="UTF-8") {  
     $content=mb_convert_encoding($content,$to_encoding,$from_encoding);  
     $str=mb_convert_encoding("　",$to_encoding,$from_encoding);  
     $content=mb_eregi_replace($str," ",$content);  
     $content=mb_convert_encoding($content,$from_encoding,$to_encoding);  
     $content=trim($content);  
    return $content;  
 } 
function showPage($url,$page,$pagesize,$rscount,$pagecount){
	echo "<div class='page'>当前页:".$page."/".$pagecount."页 每页 ".$pagesize." 条 共 ".$pagecount." 页 </div>";
	echo "<div class='page2'><a href='".$url."'><img src='images/firstpage.jpg' width='50' height='11' alt='首页' /></a>";
	if(($page-1)>0){
	echo "<a href='".$url."&page=".($page-1)."'><img src='images/prepage.jpg' width='56' height='11' alt='上一页' /></a>";
	}else{
		echo "<img src='images/prepage_01.gif' width='56' height='11' alt='上一页' />";
	}
	if(($page+1)<=$pagecount){
	echo "<a href='".$url."&page=".($page+1)."'><img src='images/nextpage.gif' width='57' height='11' alt='下一页' /></a>";
	}else{
		echo "<img src='images/nextpage_01.gif' width='56' height='11' alt='下一页' />";
	}
	echo "<a href='".$url."&page=".$pagecount."'><img src='images/lastpage.gif' width='60' height='11' alt='尾页' /></a>";
	echo "</div>";		
}
	/*
		* 检查管理员权限
		* @param $right 某个操作的权限值
		* @param $rightList 管理员当前组的权限

	*/
	function checkAdminRight($right,$rightList){
		if(strpos($rightList,$right)===false){
			alertInfo2("您没有该项权限","",1);
			exit;
		}
	}

function cut_str($string,$sublen,$start=0,$code='UTF-8')
{
	if($code=='UTF-8')
	{
		$pa="/[x01-x7f]|[xc2-xdf][x80-xbf]|xe0[xa0-xbf][x80-xbf]|[xe1-xef][x80-xbf][x80-xbf]|xf0[x90-xbf][x80-xbf][x80-xbf]|[xf1-xf7][x80-xbf][x80-xbf][x80-xbf]/";
		preg_match_all($pa,$string,$t_string);

		if(count($t_string[0])-$start>$sublen) return join('',array_slice($t_string[0],$start,$sublen))."...";
		return join('',array_slice($t_string[0],$start,$sublen));
	}else{
		$start=$start*2;
		$sublen=$sublen*2;
		$strlen=strlen($string);
		$tmpstr='';

		for($i=0;$i<$strlen;$i++)
		{
			if($i>=$start&&$i<($start+$sublen))
			{
				if(ord(substr($string,$i,1))>129)
				{
					$tmpstr.=substr($string,$i,2);
				}else{
					$tmpstr.=substr($string,$i,1);
				}
			}
			if(ord(substr($string,$i,1))>129) $i++;
		}
		if(strlen($tmpstr)<$strlen ) $tmpstr.="...";
		return $tmpstr;
	}
}

 function sendNotice($title,$url,$user,$type){
		$sql_ss="select notice_id from ".DB_TABLE_PREFIX."notice where notice_type='".$type."' and notice_status='0' and notice_user='".$user."'";
		$rs_ss=mysql_query($sql_ss);
		$row_ss=mysql_fetch_assoc($rs_ss);
		if (!$row_ss){
			$sql_rr="insert into ".DB_TABLE_PREFIX."notice(notice_title,notice_url,notice_user,notice_addtime,notice_type,notice_status) values ('".$title."','".$url."','".$user."',now(),'".$type."','0')";
			mysql_query($sql_rr);
		}else{
			$sql_rr="update ".DB_TABLE_PREFIX."notice set notice_addtime=now(),notice_count=notice_count+1,notice_url='".$url."' where  notice_type='".$type."' and notice_status='0' and notice_user='".$user."'";
			mysql_query($sql_rr);
		}
	}

?>