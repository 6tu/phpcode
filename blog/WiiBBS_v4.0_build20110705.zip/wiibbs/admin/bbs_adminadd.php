<?php

/**
 * bbs_adminadd.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

?><?php require_once('inc/config.php');
require_once 'admincheck.php';
require_once('../lang/'.$language.'/admin/common.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['menu_bbsadminAdd']?> </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
 </head>
 <body>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li class="l1"><a href="bbs_admin.php" target="mainFrame" ><?php echo $_['tab_adminList']?></a> </li>
				<li><a href="bbs_adminadd.php"><?php echo $_['tab_adminAdd']?></a> </li>
			</ul>		
		</div>
		<div class="listintor">
			<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" />
				<span><?php echo $_['text_position']?>：<?php echo $_['position_user'] ?> －&gt; <strong><?php echo $_['tab_adminAdd']?></strong></span></div>
			<div class="header2"><span><?php echo $_['tab_adminAdd']?></span></div>
			<div class="fromcontent">
				<form id="form2" name="addForm" method="post" action="bbsadmin_do.php?act=add">
					<p><?php echo $_['text_bbsaccount']?>：<input class="in1" type="text" name="name" id="name"/>
								<span class="start">*</span>
					</p>
					<div class="btn">
						<input type="image" src="images/submit1.gif" width="56" height="20" alt="<?php echo $_['alt_submit']?>" onClick="return checkIn();"/>
					</div>
					<script language="javascript">
						function checkspace(checkstr) {
						  var str = '';
						  for(i = 0; i < checkstr.length; i++) {
							str = str + ' ';
						  }
						  return (str == checkstr);
						}
						function checkIn(){
							if(checkspace(document.addForm.name.value)) {
								alert("<?php echo $_['alter_bbsAccount']?>");
								return false;
							}
						}
					</script>
				</form>
			</div>
		</div>
	</div>
 </body>
</html>
