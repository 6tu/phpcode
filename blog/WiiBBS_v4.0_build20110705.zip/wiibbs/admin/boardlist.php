<?php

/**
 * boardlist.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once("inc/config.php");
	require_once("../lang/".$language."/admin/board_config.php");
	require_once('../lang/'.$language.'/admin/common.php');
	require_once('admincheck.php');
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_board']?> </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
      <script language="javascript">
		function checkAll(f){
			var len=f.elements.length;
			if (document.getElementById("handler").checked==true)
			{	
				for(i=0;i<len;i++){
					var e=f.elements[i];
					if (e.type=='checkbox') e.checked=true;
				}
			}
			if (document.getElementById("handler").checked==false)
			{	
				for(i=0;i<len;i++){
					var e=f.elements[i];
					if (e.type=='checkbox') e.checked=false;
				}
			}
		}
	</script>
</head>
 <body>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li><span><span><a href="#" target="mainFrame"><?php echo $_['tab_boardList']?></a></span></span></li>
				<li class="l1"><span><span><a href="boardadd.php" target="mainFrame"><?php echo $_['tab_boardAdd']?></a></span></span></li>
			</ul>
		</div>
		<div class="listintor">
			<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" />
				<span><?php echo $_['text_position']?>：<?php echo $_['position_board']?> －&gt; <strong><?php echo $_['tab_boardList']?></strong></span>
			</div>
			<form id="listForm" name="listForm" method="post" action="#">
				<div class="header2"><span><?php echo $_['tab_boardList']?></span></div>
				<div class="header3">
					<input type="checkbox" id="handler" name="handler" onClick="checkAll(this.form)"> <strong><?php echo $_['text_selAll']?></strong>
					<a href="javascript:document.listForm.action='board_do.php?act=update';document.listForm.submit();"><img src="images/act_save.gif" width="16" height="16" alt="<?php echo $_['text_save'];?>" /> <strong><?php echo $_['text_save']?></strong> </a>
					<a href="boardadd.php"><img src="images/act_add.gif" alt="+" /><strong><?php echo $_['text_newAdd']?></strong></a>
					<a href="javascript:if(confirm('<?php echo $_['text_sureSel'];?>')){document.listForm.action='board_do.php?act=delAll';document.listForm.submit();}"><img src="images/act_del.gif" width="14" height="14" alt="<?php echo $_['text_del'];?>" /> <strong><?php echo $_['text_del']?></strong></a>
				</div>
				<div class="content">
					<table width="100%">
						<tr class="t1">
							<th><?php echo $_['text_select']?></th>
							<th><?php echo $_['text_boardname']?></th>
							<th><?php echo $_['text_boardpic']?></th>
							<th><?php echo $_['text_boardadmin']?></th>
							<th><?php echo $_['text_boarddesc']?></th>
							<th><?php echo $_['text_upload']?></th>
							<th><?php echo $_['text_ischeck']?></th>
							<th><?php echo $_['text_boardorder']?></th>
							<th><?php echo $_['text_boardedit']?></th>
							<th><?php echo $_['text_boarddel']?></th>
						</tr>
						<?php
							if(empty($_GET['pagesize'])||!is_numeric($_GET['pagesize']))
							{
								$pagesize=10;
							}else{
								$pagesize=$_GET['pagesize'];
							if($_GET['pagesize']<1)$pagesize=10;
							}
							$startrow=0;
							$sql2="select * from ".DB_TABLE_PREFIX."board order by board_order asc,board_id desc";
							$result=mysql_query($sql2) or die ($_['fail_selectBoard_3']);
							$rscount=mysql_num_rows($result);
							if ($rscount%$pagesize==0)
							$pagecount=$rscount/$pagesize;
							else
								$pagecount=ceil($rscount/$pagesize);
							if (empty($_GET['page'])||!is_numeric($_GET['page']))
								$page=1;
							else{
								$page=$_GET['page'];
								if($page<1) $page=1;
								if($page>$pagecount) $page=$pagecount;
								$startrow=($page-1)*$pagesize;
							}
							if($page>=$pagecount)
							{
								$nextpage=$pagecount;
							}else{
								$nextpage=$page+1;
							}
							if($page<=1)
							{
								$prepage=1;
							}else{
								$prepage=$page-1;
							}
							$sql="select * from ".DB_TABLE_PREFIX."board order by board_order asc,board_id desc limit $startrow,$pagesize";
							$rs=mysql_query($sql);
							$num=mysql_num_rows($rs);
							if(!$num){
								echo "<tr><td colspan='9'>".$_['text_nodate']."</td></tr>";
							}else{
								$i=1;
								while($row=mysql_fetch_assoc($rs)){
						?>
							<tr>
								<td><input type="checkbox" name="id_list[]" value="<?php echo $row["board_id"];?>"></td>
								<td><?php echo $row["board_name"]?></td>
								<td><img src="<?php echo "../userfiles/board/".$row["board_pic"]?>" width="100"/></td>
								<td><?php echo $row["board_admin"]?></td>
								<td class="td1"><?php echo cut_str($row["board_desc"],12,0,"utf-8");?></td>
								<td><?php if($row["board_upload"]=="0"){echo $_['text_no'];}else{echo $_['text_yes'];}?></td>
								<td><?php if($row["board_ischeck"]=="0"){echo $_['text_no'];}else{echo $_['text_yes'];}?></td>
								<td><input name="id<?php echo $i;?>" type="hidden" value="<?php echo $row["board_id"];?>" /><input name="i" type="hidden" value="<?php echo $i;?>" /><input name="order<?php echo $i;?>" type="text" size="4" value="<?php echo $row["board_order"];?>" /></td>
								<td><a href="boardedit.php?id=<?php echo $row["board_id"]?>"><img src="images/dot_edit.gif" width="9" height="9" alt="<?php echo $_['text_edit'];?>"></a></td>
								<td><a href="javascript:if(confirm('<?php echo $_['text_sureSel']?>?')){location.href='board_do.php?act=del&id=<?php echo $row["board_id"]?>'}"><img src="images/dot_del.gif" width="9" height="9" alt="<?php echo $_['text_del'];?>" /></a></td>
							</tr>
						<?php
								$i++;
								}
							}	
						?>
					</table>
					<?php
						if($rscount>0){
							$url="boardlist.php?";
							$url2="boardlist.php";
							include_once('page.php');
						}
					?>	
				</div>
			</form>
		</div>
	</div>
 </body>
</html>