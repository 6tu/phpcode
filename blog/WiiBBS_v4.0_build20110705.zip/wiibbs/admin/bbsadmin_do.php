<?php

/**
 * bbsadmin_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

require_once('inc/config.php');
require_once 'admincheck.php';
require_once('../lang/'.$language.'/admin/common.php');
?>
<?php
	$act=$_GET['act'];
	switch($act)
	{
		case 'del':
			$id=$_GET['id'];
			checkData($id,'ID',1);
			$sql="select * from ".DB_TABLE_PREFIX."user where user_id=".$id;
			$result=mysql_query($sql);
			$row=mysql_fetch_assoc($result);
			if($row)
			{
				$sql2="update ".DB_TABLE_PREFIX."user set user_level='1' where user_level='2' and user_id=".$id;
				if(mysql_query($sql2))
				{
					alertInfo2($_['success_delbbsAdmin'],'bbs_admin.php',0);
				}else{
					alertInfo2($_['fail_deleteBBSAdmin'],'',1);
				}
			}else{
				alertInfo2($_['fail_deleteBBSAdmin_r'],"",1);
			}
			break;
		case 'add':
			$name=sqlReplace(trim($_POST['name']));
			checkData($name,$_['text_adminAccount'],1);
			$sql="select user_level from ".DB_TABLE_PREFIX."user where user_account='".$name."'";
			$result=mysql_query($sql);
			$row=mysql_fetch_assoc($result);
			if($row)
			{
				$sql2="update ".DB_TABLE_PREFIX."user set user_level='2' where user_account='".$name."'";
				if(mysql_query($sql2))
				{
					alertInfo2($_['success_addbbsAdmin'],'bbs_admin.php',0);
				}else{
					alertInfo2($_['fail_addeteBBSAdmin'],'',1);
				}
			}else{
				alertInfo2($_['fail_noUser'] ,'',1);
			}
			break;
		case 'delAll':
			if(empty($_POST["id_list"])){
				alertInfo($_['text_noCheck'],"bbs_admin.php",0);
			}
			$id_list=$_POST["id_list"];
			foreach($id_list as $val){
				$sqlStr="update ".DB_TABLE_PREFIX."user set user_level='1' where user_level='2' and user_id=".$val."";
				if(mysql_query($sqlStr)){
					alertInfo($_['success_delAdmin'],"bbs_admin.php",0);
				}else{
					alertInfo($_['fail_delBBSAdmin'],"bbs_admin.php",0);
				 }
			}
			break;
	}
?>
