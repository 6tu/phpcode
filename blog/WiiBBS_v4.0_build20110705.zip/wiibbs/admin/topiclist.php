<?php

/**
 * topiclist.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	require_once("inc/config.php");
	require_once('../lang/'.$language.'/admin/topic_config.php');
	require_once("../lang/".$language."/admin/common.php");
	require_once("admincheck.php");
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_topiclist']?> </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
      <script language="javascript">
		function checkAll(f){
			var len=f.elements.length;
			if (document.getElementById("handler").checked==true)
			{	
				for(i=0;i<len;i++){
					var e=f.elements[i];
					if (e.type=='checkbox') e.checked=true;
				}
			}
			if (document.getElementById("handler").checked==false)
			{	
				for(i=0;i<len;i++){
					var e=f.elements[i];
					if (e.type=='checkbox') e.checked=false;
				}
			}
		}
	</script>
</head>
 <body>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li><span><span><a href="#" target="mainFrame"><?php echo $_['tab_topiclist']?></a></span></span></li>
				<li class="l1"><span><span><a href="topicsearch.php" target="mainFrame"><?php echo $_['tab_topicsearch']?></a></span></span></li>
			</ul>
		</div>
		<div class="listintor">
			<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" /><span><?php echo $_['text_position']?>：<?php echo $_['position_topic']?> — &gt; <strong><?php echo $_['tab_topiclist']?></strong></span></div>
			<form id="listForm" name="listForm" method="post" action="#">
				<div class="header2"><span><?php echo $_['tab_topiclist']?></span></div>
				<div class="header3">
					<input type="checkbox" id="handler" name="handler" onClick="checkAll(this.form)"> <strong><?php echo $_['text_selAll']?></strong>
					<a href="javascript:if(confirm('您确定要删除吗？')){document.listForm.action='topic_do.php?act=delAll';document.listForm.submit();}"><img src="images/act_del.gif" width="14" height="14" alt="删除" /> <strong><?php echo $_['text_del']?></strong></a>
				</div>
				<div class="content">
					<table width="100%">
						<tr class="t1">
							<th><?php echo $_['text_topicselect']?></th>
							<th><?php echo $_['text_topictitle']?></th>
							<th><?php echo $_['text_topicuser']?></th>
							<th><?php echo $_['text_topicboard']?></th>
							<th><?php echo $_['text_addtime']?></th>
							<th><?php echo $_['text_topicview']?></th>
							<th><?php echo $_['text_topicdel']?></th>
						</tr>
						<?php
							if(empty($_GET['pagesize'])||!is_numeric($_GET['pagesize']))
							{
								$pagesize=10;
							}else{
								$pagesize=$_GET['pagesize'];
							if($_GET['pagesize']<1)$pagesize=10;
							}
							$startrow=0;
							$sql2="select * from ".DB_TABLE_PREFIX."topic order by topic_id desc";
							$result=mysql_query($sql2) or die ('查询失败，请检查SQL语句2');
							$rscount=mysql_num_rows($result);
							if ($rscount%$pagesize==0)
							$pagecount=$rscount/$pagesize;
							else
								$pagecount=ceil($rscount/$pagesize);
							if (empty($_GET['page'])||!is_numeric($_GET['page']))
								$page=1;
							else{
								$page=$_GET['page'];
								if($page<1) $page=1;
								if($page>$pagecount) $page=$pagecount;
								$startrow=($page-1)*$pagesize;
							}
							if($page>=$pagecount)
							{
								$nextpage=$pagecount;
							}else{
								$nextpage=$page+1;
							}
							if($page<=1)
							{
								$prepage=1;
							}else{
								$prepage=$page-1;
							}
							$sql="select * from ".DB_TABLE_PREFIX."topic order by topic_id desc limit $startrow,$pagesize";
							$rs=mysql_query($sql);
							$num=mysql_num_rows($rs);
							if(!$num){
								echo "<tr><td colspan='7'>暂时没有数据！</td></tr>";
							}else{
								while($row=mysql_fetch_assoc($rs)){
									$topicBoard=$row["topic_board"];
									$sqlStr="select * from ".DB_TABLE_PREFIX."board where board_id=".$topicBoard;
									$result=mysql_query($sqlStr);
									$row1=mysql_fetch_assoc($result);
									$boardName=$row1["board_name"];
						?>
						<tr>
							<td><input type="checkbox" name="id_list[]" value=<?php echo $row["topic_id"]?> /></td>
							<td class="td1"><?php echo cut_str($row["topic_title"],12,0,"utf-8");?></td>
							<td><?php echo $row["topic_user"];?></td>
							<td><?php echo $boardName;?></td>
							<td><?php echo $row["topic_posttime"];?></td>
							<td><a href="../ui/color/topicshow.php?bd=<?php echo $topicBoard?>&id=<?php echo $row["topic_id"]?>" target="blank">查看</a></td>
							<td><a href="javascript:if(confirm('<?php echo $_['text_sureSel']?>?')){location.href='topic_do.php?act=del&id=<?php echo $row["topic_id"]?>'}"><img src="images/dot_del.gif" width="9" height="9" alt="删除" /></a></td>
						</tr>
						<?php
								}
							}	
						?>
					</table>
					<?php
						if($rscount>0){
							$url="topiclist.php?";
							$url2="topiclist.php";
							include_once('page.php');
						}
					?>
				</div>
			</form>
		</div>
	</div>
 </body>
</html>