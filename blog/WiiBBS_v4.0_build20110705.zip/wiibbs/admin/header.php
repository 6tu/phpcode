<?php

/**
 * header.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

require_once('inc/config.php');
require_once('../lang/'.$language.'/admin/common.php');
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> header </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
 </head>
 <body>
	<div id="header">
		<a href="admin.php" target="mainFrame"><img src="images/wiibbs01.gif" width="114" height="31" alt="WiiSNS" /></a>
		<span class="sp1"><?php echo $_['header_manage']?></span>
	 </div>
	 <div id="quit">
	</div>
	<div id="indx">
		<ul>
			<li><a href="../index.php" target="_blank"><?php echo $_['text_index1']?></a></li>
			<li><a href="admin.php" target="mainFrame"><?php echo $_['text_index2']?></a></li>
			<li><a href="adminpw.php" target="mainFrame"><?php echo $_['text_editPWD']?></a></li>
			<li><a href="admin_quit.php"><?php echo $_['text_quit']?></a></li>
		</ul>
	</div>
 </body>
</html>
