<?php

/**
 * upgrade.php WiiBBS版本自动更新界面
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu, Jiang
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	require_once("inc/config.php");
	require_once("../lang/".$language."/admin/common.php");
	require_once("admincheck.php");
	

	require_once("../include/version.php");

	$file=sqlReplace(trim($_GET['file']));
	$ver=sqlReplace(trim($_GET['ver']));

	$file=checkData($file,"升级包文件",1);
	$ver=checkData($ver,"版本号",1);

	if($subversion!=$ver) alertInfo2('该升级包不适用于当前版本。','',1);

	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> WiiBBS在线升级 </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
  <script type="text/javascript" src="js/ajax.js"></script>
  <script type="text/javascript">
  <!--
	function doSend_down(){
		createXMLHttpRequest();
		http_request.onreadystatechange=request_down;
		http_request.open("POST",'upgrade_do.php',true);
		http_request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
		http_request.send("act=down&f=<?php echo $file?>");
	}
	function doSend_zip(){
		createXMLHttpRequest();
		http_request.onreadystatechange=request_zip;
		http_request.open("POST",'upgrade_do.php',true);
		http_request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
		http_request.send("act=zip&f=<?php echo $file?>");
	}
	function doSend_install(){
		createXMLHttpRequest();
		http_request.onreadystatechange=request_install;
		http_request.open("POST",'upgrade/<?php echo $file?>/update.php',true);
		http_request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
		http_request.send("act=install&v=<?php echo $ver?>");
	}
	function request_down(){
			if (http_request.readyState==4)
			{
				if (http_request.status==200){
					txt=http_request.responseText;
					if (txt=="S"){
						document.getElementById("info_down").innerHTML="<span>下载更新包成功。</span>";
						doSend_zip();
					}else
						document.getElementById("info_down").innerHTML="<span style='color:red;'>下载失败。<a href='http://p.wiipu.com/WiiBBS/down/<?php echo $file;?>_update.zip'>手动下载</a></span>";
				}else
					document.getElementById("info_down").innerHTML="<span style='color:red;'>意外错误，下载失败。</span>";
			}else
				document.getElementById("info_down").innerHTML="<span><img src='images/loading.gif'/>正在下载更新包...</span>";
	}
	function request_zip(){
			if (http_request.readyState==4)
			{
				if (http_request.status==200){
					txt=http_request.responseText;
					if (txt=="S"){
						document.getElementById("info_zip").innerHTML="<span>解压成功。</span>";
						doSend_install();
					}
					else
						document.getElementById("info_zip").innerHTML="<span style='color:red;'>解压失败。</span>";
				}else
					document.getElementById("info_zip").innerHTML="<span style='color:red;'>意外错误，解压失败。</span>";
			}else
				document.getElementById("info_zip").innerHTML="<span style='color:red;'><img src='images/loading.gif'/>正在解压...</span>";
	}
	function request_install(){
			if (http_request.readyState==4)
			{
				if (http_request.status==200){
					txt=http_request.responseText;
					if (txt=="S")
						document.getElementById("info_install").innerHTML="<span>升级成功。</span>";
					else
						document.getElementById("info_install").innerHTML="<span style='color:red;'>安装升级失败。</span>";
				}else
					document.getElementById("info_install").innerHTML="<span style='color:red;'>意外错误导致安装失败。</span>";
			}else
				document.getElementById("info_install").innerHTML="<span color='red'><img src='images/loading.gif'/>正在安装升级包...</span>";
	}
	function act_down(){
		doSend_down();
	}
	function act_zip(){
		doSend_zip();
	}
	function act_install(){
		doSend_install();
	}
  //-->
  </script>
 </head>
 <body>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li><span><span><a href="#" target="mainFrame">在线升级</a></span></span></li>
			</ul>
		</div>
		<div class="listintor">
			<div class="header1">
				<img src="images/square.gif" width="6" height="6" alt="" /><span>位置：<strong>WiiBBS在线升级</strong></span>
			</div>
			<div class="header2"><span>WiiBBS在线升级</span></div>
			<div class="fromcontent">
				<div id="info">
					<p id="info_down"></p>
					<p id="info_zip"></p>
					<p id="info_install"></p>
					<script type="text/javascript">
					<!--
						doSend_down();
					//-->
					</script>
					<p ><br/><br/><br/><br/><input type="button" value="返回" onclick="javascript:location.href='admin.php'"/></p>
				</div>
			</div>
		</div>
	</div>
 </body>
</html>