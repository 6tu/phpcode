<?php

/**
 * admingroup.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	require_once('inc/config.php');
	require_once('../lang/'.$language.'/admin/common.php');
	require_once('admincheck.php');
	
	$act=$_GET['act'];
	switch($act){
		Case "add":
			$admin_name=sqlReplace(trim($_POST['name']));
			$admin_name=checkData($admin_name,$_['alert_group'],1);
			$sql="insert into ".DB_TABLE_PREFIX."admingroup (admingroup_name) values('".$admin_name."')";
			if(mysql_query($sql)){
				alertInfo($_['success_addAdmin'],"admingrouplist.php",0);
			}else{
				alertInfo($_['failGroupAdd'],"admingroupadd.php",0);
			}
			break;
		Case "del":
			$id=sqlReplace($_GET['id']);
			$id=checkData($id,"ID",0);
			$sql="delete from ".DB_TABLE_PREFIX."admingroup where admingroup_id=$id";
			if(mysql_query($sql)){
				alertInfo($_['success_delAdmin'],"admingrouplist.php",0);
			}else{
				alertInfo($_['failGroupDel'],"admingrouplist.php",0);
			}
			break;
		case "save":
			$id=sqlReplace($_GET['id']);
			$id=checkData($id,"ID",0);
			$group="";
			if(empty($_POST['id_list'])){
				alertInfo($_['alert_limit'],"admingrouplist.php",0);
			}else{
				foreach($_POST['id_list'] as $val){
					$group.=$val."|";
				}
				$sql="update ".DB_TABLE_PREFIX."admingroup set admingroup_right='".$group."' where admingroup_id=$id";
				if(mysql_query($sql)){
					alertInfo($_['success_save'],"admingrouplist.php",0);
				}else{
					alertInfo($_['failGroupSave'],"admingrouplist.php",0);
				}
			}	
	}
	mysql_close($db_connect);
?>
	
	
	
	