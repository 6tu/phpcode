<?php

/**
 * user_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once('inc/config.php');
	require_once('../lang/'.$language.'/admin/user_config.php');
	require_once('../lang/'.$language.'/admin/common.php');
	require_once('admincheck.php');
	
	$act=$_GET["act"];
	switch($act){
		case "add":
			$userAccount=sqlReplace(trim($_POST["account"]));
			$userPass=sqlReplace(trim($_POST["pass"]));
			$userMobile=sqlReplace(trim($_POST["mobile"]));
			$userEmail=sqlReplace(trim($_POST["email"]));
			$userIsVip=sqlReplace(trim($_POST["isvip"]));
			$userName=sqlReplace(trim($_POST["username"]));
			$userNickName=sqlReplace(trim($_POST["nickname"]));
			$userSex=sqlReplace(trim($_POST["sex"]));
			$userBrithday=sqlReplace(trim($_POST["brithday"]));
			$userProvince=sqlReplace(trim($_POST["province"]));
			$userCity=sqlReplace(trim($_POST["city"]));
			$userQQ=sqlReplace(trim($_POST["qq"]));
			$userSina=sqlReplace(trim($_POST["sina"]));
			$userIntro=sqlReplace(trim($_POST["intro"]));
			$userNote=sqlReplace(trim($_POST["note"]));
			$userInfo=sqlReplace(trim($_POST["info"]));
			$userPhoto=sqlReplace(trim($_FILES['file']['name']));
			$userAddress=sqlReplace(trim($_POST["address"]));
			$salt=rand(1000,9999);
			if(empty($userAccount)){
				alertInfo2($_['alert_useraccount'],'',1);
			}
			if(empty($userPass)){
				alertInfo2($_['alert_userpass'],'',1);
			}
			if(empty($userMobile)){
				alertInfo2($_['alert_usermobile'],'',1);
			}
			if(empty($userEmail)){
				alertInfo2($_['alert_useremail'],'',1);
			}

			if(empty($userPhoto)){
				$userPhoto=$filename1="";
				$sql="insert into ".DB_TABLE_PREFIX."user(user_account,user_password,user_mobile,user_email,user_info,user_isvip,user_salt,user_name,user_nickname,user_note,user_sex,user_city,user_province,user_photo,user_birthday,user_qq,user_sina,user_intro,user_address,user_regtime) values('".$userAccount."','".md5(md5($userPass).$salt)."','".$userMobile."','".$userEmail."','".$userInfo."','".$userIsVip."','".$salt."','".$userName."','".$userNickName."','".$userNote."','".$userSex."','".$userCity."','".$userProvince."','".$filename1."','".$userBrithday."','".$userQQ."','".$userSina."','".$userIntro."','".$userAddress."',now())";

				if(mysql_query($sql)){
					alertInfo2($_['success_useradd'],'userlist.php',0);
				}else{
					alertInfo2($_['fail_useradd'],'',1);
				}
			}else{
				$f_name=$_FILES['file']['name'];
				$f_size=$_FILES['file']['size'];
				$f_tmpName=$_FILES['file']['tmp_name'];
				$f_ext=strtolower(preg_replace('/.*\.(.*[^\.].*)*/iU','\\1',$f_name));
				$f_extList="png|jpg|gif|swf";
				$f_dir="../userfiles/user";
				$f_exts=explode("|",$f_extList);
				$checkExt=false;
				foreach($f_exts as $v){
					if($f_ext==$v){
						$checkExt=true;
						break;
					}
				}
				if(!$checkExt){
					alertInfo("文件格式不在允许范围",'useredit.php?id='.$id,1);
					exit();
				}
				if(!file_exists("$f_dir"))
					@mkdir($f_dir,0777);
					$date=date('YmdHis');
					$filename=$f_dir."/".$date.".".$f_ext;
					$filename1=$date.".".$f_ext;
					if(copy($f_tmpName,$filename)){
					$sql="insert into ".DB_TABLE_PREFIX."user(user_account,user_password,user_mobile,user_email,user_info,user_isvip,user_salt,user_name,user_nickname,user_note,user_sex,user_city,user_province,user_photo,user_birthday,user_qq,user_sina,user_intro,user_address,user_regtime) values('".$userAccount."','".md5(md5($userPass).$salt)."','".$userMobile."','".$userEmail."','".$userInfo."','".$userIsVip."','".$salt."','".$userName."','".$userNickName."','".$userNote."','".$userSex."','".$userCity."','".$userProvince."','".$filename1."','".$userBrithday."','".$userQQ."','".$userSina."','".$userIntro."','".$userAddress."',now())";
					if(mysql_query($sql)){
						alertInfo2($_['success_useradd'],"userlist.php",0);
					}else{
						alertInfo2($_['fail_useradd'],"",1);
					}
				}else{
					alertInfo("未知错误，上传失败，请重新上传。",'',1);
					exit();
				}
			}
			break;

		case "edit":
			$id=sqlReplace(trim($_GET["id"]));
			checkData($id,"ID",0);
			$userAccount=sqlReplace(trim($_POST["account"]));
			$userPass=sqlReplace(trim($_POST["pass"]));
			$userMobile=sqlReplace(trim($_POST["mobile"]));
			$userEmail=sqlReplace(trim($_POST["email"]));
			$userIsVip=sqlReplace(trim($_POST["isvip"]));
			$userName=sqlReplace(trim($_POST["username"]));
			$userNickName=sqlReplace(trim($_POST["nickname"]));
			$userSex=sqlReplace(trim($_POST["sex"]));
			$userBrithday=sqlReplace(trim($_POST["brithday"]));
			$userProvince=sqlReplace(trim($_POST["province"]));
			$userCity=sqlReplace(trim($_POST["city"]));
			$userQQ=sqlReplace(trim($_POST["qq"]));
			$userSina=sqlReplace(trim($_POST["sina"]));
			$userIntro=sqlReplace(trim($_POST["intro"]));
			$userNote=sqlReplace(trim($_POST["note"]));
			$userInfo=sqlReplace(trim($_POST["info"]));
			$userPhoto=sqlReplace(trim($_FILES['file']['name']));
			$userAddress=sqlReplace(trim($_POST["address"]));
			$salt=rand(1000,9999);
			if(empty($userAccount)){
				alertInfo($_['alert_useraccount'],'useredit.php?id='.$id,0);
			}
			if(empty($userPass)){
				alertInfo($_['alert_userpass'],'useredit.php?id='.$id,0);
			}
			if(empty($userMobile)){
				alertInfo($_['alert_usermobile'],'useredit.php?id='.$id,0);
			}
			if(empty($userEmail)){
				alertInfo($_['alert_useremail'],'useredit.php?id='.$id,0);
			}

			$sql="select * from ".DB_TABLE_PREFIX."user where user_id=".$id;
			$result=mysql_query($sql);
			$row=mysql_fetch_assoc($result);
			$userPass2=$row["user_password"];

			if(empty($userPhoto)){
				$userPhoto=$filename1="";
				if($userPass2==$userPass){
					$sqlstr="update ".DB_TABLE_PREFIX."user set user_account='".$userAccount."',user_password='".$userPass2."',user_mobile='".$userMobile."',user_email='".$userEmail."',user_isvip='".$userIsVip."',user_Name='".$userName."',user_nickname='".$userNickName."',user_sex='".$userSex."',user_birthday='".$userBrithday."',user_province='".$userProvince."',user_city='".$userCity."',user_qq='".$userQQ."',user_sina='".$userSina."',user_Intro='".$userIntro."',user_note='".$userNote."',user_info='".$userInfo."',user_photo='".$filename1."',user_address='".$userAddress."' where user_id=".$id;
					if(mysql_query($sqlstr)){
						alertInfo2($_['success_usersave'],'userlist.php',0);
					}else{
						alertInfo2($_['fail_usersave'],'',1);
					}
				}else{
					$sqlstr="update ".DB_TABLE_PREFIX."user set user_account='".$userAccount."',user_password='".md5(md5($userPass).$salt)."',user_mobile='".$userMobile."',user_email='".$userEmail."',user_isvip='".$userIsVip."',user_Name='".$userName."',user_nickname='".$userNickName."',user_sex='".$userSex."',user_birthday='".$userBrithday."',user_province='".$userProvince."',user_city='".$userCity."',user_qq='".$userQQ."',user_sina='".$userSina."',user_Intro='".$userIntro."',user_note='".$userNote."',user_info='".$userInfo."',user_photo='".$filename1."',user_address='".$userAddress."',user_salt='".$salt."' where user_id=".$id;
					if(mysql_query($sqlstr)){
						alertInfo2($_['success_usersave'],'userlist.php',0);
					}else{
						alertInfo2($_['fail_usersave'],'',1);
					}
				}
			}else{
				$f_name=$_FILES['file']['name'];
				$f_size=$_FILES['file']['size'];
				$f_tmpName=$_FILES['file']['tmp_name'];
				$f_ext=strtolower(preg_replace('/.*\.(.*[^\.].*)*/iU','\\1',$f_name));
				$f_extList="png|jpg|gif|swf";
				$f_dir="../userfiles/user";
				$f_exts=explode("|",$f_extList);
				$checkExt=false;
				foreach($f_exts as $v){
					if($f_ext==$v){
						$checkExt=true;
						break;
					}
				}
				if(!$checkExt){
					alertInfo("文件格式不在允许范围",'useredit.php?id='.$id,1);
					exit();
				}
				if(!file_exists("$f_dir"))
					@mkdir($f_dir,0777);
					$date=date('YmdHis');
					$filename=$f_dir."/".$date.".".$f_ext;
					$filename1=$date.".".$f_ext;
				if(copy($f_tmpName,$filename)){
					if($userPass2==$userPass){
						$sqlstr="update ".DB_TABLE_PREFIX."user set user_account='".$userAccount."',user_password='".$userPass2."',user_mobile='".$userMobile."',user_email='".$userEmail."',user_isvip='".$userIsVip."',user_Name='".$userName."',user_nickname='".$userNickName."',user_sex='".$userSex."',user_birthday='".$userBrithday."',user_province='".$userProvince."',user_city='".$userCity."',user_qq='".$userQQ."',user_sina='".$userSina."',user_Intro='".$userIntro."',user_note='".$userNote."',user_info='".$userInfo."',user_photo='".$filename1."',user_address='".$userAddress."' where user_id=".$id;
						if(mysql_query($sqlstr)){
							alertInfo($_['success_usersave'],'userlist.php',0);
						}else{
							alertInfo($_['fail_usersave'],'',1);
						}
					}else{
						$sqlstr="update ".DB_TABLE_PREFIX."user set user_account='".$userAccount."',user_password='".md5(md5($userPass).$salt)."',user_mobile='".$userMobile."',user_email='".$userEmail."',user_isvip='".$userIsVip."',user_Name='".$userName."',user_nickname='".$userNickName."',user_sex='".$userSex."',user_birthday='".$userBrithday."',user_province='".$userProvince."',user_city='".$userCity."',user_qq='".$userQQ."',user_sina='".$userSina."',user_Intro='".$userIntro."',user_note='".$userNote."',user_info='".$userInfo."',user_photo='".$filename1."',user_address='".$userAddress."',user_salt='".$salt."' where user_id=".$id;
						if(mysql_query($sqlstr)){
							alertInfo($_['success_usersave'],'userlist.php',0);
						}else{
							alertInfo($_['fail_usersave'],'useredit.php?id='.$id,0);
						}
					}
				}else{
					alertInfo("未知错误，上传失败，请重新上传。",'useredit.php?id='.$id,0);
					exit();
				}
			}
			break;

		case "del":
			$id=sqlReplace(trim($_GET["id"]));
			checkData($id,"ID",0);
			$sql="select * from ".DB_TABLE_PREFIX."user where user_id=".$id;
			$rs=mysql_query($sql);
			$row=mysql_fetch_assoc($rs);
			$userPhoto=$row["user_photo"];
			if(file_exists("../userfiles/user/".$userPhoto)){
				@unlink("../userfiles/user/".$userPhoto);
			}
			$sqlStr="delete from ".DB_TABLE_PREFIX."user where user_id=".$id;
			if(mysql_query($sqlStr)){
				alertInfo2($_['success_userdel'],'',1);
			}else{
				alertInfo2($_['fail_userdel'],'',1);
			}
			break;

		case "delAll":
			if(empty($_POST["id_list"])){
				alertInfo2($_['text_selDel'],"",1);	
			}
			$listall=$_POST["id_list"];
			foreach($listall as $listid){
				$sql="select * from ".DB_TABLE_PREFIX."user where user_id=".$listid;
				$rs=mysql_query($sql);
				$row=mysql_fetch_assoc($rs);
				$userPhoto=$row["user_photo"];
				if(file_exists("../userfiles/user/".$userPhoto)){
					@unlink("../userfiles/user/".$userPhoto);
				}
				$sqlStr="delete from ".DB_TABLE_PREFIX."user where user_id=".$listid;
				if(!mysql_query($sqlStr)){
					alertInfo2($_['fail_userdel'],'',1);
				}
			}
			alertInfo2($_['success_userdel'],'',1);
			break;
			
		case "rmd":
			$i=trim($_POST["i"]);
			if(empty($i))
			{
				alertInfo('当前没有需要保存的内容','userlist.php',0);
			}
			$i=checkData2($i,"11",0);
			for($x=1;$x<=$i;$x++){
				$tempId=$_POST["id".$x];
				$tempId=checkData2($tempId,'ID11',0);
				if(empty($_POST["isRmd".$x]))
				{
					$tempRmd="";
				}else{
					$tempRmd=$_POST["isRmd".$x];
				}
				if($tempRmd=="on"){
					$tempRmd=1;
				}else{
					$tempRmd=0;
				}
				$sqlStrt="update ".DB_TABLE_PREFIX."user set user_isvip=".$tempRmd." where user_id=".$tempId."";
				if(!mysql_query($sqlStrt)){
					alertInfo2('保存失败! 原因：SQL更新失败','',1);
				}
			}
			alertInfo2('保存成功!','',1);
			break;
	}
?>