<?php

/**
 * adminadd.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

?><?php
	require_once('inc/config.php');
	require_once('../lang/'.$language.'/admin/common.php');
	require_once('admincheck.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_adminAdd']?> </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
 </head>
 <body>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li class="l1"><a href="adminlist.php" target="mainFrame" ><?php echo $_['tab_adminList']?></a> </li>
				<li><a href="adminadd.php"><?php echo $_['tab_adminAdd']?></a> </li>
			</ul>		
		</div>
		<div class="listintor">
			<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" />
				<span><?php echo $_['text_position']?>：<?php echo $_['position_system']?> －&gt; <strong><?php echo $_['tab_adminAdd']?></strong></span>
			</div>
			<div class="header2"><span><?php echo $_['tab_adminAdd']?></span></div>
			<div class="fromcontent">
				<form name="addadminForm" method="post" action="admin_do.php?action=add">
					<p><label><?php echo $_['text_adminAccount']?>：</label><input class="in1" type="text" name="account" id="account"/><span class="start"> *</span>
					</p>
					<p><label><?php echo $_['text_adminpwd']?>：</label><input class="in1" type="password" name="password" id="password"/><span class="start"> * <?php echo $_['text_pointPwd']?></span></p>
					<p><label>&nbsp;</label><input type="image" src="images/submit1.gif" width="56" height="20" alt="<?php echo $_['alt_submit']?>" onClick="return checkInput();"/></p>
					<script language="javascript">
						function checkInput(){
							if(document.addadminForm.account.value=='') {
								document.addadminForm.account.focus();
								alert("<?php echo $_['alert_account']?>");
								return false;
							}
							if(document.addadminForm.password.value=='') {
								document.addadminForm.password.focus();
								alert("<?php echo $_['alert_pwd']?>");
								return false;
							}
							if(document.addadminForm.password.value.length<6){
								document.addadminForm.password.value="";
								document.addadminForm.password.focus();
								alert("<?php echo $_['error_adminPwd_length']?>");
								return false;
							}
						}
					</script>
				</form>
			</div>
		</div>
	</div>
 </body>
</html>
