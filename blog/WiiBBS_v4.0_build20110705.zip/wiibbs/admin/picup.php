<?php

/**
 * picup.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	require_once('inc/config.php');
	require_once('../lang/'.$language.'/admin/common.php');
	require_once('admincheck.php');
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
	<title> <?php echo $_['header_upPic'];?> </title>
	<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>
	<?php
		$action=(empty($_GET["action"]))?'':$_GET['action'];
		$msg="";
		if($action=='up'){
			$f_name=$_FILES['file']['name'];
			$f_size=$_FILES['file']['size'];
			$f_tmpName=$_FILES['file']['tmp_name'];
			$f_ext=strtolower(preg_replace('/.*\.(.*[^\.].*)*/iU','\\1',$f_name));
			$f_extList="png|jpg|gif";

			$f_exts=explode("|",$f_extList);
			$checkExt=true;
			foreach ($f_exts as $v)
				if ($f_ext==$v){
					$checkExt=false;
					break;
				}

			if ($checkExt) {
				alertInfo2(	$_['text_checkext'],'',1);
				exit();
			}

			if ($f_size>200*1024){
				alertInfo2($_['text_picSize'],'',1);
				exit();
			}
			if($f_size>1048576){
				$f_size=$f_size/1048576;
				$f_size=number_format($f_size,2)."MB";
			}else{
				$f_size=$f_size/1024;
				$f_size=intval($f_size)."KB";
			}
			if (!file_exists("../userfiles"))
				@mkdir("../userfiles",0777);
				$random= rand(100,999); 
				$f_names= time().$random.".".$f_ext;
				$filenames="../userfiles"."/".$f_names;
				$msg=$_['text_picMsg1'].$f_ext.$_['text_picMsg2'].$f_size."";
				if (copy($f_tmpName,$filenames)){
					echo "<script language='javascript'>";
					echo "alert('".$msg."');";
					echo "window.opener.document.getElementById('addadminForm').pic.value='userfiles/".$f_names."';";
					echo "window.close();";
					echo "</script>";
				}else{
					alertInfo2($_['text_uploarFail'],'',1);
					exit();
				}
			}
		?>
	<div id="pic">
		<div id="content1">
			<h1><?php echo $_['header_upPic'];?></h1>
			<div id="intro">
			<form action="picup.php?action=up" method="post" enctype="multipart/form-data" name="form1" id="form1">
				<p><input type="file" name="file" class="botton"/>
				<input type="submit" name="Submit" value="上传" class="button"/></p>
			</form>
			<div class="point">
				<p class="important"><?php echo $_['text_point'];?>：</p>
				<p>1.图片格式只能为gif|jpg|png。</p>
				<p>2.图片的大小必须小于200K。</p>
				<p class="important"><?php echo $msg?></p>
			</div>
			<p class="center"><a href="#" onclick="javascript:window.close();">【关闭窗口】</a></p>
			</div>
		</div>
	</div>
</body>
</html>