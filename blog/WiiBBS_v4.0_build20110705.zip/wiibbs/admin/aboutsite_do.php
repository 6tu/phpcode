<?php

/**
 * aboutsite_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */


	require_once('inc/config.php');
	require_once('../lang/'.$language.'/admin/common.php');
	require_once('../lang/'.$language.'/admin/site.php');
	require_once("admincheck.php");
	//checkAdminRight("122",$_SESSION[WiiBBS_ID."admingroup"]);
	$act=trim($_GET['act']);
	switch($act)
	{
		case 'base':
			$name=checkData2(Trim($_POST["name"]),$_['alert_name_r'],1);
			$a_width=sqlReplace(Trim($_POST["width"]));
			$a_count=sqlReplace(Trim($_POST["count"]));
			$express=sqlReplace(trim($_POST['express']));
			$ubb=sqlReplace(trim($_POST['ubb']));
			$f_name=$_FILES['file']['name'];
			$f_size=$_FILES['file']['size'];
			$f_tmpName=$_FILES['file']['tmp_name'];
			if (!empty($f_name)){
				$f_ext=strtolower(preg_replace('/.*\.(.*[^\.].*)*/iU','\\1',$f_name));
				$f_extList="png|jpg|gif";
				$f_dir="../userfiles/logo";

				$f_exts=explode("|",$f_extList);
				$checkExt=false;
				foreach ($f_exts as $v)
					if ($f_exts==$v){
						$checkExt=true;
						break;
					}

					if ($checkExt) {
						alertInfo($_['alter_f_ext'],'',1);
						exit();
					}

					if ($f_size>20*1024){
						alertInfo($_['alter_f_size'],'',1);
						exit();
					}

					if (!file_exists("$f_dir"))
						@mkdir($f_dir,0777);
					$pic='userfiles/logo/logo.jpg';
					if (copy($f_tmpName,$f_dir."/"."logo.jpg")){
								
					}else{
						alertInfo($_['alter_f_upload'],'',1);
						exit();
					}
					$sqlStr="update ".DB_TABLE_PREFIX."site set site_name='".$name."',site_logo='".$pic."',site_width=".$a_width.",site_count=".$a_count.",site_express='".$express."',site_ubb='".$ubb."'";
			}else{
				$sqlStr="update ".DB_TABLE_PREFIX."site set site_name='".$name."',site_width=".$a_width.",site_count=".$a_count.",site_express='".$express."',site_ubb='".$ubb."'";
			}
			if(mysql_query($sqlStr)){
				writeConfig();
				alertInfo($_['success_setConf'],"aboutsite.php",0);
			}else{
				alertInfo($_['fail_setConf'],"aboutsite.php",0);
			}
		break;
		case 'advance':
			$mSMTP=sqlReplace(Trim($_POST["smtp"]));
			$mAddress=sqlReplace(Trim($_POST["address"]));
			$mAccount=sqlReplace(Trim($_POST["account"]));
			$mPass=sqlReplace(Trim($_POST["password"]));
			$filter=HTMLEncode(trim($_POST['filter']));
			$timezone=sqlReplace(trim($_POST['timezone']));
			$sql="update ".DB_TABLE_PREFIX."site set site_mailsmtp='".$mSMTP."',site_mailaddress='".$mAddress."',site_mailaccount='".$mAccount."',site_mailpassword='".$mPass."',site_filter='".$filter."',site_timezone='".$timezone."'";
			if(mysql_query($sql))
			{
				writeConfig();
				alertInfo($_['success_advance'],'aboutsiteadvance.php',0);
			}else{
				alertInfo($_['fail_advance'],'aboutsiteadvance.php',0);
			}
			break;
		case 'ucenter':
			$uccode=trim($_POST['uccode']);
			$uccode=str_replace("\'","'",$uccode);
			$uccode=str_replace("\‘","'",$uccode);
			if(empty($uccode))
			{
				alertInfo2($_['alert_ucenter'],'',1);
			}
			if(file_exists("../include/ucenter_key.php"))
			{
				@unlink("../include/ucenter_key.php");
			}
			$handle=fopen("../include/ucenter_key.php",'w+');
			$str="<?php ";
			$str.="\n";
			$str.=$uccode;
			$str.="\n";
			$str.=" ?>";
			fwrite($handle,$str);
			fclose($handle);
			alertInfo2($_['success_ucenter'],'aboutsiteuc.php',0);
	}

	function writeConfig(){
		$sqlStr="select * from ".DB_TABLE_PREFIX."site limit 0,1";
		$rs= mysql_query($sqlStr) or die (ERROR_SELECTSQL);
		$row = mysql_fetch_assoc($rs);
		if($row){
			$str.="<?php \n";
			$str.="define('SITENAME', '".$row["site_name"]."');//网站名称\n";
			$str.="define('SITELOGO', '".$row["site_logo"]."');//logo\n";
			$str.="define('SITEWIDTH', '".$row["site_width"]."');//网站宽带\n";
			$str.="define('SITECOUNT', '".$row["site_count"]."');//是否显示论坛统计\n";
			$str.="define('MAILSMTP', '".$row["site_mailsmtp"]."');//SMTP服务器\n";
			$str.="define('MAILACCOUNT', '".$row["site_mailaccount"]."');//Email帐号\n";
			$str.="define('MAILAPASSWORD', '".$row["site_mailpassword"]."');//Email密码\n";
			$str.="define('MAILADDRESS', '".$row["site_mailaddress"]."');//Email地址\n";
			$str.="define('SITECODE', '".$row["site_code"]."');//统计代码\n";
			$str.="define('SITEFILTER', '".$row["site_filter"]."');//过滤关键词\n";
			$str.="define('SITETIMEZONE', '".$row["site_timezone"]."');//时区\n";
			$str.="define('SITEEXPRESS', '".$row["site_express"]."');//是否开启表情\n";
			$str.="define('SITEUBB', '".$row["site_ubb"]."');//是否开启ubb\n";
			$str.="define('SITEEMAIL', '0');//是否注册email\n";
			$str.="define('SITEPHONE', '0');//是否注册手机\n";
			$str.="?>";
			$fp=fopen("../cache/config.php","w+");
			fwrite($fp,$str);
			fclose($fp);
			
		}
	}
	
?>