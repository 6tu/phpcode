<?php

/**
 * configue.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

require_once('inc/config.php');
require_once('../lang/'.$language.'/admin/common.php');
require_once 'admincheck.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_setConfigue']?> </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
 </head>
 <body>
<div class="bgintor">
   <div class="tit1">
	<ul>
		<li><a href="configue.php" target="mainFrame"><?php echo $_['header_setConfigue']?></a> </li>
	</ul>		
</div>
	<div class="listintor">
		<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" />
			<span><?php echo $_['text_position']?>：<?php echo $_['position_web']?> －&gt; <strong><?php echo $_['header_setConfigue']?></strong></span>
		</div>
		<div class="header2"><span><?php echo $_['header_setConfigue']?></span>
		</div>
		<div class="fromcontent">
			<form action="configue_do.php" method="post" id="doForm" name='doForm' enctype="multipart/form-data">
				
				<p><label>&nbsp;</label><?php if (!empty($siteLogo)) echo "<img src='../".$siteLogo."' alt=''/>"?></p>
				<p><label><?php echo $_['text_logo']?>：</label><input type="file" name="file" class="button"/></p>
				<p><label><?php echo $_['text_webName']?>：</label><input class="in1" name="name" value="<?php echo $siteName?>"/><span class="start"> *</span>
				</p>
				<p><label><?php echo $_['text_icp']?>：</label><input class="in1" type="text" name="accreditation" value="<?php echo $accreditation?>"/></p>
				<p><label><?php echo $_['text_webWidth']?>：</label><input type="radio" name="width" value="0" <?php if ($siteWidth=="0") echo "checked"?>/> <?php echo $_['text_standard']?>  <input type="radio" name="width" value="1" <?php if ($siteWidth=="1") echo "checked"?>/> <?php echo $_['text_adaptive']?></p>
				<p><label><?php echo $_['text_smtp']?>：</label><input type="text" class="in1" name="mailSMTP" value="<?php echo $mailSMTP?>"/></p>
				<p><label><?php echo $_['text_emailAddress']?>：</label><input type="text"  class="in1" name="mailAddress" value="<?php echo $mailAddress?>"/></p>
				<p><label><?php echo $_['text_emailAcount']?>：</label><input type="text" class="in1" name="mailAccount" value="<?php echo $mailAccount?>"/></p>
				<p><label><?php echo $_['text_emailPwd']?>：</label><input type="password" class="in1" name="mailPass" value="<?php echo $mailPassword?>"/></p>
				<p><label>&nbsp;</label>
					<input type="image" src="images/submit1.gif" width="56" height="20" alt="提交" onClick="return check();"/>
				</p>
			</form>
			<script language="javascript">
					function check(){
					  if(document.doForm.name.value=='') {
							document.doForm.name.focus();
							alert("<?php echo $_['alert_webName']?>");
							return false;
						}
					}
			</script>
		</div>
	</div>
  </div>
 </body>
</html>
