<?php

/**
 * admin.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

?><?php 
require_once('inc/config.php');
require_once('../lang/'.$language.'/admin/common.php');
require_once('../lang/'.$language.'/admin/admin.php');
require_once("admincheck.php");
require_once '../include/version.php';
?>
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_admin_title']?> </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
 </head>
 <body id="flow">
	<div class="bgintor">
		<div class="bgintor2">
			<div class="bgvline"></div>
			<div class="bgtitle"><span><img src="images/home.gif" width="16" height="15" alt="" /></span>
				<span><strong><?php echo $_['text_position']?></strong>：<?php echo $_['text_position_index']?></span></div>
			<div class="bgintor3">
				<div class="left">
					<div class="title2"></div>
					<div class="title1"><span class="s1"><?php echo $_['text_profile']?></span></div>
					<div class="bgintor4">
					<?php
						$sql="select * from ".DB_TABLE_PREFIX."admin,".DB_TABLE_PREFIX."admingroup where admingroup_id=admin_group";
						$rs=mysql_query($sql);
						$row=mysql_fetch_assoc($rs);
						if ($row){
					?>	
						<p><?php echo $_['text_proAdminGroup']?>：<?php echo $row['admingroup_name']?></p>
						<p><?php echo $_['text_proAccount']?>：<?php echo $row['admin_account']?></p>
						<p><?php echo $_['text_proLoginCount']?>：<?php echo $row['admin_logincount']?></p>
					<?php
						}	
					?>
					</div>
				</div>
			</div>
			<div class="bgintor3">
				<div class="left">
					<div class="title2"></div>
					<div class="title1"><span class="s1"><?php echo $_['text_sysInfor']?></span></div>
					<div class="bgintor4">
						<p><?php echo $_['text_wiibbsUserCount'];?>：<span style="color:red;"><strong><script language='javascript' src="http://p.wiipu.com/WiiBBS/count.php"></script></strong></span> (<?php echo $_['text_adminTip'];?>)</p>
						<p><?php echo $_['text_sysName']?>：WiiBBS</p>
						<p><?php echo $_['text_version'];?>：<?php echo $version."(".$subversion.")";?> </p>
						<p><?php echo $_['text_bbsUpdate'];?>：<?php echo $updateTime;?> </p>
						<p><br/><br/></p>
					</div>
				</div>
			</div>
			<div class="bgintor3">
				<div class="left">
					<div class="title2"></div>
					<div class="title1"><span class="s1"><?php echo $_['text_bbsStat'] ;?></span></div>
					<div class="bgintor4">
						<?php
							$sql="select count(user_id) as ct from ".DB_TABLE_PREFIX."user";
							$rs=mysql_query($sql);
							$row=mysql_fetch_assoc($rs);
							$userCount=$row["ct"];
							
							$sql="select counter_number from ".DB_TABLE_PREFIX."counter where counter_type='day'";
							$rs=mysql_query($sql);
							$row=mysql_fetch_assoc($rs);
							$dayCount=$row["counter_number"];

							$sql="select counter_number from ".DB_TABLE_PREFIX."counter where counter_type='total'";
							$rs=mysql_query($sql);
							$row=mysql_fetch_assoc($rs);
							$totalCount=$row["counter_number"];
						?>
						<p><?php echo $_['text_userCount'];?>：<?php echo $userCount;?></p>
						<p><?php echo $_['text_dayCount'];?>： <?php echo $dayCount;?></p>
						<p><?php echo $_['text_totalCount'];?>： <?php echo $totalCount;?></p>
					</div>
				</div>
			</div>
			<div class="bgintor3">
				<div class="left">
					<div class="title2"></div>
					<div class="title1"><span class="s1"><?php echo $_['text_upgrade'];?></span></div>
					<div class="bgintor4">
						<p><script language='javascript' src="http://p.wiipu.com/WiiBBS/upgrade.php"></script></p>
						<p><br/><br/></p>
					</div>
				</div>
			</div>
			<div id="main"></div>
			<div class="bgintor5">
				<div class="title2"></div>
				<div class="title1"><span class="s1"><?php echo $_['text_bbsNews'];?></span></div>
				<ul>
					<script language='javascript' src="http://www.wiipu.com/news/wiibbs.php"></script>
				</ul>
			</div>
		</div>
	</div>
 </body>
</html>
