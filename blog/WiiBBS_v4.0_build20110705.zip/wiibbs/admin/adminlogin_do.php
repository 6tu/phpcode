<?php

/**
 * adminlogin_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

require_once('inc/config.php');
require_once('../lang/'.$language.'/admin/common.php');
require_once("db_conn.php");
$name=sqlReplace(trim($_POST["name"]));
$pass=sqlReplace(trim($_POST["password"]));
$code=sqlReplace(trim($_POST["code"]));
if((empty($name)) || (empty($pass)) || (empty($code))){
	alertInfo2($_['alert_nullP'],"adminlogin.php",0);
	exit();
}
if($code!=$_SESSION["imgcode"]){
	alertInfo2($_['alert_code'],"adminlogin.php",0);
	exit();
}

$sqlStr="select * from ".DB_TABLE_PREFIX."admin,".DB_TABLE_PREFIX."admingroup where admin_account='".$name."' and admin_password='".md5($pass)."' and admingroup_id=admin_group";
$rs=mysql_query($sqlStr);
$row=mysql_fetch_assoc($rs);
	if(!$row){
		alertInfo2($_['error_accountPWD'],"adminlogin.php",1); 	
	}else{
		$admin_count=$row['admin_logincount']+1;
		$ip=$_SERVER['REMOTE_ADDR'];
		$sql="update ".DB_TABLE_PREFIX."admin set admin_logintime='".date('Y-m-d H:i:s')."',admin_loginip='".$ip."',admin_logincount='".$admin_count."' where admin_account='".$name."'";
		if(!mysql_query($sql))
		{
			alertInfo2($_['fail_updateAdmin'],'adminlogin.php',0);
		}
		$_SESSION[WiiBBS_ID."admin"]=$name;
		$_SESSION[WiiBBS_ID."admingroup"]=$row['admingroup_right'];
		header("location:adminindex.php");
	}
?>