<?php

/**
 * db_conn.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	//error_reporting(0);
	require_once("inc/function.php");
	header("content-type:text/html;charset=utf-8");
	session_start();
	ob_start();
	require_once("../include/config.php");
	$db_connect = mysql_connect(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD);
	if (!$db_connect) {
		die ($_['fail_connectDatabase']);
	}
	mysql_select_db(DB_DATABASE, $db_connect) or die ($_['fail_findDatabase']);
	mysql_query("set names utf8;");
?>