<?php

/**
 * aboutsite.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

?>
<?php
	require_once('inc/config.php');
	require_once('../lang/'.$language.'/admin/common.php');
	require_once('../lang/'.$language.'/admin/site.php');
	require_once("admincheck.php");
	//checkAdminRight("122",$_SESSION[WiiBBS_ID."admingroup"]);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_site'];?> </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
 </head>
 <?php
	$sqlStr="select  * from ".DB_TABLE_PREFIX."site limit 0,1";
	$rs=mysql_query($sqlStr);
	$row=mysql_fetch_assoc($rs);
	If(!$row){
		alertInfo($_['error_siteInitialize'],"admin.php",0);
	}Else{
		$logo=$row["site_logo"];
		$name=$row["site_name"];
		$a_width=$row["site_width"];
		$a_count=$row["site_count"];
		$express=$row['site_express'];
		$ubb=$row['site_ubb'];
	}
 ?>
 <body>
 	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li><a href="aboutsite.php" target="mainFrame" ><?php echo $_['tab_base'];?></a> </li>
				<li class="l1"><a href="aboutsiteadvance.php" target="mainFrame"><?php echo $_['tab_advance'];?></a> </li>
				<li class="l1"><a href="aboutsiteuc.php" target="mainFrame"><?php echo $_['tab_UCenter'];?></a> </li>
			</ul>		
		</div>
		<div class="listintor">
			<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" />
				<span><?php echo $_['text_position']."：".$_['position_bbs'];?> －&gt; <strong><?php echo $_['tab_base'];?></strong></span>
			</div>
			<div class="header2"><span><?php echo $_['tab_base'];?></span>
			</div>
			<div class="fromcontent">
				<form id="form2" name="addForm" method="post" action="aboutsite_do.php?act=base" enctype="multipart/form-data">
					<?php if (!empty($logo)){?>
					<p><label class="long">&nbsp;</label> <img src='../<?php echo $logo?>' alt=''/> </p>
					<?php }?>
					<p><label class="long"><?php echo $_['text_logo']?>：</label><input type="file" name="file" class="button"/></p>
					<p><label class="long"><?php echo $_['text_webName']?>：</label><input class="in1" name="name" value="<?php echo $name?>"/><span class="start">*</span>
					</p>
					<p><label class="long"><?php echo $_['text_webWidth']?>：</label><input type="radio" name="width" value="226" <?php If($a_width=="226")echo "checked"?>/> <?php echo $_['text_standard']?>  <input type="radio" name="width" value="0" <?php If($a_width=="0") echo "checked"?>/> <?php echo $_['text_adaptive']?></p>
					<p><label class="long"><?php echo $_['text_count'];?>：</label><input type="radio" name="count" value="0" <?php If($a_count=="0") echo "checked"?>/><?php echo $_['text_no'];?><input type="radio" name="count" value="1" <?php If($a_count=="1") echo "checked"?>/><?php echo $_['text_yes'];?> <span class='start'>（<?php echo $_['text_tip1'];?>）</span></p>
					<p><label class="long"><?php echo $_['text_express'];?>：</label><input type="radio" name="express" value="0" <?php If($express=="0") echo "checked"?>/><?php echo $_['text_no'];?><input type="radio" name="express" value="1" <?php If($express=="1") echo "checked"?>/><?php echo $_['text_yes'];?></p>
					<p><label class="long"><?php echo $_['text_ubb'];?>：</label><input type="radio" name="ubb" value="0" <?php if($ubb==0) echo "checked";?> /><?php echo $_['text_no'];?><input type="radio" name="ubb" value="1" <?php if($ubb==1) echo "checked";?>/><?php echo $_['text_yes'];?> <span class='start'>（<?php echo $_['text_tip1'].$_['text_tip2']?>）</span></p>
					<p><label class="long">&nbsp;</label><input type="image" src="images/submit1.gif" width="56" height="20" alt="<?php echo $_['alt_submit'];?>" onClick="return checkIn();"/>
					</p>
					<script language="javascript">
						function checkspace(checkstr) {
						  var str = '';
						  for(i = 0; i < checkstr.length; i++) {
							str = str + ' ';
						  }
						  return (str == checkstr);
						}
						function checkIn(){
							if(checkspace(document.addForm.name.value)) {
								alert("<?php echo $_['alert_name'];?>");
								document.addForm.name.focus();
								return false;
							}
						}
					</script>
				</form>
			</div>
		</div>
	</div>
 </body>
</html>
