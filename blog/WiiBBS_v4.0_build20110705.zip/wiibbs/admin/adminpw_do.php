<?php

/**
 * adminpw_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once('inc/config.php');
	require_once('../lang/'.$language.'/admin/common.php');
	require_once 'admincheck.php';
	$pw=checkData2(trim($_POST["password"]),$_['text_oldPWD'],1);
	$pw1=checkData2(trim($_POST["password1"]),$_['text_newPWD'],1);
	$pw2=checkData2(trim($_POST["password2"]),$_['text_PWD2'],1);
	if($pw1!=$pw2)
		alertInfo2($_['alert_pwd3'],"",1);
	//密码不小于6位
	if(strLen($pw1)<6) 
		alertInfo2($_['error_adminPwd_length'],"",1);
	//判断原密码是否正确
	$sqlStr="select * from ".DB_TABLE_PREFIX."admin where admin_account='".$_SESSION[WiiBBS_ID."admin"]."' and admin_password='".md5($pw)."'";
	$rs=mysql_query($sqlStr);
	$row=mysql_fetch_array($rs);
	if(!$row){
		alertInfo($_['error_oldPWD'],"adminpw.php",0);
	}else{
		$row["admin_password"]=md5($pw2);
		$sql="update ".DB_TABLE_PREFIX."admin set admin_password='".md5($pw2)."' where admin_account='".$_SESSION[WiiBBS_ID."admin"]."'";
		if(mysql_query($sql)){
			alertInfo($_['success_updatePwd'],"adminpw.php",0);
		}else{
			alertInfo($_['fail_updatePWD']s,"adminpw.php",0);
		}			
	}
?>
 