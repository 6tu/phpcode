<?php

/**
 * topicsearch.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	require_once("inc/config.php");
	require_once('../lang/'.$language.'/admin/topic_config.php');
	require_once("../lang/".$language."/admin/common.php");
	require_once("admincheck.php");
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_topicSearch']?> </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
 </head>
 <body>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li class="l1"><span><span><a href="topiclist.php" target="mainFrame"><?php echo $_['tab_topiclist']?></a></span></span></li>
				<li><span><span><a href="#" target="mainFrame"><?php echo $_['tab_topicsearch']?></a></span></span></li>
			</ul>
		</div>
		<div class="listintor">
			<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" />
				<span><?php echo $_['text_position']?>：<?php echo $_['position_topic']?> －&gt; <strong><?php echo $_['tab_topicsearch']?></strong></span>
			</div>
			<div class="header2"><span><?php echo $_['tab_topicsearch']?></span></div>
			<div class="fromcontent">
				<form id="addadminForm" name="addadminForm" method="post" action="topic_searchlist.php">
					<p><span class="start">提示：支持模糊搜索，不必填写所有的项，填写关键字即可。</span></p>
					<p><?php echo $_['text_topictitle']?>：<input class="in1" type="text" id="title" name="title" /></p>
					<p>&nbsp;&nbsp;<?php echo $_['text_topicuser']?>：<input class="in1" type="text" id="user" name="user" /></p>
					<p><?php echo $_['text_topiccontent']?>：<input class="in1" type="text" id="content" name="content" /></p>
					<div class="btn">
						<input type="image" src="images/submit1.gif" width="56" height="20" alt="<?php echo $_['alt_submit']?>" onClick="return checkInput();"/>
					</div>
				</form>
			</div>
		</div>
	</div>
 </body>
</html>