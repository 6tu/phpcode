<?php

/**
 * menu.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

require_once('inc/config.php');
require_once('../lang/'.$language.'/admin/user_config.php');
require_once('../lang/'.$language.'/admin/board_config.php');
require_once('../lang/'.$language.'/admin/bbsstat_config.php');
require_once('../lang/'.$language.'/admin/topic_config.php');
require_once('../lang/'.$language.'/admin/common.php');
?><html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_memu']?> </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
   <script type="text/javascript">
	function display2(x){
		var s=document.getElementById(x);
		var imgs=x+"img";
		if(s.style.display=="none")
		{
			s.style.display="";
			document.getElementById(imgs).src="images/down.gif";
		}else{
			s.style.display="none";
			document.getElementById(imgs).src="images/aleft.gif";
		}
	}
  </script>
 </head>	
 <body id="flow">
	<div class="menu" id="me">
		<div class="menu_content">
			
			<div class="menu_h">
				<?php echo $_['position_board']?>
			</div>
			<div class="menu_intor">
				<p><a href="boardclass.php" target="mainFrame"><?php echo $_['menu_boardclass']?></a></p>
				<p><a href="boardlist.php" target="mainFrame"><?php echo $_['menu_boardList']?></a></p>
			</div>
			<div class="menu_h">
				<?php echo $_['position_topic']?>
			</div>
			<div class="menu_intor">
				<p><a href="topiclist.php" target="mainFrame"><?php echo $_['menu_topic']?></a></p>
				<p><a href="replylist.php" target="mainFrame"><?php echo $_['menu_reply']?></a></p>
				<p><a href="filelist.php" target="mainFrame"><?php echo $_['menu_file']?></a></p>
			</div>
			<div class="menu_h">
				<?php echo $_['position_user']?>
			</div>
			<div class="menu_intor">
				<p><a href="userlist.php" target="mainFrame"><?php echo $_['menu_userList']?></a></p>
				<p><a href="msgsendlist.php" target="mainFrame"><?php echo $_['menu_msgsend']?></a></p>
				<p><a href="bbs_admin.php" target="mainFrame"><?php echo $_['menu_bbsadmin']?></a></p>
			</div>
			<div class="menu_h">
				<?php echo $_['position_bbs']?>
			</div>
			<div class="menu_intor">
				<p><a href="adminlist.php" target="mainFrame"><?php echo $_['menu_adminList']?></a></p>
				<p><a href="aboutsite.php" target="mainFrame"><?php echo $_['menu_conf']?></a></p>
				<p><a href="themessite.php" target="mainFrame"><?php echo $_['menu_skin']?></a></p>
				<p><a href="linklist.php" target="mainFrame"><?php echo $_['menu_link']?></a></p>
				<p><a href="stat_bbs.php" target="mainFrame"><?php echo $_['menu_bbsstat']?></a></p>
				<p><a href="keywordlist.php" target="mainFrame"><?php echo $_['menu_keyword']?></a></p>
			</div>
			
		</div>
	</div>
 </body>
</html>
