<?php

/**
 * admingroupedit.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once('inc/config.php');
	require_once('../lang/'.$language.'/admin/common.php');
	require_once('admincheck.php');
	
	$id=sqlReplace($_GET['id']);
	$id=checkData($id,"ID",0);
	$sql="select * from ".DB_TABLE_PREFIX."admingroup where admingroup_id=$id";
	$rs=mysql_query($sql);
	$row=mysql_fetch_assoc($rs);
	if($row){
		$groupname=$row['admingroup_name'];
		$groupright=$row['admingroup_right'];
	}else{
		alertInfo($_['error_noinfor'],'',1);
	}
	function checkRight($str,$group){
		if(strpos($group,$str)>-1)
			return "checked='checked'";
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['text_edit'],"\"".$groupname."\"".$_['text_limit']?></title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
 </head>
 <body>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li  class="l1"><span><span><a href="admingrouplist.php" target="mainFrame"><?php echo $_['tab_groupList']?></a></span></span></li>
				<li   class="l1"><span><span><a href="admingroupadd.php"><?php echo $_['tab_groupAdd']?></a></span></span></li>
			</ul>		
		</div>
		<div class="listintor">
			<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" />
				<span><?php echo $_['text_position']?>：<?php echo $_['position_system']?> －&gt; <strong><?php echo $_['text_edit'],"\"".$groupname."\"".$_['text_limit']?></strong></span></div>
			<div class="header2"><span><?php echo $_['tab_groupAdd']?></span></div>
			<div class="content">
				<form action="admingroup_do.php?act=save&id=<?php echo $id?>" method="post" id="doForm" name="doForm" onSubmit="return Checker()">
					<table width="100%" border="0" cellspacing="1" cellpadding="0">
						<tr>
							<th width="50"><?php echo $_['text_check']?></th>
							<th><?php echo $_['text_limit'] ?></th>
						</tr>
						
						<tr>
							<td class="center"><input type="checkbox" name="id_list[]" value="121"
							<?php echo checkRight("121",$groupright)?>/></td>
							<td><?php echo $_['text_seeAdmin']?></td>
						</tr>
						<tr>
							<td class="center"><input type="checkbox" name="id_list[]" value="122"
							<?php echo checkRight("122",$groupright)?>/></td>
							<td><?php echo $_['text_manageAdmin']?></td>
						</tr>
						<tr>
							<td class="center"><input type="checkbox" name="id_list[]" value="131"
							<?php echo checkRight("131",$groupright)?>/></td>
							<td><?php echo $_['text_manageGroup']?></td>
						</tr>
						
						
					
						
						
						
					</table>
					<div class="btn">
						<input type="image" src="images/submit1.gif" width="56" height="20" alt="<?php echo $_['alt_submit']?>"/>
					</div>
				</form>
			</div>
		</div>
	</div>
 </body>
</html>