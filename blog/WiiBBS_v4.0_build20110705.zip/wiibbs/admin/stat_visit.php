<?php

/**
 * stat_visit.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	require_once("inc/config.php");
	require_once("../lang/".$language."/admin/bbsstat_config.php");
	require_once("../lang/".$language."/admin/common.php");
	require_once("admincheck.php");
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_visitstat']?> </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
 </head>
 <body>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li class="l1"><span><span><a href="stat_bbs.php" target="mainFrame"><?php echo $_['tab_bbsdata']?></a></span></span></li>
				<li><span><span><a href="#" target="mainFrame"><?php echo $_['tab_visitstat']?></a></span></span></li>
				<li class="l1"><span><span><a href="stat_online.php" target="mainFrame"><?php echo $_['tab_onlinestat']?></a></span></span></li>
			</ul>
		</div>
		<div class="listintor">
			<div class="header1">
				<img src="images/square.gif" width="6" height="6" alt="" /><span><?php echo $_['text_position']?>：<?php echo $_['position_bbs']?> －&gt; <strong><?php echo $_['tab_visitstat']?></strong></span>
			</div>
			<div class="header2"><span><?php echo $_['tab_visitstat']?></span></div>
			<div class="fromcontent">
				<?php
					if(isset($_GET['act']))
					{
						if(trim($_GET['act'])=='save')
						{
							$code=trim($_POST['code']);
							$sql="update ".DB_TABLE_PREFIX."site set site_code='".$code."'";
							if(mysql_query($sql))
							{
								writeConfig();
								alertInfo2('第三方统计代码保存成功','stat_visit.php',0);
							}else{
								alertInfo2('第三方统计代码保存失败','stat_visit.php',0);
							}
						}
					}
					$sql="select counter_number from ".DB_TABLE_PREFIX."counter where counter_type='day'";
					$rs=mysql_query($sql);
					$row=mysql_fetch_assoc($rs);
					$dayCount=$row["counter_number"];

					$sql="select counter_number from ".DB_TABLE_PREFIX."counter where counter_type='total'";
					$rs=mysql_query($sql);
					$row=mysql_fetch_assoc($rs);
					$totalCount=$row["counter_number"];
					$sql="select counter_number from ".DB_TABLE_PREFIX."counter where counter_type='total'";
					$rs=mysql_query($sql);
					$row=mysql_fetch_assoc($rs);
					$totalCount=$row["counter_number"];
					$sqlStr="select * from ".DB_TABLE_PREFIX."site limit 0,1";
					$rs= mysql_query($sqlStr) or die (ERROR_SELECTSQL);
					$row = mysql_fetch_assoc($rs);
					if($row){
						$code=$row["site_code"];
					}
				?>
				<p><img src="images/li1.gif" alt="·" /> 总浏览量：<?php echo $totalCount ?></p>
				<p><img src="images/li1.gif" alt="·" /> 今日浏览量：<?php echo $dayCount ?></p>
				<p><img src="images/li1.gif" alt="·" /><span class='start'> 网站统计：(请将从第三方统计(例如：cnzz，51.la，google等)获得的统计代码复制到下面的框中。)</span></p>
				<form action="stat_visit.php?act=save" method='post'>
					<p><textarea name="code" cols='60' rows='10'><?php echo $code;?></textarea></p>
					<div class="btn">
						<input type="image" src="images/submit1.gif" width="56" height="20" alt="提交"/>
					</div>
				</form>
			</div>
		</div>
	</div>
	<?php
		function writeConfig(){
		$sqlStr="select * from ".DB_TABLE_PREFIX."site limit 0,1";
		$rs= mysql_query($sqlStr) or die (ERROR_SELECTSQL);
		$row = mysql_fetch_assoc($rs);
		if($row){
			$str.="<?php \n";
			$str.="define('SITENAME', '".$row["site_name"]."');//网站名称\n";
			$str.="define('SITELOGO', '".$row["site_logo"]."');//logo\n";
			$str.="define('SITEWIDTH', '".$row["site_width"]."');//网站宽带\n";
			$str.="define('SITECOUNT', '".$row["site_count"]."');//是否显示论坛统计\n";
			$str.="define('MAILSMTP', '".$row["site_mailsmtp"]."');//SMTP服务器\n";
			$str.="define('MAILACCOUNT', '".$row["site_mailaccount"]."');//Email帐号\n";
			$str.="define('MAILAPASSWORD', '".$row["site_mailpassword"]."');//Email密码\n";
			$str.="define('MAILADDRESS', '".$row["site_mailaddress"]."');//Email地址\n";
			$str.="define('SITECODE', '".$row["site_code"]."');//统计代码\n";
			$str.="define('SITEFILTER', '".$row["site_filter"]."');//过滤关键词\n";
			$str.="define('SITETIMEZONE', '".$row["site_timezone"]."');//时区\n";
			$str.="define('SITEEXPRESS', '".$row["site_express"]."');//是否开启表情\n";
			$str.="define('SITEUBB', '".$row["site_ubb"]."');//是否开启ubb\n";
			$str.="define('SITEEMAIL', '0');//是否注册email\n";
			$str.="define('SITEPHONE', '0');//是否注册手机\n";
			$str.="?>";
			$fp=fopen("../cache/config.php","w+");
			fwrite($fp,$str);
			fclose($fp);
			
		}
	}
	?>
 </body>
</html>