<?php

/**
 * linkedit.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	require_once("inc/config.php");
	require_once("../lang/".$language."/admin/link_config.php");
	require_once("../lang/".$language."/admin/common.php");
	require_once("admincheck.php");
	
	$id=sqlReplace(trim($_GET["id"]));
	$sql="select * from ".DB_TABLE_PREFIX."link where link_id=".$id;
	$rs=mysql_query($sql);
	$row=mysql_fetch_assoc($rs);
	if($row){
		$linkName=$row["link_title"];
		$linkUrl=$row["link_url"];
		$linkPic=$row["link_pic"];
		$linkIndex=$row["link_index"];
	}else{
		alertInfo2($_['fail_linknoInfo'],"linklist.php",0);
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_linkEdit']?> </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
 </head>
 <body>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li class="l1"><span><span><a href="linklist.php" target="mainFrame"><?php echo $_['tab_linkList']?></a></span></span></li>
				<li class="l1"><span><span><a href="linkadd.php" target="mainFrame"><?php echo $_['tab_linkAdd']?></a></span></span></li>
			</ul>
		</div>
		<div class="listintor">
			<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" />
				<span><?php echo $_['text_position']?>：<?php echo $_['position_bbs']?> －&gt; <strong><?php echo $_['tab_linkEdit']?></strong></span>
			</div>
			<div class="header2"><span><?php echo $_['tab_linkEdit']?></span></div>
			<div class="fromcontent">
				<form id="addadminForm" name="addadminForm" method="post" action="link_do.php?act=edit&id=<?php echo $id;?>" enctype="multipart/form-data">
					<p><?php echo $_['text_linkname']?>：<input class="in1" type="text" id="name" name="name" value="<?php echo $linkName;?>"/><span class="start"> *</span></p>
					<p><?php echo $_['text_linkpic']?>：<input type="file" name="file" /></p>
					
					<p><?php echo $_['text_linkurl']?>：<input class="in1" type="text" id="url" name="url" value="<?php echo $linkUrl;?>"/><span class="start"> *</span></p>
					<div class="btn">
						<input type="image" src="images/submit1.gif" width="56" height="20" alt="<?php echo $_['alt_submit']?>" onClick="return checkInput();"/>
					</div>
					<script type="text/javascript">
						function checkInput(){
							var form=document.getElementById("addadminForm");
							if (form.name.value=="")
							{
								alert("<?php echo $_['alert_linkname']?>");
								form.name.focus();
								return false;
							}
							if(form.url.value=="")
							{
								alert("<?php echo $_['alert_linkurl']?>");
								form.url.focus();
								return false;
							}
							str = form.url.value;
							str = str.match(/http:\/\/.+/); 
							if (str == null){
								alert('<?php echo $_['alert_linkurl_r'];?>'); 
								return false;
							}else{
								return true; 
							}
						}
					</script>
				</form>
			</div>
		</div>
	</div>
 </body>
</html>