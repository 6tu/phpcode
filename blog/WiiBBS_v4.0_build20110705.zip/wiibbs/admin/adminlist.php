<?php

/**
 * adminlist.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once('inc/config.php');
	require_once('../lang/'.$language.'/admin/common.php');
	require_once 'admincheck.php';

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_admin']?> </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
 </head>
 <body>
 <div class="bgintor">
	<div class="tit1">
		<ul>
			<li><a href="adminlist.php" target="mainFrame" ><?php echo $_['tab_adminList']?></a> </li>
			<li class="l1"><a href="adminadd.php"><?php echo $_['tab_adminAdd']?></a> </li>
		</ul>		
	</div>
	<div class="listintor">
		<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" />
			<span><?php echo $_['text_position']?>：<?php echo $_['position_system']?> －&gt;<strong><?php echo $_['tab_adminList']?></strong></span>
		</div>
		<div class="header2"><span><?php echo $_['tab_adminList']?></span></div>
		<div class="content">
			<table width="100%">
				<tr class="t1">
					<td><?php echo $_['text_adminAccount']?></td>
					<td><?php echo $_['text_logonTime']?></td>
					<td><?php echo $_['text_logonIP']?></td>
					<td><?php echo $_['text_proLoginCount']?></td>
					<td><?php echo $_['text_del']?></td>
				</tr>
				<?php
					$sql="select * from ".DB_TABLE_PREFIX."admin";
					$result=mysql_query($sql);
					while($row=mysql_fetch_assoc($result))
					{
				?>
				<tr>
					<td><?php echo $row['admin_account'];?></td>
					<td><?php echo $row['admin_logintime'];?></td>
					<td><?php echo $row['admin_loginip'];?></td>
					<td><?php echo $row['admin_logincount']?></td>
					<?php if ($row['admin_account']!=$_SESSION[WiiBBS_ID.'admin']){ ?>
					<td><a href="javascript:if(confirm('<?php echo $_['text_sureSel'] ?>')){location.href='admin_do.php?action=del&id=<?php echo $row["admin_account"]?>'}"><img src="images/dot_del.gif" width="9" height="9" alt="<?php echo $_['text_del']?>" /></a></td>
					<?php }else{ ?>
					<td></td>
					<?php } ?>
				</tr>
					<?php
					}
				    ?>
			</table>
		</div>
	</div>
 </div>
 </body>
</html>
