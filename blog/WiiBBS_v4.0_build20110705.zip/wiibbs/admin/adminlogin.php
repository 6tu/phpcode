<?php

/**
 * adminlogin.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once('inc/config.php');
	require_once('../lang/'.$language.'/admin/common.php');
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_login']?> </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
    <link rel="stylesheet" href="style.css" type="text/css"/>
 </head>
 <body>
	<div id="content">
		<div id="login">
			<div class="loginpic"><img src="images/wiibbs.gif" width="104" height="30" alt="wiisns" /><img src="images/site.gif" width="145" height="30" alt="网站管理平台" /></div>
			<div class="loginpic2"><img src="images/banner.gif" width="940" height="183" alt="" /></div>
			<div class="loginpic3">
				<div class="mid">
				<form  id="loginform" action="adminlogin_do.php" method="post">					
					<p><?php echo $_['text_loginAccount']?>：<input type="text" name="name" class="txt"/></p>
					<p><?php echo $_['text_loginPwd']?>：<input class="txt" type="password" name="password"/></p>
					<p><?php echo $_['text_loginCode']?>：<input class="txt txt1" type="text" name="code"/></p>
					<p class="code"><img src="inc/imgcode.php" height="24" width="60" alt="没看到图片请刷新页面"/></p>
					<p class="btn"><input type="image" src="images/submit.gif" onClick="return checkInput();"/>　<input type="image" src="images/reset.gif" onClick="this.form.reset();return false;"/></p>
					<script type="text/javascript">
						function checkInput(){
							var form=document.getElementById('loginform');
							if(form.name.value=="")
							{
								alert('<?php echo $_['alert_account']?>');
								form.name.focus();
								return false;
							}
							if(form.password.value=="")
							{
								alert('<?php echo $_['alert_pwd']?>')
								form.password.focus();
								return false;
							}
							if(form.code.value=="")
							{
								alert('<?php echo $_['alter_codeNull']?>');
								form.code.focus();
								return false;
							}
						}
					</script>
				</form>
				</div>
			</div>
			<div class="loginpic4">
				<span class="sp1"><?php echo $_['text_call']?></span>
				<span class="sp2"><?php echo $_['text_com']?></span>
			</div>
		</div>
	</div>
 </body>
</html>
