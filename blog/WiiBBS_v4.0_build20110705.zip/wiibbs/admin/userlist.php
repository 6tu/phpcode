<?php

/**
 * userlist.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once("inc/config.php");
	require_once('../lang/'.$language.'/admin/user_config.php');
	require_once('../lang/'.$language.'/admin/common.php');
	require_once('admincheck.php');
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_userList']?> </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
  <script language="javascript">
	function checkAll(f){
		var len=document.getElementsByName('id_list[]').length;
		if (document.getElementById("handler").checked==true)
		{
			for(i=0;i<len;i++){
				document.getElementsByName('id_list[]')[i].checked=true;
			}
		}
		if (document.getElementById("handler").checked==false)
		{
			for(i=0;i<len;i++){
				document.getElementsByName('id_list[]')[i].checked=false;
			}
		}
	}
  </script>
</head>
 <body>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li><span><span><a href="#" target="mainFrame"><?php echo $_['tab_userList']?></a></span></span></li>
				<li class="l1"><span><span><a href="usersearch.php" target="mainFrame"><?php echo $_['tab_userSearch']?></a></span></span></li>
				<li class="l1"><span><span><a href="useradd.php" target="mainFrame"><?php echo $_['tab_userAdd']?></a></span></span></li>
			</ul>
		</div>
		<div class="listintor">
			<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" />
				<span><?php echo $_['text_position']?>：<?php echo $_['position_user']?> －&gt; <strong><?php echo $_['tab_userList']?></strong></span>
			</div>
			<form id="listForm" name="listForm" method="post" action="#">
				<div class="header2"><span><?php echo $_['tab_userList']?></span></div>
				<div class="header3">
					<input type="checkbox" id="handler" name="handler" onClick="checkAll(this.form)"> <strong><?php echo $_['text_selAll']?></strong>
					<a href="javascript:document.listForm.action='user_do.php?act=rmd';document.listForm.submit();"><img src="images/act_save.gif" width="16" height="16" alt="保存" /> <strong><?php echo $_['text_save']?></strong> </a>
					<a href="useradd.php"><img src="images/act_add.gif" alt="+" /><strong><?php echo $_['text_newAdd']?></strong></a>
					<a href="javascript:if(confirm('您确定要删除吗？')){document.listForm.action='user_do.php?act=delAll';document.listForm.submit();}"><img src="images/act_del.gif" width="14" height="14" alt="删除" /> <strong><?php echo $_['text_del']?></strong></a>
				</div>
				<div class="content">
					<table width="100%">
						<tr class="t1">
							<th><?php echo $_['text_check']?></th>
							<th><?php echo $_['text_useraccount']?></th>
							<th><?php echo $_['text_usermobile']?></th>
							<th><?php echo $_['text_useremail']?></th>
							<th><?php echo $_['text_userregtime']?></th>
							<th><?php echo $_['text_userisvip']?></th>
							<th><?php echo $_['text_usernote']?></th>
							<th><?php echo $_['text_usersend']?></th>
							<th><?php echo $_['text_useredit']?></th>
							<th><?php echo $_['text_userdel']?></th>
						</tr>
						<?php
							if(empty($_GET['pagesize'])||!is_numeric($_GET['pagesize'])){
								$pagesize=10;
							}else{
								$pagesize=$_GET["pagesize"];
							if($_GET["pagesize"]<1)$pagesize=10;
							}
							$startrow=0;
							$sql2="select * from ".DB_TABLE_PREFIX."user order by user_id desc";
							$result=mysql_query($sql2) or die ("查询失败，请检查SQL语句2！");
							$rscount=mysql_num_rows($result);
							if ($rscount%$pagesize==0)
							$pagecount=$rscount/$pagesize;
							else
								$pagecount=ceil($rscount/$pagesize);
							if (empty($_GET['page'])||!is_numeric($_GET['page']))
								$page=1;
							else{
								$page=$_GET['page'];
								if($page<1) $page=1;
								if($page>$pagecount) $page=$pagecount;
								$startrow=($page-1)*$pagesize;
							}
							if($page>=$pagecount)
							{
								$nextpage=$pagecount;
							}else{
								$nextpage=$page+1;
							}
							if($page<=1)
							{
								$prepage=1;
							}else{
								$prepage=$page-1;
							}
							$sql="select * from ".DB_TABLE_PREFIX."user order by user_id desc limit $startrow,$pagesize";
							$rs=mysql_query($sql);
							$num=mysql_num_rows($rs);
							if(!$num){
								echo "<tr><td colspan='10'>暂时没有数据！</td></tr>";
							}else{
								$i=0;
								while($row=mysql_fetch_assoc($rs)){
									$i++;
									$sqlstr="select count(msg_id) as ct from ".DB_TABLE_PREFIX."msg  where msg_send='".$row['user_account']."'";
									$result=mysql_query($sqlstr);
									$rows=mysql_fetch_assoc($result);
									$msgsend=$rows["ct"];
						?>
								<tr>
									<td><input type="checkbox" id="handler" name="id_list[]" value="<?php echo $row["user_id"];?>"></td>
									<td><?php echo $row["user_account"];?></td>
									<td><?php echo $row["user_mobile"];?></td>
									<td><?php echo $row["user_email"];?></td>
									<td><?php echo $row["user_regtime"];?></td>
									<td><input type="hidden" name="i" value="<?php echo $i?>"/><input type="hidden" name="id<?php echo $i?>" value="<?php echo $row["user_id"]?>"/><input type="checkbox" name="isRmd<?php echo $i?>" <?php if($row["user_isvip"]=="1") echo "checked"?>/></td>
									<td><?php echo cut_str($row["user_note"],12,0,"utf-8");?></td>
									<td><?php echo $msgsend;?></td>
									<td><a href="useredit.php?id=<?php echo $row["user_id"]?>"><img src="images/dot_edit.gif" width="9" height="9" alt="编辑"></a></td>
									<td><a href="javascript:if(confirm('<?php echo $_['text_sureSel']?>?')){location.href='user_do.php?act=del&id=<?php echo $row["user_id"]?>'}"><img src="images/dot_del.gif" width="9" height="9" alt="删除" /></a></td>
								</tr>
						<?php
								}
							}
						?>
					</table>
					<?php
						if($rscount>0){
							$url="userlist.php?";
							$url2="userlist.php";
							include_once('page.php');
						}
					?>	
				</div>
			</form>
		</div>
	</div>
 </body>
</html>