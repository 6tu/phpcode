<?php

/**
 * link_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once("inc/config.php");
	require_once("../lang/".$language."/admin/link_config.php");
	require_once("../lang/".$language."/admin/common.php");
	require_once("admincheck.php");
	
	$act=$_GET["act"];
	switch($act){
		case "add":
			$linkName=sqlReplace(trim($_POST["name"]));
			$linkUrl=sqlReplace(trim($_POST["url"]));
			$linkPic=sqlReplace(trim($_FILES['file']['name']));
			if(empty($linkName)){
				alertInfo2($_['alert_linkname'],'',1);
			}
			if(empty($linkUrl)){
				alertInfo2($_['alert_linkurl'],"",1);
			}
			if($linkPic==""){
				$linkPic=$filename1="";
				$sql="insert into ".DB_TABLE_PREFIX."link(link_title,link_pic,link_url) values ('".$linkName."','".$filename1."','".$linkUrl."')";
				if(mysql_query($sql)){
					alertInfo2($_['success_linkadd'],'linklist.php',0);
				}else{
					alertInfo2($_['fail_linkadd'],'',1);
				}
			}else{
				$f_name=$_FILES['file']['name'];
				$f_size=$_FILES['file']['size'];
				$f_tmpName=$_FILES['file']['tmp_name'];
				$f_ext=strtolower(preg_replace('/.*\.(.*[^\.].*)*/iU','\\1',$f_name));
				$f_extList="png|jpg|gif|swf";
				$f_dir="../userfiles/link";
				$f_exts=explode("|",$f_extList);
				$checkExt=false;
				foreach($f_exts as $v){
					if($f_ext==$v){
						$checkExt=true;
						break;
					}
				}
				if(!$checkExt){
					alertInfo($_['text_checkext'],'',1);
					exit();
				}
				if(!file_exists("$f_dir"))
				@mkdir($f_dir,0777);
				$date=date('YmdHis');
				$filename=$f_dir."/".$date.".".$f_ext;
				$filename1=$date.".".$f_ext;
				if(copy($f_tmpName,$filename)){
					$sql="insert into ".DB_TABLE_PREFIX."link(link_title,link_pic,link_url) values ('".$linkName."','".$filename1."','".$linkUrl."')";
					if(mysql_query($sql)){
						alertInfo2($_['success_linkadd'],'linklist.php',0);
					}else{
						alertInfo2($_['fail_linkadd'],'',1);
					}
				}else{
					alertInfo($_['text_uploarFail'],'',1);
					exit();
				}
			}
			break;

		case "edit":
			$id=sqlReplace(trim($_GET["id"]));
			checkData2($id,"ID",1);
			$linkName=sqlReplace(trim($_POST["name"]));
			$linkUrl=sqlReplace(trim($_POST["url"]));
			$linkPic=sqlReplace(trim($_FILES['file']['name']));
			if(empty($linkName)){
				alertInfo2($_['alert_linkname'],'',1);
			}
			if(empty($linkUrl)){
				alertInfo2($_['alert_linkurl'],"",1);
			}
			$sql="select * from ".DB_TABLE_PREFIX."link where link_id=".$id;
			$rs=mysql_query($sql);
			$row=mysql_fetch_assoc($rs);
			$linkPic1=$row["link_pic"];
			if($linkPic==""){
				$sql="update ".DB_TABLE_PREFIX."link set link_title='".$linkName."',link_url='".$linkUrl."' where link_id=".$id;
				if(mysql_query($sql)){
					alertInfo2($_['success_linkedit'],"linklist.php",0);
				}else{
					alertInfo2($_['fail_linkedit'],"",1);
				}
			}else{
				$f_name=$_FILES['file']['name'];
				$f_size=$_FILES['file']['size'];
				$f_tmpName=$_FILES['file']['tmp_name'];
				$f_ext=strtolower(preg_replace('/.*\.(.*[^\.].*)*/iU','\\1',$f_name));
				$f_extList="png|jpg|gif|swf";
				$f_dir="../userfiles/link";
				$f_exts=explode("|",$f_extList);
				$checkExt=false;
				foreach($f_exts as $v){
					if($f_ext==$v){
						$checkExt=true;
						break;
					}
				}
				if(!$checkExt){
					alertInfo($_['text_checkext'],'linkedit.php?id='.$id,1);
					exit();
				}
				if(!file_exists("$f_dir"))
				@mkdir($f_dir,0777);
				$date=date('YmdHis');
				$filename=$f_dir."/".$date.".".$f_ext;
				$filename1=$date.".".$f_ext;
				if(copy($f_tmpName,$filename)){
					$sql="update ".DB_TABLE_PREFIX."link set link_title='".$linkName."',link_url='".$linkUrl."',link_pic='".$filename1."' where link_id=".$id;
					if(mysql_query($sql)){
						alertInfo2($_['success_linkedit'],'linklist.php',0);
					}else{
						alertInfo2($_['fail_linkedit'],'',1);
					}
				}else{
					alertInfo($_['text_uploarFail'],'',1);
					exit();
				}
			}
			break;

		case "del":
			$id=sqlReplace(trim($_GET["id"]));
			checkData($id,"ID",1);
			$sql="select * from ".DB_TABLE_PREFIX."link where link_id=".$id;
			$rs=mysql_query($sql);
			$row=mysql_fetch_assoc($rs);
			$linkPic=$row["link_pic"];
			if(file_exists("../userfiles/link/".$linkPic)){
				@unlink("../userfiles/link/".$linkPic);
			}
			$sqlstr="delete from ".DB_TABLE_PREFIX."link where link_id=".$id;
			if(mysql_query($sqlstr)){
				alertInfo2($_['success_linkdel'],"",1);
			}else{
				alertInfo2($_['fail_linkdel'],"",1);
			}
			break;

		case "delAll":
			if(empty($_POST["id_list"])){
				alertInfo2($_['text_selDel'],"",1);
			}
			$listall=$_POST["id_list"];
			foreach($listall as $listid){
				$sql="select * from ".DB_TABLE_PREFIX."link where link_id=".$listid;
				$rs=mysql_query($sql);
				$row=mysql_fetch_assoc($rs);
				$linkPic=$row["link_pic"];
				if(file_exists("../userfiles/link/".$linkPic)){
					@unlink("../userfiles/link/".$linkPic);
				}
				$sqlstr="delete from ".DB_TABLE_PREFIX."link where link_id=".$listid;
				if(!mysql_query($sqlstr)){
					alertInfo2($_['fail_linkdel'],"",1);
				}
			}
			alertInfo2($_['success_linkdel'],"",1);
			break;

		case "update":
			$i=sqlReplace(trim($_POST["i"]));
			checkData2($i,"",0);
			for($x=1;$x<=$i;$x++){
				$tempId=sqlReplace(trim($_POST["id".$x]));
				checkData2($tempId,'ID',0);
				$tempOrder=sqlReplace(trim($_POST["order".$x]));
				checkData2($tempOrder,'ID',0);
				$sqlStr="update ".DB_TABLE_PREFIX."link set link_order=".$tempOrder." where link_id=".$tempId."";
				if(!mysql_query($sqlStr)){
					alertInfo($_['fail_linksave'],"linklist.php",0);
				}
			}
			alertInfo($_['success_linksave'],"linklist.php",0);
			break;
	}
?>