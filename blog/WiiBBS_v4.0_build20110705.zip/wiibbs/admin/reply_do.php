<?php

/**
 * reply_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once("inc/config.php");
	require_once("../lang/".$language."/admin/reply_config.php");
	require_once("../lang/".$language."/admin/common.php");
	require_once("admincheck.php");
	
	$act=sqlReplace(trim($_GET["act"]));
	switch($act){
		case "del":
			$id=sqlReplace(trim($_GET["id"]));
			checkData2($id,"ID",1);
			$sql="select * from ".DB_TABLE_PREFIX."reply where reply_id=".$id;
			$rs=mysql_query($sql);
			$row=mysql_fetch_assoc($rs);
			$file="../userfile/attach/".$row["reply_upload"];
			if(file_exists($file)){
				@unlink($file);
			}
			$sql1="delete from ".DB_TABLE_PREFIX."reply where reply_id=".$id;
			if(!mysql_query($sql1)){
				alertInfo2("删除失败！","",1);
			}else{
				alertInfo2("删除成功！","replylist.php",0);
			}
			break;

		case "delAll":
			if(empty($_POST["id_list"])){
				alertInfo2("请选择删除项！","",1);
			}
			$listall=$_POST["id_list"];
			foreach($listall as $listid){
				$sql="select * from ".DB_TABLE_PREFIX."reply where reply_id=".$listid;
				$rs=mysql_query($sql);
				while($row=mysql_fetch_assoc($rs)){
					$file="../userfiles/attach/".$row["reply_upload"];
					if(file_exists($file)){
						@unlink($file);
					}
				}
				$sql1="select * from ".DB_TABLE_PREFIX."reply where reply_id=".$listid;
				if(!mysql_query($sql1)){
					alertInfo2("删除失败，错误编号：","",1);
				}
			}
			alertInfo2("删除成功！","",1);
			break;
	}
?>