<?php

/**
 * stat_online.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once("inc/config.php");
	require_once("../lang/".$language."/admin/bbsstat_config.php");
	require_once("../lang/".$language."/admin/common.php");
	require_once("admincheck.php");
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_onlinestat']?> </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
 </head>
 <body>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li class="l1"><span><span><a href="stat_bbs.php" target="mainFrame"><?php echo $_['tab_bbsdata']?></a></span></span></li>
				<li class="l1"><span><span><a href="stat_visit.php" target="mainFrame"><?php echo $_['tab_visitstat']?></a></span></span></li>
				<li><span><span><a href="#" target="mainFrame"><?php echo $_['tab_onlinestat']?></a></span></span></li>
			</ul>
		</div>
		<div class="listintor">
			<div class="header1">
				<img src="images/square.gif" width="6" height="6" alt="" /><span><?php echo $_['text_position']?>：<?php echo $_['position_bbs']?> －&gt; <strong><?php echo $_['tab_onlinestat']?></strong></span>
			</div>
			<form id="listForm" name="listForm" method="post" action="#">
				<div class="header2"><span><?php echo $_['tab_onlinestat']?></span></div>
				<div class="content">
					<table width="100%">
						<tr class="t1">
							<th>访问IP</th>
							<th>访问时间</th>
						</tr>
						<?php
							if(empty($_GET['pagesize'])||!is_numeric($_GET['pagesize']))
							{
								$pagesize=10;
							}else{
								$pagesize=$_GET['pagesize'];
							if($_GET['pagesize']<1)$pagesize=10;
							}
							$startrow=0;
							$sql2="select * from ".DB_TABLE_PREFIX."online order by online_time desc";
							$result=mysql_query($sql2) or die ('查询失败，请检查SQL语句2');
							$rscount=mysql_num_rows($result);
							if ($rscount%$pagesize==0)
							$pagecount=$rscount/$pagesize;
							else
								$pagecount=ceil($rscount/$pagesize);
							if (empty($_GET['page'])||!is_numeric($_GET['page']))
								$page=1;
							else{
								$page=$_GET['page'];
								if($page<1) $page=1;
								if($page>$pagecount) $page=$pagecount;
								$startrow=($page-1)*$pagesize;
							}
							if($page>=$pagecount)
							{
								$nextpage=$pagecount;
							}else{
								$nextpage=$page+1;
							}
							if($page<=1)
							{
								$prepage=1;
							}else{
								$prepage=$page-1;
							}
							$sql="select * from ".DB_TABLE_PREFIX."online order by online_time desc limit $startrow,$pagesize";
							$rs=mysql_query($sql);
							$num=mysql_num_rows($rs);
							if(!$num){
								echo "<tr><td colspan='2'>暂时没有数据！</td></tr>";
							}else{
								while($row=mysql_fetch_assoc($rs)){
						?>
						<tr>
							<td><?php echo $row["online_ip"];?></td>
							<td><?php echo $row["online_time"];?></td>
						</tr>
						<?php
								}
							}
						?>
					</table>
					<?php
						if($rscount>0){
							$url="online_stat.php?";
							$url2="online_stat.php";
							include_once('page.php');
						}
					?>	
				</div>
			</form>
		</div>
	</div>
 </body>
</html>