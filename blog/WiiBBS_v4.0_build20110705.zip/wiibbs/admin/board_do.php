<?php

/**
 * board_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	require_once('inc/config.php');
	require_once('../lang/'.$language.'/admin/board_config.php');
	require_once('../lang/'.$language.'/admin/common.php');
	require_once('admincheck.php');
	
	$act=$_GET["act"];
	switch($act){
		case "add";
			$boardName=sqlReplace(trim($_POST["name"]));
			$boardDesc=sqlReplace(trim($_POST["desc"]));
			$boardAdmin=sqlReplace(trim($_POST["admin"]));
			$boardUpload=sqlReplace(trim($_POST["upload"]));
			$boardIsCheck=sqlReplace(trim($_POST["isCheck"]));
			$boardType=sqlReplace(trim($_POST["type"]));
			$boardUser=sqlReplace(trim($_POST["user"]));
			$boardClass=sqlReplace(trim($_POST["boardclass"]));
			$boardPic=sqlReplace(trim($_FILES['file']['name']));
			if(empty($boardName)){
				alertInfo($_['alert_boardname'],'',1);
			}

			if(empty($boardPic)){
				$boardPic=$filename1="";
				$sql="insert into ".DB_TABLE_PREFIX."board (board_name,board_desc,board_admin,board_upload,board_ischeck,board_type,board_users,board_pic,board_class) values ('".$boardName."','".$boardDesc."','".$boardAdmin."','".$boardUpload."','".$boardIsCheck."','".$boardType."','".$boardUser."','".$filename1."','".$boardClass."')";
				if(mysql_query($sql)){
					$sqlstr="select * from ".DB_TABLE_PREFIX."board where board_name='".$boardName."'";
					$rs2=mysql_query($sqlstr);
					$rows2=mysql_fetch_assoc($rs2);
					$boardID=$rows2["board_id"];
					if(!empty($boardAdmin)){
						$boardAdmin1=explode("|",$boardAdmin);
						foreach($boardAdmin1 as $vals){
							$sql1="select * from ".DB_TABLE_PREFIX."user where user_account='".$vals."'";
							$rs1=mysql_query($sql1);
							$row1=mysql_fetch_assoc($rs1);
							if(!$row1){
								alertInfo2("帐号不存在","",1);
							}else{
								$userID=$row1["user_id"];
							}
							$sql3="insert into ".DB_TABLE_PREFIX."usergroup (usergroup_user,usergroup_board,usergroup_type) values('".$userID."','".$boardID."','1')";
							mysql_query($sql3);
						}
					}
					alertInfo($_['success_boardadd'],'boardlist.php',0);
				}else{
					alertInfo($_['fail_boardadd'],'boardadd.php',0);
				}
			}else{
				$f_name=$_FILES['file']['name'];
				$f_size=$_FILES['file']['size'];
				$f_tmpName=$_FILES['file']['tmp_name'];
				$f_ext=strtolower(preg_replace('/.*\.(.*[^\.].*)*/iU','\\1',$f_name));
				$f_extList="png|jpg|gif|swf";
				$f_dir="../userfiles/board";
				$f_exts=explode("|",$f_extList);
				$checkExt=false;
				foreach($f_exts as $v){
					if($f_ext==$v){
						$checkExt=true;
						break;
					}
				}
				if(!$checkExt){
					alertInfo("文件格式不在允许范围",'boardclassedit.php?id='.$id,1);
					exit();
				}
				if(!file_exists("$f_dir"))
				@mkdir($f_dir,0777);
				$date=date('YmdHis');
				$filename=$f_dir."/".$date.".".$f_ext;
				$filename1=$date.".".$f_ext;
				if(copy($f_tmpName,$filename)){
					$sql="insert into ".DB_TABLE_PREFIX."board (board_name,board_desc,board_admin,board_upload,board_ischeck,board_type,board_users,board_pic,board_class) values ('".$boardName."','".$boardDesc."','".$boardAdmin."','".$boardUpload."','".$boardIsCheck."','".$boardType."','".$boardUser."','".$filename1."','".$boardClass."')";
					if(mysql_query($sql)){
						$sqlstr="select * from ".DB_TABLE_PREFIX."board where board_name='".$boardName."'";
						$rs2=mysql_query($sqlstr);
						$rows2=mysql_fetch_assoc($rs2);
						$boardID=$rows2["board_id"];
						if(!empty($boardAdmin)){
							$boardAdmin1=explode("|",$boardAdmin);
							foreach($boardAdmin1 as $vals){
								$sql1="select * from ".DB_TABLE_PREFIX."user where user_account='".$vals."'";
								$rs1=mysql_query($sql1);
								$row1=mysql_fetch_assoc($rs1);
								if(!$row1){
									alertInfo2("帐号不存在","",1);
								}else{
									$userID=$row1["user_id"];
								}
								$sql3="insert into ".DB_TABLE_PREFIX."usergroup (usergroup_user,usergroup_board,usergroup_type) values('".$userID."','".$boardID."','1')";
								mysql_query($sql3);
							}
						}
						alertInfo($_['success_boardadd'],'boardlist.php',0);
					}else{
						alertInfo($_['fail_boardadd'],'boardadd.php',0);
					}
				}else{
					alertInfo("未知错误，上传失败，请重新上传。",'',1);
					exit();
				}
			}
			break;

		case "edit":
			$id=sqlReplace(trim($_GET['id']));
			checkData($id,"ID",0);
			$boardName=sqlReplace(trim($_POST["name"]));
			$boardDesc=sqlReplace(trim($_POST["desc"]));
			$boardAdmin=sqlReplace(trim($_POST["admin"]));
			$boardUpload=sqlReplace(trim($_POST["upload"]));
			$boardIsCheck=sqlReplace(trim($_POST["isCheck"]));
			$boardType=sqlReplace(trim($_POST["type"]));
			$boardUser=sqlReplace(trim($_POST["user"]));
			$boardClass=sqlReplace(trim($_POST["boardclass"]));
			$boardPic=sqlReplace(trim($_FILES['file']['name']));
			if(empty($boardName)){
				alertInfo($_['alert_boardname'],'',1);
			}

			if(empty($boardPic)){
				$sql="update ".DB_TABLE_PREFIX."board set board_name='".$boardName."',board_desc='".$boardDesc."',board_admin='".$boardAdmin."',board_upload='".$boardUpload."',board_ischeck='".$boardIsCheck."',board_type='".$boardType."',board_users='".$boardUser."',board_class='".$boardClass."' where board_id=".$id;
				if(mysql_query($sql)){
					$sql3="delete from ".DB_TABLE_PREFIX."usergroup where usergroup_board=".$id;
					mysql_query($sql3);
					if(!empty($boardAdmin)){
						$boardAdmin1=explode("|",$boardAdmin);
						foreach($boardAdmin1 as $vals){
							$sql1="select * from ".DB_TABLE_PREFIX."user where user_account='".$vals."'";
							$rs1=mysql_query($sql1);
							$row1=mysql_fetch_assoc($rs1);
							if(!$row1){
								alertInfo2("帐号不存在","",1);
							}else{
								$userID=$row1["user_id"];
							}
							$sql2="insert into ".DB_TABLE_PREFIX."usergroup (usergroup_user,usergroup_board,usergroup_type) values ('".$userID."','".$id."','1')";
							mysql_query($sql2);
						}
					}
					alertInfo($_['success_boardedit'],'boardlist.php',0);
				}else{
					alertInfo($_['fail_boardedit'],'boardlist.php',0);
				}
			}else{
				$f_name=$_FILES['file']['name'];
				$f_size=$_FILES['file']['size'];
				$f_tmpName=$_FILES['file']['tmp_name'];
				$f_ext=strtolower(preg_replace('/.*\.(.*[^\.].*)*/iU','\\1',$f_name));
				$f_extList="png|jpg|gif|swf";
				$f_dir="../userfiles/board";
				$f_exts=explode("|",$f_extList);
				$checkExt=false;
				foreach($f_exts as $v){
					if($f_ext==$v){
						$checkExt=true;
						break;
					}
				}
				if(!$checkExt){
					alertInfo("文件格式不在允许范围",'boardclassedit.php?id='.$id,1);
					exit();
				}
				if(!file_exists("$f_dir"))
				@mkdir($f_dir,0777);
				$date=date('YmdHis');
				$filename=$f_dir."/".$date.".".$f_ext;
				$filename1=$date.".".$f_ext;
				if(copy($f_tmpName,$filename)){
					$sql="update ".DB_TABLE_PREFIX."board set board_name='".$boardName."',board_desc='".$boardDesc."',board_admin='".$boardAdmin."',board_upload='".$boardUpload."',board_ischeck='".$boardIsCheck."',board_type='".$boardType."',board_users='".$boardUser."',board_class='".$boardClass."',board_pic='".$filename1."' where board_id=".$id;
					if(mysql_query($sql)){
						$sql3="delete from ".DB_TABLE_PREFIX."usergroup where usergroup_board=".$id;
						mysql_query($sql3);
						if(!empty($boardAdmin)){
							$boardAdmin1=explode("|",$boardAdmin);
							foreach($boardAdmin1 as $vals){
								$sql1="select * from ".DB_TABLE_PREFIX."user where user_account='".$vals."'";
								$rs1=mysql_query($sql1);
								$row1=mysql_fetch_assoc($rs1);
								if(!$row1){
									alertInfo2("帐号不存在","",1);
								}else{
									$userID=$row1["user_id"];
								}
								$sql2="insert into ".DB_TABLE_PREFIX."usergroup (usergroup_user,usergroup_board,usergroup_type) values ('".$userID."','".$id."','1')";
								mysql_query($sql2);
							}
						}
						alertInfo($_['success_boardadd'],'boardlist.php',0);
					}else{
						alertInfo($_['fail_boardadd'],'boardadd.php',0);
					}
				}else{
					alertInfo("未知错误，上传失败，请重新上传。",'',1);
					exit();
				}
			}
			break;

		case "del":
			$id=sqlReplace(trim($_GET["id"]));
			checkData($id,"ID",0);
			$sql="select * from ".DB_TABLE_PREFIX."board where board_id=".$id;
			$rs=mysql_query($sql);
			$row=mysql_fetch_assoc($rs);
			$boardPic=$row["board_pic"];
			if(file_exists("../userfiles/board/".$boardPic)){
				@unlink("../userfiles/board/".$boardPic);
			}
			$sql1="delete from ".DB_TABLE_PREFIX."usergroup where usergroup_board=".$id;
			if(!mysql_query($sql1)){
				alertInfo2("删除失败","",1);
			}
			$sqlStr="delete from ".DB_TABLE_PREFIX."board where board_id=".$id;
			if(mysql_query($sqlStr)){
				alertInfo2($_['success_boarddel'],'',1);
			}else{
				alertInfo2($_['fail_boarddel'],'',1);
			}
			break;

		case "delAll":
			if(empty($_POST['id_list'])){
				alertInfo($_['text_selDel'],"boardlist.php",0);
			}
			$listall=$_POST["id_list"];
			foreach($listall as $listid){
				$sql="select * from ".DB_TABLE_PREFIX."board where board_id=".$listid;
				$rs=mysql_query($sql);
				$row=mysql_fetch_assoc($rs);
				$boardPic=$row["board_pic"];
				if(file_exists("../userfiles/board/".$boardPic)){
					@unlink("../userfiles/board/".$boardPic);
				}
				$sql1="delete from ".DB_TABLE_PREFIX."usergroup where usergroup_board=".$listid;
				if(!mysql_query($sql1)){
					alertInfo2("删除失败","",1);
				}
				$sqlStr="delete from ".DB_TABLE_PREFIX."board where board_id=".$listid;
				if(!mysql_query($sqlStr)){
					alertInfo2($_['fail_boarddel'],'',1);
				}
			}
			alertInfo2($_['success_boarddel'],'',1);
			break;

		case "update":
			$i=sqlReplace(trim($_POST["i"]));
			checkData2($i,"",0);
			for($x=1;$x<=$i;$x++){
				$tempId=sqlReplace(trim($_POST["id".$x]));
				checkData2($tempId,'ID',0);
				$tempOrder=sqlReplace(trim($_POST["order".$x]));
				checkData2($tempOrder,'ID',0);
				$sqlStr="update ".DB_TABLE_PREFIX."board set board_order=".$tempOrder." where board_id=".$tempId."";
				if(!mysql_query($sqlStr)){
					alertInfo($_['fail_boardsave'],"boardlist.php",0);
				}
			}
			alertInfo($_['success_boardsave'],"boardlist.php",0);
			break;
	}
?>