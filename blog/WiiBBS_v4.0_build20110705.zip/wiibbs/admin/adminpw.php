<?php

/**
 * adminpw.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once('inc/config.php');
	require_once('../lang/'.$language.'/admin/common.php');
	require_once 'admincheck.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_adminEdit']?> </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
 </head>
 <body>
	<div class="listintor">
		<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" />
			<span><?php echo $_['text_position']?>：<?php echo $_['text_position_index']?> －&gt;  <strong><?php echo $_['text_editPWD']?></strong></span>
		</div>
		<div class="header2"><span><?php echo $_['text_editPWD']?></span></div>
		<div class="fromcontent">
			<form id="updatePWForm" name="updatePWForm" method="post" action="adminpw_do.php">
				<p><label><?php echo $_['text_oldPWD']?>：</label><input class="in1" type="password" name="password" id="password"/><span class="start"> *</span></p>
				<p><label><?php echo $_['text_newPWD']?>：</label><input class="in1" type="password" name="password1" id="password1"/><span class="start"> * <?php echo $_['text_pointPwd']?></span></p>
				<p><label><?php echo $_['text_PWD2']?>：</label><input class="in1" type="password" name="password2" id="password2"/><span class="start"> *</span></p>
				<p><label>&nbsp;</label><input type="image" src="images/submit1.gif" width="56" height="20" alt="<?php echo $_['alt_submit']?>" onClick="return checkInput2();"/></p>
				<script language="javascript">
					function checkInput2(){
					  if(document.updatePWForm.password.value=='') {
							document.updatePWForm.password.focus();
							alert("<?php echo $_['alert_old']?>");
							return false;
						}
						if(document.updatePWForm.password1.value=='') {
							document.updatePWForm.password1.focus();
							alert("<?php echo $_['alert_new']?>");
							return false;
						}
						if(document.updatePWForm.password2.value=='') {
							document.updatePWForm.password2.focus();
							alert("<?php echo $_['alert_pwd2']?>");
							return false;
						}
						if(document.updatePWForm.password1.value.length<6){
							document.updatePWForm.password1.focus();
							document.updatePWForm.password1.value="";
							document.updatePWForm.password2.value="";
							alert("<?php echo $_['error_adminPwd_length']?>");
							return false;
						}
						if(document.updatePWForm.password1.value!=document.updatePWForm.password2.value) {
							document.updatePWForm.password1.value="";
							document.updatePWForm.password2.value="";
							document.updatePWForm.password1.focus();
							alert("<?php echo $_['alert_pwd3']?>");
							return false;
						}
					}
				</script>
			</form>
		</div>
	</div>
 </body>
</html>
