<?php

/**
 * msgsendlist.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once("inc/config.php");
	require_once("../lang/".$language."/admin/msg_config.php");
	require_once("../lang/".$language."/admin/common.php");
	require_once("admincheck.php");
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_msgsendlist']?> </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
      <script language="javascript">
		function checkAll(f){
			var len=f.elements.length;
			if (document.getElementById("handler").checked==true)
			{	
				for(i=0;i<len;i++){
					var e=f.elements[i];
					if (e.type=='checkbox') e.checked=true;
				}
			}
			if (document.getElementById("handler").checked==false)
			{	
				for(i=0;i<len;i++){
					var e=f.elements[i];
					if (e.type=='checkbox') e.checked=false;
				}
			}
		}
	</script>
</head>
 <body>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li><span><span><a href="#" target="mainFrame"><?php echo $_['tab_msgsendlist']?></a></span></span></li>
				<li class="l1"><span><span><a href="msgsend.php" target="mainFrame"><?php echo $_['tab_msgsend']?></a></span></span></li>
			</ul>
		</div>
		<div class="listintor">
			<div class="header1">
				<img src="images/square.gif" width="6" height="6" alt="" /><span><?php echo $_['text_position']?>：<?php echo $_['position_user']?> — &gt; <strong><?php echo $_['tab_msgsendlist']?></strong></span>
			</div>
			<form id="listForm" name="listForm" method="post" action="#">
				<div class="header2"><span><?php echo $_['tab_msgsendlist']?></span></div>
				<div class="header3">
					<input type="checkbox" id="handler" name="handler" onClick="checkAll(this.form)"> <strong><?php echo $_['text_selAll']?></strong>
					<a href="javascript:if(confirm('<?php echo $_['text_sureSel'];?>')){document.listForm.action='msgSend_do.php?act=delAll';document.listForm.submit();}"><img src="images/act_del.gif" width="14" height="14" alt="<?php echo $_['text_del'];?>" /> <strong><?php echo $_['text_del']?></strong></a>
				</div>
				<div class="content">
					<table width="100%">
						<tr class="t1">
							<th><?php echo $_['text_msgselect']?></th>
							<th><?php echo $_['text_msgtitle']?></th>
							<th><?php echo $_['text_msgcontent']?></th>
							<th><?php echo $_['text_msgposttime']?></th>
							<th><?php echo $_['text_msgsenddel']?></th>
						</tr>
						<?php
							if(empty($_GET['pagesize'])||!is_numeric($_GET['pagesize']))
							{
								$pagesize=10;
							}else{
								$pagesize=$_GET['pagesize'];
							if($_GET['pagesize']<1)$pagesize=10;
							}
							$startrow=0;
							$sql2="select * from ".DB_TABLE_PREFIX."msglog order by msglog_id desc";
							$result=mysql_query($sql2) or die ($_['failSelectGroup']);
							$rscount=mysql_num_rows($result);
							if ($rscount%$pagesize==0)
							$pagecount=$rscount/$pagesize;
							else
								$pagecount=ceil($rscount/$pagesize);
							if (empty($_GET['page'])||!is_numeric($_GET['page']))
								$page=1;
							else{
								$page=$_GET['page'];
								if($page<1) $page=1;
								if($page>$pagecount) $page=$pagecount;
								$startrow=($page-1)*$pagesize;
							}
							if($page>=$pagecount)
							{
								$nextpage=$pagecount;
							}else{
								$nextpage=$page+1;
							}
							if($page<=1)
							{
								$prepage=1;
							}else{
								$prepage=$page-1;
							}
							$sql="select * from ".DB_TABLE_PREFIX."msglog order by msglog_id desc limit $startrow,$pagesize";
							$rs=mysql_query($sql);
							$num=mysql_num_rows($rs);
							if(!$num){
								echo "<tr><td colspan='7'>".$_['text_nodate']."</td></tr>";
							}else{
								while($row=mysql_fetch_assoc($rs)){
						?>
						<tr>
							<td><input type="checkbox" name="id_list[]" value="<?php echo $row["msglog_id"]?>" /></td>
							<td><?php echo $row["msglog_title"]?></td>
							<td><?php echo $row["msglog_content"]?></td>
							<td><?php echo $row["msglog_sendtime"]?></td>
							<td><a href="javascript:if(confirm('<?php echo $_['text_sureSel']?>?')){location.href='msgSend_do.php?act=del&id=<?php echo $row["msglog_id"]?>'}"><img src="images/dot_del.gif" width="9" height="9" alt="<?php echo $_['text_del'];?>" /></a></td>
						</tr>
						<?php
								}
							}
						?>
					</table>
				</div>
			</form>
		</div>
	</div>
 </body>
</html>