<?php

/**
 * admin_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

require_once('inc/config.php');
require_once('../lang/'.$language.'/admin/common.php');
require_once("admincheck.php");
$action=trim($_GET["action"]);
$action=checkData2($action,$_['text_keyParam'],1);

//添加管理员
if($action=="add"){
	$name=checkData2(sqlReplace(trim($_POST["account"])),$_['error_adminAccount'],1);
	$pass=checkData2(sqlReplace(trim($_POST["password"])),$_['error_adminPwd'],1);
	//$group=sqlReplace($_POST["group"]);
	if(strLen($pass)<6)  
		alertInfo2($_['error_adminPwd_length'],"admin_view.php",0);
		$pass=md5($pass);
		//判断账号是否存在
		$sqlStr="select * from ".DB_TABLE_PREFIX."admin where admin_account='".$name."'";
		$rs=mysql_query($sqlStr);
		$row=mysql_fetch_assoc($rs);
		if(!$row){
			$sqlStr="insert into ".DB_TABLE_PREFIX."admin(admin_account,admin_password) values('".$name."','".$pass."')";
			if(mysql_query($sqlStr)){
				alertInfo2($_['success_addAdmin'],"adminlist.php",0);
			}else{
				alertInfo2($_['failAddAdmin'],"adminlist.php",0);
			}
		}else{
			alertInfo2($_['failExistsAccount'],"adminlist.php",0);
		}
}
//删除管理员
if($action=="del"){
	$name=checkData2(trim($_GET["id"]),$_['error_adminAccount'],1);	
	//当前管理员不能被删除
	if($name!=$_SESSION[WiiBBS_ID."admin"]){	
		$sqlStr="delete from ".DB_TABLE_PREFIX."admin where admin_account='".$name."'";
		if(mysql_query($sqlStr)){
			alertInfo2($_['success_delAdmin'],"adminlist.php",0);
		}else{
			alertInfo2($_['failDelAdmin'],"adminlist.php",0);
		}
	}
}
?>