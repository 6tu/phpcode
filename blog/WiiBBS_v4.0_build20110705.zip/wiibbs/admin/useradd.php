<?php

/**
 * useradd.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once("inc/config.php");
	require_once('../lang/'.$language.'/admin/user_config.php');
	require_once('../lang/'.$language.'/admin/common.php');
	require_once('admincheck.php');
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_userAdd']?> </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
 </head>
 <body>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li class="l1"><span><span><a href="userlist.php" target="mainFrame"><?php echo $_['tab_userList']?></a></span></span></li>
				<li class="l1"><span><span></span><a href="usersearch.php" target="mainFrame"><?php echo $_['tab_userSearch']?></a></span></li>
				<li><span><span><a href="#" target="mainFrame"><?php echo $_['tab_userAdd']?></a></span></span></li>
			</ul>
		</div>
		<div class="listintor">
			<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" />
				<span><?php echo $_['text_position']?>：<?php echo $_['position_user']?> －&gt; <strong><?php echo $_['tab_userAdd']?></strong></span>
			</div>
			<div class="header2"><span><?php echo $_['tab_userAdd']?></span></div>
			<div class="fromcontent">
				<form id="addadminForm" name="addadminForm" method="post" action="user_do.php?act=add" enctype="multipart/form-data">
					<p><?php echo $_['text_useraccount']?>：<input class="in1" type="text" id="account" name="account" /><span class="start"> *</span></p>
					<p><?php echo $_['text_password']?>：<input class="in1" type="password" id="pass" name="pass" /><span class="start"> *</span></p>
					<p><?php echo $_['text_usermobile']?>：<input class="in1" type="text" id="mobile" name="mobile" /><span class="start"> *</span></p>
					<p><?php echo $_['text_useremail']?>：<input class="in1" type="text" id="email" name="email" /><span class="start"> *</span></p>
					<p>&nbsp;<?php echo $_['text_userisvip']?>：<input type="radio" id="isvip" name="isvip" value="0" checked /> 否 <input type="radio" id="isvip" name="isvip" value="1" /> 是</p>
					<p><?php echo $_['text_username']?>：<input class="in1" type="text" id="username" name="username" /></p>
					<p><?php echo $_['text_usernickname']?>：<input class="in1" type="text" id="nickname" name="nickname" /></p>
					<p><?php echo $_['text_usersex']?>：<input type="radio" id="sex" name="sex" value="0" /> 男 <input type="radio" id="sex" name="sex" value="1" /> 女</p>
					<p><?php echo $_['text_userphoto']?>：<input type="file" name="file" /></p>
					<p><?php echo $_['text_userbrithday']?>：<input class="in1" type="text" id="brithday" name="brithday" /><span class="start">(格式:1988-01-01)</span></p>
					<p><?php echo $_['text_province']?>：<input class="in1" type="text" id="province" name="province" /></p>
					<p><?php echo $_['text_usercity']?>：<input class="in1" type="text" id="city" name="city" /></p>
					<p><?php echo $_['text_useraddress']?>：<input class="in1" type="text" id="address" name="address" /></p>
					<p>&nbsp;&nbsp;<?php echo $_['text_userqq']?>：<input class="in1" type="text" id="qq" name="qq" /></p>
					<p><?php echo $_['text_usersina']?>：<input class="in1" type="text" id="sina" name="sina" /></p>
					<p><?php echo $_['text_userintro']?>：<input class="in1" type="text" id="intro" name="intro" /></p>
					<p><?php echo $_['text_usernote']?>：<input class="in1" type="text" id="note" name="note" /></p>
					<p><?php echo $_['text_userinfo']?>：</p>
					<p><textarea id="info" name="info" cols="30" rows="7"></textarea></p>
					<div class="btn">
						<input type="image" src="images/submit1.gif" width="56" height="20" alt="<?php echo $_['alt_submit']?>" onClick="return checkInput();"/>
					</div>
					<script type="text/javascript">
						function checkInput(){
							var form=document.getElementById("addadminForm");
							if (form.account.value=="")
							{
								alert("<?php echo $_['alert_useraccount']?>");
								form.account.focus();
								return false;
							}
							if(form.pass.value=="")
							{
								alert("<?php echo $_['alert_userpass']?>");
								form.pass.focus();
								return false;
							}
							if(form.mobile.value=="")
							{
								alert("<?php echo $_['alert_usermobile']?>");
								form.mobile.focus();
								return false;
							}
							if(form.email.value=="")
							{
								alert("<?php echo $_['alert_useremail']?>");
								form.email.focus();
								return false;
							}
						}
					</script>
				</form>
			</div>
		</div>
	</div>
 </body>
</html>