<?php

/**
 * configue_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once('inc/config.php');
	require_once('../lang/'.$language.'/admin/common.php');
	require_once 'admincheck.php'; 
	$name=sqlReplace(Trim($_POST['name']));
	$width=sqlReplace(Trim($_POST['width']));
	$accreditation=sqlReplace(trim($_POST['accreditation']));
	$mailSMTP=sqlReplace(Trim($_POST['mailSMTP']));
	$mailAddress=sqlReplace(Trim($_POST['mailAddress']));
	$mailAccount=sqlReplace(Trim($_POST['mailAccount']));
	$mailPass=sqlReplace(Trim($_POST['mailPass']));
	checkData($name,$_['text_webName'],1);
	$f_name=$_FILES['file']['name'];
	$f_size=$_FILES['file']['size'];
	$f_tmpName=$_FILES['file']['tmp_name'];
	$f_ext=strtolower(preg_replace('/.*\.(.*[^\.].*)*/iU','\\1',$f_name));
	$f_extList="png|jpg|gif";
	$f_dir="../userfiles/logo";

	$f_exts=explode("|",$f_extList);
	$checkExt=false;
	foreach ($f_exts as $v)
		if ($f_exts==$v){
			$checkExt=true;
			break;
		}

		if ($checkExt) {
			alertInfo($_['alter_f_ext'],'',1);
			exit();
		}

		if ($f_size>20*1024){
			alertInfo($_['alter_f_size'],'',1);
			exit();
		}

		if (!file_exists("$f_dir"))
			@mkdir($f_dir,0777);
		$pic='userfiles/logo/logo.jpg';
		if (copy($f_tmpName,$f_dir."/"."logo.jpg")){
					
		}else{
			alertInfo($_['alter_f_upload'],'',1);
			exit();
		}
	$sql="update ".DB_TABLE_PREFIX."conf set conf_name='".$name."',conf_logo='".$pic."',conf_width='".$width."',conf_accreditation='".$accreditation."',conf_mailSMTP='".$mailSMTP."',conf_mailAddress='".$mailAddress."',conf_mailAccount='".$mailAccount."',conf_mailPassword='".$mailPass."'";
	if(mysql_query($sql)){
		alertInfo2($_['success_setConf'],'configue.php',0);
	}else{
		alertInfo2($_['fail_setConf'],'',1);
	}

?>