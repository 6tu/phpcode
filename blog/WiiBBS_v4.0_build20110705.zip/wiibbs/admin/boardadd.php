<?php

/**
 * boardadd.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once('inc/config.php');
	require_once('../lang/'.$language.'/admin/board_config.php');
	require_once('../lang/'.$language.'/admin/common.php');
	require_once('admincheck.php');
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_boardAdd']?> </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
  <script type="text/javascript">
	function show_1(type){
		switch(type)
		{
			case "category":
				document.getElementById('category').style.display="";
				break;
			case "category1":
				document.getElementById('category').style.display="none";
				break;
			case "tag":
				document.getElementById('tag').style.display="none";
				break;
			case "log":
				document.getElementById('tag').style.display="";
				break;
		}
	}
 </script>
 </head>
 <body>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li class="l1"><span><span><a href="boardlist.php" target="mainFrame"><?php echo $_['tab_boardList']?></a></span></span></li>
				<li><span><span><a href="#" target="mainFrame"><?php echo $_['tab_boardAdd']?></a></span></span></li>
			</ul>
		</div>
		<div class="listintor">
			<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" />
				<span><?php echo $_['text_position']?>：<?php echo $_['position_board']?> －&gt; <strong><?php echo $_['tab_boardAdd']?></strong></span>
			</div>
			<div class="header2"><span><?php echo $_['tab_boardAdd']?></span></div>
			<div class="fromcontent">
				<form id="addadminForm" name="addadminForm" method="post" action="board_do.php?act=add" enctype="multipart/form-data">
					<p><?php echo $_['text_boardname']?>：<input class="in1" type="text" name="name" id="name"/><span class="start"> *</span></p>
					<p><?php echo $_['text_boarddesc']?>：<input name="desc" type="text" class="in1"/></p>
					<p><?php echo $_['text_boardadmin']?>：<input name="admin" type="text" class="in1"/>（<?php echo $_['text_boarTip1'];?>）</p>
					<p><?php echo $_['text_boardclass1']?>：
						<select name="boardclass">
							<?php
								$sqlStr="select * from ".DB_TABLE_PREFIX."boardclass order by boardclass_order asc,boardclass_id desc";
								$rs=mysql_query($sqlStr);
								$num=mysql_num_rows($rs);
								if(!$num){
									alertInfo2($_['text_noCheckClass'],"boardclassadd.php",0);
								}else{
									$row=mysql_fetch_array($rs);
									while($row){
										echo "<option value='".$row['boardclass_id']."'";
										echo "selected='selected'>";
										echo $row['boardclass_name'];
										echo "</option> ";
										$row = mysql_fetch_array($rs);
									}
								}
							?>
						</select>
					</p>
					<p><?php echo $_['text_boardpic']?>：<input type="file" name="file" /></p>
					<div id="category">
						<p><?php echo $_['text_boardupload']?>：<input type="radio" name="upload" value="0" checked="checked"/><?php echo $_['text_no'];?><input type="radio" name="upload" value="1" /><?php echo $_['text_yes'];?></p>
						<p><?php echo $_['text_boardischeck']?>：<input type="radio" name="isCheck" value="0" checked="checked"/><?php echo $_['text_no'];?><input type="radio" name="isCheck" value="1"/><?php echo $_['text_yes'];?></p>
					</div>
					<p><?php echo $_['text_boardtype']?>：<input name="type" type="radio" value="4" onClick="show_1('tag')" /><?php echo $_['text_boardGuess'];?><input name="type" type="radio" value="0" checked="checked" onClick="show_1('tag')" /><?php echo $_['text_boardPt'];?> <input name="type" type="radio" value="1" onClick="show_1('tag')" /><?php echo $_['text_boardUser'];?> <input name="type" type="radio" value="2" onClick="show_1('tag')" /><?php echo $_['text_boardVip'];?> <input name="type" type="radio" value="3" onClick="show_1('tag')" /><?php echo $_['text_boardAdmin'];?>	<input name="type" type="radio" value="5" onClick="show_1('log')" /><?php echo $_['text_boardTo'];?> <input name="type" type="radio" value="6" onClick="show_1('tag')" /><?php echo $_['text_boardNews'];?>
					</p>
					<div id="tag" style="display:none">
						<p><?php echo $_['text_userTip'];?>：</p>
						<p class="txt"><textarea name="user" cols="50" rows="7"></textarea></p>
					</div>
					<div class="btn">
						<input type="image" src="images/submit1.gif" width="56" height="20" alt="<?php echo $_['alt_submit']?>" onClick="return checkInput();"/>
					</div>
					<script type="text/javascript">
						function checkInput(){
							var form=document.getElementById("addadminForm");
							if (form.name.value=="")
							{
								alert("<?php echo $_['alert_boardname']?>");
								form.name.focus();
								return false;
							}
						}
					</script>
				</form>
			</div>
		</div>
	</div>
 </body>
 </html>