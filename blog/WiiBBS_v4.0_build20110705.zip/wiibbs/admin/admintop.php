<?php

/**
 * admintop.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
		<title> Top Frame </title>
		<link rel="stylesheet" href="style.css" type="text/css" />
	</head>
	<?php
		require_once('inc/config.php');
		require_once('../lang/'.$language.'/admin/common.php');
		require_once('admincheck.php');
	?>
	<base target="mainFrame"/>
	<body>
		<div id="topFrame">
			<div id="content">
				<img src="images/logo.gif" alt="<?php echo $_['alt_manage']?>" />
				<span id="panel">
				<a href="adminMain.php"><img src="images/top_bt_index.gif" alt="<?php echo $_['alt_index']?>" /></a><a href="javascript:history.go(-1);"><img src="images/top_bt_back.gif" alt="<?php echo $_['alt_return']?>" /></a><a href="javascript:history.go(1);"><img src="images/top_bt_ahead.gif" alt="<?php echo $_['alt_go']?>" /></a><a href="javascript:top.location.reload();"><img src="images/top_bt_refresh.gif" alt="<?php echo $_['alt_refresh']?>" /></a> <a href="adminpw.php"><img src="images/top_bt_self.gif" alt="" /></a><a href="admin_quit.php"><img src="images/top_bt_quit.gif" alt="" /></a></span>
				<span id="time"><img src="images/clock.gif" alt="" />
				<?php
					$weekarray=array($_['text_sunday'],$_['text_mon'],$_['text_tues'],$_['text_wed'],$_['text_thur'],$_['text_fri'],$_['text_sat']);
					$w=$_['text_week'].$weekarray[date("w")];
				?><?php echo $_['text_data']?>：<?php echo date("Y$_['text_year']m$_['text_month']d$_['text_day']".$w)?>
				</span>
		</div>
	</body>
</html>