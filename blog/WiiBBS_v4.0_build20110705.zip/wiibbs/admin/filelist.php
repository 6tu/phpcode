<?php

/**
 * filelist.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once("inc/config.php");
	require_once("../lang/".$language."/admin/file_config.php");
	require_once("../lang/".$language."/admin/common.php");
	require_once("admincheck.php");
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_filelist']?> </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
      <script language="javascript">
		function checkAll(f){
			var len=f.elements.length;
			if (document.getElementById("handler").checked==true)
			{	
				for(i=0;i<len;i++){
					var e=f.elements[i];
					if (e.type=='checkbox') e.checked=true;
				}
			}
			if (document.getElementById("handler").checked==false)
			{	
				for(i=0;i<len;i++){
					var e=f.elements[i];
					if (e.type=='checkbox') e.checked=false;
				}
			}
		}
	</script>
</head>
 <body>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li class="l1"><span><span><a href="#" target="mainFrame"><?php echo $_['tab_filelist'];?></a></span></span></li>
			</ul>
		</div>
		<div class="listintor">
			<div class="header1">
				<img src="images/square.gif" width="6" height="6" alt="" /><span><?php echo $_['text_position']?>：<?php echo $_['position_topic']?> — &gt; <strong><?php echo $_['tab_filelist']?></strong></span>
			</div>
			<form id="listForm" name="listForm" method="post" action="#">
				<div class="header2"><span><?php echo $_['tab_filelist']?></span></div>
				<div class="header3">
					<input type="checkbox" id="handler" name="handler" onClick="checkAll(this.form)"> <strong><?php echo $_['text_selAll']?></strong>
					<a href="javascript:if(confirm('<?php echo $_['text_sureSel'];?>')){document.listForm.action='file_do.php?act=delAll';document.listForm.submit();}"><img src="images/act_del.gif" width="14" height="14" alt="<?php echo $_['text_del'];?>" /> <strong><?php echo $_['text_del']?></strong></a>
				</div>
				<div class="content">
					<table width="100%">
						<tr class="t1">
							<th><?php echo $_['text_fileselect']?></th>
							<th><?php echo $_['text_filename']?></th>
							<th><?php echo $_['text_fileview']?></th>
							<th><?php echo $_['text_filetopic']?></th>
							<th><?php echo $_['text_fileurl']?></th>
							<th><?php echo $_['text_fileaddtime']?></th>
							<th><?php echo $_['text_filesort']?></th>
							<th><?php echo $_['text_filedel']?></th>
						</tr>
						<?php
							if(empty($_GET['pagesize'])||!is_numeric($_GET['pagesize']))
							{
								$pagesize=10;
							}else{
								$pagesize=$_GET['pagesize'];
							if($_GET['pagesize']<1)$pagesize=10;
							}
							$startrow=0;
							$sql2="select * from ".DB_TABLE_PREFIX."file order by file_id desc";
							$result=mysql_query($sql2) or die ($_['fail_selectFile']);
							$rscount=mysql_num_rows($result);
							if ($rscount%$pagesize==0)
							$pagecount=$rscount/$pagesize;
							else
								$pagecount=ceil($rscount/$pagesize);
							if (empty($_GET['page'])||!is_numeric($_GET['page']))
								$page=1;
							else{
								$page=$_GET['page'];
								if($page<1) $page=1;
								if($page>$pagecount) $page=$pagecount;
								$startrow=($page-1)*$pagesize;
							}
							if($page>=$pagecount)
							{
								$nextpage=$pagecount;
							}else{
								$nextpage=$page+1;
							}
							if($page<=1)
							{
								$prepage=1;
							}else{
								$prepage=$page-1;
							}
							$sql="select * from ".DB_TABLE_PREFIX."file order by file_id desc limit $startrow,$pagesize";
							$rs=mysql_query($sql);
							$num=mysql_num_rows($rs);
							if(!$num){
								echo "<tr><td colspan='7'>".$_['text_nodate']."</td></tr>";
							}else{
								while($row=mysql_fetch_assoc($rs)){
									$sql1="select * from ".DB_TABLE_PREFIX."topic where topic_id=".$row["file_topic"];
									$rs1=mysql_query($sql1);
									$row1=mysql_fetch_assoc($rs1);
									$topicTitle=$row1["topic_title"];
						?>
						<tr>
							<td><input type="checkbox" name="id_list[]" value="<?php echo $row["file_id"]?>" /></td>
							<td><?php echo $row["file_name"]?></td>
							<td>
							<?php
								$f_ext=strtolower(preg_replace('/.*\.(.*[^\.].*)*/iU','\\1',$row["file_name"]));
								$f_extList="png|jpg|gif|swf";
								$f_exts=explode("|",$f_extList);
								$checkExt=false;
								foreach($f_exts as $v){
									if($f_ext==$v){
										$checkExt=true;
										break;
									}
								}
								if($checkExt){
							?>
									<img src="<?php echo "../userfiles/attach/".$row["file_name"]?>" width='100' />
							<?		
								}
							?>
							</td>
							<td><a href="#" target="blank"><?php echo $topicTitle;?></a></td>
							<td><?php echo $row["file_url"]."/".$row["file_name"]?></td>
							<td><?php echo $row["file_addtime"]?></td>
							<td><?php if($row["file_sort"]=='1'){echo $_['text_reply'];}else{echo $_['text_topic'];}?></td>
							<td><a href="javascript:if(confirm('<?php echo $_['text_sureSel']?>?')){location.href='file_do.php?act=del&id=<?php echo $row["file_id"]?>'}"><img src="images/dot_del.gif" width="9" height="9" alt="<?php echo $_['text_del'];?>" /></a></td>
						</tr>
						<?php
								}
							}	
						?>
						</table>
						<?php
							if($rscount>0){
								$url="filelist.php?";
								$url2="filelist.php";
								include_once('page.php');
							}
						?>
					</div>
				</div>
			</form>
		</div>
	</div>
 </body>
</html>