<?php

/**
 * topic_searchlist.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once("inc/config.php");
	require_once('../lang/'.$language.'/admin/topic_config.php');
	require_once("../lang/".$language."/admin/common.php");
	require_once("admincheck.php");
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_topicsearch']?> </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
  <script language="javascript">
	function checkAll(f){
		var len=document.getElementsByName('id_list[]').length;
		if (document.getElementById("handler").checked==true)
		{
			for(i=0;i<len;i++){
				document.getElementsByName('id_list[]')[i].checked=true;
			}
		}
		if (document.getElementById("handler").checked==false)
		{
			for(i=0;i<len;i++){
				document.getElementsByName('id_list[]')[i].checked=false;
			}
		}
	}
  </script>
</head>
 <body>
	<?php
		if(empty($_GET['t'])){$t='';}else{$t=$_GET['t'];}
		$tt=(empty($_REQUEST["title"]))?"":$_REQUEST["title"];
		$u=(empty($_REQUEST["user"]))?"":$_REQUEST["user"];
		$c=(empty($_REQUEST["content"]))?"":$_REQUEST["content"];
		$l=(empty($_GET["l"]))?"":$_GET['l'];
		$g=(empty($_GET["g"]))?"":$_GET['g'];
		$pagesize=10;
		$startRow=0;
		$page=(empty($_GET["page"]))?"":$_GET['page'];
		if (empty($_GET['page'])||!is_numeric($_GET['page'])){
			$page=1;
		}else{
			$page=$_GET['page'];
			$startRow=($page-1)*$pagesize;
		}
		$url="t=".$t."&tt=".$tt."&u=".$u."&c=".$c."&l=".$l."&g=".$g;
		$sqlStrt="select * from ".DB_TABLE_PREFIX."topic where topic_title like '%".$tt."%' and topic_user like '%".$u."%' and topic_content like '%".$c."%' order by topic_id desc";
		$sqlStr="select * from ".DB_TABLE_PREFIX."topic where topic_title like '%".$tt."%' and topic_user like '%".$u."%' and topic_content like '%".$c."%' order by topic_id desc limit $startRow,$pagesize";
	?>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li class="l1"><span><span><a href="topiclist.php" target="mainFrame"><?php echo $_['tab_topiclist']?></a></span></span></li>
				<li class="l1"><span><span><a href="topicsearch.php" target="mainFrame"><?php echo $_['tab_topicsearch']?></a></span></span></li>
			</ul>
		</div>
		<div class="listintor">
			<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" />
				<span><?php echo $_['text_position']?>：<?php echo $_['position_topic']?> －&gt; <strong><?php echo $_['tab_topicsearch']?></strong></span>
			</div>
			<form id="listForm" name="listForm" method="post" action="#">
				<div class="header2"><span><?php echo $_['tab_topicsearch']?></span></div>
				<div class="header3">
					<input type="checkbox" id="handler" name="handler" onClick="checkAll(this.form)"> <strong><?php echo $_['text_selAll']?></strong>
					<a href="javascript:if(confirm('您确定要删除吗？')){document.listForm.action='topic_do.php?act=delAll';document.listForm.submit();}"><img src="images/act_del.gif" width="14" height="14" alt="删除" /> <strong><?php echo $_['text_del']?></strong></a>
				</div>
				<div class="content">
					<table>
						<tr class="t1">
							<th><?php echo $_['text_topicselect']?></th>
							<th><?php echo $_['text_topictitle']?></th>
							<th><?php echo $_['text_topicuser']?></th>
							<th><?php echo $_['text_topicboard']?></th>
							<th><?php echo $_['text_addtime']?></th>
							<th><?php echo $_['text_topicview']?></th>
							<th><?php echo $_['text_topicdel']?></th>
						</tr>
						<?php
							$rs=mysql_query($sqlStrt);
							$row=mysql_fetch_assoc($rs);
							if(!$row){ 
								echo "<tr><td colspan='7'>暂且没有数据！</td></tr>";
							}else{		
								$rs = mysql_query($sqlStrt) or die ("查询失败，请检查SQL语句T。");
								$result = mysql_query($sqlStr) or die ("查询失败，请检查SQL语句。");
								$rscount=mysql_num_rows($rs);
								if ($rscount%$pagesize==0)
									$pagecount=$rscount/$pagesize;
								else
									$pagecount=ceil($rscount/$pagesize);
								while($row=mysql_fetch_assoc($result)){
									$topicBoard=$row["topic_board"];
									$sqlStr1="select * from ".DB_TABLE_PREFIX."board where board_id=".$topicBoard;
									$result1=mysql_query($sqlStr1);
									$row1=mysql_fetch_assoc($result1);
									$boardName=$row1["board_name"];
						?>
						<tr>
							<td><input type="checkbox" name="id_list[]" value=<?php echo $row["topic_id"]?> /></td>
							<td class="td1"><?php echo $row["topic_title"];?></td>
							<td><?php echo $row["topic_user"];?></td>
							<td><?php echo $boardName;?></td>
							<td><?php echo $row["topic_posttime"];?></td>
							<td><a href="#">查看</a></td>
							<td><a href="javascript:if(confirm('<?php echo $_['text_sureSel']?>?')){location.href='topic_do.php?act=del&id=<?php echo $row["topic_id"]?>'}"><img src="images/dot_del.gif" width="9" height="9" alt="删除" /></a></td>
						</tr>
						<?php
								}
						?>
					</table>
					<?php
						showPage("topic_searchlist.php?".$url,$page,$pagesize,$rscount,$pagecount);
					?>
					<?php }?>
				</div>
			</form>
		</div>
	</div>
 </body>
</html>