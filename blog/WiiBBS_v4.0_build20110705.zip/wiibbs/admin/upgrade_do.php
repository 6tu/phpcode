<?php

/**ffffffffffffffff
 * upgrade_do.php WiiBBS升级更新操作
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	require_once('inc/config.php');
	require_once('../lang/'.$language.'/admin/common.php');
	require_once("admincheck.php");
	//checkAdminRight("122",$_SESSION[WiiBBS_ID."admingroup"]);
	error_reporting(0);
	$act=trim($_POST['act']);
	$file=sqlReplace(trim($_POST['f']));
	switch($act)
	{
		case 'down':
			$f_url="http://p.wiipu.com/WiiBBS/down/".$file.".zip";

			$dir='upgrade';
			if(!is_dir($dir)) @mkdir($dir,0777); 
			
			$headers = get_headers($f_url, 1); 
			if ((array_key_exists("Content-Length", $headers))) 
			{
				$downfile = $dir.'/'.basename($f_url);
				$f_handle = fopen ($f_url, "rb");
				if ($f_handle) {
					$down_handle = fopen ($downfile, "wb");
					if ($down_handle) {
						while(!feof($f_handle)){
							fwrite($down_handle, fread($f_handle, 1024 * 8 ), 1024 * 8 );
						}
						fclose($down_handle);
						sleep(6);
						echo "S";
					}else{
						echo "E";
					}
					fclose($f_handle);
				}else
					echo "E";
			}else{
				$filesize=0; 
				echo "E";
			}

			break;
		case 'zip':
			require_once('inc/zip.class.php');

			$archive   = new PHPZip();
			$zipfile   = 'upgrade/'.$file.'.zip';
			$savepath  = 'upgrade/'.$file;
			$array     = $archive->GetZipInnerFilesInfo($zipfile);
			$filecount = 0;
			$dircount  = 0;
			$failfiles = array();

			set_time_limit(0);

			for($i=0; $i<count($array); $i++) {
				if($array[$i][folder] == 0){
					if($archive->unZip($zipfile, $savepath, $i) > 0){
						$filecount++;
					}else{
						$failfiles[] = $array[$i][filename];
					}
				}else{
					$dircount++;
				}
			}
			set_time_limit(30);
			sleep(6);

			if(count($failfiles) > 0){
				echo "E";
			}else{
				echo "S";
			}
			break;
	}
	
?>