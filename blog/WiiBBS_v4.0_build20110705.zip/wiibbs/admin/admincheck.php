<?php

/**
 * admincheck.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once('db_conn.php');
	if (empty($_SESSION[WiiBBS_ID.'admin']))
		echo "<script type='text/javascript'>alert('".$_['alter_check']."');top.location.href='adminlogin.php';</script>";
?>