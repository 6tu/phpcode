<?php

/**
 * themessite.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once('inc/config.php');
	require_once('../lang/'.$language.'/admin/common.php');
	require_once("admincheck.php");
	require_once("style_default.php");
	//checkAdminRight("122",$_SESSION[WiiBBS_ID."admingroup"]);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> 主题设置 </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
  <script type="text/javascript" src="js/jscolor/jscolor.js"></script>
 </head>
 <?php
	$sqlStr="select  * from ".DB_TABLE_PREFIX."site limit 0,1";
	$rs=mysql_query($sqlStr);
	$row=mysql_fetch_assoc($rs);
	If(!$row){
		alertInfo("数据库初始化失败！","admin.php",0);
	}Else{
		$logo=$row["site_logo"];
		$name=$row["site_name"];
		$a_width=$row["site_width"];
		$a_count=$row["site_count"];
		$express=$row['site_express'];
		$ubb=$row['site_ubb'];
	}
 ?>
 <body>
 	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li><a href="aboutsite.php" target="mainFrame" >彩板主题设置</a> </li>
			</ul>		
		</div>
		<div class="listintor">
			<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" />
				<span>位置：系统管理 －&gt; <strong>彩板主题设置</strong></span>
			</div>
			<div class="header2"><span>彩板主题设置</span>
			</div>
			<div class="fromcontent">
				<form id="form2" name="addForm" method="post" action="themessite_do.php" >
					<p><label>头尾样式：</label>背景色 <input class="color" name="top_groundColor"  value="<?php echo $top_groundColor?>"> 文字颜色 <input class="color" name="top_color" value="<?php echo $top_color?>"> 超链接颜色 <input class="color" name="top_aColor"  autocomplete="off" class="color" value="<?php echo $top_aColor?>"></p>

					<p><label>一级标题：</label>背景色 <input class="color" name="h1_groundColor"  value="<?php echo $h1_groundColor?>"> 文字颜色 <input class="color" name="h1_color" value="<?php echo $h1_color?>"> 超链接颜色 <input class="color" name="h1_aColor"  autocomplete="off" class="color" value="<?php echo $h1_aColor?>"> 边框的颜色 <input class="color" name="h1_borderColor"  autocomplete="off" class="color" value="<?php echo $h1_borderColor?>"></p>

					<p><label>二级标题：</label>背景色 <input class="color" name="h2_groundColor"  value="<?php echo $h2_groundColor?>"> 文字颜色 <input class="color" name="h2_color" value="<?php echo $h2_color?>"> 超链接颜色 <input class="color" name="h2_aColor"  autocomplete="off" class="color" value="<?php echo $h2_aColor?>"> 边框的颜色 <input class="color" name="h2_borderColor"  autocomplete="off" class="color" value="<?php echo $h2_borderColor?>"></p>


					<p><label>整站：</label>文字颜色 <input class="color" name="all_color"  value="<?php echo $all_color?>"> 说明性文字颜色 <input class="color" name="all_desColor" value="<?php echo $all_desColor?>"> 超链接颜色 <input class="color" name="all_aColor"  autocomplete="off" class="color" value="<?php echo $all_aColor?>"></p>

					<p><label>关键字：</label>文字颜色 <input class="color" name="key_color"  value="<?php echo $key_color?>"> </p>

					<p><label>提示文字：</label>文字颜色 <input class="color" name="point_color"  value="<?php echo $point_color?>"> 超链接 <input class="color" name="point_aColor"  value="<?php echo $point_aColor?>"></p>
					<p><label>分割线：</label>颜色 <input class="color" name="line_color"  value="<?php echo $line_color?>"> </p>

					<p><label>底部 彩板 3g版：</label>背景色 <input class="color" name="3g_groundColor"  value="<?php echo $g_groundColor?>"> 字体颜色 <input class="color" name="3g_color"  value="<?php echo $g_color?>"> 超链接 <input class="color" name="3g_aColor"  value="<?php echo $g_aColor?>"></p>
					<p><label>评论页隔行变色</label>背景色 <input class="color" name="row_groundColor"  value="<?php echo $row_groundColor?>"></p>

					<p><label>logo：</label>文字颜色 <input class="color" name="logo_color" value="<?php echo $logo_color?>"> 文字大小 <input style="width:30px" name="fontSize" value="<?php echo $fontSize?>"> px</p>
					
					<p><label>&nbsp;</label><input type="image" src="images/submit1.gif" width="56" height="20" alt="提交"/>
					</p>
					
				</form>
			</div>
		</div>
	</div>
 </body>
</html>
