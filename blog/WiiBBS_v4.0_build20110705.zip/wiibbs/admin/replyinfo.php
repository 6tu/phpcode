<?php

/**
 * replyinfo.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	require_once("inc/config.php");
	require_once("../lang/".$language."/admin/reply_config.php");
	require_once("../lang/".$language."/admin/common.php");
	require_once("admincheck.php");
	
	$id=sqlReplace(trim($_GET["id"]));
	$sql="select * from ".DB_TABLE_PREFIX."reply where reply_id=".$id;
	$rs=mysql_query($sql);
	$row=mysql_fetch_assoc($rs);
	if(!$row){
		alertInfo2("查询失败，错误编号：","replylist.php",0);
	}else{
		$replyContent=$row["reply_content"];
		$replyUser=$row["reply_user"];
		$replyPostTime=$row["reply_posttime"];
		$replyTopic=$row["reply_topic"];
		$replyBoard=$row["reply_board"];
		$sql2="select * from ".DB_TABLE_PREFIX."topic where topic_id=".$replyTopic;
		$rs2=mysql_query($sql2);
		$row2=mysql_fetch_assoc($rs2);
		$topicName=$row2["topic_title"];
		$sql3="select * from ".DB_TABLE_PREFIX."board where board_id=".$replyBoard;
		$rs3=mysql_query($sql3);
		$row3=mysql_fetch_assoc($rs3);
		$boardName=$row3["board_name"];
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_replyinfo']?> </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
 </head>
  <body>
	<div class="bgintor">
		<div class="listintor">
			<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" />
				<span><?php echo $_['text_position']?>：<?php echo $_['position_topic']?> －&gt; <strong><?php echo $_['tab_replyinfo']?></strong></span>
			</div>
			<div class="header2"><span><?php echo $_['tab_replyinfo']?></span></div>
			<div class="fromcontent">
			<form id="listForm" name="listForm" method="post" action="replylist.php">
					<p><?php echo $_['text_replyuser']?>：<?php echo $replyUser;?></p>
					<p><?php echo $_['text_replytime']?>：<?php echo $replyPostTime;?></p>
					<p><?php echo $_['text_replytopic']?>：<?php echo $topicName;?></p>
					<p><?php echo $_['text_replyboard']?>：<?php echo $boardName;?></p>
					<p><?php echo $_['text_replycontent']?>：</p>
					<p><?php echo $replyContent;?></p>
					<div class="btn">
						<input type="image" src="images/goback.gif" width="56" height="20" alt="返回" />
						<a href="javascript:if(confirm('<?php echo $_['text_sureSel']?>?')){location.href='reply_do.php?act=del&id=<?php echo $row["reply_id"]?>'}"><img src="images/del.gif" width="56" height="20" alt="删除" /></a>
					</div>
				</form>
			</div>
		</div>
	</div>
  </body>
 </html>