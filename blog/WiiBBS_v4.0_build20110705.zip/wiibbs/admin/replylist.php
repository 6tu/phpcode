<?php

/**
 * replylist.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once("inc/config.php");
	require_once("../lang/".$language."/admin/reply_config.php");
	require_once("../lang/".$language."/admin/common.php");
	require_once("admincheck.php");
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_replylist']?> </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
      <script language="javascript">
		function checkAll(f){
			var len=f.elements.length;
			if (document.getElementById("handler").checked==true)
			{	
				for(i=0;i<len;i++){
					var e=f.elements[i];
					if (e.type=='checkbox') e.checked=true;
				}
			}
			if (document.getElementById("handler").checked==false)
			{	
				for(i=0;i<len;i++){
					var e=f.elements[i];
					if (e.type=='checkbox') e.checked=false;
				}
			}
		}
	</script>
</head>
 <body>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li class="l1"><span><span><a href="#" target="mainFrame"><?php echo $_['tab_replylist']?></a></span></span></li>
			</ul>
		</div>
		<div class="listintor">
			<div class="header1">
				<img src="images/square.gif" width="6" height="6" alt="" /><span><?php echo $_['text_position']?>：<?php echo $_['position_topic']?> — &gt; <strong><?php echo $_['tab_replylist']?></strong></span>
			</div>
			<form id="listForm" name="listForm" method="post" action="#">
				<div class="header2"><span><?php echo $_['tab_replylist']?></span></div>
				<div class="header3">
					<input type="checkbox" id="handler" name="handler" onClick="checkAll(this.form)"> <strong><?php echo $_['text_selAll']?></strong>
					<a href="javascript:if(confirm('您确定要删除吗？')){document.listForm.action='reply_do.php?act=delAll';document.listForm.submit();}"><img src="images/act_del.gif" width="14" height="14" alt="删除" /> <strong><?php echo $_['text_del']?></strong></a>
				</div>
				<div class="content">
					<table width="100%">
						<tr class="t1">
							<th><?php echo $_['text_replyselect']?></th>
							<th><?php echo $_['text_replycontent']?></th>
							<th><?php echo $_['text_replyuser']?></th>
							<th><?php echo $_['text_replytime']?></th>
							<th><?php echo $_['text_replytopic']?></th>
							<th><?php echo $_['text_replyboard']?></th>
							<th><?php echo $_['text_replyview']?></th>
							<th><?php echo $_['text_replydel']?></th>
						</tr>
						<?php
							if(empty($_GET['pagesize'])||!is_numeric($_GET['pagesize']))
							{
								$pagesize=10;
							}else{
								$pagesize=$_GET['pagesize'];
							if($_GET['pagesize']<1)$pagesize=10;
							}
							$startrow=0;
							$sql2="select * from ".DB_TABLE_PREFIX."reply order by reply_id desc";
							$result=mysql_query($sql2) or die ('查询失败，请检查SQL语句2');
							$rscount=mysql_num_rows($result);
							if ($rscount%$pagesize==0)
							$pagecount=$rscount/$pagesize;
							else
								$pagecount=ceil($rscount/$pagesize);
							if (empty($_GET['page'])||!is_numeric($_GET['page']))
								$page=1;
							else{
								$page=$_GET['page'];
								if($page<1) $page=1;
								if($page>$pagecount) $page=$pagecount;
								$startrow=($page-1)*$pagesize;
							}
							if($page>=$pagecount)
							{
								$nextpage=$pagecount;
							}else{
								$nextpage=$page+1;
							}
							if($page<=1)
							{
								$prepage=1;
							}else{
								$prepage=$page-1;
							}
							$sql="select * from ".DB_TABLE_PREFIX."reply order by reply_id desc limit $startrow,$pagesize";
							$rs=mysql_query($sql);
							$num=mysql_num_rows($rs);
							if(!$num){
								echo "<tr><td colspan='7'>暂时没有数据！</td></tr>";
							}else{
								while($row=mysql_fetch_assoc($rs)){
									$sql2="select * from ".DB_TABLE_PREFIX."topic where topic_id=".$row["reply_topic"];
									$rs2=mysql_query($sql2);
									$row2=mysql_fetch_assoc($rs2);
									$topicTitle=$row2["topic_title"];

									$sql3="select * from ".DB_TABLE_PREFIX."board where board_id=".$row["reply_board"];
									$rs3=mysql_query($sql3);
									$row3=mysql_fetch_assoc($rs3);
									$boardName=$row3["board_name"];
						?>
						<tr>
							<td><input type="checkbox" name="id_list[]" value="<?php echo $row["reply_id"]?>" /></td>
							<td class="td1"><?php echo cut_str($row["reply_content"],12,0,"utf-8");?></td>
							<td><?php echo $row["reply_user"]?></td>
							<td><?php echo $row["reply_posttime"]?></td>
							<td><a href="../ui/color/topicShow.php?bd=<?php echo $row["reply_board"]?>&id=<?php echo $row["reply_topic"]?>" target="blank"><?php echo $topicTitle?></a></td>
							<td><?php echo $boardName?></td>
							<td><a href="replyinfo.php?id=<?php echo $row["reply_id"]?>">查看</a></td>
							<td><a href="javascript:if(confirm('<?php echo $_['text_sureSel']?>?')){location.href='reply_do.php?act=del&id=<?php echo $row["reply_id"]?>'}"><img src="images/dot_del.gif" width="9" height="9" alt="删除" /></a></td>
						</tr>
						<?php
								}
							}
						?>
					</table>
					<?php
						if($rscount>0){
							$url="replylist.php?";
							$url2="replylist.php";
							include_once('page.php');
						}
					?>
				</div>
			</form>
		</div>
	</div>
 </body>
</html>