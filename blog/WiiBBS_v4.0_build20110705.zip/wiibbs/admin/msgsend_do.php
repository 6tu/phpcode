<?php

/**
 * msgsend_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	require_once("inc/config.php");
	require_once("../lang/".$language."/admin/msg_config.php");
	require_once('../lang/'.$language.'/admin/common.php');
	require_once('admincheck.php');
	
	$act=sqlReplace(trim($_GET["act"]));
	switch($act){
		case "send":
			$msgTitle=sqlReplace(trim($_POST["title"]));
			$msgContent=sqlReplace(trim($_POST["content"]));
			$sql="select * from ".DB_TABLE_PREFIX."user";
			$rs=mysql_query($sql);
			while($row=mysql_fetch_assoc($rs)){
				$userAccount=$row["user_account"];
				$sql1="insert into ".DB_TABLE_PREFIX."msg (msg_send,msg_received,msg_title,msg_content,msg_addtime,msg_side) values('admin','".$userAccount."','".$msgTitle."','".$msgContent."','".date("Y-m-d H:i:s")."','1')";
				if(!mysql_query($sql1)){
					alertInfo2($_['fail_send'],"",1);
				}
				$title=$_['text_noticeTitle'];
				$url='';
				sendNotice($title,$url,$userAccount,'2');
			}
			$sql2="insert into ".DB_TABLE_PREFIX."msglog (msglog_title,msglog_content,msglog_sendtime) values ('".$msgTitle."','".$msgContent."','".date("Y-m-d H:i:s")."')";
			if(!mysql_query($sql2)){
				alertInfo2($_['fail_msgadd'],"",1);
			}

			alertInfo2($_['success_send'],"msgsendlist.php",0);
			break;

		case "del":
			$id=sqlReplace(trim($_GET["id"]));
			checkData2($id,"ID",1);
			$sql="delete from ".DB_TABLE_PREFIX."msglog where msglog_id=".$id;
			if(mysql_query($sql)){
				alertInfo2($_['success_msgdel'],"",1);
			}else{
				alertInfo2($_['fail_msgdel'],"",1);
			}
			break;

		case "delAll":
			if(empty($_POST["id_list"])){
				alertInfo2($_['text_selDel'],"",1);
			}
			$listall=$_POST["id_list"];
			foreach($listall as $listid){
				$sql="delete from ".DB_TABLE_PREFIX."msglog where msglog_id=".$listid;
				if(!mysql_query($sql)){
					alertInfo2($_['fail_msgdel'],"",1);
				}
			}
			alertInfo2($_['success_msgdel'],"",1);
			break;
	}
?>