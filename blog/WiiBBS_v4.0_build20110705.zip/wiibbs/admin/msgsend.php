<?php

/**
 * msgsend.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	require_once("inc/config.php");
	require_once("../lang/".$language."/admin/msg_config.php");
	require_once('../lang/'.$language.'/admin/common.php');
	require_once('admincheck.php');
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_msgsend']?> </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
 </head>
 <body>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li class="l1"><span><span><a href="msgsendlist.php" target="mainFrame"><?php echo $_['tab_msgsendlist']?></a></span></span></li>
				<li><span><span><a href="#" target="mainFrame"><?php echo $_['tab_msgsend']?></a></span></span></li>
			</ul>
		</div>
		<div class="listintor">
			<div class="header1">
				<img src="images/square.gif" width="6" height="6" alt="" /><span><?php echo $_['text_position']?>：<?php echo $_['position_user']?> — &gt; <strong><?php echo $_['tab_msgsend']?></strong></span>
			</div>
			<div class="header2"><span><?php echo $_['tab_msgsend']?></span></div>
			<div class="fromcontent">
				<form id="addadminForm" name="addadminForm" method="post" action="msgSend_do.php?act=send">
					<p><?php echo $_['text_msgtitle']?>：<input class="in1" type="text" id="title" name="title" /></p>
					<p><?php echo $_['text_msgcontent']?>：</p>
					<p><textarea id="content" name="content" cols="30" rows="7"></textarea></p>
					<div class="btn">
						<input type="image" src="images/submit1.gif" width="56" height="20" alt="<?php echo $_['alt_submit']?>" onClick="return checkInput();"/>
					</div>
					<script type="text/javascript">
						function checkInput(){
							var form=document.getElementById("addadminForm");
							if (form.title.value=="")
							{
								alert("<?php echo $_['alert_titleNull'];?>");
								form.title.focus();
								return false;
							}
							if(form.content.value=="")
							{
								alert("<?php echo $_['alert_contentNull'];?>");
								form.content.focus();
								return false;
							}
					</script>
				</form>
			</div>
		</div>
	</div>
 </body>
</html>