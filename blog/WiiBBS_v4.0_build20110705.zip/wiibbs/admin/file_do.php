<?php

/**
 * file_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once("inc/config.php");
	require_once("../lang/".$language."/admin/file_config.php");
	require_once("../lang/".$language."/admin/common.php");
	require_once("admincheck.php");
	
	$act=sqlReplace(trim($_GET["act"]));
	switch($act){
		case "del":
			$id=sqlReplace(trim($_GET["id"]));
			checkData2($id,"ID",1);
			$sql="select * from ".DB_TABLE_PREFIX."file where file_id=".$id;
			$rs=mysql_query($sql);
			$row=mysql_fetch_assoc($rs);
			$fileName=$row["file_name"];
			$file="../userfiles/attach/".$fileName;
			if(file_exists($file)){
				@unlink($file);
			}
			$sqlstr="delete from ".DB_TABLE_PREFIX."file where file_id=".$id;
			if(mysql_query($sqlstr)){
				alertInfo2($_['success_filedel'],"",1);
			}else{
				alertInfo2($_['fail_filedel'],"",1);
			}
			break;

		case "delAll":
			if(empty($_POST["id_list"])){
				alertInfo2($_['text_selDel'],"",1);
			}
			$listall=$_POST["id_list"];
			foreach($listall as $listid){
				$sql="select * from ".DB_TABLE_PREFIX."file where file_id=".$listid;
				$rs=mysql_query($sql);
				$row=mysql_fetch_assoc($rs);
				$fileName=$row["file_name"];
				$file="../userfiles/attach/".$fileName;
				if(file_exists($file)){
					@unlink($file);
				}
				$sqlstr="delete from ".DB_TABLE_PREFIX."file where file_id=".$listid;
				if(!mysql_query($sqlstr)){
					alertInfo2($_['fail_filedelAll'],"",1);
				}
			}
			alertInfo2($_['success_filedelAll'],"",1);
			break;
	}
?>