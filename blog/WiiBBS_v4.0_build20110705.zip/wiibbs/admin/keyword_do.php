<?php

/**
 * keyword_do.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	require_once("inc/config.php");
	require_once("../lang/".$language."/admin/common.php");
	require_once("../lang/".$language."/admin/keyword.php");
	require_once("admincheck.php");
	
	$act=sqlReplace(trim($_GET["act"]));
	switch($act){
		case "del":
			$id=sqlReplace(trim($_GET["id"]));
			checkData2($id,"ID",1);
			$sql="delete from ".DB_TABLE_PREFIX."keyword where keyword_id=".$id;
			if(mysql_query($sql)){
				alertInfo2($_['success_keyworddel'],"",1);
			}else{
				alertInfo2($_['fail_keyworddel'],"",1);
			}
			break;

		case "delAll":
			if(empty($_POST["id_list"])){
				alertInfo2($_['text_selDel'],"",1);
			}
			$listall=$_POST["id_list"];
			foreach($listall as $listid){
				$sql="delete from ".DB_TABLE_PREFIX."keyword where keyword_id=".$listid;
				if(!mysql_query($sql)){
					alertInfo2($_['fail_keyworddelAll'],"",1);
				}
			}
			alertInfo2($_['success_keywordAll'],"",1);
			break;
		case "qx":
			$id=sqlReplace(trim($_GET["id"]));
			checkData2($id,"ID",1);
			$sqlStr="select * from ".DB_TABLE_PREFIX."keyword where keyword_id=".$id;
			$rs=mysql_query($sqlStr);
			$row=mysql_fetch_assoc($rs);
			if ($row){
				$sql="update ".DB_TABLE_PREFIX."keyword set keyword_index='0' where keyword_id=".$id;
				if(mysql_query($sql)){
					alertInfo2($_['success_setIndex'],"",1);
				}else{
					alertInfo2($_['fail_setIndex'],"",1);
				}
			}else{
				alertInfo2($_['error_noinfor'],"",1);
			}
		break;
		case "yes":
				$id=sqlReplace(trim($_GET["id"]));
				checkData2($id,"ID",1);
				$sqlStr="select * from ".DB_TABLE_PREFIX."keyword where keyword_id=".$id;
				$rs=mysql_query($sqlStr);
				$row=mysql_fetch_assoc($rs);
				if ($row){
					$sql="update ".DB_TABLE_PREFIX."keyword set keyword_index='1' where keyword_id=".$id;
					if(mysql_query($sql)){
						alertInfo2($_['success_setIndex'],"",1);
					}else{
						alertInfo2($_['fail_setIndex'],"",1);
					}
				}else{
					alertInfo2($_['error_noinfor'],"",1);
				}
		break;
	}
?>