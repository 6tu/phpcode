<?php

/**
 * admingrouplist.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

	require_once('inc/config.php');
	require_once('../lang/'.$language.'/admin/common.php');
	require_once('admincheck.php');
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_group']?> </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
</head>
 <body>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li><span><span><a href="admingrouplist.php" target="mainFrame"><?php echo $_['tab_groupList']?></a></span></span></li>
				<li  class="l1"><span><span><a href="admingroupadd.php"><?php echo $_['tab_groupAdd']?></a></span></span></li>
			</ul>		
		</div>
		<div class="listintor">
			<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" />
				<span><?php echo $_['text_position']?>：<?php echo $_['position_system']?> －&gt; <strong><<?php echo $_['tab_groupList']?></strong></span>
			</div>
			<form  name="listForm" method="post" action="#" id="listForm">
				<div class="header2"><span><?php echo $_['tab_groupList']?></span></div>
				<div class="header3">
					<a href="admingroupadd.php"><img src="images/act_add.gif" alt="+" /><?php echo $_['text_newAdd']?></a>
				</div>
				<div class="content">
					<table width="100%">
						<tr class="t1">
							<th><?php echo $_['text_name']?></th>
							<th><?php echo $_['text_setLimit']?></th>
							<th><?php echo $_['text_del']?></th>
						</tr>
					<?php
						$sql="select * from ".DB_TABLE_PREFIX."admingroup";
						$rs=mysql_query($sql);
						while($row=mysql_fetch_assoc($rs)){
							echo "<tr><td>".$row['admingroup_name']."</td><td class='center'><a href='admingroupedit.php?id=".$row['admingroup_id']."'><img src='images/dot_edit.gif'></a></td>";
							echo "<td class='center'><a href='javascript:if(confirm(\"".$_['text_sureSel']."？\"))location.href=\"admingroup_do.php?act=del&id=".$row['admingroup_id']."\"'><img src='images/dot_del.gif'></a>";
							echo"</td></tr>";
						}
					?>
					</table>
				</div>
			</form>
		</div>
	</div>
 </body>
</html>