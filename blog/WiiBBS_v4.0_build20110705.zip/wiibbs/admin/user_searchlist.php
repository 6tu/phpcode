<?php

/**
 * user_searchlist.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	require_once("inc/config.php");
	require_once('../lang/'.$language.'/admin/user_config.php');
	require_once("../lang/".$language."/admin/common.php");
	require_once("admincheck.php");
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_userList']?> </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
  <script language="javascript">
	function checkAll(f){
		var len=document.getElementsByName('id_list[]').length;
		if (document.getElementById("handler").checked==true)
		{
			for(i=0;i<len;i++){
				document.getElementsByName('id_list[]')[i].checked=true;
			}
		}
		if (document.getElementById("handler").checked==false)
		{
			for(i=0;i<len;i++){
				document.getElementsByName('id_list[]')[i].checked=false;
			}
		}
	}
  </script>
</head>
 <body>
	<?php
		if(empty($_GET['t'])){$t='';}else{$t=$_GET['t'];}
		$ac=(empty($_REQUEST["account"]))?"":$_REQUEST["account"];
		$m=(empty($_REQUEST["mobile"]))?"":$_REQUEST["mobile"];
		$mail=(empty($_REQUEST["email"]))?"":$_REQUEST["email"];
		$adr=(empty($_REQUEST["address"]))?"":$_REQUEST["address"];
		$p=(empty($_REQUEST["province"]))?"":$_REQUEST["province"];
		$ct=(empty($_REQUEST["city"]))?"":$_REQUEST["city"];
		$n=(empty($_REQUEST["nickname"]))?"":$_REQUEST["nickname"];
		$l=(empty($_GET["l"]))?"":$_GET['l'];
		$g=(empty($_GET["g"]))?"":$_GET['g'];
		$pagesize=15;
		$startRow=0;
		$page=(empty($_GET["page"]))?"":$_GET['page'];
		if (empty($_GET['page'])||!is_numeric($_GET['page'])){
			$page=1;
		}else{
			$page=$_GET['page'];
			$startRow=($page-1)*$pagesize;
		}			
		$url="t=".$t."&ac=".$ac."&m=".$m."&mail=".$mail."&adr=".$adr."&p=".$p."&ct=".$ct."&n=".$n."&l=".$l."&g=".$g;
		$where='';
		if (!empty($ac)) $where.=" and  user_account like '%".$ac."%'";
		if (!empty($m)) $where.=" and user_mobile like '%".$m."%'";
		if (!empty($mail)) $where.=" and user_email like '%".$mail."%'";
		if (!empty($adr)) $where.=" and user_address like '%".$adr."%'";
		if (!empty($p)) $where.=" and user_province like '%".$p."%'";
		if (!empty($ct)) $where.=" and user_city like '%".$ct."%'";
		if (!empty($n)) $where.=" and user_nickname like '%".$n."%'";
		$sqlStrt="select * from ".DB_TABLE_PREFIX."user where 1=1 ".$where;
		
		$sqlStr="select * from ".DB_TABLE_PREFIX."user  where 1=1 ".$where." order by user_id desc limit $startRow,$pagesize";
	?>
	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li class="l1"><span><span><a href="userlist.php" target="mainFrame"><?php echo $_['tab_userList']?></a></span></span></li>
				<li class="l1"><span><span><a href="usersearch.php" target="mainFrame"><?php echo $_['tab_userSearch']?></a></span></span></li>
				<li class="l1"><span><span><a href="useradd.php" target="mainFrame"><?php echo $_['tab_userAdd']?></a></span></span></li>
			</ul>
		</div>
		<div class="listintor">
			<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" />
				<span><?php echo $_['text_position']?>：<?php echo $_['position_user']?> －&gt; <strong><?php echo $_['tab_userSearch']?></strong></span>
			</div>
			<form id="listForm" name="listForm" method="post" action="#">
				<div class="header2"><span><?php echo $_['tab_userSearch']?></span></div>
				<div class="header3">
					<input type="checkbox" id="handler" name="handler" onClick="checkAll(this.form)"> <strong><?php echo $_['text_selAll']?></strong>
					<a href="javascript:document.listForm.action='user_do.php?act=rmd&<?php echo $url?>&page=<?php echo $page?>';document.listForm.submit();"><img src="images/act_save.gif" width="16" height="16" alt="保存" /> <strong><?php echo $_['text_save']?></strong> </a>
					<a href="javascript:if(confirm('您确定要删除吗？')){document.listForm.action='user_do.php?act=delAll';document.listForm.submit();}"><img src="images/act_del.gif" width="14" height="14" alt="删除" /> <strong><?php echo $_['text_del']?></strong></a>
				</div>
				<div class="content">
					<table width="100%">
						<tr class="t1">
							<th><?php echo $_['text_check']?></th>
							<th><?php echo $_['text_useraccount']?></th>
							<th><?php echo $_['text_usermobile']?></th>
							<th><?php echo $_['text_useremail']?></th>
							<th><?php echo $_['text_userregtime']?></th>
							<th><?php echo $_['text_userisvip']?></th>
							<th><?php echo $_['text_usernote']?></th>
							<th><?php echo $_['text_useredit']?></th>
							<th><?php echo $_['text_userdel']?></th>
						</tr>
						<?php
							$rs=mysql_query($sqlStrt);
							$row=mysql_fetch_assoc($rs);
							if(!$row){ 
								echo "<tr><td colspan='7'>暂且没有数据！</td></tr>";
							}else{		
								$rs = mysql_query($sqlStrt) or die ("查询失败，请检查SQL语句T。");
								$result = mysql_query($sqlStr) or die ("查询失败，请检查SQL语句。");
								$rscount=mysql_num_rows($rs);
								if ($rscount%$pagesize==0)
									$pagecount=$rscount/$pagesize;
								else
									$pagecount=ceil($rscount/$pagesize);
								$i=0;
								while($row=mysql_fetch_assoc($result)){
								$i++;
						  ?>
						<tr>
							<td><input type="checkbox" name="id_list[]" value="<?php echo $row["user_id"];?>"></td>
							<td><?php echo $row["user_account"];?></td>
							<td><?php echo $row["user_mobile"];?></td>
							<td><?php echo $row["user_email"];?></td>
							<td><?php echo $row["user_regtime"];?></td>
							<td><input type="hidden" name="id<?php echo $i?>" value="<?php echo $row["user_id"]?>"/><input type="checkbox" name="isRmd<?php echo $i?>" <?php if($row["user_isvip"]=="1") echo "checked"?>/></td>
							<td><?php echo $row["user_note"];?></td>
							<td><a href="useredit.php?id=<?php echo $row["user_id"]?>"><img src="images/dot_edit.gif" width="9" height="9" alt="编辑"></a></td>
							<td><a href="javascript:if(confirm('<?php echo $_['text_sureSel']?>?')){location.href='user_do.php?act=del&id=<?php echo $row["user_id"]?>'}"><img src="images/dot_del.gif" width="9" height="9" alt="删除" /></a></td>
						</tr>
						<?php
								}
						?>
					</table>
					<div class="page">
					  <p><input type="hidden" name="i" value="<?php echo $i?>"/>
					  </p>
					</div>
					<?php
					showPage("user_searchlist.php?".$url,$page,$pagesize,$rscount,$pagecount);
					?>
					<?php }?>
				</div>
			</form>
		</div>
	</div>
 </body>
</html>