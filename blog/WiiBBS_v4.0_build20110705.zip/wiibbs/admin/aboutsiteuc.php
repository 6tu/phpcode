<?php

/**
 * aboutsiteuc.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. (http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */

?><?php
	require_once('inc/config.php');
	require_once('../lang/'.$language.'/admin/common.php');
	require_once('../lang/'.$language.'/admin/site.php');
	require_once("admincheck.php");
	//checkAdminRight("122",$_SESSION[WiiBBS_ID."admingroup"]);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title> <?php echo $_['header_site'];?> </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="author" content="Jiangting@WiiPu -- http://www.wiipu.com" />
  <link rel="stylesheet" href="style2.css" type="text/css"/>
 </head>
 <body>
 	<div class="bgintor">
		<div class="tit1">
			<ul>
				<li  class="l1"><a href="aboutsite.php" target="mainFrame" ><?php echo $_['tab_base'];?></a> </li>
				<li class="l1"><a href="aboutsiteadvance.php"><?php echo $_['tab_advance'];?></a> </li>
				<li><a href="aboutsiteuc.php"><?php echo $_['tab_UCenter'];?></a> </li>
			</ul>		
		</div>
		<div class="listintor">
			<div class="header1"><img src="images/square.gif" width="6" height="6" alt="" />
				<span><?php echo $_['text_position']."：".$_['position_bbs'];?> －&gt; <strong><?php echo $_['tab_UCenter'];?></strong></span>
			</div>
			<div class="header2"><span><?php echo $_['tab_UCenter'];?></span></div>
			<div class="fromcontent">
				<form action="aboutsite_do.php?act=ucenter" method="post" id="doForm">
					<p class='p1'><?php echo $_['text_tip4'];?></p>
					<p><?php echo $_['text_ucenter'];?>：</p>
					<p class="txt">
						<textarea name="uccode" cols="60" rows="9"></textarea>
					</p>
					<div class="btn">
						<input type="image" src="images/submit1.gif" width="56" height="20" alt="<?php echo $_['alt_submit'];?>" onClick="return check();"/>
					</div>
				</form>
			</div>
		</div>
	</div>
 </body>
</html>
