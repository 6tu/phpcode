<?php

/**
 * index.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) ΢�տƼ� WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	require_once("include/db_conn.php");
	$userBrowser=$_COOKIE[WiiBBS_ID."browser"];
	$url=empty($_GET['key'])?'':$_GET['key'];
	$url=sqlReplace($url);
	if (empty($url)){
		if(!empty($userBrowser)){
			Header("Location:".NETURL."/ui/".$userBrowser."/index.php");
		}else{
			websitez_detect_mobile_device();
			if ($mobile_browser){
				if ($mobile_browser_type=='3'){
					setcookie(WiiBBS_ID."browser","3g",time()+60*60*24*7);
					Header("Location:".NETURL."/ui/3g/index.php");
				}else if ($mobile_browser_type=='1'){
					setcookie(WiiBBS_ID."browser","color",time()+60*60*24*7);
					Header("Location:".NETURL."/ui/color/index.php");
				}else if ($mobile_browser_type=='2'){
					setcookie(WiiBBS_ID."browser","simple",time()+60*60*24*7);
					Header("Location:".NETURL."/ui/simple/index.php");
				}
			}else{
				setcookie(WiiBBS_ID."browser","color",time()+60*60*24*7);
				Header("Location:".NETURL."/ui/color/index.php");

			}
		}
	}else{
		Header("Location:".NETURL."/ui/".$url."/index.php");
	}

?>