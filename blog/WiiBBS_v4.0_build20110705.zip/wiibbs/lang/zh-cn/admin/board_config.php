<?php

/**
 * board_config.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	$_['header_board']                        ='版面';
	$_['header_boardAdd']                     ='添加版面';
	$_['header_boardEdit']                    ='编辑版面';
	$_['position_board']                      ='版面管理';
	$_['tab_boardList']                        ='版面列表';
	$_['tab_boardAdd']                        ='添加版面';
	$_['tab_boardEdit']                        ='编辑版面';
	$_['tab_boardclassList']                   ='版面分类';
	$_['tab_boardclassAdd']                   ='添加版面分类';
	$_['tab_boardclassEdit']                   ='编辑版面分类';

	$_['text_select']                         ='选择';
	$_['text_boardname']                      ='版面名称';
	$_['text_boarddesc']                      ='版面简介';
	$_['text_boardadmin']                     ='版面版主';
	$_['text_boardpic']                       ='版面图片';
	$_['text_boardclass1']                     ='所属分类';
	$_['text_boardcategory']                  ='版面模式';
	$_['text_boardtype']                      ='版面类型';
	$_['text_boardischeck']                   ='本版面是否开启审核功能';
	$_['text_boardupload']                    ='本版面是否开启附件上传功能';
	$_['text_upload']                         ='可上传';
	$_['text_ischeck']                          ='需审核';
	$_['text_boardorder']                     ='排序';
	$_['text_boardedit']                      ='编辑';
	$_['text_boarddel']                       ='删除';
	$_['text_boarTip1']                       ='版主须为前台已注册的会员，多个版主用“|”隔开';
	$_['text_noCheckClass']                   ='请先添加版面分类';
	$_['text_boardGuess']                     ='游客版面(注册会员跟游客都可以)';
	$_['text_boardUser']                      ='会员版面';
	$_['text_boardVip']                       ='VIP版面';
	$_['text_boardAdmin']                     ='管理员版面';
	$_['text_boardTo']                        ='指定会员版面';
	$_['text_boardNews']                      ='资讯版面';
	$_['text_boardPt']                        ='普通版面';
	$_['text_userTip']                        ='请输入指定会员帐号按"|"间隔';

	$_['success_boardadd']                    ='版面添加成功';
	$_['success_boardedit']                   ='版面修改成功';
	$_['success_boarddel']                    ='版面删除成功';
	$_['success_boardclassadd']               ='版面分类添加成功';
	$_['success_boardclassedit']              ='版面分类修改成功';
	$_['success_boardclassdel']               ='版面分类删除成功';
	$_['success_boardclasssave']              ='版面分类排序成功';
	$_['success_boardsave']                   ='版面排序成功';
	$_['fail_boardadd']                       ='版面添加失败，错误编码：';
	$_['fail_boardedit']                      ='版面修改失败，错误编码：';
	$_['fail_boarddel']                       ='版面删除失败，错误编码：';
	$_['fail_boardnoinfo']                    ='查询版面失败，错误编码：';
	$_['fail_boardclassadd']                  ='版面分类添加失败，错误编码：';
	$_['fail_boardclassedit']                 ='版面分类修改失败，错误编码：';
	$_['fail_boardclassdel']                  ='版面分类删除失败，错误编码：';
	$_['fail_boardclasssave']                 ='版面分类排序失败';
	$_['fail_boardsave']                      ='版面排序失败';

	$_['alert_boardname']                     ='版面名称不能为空';

	$_['fail_selectBoard_r']                          ='0300:查询失败，请检查SQL语句';
	$_['fail_selectBoard_2']                          ='0301:查询失败，请检查SQL语句';
	$_['fail_selectBoard_3']                          ='0302:查询失败，请检查SQL语句';
?>