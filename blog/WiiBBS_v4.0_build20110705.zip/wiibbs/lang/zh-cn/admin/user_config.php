<?php

/**
 * user_config.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	$_['position_user']                       ='用户管理';
	$_['header_userList']                     ='用户列表';
	$_['header_userAdd']                      ='添加用户';
	$_['header_userSearch']                   ='搜索用户';
	$_['menu_userList']                       ="用户管理";
	$_['menu_msgList']                        ='信息列表';
	$_['tab_userList']                        ='用户列表';
	$_['tab_userSearch']                      ='用户搜索';
	$_['tab_userAdd']                         ='添加用户';
	$_['tab_userEdit']                        ='编辑用户';


	$_['text_useraccount']                    ='用户帐号';
	$_['text_password']                       ='用户密码';
	$_['text_usermobile']                     ='用户手机';
	$_['text_useremail']                      ='用户邮箱';
	$_['text_userregtime']                    ='注册时间';
	$_['text_userisvip']                      ='是否VIP';
	$_['text_username']                       ='用户姓名';
	$_['text_usernickname']                   ='用户昵称';
	$_['text_usersex']                        ='用户性别';
	$_['text_usercity']                       ='所在城市';
	$_['text_province']                       ='所在省份';
	$_['text_userphoto']                      ='用户头像';
	$_['text_userbrithday']                   ='出生日期';
	$_['text_userqq']                         ='用户QQ';
	$_['text_userintro']                      ='用户简介';
	$_['text_useraddress']                    ='用户地址';
	$_['text_userinfo']                       ='相关信息';
	$_['text_usersina']                       ='用户微博';
	$_['text_usernote']                       ='用户备注';
	$_['text_userinfo']                       ='用户信息';
	$_['text_usersend']                       ='发信数';
	$_['text_useredit']                       ='编辑';
	$_['text_userdel']                        ='删除';

	$_['success_useradd']                     ='添加用户成功';
	$_['success_usersave']                    ='保存用户成功';
	$_['success_userdel']                     ='删除用户成功';
	$_['fail_useradd']                        ='添加用户失败，错误编号：0300';
	$_['fail_usersave']                       ='保存用户失败，错误编号：0301';
	$_['fail_userdel']                        ='删除用户失败，错误编号：0302';

	$_['error_nouserinfo']                    ='查询失败，错误编号：0303';

	$_['alert_useraccount']                   ='用户帐号不能为空';
	$_['alert_userpass']                      ='用户密码不能为空';
	$_['alert_usermobile']                    ='用户手机不能为空';
	$_['alert_useremail']                     ='用户邮箱不能为空';
?>