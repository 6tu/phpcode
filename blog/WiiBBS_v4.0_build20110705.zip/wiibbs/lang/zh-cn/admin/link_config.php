<?php

/**
 * link_config.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	$_['header_link']                    ='友情链接';
	$_['header_linkadd']                 ='增加友情链接';
	$_['header_linkedit']                ='修改友情链接';

	$_['tab_linkList']                   ='友情链接';
	$_['tab_linkAdd']                    ='添加友情链接';
	$_['tab_linkEdit']                   ='编辑友情链接';

	$_['text_linkname']                  ='链接名称';
	$_['text_linkpic']                   ='链接图片';
	$_['text_linkurl']                   ='链接地址';
	$_['text_index']                     ='是否首页显示';
	$_['text_linkorder']                 ='排序';
	$_['text_linkedit']                  ='编辑';
	$_['text_linkdel']                   ='删除';

	$_['alert_linkname']                 ='链接名称不能为空';
	$_['alert_linkurl']                  ='链接地址不能为空';
	$_['alert_linkurl_r']                  ='你输入的URL无效';

	$_['success_linkadd']                ='友情链接添加成功';
	$_['success_linkedit']               ='友情链接修改成功';
	$_['success_linkdel']                ='友情链接删除成功';
	$_['success_linksave']               ='友情链接排序成功';
	$_['fail_linkedit']                  ='友情链接修改失败';
	$_['fail_linkadd']                   ='友情链接添加失败';
	$_['fail_linksave']                  ='友情链接排序失败';
	$_['fail_linkdel']                   ='友情链接删除失败，错误编码：';
	$_['fail_linknoInfo']                ='查询失败，该链接不存在，错误编码：';
?>