<?php

/**
 * reply_config.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	$_['header_replylist']                 ='回复列表';
	$_['header_replyinfo']                 ='回复详情';
	
	$_['tab_replylist']                    ='回复列表';
	$_['tab_replyinfo']                    ='回复详情';
	
	$_['text_replyselect']                 ='选择';
	$_['text_replycontent']                ='回复内容';
	$_['text_replyuser']                   ='回复者';
	$_['text_replytime']                   ='回复时间';
	$_['text_replytopic']                       ='所属帖子';
	$_['text_replyboard']                       ='所属版面';
	$_['text_replyview']                   ='查看';
	$_['text_replydel']                    ='删除';
?>