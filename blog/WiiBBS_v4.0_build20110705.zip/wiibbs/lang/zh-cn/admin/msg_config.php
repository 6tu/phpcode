<?php

/**
 * msg_config.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	$_['header_msgsendlist']              ="发送记录";

	$_['tab_msgsend']                     ="群发站内信";
	$_['tab_msgsendlist']                 ="发送记录";

	$_['text_msgselect']                  ="选择";
	$_['text_msgtitle']                   ='标题';
	$_['text_msgcontent']                 ='内容';
	$_['text_msgposttime']                ='发送时间';
	$_['text_msgsenddel']                 ='删除';
	$_['text_noticeTitle']                 ='有新的站内信';

	$_['fail_send']                       ='发送失败，错误编号：0400';
	$_['fail_msgadd']                     ='添加失败，错误编号：0401';
	$_['fail_msgdel']                     ='删除失败，错误编号：0402';
	$_['success_msgdel']                  ='删除成功';
	$_['success_send']                    ='发送成功';

	$_['alert_titleNull']                 ='标题不能为空';
	$_['alert_contentNull']                 ='内容不能为空';
?>