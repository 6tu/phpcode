<?php

/**
 * common.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	$_['header_admin_title']                  =' 后台管理首页';
	$_['header_adminAdd']                     ='添加管理员';
	$_['header_admin']                        ='管理员列表';
	$_['header_groupAdd']                     ='添加管理员组';
	$_['header_group']                        ='管理员组';
	$_['header_adminEdit']                    ='个人信息修改';
	$_['header_setConfigue']                  ='网站基本设置';
	$_['header_manage']                       ='网站管理平台';
	$_['header_memu']                         ='WiiPu管理主菜单';
	$_['header_login']                        ='登录 - WiiPu管理后台';
	$_['header_boardclass']                   ='版面分类';
	$_['header_boardclassAdd']                ='添加版面分类';
	$_['header_boardclassEdit']               ='编辑版面分类';
	$_['header_upPic']                        ='上传分类图片';

	$_['header_bbsAdmin']               ='论坛管理员列表';

	$_['text_position']                       ='位置';
	$_['text_position_index']                 ='首页';
	$_['position_system']                     ='系统管理';
	$_['position_web']                        ='网站管理';
	$_['position_bbs']                        ='论坛设置';
	$_['position_user']                       ='用户管理';
	$_['position_topic']                      ='帖子管理';

	$_['text_reply']                       ='回复';
	$_['text_topic']                       ='发帖';
	$_['text_yes']                             ='是';
	$_['text_no']                              ='否';
	$_['text_show']                             ='显示';
	$_['text_cancel']                              ='取消';
	$_['text_profile']                        ='个人资料';
	$_['text_proAdminGroup']                  ='管理员组';
	$_['text_proAccount']                     ='用 户 名';
	$_['text_proLoginCount']                  ='登录次数';

	$_['text_sysInfor']                       ='系统信息';
	$_['text_sysName']                        ='系统名称';
	$_['text_sysTime']                        ='系统时间';

	$_['text_editPWD']                        ='修改密码';
	$_['text_oldPWD']                         ='原密码';
	$_['text_newPWD']                         ='新密码';
	$_['text_PWD2']                           ='确认密码';

	$_['text_adminAccount']                   ='管理员名称';
	$_['text_adminpwd']                       ='管理员密码';
	$_['text_pointPwd']                       ='不少于6位';
	$_['text_adminLimit']                     ='管理员权限';
	$_['text_groupAccount']                   ='管理员组名称';
	$_['text_setLimit']                       ='设置权限';
	$_['text_selDel']                         ='请选择删除项';
	$_['text_sureSel']                        ='确定删除吗？';
	$_['text_selAll']                         ='全选';
	$_['text_save']                           ='保存';
	$_['text_newAdd']                         ='新建';
	$_['text_name']                           ='名称';
	$_['text_del']                            ='删除';
	$_['text_edit']                           ='编辑';
	$_['text_limit']                          ='权限';
	$_['text_check']                          ='选择';
	$_['text_seeAdmin']                       ='查看管理员';
	$_['text_manageAdmin']                    ='管理管理员(增，删，改)';
	$_['text_manageGroup']                    ='管理管理员组';
	$_['text_logonTime']                      ='登陆时间';
	$_['text_logonIP']                        ='登录IP';
	$_['text_boardclassname']                 ='分类名称';
	$_['text_boardclasspic']                  ='分类图片';
	$_['text_boardclassdesc']                 ='分类描述';
	$_['text_order']						  ='排序';
	$_['text_select']                         ='选择';
	$_['text_bbsaccount']                         ='管理员';
	$_['menu_bbsadmin']                        ='前台管理员设置';
	$_['menu_bbsadminAdd']                        ='添加论坛管理员';
	$_['text_bbsaccount']                        ='前台账号';

	$_['text_nodate']                                 ="没有信息";


	$_['text_checkext']                                 ="文件格式不在允许范围";
	$_['text_picSize']                                 ="文件大小不能超过200KB";
	$_['text_uploarFail']                                 ="未知错误，上传失败，请重新上传。";
	$_['text_picMsg1']                                 ="上传成功。 文件类型：";
	$_['text_picMsg2']                                 ="文件大小：";


	$_['text_keyParam']                            ='关键参数';
	$_['text_data']                                ='日期';
	$_['text_week']                                ='星期';
	$_['text_mon']                                 ='一';
	$_['text_tues']                                ='二';
	$_['text_wed']                                 ='三';
	$_['text_thur']                                ='四';
	$_['text_fri']                                 ='五';
	$_['text_sat']                                 ='六';
	$_['text_sunday']                              ='日';
	$_['text_year']                                ='年';
	$_['text_month']                               ='月';
	$_['text_day']                                 ='日';
	$_['text_point']                                 ='提示';


	$_['text_logo']                                ='网站Logo';
	$_['text_webName']                             ='网站名称';
	$_['text_icp']                                 ='ICP备案号';
	$_['text_webWidth']                            ='网站宽度';
	$_['text_smtp']                                ='SMTP服务器';
	$_['text_emailAddress']                         ='Email地址';
	$_['text_emailAcount']                          ='Email帐号';
	$_['text_emailPwd']                             ='Email密码';
	$_['text_standard']                             ='标准';
	$_['text_adaptive']                             ='自适应';

	$_['text_wiipu']                                ='Wiipu官网';
	$_['text_feedback']                             ='反馈';
	$_['text_com']                                  ="© 2008-2010 <a href=\"http://www.wiipu.com\" target=\"_blank\">北京微普科创科技有限公司</a>";
	$_['text_call']                                 ="客服：010-59451935";

	$_['text_index1']                               ='前台首页';
	$_['text_index2']                               ='管理首页';
	$_['text_quit']                                 ="安全退出";
	$_['text_noCheck']                                 ="请选择删除项";

	$_['text_loginAccount']                         ='账　号';
	$_['text_loginPwd']                             ='密　码';
	$_['text_loginCode']                            ='验证码';

	//menu
	$_['menu_adminList']                        ="系统管理员列表";
	$_['menu_group']                            ="系统管理员组";
	$_['menu_conf']                             ="系统设置";
	$_['menu_skin']                             ="风格设置";
	$_['menu_boardclass']                       ="版面分类";
	$_['menu_boardList']                        ="版面列表";
	$_['menu_link']                             ="友情链接";
	$_['menu_bbsstat']                          ="论坛统计"; 
	$_['menu_msgsend']                          ="群发站内信";
	$_['menu_file']                             ="附件管理";
	$_['menu_keyword']                          ="关键词管理";

	//success
	$_['success_addAdmin']                      ='添加成功！';
	$_['success_delAdmin']                      ='删除成功！';
	$_['success_save']                          ='保存成功！';
	$_['success_updatePwd']                     ='修改密码成功，下次登陆生效！';
	$_['success_setConf']                       ='网站基本设置成功';
	$_['success_delbbsAdmin']                       ='论坛管理员删除成功';
	$_['success_addbbsAdmin']                       ='论坛管理员添加成功';

	//fail
	$_['failAddAdmin']                          ='0101:添加失败！原因：SQL语句写入失败！';
	$_['failDelAdmin']                          ='0102:删除失败！原因：执行 ‘delete’ SQL语句失败！';
	$_['failExistsAccount']                     ='该帐号已经存在！';
	$_['failSelectGroup']                       ='查询失败，请检查SQL语句。';
	$_['failGroupAdd']                          ='0104:添加失败！原因：SQL写入失败。';
	$_['failGroupDel']                          ='0105:删除失败！原因：SQL删除失败。';
	$_['failGroupSave']                         ='0106:保存失败！原因：SQL更新失败。';
	$_['fail_updateAdmin']                      ='0100:数据更新失败，请重新登录.';
	$_['fail_updatePWD']                        ='0103:修改密码失败！';
	$_['fail_setConf']                          ='0002网站基本设置失败,原因sql异常。';
	$_['fail_selectBoard']                          ='查询失败，请检查SQL语句';
	$_['fail_connectDatabase']                          ='0000:数据库连接失败';
	$_['fail_findDatabase']                          ='0001:没有找到数据库。';

	$_['fail_deleteBBSAdmin']                   ='论坛管理员删除失败';
	$_['fail_deleteBBSAdmin_r']                  ='您要删除的论坛管理员不存在';
	$_['fail_addeteBBSAdmin']                  ='论坛管理员添加失败';
	$_['fail_noUser']                          ='该用户不存在';
	$_['fail_delBBSAdmin']                          ='删除失败!';

	//tab
	$_['tab_adminList']                        ='管理员列表';
	$_['tab_adminAdd']                        ='添加管理员';
	$_['tab_groupList']                        ='管理员组列表';
	$_['tab_groupAdd']                        ='添加管理员组';

	//alert
	$_['alert_account']                        ='账号不能为空';
	$_['alert_pwd']                            ='密码不能为空';
	$_['alert_group']                          ='管理员组名称';
	$_['alert_limit']                          ='请选择权限';
	$_['alert_group_a']                        ='管理员名称不能为空';
	$_['alert_nullP']                          ='账号、密码、验证码不能为空';
	$_['alert_code']                           ='验证码错误';
	$_['alert_old']                            ='原密码不能为空';
	$_['alert_new']                            ='新密码不能为空';
	$_['alert_pwd2']                           ='确认密码不能为空';
	$_['alert_pwd3']                           ='两次密码不相同';
	$_['alert_webName']                        ='网站名称不能为空';
	$_['alert_boardclassname']                 ='分类名称不能为空';
	$_['alert_boardclassdesc']                 ='分类描述不能为空';

	$_['alter_f_ext']                          ='文件格式不在允许范围';
	$_['alter_f_size']                         ='文件大小不能超过20KB';
	$_['alter_f_upload']                       ='未知错误，上传失败。请重新上传。';
	$_['alter_codeNull']                       ='验证码不能为空';
	$_['alter_check']                          ='登陆超时或尚未登陆';
	$_['alter_bbsAccount']                          ='名称不能为空';


	//button

	$_['alt_submit']                        ='提交';
	$_['alt_manage']                        ='管理平台';
	$_['alt_index']                         ='首页';
	$_['alt_return']                        ='返回';
	$_['alt_go']                            ='前进';
	$_['alt_refresh']                       ='刷新';
	$_['alt_code']                          ='没看到图片请刷新页面';



	$_['error_adminAccount']                     ='管理员账号';
	$_['error_adminPwd']                         ='管理员密码';
	$_['error_adminPwd_length']                  ='密码不能小于6位！';
	$_['error_nogroup']                          ='请先添加管理员组！';
	$_['error_noinfor']                          ='数据被删除或不存在';
	$_['error_accountPWD']                       ='账号或密码错误！';	
	$_['error_oldPWD']                           ='原密码错误！';
	$_['error_siteInitialize']                   ='数据库初始化失败!';
?>