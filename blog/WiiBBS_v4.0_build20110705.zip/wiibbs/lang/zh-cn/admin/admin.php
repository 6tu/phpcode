<?php

/**
 * bbsstat_cofig.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	
	$_['text_wiibbsUserCount']                      ='使用WiiBBS网站数';
	$_['text_version']                              ='版  本  号';
	$_['text_bbsUpdate']                            ='更新时间';
	$_['text_bbsStat']                              ='论坛统计';
	$_['text_userCount']                            ='注册会员数';
	$_['text_dayCount']                             ='今日流量';
	$_['text_totalCount']                           ='总浏览量';
	$_['text_upgrade']                              ='在线升级';
	$_['text_bbsNews']                              ='WiiBBS动态';
	$_['text_adminTip']                             ='2011年5月起统计';
	
?>