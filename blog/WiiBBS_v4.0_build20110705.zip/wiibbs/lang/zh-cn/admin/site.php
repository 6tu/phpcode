<?php

/**
 * bbsstat_cofig.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	$_['header_site']                    ='网站设置';
	

	$_['tab_base']                       ='基本设置';
	$_['tab_advance']                     ='高级设置';
	$_['tab_UCenter']                    ='UCenter设置';

	$_['text_count']                      ='是否显示论坛统计';
	
	$_['text_tip1']                        ='提示：仅对论坛作用';

	$_['text_express']                        ='是否开启表情功能';
	$_['text_ubb']                        ='是否支持UBB代码';
	$_['text_tip2']                        ='链接：[url="名称"]地址[/url]　　图片：[img]地址[/img]';
	$_['text_timeZone']                        ='时区';
	$_['text_smtp']                        ='SMTP服务器';
	$_['text_mailAddress']                        ='Email地址';
	$_['text_mailAccount']                        ='Email帐号';
	$_['text_mailPass']                        ='Email密码';
	$_['text_tip3']                        ='内容过滤：(不允许出现的字词。词之间用逗号分开)';
	$_['text_tip4']                        ='提示：当您已经添加了一个新的UCenter应用程序后将UCenter应用管理下的 应用的UCenter配置信息 拷贝到以下输入框中.';
	$_['text_ucenter']                        ='UCenter代码';

	$_['text_standard']                        ='标准时间(UTC)';
	$_['text_assigned']                        ='手动指定偏差';

	$_['alert_name']                        ='网站名称不能为空';
	$_['alert_name_r']                        ='网站名称';

	$_['success_advance']                        ='网站高级设置成功!';
	$_['success_ucenter']                        ='Ucenter配置成功!';

	$_['fail_advance']                        ='网站高级设置失败!';


	$_['alert_ucenter']                           ='UCenter代码不能为空!';

?>