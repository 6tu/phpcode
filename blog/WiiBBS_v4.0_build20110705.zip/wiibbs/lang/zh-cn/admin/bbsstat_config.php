<?php

/**
 * bbsstat_cofig.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	$_['header_bbsstat']                    ='论坛统计';
	$_['header_visitstat']                  ='访问统计';
	$_['header_onlinestat']                 ='在线统计';

	$_['tab_bbsdata']                       ='论坛数据';
	$_['tab_visitstat']                     ='访问统计';
	$_['tab_onlinestat']                    ='在线统计';
?>