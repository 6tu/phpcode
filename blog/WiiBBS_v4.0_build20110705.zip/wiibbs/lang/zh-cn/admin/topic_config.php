<?php

/**
 * topic_config.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	$_['menu_topic']                  ='帖子管理';
	$_['menu_reply']                  ='回复管理';
	$_['header_topiclist']            ='帖子管理';
	$_['header_topicsearch']          ='帖子搜索';

	$_['tab_topiclist']               ='帖子列表';
	$_['tab_replylist']               ='回复列表';
	$_['tab_topicsearch']             ='帖子搜索';
	
	$_['text_topicselect']            ='选择';     
	$_['text_topictitle']             ='帖子标题';
	$_['text_topicuser']              ='发帖人';
	$_['text_topicboard']             ='所属版面';
	$_['text_replycount']             ='回复量';
	$_['text_viewcount']              ='浏览量';
	$_['text_addtime']                ='添加时间';
	$_['text_topicview']              ='查看原贴';
  	$_['text_topiccontent']           ='帖子内容';
	$_['text_topicedit']              ='编辑';
	$_['text_topicdel']               ='删除';
?>