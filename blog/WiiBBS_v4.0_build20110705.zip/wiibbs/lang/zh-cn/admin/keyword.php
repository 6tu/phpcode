<?php

/**
 * file_config.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	
	$_['tab_keywordList']                     ="关键词列表";
	$_['text_keywordName']                     ="关键词名称";
	$_['text_searchCount']                     ="搜索次数";
	$_['text_lastTimeSearch']                     ="最后一次搜索时间";
	$_['text_isIndex']                     ="是否在前台显示";
	$_['text_keywordName']                     ="关键词名称";
	$_['text_keywordName']                     ="关键词名称";


	$_['success_keyworddel']                     ="0308:删除成功";
	$_['success_keywordAll']                     ="0310:删除成功";
	$_['success_setIndex']                     ="设置成功！";

	$_['fail_keyworddel']                     ="0307:删除失败";
	$_['fail_keyworddelAll']                     ="0309:删除失败";
	$_['fail_setIndex']                     ="设置失败！";
	$_['fail_selectKeyword']                     ="0311:查询失败，请检查SQL语句";
?>