<?php

/**
 * file_config.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	$_['header_filelist']                  ="附件管理";

	$_['tab_filelist']                     ="附件列表";

	$_['text_fileselect']                  ="选择";
	$_['text_filetopic']                   ="所属帖子";
	$_['text_fileurl']                     ="附件地址";
	$_['text_filename']                    ="附件名称";
	$_['text_fileview']                    ="预览";
	$_['text_fileaddtime']                 ="添加时间";
	$_['text_filesort']                    ="附件类型";
	$_['text_filedel']                     ="删除";
	$_['success_filedel']                     ="0303:删除成功";
	$_['success_filedelAll']                     ="0306:删除成功";

	$_['fail_filedel']                     ="0304:删除失败";
	$_['fail_filedelAll']                     ="0305:删除失败";
	$_['fail_selectFile']                     ="0306:查询失败，请检查SQL语句";
?>