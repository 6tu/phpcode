<?php

/**
 * msg.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	//text
	$_['text_myBox']	=	'我的信息';
	$_['text_writeBox']	=	'写新信息';
	$_['text_unredBox']	=	'未读信息';
	$_['text_inBox']	=	'收件箱';
	$_['text_outBox']	=	'发件箱';
	$_['text_sender']	=	'发件人';
	$_['text_title']	=	'标题';
	$_['text_content']	=	'内容';
	$_['text_details']	=	'信息详情';
	$_['text_wirter']	=	'写信人';
	$_['text_receiver']	=	'收信人';
	$_['text_unred']	=	'未读';
	$_['text_hasred']	=	'已读';
	//tip信息提示
	$_['tip_send1']	    =	'1、收件人不能为空，且存在.';
	$_['tip_send2']	    =	'2、标题不能为空.';
	$_['tip_send3']	    =	'3、内容不能为空.';
	$_['tip_noMsg']	    =	'暂无信息';
	$_['tip_reply1']	=	'1、回复标题不能为空.';
	$_['tip_reply2']	=	'2、回复内容不能为空.';
	$_['tip_nomsg']	=	'信息被删除或已经不存在';
	$_['tip_Receivernull']	=	'收件人不能为空';
	$_['tip_titlenull']	=	'标题不能为空';
	$_['tip_contentnull']	=	'内容不能为空';
	$_['tip_noReceiver']	=	'收件人不存在';
	$_['tip_noSendSelf']	=	'不能给自己发送';

	//btn
	$_['btn_reply']	   =	'回复';
	$_['btn_del']	   =	'删除';

	//suc
	$_['suc_send']	   =	'发送成功';
	$_['suc_del']	   =	'删除成功';
	$_['suc_reply']	   =	'回复成功';
?>