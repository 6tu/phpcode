<?php

/**
 * function.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */


	define('FUNCTION_AUTO','如果没有自动跳转,请');
	define('FUNCTION_CLICK','点击这里');
	define('FUNCTION_PRE','上页');
	define('FUNCTION_NEXT','下页');

?>