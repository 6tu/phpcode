<?php

/**
 * topic.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	$_['header_dowm']                               ='文件下载';
	$_['header_editTopic']                          ='编辑帖子';
	$_['header_delTopic']                           ='删除帖子';
	$_['header_moveTopic']                          ='转移帖子';

	$_['text_TopicAll']                             ='总置顶帖';
	$_['text_postTopic']                            ='发表帖子';
	$_['text_moderator']                            ='版主';
	$_['text_good']                                 ='精华区';
	$_['text_all']                                  ='全部';
	$_['text_check']                                ='待审核帖';
	$_['text_picDown']                              ='图片下载';
	$_['text_oldPic']								='原图';
	$_['text_highPic']								='高清320*480';
	$_['text_smallPic']								='大240*320';
	$_['text_smallerPic']							='小128*160';
	$_['text_topicTitle']							='标题';
	$_['text_topicContent']							='内容';
	$_['text_topictoSina']							='分享到新浪微博';
	$_['text_topicinfo']							='注:<br/>
				1、附件上传速度及大小限制视各地网络情况而定,建议';
	$_['text_topicinfo_1']							='以内,支持';
	$_['text_topicinfo_2']='<br/>
				2、部分手机不支持文件名为中文的附件上传.<br/>';
	$_['text_sureDel']								='确定要删除这条帖子吗?';
	$_['text_sureDelReply']							='确定要删除这条回复吗？';
	$_['text_checkBoard']							='请选择要转移至的版面';
	$_['text_noBoard']								='无版面';

	$_['text_filename']								='文件名';
	$_['text_write']								='发表于';
	$_['text_topicdel']								='删';
	$_['text_topicEdit']							='改';
	$_['text_topicAlltop']							='总置顶';
	$_['text_topicTop']								='置顶';
	$_['text_topicGood']							='精华';
	$_['text_topicLock']							='锁';
	
	
	$_['text_topicCAlltop']							='取消总置顶';
	$_['text_topicCTop']							='取消置顶';
	$_['text_topicCGood']							='取消精华';
	$_['text_topicCLock']							='解锁';

	$_['text_topicMove']							='转移';
	$_['text_topicsina']							='转发到新浪微博';
	$_['text_morecomment']							='更多回复';
	$_['text_comment']								='回复';
	$_['text_replyList']							='回复列表';
	$_['text_quickReply']							='快速回复';
	$_['text_topicList']							='帖子列表';
	$_['text_contentDefault']						='顶';
	$_['text_fileUp']								='附件';
	$_['text_fileSize']								='大小限制';
	$_['text_fileType']								='格式限制';
	$_['text_ubb']									='支持UBB代码';
	$_['text_orderDESC']							='查看最新回帖';
	$_['text_orderASC']								='正序查看';
	$_['text_reply_r']								='的回帖';
	$_['text_oldBorder']							='原版面';
	$_['text_newBorder']							='新版面';

	$_['text_checkTopic']							='审核帖子';
	$_['text_managerTopic']							='管理帖子';
	$_['text_promptTopic']							='提示';
	$_['text_m_backBoard']                          ='返回版面';

	$_['alert_login']								='请先登录';
	$_['alert_noPic']								='图片不存在';
	$_['alert_noNEW']								='信息已被删除';
	$_['alert_lock']								='该帖子被锁定，不能回复！';
	$_['alert_filter']								='内容中有不和谐的关键字！';
	$_['alert_filter_r']							='包含不和谐的关键字！';
	$_['alert_contentNull']							='回复内容不能为空！';
	$_['alert_contentNull_r']						='内容不能为空!';
	$_['alert_titleNull']							='帖子标题不能为空!';
	$_['alert_type1']								='只允许上传';
	$_['alert_type2']								='的格式的文件';
	$_['alert_type3']								='文件不能超过';
	$_['alert_repeatPost']							='不要太贪心哦，发一次就够啦。';
	$_['alert_postSucc']							='发布成功！';
	$_['alert_postFail']							='意外出错';
	$_['alert_uploadFail']							='上传失败';

	$_['alert_postEdit']							='修改成功';
	$_['alert_errorEdit']							='修改失败';
	$_['alert_postdo']								='操作成功';
	$_['alert_noLimit']								='没有权限';
	$_['alert_noCheckLimit']						='没有审核权限';
	$_['alert_noCheckBorder']						='没有选择版面!';
	$_['alert_adminBoard']							='发此版面只有管理员才能发帖！';
	$_['alert_postreply']							='回复成功';
	$_['alert_errorreply']							='回复失败';
	$_['alert_errordel']							='删除失败';
	$_['alert_postdel']								='删除成功';
	$_['alert_nofile']								='附件已被删除';
	$_['alert_postRepeat']                          ='不能重复发布呦';

	$_['alert_successMove']							='转移成功';
	$_['alert_successCheck']						='审核成功';
	$_['alert_errorCheck']							='审核失败';
	$_['alert_boardLogin']							='该版面需要注册登陆后才能访问！';
	$_['alert_boardvip']							='该版面VIP会员才能访问！';
	$_['alert_boardMember']							='该版面只有指定会员才可进入! ';
	$_['alert_noboard']								='版面不存在或已被删除!';


	define('NOTICETITLE','帖子有新的回复');

	define('S_TOP','顶');
	define('S_GOOD','精');
	define('S_FILE','附');
	define('S_REPLY','回');
	define('S_SEE','阅');
	define('NOTOPIC','暂无');
	$_['btn_do']	   =	'发布';
	$_['btn_certain']	   =	'确定';
	$_['btn_cancel']	   =	'取消';
	$_['btn_move']	   =	'转移';
	$_['btn_hotTopic']	   =	'热帖';
	$_['btn_newTopic']	   =	'新帖';
	$_['btn_checkTopic']	   =	'审核';
	
?>