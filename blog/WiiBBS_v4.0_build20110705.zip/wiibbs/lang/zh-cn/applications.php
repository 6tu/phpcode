<?php

/**
 * applications.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
	//text
	$_['text_HotTopic']					=	'热门帖子';
	$_['text_Lcount']					=	'论坛统计';
	$_['text_online']					=	'当前在线';
	$_['text_memberCount']				=	'会员数';
	$_['text_topicCount']				=	'主题数';
	$_['text_cenusCount']				=	'帖子数';
	$_['text_todayFlow']				=	'今日流量';
	$_['text_allFlow']					=	'总浏览量';
	$_['text_searchTopic']				=	'帖子搜索';
	$_['text_links']					=	'友情链接';
	$_['text_key']						=	'热门搜索';

	//tip
	$_['tip_search']					=	'的搜索结果';
	define('tip_noSearchResult','没有找到相应结果，请重新搜索');
	$_['tip_noLink']					=	'尚未添加任何连接';
	$_['tip_noHotTopic']				=	'暂无热门帖子';
	$_['tip_pageExpired']				=	'不能访问此页面';
	$_['tip_nokey']						=	'尚未任何关键字';
?>