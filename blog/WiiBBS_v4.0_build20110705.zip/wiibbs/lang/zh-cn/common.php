<?php

/**
 * common.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
//meta
	$_['meta_Author']                    = '微普科技http://www.wiipu.com';


	define('FUNCTION_RETURN','返回');
	define('FUNCTION_INVA_PAREA','非法参数');
	define('FUNCTION_NOTNULL','不能为空');

//error
	define('ERROR_DBLINK','数据库连接失败');
	define('ERROR_OPERATION','非法访问');
	define('error_operationDo','非法操作');
	define('ERROR_SELECTSQL','查询失败，请检查SQL语句');
	define('ERROR_SETINITIALIZE','数据库初始化失败');

//text
	$_['text_goodMorning']				='上午好';
	$_['text_goodAfternoon']			='下午好';
	$_['text_tourist']					='游客';
	$_['text_welcome']					='欢迎您';
	$_['text_recommend']					='推荐';

	$_['text_index']					='首页';
	$_['text_mail']						='私信';
	$_['text_reply']					='回复';
	$_['text_login']					='登陆';
	$_['text_reg']						='注册';
	$_['text_userCenter']				='用户中心';
	$_['text_userAccount']				='账户';
	$_['text_notice']				    ='通知';
	$_['text_notice']				    ='通知';
	$_['text_toTop']					='顶部';
	$_['text_hotTopic']					=	'热门';
	$_['text_board']					=	'版面';
	$_['text_census']					=	'统计';
	$_['text_search']					=	'搜索';
	$_['text_link']						=	'友链';
	$_['text_quit']						=	'退出';
	$_['text_more']						=	'更多';
	$_['text_notice']					=	'通知';
	$_['text_time']					=	'时间';
	$_['text_switch']							='转到';
	$_['text_skip']							='跳';
	$_['text_noticeHave']					=	'您有';
	$_['text_noticeEmial']					=	'封站内信未读';
	$_['text_noticeReply']					=	'条新回复';
	$_['text_upload_file']					='上传附件';
	$_['text_upload1']					='上传';
	define('text_noticeNCTitle','修改昵称');
	define('text_noticeNCContent',"<a href='useredit.php'>点击修改昵称</a>");
	define('text_fileType','类型');
	define('text_fileSize','大小');

	$_['text_simple']					=	'简版';
	$_['text_color']					=	'彩版';
	$_['text_3g']						=	'触屏版';
	$_['alert_login']					='请先登录';
	$_['success_login']					='登陆成功!';

//btn
	$_['btn_login']						=	'登录';
	$_['btn_register']					=	'注册';
	$_['btn_exit']						=	'退出';
	$_['btn_submit']					=	'提交';
	$_['btn_goback']					=	'返回';
	$_['btn_upload']					=	'上传';
	$_['btn_search']					=	'搜';
	$_['btn_back']						=	'返回';

	$_['alert_account']                        ='账号不能为空';
	$_['alert_pwd']                            ='密码不能为空';
	$_['alert_pwd1']                            ='确认密码不能为空';
	$_['alert_pwd2']                            ='两次输入的密码不同';

	$_['error_up1']                             ='上传的文件大小超过了系统限制';
	$_['error_up2']                             ='上传文件过程出错。';
	$_['error_up3']                             ='没有选择文件。';
	$_['error_up4']                             ='系统错误：不存在临时文件夹。';
	$_['error_up5']                             ='系统错误：写入文件出错。';
	$_['error_up6']                             ='未知错误';
	$_['error_up7']                             ='图片保存的目标文件夹不存在或无写权限。';

	
?>