<?php

/**
 * user.php
 *
 * @version       v0.01
 * @create time   2011-5-30
 * @update time   
 * @author        wiipu
 * @copyright     Copyright (c) 微普科技 WiiPu Tech Inc. ( http://www.wiipu.com)
 * @informaition  

 * Update Record:
 *
 */
//text
	$_['text_userLogin']	=	'用户登录';
	$_['text_memberLogin']	=	'会员登录';
	$_['text_userRegister']	=	'会员注册';
	$_['text_forgetPwd']	=	'忘记密码';
	$_['text_account']	=	'账号';		
	$_['text_password']	=	'密码';
	$_['text_email']	=	'邮箱';
	$_['text_newPwd']	=	'新密码';
	$_['text_confirmPwd']	=	'确认密码';
	$_['text_accountoremail']	=	'账号/邮箱/手机号';
	$_['text_accountoremail_3g']	=	'账号';
	$_['text_remberCookie']	=	'记住登录状态，需支持并打开手机的cookie功能';
	$_['text_restpw']	=	'重置密码';
	$_['text_mailTile']	=	'忘记密码';
	$_['text_myStuff']	=	'我的资料';
	$_['text_editStuff']	=	'修改资料';
	$_['text_editPwd']	=	'修改密码';
	$_['text_memberInformation']	=	'会员资料';
	$_['text_nikeName']	=	'昵称';
	$_['text_score']	=	'积分';
	$_['text_grade']	=	'等级';
	$_['text_regTime']	=	'注册时间';
	$_['text_logCount']	=	'登录次数';
	$_['text_lastLoginTime']	=	'最近登录';
	$_['text_details']	=	'详细资料';
	$_['text_mobile']	=	'手机号';
	$_['text_name']	=	'姓名';
	$_['text_sex']	=	'性别';
	$_['text_city']	=	'城市';
	$_['text_province']	=	'省份';
	$_['text_qq']	=	'QQ';
	$_['text_address']	=	'地址';
	$_['text_sina']	=	'微博账号';
	$_['text_brith']	=	'生日';
	$_['text_man']	=	'男';
	$_['text_women']	=	'女';
	$_['text_editUser']	=	'修改个人资料';
	$_['text_oldPwd']	=	'旧密码';
	$_['text_newPwd']	=	'新密码';
	$_['text_rePwd']	=	'确认密码';
	$_['text_upload']	=	'上传头像';
	$_['text_myTopic']	=	'我的帖子';
	$_['text_mySendTopic']	=	'已发布的帖子';
	$_['text_sendMsg']	=	'发送信息';
	$_['text_m_login']	=	'登陆';
	$_['text_m_reg']	=	'注册';
	$_['text_m_backIndex']	=	'返回论坛首页';
	$_['text_noUpload']	=	'您还没有选择要上传的文件';

//tip提示信息
	$_['tip_tips']	=	'小提示:';
	$_['tip_login1']	=	'1、登录成功后保存任意页面为书签，下次通过书签访问，也可免去登录过程。';
	$_['tip_login2']	=	'2、请不要直接通过手机浏览器的发送地址功能将登录后的页面地址发送给朋友，以免泄露个人信息及密码。';
	$_['tip_commom']	=	'注';
	$_['tip_reg1']	=	'1、账号为必填项';
	$_['tip_reg2']	=	'2、密码为必填项';
	$_['tip_accountexist']	=	'该账号已经存在，请重新输入.';
	$_['tip_updateEmail']	=	'邮箱更新失败，';
	$_['tip_emailexist']	=	'邮箱已经存在，';
	$_['tip_exception']	=	'意外错误.返回上一页';
	$_['tip_exception_3g']	=	'意外错误';
	$_['tip_AEexist']	=	'账号或邮箱或手机号不存在';
	$_['tip_pwderror']	=	'密码输入错误';
	$_['tip_forgetPw1']	=	'1、填写您的账号和邮箱我们将会为您发送一封忘记密码的邮件.';
	$_['tip_forgetPw2']	=	'2、如何您的个人信息没有填写邮箱，请与管理员联系。';
	$_['tip_noequalPw']	=	'两次输入的密码不一致，跳到上一页.';
	$_['tip_forgetPw21']	=	'1.新密码不能为空.';
	$_['tip_forgetPw22']	=	'2.确认密码不能为空.';
	$_['tip_forgetPw23']	=	'3.新密码必须和确认密码一致.';
	$_['tip_expired']	=	'该网页已经过期.';
	$_['tip_nikenameExists']	=	'该昵称已经存在';
	$_['tip_emailExists']	=	'该邮箱已经存在';	
	$_['tip_emailFormat']	=	'邮箱格式有误';	
	$_['tip_errorOldPwd']	=	'旧密码错误';
	$_['tip_mobileExists']	=	'该号码已经存在请重新输入';
	$_['tip_upload1']	=	'1、格式限制gif|jpg|png';
	$_['tip_upload2']	=	'2、图片大小不超过40k';
	$_['tip_mobileFormat']	=	'请输入正确的手机号';
	$_['tip_forbidAccount']	=	'该用户名禁止注册';
	$_['tip_accounLength']	=	'用户长度应在';
	$_['tip_center']	=	'之间';
	$_['tip_allowNum']	=	'账户注册只允许数字';
	$_['tip_allowLetter']	=	'账户注册只允许为字母';
	$_['tip_allowCommon']	=	'账户只允许字母、数字及短横线';
	$_['tip_timeOut']	=	'两分钟内不容许同一IP注册';
	$_['tip_to']	=	'至';
	$_['tip_returnlogin']	=	'该操作需要注册登陆后才能执行!';
	$_['tip_select']	=	'请选择';

//btn
	$_['btn_forgetpw']	=	'忘记密码';
	$_['btn_clickhere']	=	'点击此处';

//suc
	$_['suc_register']	=	'注册成功';
	$_['suc_register_3g']	=	'注册成功,请登录';
	$_['suc_login']	=	'登陆成功，跳到首页';
	$_['suc_forgetPw1']	=	'申请成功，请打开您输入的邮箱进行重置密码';
	$_['suc_forgetPw2']	=	'设置成功，请使用刚才的密码登录.跳到登录页';
	$_['suc_loginout']	=	'用户退出成功，返回到登录前的页面';
	$_['suc_editUser']	=	'更新成功';
	$_['suc_editPw']	=	'密码修改成功,下次使用新密码登录.';
	$_['suc_upload']	=	'头像上传成功';

//error
	$_['error_register']	=	'注册失败，';
	$_['error_login']	=	'登录失败';
	$_['error_forgetPw1']	=	'账号或邮箱错误.跳到忘记密码页';
	$_['error_forgetPw2']	=	'设置失败，请重新操作.返回到上一页';
	$_['error_editUser']	=	'更新失败';
	$_['error_eidtPw']	=	'密码修改失败';
	$_['error_fileFormat']	=	'您上传的文件格式错误';
	$_['error_fileSizeOut']	=	'只能上传不大于40k的图片';
	$_['error_upload']	=	'头像上传失败,请重新上传.';
	$_['error_username']    ='用户名或密码不正确！';
	$_['alert_email_null']    ='邮箱不能为空！';
	$_['alert_email_error']    ='请填写正确的邮箱地址！';
	$_['alert_not_Findpwd']    ='无法找回密码，请联系管理员，在后台设置发送邮件的信息！';
	$_['alert_fail_sendEmail']    ='发送邮件失败！';
	$_['alert_forgetPw21']	=	'新密码不能为空.';
	$_['alert_forgetPw22']	=	'确认密码不能为空.';
	$_['alert_forgetPw23']	=	'新密码必须和确认密码一致.';
	$_['alert_oldPWD']	=	'旧密码不能为空.';

?>