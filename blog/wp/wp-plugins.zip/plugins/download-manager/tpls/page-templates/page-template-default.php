<!-- WPDM Template: Default Template -->

<div class="row">
<div class="col-md-12">
[thumb_900x0]
</div>
    <div class="col-md-12"><br/>
<table class="table table-bordered">
<tbody>
<tr><td>Download</td><td>[download_count]</td></tr>
<tr><td>Stock</td><td>[quota]</td></tr>
<tr><td>File Size</td><td>[file_size]</td></tr>
<tr><td>Create Date</td><td>[create_date]</td></tr>
<tr><td colspan="2">[download_link_extended]</td></tr>
</tr>
</tbody></table>
        </div>


<div class="col-md-12">
[description]



</div>
</div>
 
