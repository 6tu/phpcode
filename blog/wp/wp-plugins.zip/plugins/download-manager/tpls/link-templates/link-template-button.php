<!-- WPDM Link Template: Only Link/Button -->
[download_link_extended]