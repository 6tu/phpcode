<!-- WPDM Link Template: Card -->

    <div class="list-group wpdm-lt-card" style="margin: 0 0 15px 0">
        <div class="list-group-item">
            <a href="[page_url]" style="display: block;margin: 5px 0">
            [thumb_500x250]
            </a>
        </div>
        <div class="list-group-item">
            <h4 style="padding: 0px;margin:0px;">[page_link]</h4>
        </div>
        <div class="list-group-item">
            <span class="badge">[file_size]</span> File Size
        </div>
        <div class="list-group-item">
            <span class="badge">[download_count]</span> Downloads
        </div>
        <div class="list-group-item">
            [download_link]
        </div>
    </div>

 