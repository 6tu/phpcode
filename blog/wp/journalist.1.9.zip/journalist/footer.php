</div>

<div id="footer">
	<p>The Journalist template by <a href="http://lucianmarin.com/" rel="designer">Lucian E. Marin</a> &mdash; Built for <a href="http://wordpress.org/">WordPress</a></p>
</div>
<?php do_action('wp_footer', ''); ?>

</body>
</html>