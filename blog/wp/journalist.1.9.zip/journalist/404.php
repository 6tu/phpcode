<?php get_header(); ?>

<div id="content">

	<h2>Error 404 - Not Found</h2>
	<div class="warning">
		<p>Apologies, but we were unable to find what you were looking for. Perhaps searching will help.</p>
	</div>

</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
