<?php get_header(); ?>
<div class="content-wrap">
	<div class="content">
		<?php echo _hui('ads_cat_01_s') ? '<div class="ssr ssr-content">'.hui_get_adcode('ads_cat_01').'</div>' : '' ?>
		<?php 
		$pagedtext = '';
		if( $paged && $paged > 1 ){
			$pagedtext = ' <small>'.__('第', 'haoui').$paged.__('页', 'haoui').'</small>';
		}

		if( _hui('cat_desc_s') ){
			$description = trim(strip_tags(category_description()));
		    if( _hui('cat_keyworks_s') && $description && strstr($description, '::::::') ){
		        $desc = explode('::::::', $description);
		        $description = trim($desc[2]);
		    }
		    echo '<div class="cat-leader"><h1>', single_cat_title(), $pagedtext.'</h1><div class="cat-leader-desc">'.$description.'</div></div>';
	    }else{
	    	echo '<h1 class="title"><strong><a href="'.get_category_link( get_cat_ID( single_cat_title('',false) ) ).'">', single_cat_title(), '</a></strong>'.$pagedtext.'</h1>';
	    }

		get_template_part( 'excerpt' ); 
		?>
	</div>
	<div>&#22823;&#37327;&#28304;&#30721;&#65292;&#25345;&#32493;&#26356;&#26032;&#65306;&#119;&#119;&#119;&#46;&#108;&#97;&#110;&#114;&#101;&#110;&#122;&#104;&#105;&#106;&#105;&#97;&#46;&#99;&#111;&#109;</div>
</div>
<?php get_sidebar(); get_footer(); ?>