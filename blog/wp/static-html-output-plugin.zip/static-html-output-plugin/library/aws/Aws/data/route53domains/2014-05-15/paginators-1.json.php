<?php
// This file was auto-generated from sdk-root/src/data/route53domains/2014-05-15/paginators-1.json
return [ 'version' => '1.0', 'pagination' => [ 'ListDomains' => [ 'limit_key' => 'MaxItems', 'input_token' => 'Marker', 'output_token' => 'NextPageMarker', 'result_key' => 'Domains', ], 'ListOperations' => [ 'limit_key' => 'MaxItems', 'input_token' => 'Marker', 'output_token' => 'NextPageMarker', 'result_key' => 'Operations', ], ],];
