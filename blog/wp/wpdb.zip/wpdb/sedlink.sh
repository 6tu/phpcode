sed -i "s/href=\"http:\/\/ys138.win\/201/href="..\/..\/201/g" `grep -rl "index.html" /var/www/html/page`
sed -i "s/href=\"http:\/\/ys138.win\//href=\"..\/..\//g" `grep -rl "index.html" /var/www/html/page`
sed -i "s/href='http:\/\/ys138.win\//href='..\/..\//g" `grep -rl "index.html" /var/www/html/page`
sed -i "s/src='http:\/\/ys138.win\//src='..\/..\//g" `grep -rl "index.html" /var/www/html/page`

sed -i "s/href=\"..\/..\/app\/\"/href=\"http:\/\/ys138.win\/app\/\"/g" `grep -rl "index.html" /var/www/html/page`
sed -i "s/href=\"..\/..\/ss\/\"/href=\"http:\/\/ys138.win\/ss\/\"/g" `grep -rl "index.html" /var/www/html/page`

