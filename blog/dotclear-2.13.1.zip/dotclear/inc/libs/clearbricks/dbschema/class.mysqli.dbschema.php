<?php
# -- BEGIN LICENSE BLOCK ---------------------------------------
#
# This file is a mysqli dbchema for Clearbrick.
#
# Mysql and mysqli DBSchema are the same, so this class only
# extends original mysql DBSchema class.
#
# Copyright (c) 2011 Maxime Varinard @ Vaisonet
# Licensed under the GPL version 2.0 license.
# See LICENSE file or
# http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
#
# -- END LICENSE BLOCK -----------------------------------------

require_once('class.mysql.dbschema.php');
class mysqliSchema extends mysqlSchema
{

}
?>