<?php


	$lang['admin']['uploader']['default'] = array(
		'head'		=> 'Uploader',
		'descr'		=> 'Pick one or more file to upload.',
		'fset1'		=> 'File Picker',
		'fset2'		=> 'Upload',
		'submit'	=> 'Upload',

	);

	$lang['admin']['uploader']['default']['msgs'] = array(
		1	=> 'File(s) uploaded',
		-1	=> 'An error occurred while trying to upload.',
	);
	
	
	
	$lang['admin']['uploader']['browse'] = array(
		'head'		=> 'Browse',
		'descr'		=> 'Pick one or more file to upload.',
		'fset1'		=> 'File Picker',
		'submit'	=> 'Upload',

	);

	
?>
