<?php

$lang['plugin']['accessibleantispam'] = array(
		
	'prefix'	=> 'In order to help eliminate automated spam attacks '.
		'we must ask you to prove you are human. What is ',
		
	'sum'		=> '%s plus %s ?',
	'sub'		=> '%2$s subtracted from %1$s ?',
	'prod'		=> '%s times %s ?',
		
	'error'		=> 'Sorry, you gave the wrong answer. Please try again.'
	
	);

