<?php
	
	$langconf = array();
	$langconf['id'] = 'Simplified Chinese (PRC)';
	$langconf['locale'] = 'zh-cn';
	$langconf['charsets'][0] = 'utf-8';

?>
