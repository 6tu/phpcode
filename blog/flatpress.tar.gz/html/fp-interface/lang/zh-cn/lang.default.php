<?php

	$lang = array();

	$lang['main'] = array(
		
		'nextpage'		=> '下一页 &raquo;',
		'prevpage'		=> '&laquo; 上一页',
		'entry'      	=> '文章',
		'static'     	=> '静态页面',
		'comment'    	=> '评论',
		'preview'    	=> '编辑/预览',
		
		'filed_under'	=> '发布在 ',	
		
		'add_entry'  	=> '添加文章',
		'add_comment'  	=> '添加评论',
		'add_static'  	=> '添加静态页面',
		
		'btn_edit'     	=> '编辑',
		'btn_delete'   	=> '删除',
		
		'nocomments'	=> '添加评论',
		'comment'	=> '1 个评论',
		'comments'	=> ' 个评论',
		
	);
	
	$lang['search'] = array(
		
		'head'	=> '搜索',
		'fset1'	=> '即时搜索条件',
		'keywords'	=> '关键词',
		'onlytitles'	=> '仅标题',
		'fulltext'	=> '全文',
		
		'fset2'	=> '日期',
		'datedescr'	=> '您可以将搜索限制在一定的时间段内。可以是一年内、一月内或一个完整的日期前。 '.
					'不填表示搜索全部时间。',
		
		'fset3' 	=> '按分类搜索',
		'catdescr'	=> '不填表示搜索全部分类。',
		
		'fset4'	=> '开始搜索',
		'submit'	=> '搜索',
		
		'headres'	=> '搜索结果',
		'descrres'	=> '搜索 <strong>%s</strong> 返回如下结果:',
		'descrnores'=> '搜索 <strong>%s</strong> 返回 0 个结果。',
		
		'moreopts'	=> '更多选项',
		
		
		'searchag'	=> '再次搜索',
		
	);
	
	$lang['search']['error'] = array(
	
		'keywords'	=> '您必须至少指定一个关键词。'
	
	);
	
	
	
	
	
	$lang['entry'] = array();
	$lang['entry']['flags'] = array();
	
	$lang['entry']['flags']['long'] = array(
		'draft' => '<strong>草稿文章</strong>: 隐藏, 等待发布',
		//'static' => '<strong>Static entry</strong>: normally hidden, to reach the entry put ?page=title-of-the-entry in url (experimental)',
		'commslock' => '<strong>评论关闭</strong>: 此文章禁止评论'
	);
	
	$lang['entry']['flags']['short'] = array(
		'draft' => '草稿文章',
		//'static' => 'Static',
		'commslock' => '评论关闭'
	);

	$lang['404error'] = array(
		'subject'	=> '未找到',
		'content'	=> '<p>抱歉，找不到您所请求的页面。</p>'
	);
		
	// Login
	$lang['login'] = array(
		
		'head'		=> '登录',
		'fieldset1'	=> '请输入您的用户名密码',
		'user'		=> '用户名:',
		'pass'		=> '密码:',
		'fieldset2'	=> '请登录',
		'submit'	=> '登录',
		'forgot'	=> '遗忘密码'
	);
		
	$lang['login']['success'] = array(
		'success'	=> '登录成功。',
		'logout'	=> '登出成功。',
		'redirect'	=> ' 5 秒钟后重定向。',
		'opt1'		=> '回到主页',
		'opt2'		=> '进入控制面板',
		'opt3'		=> '添加新文章'
	);
	
	$lang['login']['error'] = array(
		'user'		=> '请输入用户名。',
		'pass'		=> '请输入密码。',
		'match'		=> '用户名或密码错误。'
	);
	
	
	$lang['comments'] = array(
		'head'		=> '添加评论',
		'descr'		=> '完成下列表单发表您的观点。',
		'fieldset1'	=> '用户数据',
		'name'		=> '昵称 (*)',
		'email'		=> 'Email:',
		'www'		=> 'Web:',
		'cookie'	=> '记住设置',
		'fieldset2'	=> '添加您的评论',
		'comment'	=> '评论 (*):',
		'fieldset3'	=> '发送',
		'submit'	=> '添加',
		'reset'		=> '重置',
		'success'	=> '评论添加成功',
		'nocomments'	=> '此文章尚未收到任何评论',
		'commslock'	=> '此文章评论已关闭',
	);
	
	$lang['comments']['error'] = array(
		'name'		=> '请填写您的昵称',
		'email'		=> '请使用有效的 Email',
		'www'		=> '请使用有效的 URL',
		'comment'	=> '请填写评论正文',
	);
	
	$lang['date']['month'] = array(
		
		'一月',
		'二月',
		'三月',
		'四月',
		'五月',
		'六月',
		'七月',
		'八月',
		'九月',
		'十月',
		'十一月',
		'十二月'
		
	);

	$lang['date']['month_abbr'] = array(
		
		'Jan',
		'Feb',
		'Mar',
		'Apr',
		'May',
		'Jun',
		'Jul',
		'Aug',
		'Sep',
		'Oct',
		'Nov',
		'Dec'
		
	);

	$lang['date']['weekday'] = array(
		
		'星期日',
		'星期一',
		'星期二',
		'星期三',
		'星期四',
		'星期五',
		'星期六',
		
	);

	$lang['date']['weekday_abbr'] = array(
		
		'周日',
		'周一',
		'周二',
		'周三',
		'周四',
		'周五',
		'周六',
		
	);



?>
