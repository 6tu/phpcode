<?php

	$lang['admin']['plugin']['submenu'] = array (
		'default'		=> '插件管理'
	);
	
	/* main plugin panel */

	$lang['admin']['plugin']['default'] = array(
	
		'head'		=> '插件管理',
		'enable'	=> '启用',
		'disable'	=> '禁用',
		'descr'		=> '<a class="hint" '.
						'href="http://wiki.flatpress.org/doc:plugins" title="What is a plugin?">'.
						'插件</a> 是用来扩展 FlatPress 功能的组件。</p>'.
						'<p>您可以通过将插件文件上传至 <code>fp-plugins/</code> 目录来安装插件'.
						'。</p>'.
						'<p>本面板中您可以禁用或启用插件。',
		'name'		=> '名称',
		'description'=>'描述',
		'author'	=> '作者',
		'version'	=> '版本',
		'action'	=> '操作',
	);
	
	$lang['admin']['plugin']['default']['msgs'] = array(
		1	=> '设置保存成功',
		-1	=> '保存设置出错。有多种可能的原因：例如文件中才能在语法错误。',
	);
	
	/* system errors */
	
	$lang['admin']['plugin']['errors'] = array(
		'head'		=> '载入插件时出现如下错误:',
		'notfound'	=> '插件未找到，跳过。',
		'generic'	=> '错误代号 %d',
	);
	
?>
