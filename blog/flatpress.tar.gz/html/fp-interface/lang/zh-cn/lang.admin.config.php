<?php

	$lang['admin']['config']['default'] = 
	array(
		'head'		=> '选项',
		'descr'		=> '自定义和设置您的 FlatPress。',
		'submit'		=> '保存',
		
		'sysfset'		=> '系统信息',
		'syswarning'	=> '<big>警告!</big> 以下信息需要您的注意，请及时修正。否则 FlatPress 无法正常工作。',
		'blog_root'		=> '<strong>FlatPress 的绝对路径</strong>。 提示:'.
					'通常您无需修改此项，请谨慎，FlatPress 无法验证此项是否正确。',
		'www'		=>'<strong>绝对链接</strong>。 指向您博客的URL，包括博客所在的目录。<br />'.
					'例如: http://www.mydomain.com/flatpress/ (注意末尾的斜线)',
		// ------
		
		'gensetts'		=> '主要设置',
		'blogtitle'		=> '博客标题',
		'blogsubtitle'		=> '博客副标题',
		'blogfooter'		=> '博客页脚',
		'blogauthor'		=> '博客作者',
		'startpage'			=> '网站的主页是',
		'stdstartpage'		=> '我的博客 (默认)',
		'blogurl'			=> 'Blog URL',
		'blogemail'			=> 'Blog email',
		'notifications'		=> '通知',
		'mailnotify'		=> '为评论启用邮件通知',
		'blogmaxentries'	=> '每页文章数',
		'langchoice'		=> 'Language',

		'intsetts'		=> '国际化设置',
		'utctime'		=> '<acronym title="Universal Coordinated Time">UTC</acronym> 时间',
		'timeoffset'		=> '与本地时间相差',
		'hours'			=> '小时',
		'timeformat'		=> '默认时间格式',
		'dateformat'		=> '默认日期格式',
		'dateformatshort'	=> '默认日期格式（短格式）',
		'output'		=> '输出',
		'charset'		=> '字符集',
		'charsettip'	=> '撰写博客的字符编码 (UTF-8 '.
						'<a href="http://wiki.flatpress.org/doc:charsets">为推荐编码</a>)'
		);
		
	$lang['admin']['config']['default']['msgs'] = 
	array(
		1		=> '配置保存成功。',
		-1		=> '保存配置时出错。',
		
		);
			
	$lang['admin']['config']['default']['error'] = 
	array(
		'www' 		=>	'博客的绝对地址必须是有效链接。',
		'title'		=>	'必须设置博客标题',
		'email'		=>	'Email 格式必须正确。',
		'maxentries'=>	'最大文章数设置无效。',
		'timeoffset'=>	'标准时间差设置无效。'.
						'请使用小数点表示 (例如 2h30"(2小时30分) => 2.5)',
		'timeformat'=>	'请指定时间格式掩码',
		'dateformat'=>	'请指定日期格式掩码',
		'dateformatshort'=>	'请指定日期格式掩码(短日期格式)',
		'charset'	=>	'请指定系统的字符编码',
		'lang'		=>	'您所选择的语言不可用'
		);		
			
		
?>
