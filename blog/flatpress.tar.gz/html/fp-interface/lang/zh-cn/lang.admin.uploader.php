<?php


	$lang['admin']['uploader']['default'] = array(
		'head'		=> '文件上传',
		'descr'		=> '选择一个或多个文件进行上传。',
		'fset1'		=> '选择文件',
		'fset2'		=> '上传',
		'submit'	=> '上传',

	);

	$lang['admin']['uploader']['default']['msgs'] = array(
		1	=> '文件上传成功',
		-1	=> '文件上传中发生错误。',
	);
	
	
	
	$lang['admin']['uploader']['browse'] = array(
		'head'		=> '浏览',
		'descr'		=> '选择一个或多个文件.',
		'fset1'		=> '选择文件',
		'submit'	=> '上传',

	);

	
?>
