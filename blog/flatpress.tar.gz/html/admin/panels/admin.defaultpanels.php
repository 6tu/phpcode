<?php

	admin_addpanel('main');
	
	admin_addpanel('entry');
	
	

	admin_addpanel('static');

	admin_addpanel('uploader');

	admin_addpanel('widgets');
	
	//admin_addpanel('users');
	admin_addpanel('plugin'	);
	admin_addpanel('themes');	
	
	admin_addpanel('config');

	admin_addpanel('maintain');
	
	
?>
