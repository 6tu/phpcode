<?php
	$lang['plugin']['thumb']['errors'] = array (
		-1	=> 'Could not find '.
			'<a href="http://www.php.net/manual/en/ref.image.php">PHP GD2 extension</a> ' .
			'required for <strong>thumb</strong> to work. Please disable thumb from this panel ' .
			'or enable this extension'
	);
?>