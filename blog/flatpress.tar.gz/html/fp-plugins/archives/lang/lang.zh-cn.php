<?php
	$lang['plugin']['archives'] = array(
		
		'subject'			=> '文章存档',
		'no_posts'		=> '无文章',
	
	);

?>
