<?php

	$lang['plugin']['categories'] = array(
		
		'subject'	=> '分类'
	
	);

?>