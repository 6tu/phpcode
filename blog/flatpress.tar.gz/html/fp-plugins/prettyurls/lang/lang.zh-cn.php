<?php
	$lang['plugin']['prettyurls']['errors'] = array (
		-2	=> '无法在您的根目录中创建 <code>.htaccess</code> 文件。'.
				'PrettyURLs 可能无法正常工作，请检查插件控制面板。'
	);
	
	$lang['admin']['plugin']['submenu']['prettyurls'] = 'PrettyURLs 设置';
	$lang['admin']['plugin']['prettyurls'] = array(
		'head'		=> 'PrettyURLs 设置',
		'htaccess'	=> '.htaccess',
		'description'=>'此代码窗口可以编辑您的 '.
						'<code><a class="hint" href="http://wiki.flatpress.org/doc:plugins:prettyurls#htaccess">.htaccess</a></code>.',
		'cantsave'	=> '您无法编辑此文件，因为，此文件 <strong>无法写入</strong>。 您可以设置写权限或将代码复制粘贴成文件再上传至服务器中。<a class="hint" href="http://wiki.flatpress.org/doc:plugins:prettyurls#manual_upload">详见</a>',
		'mode'		=> '模式',
		'auto'		=> '自动',
			'autodescr'	=> '自动判断最佳模式',
		'pathinfo'	=> '路径信息',
			'pathinfodescr' => '例如 /index.php/2011/01/01/hello-world/',
		'httpget'	=> 'HTTP Get',
			'httpgetdescr'=> '例如 /?u=/2011/01/01/hello-world/',
		'pretty'	=> '链接美化',
			'prettydescr'=> '例如 /2011/01/01/hello-world/',

		'saveopt' 	=> '保存设置',

		'submit'	=> '保存 .htaccess'
	);
	$lang['admin']['plugin']['prettyurls']['msgs'] = array(
		1		=> '.htaccess 保存成功',
		-1		=> '.htaccess 保存失败 (请检查您的 <code>'. BLOG_ROOT .'</code> 是否有写权限)?',

		2		=> '设置保存成功',
		-2		=> '保存设置时出错。',
	);
	
?>
