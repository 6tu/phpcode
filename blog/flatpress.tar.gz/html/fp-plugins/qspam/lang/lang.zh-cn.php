<?php

$lang['plugin']['qspam'] = array(
	'error' => '错误: 评论中含有受限词汇'
);

$lang['admin']['plugin']['submenu']['qspam'] = 'QuickSpamFilter';
$lang['admin']['plugin']['qspam'] = array(
	'head' => 'QuickSpam 设置',
	'desc1' => '禁止评论中出现如下字眼 (每行一个) :',
	'desc2' => '<strong>警告:</strong> 字符过滤将禁止任何含有关键词的评论， 
	
	(例如 "old" 会同时过滤 "b<em>old</em>" )',
	'options' => '其他选项',
	'desc3' => '过滤阀值',
	'desc3pre' => '过滤含有超过 ',
	'desc3post' => ' 个关键词的评论。',
	'submit' => '保存设置',
	'msgs' => array(
		1 => '受限关键词列表保存成功。',
		-1 => '受限关键词列表保存失败。'
	)
);

?>
