<?php

	$lang['plugin']['adminarea'] = array(
		
		'subject'		=> '管理面板',
		'welcome'		=> '欢迎归来, ',
		'admin_panel'	=> '主面板',
		'add_entry'		=> '新建博客文章',
		'add_static'	=> '新建静态页面',
		'logout'		=> '退出'
	
	);

?>