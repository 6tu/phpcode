<?php

	$lang['plugin']['calendar'] = array(
		
		'subject'	=> 'Calendar'
	
	);

?>