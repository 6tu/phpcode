<?php

	$lang['plugin']['calendar'] = array(
		
		'subject'	=> '日历'
	
	);

?>