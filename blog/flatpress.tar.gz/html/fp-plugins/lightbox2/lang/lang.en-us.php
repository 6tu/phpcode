<?php
	$lang['plugin']['lightbox']['errors'] = array (
		-1	=> 'This plugin require jsUtils to be loaded. Maybe plugins have been loaded in wrong order'
	);
?>