<?php
	$lang['plugin']['lightbox']['errors'] = array (
		-1	=> '此插件需要 jsUtils 才能载入。也可能是插件的载入顺序有问题。'
	);
?>