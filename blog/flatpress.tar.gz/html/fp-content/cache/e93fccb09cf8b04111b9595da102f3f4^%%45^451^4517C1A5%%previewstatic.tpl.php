<?php /* Smarty version 2.6.26, created on 2017-03-08 14:07:41
         compiled from previewstatic.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('block', 'static', 'previewstatic.tpl', 1, false),array('modifier', 'date_format', 'previewstatic.tpl', 4, false),)), $this); ?>
			<?php $this->_tag_stack[] = array('static', array('content' => $this->_tpl_vars['entry'])); $_block_repeat=true;smarty_block_static($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>
			<div class="entry">
				<h3><?php echo $this->_tpl_vars['subject']; ?>
</h3>
				<p class="date">Published by <?php echo $this->_tpl_vars['author']; ?>
 on <?php echo ((is_array($_tmp=$this->_tpl_vars['date'])) ? $this->_run_mod_handler('date_format', true, $_tmp, $this->_tpl_vars['fp_config']['locale']['dateformat']) : theme_date_format($_tmp, $this->_tpl_vars['fp_config']['locale']['dateformat'])); ?>
 </p>
				<?php echo $this->_tpl_vars['content']; ?>

			</div>
			<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_static($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>
