<?php /* Smarty version 2.6.26, created on 2017-03-08 14:05:42
         compiled from plugin:blockparser/admin.plugin.blockparser */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('block', 'static_block', 'plugin:blockparser/admin.plugin.blockparser', 5, false),array('block', 'static', 'plugin:blockparser/admin.plugin.blockparser', 18, false),array('modifier', 'in_array', 'plugin:blockparser/admin.plugin.blockparser', 20, false),array('modifier', 'action_link', 'plugin:blockparser/admin.plugin.blockparser', 27, false),array('modifier', 'cmd_link', 'plugin:blockparser/admin.plugin.blockparser', 34, false),)), $this); ?>
<h2><?php echo $this->_tpl_vars['plang']['head']; ?>
</h2>
<p><?php echo $this->_tpl_vars['plang']['description']; ?>
</p>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "shared:errorlist.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $this->_tag_stack[] = array('static_block', array()); $_block_repeat=true;smarty_block_statics($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>

<form method="post"
	action="<?php echo @BLOG_BASEURL; ?>
admin.php?p=entry"
	enctype="multipart/form-data">
	
<table class="entrylist">
<thead>
<tr>
<th><?php echo $this->_tpl_vars['plang']['id']; ?>
</th>
<th><?php echo $this->_tpl_vars['panelstrings']['title']; ?>
</th>
<th><?php echo $this->_tpl_vars['panelstrings']['action']; ?>
</th></tr></thead>
<tbody>
<?php $this->_tag_stack[] = array('static', array()); $_block_repeat=true;smarty_block_static($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>

	<?php $this->assign('inarr', ((is_array($_tmp=$this->_tpl_vars['id'])) ? $this->_run_mod_handler('in_array', true, $_tmp, $this->_tpl_vars['enabledlist']) : in_array($_tmp, $this->_tpl_vars['enabledlist']))); ?>
	<tr<?php if ($this->_tpl_vars['inarr']): ?> class="enabled" <?php endif; ?>>
		<td> <?php echo $this->_tpl_vars['id']; ?>
 </td>
		<td class="main-cell"> <?php echo $this->_tpl_vars['subject']; ?>
 </td>
		<td>
			<a 
			class="link-general" 
			href="<?php echo ((is_array($_tmp="?p=static")) ? $this->_run_mod_handler('action_link', true, $_tmp, 'write') : admin_filter_action($_tmp, 'write')); ?>
&amp;page=<?php echo $this->_tpl_vars['id']; ?>
">
			<?php echo $this->_tpl_vars['panelstrings']['edit']; ?>

			</a>
			
			<?php if ($this->_tpl_vars['inarr']): ?> 
			
			<a class="link-disable"
			href="<?php echo ((is_array($_tmp=$this->_tpl_vars['action_url'])) ? $this->_run_mod_handler('cmd_link', true, $_tmp, 'disable', $this->_tpl_vars['id']) : admin_filter_command($_tmp, 'disable', $this->_tpl_vars['id'])); ?>
"> 
				<?php echo $this->_tpl_vars['panelstrings']['disable']; ?>

			</a> 
			<?php else: ?>
			<a class="link-enable" 
			href="<?php echo ((is_array($_tmp=$this->_tpl_vars['action_url'])) ? $this->_run_mod_handler('cmd_link', true, $_tmp, 'enable', $this->_tpl_vars['id']) : admin_filter_command($_tmp, 'enable', $this->_tpl_vars['id'])); ?>
"> 
				<?php echo $this->_tpl_vars['panelstrings']['enable']; ?>

			</a> 
			<?php endif; ?>
		</td>
	</tr>

<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_static($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>
</tbody></table>
</form>

<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_statics($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>
