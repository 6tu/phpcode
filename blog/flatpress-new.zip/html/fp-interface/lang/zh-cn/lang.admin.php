<?php

	$lang['admin']['head'] = '管理面板';
	
	$lang['admin']['panels'] = array(
		'main'		=> '主面板',
		'config'	=> '参数设置',
		//'users'		=> 'Users',
		'entry'		=> '文章管理',
		'static'	=> '静态页面',
		'uploader'	=> '上传文件',
		'widgets'	=> '版面管理',
		//'add'		=> 'Add',
		//'edit'		=> 'Edit/Delete',
		'maintain'	=> '维护工具',
		'plugin'	=> '插件管理',
		'themes'	=> '主题管理',
		//'updates'	=> 'Updates',
	);
	
	
	$lang['admin']['general'] = array(
		'id'		=> 'ID',	# for entry ids
		'name'		=> '文件名', 	# for file names
		'title'		=> '标题', # for entry/posts/static titles
		'comments'	=> '#评论',
		'author'	=> '作者',
		'actdel'	=> '删除',
		'actedit'	=> '编辑',
		'actenable'	=> '启用',
		'actdisable'=> '禁用'
	);

?>
