<h2><?php echo $l['head']; ?></h2>
<div class="post">

<?php echo wpautop(sprintf($l['descr'], BLOG_BASEURL, BLOG_BASEURL . 'login.php')); ?>

</div>