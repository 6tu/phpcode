<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>Flatpress installer</title>
		<link href="setup/res/setup.css" type="text/css" rel="stylesheet" /></head>
<body>
	<div id="rap">
		<h1 id="header">FlatPress Installer (experimental)</h1>
		</div>

		<div id="main">
		
	
<form class="storycontent" method="post" action="<?php echo BLOG_BASEURL ?>setup.php"> 