<?php
	$lang['plugin']['lightbox']['errors'] = array (
		-1	=> 'Questo plugin necessita di jsUtils per essere abilitato. Forse i plugin sono stati abilitati nell\'ordine sbagliato.'
	);
?>