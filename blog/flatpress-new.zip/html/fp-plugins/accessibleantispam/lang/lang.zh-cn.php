<?php

$lang['plugin']['accessibleantispam'] = array(
		
	'prefix'	=> '为了消除垃圾评论，'.
		'请回答 ',
		
	'sum'		=> '%s ╋ %s ﹦?',
	'sub'		=> '%1$s ─ %2$s﹦?',
	'prod'		=> '%s ╳ %s ＝?',
		
	'error'		=> '抱歉，您的回答错误。'
	
	);

