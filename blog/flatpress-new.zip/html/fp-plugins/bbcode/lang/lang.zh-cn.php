<?php

$lang['admin']['plugin']['submenu']['bbcode'] = 'BBCode';
$lang['admin']['plugin']['bbcode'] = array(
	'head' => 'BBCode 设置',
	'desc1' => '本插件使用 <a href="http://www.phpbb.com/'.
		'phpBB/faq.php?mode=bbcode">BBCode</a> 语法，并能与 '.
		'lightbox(如果启用) 自动整合。',
	
	'options' => '设置',

	'editing'	=> '编辑',
	'allow_html'=> '内嵌 HTML',
	'allow_html_long' => '允许在 BBCode中使用 HTML',
	'toolbar' => '工具栏',
	'toolbar_long' => '启用编辑器工具栏。',

	'other'	=>	'其他选项',
	'comments' => '评论',
	'comments_long' => '允许评论中使用 BBCode',
	'urlmaxlen' => 'URL 长度限制',
	'urlmaxlen_long_pre' => '缩短URL，如果长度大于 ',
	'urlmaxlen_long_post'=>' 字符。',
	'submit' => '保存设置',
	'msgs' => array(
		1 => 'BBCode 设置保存成功。',
		-1 => 'BBCode 保存失败。'
	),

	'editor' => array(
		'formatting'     => '格式',
		'textarea'       => '编辑框: ',
		'expand'         => '扩大',
		'expandtitle'    => '增加编辑框高度',
		'reduce'         => '缩小',
		'reducetitle'    => '缩小编辑框高度',
		// note: accesskeys are not internationalized...
		// btw. why not :-D
		'bold'           => 'B',
		'boldtitle'      => '加粗',
		'italic'         => 'I',
		'italictitle'    => '斜体',
		'underline'      => 'U',
		'underlinetitle' => '下划线',
		'quote'          => '引用',
		'quotetitle'     => '引用',
		'code'           => '代码',
		'codetitle'      => '代码',
		'help'           => 'BBCode 帮助',
		// currently not used
		'status'         => '状态栏',
		'statusbar'      => '正常模式。按 &lt;Esc&gt; 键切换至编辑模式。'
	)
);

?>
