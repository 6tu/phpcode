<?php
	$lang['plugin']['akismet']['errors'] = array (
		-1	=> '您还没有设定 API Key。请到插件面板中设置您的 API key。API Key的注册申请请到 <a href="http://wordpress.com">Wordpress.com</a> '
	);
	
	$lang['admin']['plugin']['submenu']['akismet'] = 'Akismet 配置';
	
	$lang['admin']['plugin']['akismet'] = array(
		'head'		=> 'Akismet 配置',
		'description'=>'<a href="http://akismet.com/">Akismet</a> 可以帮助很多用户极大限度的降低 '
					 .'甚至完全消除垃圾您网站上的评论和 trackback 。'
					 .'如果您没有 WordPress.com 账户，您可以到 '.
					 '<a href="http://wordpress.com/api-keys/">WordPress.com</a> 注册。',
		'apikey'	=> 'WordPress.com API Key',
		'whatis'	=> '(<a href="http://faq.wordpress.com/2005/10/19/api-key/">这是什么?</a>)',
		'submit'	=> '保存 API key'
	);
	$lang['admin']['plugin']['akismet']['msgs'] = array(
		1		=> 'API key 保存成功',
		-1		=> 'API key 无效'
	);
	
?>