<?php

	$lang['plugin']['lastentries'] = array(
		
		'subject_before_count'	=> '最近 ',
		'subject_after_count'	=> ' 篇文章',
		'edit'			=> '编辑',
		'add_entry'		=> '新建文章',
		'no_entries'	=> '无文章'
	
	
	);

?>
