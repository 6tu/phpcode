<?php
	$lang['plugin']['thumb']['errors'] = array (
		-1	=> '未发现 <strong>thumb</strong> 略缩图插件所需的 '.
			'<a href="http://www.php.net/manual/en/ref.image.php">PHP GD2 扩展</a> '.
			'。请从此面板中禁用略缩图，'.
			'或想办法启用PHP的 GD2 扩展。'
	);
?>