<?php

	$lang['plugin']['categories'] = array(
		
		'subject'	=> 'Categories'
	
	);

?>