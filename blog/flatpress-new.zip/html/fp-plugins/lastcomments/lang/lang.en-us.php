<?php
	// cimangi Aggiunta traduzione stringhe
	$lang['plugin']['lastcomments'] = array(
		
		'last'				=> 'Last',
		'comments'			=> 'comments',
		'no_comments'		=> 'No comments',
		'no_new_comments'	=> 'No new comments'
		
	);

?>