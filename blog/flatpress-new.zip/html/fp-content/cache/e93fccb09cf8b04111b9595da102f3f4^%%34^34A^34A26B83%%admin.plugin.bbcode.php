<?php /* Smarty version 2.6.26, created on 2017-03-17 09:28:15
         compiled from plugin:bbcode/admin.plugin.bbcode */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('block', 'html_form', 'plugin:bbcode/admin.plugin.bbcode', 6, false),)), $this); ?>
<h2><?php echo $this->_tpl_vars['plang']['head']; ?>
</h2>
<p><?php echo $this->_tpl_vars['plang']['desc1']; ?>
</p>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "shared:errorlist.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<?php $this->_tag_stack[] = array('html_form', array('class' => "option-set")); $_block_repeat=true;smarty_block_html_form($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>
<h2><?php echo $this->_tpl_vars['plang']['editing']; ?>
</h2>

<dl class="option-list">
	<dt><label for="bb-escape-html">
		<?php echo $this->_tpl_vars['plang']['allow_html']; ?>

	</label></dt>
	<dd> 
		<p><input type="checkbox" name="bb-allow-html" id="bb-allow-html" <?php if ($this->_tpl_vars['bbchecked'][0]): ?>checked="checked"<?php endif; ?> /> 
		<?php echo $this->_tpl_vars['plang']['allow_html_long']; ?>
</p>
	</dd>

	<dt><label for="bb-toolbar">
		<?php echo $this->_tpl_vars['plang']['toolbar']; ?>

	</label></dt>
	<dd> 
		<p><input type="checkbox" name="bb-toolbar" id="bb-toolbar" <?php if ($this->_tpl_vars['bbchecked'][2]): ?>checked="checked"<?php endif; ?> />
		<?php echo $this->_tpl_vars['plang']['toolbar_long']; ?>
</p>
	</dd>

</dl>
		

<h2><?php echo $this->_tpl_vars['plang']['other']; ?>
</h2>

<dl class="option-list">
	<dt><label for="bb-comments">
		<?php echo $this->_tpl_vars['plang']['comments']; ?>

	</label></dt>
	<dd> 
		<p><input type="checkbox" name="bb-comments" id="bb-comments" <?php if ($this->_tpl_vars['bbchecked'][1]): ?>checked="checked"<?php endif; ?> />
		<?php echo $this->_tpl_vars['plang']['comments_long']; ?>
 </p>
	</dd>

	<dt><label for="bb-urlmaxlen">
		<?php echo $this->_tpl_vars['plang']['urlmaxlen']; ?>

	</label></dt>
	<dd> 
		<p><?php echo $this->_tpl_vars['plang']['urlmaxlen_long_pre']; ?>

		<input type="text" name="bb-maxlen" size="3" value="<?php echo $this->_tpl_vars['bbconf']['number']; ?>
">
		<?php echo $this->_tpl_vars['plang']['urlmaxlen_long_post']; ?>
</p>
	</dd>

</dl>
		

	<label>
		<?php echo $this->_tpl_vars['plang']['opn4pre']; ?>

		
		<?php echo $this->_tpl_vars['plang']['opn4post']; ?>

	</label>
<p class="buttonbar">
	<input type="submit" name="bb-conf" value="<?php echo $this->_tpl_vars['plang']['submit']; ?>
"/>
</p>
<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_html_form($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>