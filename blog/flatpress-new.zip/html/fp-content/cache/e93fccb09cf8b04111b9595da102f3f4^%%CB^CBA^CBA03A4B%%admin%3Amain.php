<?php /* Smarty version 2.6.26, created on 2017-03-08 14:04:07
         compiled from admin:main/ */ ?>
<h2><?php echo $this->_tpl_vars['panelstrings']['head']; ?>
</h2>
<p><?php echo $this->_tpl_vars['panelstrings']['descr']; ?>
</p>
<dl>
	<dt class="admin-mainmenu-item">	
		<img src="<?php echo @ADMIN_DIR; ?>
imgs/newentry.png" class="alignleft" alt="<?php echo $this->_tpl_vars['panelstrings']['op1']; ?>
"
		title="<?php echo $this->_tpl_vars['panelstrings']['op1']; ?>
" />
		<a href="admin.php?p=entry&amp;action=write"><?php echo $this->_tpl_vars['panelstrings']['op1']; ?>
</a>
	</dt>
	<dd class="admin-icon-descr"><?php echo $this->_tpl_vars['panelstrings']['op1d']; ?>
</dd>
	
	<dt class="admin-mainmenu-item">
		<img src="<?php echo @ADMIN_DIR; ?>
imgs/entries.png" class="alignleft" alt="<?php echo $this->_tpl_vars['panelstrings']['op2']; ?>
"
		title="<?php echo $this->_tpl_vars['panelstrings']['op2']; ?>
" />
		<a href="admin.php?p=entry"><?php echo $this->_tpl_vars['panelstrings']['op2']; ?>
</a>
	</dt>
	<dd class="admin-icon-descr"><?php echo $this->_tpl_vars['panelstrings']['op2d']; ?>
</dd>
	
	<dt class="admin-mainmenu-item">
		<img src="<?php echo @ADMIN_DIR; ?>
imgs/widgets.png" class="alignleft" alt="<?php echo $this->_tpl_vars['panelstrings']['op3']; ?>
"
		title="<?php echo $this->_tpl_vars['panelstrings']['op3']; ?>
" />
		<a href="admin.php?p=widgets"><?php echo $this->_tpl_vars['panelstrings']['op3']; ?>
</a>
	</dt>
	<dd class="admin-icon-descr"><?php echo $this->_tpl_vars['panelstrings']['op3d']; ?>
</dd>
	
	<dt class="admin-mainmenu-item">
		<img src="<?php echo @ADMIN_DIR; ?>
imgs/plugins.png" class="alignleft" alt="<?php echo $this->_tpl_vars['panelstrings']['op4']; ?>
"
		title="<?php echo $this->_tpl_vars['panelstrings']['op4']; ?>
" />
		<a href="admin.php?p=plugin"><?php echo $this->_tpl_vars['panelstrings']['op4']; ?>
</a>
	</dt>
	<dd class="admin-icon-descr"><?php echo $this->_tpl_vars['panelstrings']['op4d']; ?>
</dd>
	
	<dt class="admin-mainmenu-item">
		<img src="<?php echo @ADMIN_DIR; ?>
imgs/config.png" class="alignleft" alt="<?php echo $this->_tpl_vars['panelstrings']['op5']; ?>
"
		title="<?php echo $this->_tpl_vars['panelstrings']['op5']; ?>
" />
		<a href="admin.php?p=config"><?php echo $this->_tpl_vars['panelstrings']['op5']; ?>
</a>
	</dt>
	<dd class="admin-icon-descr"><?php echo $this->_tpl_vars['panelstrings']['op5d']; ?>
</dd>
	
	<dt class="admin-mainmenu-item">
		<img src="<?php echo @ADMIN_DIR; ?>
imgs/maintain.png" class="alignleft" alt="<?php echo $this->_tpl_vars['panelstrings']['op6']; ?>
"
		title="<?php echo $this->_tpl_vars['panelstrings']['op6']; ?>
" />
		<a href="admin.php?p=maintain"><?php echo $this->_tpl_vars['panelstrings']['op6']; ?>
</a>
	</dt>
	<dd class="admin-icon-descr"><?php echo $this->_tpl_vars['panelstrings']['op6d']; ?>
</dd>
	
</dl>