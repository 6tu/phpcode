<?php

$user = array (
  'userid' => 'admin',
  'password' => '089396b5b931f3f439eb29d57c04cfbe',
  'www' => 'http://vpn.boypay.net/',
  'email' => 'admin@boypay.net',
);

?>