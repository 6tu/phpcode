<?php

$fp_widgets = array (
  'right' => 
  array (
    0 => 'adminarea',
    1 => 'categories',
    2 => 'archives',
    3 => 'lastentries',
    4 => 'searchbox',
  ),
);

?>