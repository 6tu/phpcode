<?php

$fp_plugins = array (
  0 => 'accessibleantispam',
  1 => 'adminarea',
  2 => 'akismet',
  3 => 'archives',
  4 => 'bbcode',
  5 => 'blockparser',
  6 => 'calendar',
  7 => 'categories',
  8 => 'favicon',
  9 => 'footnotes',
  10 => 'jquery',
  11 => 'lastcomments',
  12 => 'lastentries',
  13 => 'lightbox2',
  14 => 'postviews',
  15 => 'prettyurls',
  16 => 'qspam',
  17 => 'readmore',
  18 => 'searchbox',
  19 => 'thumb',
);

?>