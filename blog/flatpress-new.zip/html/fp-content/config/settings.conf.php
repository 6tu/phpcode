<?php

$fp_config = array (
  'general' => 
  array (
    'www' => 'https://boypay.net/',
    'title' => '要塞郡',
    'subtitle' => ' ',
    'footer' => '生活有度，人生添寿。',
    'author' => 'admin',
    'email' => 'admin@boypay.net',
    'startpage' => NULL,
    'maxentries' => '5',
    'notify' => true,
    'theme' => 'leggero',
    'style' => 'leggero',
    'blogid' => 'fp-c8776e0',
    'charset' => 'utf-8',
  ),
  'locale' => 
  array (
    'timeoffset' => '2',
    'timeformat' => '%H:%M:%S',
    'dateformat' => '%A, %B %e, %Y',
    'dateformatshort' => '%Y-%m-%d',
    'charset' => 'utf-8',
    'lang' => 'zh-cn',
  ),
  'plugins' => 
  array (
    'blockparser' => 
    array (
      'pages' => 
      array (
        0 => 'Menu',
        1 => 'about',
        2 => 'menu',
      ),
    ),
    'prettyurls' => 
    array (
      'mode' => 0,
    ),
    'bbcode' => 
    array (
      'escape-html' => true,
      'comments' => false,
      'editor' => true,
      'url-maxlen' => 100,
    ),
  ),
);

?>