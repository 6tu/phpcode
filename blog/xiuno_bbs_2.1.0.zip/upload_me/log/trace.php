

---------------------------------------------------------------------------------
<?php exit;?>
---------------------------------------------------------------------------------
/?ueditor-uploadimage-ajax-1.htm
POST:Array
(
    [upload\"-----------------------------7b4a6d158c9--] => 
)

SQL:Array
(
    [0] => SET names utf8, sql_mode=''
    [1] => SELECT * FROM bbs_runtime WHERE k='runtime' LIMIT 1
    [2] => SELECT * FROM bbs_group WHERE groupid='0' LIMIT 1
    [3] => SELECT * FROM bbs_online WHERE sid='5c803c7a1afcbdb8' LIMIT 1
    [4] => SELECT * FROM bbs_online WHERE sid='5c803c7a1afcbdb8' LIMIT 1
    [5] => INSERT INTO bbs_online SET sid='5c803c7a1afcbdb8',uid='0',username='',groupid='0',ip='2130706433',url='/?ueditor-uploadimage-ajax-1.htm',lastvisit='1378437339'
    [6] => SELECT * FROM bbs_runtime WHERE k='runtime' LIMIT 1
    [7] => UPDATE bbs_runtime SET k='runtime',v='{&quot;app_name&quot;:&quot;Xiuno BBS&quot;,&quot;timeoffset&quot;:&quot;+8&quot;,&quot;forum_index_pagesize&quot;:20,&quot;cookie_keeptime&quot;:86400,&quot;site_pv&quot;:100000,&quot;site_runlevel&quot;:0,&quot;threadlist_hotviews&quot;:200,&quot;seo_title&quot;:&quot;Xiuno BBS&quot;,&quot;seo_keywords&quot;:&quot;Xiuno BBS&quot;,&quot;seo_description&quot;:&quot;Xiuno BBS&quot;,&quot;search_type&quot;:&quot;title&quot;,&quot;china_icp&quot;:&quot;&quot;,&quot;app_copyright&quot;:&quot;\u00a9 2008-2010 \u79d1\u6280\u6709\u9650\u516c\u53f8&quot;,&quot;footer_js&quot;:&quot;&quot;,&quot;iptable_on&quot;:0,&quot;badword_on&quot;:0,&quot;online_hold_time&quot;:1800,&quot;onlines&quot;:2,&quot;posts&quot;:false,&quot;threads&quot;:false,&quot;users&quot;:2,&quot;todayposts&quot;:0,&quot;todayusers&quot;:0,&quot;cron_1_next_time&quot;:1378437551,&quot;cron_2_next_time&quot;:1378483200,&quot;newuid&quot;:0,&quot;newusername&quot;:&quot;&quot;,&quot;toptids&quot;:false,&quot;forumarr&quot;:{&quot;1&quot;:&quot;\u9ed8\u8ba4\u7248\u5757&quot;},&quot;forumaccesson&quot;:[],&quot;grouparr&quot;:{&quot;0&quot;:&quot;\u6e38\u5ba2\u7ec4&quot;,&quot;1&quot;:&quot;\u7ba1\u7406\u5458\u7ec4&quot;,&quot;2&quot;:&quot;\u8d85\u7ea7\u7248\u4e3b\u7ec4&quot;,&quot;4&quot;:&quot;\u7248\u4e3b\u7ec4&quot;,&quot;5&quot;:&quot;\u5b9e\u4e60\u7248\u4e3b\u7ec4&quot;,&quot;6&quot;:&quot;\u5f85\u9a8c\u8bc1\u7528\u6237\u7ec4&quot;,&quot;7&quot;:&quot;\u7981\u6b62\u7528\u6237\u7ec4&quot;,&quot;11&quot;:&quot;\u4e00\u7ea7\u7528\u6237\u7ec4&quot;,&quot;12&quot;:&quot;\u4e8c\u7ea7\u7528\u6237\u7ec4&quot;,&quot;13&quot;:&quot;\u4e09\u7ea7\u7528\u6237\u7ec4&quot;,&quot;14&quot;:&quot;\u56db\u7ea7\u7528\u6237\u7ec4&quot;,&quot;15&quot;:&quot;\u4e94\u7ea7\u7528\u6237\u7ec4&quot;}}',expiry='0' WHERE k='runtime' LIMIT 1
)

Array
(
    [bbs_sid] => 5c803c7a1afcbdb8
    [bbs_lastonlineupdate] => 1378437339
    [bbs_lastday] => 1378437285
)
 - 0.499


---------------------------------------------------------------------------------
<?php exit;?>
---------------------------------------------------------------------------------
/?ueditor-uploadimage-ajax-1.htm
POST:Array
(
    [upload\"-----------------------------7b4a6d158c9--] => 
)

SQL:Array
(
    [0] => SET names utf8, sql_mode=''
    [1] => SELECT * FROM bbs_runtime WHERE k='runtime' LIMIT 1
    [2] => SELECT * FROM bbs_group WHERE groupid='0' LIMIT 1
)

Array
(
    [bbs_sid] => 5c803c7a1afcbdb8
    [bbs_lastonlineupdate] => 1378437339
    [bbs_lastday] => 1378437285
)
 - 0.785


---------------------------------------------------------------------------------
<?php exit;?>
---------------------------------------------------------------------------------
/?ueditor-uploadimage-ajax-1.htm
POST:Array
(
    [upload\"-----------------------------7b4a6d158c9--] => 
)

SQL:Array
(
    [0] => SET names utf8, sql_mode=''
    [1] => SELECT * FROM bbs_runtime WHERE k='runtime' LIMIT 1
    [2] => SELECT * FROM bbs_group WHERE groupid='0' LIMIT 1
)

Array
(
    [bbs_sid] => 5c803c7a1afcbdb8
    [bbs_lastonlineupdate] => 1378437339
    [bbs_lastday] => 1378437285
)
 - 0.778


---------------------------------------------------------------------------------
<?php exit;?>
---------------------------------------------------------------------------------
/?ueditor-uploadimage-bbs_sid-e4149dd6a36f917d-bbs_auth-F0ABcX0V%2BRDgR8Lcz%252FA1qk8lRBFRtSUPjbJyekoFhraIUq3%2BuxKUE6HALkwqccz6-ajax-1.htm
POST:Array
(
    [upload\"-----------------------------7b4a6d158c9--] => 
)

SQL:Array
(
    [0] => SET names utf8, sql_mode=''
    [1] => SELECT * FROM bbs_runtime WHERE k='runtime' LIMIT 1
    [2] => SELECT * FROM bbs_group WHERE groupid='1' LIMIT 1
    [3] => SELECT * FROM bbs_online WHERE sid='e4149dd6a36f917d' LIMIT 1
    [4] => UPDATE bbs_online SET sid='e4149dd6a36f917d',uid='0',username='',ip='2130706433',groupid='0',url='/',lastvisit='1378437678' WHERE sid='e4149dd6a36f917d' LIMIT 1
    [5] => SELECT * FROM bbs_user WHERE uid='1' LIMIT 1
    [6] => SELECT MAX(aid) FROM bbs_attach
    [7] => INSERT INTO bbs_framework_maxid SET maxid='0', name='attach'
    [8] => UPDATE bbs_framework_maxid SET maxid=maxid+'1' WHERE name='attach' LIMIT 1
    [9] => UPDATE bbs_framework_count SET count = '1' WHERE name='attach' LIMIT 1
    [10] => SELECT * FROM bbs_attach WHERE fid='0' AND aid='1' LIMIT 1
    [11] => INSERT INTO bbs_attach SET fid='0',tid='0',pid='0',filesize='0',width='0',height='0',filename='',orgfilename='UEditor_snapScreen_tmp.jpg',filetype='image',dateline='1378437678',comment='',downloads='0',isimage='1',golds='0',uid='1',aid='1'
    [12] => UPDATE bbs_attach SET fid='0',tid='0',pid='0',filesize='3975',width='123',height='116',filename='000/000/3c1249cf024eb10e7914babd18da86e5.jpg',orgfilename='UEditor_snapScreen_tmp.jpg',filetype='image',dateline='1378437678',comment='',downloads='0',isimage='1',golds='0',uid='1',aid='1' WHERE fid='0' AND aid='1' LIMIT 1
)

Array
(
    [bbs_sid] => 5c803c7a1afcbdb8
    [bbs_lastonlineupdate] => 1378437678
    [bbs_lastday] => 1378437285
)
 - 0.868


---------------------------------------------------------------------------------
<?php exit;?>
---------------------------------------------------------------------------------
/?ueditor-uploadimage-bbs_sid-e4149dd6a36f917d-bbs_auth-F0ABcX0V%2BRDgR8Lcz%252FA1qk8lRBFRtSUPjbJyekoFhraIUq3%2BuxKUE6HALkwqccz6-ajax-1.htm
POST:Array
(
    [upload\"-----------------------------7b4a6d158c9--] => 
)

SQL:Array
(
    [0] => SET names utf8, sql_mode=''
    [1] => SELECT * FROM bbs_runtime WHERE k='runtime' LIMIT 1
    [2] => SELECT * FROM bbs_group WHERE groupid='1' LIMIT 1
    [3] => SELECT * FROM bbs_user WHERE uid='1' LIMIT 1
    [4] => UPDATE bbs_framework_maxid SET maxid=maxid+'1' WHERE name='attach' LIMIT 1
    [5] => UPDATE bbs_framework_count SET count = '2' WHERE name='attach' LIMIT 1
    [6] => SELECT * FROM bbs_attach WHERE fid='0' AND aid='2' LIMIT 1
    [7] => INSERT INTO bbs_attach SET fid='0',tid='0',pid='0',filesize='0',width='0',height='0',filename='',orgfilename='UEditor_snapScreen_tmp.jpg',filetype='image',dateline='1378437760',comment='',downloads='0',isimage='1',golds='0',uid='1',aid='2'
    [8] => UPDATE bbs_attach SET fid='0',tid='0',pid='0',filesize='3330',width='152',height='127',filename='000/000/43702c4e35ad8b99f083cc720d36b802.jpg',orgfilename='UEditor_snapScreen_tmp.jpg',filetype='image',dateline='1378437760',comment='',downloads='0',isimage='1',golds='0',uid='1',aid='2' WHERE fid='0' AND aid='2' LIMIT 1
)

Array
(
    [bbs_sid] => 5c803c7a1afcbdb8
    [bbs_lastonlineupdate] => 1378437678
    [bbs_lastday] => 1378437285
)
 - 0.711
