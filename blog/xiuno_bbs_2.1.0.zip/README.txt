【如何安装？】

1. 上传 upload 目录下所有文件
2. 设置如下目录和文件为可写
	./upload
	./tmp
	./log
	./conf

3. 访问 http://www.domain.com/install/, 根据提示安装 (http://www.domain.com/ 为您的网址)。