<head>
<title>VPS ʵʱ��� </title>

<table width=960>
<tr><td align="center" width=10>HiForMance</td><td><object style="border:0px" type="text/x-scriptlet" data="http://107.173.160.111/tz/vpsstate.php" width=960 height=160></object></td></tr>


</table>
</head>