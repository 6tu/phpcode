<?php
# http://www.helloweba.com/view-blog-253.html

$post['email'] = 'zhongxiaolee@gmail.com';
$post['password'] = 'qq0000000';

$cookie = tempnam('./', 'cookie');
$url = 'https://app.arukas.io/api/login';
$url2 = 'https://app.arukas.io/api/containers';
$header[] = 'Accept:application/vnd.api+json';
$header[] = 'Content-Type:application/vnd.api+json';
$login = login_post($url, $cookie, $post);
if(!strstr($login, 'OK')){
    echo '<br>��¼ʧ��';
    exit(0);
}
$result = get_content($url2, $cookie, $header);
unlink($cookie);
$arr = json_decode($result, true);
# for($i = 0;$i < count($arr['data']);$i++)print_r($arr['data'][$i]['attributes']['port_mappings']['0']);
$cmd = $arr['data']['0']['attributes']['cmd'];
$port = $arr['data']['0']['attributes']['port_mappings']['0']['0']['service_port'];
$host = $arr['data']['0']['attributes']['port_mappings']['0']['0']['host'];
$host = str_replace('-', '.', $host);
$host = explode('.', $host);
$ip = $host[1] . '.' . $host[2] . '.' . $host[3] . '.' . $host[4];
$cmd = explode(' ', $cmd);
$pw = $cmd[4];
$method = $cmd[6];
$ssqr = 'ss://' . base64_encode($method . ':' . $pw . '@' . $ip . ':' . $port) . '#arukas-01';

echo '<pre>' . "\r\n\r\n";
echo 'ss://' . $method . ':' . $pw . '@' . $ip . ':' . $port . "\r\n\r\n";
echo '{' . "\r\n";
echo '    "server":"' . $ip . '",' . "\r\n";
echo '    "server_port":' . $port . ',' . "\r\n";
echo '    "local_port":1080,' . "\r\n";
echo '    "password":"' . $pw . '",' . "\r\n";
echo '    "timeout":600,' . "\r\n";
echo '    "method":"' . $method . '",' . "\r\n";
echo '}' . "\r\n\r\n";

$PNG_TEMP_DIR = dirname(__FILE__) . DIRECTORY_SEPARATOR . 'qr\temp' . DIRECTORY_SEPARATOR;
$PNG_WEB_DIR = 'qr/temp/';
if(!file_exists($PNG_TEMP_DIR))mkdir($PNG_TEMP_DIR);
$filename = $PNG_TEMP_DIR . 'test.png';
$errorCorrectionLevel = 'H'; //array('L','M','Q','H')
$matrixPointSize = '4'; //array(1~10)
include './qr/qrlib.php';
if(isset($ssqr)){
    if(trim($ssqr) == '')die('data can not be empty! <a href="?" >back</a>');
    $filename = $PNG_TEMP_DIR . md5($ssqr . '|' . $errorCorrectionLevel . '|' . $matrixPointSize) . '.png';
    QRcode :: png($ssqr, $filename, $errorCorrectionLevel, $matrixPointSize, 2);
}
echo '<img src="' . $PNG_WEB_DIR . basename($filename) . '"/>';

function login_post($url, $cookie, $post){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
    $result = curl_exec($ch);
    curl_close($ch);
    return$result;
}
function get_content($url, $cookie, $header){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
    $result = curl_exec($ch);
    curl_close($ch);
    return$result;
}
?>