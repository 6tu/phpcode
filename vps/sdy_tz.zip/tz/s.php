<?php
echo "<pre>\r\n";
print_r($_SERVER);