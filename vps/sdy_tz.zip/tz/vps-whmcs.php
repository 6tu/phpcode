<?php
# 母鸡数据更新在罗马尼亚时间上午9点，把时间向前推9+个小时
# 洛杉矶时区同布加勒斯特相差10小时。这样方便条件判断

date_default_timezone_set('Europe/Bucharest');   # 罗马尼亚时间
$t0 = date('ymdHis',time());
date_default_timezone_set("America/Los_Angeles");# 洛杉矶时间
$t1 = date('ymdHis',time());
// echo "Bucharest: $t0 - Los_Angeles: $t1";
$log_dir = './log/';
if(!is_dir($log_dir)) mkdir($log_dir,0777);
$log = $log_dir . 'vps-' . date('ymd',time()) . '.log';
$log = $log_dir . 'vps-190520.log';
if (file_exists($log)) {
    echo file_get_contents($log);
    exit;
}

$url = 'https://servercheap.net/crm';
$dologin = $url . '/dologin.php';
$clientarea = $url . '/clientarea.php';
$details = $clientarea . '?action=productdetails&id=2166&rrd=0&timeframe=hour&language=chinese';

$cookie_dir = './cookie/';
if(!is_dir($cookie_dir)) mkdir($cookie_dir,0777);
$cookie_file = $cookie_dir . time() . '.cookie';
setcookie("PHPSESSID", "vc0heoa6lfsi3gger54pkns152");
$token = getResponse($clientarea, [], $cookie_file);
preg_match('/<input type="hidden" name="token" value="(.*)"/U', $token, $match);
// print_r($match);
$post['token'] = $match[1];
$post['username'] = 'zhongxiaolee@gmail.com';
$post['password'] = 'password';

$login = getResponse($dologin, $post, $cookie_file);
$pd = getResponse($details, $data=[], $cookie_file);

unlink($cookie_file);

# 数据索取完毕

# 删除js
$preg = "/<script[\s\S]*?<\/script>/i";
$html = preg_replace($preg, "", $pd, -1);

unset($pd);

# 提取需要的部分
$pd_array1 = explode('<div class="product-details clearfix">' , $html);
$tmp = mb_substr($pd_array1[1],0,770,'utf8');
$tmp1 = '<div class="product-details clearfix">' . $tmp . "</div></div></div></div></div>\r\n";

$pd_array2 = explode('<div class="module-header">' , $html);
$tmp = mb_substr($pd_array2[1],0,5110,'utf8');
$tmp = str_replace('<strong>' , "<b>" , $tmp);
$tmp = str_replace('</strong>' , "</b>" , $tmp);
$tmp2 = '<br><div class="module-header">' . $tmp;

$pd_array3 = explode('end Disbale resource usage -->' , $html);
$tmp = mb_substr($pd_array3[1],0,2850,'utf8');
$tmp = str_replace('<strong>' , "\r\n<br><strong>" , $tmp);
$tmp3 = '<br><hr/><br>' . $tmp;

$tmp = $tmp1. $tmp2 .$tmp3;

# 删除冗余
$tmp = preg_replace("/(\r\n|\n|\r|\t)/i", '', $tmp);
$tmp = preg_replace ("/\s(?=\s)/", "\\1", $tmp);
$tmp = str_replace(array(' <', '> '), array('<', '>'), $tmp);
$tmp = str_replace('</td></tr><tr><td>' , "</td></tr>\r\n<br><tr><td>" , $tmp);

//$tmp = trim($tmp);
$tmp = str_replace('<h3', "\r\n<br><b><h3", $tmp);
$tmp = str_replace('</h3>', "</h3></b>\r\n<br>", $tmp);
$tmp = str_replace('<p', "\r\n<br><b><p", $tmp);
$tmp = str_replace('</p>', "</p></b>\r\n<br><br>", $tmp);



$tmp = strip_tags($tmp, '<hr><h4><b><br><tr><td><strong><table>');

$tmp = str_replace(array('</strong>','<strong>') , array(" --> ", "  \r\n") , $tmp);
$tmp = str_replace(array('<tr><td>','</td><td>','</td></tr>'), array('',' --> ',"<br>\r\n"), $tmp);
$tmp = strip_tags($tmp, '<hr><b><br>');

$tmp = str_replace("<br>\r\n", '', $tmp);
$tmp = str_replace("<hr/>", "\r\n", $tmp);
$tmp = str_replace("<b>Billing", "<br><b>Billing", $tmp);
$tmp = str_replace("Details", "", $tmp);
$tmp = str_replace('<br>', "\r\n", $tmp);
$tmp = str_replace("\r\n  \r\n", "\r\n", $tmp);
$tmp = str_replace("\r\n\r\n", "\r\n", $tmp);
$tmp = str_replace("可用</b>", "</b>\r\n", $tmp);
$tmp = str_replace("∞", " ∞ ", $tmp);




$head = "<!DOCTYPE html>\r\n<html>\r\n<head>\r\n<meta charset=\"utf-8\"/>\r\n";
$head .= "<title>Servercheap.NET - 客戶中心</title>\r\n</head>\r\n<body>\r\n";
        
$html = $head . "<pre>\r\n".$tmp . "\r\n\r\n</body>\r\n</html>";
$html = beautify_html($html);





# 繁体转简体
// define("MEDIAWIKI_PATH", "/var/www/zhtools/mediawiki-1.13.3/");
// require_once "../zhtools/mediawiki-zhconverter.inc.php";
// $html = MediaWikiZhConverter::convert($html, "zh-hans");
// header("Content-type: text/html; charset=utf-8");
// echo '<style type="text/css">body,select,textarea {font-size:1.1em}body, html,input{font-family:"SimSun";}</style>';
echo $html;
file_put_contents($log, $html . "\r\n\r\n$t0" . '[Bucharest]');







function getResponse($url, $data = [], $cookie_file = '', $timeout = 10){
    if(empty($cookie_file)){
        $cookie_file = '.cookie';
    }
    $url_array = parse_url($url);
    $host = $url_array['scheme'] . '://' . $url_array['host'];
    if(!empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) $lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
    else $lang = 'zh-CN,zh;q=0.9';
    if(!empty($_SERVER['HTTP_REFERER'])) $refer = $_SERVER['HTTP_REFERER'];
    else $refer = $host . '/clientarea.php?incorrect=true';
    if(!empty($_SERVER['HTTP_USER_AGENT'])) $agent = $_SERVER['HTTP_USER_AGENT'];
    else $agent = 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.67 Safari/537.36';
    // echo $lang . "<br>\r\n" . $refer . "<br>\r\n" . $agent . "<br>\r\n";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_USERAGENT, $agent);
    curl_setopt($ch, CURLOPT_REFERER, $refer);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Accept-Language: " . $lang));
    if(!empty($data)){
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_file); # 取cookie的参数是
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file); # 发送cookie
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
    try{
        $handles = curl_exec($ch);
        curl_close($ch);
        return $handles;
    }
    catch(Exception $e){
        echo 'Caught exception:', $e -> getMessage(), "\n";
    }
}


# HTML 格式化
function beautify_html($html){
    $tidy_config = array(
        'clean' => false,
        'indent' => true,
        'indent-spaces' => 4,
        'output-xhtml' => false,
        'show-body-only' => false,
        'wrap' => 0
        );
    if(function_exists('tidy_parse_string')){ 
        $tidy = tidy_parse_string($html, $tidy_config, 'utf8');
        $tidy -> cleanRepair();
        return $tidy;
    }
    else return $html;
}

