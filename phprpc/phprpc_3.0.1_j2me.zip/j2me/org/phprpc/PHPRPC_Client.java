/**********************************************************\
|                                                          |
| The implementation of PHPRPC Protocol 3.0                |
|                                                          |
| PHPRPC_Client.java                                       |
|                                                          |
| Release 3.0.1                                            |
| Copyright (c) 2005-2008 by Team-PHPRPC                   |
|                                                          |
| WebSite:  http://www.phprpc.org/                         |
|           http://www.phprpc.net/                         |
|           http://www.phprpc.com/                         |
|           http://sourceforge.net/projects/php-rpc/       |
|                                                          |
| Authors:  Ma Bingyao <andot@ujn.edu.cn>                  |
|                                                          |
| This file may be distributed and/or modified under the   |
| terms of the GNU Lesser General Public License (LGPL)    |
| version 3.0 as published by the Free Software Foundation |
| and appearing in the included file LICENSE.              |
|                                                          |
\**********************************************************/

/* PHPRPC_Client class for J2ME.
 *
 * Copyright (C) 2005-2008 Ma Bingyao <andot@ujn.edu.cn>
 * Version: 3.0.1
 * LastModified: Sep 18, 2008
 * This library is free.  You can redistribute it and/or modify it.
 *
/*
 * Example usage:
 *
import org.phprpc.PHPRPC_Client;

public class Test
{
    public static void main(String[] args) {
        PHPRPC_Client rpc = new PHPRPC_Client("http://www.phprpc.org/server.php");
        rpc.setKeyLength(1024);
        rpc.setEncryptMode(2);
        System.out.println(rf.invoke("add", new Object[2]{new Integer(1), new Integer(2)});
        System.out.println(rf.invoke("add", new Object[2]{new Double(1.5), new Integer(2)});
    }
}
 * 
 */

package org.phprpc;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Random;
import java.security.DigestException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.microedition.io.Connector;
import javax.microedition.io.HttpConnection;
import org.phprpc.util.Base64;
import org.phprpc.util.BigInteger;
import org.phprpc.util.XXTEA;
import org.phprpc.util.Cast;
import org.phprpc.util.PHPSerializer;

public class PHPRPC_Client {
    protected PHPSerializer __phpser = null;
    private String __server = "";
    private PHPRPC_Error __warning = null;
    private byte[] __key = null;
    private int __keylen = 128;
    private int __encryptMode = 0;
    private Hashtable __cookies = new Hashtable();
    private String __cookie = null;
    private String __charset = "utf-8";
    private String __output = "";
    private double __version = 3.0;

    public PHPRPC_Client() {
    }

    public PHPRPC_Client(String serverURL) {
        useService(serverURL);
    }

    public final boolean useService(String serverURL) {
        __server = serverURL;
        __key = null;
        __keylen = 128;
        __encryptMode = 0;
        __cookies = new Hashtable();
        __cookie = null;
        __phpser = new PHPSerializer();
        setCharset("utf-8");
        return true;
    }

    public final boolean setKeyLength(int keyLength) {
        if (__key != null) {
            return false;
        }
        else {
            __keylen = keyLength;
            return true;
        }
    }

    public final int getKeyLength() {
        return __keylen;
    }

    public final boolean setEncryptMode(int encryptMode) {
        if ((encryptMode >= 0) && (encryptMode <= 3)) {
            __encryptMode = encryptMode;
            return true;
        }
        else {
            __encryptMode = 0;
            return false;
        }
    }

    public final int getEncryptMode() {
        return __encryptMode;
    }

    public final void setCharset(String charset) {
        __charset = charset;
        __phpser.setCharset(__charset);        
    }

    public final String getCharset() {
        return __charset;
    }

    public final String getOutput() {
        return __output;
    }

    public final PHPRPC_Error getWarning() {
        return __warning;
    }

    public final Object invoke(String function, Object[] args) {
        return invoke(function, args, false);
    }

    public final Object invoke(String function, Object[] args, boolean byRef) {
        try {
            __keyExchange();
            StringBuffer requestBody = new StringBuffer();
            requestBody.append("phprpc_func=").append(function);
            if (args != null && args.length > 0) {
                requestBody.append("&phprpc_args=");
                requestBody.append(replaceAll(Base64.encode(__encrypt(__phpser.serialize(args), 1)), '+', "%2B"));
            }
            requestBody.append("&phprpc_encrypt=").append(__encryptMode);
            if (!byRef) {
                requestBody.append("&phprpc_ref=false");
            }
            Hashtable result = __post(requestBody.toString());
            int errno = Integer.parseInt((String) result.get("phprpc_errno"));
            if (errno > 0) {
                String errstr = new String(Base64.decode((String) result.get("phprpc_errstr")), __charset);
                __warning = new PHPRPC_Error(errno, errstr);
            }
            else {
                __warning = null;
            }
            if (result.containsKey("phprpc_output")) {
                byte[] output = Base64.decode((String) result.get("phprpc_output"));
                if (__version >= 3) {
                    output = __decrypt(output, 3);
                }
                __output = new String(output, __charset);
            }
            else {
                __output = "";
            }
            if (result.containsKey("phprpc_result")) {
                if (result.containsKey("phprpc_args")) {
                    Object[] arguments = (Object[]) __phpser.unserialize(__decrypt(Base64.decode((String) result.get("phprpc_args")), 1), Object[].class);
                    for (int i = 0; i < Math.min(args.length, arguments.length); i++) {
                        args[i] = arguments[i];
                    }
                }
                return __phpser.unserialize(__decrypt(Base64.decode((String) result.get("phprpc_result")), 2));
            }
            else {
                return __warning;
            }
        }
        catch (PHPRPC_Error e) {
            return e;
        }
        catch (Throwable e) {
            return new PHPRPC_Error(1, e.toString());
        }
    }

    private final void __sendRequest(HttpConnection connection, String requestBody) throws IOException {
        byte[] rb = requestBody.getBytes();
        connection.setRequestMethod(HttpConnection.POST);
        connection.setRequestProperty("Connection", "close");
        connection.setRequestProperty("User-Agent", "PHPRPC Client 3.0 for J2ME");
        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=" + __charset);
        connection.setRequestProperty("Pragma", "no-cache");
        connection.setRequestProperty("Cache-Control", "no-cache");
        if (__cookie != null) {
            connection.setRequestProperty("Cookie", __cookie);
        }
        connection.setRequestProperty("Accept", "*/*");
        OutputStream os = connection.openOutputStream();
        os.write(rb);
        os.flush();
        os.close();
    }

    private final void __addCookie(String cookie) {
        int p = cookie.indexOf('=');
        String name, value;
        if (p > -1) {
            name = cookie.substring(0, p);
            value = cookie.substring(p + 1);
        }
        else {
            name = cookie;
            value = "";
        }
        if (!name.equals("domain") && !name.equals("expires") &&
            !name.equals("path") && !name.equals("secure")) {
            __cookies.put(name, value);
        }
    }

    private final String __readLine(InputStream is) throws IOException {
        StringBuffer sb = new StringBuffer();
        int c;
        while ((c = is.read()) > -1) {
            if (c == 13) {
                c = is.read();
                if (c != 10) {
                    throw new IOException();
                }
                else {
                    return sb.toString();
                }
            }
            else {
                sb.append((char) c);
            }
        }
        return sb.toString();
    }

    private final boolean __readCRLF(InputStream is) throws IOException {
        if (is.read() != 13) {
            return false;
        }
        if (is.read() != 10) {
            return false;
        }
        return true;
    }

    private final void __readResponseHeader(HttpConnection connection, String requestBody) throws IOException, PHPRPC_Error {
        __sendRequest(connection, requestBody);
        if (connection.getResponseCode() != connection.HTTP_OK) {
            throw new PHPRPC_Error(connection.getResponseCode(), connection.getResponseMessage());
        }
        int i = 0;
        String key, value;
        boolean hasCookie = false;
        __version = -1;
        while ((key = connection.getHeaderFieldKey(i)) != null) {
            key = key.toLowerCase();
            if (key.equals("x-powered-by")) {
                value = connection.getHeaderField(i);
                if (value.startsWith("PHPRPC Server/")) {
                    __version = Double.parseDouble(value.substring(14));
                }
            }
            if (key.equals("set-cookie")) {
                hasCookie = true;
                value = connection.getHeaderField(i);
                int p;
                while ((p = value.indexOf(';', 0)) >= 0) {
                    String cookie = value.substring(0, p);
                    value = value.substring(p + 1).trim();
                    __addCookie(cookie);
                }
                if (!value.equals("")) {
                    __addCookie(value);
                }
            }
            i++;
        }
        if (__version < 0) {
            throw new PHPRPC_Error(1, "Illegal PHPRPC server.");
        }
        if (hasCookie) {
            __cookie = "";
            for (Enumeration keys = __cookies.keys(); keys.hasMoreElements();) {
                key = (String) keys.nextElement();
                value = (String) __cookies.get(key);
                __cookie += key + "=" + value + "; ";
            }
        }
        String contentType = connection.getType();
        if (contentType.toLowerCase().startsWith("text/plain; charset=")) {
            setCharset(contentType.substring(20));
        }
    }
    
    private final Hashtable __parseBody(byte[] responseBodyByteArray) throws IOException, PHPRPC_Error {
        ByteArrayInputStream is = new ByteArrayInputStream(responseBodyByteArray);
        Hashtable result = new Hashtable();
        String buf;
        while (!(buf = __readLine(is)).equals("")) {
            int p = buf.indexOf('=');
            if (p > -1) {
                result.put(buf.substring(0, p), buf.substring(p + 2, buf.length() - 2));
            }
        }
        return result;
    }

    private final Hashtable __readResponseBody(HttpConnection connection) throws IOException, PHPRPC_Error {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        InputStream is = connection.openInputStream();
        String te = connection.getHeaderField("transfer-encoding");
        if (te != null && te.toLowerCase().equals("chunked")) {
            String s = __readLine(is);
            if (s.equals("")) {
                is.close();
                connection.close();
                return new Hashtable();
            }
            int n = Integer.parseInt(s, 16);
            while (n > 0) {
                byte[] b = new byte[n];
                int len;
                while (n > 0 && (len = is.read(b, 0, n)) > -1) {
                    baos.write(b, 0, len);
                    n -= len;
                }
                if (!__readCRLF(is)) {
                    is.close();
                    connection.close();
                    throw new PHPRPC_Error(1, "Response is incorrect.");
                }
                n = Integer.parseInt(__readLine(is), 16);
            }
            __readLine(is);
        }
        else if (connection.getLength() > 0) {
            int n = (int)connection.getLength();
            byte[] b = new byte[n];
            int len;
            while (n > 0 && (len = is.read(b, 0, n)) > -1) {
                baos.write(b, 0, len);
                n -= len;
            }
        }
        else {
            byte[] b = new byte[2048];
            int len;
            while ((len = is.read(b, 0, 2048)) > -1) {
                baos.write(b, 0, len);
            }
        }
        is.close();
        connection.close();
        return __parseBody(baos.toByteArray());
    }
    
    private final Hashtable __post(String requestBody) throws IOException, PHPRPC_Error {
        HttpConnection connection = (HttpConnection)Connector.open(__server, Connector.READ_WRITE, true);        
        Hashtable responseBody;
        try {
            __readResponseHeader(connection, requestBody);
            responseBody = __readResponseBody(connection);
        }
        catch (IOException e) {
            connection.close();
            throw e;
        }
        return responseBody;
    }
    
    private final void __keyExchange() throws IOException, IllegalAccessException, NoSuchAlgorithmException, DigestException, PHPRPC_Error {
        if (__key != null || __encryptMode == 0) return;
        Hashtable result = __post("phprpc_encrypt=true&phprpc_keylen=" + __keylen);
        if (result.containsKey("phprpc_keylen")) {
            __keylen = Integer.parseInt((String) result.get("phprpc_keylen"));
        }
        else {
            __keylen = 128;
        }
        if (result.containsKey("phprpc_encrypt")) {
            Hashtable encrypt = (Hashtable) __phpser.unserialize(Base64.decode((String) result.get("phprpc_encrypt")), Hashtable.class);
            BigInteger x = (new BigInteger(__keylen - 1, new Random())).setBit(__keylen - 2);
            BigInteger y = new BigInteger(Cast.toString(encrypt.get("y")));
            BigInteger p = new BigInteger(Cast.toString(encrypt.get("p")));
            BigInteger g = new BigInteger(Cast.toString(encrypt.get("g")));
            BigInteger k = y.modPow(x, p);
            byte[] key;
            if (__keylen == 128) {
                key = k.toByteArray();
                __key = new byte[16];
                for (int i = 1, n = Math.min(key.length, 16); i <= n; i++) {
                    __key[16 - i] = key[key.length - i];
                }
            }
            else {
                MessageDigest md5 = MessageDigest.getInstance("MD5");
                key = k.toString().getBytes();
                md5.update(key, 0, key.length);
                __key = new byte[16];
                md5.digest(__key, 0, __key.length);
            }
            __post("phprpc_encrypt=" + g.modPow(x, p).toString());
        }
        else {
            __key = null;
            __encryptMode = 0;
        }
    }

    private final byte[] __encrypt(byte[] s, int level) {
        if (__key != null && __encryptMode >= level) {
            s = XXTEA.encrypt(s, __key);
        }
        return s;
    }
    
    private final byte[] __decrypt(byte[] s, int level) {
        if (__key != null && __encryptMode >= level) {
            s = XXTEA.decrypt(s, __key);
        }
        return s;
    }
    
    private final String replaceAll(String s, char c, String r) {
        char[] cs = s.toCharArray();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < cs.length; i++) {
            if (cs[i] == c) {
                sb.append(r);
            }
            else {
                sb.append(cs[i]);
            }
        }
        return sb.toString();
    }    
}