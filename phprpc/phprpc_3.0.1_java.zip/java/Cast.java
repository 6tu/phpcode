/**********************************************************\
|                                                          |
| The implementation of PHPRPC Protocol 3.0                |
|                                                          |
| Cast.java                                                |
|                                                          |
| Release 3.0.1                                            |
| Copyright (c) 2005-2008 by Team-PHPRPC                   |
|                                                          |
| WebSite:  http://www.phprpc.org/                         |
|           http://www.phprpc.net/                         |
|           http://www.phprpc.com/                         |
|           http://sourceforge.net/projects/php-rpc/       |
|                                                          |
| Authors:  Ma Bingyao <andot@ujn.edu.cn>                  |
|                                                          |
| This file may be distributed and/or modified under the   |
| terms of the GNU Lesser General Public License (LGPL)    |
| version 3.0 as published by the Free Software Foundation |
| and appearing in the included file LICENSE.              |
|                                                          |
\**********************************************************/

/* Cast library.
 *
 * Copyright (C) 2005-2008 Ma Bingyao <andot@ujn.edu.cn>
 * Version: 3.0.1
 * LastModified: Feb 3, 2008
 * This library is free.  You can redistribute it and/or modify it.
 */

package org.phprpc.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;

public final class Cast {

    private Cast() {};

    static public byte[] getBytes(Object obj, String charset) {
        if (obj instanceof byte[]) {
            return (byte[])obj;
        }
        try {
            return obj.toString().getBytes(charset);
        }
        catch (Exception e) {
            return obj.toString().getBytes();
        }
    }

    static public byte[] getBytes(Object obj) {
        return getBytes(obj, "utf-8");
    }

    static public String toString(Object obj, String charset) {
        if (obj instanceof byte[]) {
            try {
                return new String((byte[]) obj, charset);
            }
            catch (Exception e) {
                return new String((byte[]) obj);
            }
        }
        else {
            return obj.toString();
        }
    }

    static public String toString(Object obj) {
        return toString(obj, "utf-8");
    }

    static public Object cast(Number n, Class destClass) {
        if (destClass == Byte.class || destClass == Byte.TYPE) {
            return new Byte(n.byteValue());
        }
        if (destClass == Short.class || destClass == Short.TYPE) {
            return new Short(n.shortValue());
        }
        if (destClass == Integer.class || destClass == Integer.TYPE) {
            return new Integer(n.intValue());
        }
        if (destClass == Long.class || destClass == Long.TYPE) {
            return new Long(n.longValue());
        }
        if (destClass == Float.class || destClass == Float.TYPE) {
            return new Float(n.floatValue());
        }
        if (destClass == Double.class || destClass == Double.TYPE) {
            return new Double(n.doubleValue());
        }
        if (destClass == Boolean.class || destClass == Boolean.TYPE) {
            return new Boolean(n.byteValue() != 0);
        }
        return n;
    }

    static public Object cast(String s, Class destClass, String charset) {
        if (destClass == char[].class) {
            return s.toCharArray();
        }
        if (destClass == byte[].class) {
            return getBytes(s, charset);
        }
        if (destClass == StringBuffer.class) {
            return new StringBuffer(s);
        }
        if (destClass == Byte.class || destClass == Byte.TYPE) {
            return new Byte(s);
        }
        if (destClass == Short.class || destClass == Short.TYPE) {
            return new Short(s);
        }
        if (destClass == Integer.class || destClass == Integer.TYPE) {
            return new Integer(s);
        }
        if (destClass == Long.class || destClass == Long.TYPE) {
            return new Long(s);
        }
        if (destClass == Float.class || destClass == Float.TYPE) {
            return new Float(s);
        }
        if (destClass == Double.class || destClass == Double.TYPE) {
            return new Double(s);
        }
        if (destClass == Boolean.class || destClass == Boolean.TYPE) {
            return new Boolean(!(s.equals("") || s.equals("0") || s.toLowerCase().equals("false")));
        }
        return s;
    }

    static public Object cast(String s, Class destClass) {
        return cast(s, destClass, "utf-8");
    }

    static public Object cast(AssocArray obj, Class destClass, String charset) {
        if (destClass == ArrayList.class) {
            return obj.toArrayList();
        }
        if (destClass == HashMap.class) {
            return obj.toHashMap();
        }
        if (destClass == LinkedHashMap.class) {
            return obj.toLinkedHashMap();
        }
        if (destClass.isArray()) {
            return toArray(obj.toArrayList(), destClass.getComponentType(), charset);
        }
        Constructor ctor;
        if (destClass.isAssignableFrom(Collection.class)) {
            try {
                ctor = destClass.getConstructor(new Class[] { Collection.class });
                return ctor.newInstance(new Object[] { obj.toArrayList() });
            }
            catch (Throwable e) {
                return obj;
            }
        }
        if (destClass.isAssignableFrom(Map.class)) {
            try {
                ctor = destClass.getConstructor(new Class[] { Map.class });
                return ctor.newInstance(new Object[] { obj.toHashMap() });
            }
            catch (Throwable e) {
                return obj;
            }
        }
        return obj;
    }
    static public Object cast(Object obj, Class destClass, String charset) {
        if (obj == null || destClass == null || destClass == Void.class || destClass == Void.TYPE) {
            return null;
        }
        if (destClass.isInstance(obj)) {
            return obj;
        }
        if (obj instanceof byte[]) {
            return cast(toString(obj, charset), destClass, charset);
        }
        if (obj instanceof char[]) {
            return cast(new String((char[]) obj), destClass, charset);
        }
        if (obj instanceof StringBuffer) {
            return cast(obj.toString(), destClass, charset);
        }
        if (obj instanceof String) {
            return cast((String) obj, destClass, charset);
        }
        if (destClass == Character.class || destClass == Character.TYPE) {
            return new Character(obj.toString().charAt(0));
        }
        if (obj instanceof AssocArray) {
            return cast((AssocArray)obj, destClass, charset);
        }
        if ((obj instanceof Boolean) && destClass.isAssignableFrom(Number.class)) {
            return cast(new Integer((((Boolean) obj).booleanValue() == true) ? 1 : 0), destClass);
        }
        if (destClass == String.class) {
            return obj.toString();
        }
        if (destClass == StringBuffer.class) {
            return new StringBuffer(obj.toString());
        }
        if (!obj.getClass().isArray() && destClass == byte[].class) {
            return getBytes(obj);
        }
        if (!obj.getClass().isArray() && destClass == char[].class) {
            return obj.toString().toCharArray();
        }
        if (obj instanceof Number) {
            return cast((Number) obj, destClass);
        }
        return obj;
    }

    static public Object cast(Object obj, Class destClass) {
        return cast(obj, destClass, "utf-8");
    }

    static public Object toArray(ArrayList obj, Class componentType, String charset) {
        int n = obj.size();
        Object a = Array.newInstance(componentType, n);

        for (int i = 0; i < n; i++) {
            Array.set(a, i, cast(obj.get(i), componentType, charset));
        }
        return a;
    }
};
