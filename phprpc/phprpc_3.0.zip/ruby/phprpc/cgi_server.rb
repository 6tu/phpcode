############################################################
#                                                          #
# The implementation of PHPRPC Protocol 3.0                #
#                                                          #
# cgi_server.rb                                            #
#                                                          #
# Release 3.0.4                                            #
# Copyright (c) 2005-2008 by Team-PHPRPC                   #
#                                                          #
# WebSite:  http://www.phprpc.org/                         #
#           http://www.phprpc.net/                         #
#           http://www.phprpc.com/                         #
#           http://sourceforge.net/projects/php-rpc/       #
#                                                          #
# Authors:  Ma Bingyao <andot@ujn.edu.cn>                  #
#                                                          #
# This file may be distributed and/or modified under the   #
# terms of the GNU Lesser General Public License (LGPL)    #
# version 3.0 as published by the Free Software Foundation #
# and appearing in the included file LICENSE.              #
#                                                          #
############################################################
#
# PHPRPC CGIServer library.
#
# Copyright (C) 2005-2008 Ma Bingyao <andot@ujn.edu.cn>
# Version: 3.0
# LastModified: Sep 9, 2008
# This library is free.  You can redistribute it and/or modify it.

require "phprpc/base_server"

module PHPRPC
  
  class CGIServer < BaseServer
    
    def start()
      cgi = CGI::new
      header, body = call!(ENV, cgi)
      header['type'] = header['Content-Type']
      cgi.out(header) { body }
    end

  end # class CGIServer

end # module PHPRPC