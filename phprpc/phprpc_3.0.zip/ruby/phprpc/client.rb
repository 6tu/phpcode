############################################################
#                                                          #
# The implementation of PHPRPC Protocol 3.0                #
#                                                          #
# client.rb                                                #
#                                                          #
# Release 3.0.4                                            #
# Copyright (c) 2005-2008 by Team-PHPRPC                   #
#                                                          #
# WebSite:  http://www.phprpc.org/                         #
#           http://www.phprpc.net/                         #
#           http://www.phprpc.com/                         #
#           http://sourceforge.net/projects/php-rpc/       #
#                                                          #
# Authors:  Ma Bingyao <andot@ujn.edu.cn>                  #
#                                                          #
# This file may be distributed and/or modified under the   #
# terms of the GNU Lesser General Public License (LGPL)    #
# version 3.0 as published by the Free Software Foundation #
# and appearing in the included file LICENSE.              #
#                                                          #
############################################################
#
# PHPRPC Client library.
#
# Copyright (C) 2005-2008 Ma Bingyao <andot@ujn.edu.cn>
# Version: 3.0
# LastModified: Oct 6, 2008
# This library is free.  You can redistribute it and/or modify it.

require "net/http"
require "net/https"
require "uri"
require "digest/md5"
require "php/formator"
require "crypt/xxtea"
require "powmod"

module PHPRPC
  
  class Error < Exception
    attr_accessor :number
  end

  class Client

    VERSION = '3.00'

    def initialize(url = nil)
      Net::HTTP.version_1_2
      @httpclient = nil
      @http = Net::HTTP
      @uri = nil
      if url then
        @uri = URI.parse(url)
      end
      @timeout = 30
      @output = ''
      @warning = nil
      @key = nil
      @keylength = 128
      @encryptmode = 0
      @cookie = ''
      @cookies = {}
      @charset = 'utf-8'
      @server_version = nil
    end

    def use_service(url = nil, username = nil, password = nil)
      if url then
        close
        @uri = URI.parse(url)
        @key = nil
        @keylength = 128
        @encryptmode = 0
        @cookie = ''
        @cookies = {}
        @charset = 'utf-8'
        @uri.user = username unless username.nil?
        @uri.password = password unless password.nil?
      end
      Proxy.new(self)
    end

    def set_proxy(p_addr, p_port = nil, p_user = nil, p_pass = nil)
      close
      @http = Net::HTTP::Proxy(p_addr, p_port, p_user, p_pass)
    end

    def proxy=(proxy)
      close
      @http = case proxy
      when Net::HTTP then
        proxy
      when String then
        uri = URI.parse(proxy)
        Net::HTTP::Proxy(uri.host, uri.port, uri.user, uri.password)
      else
        proxy.superclass == Net::HTTP ? proxy : Net::HTTP
      end
    end

    attr_reader :keylength

    def keylength=(val)
      @keylength = val if @key.nil?
    end

    attr_reader :encryptmode

    def encryptmode=(val)
      @encryptmode = ((val >= 0) and (val <= 3)) ? val.floor : 0;
    end

    attr_accessor :charset, :timeout
    
    attr_reader :output, :warning

    def invoke(methodname, args, byref = false)
      begin
        _key_exchange()
        request = "phprpc_func=#{methodname}"
        request << '&phprpc_args=' << [_encrypt(PHP::Formator.serialize(args), 1)].pack('m').delete!("\n").gsub('+', '%2B') if args.size > 0
        request << "&phprpc_encrypt=#{@encryptmode}"
        request << '&phprpc_ref=false' unless byref
        result = _post(request)
        if result.key?('phprpc_errstr') and result.key?('phprpc_errno') then
          @warning = PHPRPC::Error.new(result['phprpc_errstr'].unpack('m')[0])
          @warning.number = result['phprpc_errno'].to_i
        elsif result.key?('phprpc_functions') then
          @warning = PHPRPC::Error.new("PHPRPC server haven't received then POST data!")
          @warning.number = 1
        else
          @warning = PHPRPC::Error.new("PHPRPC server occured unknown error!")
          @warning.number = 1
        end
        if result.key?('phprpc_output') then
          @output = result['phprpc_output'].unpack('m')[0]
          @output = _decrypt(@output, 3) if @server_version >= 3
        else
          @output = ''
        end
        if result.key?('phprpc_result') then
          PHP::Formator.unserialize(_decrypt(result['phprpc_arg'].unpack('m')[0], 1)).each { |key, value|
            args[key] = value
          } if result.key?('phprpc_args')
          PHP::Formator.unserialize(_decrypt(result['phprpc_result'].unpack('m')[0], 2))
        else
          @warning
        end
      rescue PHPRPC::Error => e
        return e
      rescue Exception => ex
        e = PHPRPC::Error.new(ex.message)
        e.number = 1
        return e
      end
    end
    
    def close
      @httpclient.finish if (not @httpclient.nil?) and @httpclient.started?
      @httpclient = nil
    end

    private

    def _raise_error(number, message)
      error = Error.new(message)
      error.number = number
      raise error
    end
    
    def _post(req)
      if @httpclient.nil? then
        @httpclient = @http.new(@uri.host, @uri.port)
        @httpclient.use_ssl = (@uri.scheme == 'https')
        @httpclient.start
      end
      headers = {
        'User-Agent' => "PHPRPC 3.0 Client for Ruby (#{RUBY_VERSION})",
        'Cache-Control' => 'no-cache',
        'Content-Type' => "application/x-www-form-urlencoded; charset=#{@charset}",
        'Content-Length' => req.size.to_s,
        'Connection' => 'keep-alive',
      }
      headers['Cookie'] = @cookie unless @cookie.empty?
      headers['Authorization'] = 'Basic ' << ["#{@uri.user}:#{@uri.password}"].pack('m').delete!("\n") unless @uri.user.nil? or @uri.password.nil?
      resp, data = @httpclient.request_post(@uri.path, req, headers)
      if resp.code == '200' then
        if resp.key?('x-powered-by') then
          @server_version = nil
          resp['x-powered-by'].split(', ').each { |value|
            @server_version = value[14..-1].to_f if value[0, 13] == 'PHPRPC Server'
          }
          _raise_error(1, 'Illegal PHPRPC server.') if @server_version.nil? 
        else
          _raise_error(1, 'Illegal PHPRPC server.')
        end
        resp['content-type'].split(', ').each { |value|
          @charset = value[20..-1] if value[/^text\/plain; charset=/i]
        }
        if resp.key?('set-cookie') then
          resp['set-cookie'].split(/[;,]\s?/).each { |pairs|
            name, value = pairs.split('=', 2)
            values ||= ''
            @cookies[name] = value unless ['domain', 'expires', 'path', 'secure'].include?(name)
          }
          @cookie = ''
          @cookies.each { |name, value|
            @cookie << "#{name}=#{value}; "
          }
        end
        result = {}
        data.split(/;\r\n/).each { |line|
          result.store(*line.match(/^(phprpc_[a-z]+)="(.*)"$/)[1, 2])
        }
        return result
      else
        _raise_error(resp.code.to_i, resp.message)
      end
    end

    def _key_exchange
      if (@key.nil?) and (@encryptmode != 0) then
        result = _post("phprpc_encrypt=true&phprpc_keylen=#{@keylength.to_s}")
        @keylength = result.key?('phprpc_keylen') ? result['phprpc_keylen'].to_i : 128
        if result.key?('phprpc_encrypt') then
          encrypt = PHP::Formator.unserialize(result['phprpc_encrypt'].unpack("m")[0])
          x = rand(1 << (@keylength - 1)) or (1 << (@keylength - 2))
          key = Math.powmod(encrypt['y'].to_i, x, encrypt['p'].to_i)
          @key = (@keylength == 128) ? [key.to_s(16).rjust(32, '0')].pack('H*') : Digest::MD5.digest(key.to_s)
          y = Math.powmod(encrypt['g'].to_i, x, encrypt['p'].to_i)
          _post("phprpc_encrypt=#{y}")
        else
          @key = nil
          @encryptmode = 0
        end
      end
    end
    
    def _encrypt(str, level)
      ((not @key.nil?) and (@encryptmode >= level)) ? Crypt::XXTEA.encrypt(str, @key) : str
    end
    
    def _decrypt(str, level)
      ((not @key.nil?) and (@encryptmode >= level)) ? Crypt::XXTEA.decrypt(str, @key) : str
    end
    
    def method_missing(methodname, *args)
      self.invoke(methodname, args)
    end

    class Proxy

      def initialize(phprpc_client)
	@phprpc_client = phprpc_client
      end

      def method_missing(methodname, *args)
        @phprpc_client.invoke(methodname, args)
      end

    end # class Proxy

  end # class Client

end # module PHPRPC