require "phprpc"

client = PHPRPC::Client.new("http://127.0.0.1:3000/")

client.encryptmode = 2
client.keylength = 256

starttime = Time.now
10.times {
  puts client.add(1, 2)
  puts client.hello('Ma Bingyao')
  puts client.sub(1, 2)
  puts client.use_session('Hello')
  puts client.use_session(' andot')
}
endtime = Time.now
puts endtime - starttime