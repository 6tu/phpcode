/**********************************************************\
|                                                          |
| The implementation of PHPRPC Protocol 3.0                |
|                                                          |
| Cast.java                                                |
|                                                          |
| Release 3.0.2                                            |
| Copyright by Team-PHPRPC                                 |
|                                                          |
| WebSite:  http://www.phprpc.org/                         |
|           http://www.phprpc.net/                         |
|           http://www.phprpc.com/                         |
|           http://sourceforge.net/projects/php-rpc/       |
|                                                          |
| Authors:  Ma Bingyao <andot@ujn.edu.cn>                  |
|                                                          |
| This file may be distributed and/or modified under the   |
| terms of the GNU Lesser General Public License (LGPL)    |
| version 3.0 as published by the Free Software Foundation |
| and appearing in the included file LICENSE.              |
|                                                          |
\**********************************************************/

/* Cast library.
 *
 * Copyright: Ma Bingyao <andot@ujn.edu.cn>
 * Version: 3.0.2
 * LastModified: Feb 16, 2009
 * This library is free.  You can redistribute it and/or modify it.
 */

package org.phprpc.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.lang.reflect.Array;
import java.lang.reflect.Method;

public final class Cast {

    private Cast() {};

    static public byte[] getBytes(Object obj, String charset) {
        if (obj instanceof byte[]) {
            return (byte[])obj;
        }
        try {
            return obj.toString().getBytes(charset);
        }
        catch (Exception e) {
            return obj.toString().getBytes();
        }
    }

    static public byte[] getBytes(Object obj) {
        return getBytes(obj, "utf-8");
    }

    static public String toString(Object obj, String charset) {
        if (obj instanceof byte[]) {
            try {
                return new String((byte[]) obj, charset);
            }
            catch (Exception e) {
                return new String((byte[]) obj);
            }
        }
        else {
            return obj.toString();
        }
    }

    static public String toString(Object obj) {
        return toString(obj, "utf-8");
    }

    static public Object cast(Number n, Class destClass) {
        if (destClass == Byte.class || destClass == Byte.TYPE) {
            return new Byte(n.byteValue());
        }
        if (destClass == Short.class || destClass == Short.TYPE) {
            return new Short(n.shortValue());
        }
        if (destClass == Integer.class || destClass == Integer.TYPE) {
            return new Integer(n.intValue());
        }
        if (destClass == Long.class || destClass == Long.TYPE) {
            return new Long(n.longValue());
        }
        if (destClass == Float.class || destClass == Float.TYPE) {
            return new Float(n.floatValue());
        }
        if (destClass == Double.class || destClass == Double.TYPE) {
            return new Double(n.doubleValue());
        }
        if (destClass == Boolean.class || destClass == Boolean.TYPE) {
            return new Boolean(n.byteValue() != 0);
        }
        return n;
    }

    static public Object cast(String s, Class destClass, String charset) {
        if (destClass == char[].class) {
            return s.toCharArray();
        }
        if (destClass == byte[].class) {
            return getBytes(s, charset);
        }
        if (destClass == StringBuffer.class) {
            return new StringBuffer(s);
        }
        if (destClass == Byte.class || destClass == Byte.TYPE) {
            return new Byte(s);
        }
        if (destClass == Short.class || destClass == Short.TYPE) {
            return new Short(s);
        }
        if (destClass == Integer.class || destClass == Integer.TYPE) {
            return new Integer(s);
        }
        if (destClass == Long.class || destClass == Long.TYPE) {
            return new Long(s);
        }
        if (destClass == Float.class || destClass == Float.TYPE) {
            return new Float(s);
        }
        if (destClass == Double.class || destClass == Double.TYPE) {
            return new Double(s);
        }
        if (destClass == Boolean.class || destClass == Boolean.TYPE) {
            return new Boolean(!(s.equals("") || s.equals("0") || s.toLowerCase().equals("false")));
        }
        return s;
    }

    static public Object cast(String s, Class destClass) {
        return cast(s, destClass, "utf-8");
    }

    static public Object cast(AssocArray obj, Class destClass, String charset) {
        if (destClass == ArrayList.class || destClass == List.class || destClass == Collection.class) {
            return obj.toArrayList();
        }
        if (destClass == Set.class) {
            return new HashSet(obj.toArrayList());
        }
        if (destClass == HashMap.class || destClass == Map.class) {
            return obj.toHashMap();
        }
        if (destClass == LinkedHashMap.class) {
            return obj.toLinkedHashMap();
        }
        if (destClass.isArray()) {
            return toArray(obj.toArrayList(), destClass.getComponentType(), charset);
        }
        if (Collection.class.isAssignableFrom(destClass)) {
            try {
                Method addAll = destClass.getMethod("addAll", new Class[] { Collection.class });
                Object o = PHPSerializer.newInstance(destClass);
                if (o != null) {
                    addAll.setAccessible(true);
                    addAll.invoke(o, new Object[] { obj.toArrayList() });
                }
                return o;
            }
            catch (Throwable e) {
                return null;
            }
        }
        if (Map.class.isAssignableFrom(destClass)) {
            try {
                Method putAll = destClass.getMethod("putAll", new Class[] { Map.class });
                Object o = PHPSerializer.newInstance(destClass);
                if (o != null) {
                    putAll.setAccessible(true);
                    putAll.invoke(o, new Object[] { obj.toHashMap() });
                }
                return o;
            }
            catch (Throwable e) {
                return null;
            }
        }
        return obj;
    }
    static public Object cast(Object obj, Class destClass, String charset) {
        if (obj == null || destClass == null || destClass == Void.class || destClass == Void.TYPE) {
            return null;
        }
        if (destClass.isInstance(obj)) {
            return obj;
        }
        if (obj instanceof byte[]) {
            return cast(toString(obj, charset), destClass, charset);
        }
        if (obj instanceof char[]) {
            return cast(new String((char[]) obj), destClass, charset);
        }
        if (obj instanceof StringBuffer) {
            return cast(obj.toString(), destClass, charset);
        }
        if (obj instanceof String) {
            return cast((String) obj, destClass, charset);
        }
        if (destClass == Character.class || destClass == Character.TYPE) {
            return new Character(obj.toString().charAt(0));
        }
        if (obj instanceof AssocArray) {
            return cast((AssocArray)obj, destClass, charset);
        }
        if ((obj instanceof Boolean) && Number.class.isAssignableFrom(destClass)) {
            return cast(new Integer((((Boolean) obj).booleanValue() == true) ? 1 : 0), destClass);
        }
        if (destClass == String.class) {
            return obj.toString();
        }
        if (destClass == StringBuffer.class) {
            return new StringBuffer(obj.toString());
        }
        if (!obj.getClass().isArray() && destClass == byte[].class) {
            return getBytes(obj);
        }
        if (!obj.getClass().isArray() && destClass == char[].class) {
            return obj.toString().toCharArray();
        }
        if (obj instanceof Number) {
            return cast((Number) obj, destClass);
        }
        return obj;
    }

    static public Object cast(Object obj, Class destClass) {
        return cast(obj, destClass, "utf-8");
    }

    static public Object toArray(ArrayList obj, Class componentType, String charset) {
        int n = obj.size();
        Object a = Array.newInstance(componentType, n);

        for (int i = 0; i < n; i++) {
            Array.set(a, i, cast(obj.get(i), componentType, charset));
        }
        return a;
    }
};
