﻿<?php

require_once __DIR__ . './php-sdk-7.2.6/autoload.php';

// 引入鉴权类
use Qiniu\Auth;

// 引入上传类
use Qiniu\Storage\UploadManager;

// 需要填写你的 Access Key 和 Secret Key
// 档案中使用 test-env.sh 给系统中增加了 QINIU_ACCESS_KEY 等变量，然后使用getenv() 函数调用了这些变量，但这对WINDOWS并不适用
$accessKey = 'KzBWtGa-Qsxd2zA_SbYkcxi9Evw0fRNgQY5ax9T6';
$secretKey = 'F8JQ4riqVfQmgCyDWya9Oi5TYBtNpOKBToYUxEyh';
$bucket = 'yisuo';

// 构建鉴权对象
$auth = new Auth($accessKey, $secretKey);

// 生成上传 Token
$token = $auth->uploadToken($bucket);

// 要上传文件的本地路径
$filePath = './php-logo.png';

// 上传到七牛后保存的文件名
$key = 'png/my-php-logo.png';

// 避免重复
// $key = time().'my-php-logo.png';

// 初始化 UploadManager 对象并进行文件的上传。
$uploadMgr = new UploadManager();

// 调用 UploadManager 的 putFile 方法进行文件的上传。
list($ret, $err) = $uploadMgr->putFile($token, $key, $filePath);
echo "\n====> putFile result: \n";
if ($err !== null) {
    var_dump($err);
} else {
    var_dump($ret);
}














