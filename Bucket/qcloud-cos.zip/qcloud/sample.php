<?php

require 'cos-php-sdk-v5/vendor/autoload.php';
/*
$cosClient = new Qcloud\Cos\Client(array(
    'region' => getenv('COS_REGION'),
    'credentials' => array(
        'appId' => getenv('COS_APPID'),
        'secretId' => getenv('COS_KEY'),
        'secretKey' => getenv('COS_SECRET'),
    ),
));
*/
# 获取bucket地域
## getBucketLocation


$cosClient = new Qcloud\Cos\Client(array(
    'region' => 'tj',
    'credentials' => array(
        'appId' => '1252761862',
        'secretId' => 'AKIDSp5DA129SZTBg0M2lOd4NBsSvFNJGZu3',
        'secretKey' => '4zhDWgeR1RgkcIl270iDWcWDi1A6qNir',
    ),
));


// 若初始化 Client 时未填写 appId，则 bucket 的命名规则为{name}-{appid} ，此处填写的存储桶名称必须为此格式
$bucket = 'yisuo-1252761862';
$key = 'p7m_2018-8-22-t.zip.b64.zip'; # 远端文件名
$local_path = "D:/www/qcloud/p7m_2018-8-22-t.zip.b64.zip";  # 本地文件名

echo '<pre>';
# 上传文件
## putObject(上传接口，最大支持上传5G文件)

### 上传文件流
try {
    $result = $cosClient->putObject(array(
        'Bucket' => $bucket,
        'Key' => $key,
        'Body' => fopen($local_path, 'rb')
    ));
    print_r($result);
} catch (\Exception $e) {
    print_r($e);
}
