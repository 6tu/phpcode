<?php
// This file was auto-generated from sdk-root/src/data/opsworks/2013-02-18/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'DescribeStacks', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'DescribeLayers', 'input' => [ 'StackId' => 'fake_stack', ], 'errorExpectedFromService' => true, ], ],];
