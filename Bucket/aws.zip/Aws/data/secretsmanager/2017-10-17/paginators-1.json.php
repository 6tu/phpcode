<?php
// This file was auto-generated from sdk-root/src/data/secretsmanager/2017-10-17/paginators-1.json
return [ 'pagination' => [ 'ListSecretVersionIds' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'ListSecrets' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];
