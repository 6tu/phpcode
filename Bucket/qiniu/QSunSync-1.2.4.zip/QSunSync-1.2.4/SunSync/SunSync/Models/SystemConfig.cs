﻿
namespace SunSync.Models
{
    class SystemConfig
    {
        public static string ACCESS_KEY;
        public static string SECRET_KEY;
    }
}
