
<?php

require 'IP.class.php';
$x_ip= $ip_address = IP::generate();
#$province_ip=$ip_address = IP::generate('安徽');
#$update_ip=IP::update();
echo $x_ip;
?>

