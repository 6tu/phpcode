<?php
session_start();
set_time_limit(0);
error_reporting(0);
echo($_SESSION['bodytext']);
?>
