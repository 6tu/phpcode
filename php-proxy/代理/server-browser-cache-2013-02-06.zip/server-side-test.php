<?php

//first time will be some slow because is generated first time, but next times will be much faster

$s=microtime(true);
$full_path="http://".$_SERVER['SERVER_NAME']."/cache"; // you should use your own path here
$string=file_get_contents($full_path."/demo.php");
$e=microtime(true);

echo ceil(1000*($e-$s)). "ms"

?>