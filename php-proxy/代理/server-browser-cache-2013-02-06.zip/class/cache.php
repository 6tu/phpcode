<?

// Created by Raul Molnar (raul@webstorm.ro, for support)
// You have full rights to change.. use.. sell.. donate some (to the Paypal account rm@webstorm.ro) .
// Have fun!

class CACHE {
	

private $root=""; // path to the local folder, YOU NEED WRITE PERMISSIONS (chmod 666 or 777)
private $server__cache_time=300; //how long will be cached a file on server in seconds
private $client__cache_time=150; //how long will be cached a file on browser in seconds
private $cache_type=2; // 0 = no cache , 1 = server side cache, 2 = client side (browser) cache, 3 = both side cache
private $attached_value=""; //userfull to COOKIE or SESSION values (may be used for logged users for example
private $page;
public $file_name; // thecache file name on server
public $full_file_name; //full file path and name on local server
public $need_update=false; //if true then means the content will be saved locally in the path (full_file_name)
public $file_extension="html"; // usefull to check the cache content faster


public function __construct($root="",$cache_type=-1, $attached_value="") {

	if ($root!="")	$this->setRoot($root);
	if ($attached_value!="")	$this->attachValue($attached_value);
	if ($cache_type!=-1)	$this->setCacheType($cache_type);

}


function startCache() { // will start caching process
	if ($this->cache_type==1) {	
					$this->setServerSideCache();
					$this->setClientCacheTime(0);
							  }
				else if ($this->cache_type==2)  {
					$this->setClientSideCache();
					$this->setServerCacheTime(0);
							}
				else if ($this->cache_type==3)  {
					$this->setClientSideCache();
					$this->setServerSideCache();
						}
				else {
					$this->setCacheTime(0);
					$this->setClientSideCache(); 
					}
	
}

function setRoot($root) { //will set root folder (without last "/"
	$this->root=$root;
}
function setCacheType($cache_type) { //will set cacheType: 0 = no cache , 1 = server side cache, 2 = client side (browser) cache, 3 = both side cache
	$this->cache_type=$cache_type;
}

function setFileExtension($file_extension) { //will set cacheType: 0 = no cache , 1 = server side cache, 2 = client side (browser) cache, 3 = both side cache
	$this->file_extension=$file_extension;
}


function setClientCacheTime($time) { // will set client cache time (in seconds)
	$this->client__cache_time=$time;
}

function setServerCacheTime($time) { // will set server cache time (in seconds)
	$this->server__cache_time=$time;
}

function setCacheTime($time) { // will set both client and server cache time (in seconds)
	$this->setClientCacheTime($time);
	$this->setServerCacheTime($time);	
}

function attachValue($value) { // will attach value related to the cache file , example : USER session or USER cookie, or a test value
	$this->attached_value=$value;
}

function start_file_cache() { //will prepare system for file caching (server side)
	$this->need_update=true;
	ob_start();
}

function setClientSideCache() { //will set headers for client side caching
	
	
	
if  ($this->client__cache_time>0) {

	$time_format = gmdate("D, d M Y H:i:s", time() + $this->client__cache_time) . " GMT";
	header("Expires: ".$time_format);
	header("Pragma: cache");
	header("Cache-Control: max-age=".$this->client__cache_time);
	}
	else {
	header('Cache-Control: no-cache');
	header('Pragma: no-cache');
	}

}

function setServerSideCache() { // is checking if the file is already there and not expired (in the interval of  "server__cache_time" seconds you set

if ($this->server__cache_time<=0) return;

$this->page=$_SERVER['REQUEST_URI'];
$sanitize=$result = preg_replace("/[^a-zA-Z0-9]+/", "",$_SERVER['PHP_SELF']);
$this->file_name=$sanitize."-".substr(md5($this->page),10,16); //will generate a file name, you can put any rule you want here

if (strlen($this->attached_value)>0) { $this->file_name.="-".$this->attached_value; }
if (strlen($this->file_extension)>0) { $this->file_name.=".".$this->file_extension; }

$this->full_file_name=$this->root."/".$this->file_name;

if (file_exists($this->full_file_name)) {
		 	$file_time=filemtime($this->full_file_name);
			$now_time=time(false);
			
			if (($file_time-$now_time)>=$this->server__cache_time) {  $this->start_file_cache(); } // if the cache file is expired then will be replaced with a more recent one
						else {
						@readfile($this->full_file_name);
						die(""); // if the cache file is not expired then will only diplay the content and the script will stop
						}
						} else {
						$this->start_cache(); // if the cache file is not created will simply create a new one
						}

}

function callback($buffer) {
 return $buffer.$this->save_file($buffer);
}	

function save_file($content) { // this will save the cache file  , can be used fopen or any method for writting, even query in a database

	
if ($file = @fopen($this->full_file_name, "wb"))
         {
             @fwrite($file, $content);
             @fclose($file);
         } 	 
	return "";
}

function start_cache() {
		$this->need_update=true;
		ob_start(array(&$this, 'callback'));
}



	
}


?>