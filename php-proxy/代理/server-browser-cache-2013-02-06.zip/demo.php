<?php 

include_once "class/cache.php";

// very important! session_start(); or start cookie here 
error_reporting(E_ALL & ~E_NOTICE );
//basic usage

$folder=$_SERVER['DOCUMENT_ROOT']."/cache/cache_"; // you need to set your path here
$cache=new CACHE();
$cache->setRoot($folder); // the cached files will be saved locally (if server side caching) here
$cache->setCacheType(1); //server side
$cache->setFileExtension("html"); // will save cached files as html, will make this easier to check the saved files
$cache->startCache(); // will start caching process


?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Cache class demo</title>
</head>
<body>
<?php  
$string="";
for ($i=1; $i<100000; $i++) $string.= ($i+3.324324324 * $i*pi()/2);
echo "String=".md5($string);  
?>
</body>
</html>