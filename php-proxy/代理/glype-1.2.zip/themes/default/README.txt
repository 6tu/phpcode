--------------------------------------------------------------------------------
| GLYPE PROXY
--------------------------------------------------------------------------------
| Theme: Default
| Author: Glype
| Website: http://www.glype.com/
--------------------------------------------------------------------------------
| SETUP INSTRUCTIONS
--------------------------------------------------------------------------------
 To customize the template you can either edit the HTML directly in main.php
 and ignore the <!--[x]--> tags, or edit a series of predefined sections
 by editing the config.php file.

 The theme comes with three ad locations built in, as follows:
  1) above form on the index page
  2) below form on the index page
  3) between form and content on proxied pages
 
 To use these default locations, simply open up config.php and add in your ad
 codes to the relevant section, as explained in the file. Alternatively you can
 customize the design further by chosing your own ad locations and inserting
 them directly into the template files.
    main.php contains the index page
    framedForm.inc.php contains the form included on proxied pages
    
--------------------------------------------------------------------------------
| ADDITIONAL INFORMATION
--------------------------------------------------------------------------------
 If you require further help with your glype proxy, try the documentation or the
 forums over at http://www.glype.com/
