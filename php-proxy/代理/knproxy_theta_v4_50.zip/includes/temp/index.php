<?php
//Silence is Golden
?>