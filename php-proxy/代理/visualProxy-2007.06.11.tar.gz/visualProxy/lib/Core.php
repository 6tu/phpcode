<?php

/**
	author : Marc Quinton - march 2007.
	licence : LGPL

	ispMonitor - an easy to use php-gtk2 frontend to ping command 

	ispMonitor is a easy to use GUI for the ping command, allowing one to monitor network defects over 
	broadband ADSL Internet connections. ispMonitor takes care of dropped or late packets. Results are
	displayed both visually and in a text window.

*/


class Core extends GtkWindow{

	protected function process_all_events(){
		while(Gtk::events_pending()) {Gtk::main_iteration();}
	}
}

?>
