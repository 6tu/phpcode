<?php

include_once('Tcp.php');

include_once('HttpHeader.php');
include_once('HttpResponse.php');
include_once('ProxyRequest.php');

class ProxyServer {
	protected $connections = array();
	protected $connection_id = 0;

	protected $server = null;
	protected $proxy_server;
	protected $callback;

	public function __construct($host='127.0.0.1', $port= 8889){
		$this->server = Tcp::server($host, $port);
		$this->server->set_accept_hook(array($this,'accept'));
		$this->proxy_server = new ExternalProxyServer();
		$this->callback = null;

		printf("starting Proxy server on {$host}:{$port} - relay to proxy server %s:%s\n", 
			$this->proxy_server->host(),
			$this->proxy_server->port()
		);
		echo "Ready ... \n";
	}

	public function accept($connection){
		$this->connection_id++;
		$this->connections[$this->connection_id] = $connection;
		$connection->id=$this->connection_id;
		$connection->set_receive_hook(array($this,'receive'));

		if($this->callback != null){
			$context = array(
				'id'         => $this->connection_id,
				'connection' => $connection
			);
			call_user_func($this->callback, $reason='accept', $context);
		}
	}


	/**
	 * -this is a HTTP:1.0 mode only : connexion are close each time after proxy request
	 * - now can only relay proxy requests from this server to an other proxy server
	 */
	public function receive($sock,$connection){
		# echo "Server : from - " . $connection->get_name() . "\n";

		$request = new ProxyRequest();
		$request->read($connection);
		$response = $request->make_proxy_http_1_0($connection, $this->proxy_server);

		$connection->request = $request;
		$connection->response = $response;

		if($this->callback != null){
			$context = array(
				'id'         => $connection->id,
				'connection' => $connection,
				'request'    => $request,
				'response'   => $response
			);
			call_user_func($this->callback, $reason='done', $context);
		}
	}

	public function get_request($id){
		if(isset($this->connections[$id]))
			return $this->connections[$id];
		else
			return false;
	}

	public function set_callback($callback){
		$this->callback = $callback;
	}
}

?>
