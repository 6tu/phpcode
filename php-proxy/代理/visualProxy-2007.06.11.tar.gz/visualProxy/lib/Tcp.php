<?php

include_once('TcpServer.php');
include_once('TcpConnection.php');

class Tcp {

	protected function __construct(){	
	}
	
	static public function server($ip, $port){
		$sock = stream_socket_server("tcp://$ip:$port");
		if ($sock) {
			return new TcpServer($sock);
		}else{
			return null;
		}
	}
	
	static public function client($ip, $port){
		$sock = stream_socket_client("tcp://$ip:$port");
		if ($sock) {
			return new TcpConnection($sock);
		} else {
			return null;
		}
	}

}

?>
