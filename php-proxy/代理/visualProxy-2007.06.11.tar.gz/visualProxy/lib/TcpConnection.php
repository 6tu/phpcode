<?php

class TcpConnection {

	protected $hook = null;
	protected $sock = null;
	protected $connected = false;
	
	public function __construct($sock){
		$this->connected = true;
		$this->sock = $sock;
		$this->watch_ids[] = Gtk::io_add_watch($sock,Gtk::IO_IN,  array($this,"io_in"));
		$this->watch_ids[] = Gtk::io_add_watch($sock,Gtk::IO_HUP, array($this,"io_hup"));
		$this->watch_ids[] = Gtk::io_add_watch($sock,Gtk::IO_ERR, array($this,"io_err"));

	}

	public function __destruct(){
		$this->shutdown();
	}

	public function io_in($sock, $conditions){
		if ($this->hook) {
			call_user_func_array($this->hook, array($this->sock,$this));
		}
		return $this->connected;
	}

	public function io_hup($sock, $conditions){
		$this->connected = false;
		$this->shutdown();
	}

	public function io_err($sock, $conditions){
		echo "TcpConnection::io_err()\n";
	}

	public function write($data){
		return fwrite($this->sock, $data, strlen($data));
	}

	public function readline(){
		return fgets($this->sock);
	}

	public function eof(){
		if(!is_resource($this->sock))
			return false;
		if($this->connected == false)
			return true;
		return feof($this->sock);
	}

	public function close(){
		if(!is_resource($this->sock))
			return false;

		if($this->sock != null && ! $this->eof())
			return fclose($this->sock);
		$this->sock = null;
	}

	public function set_receive_hook($hook){
		$oldhook = $this->hook;
		$this->hook = $hook;
		return $oldhook;
	}

	public function shutdown(){
		foreach($this->watch_ids as $id)
			Gtk::input_remove($id);
		$this->close();
	}

	function get_name($remote=true){
		if($this->sock != null)
			return stream_socket_get_name($this->sock, $remote);
		else
			return false;
	}
}

?>
