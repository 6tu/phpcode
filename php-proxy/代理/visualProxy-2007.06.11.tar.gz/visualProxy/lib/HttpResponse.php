<?php

class HttpResponse{
	protected $data;

	protected $header;
	protected $size;

	public function __construct(&$data){
		$this->data = $data;
		$this->size = strlen($data);


		$info = $this->find_header_and_data();
		$this->header = new HttpHeader($info['header']);
		$this->data = &$info['data'];
	}

	public function __toString($quiet=true){
		if($quiet)
			return sprintf("(size %s, type=%s)", $this->content_length(), $this->content_type());
		else{
			print_r($this);
		}
	}

	public function header(){
		return $this->header;
	}

	public function &data(){
		return $this->data;
	}

	public function debug(){
		print_r($this->header->__toString());
	}

	# HTTP/1.1 200 OK
	public function status(){
		$data = $this->header->command();
		if(preg_match('#HTTP/.+? (.+?) (.+)#', $data, $values))
			return $values[1];
		else
			return '?';
	}

	public function content_type(){
		return $this->header->get('Content-Type');
	}

	public function content_length(){
		return $this->header->get('Content-Length');
	}

	public function age(){
		return $this->header->get('Age');
	}


	protected function &find_header_and_data(){

		# only header, without data
		if(!strpos($this->data, "\r\n", 0)){
			$info = array(
				'header' => $this->data,
				'data'   => null
			);
			return $info;
		}

		$pos = 0;
		while($pos = strpos($this->data, "\r\n", $pos)){
			# try to find 2 successive \r\n
			if(substr($this->data, $pos, 4) == "\r\n\r\n"){
				$header = substr($this->data, 0, $pos);
				$info = array(
					'pos' => $pos,
					'header' => substr($this->data, 0, $pos),
					'data'   => substr($this->data, $pos+4, $this->size - $pos)
				);
				return $info;
			}

			$pos +=2;
		}
		throw new Exception("HttpResponse : malformed response, no header found", ERROR_HTTP_RESPONSE_MALFORMED);
	}
}

?>
