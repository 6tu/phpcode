<?php

/**
	author : Marc Quinton - march 2007.
	licence : LGPL

	ispMonitor - an easy to use php-gtk2 frontend to ping command 

	ispMonitor is a easy to use GUI for the ping command, allowing one to monitor network defects over 
	broadband ADSL Internet connections. ispMonitor takes care of dropped or late packets. Results are
	displayed both visually and in a text window.

*/



include_once('Core.php');

class GladeUI extends Core{
 
	protected $glade_file;
	protected $glade_main;
	protected $glade;

	public function __construct() {
		parent::__construct();

		# $this->glade_file = PROG_NAME . '.glade';
		# $this->glade_main = 'main';   # main widget (root)

		$this->buildGUI();
		$this->add($this->widget_get($this->glade_main));
		$this->set_position(Gtk::WIN_POS_CENTER);
	}

    public function __get($name){
        return $this->widget_get($name);
    }

	protected function buildGUI(){
		if(file_exists($this->glade_file)){
			$this->glade = $this->glade_xml = new GladeXml($this->glade_file, $this->glade_main);
			return true;
		}
		elseif(isset($GLOBALS['xml'])){
			$this->glade = $this->glade_xml = GladeXML::new_from_buffer($GLOBALS['xml'], $this->glade_main);
			return true;
		} else
			throw new Exception ("can't find glade file {$this->glade_file}");
	}

	protected function widget_get($name, $xml = null){
		if($xml == null)
			$xml = $this->glade;

		$widget = $xml->get_widget($name);
		if($widget == null)
			throw new Exception ("can't find widget named '$name' in glade file {$this->glade_file}");

		return $widget;
	}
}

?>
