<?php

class HttpHeader {
	protected $command;
	protected $header;
	protected $data;

	public function __construct($data){
		$this->data = $data;
		$lines = split("\r\n", $data);
		$this->command = array_shift($lines);
		$this->header = array();

		foreach($lines as $line){
			list($key, $val) = split(": ", $line);
			$this->header[$key] = $val;
		}
	}

	public function __toString(){
		foreach($this->header as $key=>$val)
			$list[] = " < $key: $val";
		return  " < " . $this->command . "\n" . join("\n", $list) . "\n";
	}

	public function data(){
		return $this->data;
	}

	public function _isset($key){
		return isset($this->header[$key]);
	}

	public function command(){
		return $this->command;
	}


	public function keys(){
		return array_keys($this->header);
	}

	public function get($key){
		if(isset($this->header[$key]))
			return $this->header[$key];
		else
			# throw new Exception("HttpHeader : key not set", WARNING_OUT_OF_RANGE);
			return false;
	}

	public function toString(){
		foreach($this->header as $key=>$val)
			$list[] = "$key $val";
		return join("\n", $list);
	}
}

?>
