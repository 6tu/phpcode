<?php

class TcpServer {

	protected $hook = null;
	protected $connected = false;
	protected $sock = null;
	
	public function __construct($sock){
		$this->connected = true;
		Gtk::io_add_watch($sock,Gtk::IO_IN,array($this,"socket_accept"));
	}
	
	public function socket_accept($sock, $conditions){
		$connection = new TcpConnection(stream_socket_accept($sock));
		$this->trigger_hook($connection);
		return $this->connected;
	}
	
	public function set_accept_hook($hook){
		$oldhook = $this->hook;
		$this->hook = $hook;
		return $oldhook;
	}
	
	public function get_accept_hook(){
		return $this->hook;
	}
	
	protected function trigger_hook($connection){
		if ($this->hook) {
			call_user_func_array($this->hook, array($connection));
		}
	}
	
	protected function __clone(){
	}

}

?>
