<?php

/**
	author : Marc Quinton - march 2007.
	licence : LGPL

	ispMonitor - an easy to use php-gtk2 frontend to ping command 

	ispMonitor is a easy to use GUI for the ping command, allowing one to monitor network defects over 
	broadband ADSL Internet connections. ispMonitor takes care of dropped or late packets. Results are
	displayed both visually and in a text window.

*/


class ListWidget extends GtkTreeView{

	protected $model;
	protected $cell_render;
	protected $column;
	protected $selection; # an alias to $this->get_selection();

	function __construct(){

		parent::__construct();

		$this->build();
	}

	protected function build(){

		# number | time | method (GET|POST) | address | size
		$this->model = new GtkListStore(Gtk::TYPE_LONG, Gtk::TYPE_STRING, Gtk::TYPE_STRING, Gtk::TYPE_LONG, Gtk::TYPE_STRING, Gtk::TYPE_STRING, Gtk::TYPE_STRING);
		$this->set_model($this->model);

		# for debug
		# $this->append(array(1, date('H:i:s'), 'GET',    1234,  'text/plain',  'http://www.google.fr'));

		$cell_renderer = new GtkCellRendererText();

		$col_num = 0;
		# col number
		$col = new GtkTreeViewColumn('#', $cell_renderer, 'text', $col_num);
		$col->set_sort_column_id($col_num++);
		$col->set_resizable(true);
		$this->append_column($col);

		# col time
		$col = new GtkTreeViewColumn('Time', $cell_renderer, 'text', $col_num);
		$col->set_sort_column_id($col_num++);
		$col->set_resizable(true);
		$this->append_column($col);

 		# col time
		$col = new GtkTreeViewColumn('Method', $cell_renderer, 'text', $col_num);
		$col->set_sort_column_id($col_num++);
		$col->set_resizable(true);
		$this->append_column($col);

 		# col size 
		$col = new GtkTreeViewColumn('Size', $cell_renderer, 'text', $col_num);
		$col->set_sort_column_id($col_num++);
		$col->set_resizable(true);
		$this->append_column($col);

 		# col type-mime
		$col = new GtkTreeViewColumn('Mime-type', $cell_renderer, 'text', $col_num);
		$col->set_sort_column_id($col_num++);
		$col->set_resizable(true);
		$this->append_column($col);

 		# col Status (from http response)
		$col = new GtkTreeViewColumn('Status', $cell_renderer, 'text', $col_num);
		$col->set_sort_column_id($col_num++);
		$col->set_resizable(true);
		$this->append_column($col);

 		# col address 
		$col = new GtkTreeViewColumn('Address', $cell_renderer, 'text', $col_num);
		$col->set_sort_column_id($col_num++);
		$col->set_resizable(true);
		$this->append_column($col);

	}

	public function clear(){
		$this->model->clear();
	}

	public function append($array){
		$this->model->append($array);
	}

	public function set_list($list){
		$this->clear();
		foreach($list as $array)
			$this->append($array);
	}

	# callback(GtkTreeView treeview, XXX UNKNOWN, GtkTreeViewColumn UNKNOWN);
	public function on_row_activated($treeview, $path, $column){
		$iter = $this->model->get_iter($path);
		$value = $this->model->get_value($iter, 0);
		# echo "on_row_activated($value)\n";
	}

	public function get_selected(){
		$selection = $this->get_selection();
		list($model, $iter) = $selection->get_selected();
		return $model->get_value($iter, 0);
	}

	public function find_iter($text){
		$first_iter = $this->get_model()->get_iter_first();

		if($first_iter == null)
			return false;

		$iter = $first_iter;
		while( $iter != null){
			$path = $this->get_model()->get_path($iter);
			$value = $this->get_model()->get_value($iter, 0);
			if($value == $text)
				return $iter;
			# make while loop go next
			$iter = $this->get_model()->iter_next($iter);
		}

		return false;
	}

	public function select_and_show($text){
		$iter = $this->find_iter($text);
		if($iter == false)
			return;
		$this->selection->unselect_all();
		$this->selection->select_iter($iter);
		$this->scroll_to_cell($this->get_model()->get_path($iter));
	}
}

?>
