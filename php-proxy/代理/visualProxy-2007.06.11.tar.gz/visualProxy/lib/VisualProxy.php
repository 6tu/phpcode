<?php

error_reporting(E_ALL);

include_once('ProxyServer.php');
include_once('GladeUI.php');
include_once('ListWidget.php');

define('WARNING_OUT_OF_RANGE', 1);
define('ERROR_HTTP_RESPONSE_MALFORMED', 1000);

# this is most a configuration class
class ExternalProxyServer{
	protected $host = 'localhost';
	protected $port = '8888';

	function host(){
		return $this->host;
	}
	function port(){
		return $this->port;
	}
}

class VisualProxy extends GladeUI{

	protected $list_requests;  # widget list
	protected $server;
	protected $requests;

	public function __construct(){
		$this->glade_file = DIR . '/share/visual-proxy.glade';
		$this->glade_main = 'main';   # main widget (root)

		parent::__construct();

		$this->server = new ProxyServer($host='127.0.0.1', $port=9998);
		$this->server->set_callback(array($this, 'on_proxy_callback'));
		$this->requests = array();
	}

	protected function buildGUI(){
		parent::buildGUI();
		$this->list_requests = new ListWidget();
		$this->scrolledwindow_list_requests->add($this->list_requests);
		$this->vpaned1->set_position(100);
		$this->list_requests->get_selection()->connect_simple('changed', array($this, 'on_list_selection_changed'));

		$this->set_title('Visual Proxy');
	}

	public function on_list_selection_changed(){
		$selection = $this->list_requests->get_selection();
		list($model, $iter) = $selection->get_selected();
		$id = $model->get_value($iter, 0);

		$context = $this->requests[$id];
		$this->textview_request_info->get_buffer()->set_text($context['request']->header()->data());
		$this->textview_response_info->get_buffer()->set_text($context['response']->header()->data());

		$content_type = $context['response']->content_type();
		if(strstr($content_type, 'text/') || $content_type == 'application/x-javascript')
			$this->textview_response_data->get_buffer()->set_text($context['response']->data());
		else
			$this->textview_response_data->get_buffer()->set_text('not displayable (now)');
	}

	public function on_proxy_callback($event, $context){
		if($event == 'done'){
			$list = array(
				'id'      => $context['id'],
				'time'    => date('H:i:s'),
				'method'  => $context['request']->method(),
				'size'    => $context['response']->content_length(),
				'type'    => $context['response']->content_type(),
				'status'  => $context['response']->status(),
				'address' => $context['request']->address()
			);

			$this->list_requests->append(array_values($list));
			$this->process_all_events();
			$this->requests[$context['id']] = $context;

			# status bar (and label info at bottom
			$this->label_connection_count->set_text('connections : ' . count($this->requests));

			static $mem = 0;
			if($mem == 0)
				$mem = memory_get_usage();

			$current_mem = intval((memory_get_usage() - $mem) / 1024);
			$this->label_memory->set_text("Mem : $current_mem Kb" );
			

		}
	}
}


# $server = new ProxyServer($host='127.0.0.1', $port=9998);

$ui = new VisualProxy();

$ui->connect_simple('destroy', array('gtk', 'main_quit'));
$ui->set_size_request(800, 500);
$ui->set_position(Gtk::WIN_POS_CENTER);

$ui->show_all();

gtk::main();

?>
