<?php

class ProxyRequest{
	protected $command;  # GET ...
	protected $header;
	protected $result;
	protected $time;

	public function __construct(){
		$this->command = null;
		$this->result = '';
		$this->time = time();
	}

	public function __toString(){
		$lines = split("\n", $this->header_string);
		foreach($lines as $key=>$line)
			$lines [$key] = " > " . $line;
		return join("\n", $lines) . "\n";
	}

	public function method(){
		if(strstr($this->command, 'GET '))
			return 'GET';

		if(strstr($this->command, 'POST '))
			return 'POST';

		if(strstr($this->command, 'CONNECT '))
			return 'CONNECT';

		if(strstr($this->command, 'HEAD '))
			return 'HEAD';

		return '?';
	}

	public function address(){
		if(preg_match('#.+? (.+) HTTP/1\.#', $this->command, $values))
			return $values[1];
		return '?';
	}

	public function command(){
		return $this->command;
	}

	public function header(){
		return $this->header;
	}

	public function debug(){
		$lines = split("\n", $this->header_string);
		foreach($lines as $key=>$line)
			$lines [$key] = " > " . $line;
		return join("\n", $lines) . "\n";
	}

	# read header from client
	public function read($connection){
		if($this->command == null)
			$this->command = $connection->readline();
		$this->header_string = '';
		while(!$connection->eof()){
			$line = trim($connection->readline());
			$this->header_string .=  $line . "\n";
			$this->header[] = $line;
			if(strlen($line) == 0)
				break;
		}
	}

	# note : we should use Gtk::io_add_watch or a TcpConnection class to avoid io blocking
	public function make_proxy_http_1_0($connection, $proxy, $shutdown=true){
		
		$fp = fsockopen($proxy->host(), $proxy->port(), $errno, $errstr, 30);

		if (!$fp) {
			echo "$errstr ($errno)\n";
		} else {
			$out = "{$this->command}\r\n\r\n";
			$out .= join("\r\n", $this->header);

			if(!in_array('Connection: close', $this->header))
				$out .= "Connection: Close\r\n\r\n";
			fwrite($fp, $out);

			$content = '';
			while (!feof($fp)) {
				$data = fgets($fp,1024*32);
				# fwrite($sock, $data);
				$connection->write($data);
				$this->result .= $data;
			}
			fclose($fp);
			# echo "data = $data\n";
		}

		# need to shutdown connection from client (internet browser) if in 1.0 mode
		if($shutdown)
			$connection->shutdown();

		# transform textual (and raw data) to a more usable object

		$this->header = new HttpHeader(trim($this->command) . "\r\n" . join("\n", $this->header));
		$this->http_response = new HttpResponse($this->result);

		/*
		printf("\n%s - %s - %s\n", 
			date('H:i:s'),
			$this->header->command(), 
			$this->http_response->__toString()
		); */

		/*
		echo $this->debug();
		echo $this->http_response->debug();

		if(preg_match('#text/#', $this->http_response->content_type())
			|| $this->http_response->content_type() == 'application/x-javascript')
			echo $this->http_response->data() . "\n";
		*/

		return $this->http_response;
	}
}

?>
