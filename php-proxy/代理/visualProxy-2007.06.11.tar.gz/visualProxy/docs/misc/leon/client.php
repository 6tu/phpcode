<?php

error_reporting(E_ALL);

include_once('tcp.php');

$client = Tcp::client('127.0.0.1',1111);
$client->write(".1.1.1.\n.2.2.2.\n.3.3.3.\n.4.4.4.\n");
$client->set_receive_hook('receive');

gtk::main();

function receive($sock,$connection){
	$data = fgets($sock,1024);
	echo "from - ".stream_socket_get_name($sock,true)." - $data";
	$connection->write($data);
	echo "sleeping 3s\n";
	sleep(3);
	echo "done\n";
	exit(0);
}
