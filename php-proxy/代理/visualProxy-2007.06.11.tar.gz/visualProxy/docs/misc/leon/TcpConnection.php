<?php
class TcpConnection {
   
    protected $hook = null;
    protected $sock = null;
    protected $connected = false;
	protected $watch_ids;

    public function __construct($sock){
        echo "enter TcpConnection::__construct\n";
        $this->connected = true;
        $this->sock = $sock;
		$this->watch_ids = array();

        $this->watch_ids[] = Gtk::io_add_watch($sock,Gtk::IO_IN,array($this,"data_in"));
        $this->watch_ids[] = Gtk::io_add_watch($sock,Gtk::IO_HUP,array($this,"data_hup"));
        $this->watch_ids[] = Gtk::io_add_watch($sock,Gtk::IO_ERR,array($this,"data_hup"));
    }
   
    public function data_in($sock, $conditions){
        echo "enter TcpConnection::data_in\n";
        if ($this->hook) {
            call_user_func_array($this->hook, array($this->sock));
        }
        return $this->connected;
    }

    public function data_hup($sock, $conditions){
        echo "enter TcpConnection::data_hup\n";
        $this->connected = false;
        while(Gtk::events_pending()) Gtk::main_iteration();
        Gtk::timeout_add(1, array($this, 'destroy'));
        return $this->connected;
    }
   
    public function write($data){
        echo "enter TcpConnection::write\n";
        return fwrite($this->sock, $data, strlen($data));
    }
   
    public function close(){
        echo "enter TcpConnection::close\n";
        fclose($this->sock);
    }
   
    public function set_receive_hook($function){
        echo "enter TcpConnection::set_receive_hook\n";
        $oldhook = $this->hook;
        $this->hook = $hook;
        return $oldhook;
    }
   
    public function destroy(){
        echo "enter TcpConnection::destroy\n";
        return Tcp::destroy_object($this);
    }
   
    public function __destruct(){
        echo "enter TcpConnection::__destruct\n";
        fclose($this->sock);
    }
   
}

?>
