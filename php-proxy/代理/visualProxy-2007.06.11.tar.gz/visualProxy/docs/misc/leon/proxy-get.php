<?php


$request = 'GET http://mozfr.mozdev.org/start/1.7/ HTTP/1.1';
$host = 'sirius.stna.dgac.fr';

# sirius.stna.dgac.fr:8080

$fp = fsockopen($host, 8080, $errno, $errstr, 30);

if (!$fp) {
    echo "$errstr ($errno)<br />\n";
} else {
    $out = "$request\r\n";
    $out .= "Connection: Close\r\n\r\n";

    fwrite($fp, $out);
    while (!feof($fp)) {
        echo fgets($fp,1024*32);
    }
    fclose($fp);
}



?>
