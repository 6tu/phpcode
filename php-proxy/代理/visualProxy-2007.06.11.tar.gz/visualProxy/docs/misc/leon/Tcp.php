<?php

class Tcp {

    protected function __construct(){
    }

    static public function server($ip, $port){
        echo "enter Tcp::server\n";
        $sock = stream_socket_server("tcp://$ip:$port");
        if ($sock) {
            return new TcpServer($sock);
        }else{
            return null;
        }
    }

    static public function client($ip, $port){
        echo "enter Tcp::client\n";
        $sock = stream_socket_client("tcp://$ip:$port");
        if ($sock) {
            return new TcpConnection($sock);
        } else {
            return null;
        }
    }

    static public function destroy_object(&$object){
        echo "enter Tcp::destroy_object\n";
        $object = null;
        unset($object);
        return false;
    }
   
}

?>
