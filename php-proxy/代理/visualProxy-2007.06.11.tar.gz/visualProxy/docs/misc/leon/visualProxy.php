<?php

/**
 * Marc Quinton - may 2007
 * Licence : LGPL
 *
 * a pipe is a "channel" built to talk between your php script and an external command (shell, script or what ever)
 *  - you can "talk" to this command : just write to file descriptor  (see PipeIO::write()) (stdin)
 *  - you can read from this command,  (stdout)
 *  - there is also an channel for errors : stderr
 * 
 */


error_reporting(E_ALL);

include_once('Tcp.php');
include_once('TcpConnection.php');
include_once('TcpServer.php');

$server = Tcp::server('127.0.0.1',1111);
$server->set_accept_hook('new_connection');

gtk::main();

function new_connection($connection){
    global $cons;
    $cons[] = $connection;
    echo "new_connection ".get_class($connection)."\n";
	print_r($connection);
}

$client = Tcp::client('127.0.0.1',1111);
$client->write(".1.1.1.\n.2.2.2.\n.3.3.3.\n.4.4.4.\n");
$client->set_receive_hook('receive');
gtk::main();

function receive($sock,$connection){
$data = fgets($sock,1024);
echo "from - ".stream_socket_get_name($sock,true)." - $data";
$connection->write($data);
}


?>
