<?php

class TcpServer {

    protected $hook = null;
    protected $connected = false;
    protected $sock = null;

    public function __construct($sock){
        echo "enter TcpServer::__construct\n";
        $this->connected = true;
        Gtk::io_add_watch($sock,Gtk::IO_IN,array($this,"socket_accept"));
    }

    public function socket_accept($sock, $conditions){
        echo "enter TcpServer::socket_accept\n";
        $connection = new TcpConnection(stream_socket_accept($sock));
        $this->trigger_hook($connection);
        return $this->connected;
    }
   
    public function set_accept_hook($hook){
        echo "enter TcpServer::set_accept_hook\n";
        $oldhook = $this->hook;
        $this->hook = $hook;
        return $oldhook;
    }
   
    public function get_accept_hook(){
        echo "enter TcpServer::get_accept_hook\n";
        return $this->hook;
    }

    protected function trigger_hook($connection){
        echo "enter TcpServer::trigger_hook\n";
        if ($this->hook) {
            call_user_func_array($this->hook,array($connection));
        }
    }

    protected function __clone(){

    }
}

?>
