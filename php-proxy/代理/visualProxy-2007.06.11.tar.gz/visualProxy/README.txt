
visual Proxy : a graphical HTTP proxy with php-gtk2

Author : Marc Quinton
Licence : LGPL.

Restrictions :

 - POST not working now,
 - need to relay to a local proxy (use tinyproxy on linux), see lib/VirtualProxy.php for ports,
 - need to configure your browser un proxy HTTP/1.0 : see about:config -> search proxy

Todo :
 - implement non blocking IO for socket connections
 - support HTTP/1.1
 - support direction connections,
 - display image/* type
 - search and options
