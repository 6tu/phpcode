<html><head><STYLE>BODY { FONT-SIZE: 10pt; FONT-FAMILY: ���� }</STYLE></head><body>
<marquee scrolldelay='0' scrollAmount='1' direction=up  height="100" onmousemove='this.stop()' onmouseout='this.start()'>
<?php
/************��дURL�ĺ���***************/
 function long2str($v, $w){
     $len = count($v);
     $n = ($len - 1) << 2;
     if ($w){
         $m = $v[$len - 1];
         if (($m < $n - 3) || ($m > $n)) return false;
         $n = $m;
         }
     $s = array();
     for ($i = 0; $i < $len; $i++){
         $s[$i] = pack("V", $v[$i]);
         }
     if ($w){
         return substr(join('', $s), 0, $n);
         }
    else{
         return join('', $s);
         }
     }

 function str2long($s, $w){
     $v = unpack("V*", $s . str_repeat("\0", (4 - strlen($s) % 4) & 3));
     $v = array_values($v);
     if ($w){
         $v[count($v)] = strlen($s);
         }
     return $v;
     }

 function int32($n){
     while ($n >= 2147483648) $n -= 4294967296;
     while ($n <= -2147483649) $n += 4294967296;
     return (int)$n;
     }

 function xxtea_encrypt($str, $key){
     if ($str == ""){
         return "";
         }
     $v = str2long($str, true);
     $k = str2long($key, false);
     if (count($k) < 4){
         for ($i = count($k); $i < 4; $i++){
             $k[$i] = 0;
             }
         }
     $n = count($v) - 1;
    
     $z = $v[$n];
     $y = $v[0];
     $delta = 0x9E3779B9;
     $q = floor(6 + 52 / ($n + 1));
     $sum = 0;
     while (0 < $q--){
         $sum = int32($sum + $delta);
         $e = $sum >> 2 & 3;
         for ($p = 0; $p < $n; $p++){
             $y = $v[$p + 1];
             $mx = int32((($z >> 5 & 0x07ffffff) ^ $y << 2) + (($y >> 3 & 0x1fffffff) ^ $z << 4)) ^ int32(($sum ^ $y) + ($k[$p & 3 ^ $e] ^ $z));
             $z = $v[$p] = int32($v[$p] + $mx);
             }
         $y = $v[0];
         $mx = int32((($z >> 5 & 0x07ffffff) ^ $y << 2) + (($y >> 3 & 0x1fffffff) ^ $z << 4)) ^ int32(($sum ^ $y) + ($k[$p & 3 ^ $e] ^ $z));
         $z = $v[$n] = int32($v[$n] + $mx);
         }
     return long2str($v, false);
     }

function changurl($str){
    $url_str = 'http://' . $_SERVER['HTTP_HOST'] . substr($REQUEST_URI, 0, strrpos($REQUEST_URI, '/')) . '/';
    $str = (explode('<li>', $str));
    // print_r($str);
    $n = count($str);
    for($i = 1;$i < $n;$i++){
        $url = (explode('"', $str[$i]));
        $url[1] = $url_str . "index.php?q=" . encode_url($url[1]);
        $url = $url[0] . '"' . $url[1] . '"' . $url[2];
        $url = str_replace('<a', '<li><a', $url);
        return $url;
        }
    }
changurl($str);
function encode_url($url){
    return rawurlencode(base64_encode(xxtea_encrypt($url, '123')));
    }

function utf2html($str)
{
    $ret = "";
    $max = strlen($str);
    $last = 0;  
    for ($i=0; $i<$max; $i++) {
        $c = $str{$i};
        $c1 = ord($c);
        if ($c1>>5 == 6) {  
            $ret .= substr($str, $last, $i-$last); 
            $c1 &= 31; // remove the 3 bit two bytes prefix
            $c2 = ord($str{++$i}); 
            $c2 &= 63;  
            $c2 |= (($c1 & 3) << 6); 
            $c1 >>= 2; 
            $ret .= "&#" . ($c1 * 0x100 + $c2) . ";"; 
            $last = $i+1;
        }
        elseif ($c1>>4 == 14) {  
            $ret .= substr($str, $last, $i-$last); 
            $c2 = ord($str{++$i}); 
            $c3 = ord($str{++$i}); 
            $c1 &= 15; 
            $c2 &= 63;  
            $c3 &= 63;  
            $c3 |= (($c2 & 3) << 6); 
            $c2 >>=2; 
            $c2 |= (($c1 & 15) << 4); 
            $c1 >>= 4; 
            $ret .= '&#' . (($c1 * 0x10000) + ($c2 * 0x100) + $c3) . ';'; 
            $last = $i+1;
        }
    }
    $str=$ret . substr($str, $last, $i); 
return $str;
}
/************�����������������***************/

$file = file_get_contents('http://www.dongtaiwang.com/loc/phome.php ');
preg_match("'<a href=\":/\" target=\"_blank\">��</a>(.+)<!-- end #three_col_left -->'s", $file, $line);
$news = str_replace('<div id="content_list">', '', $line[1]);
$news = str_replace('<div id="title">ȫ�����ŵ������</div>', '', $news);
$news = str_replace(' -->', '', $news);
$news = str_replace('<br>', '', $news);
$news = str_replace('</div>', '', $news);
$news = changurl($news);
if(extension_loaded('mbstring')){
$news= mb_convert_encoding($news,'UTF-8',$char[0]);
}else{
$news = iconv('GBK','UTF-8//IGNORE//TRANSLIT',$news);
$news = utf2html($news); 
}
echo $news;
?>
</marquee>
</body></html>

















