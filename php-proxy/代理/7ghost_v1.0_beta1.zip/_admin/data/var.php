<?php return array (
  'a' => '|a|',
  'b' => '|b|',
);