<?php
include 'tor.class.php';

$tor = Tor::getInstance();

// check current users ip and
// return true or false
var_dump($tor->isTorActive());

// check ip of another user
var_dump($tor->setTarget('1.2.3.4')->isTorActive());
