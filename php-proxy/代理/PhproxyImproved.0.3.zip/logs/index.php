<?php
/*
Original Author: Abdullah Arif
Fork Author: Jeffery Schefke
License : GNU GENERAL PUBLIC LICENSE
phproxyimproved.com
*/

echo "404";
?>
