<?php
/*
Author: Jeffery Schefke
License : GNU General Public License
phproxyimproved.com
*/

//To Do: Implment into Admin Module

//FLV player title
$title = 'PHProxyImproved';

//Displays FLV download link
$download = true;

//Amount to buffer
$buffer = '20';

//Displays a video limit warning
$showlimmit = true;

//Defines the a video limit (Recomended amount of videos a user should watch to preserve bandwith"
$vlimmit = 5;

//Removes the YouTube homepage AD
$adspace ='<div id="ad_creative_1" class="ad-div mastad" style="z-index: 1;"> </div>';


?>
