<?php
//Basic Cookie Tunnel HTML Page Encrypt V1.0
//By Wei Shi <swnet@263.net> aka:vivalite

//Encryption base on Tomislav Sereg(tsereg@net.hr)'s Text Encryption. 
//This Softwere Applied to GNU GPL Licence

error_reporting(0);
$filename="defert_page.htm"; //default page
$blocksize=4096; //Working block size. 4096 is best for most situation. 
//======================================================
$incfilename="jsdec.htm"; //Don't change!
$userfile=str_replace(array('<', '>', '\\', '/', '='), '' ,$HTTP_GET_VARS['filename']);
if($HTTP_GET_VARS['filename']!="" && file_exists($userfile))$filename=$userfile;

$source="";
if(@!$fp=fopen($filename,"rb"))die($filename." :No such file!");
while(!feof($fp)) {
 $source.=fread($fp,4096);
}
fclose($fp);

$escsource=array();
$btlcount=0;
$grpcount=0;
$strlength=strlen($source);

for($count=0;$count<$strlength;$count++)
{
if(++$btlcount>$blocksize){
$btlcount=0;
$grpcount++;
}
 if(bin2hex($source[$count])>127 || bin2hex($source[$count])<32 || bin2hex($source[$count])==34 || bin2hex($source[$count])==39){
  @$escsource[$grpcount].="%".bin2hex($source[$count]);
  }else{
  @$escsource[$grpcount].=$source[$count];
  }
}

$randkey="";
$randsign="";
for($i=0;$i<8;$i++){
$randkey.=chr(rand(97,122));
}
for($i=0;$i<11;$i++){
$randsign.=chr(rand(97,122));
}



$afterenc='var content=Array('.ceil(filesize($filename)/$blocksize).');'."\r\n";
for($i=0;$i<count($escsource);$i++){
 $afterenc.="content[".$i."]='";
 $scp=new SecureCP;
 $scp->SecureContext($escsource[$i],$randsign,false);
 $escsource[$i]="";
 $scp->sc_secure($randkey);
 $afterenc.=$scp->strText."';\r\n";
 $scp=null;
}


$inchtml="";
$fp=fopen($incfilename,"rb");
while(!feof($fp)) {
 $inchtml.=fread($fp,4096);
}
fclose($fp);

setcookie("bbs_id", $randkey);
echo str_replace("{_CTGROUP_}",$afterenc,str_replace("{_SIGNTEXT_}",$randsign,$inchtml));
exit;
//===========================================
//===========================================

class SecureCP{


function permutationGenerator($nNumElements) {
$this->nNumElements = $nNumElements;
$this->antranspositions = array();
$k = 0;
for ($i = 0; $i < $nNumElements - 1; $i++)
for ($j = $i + 1; $j < $nNumElements; $j++)
$this->antranspositions[ $k++ ] = ( $i << 8 ) | $j;
// keep two positions as lo and hi byte!
$this->nNumtranspositions = $k;
}
//------------------------------------------
function fromCycle($anCycle) {
$anpermutation = array($this->nNumElements);
for ($i = 0; $i < $this->nNumElements; $i++) $anpermutation[$i] = $i;
for ($i = 0; $i < count($anCycle); $i++) {
$nT = $this->antranspositions[$anCycle[$i]];
$n1 = $nT & 255;
$n2 = ($nT >> 8) & 255;
$nT = $anpermutation[$n1];
$anpermutation[$n1] = $anpermutation[$n2];
$anpermutation[$n2] = $nT;
}
return $anpermutation;
}
//------------------------------------------
function password($strpasswd) {
$this->strpasswd = $strpasswd;
}
//------------------------------------------
function getHashValue() {
//security degraded!
$m = 9;
$a = 6;
$h = 0;
for ($i = 0; $i < strlen($this->strpasswd); $i++){ 
$h = ($h % $m) * $a + ord($this->strpasswd[$i]);}
return $h;
}
//------------------------------------------
function getpermutation() {
//security degraded!
$nNumElements = 13;
$nCYCLELENGTH = 6;
$nPatchPHPmath= 3;
$anCycleP=array();
$this->permutationGenerator($nNumElements);
$anCycle = array($nCYCLELENGTH);
$npred   = $this->getHashValue();
for ($i = 0; $i < $nCYCLELENGTH; $i++) {
$npred = 3 * $npred + 9;
$anCycle[$i] = $npred % $this->nNumtranspositions;
}
$anCycleP=$anCycle;
for($i=0;$i<$nPatchPHPmath;$i++)$anCycleP=array_merge($anCycleP,$anCycle);
for($i=0;$i<$nPatchPHPmath;$i++)array_pop($anCycleP);
return $this->fromCycle($anCycleP);
}
//------------------------------------------
function SecureContext($strText, $strSignature, $bEscape) {
if($strSignature){$this->strSIGNATURE = $strSignature;} else {$this->strSIGNATURE = '';}
if($bEscape){$this->bESCApE = $bEscape;} else {$this->bESCApE = false;}
$this->strText = $strText;
}
//------------------------------------------
function sc_escape($strToEscape) {
$strEscaped = '';
for ($i = 0; $i < strlen($strToEscape); $i++) {
$chT = $strToEscape[$i];
switch($chT) {
case '\r': $strEscaped .= '\\r'; break;
case '\n': $strEscaped .= '\\n'; break;
case '\\': $strEscaped .= '\\\\'; break;
default: $strEscaped .= $chT;
   }
}
return $strEscaped;
}
//------------------------------------------
function sc_unescape($strToUnescape) {
$strUnescaped = '';
$i = 0;
while ($i < strlen($strToUnescape)) {
$chT = $strToUnescape[$i++];
if ('\\' == $chT) {
$chT = $strToUnescape[$i++];
switch( $chT ) {
case 'r': $strUnescaped .= '\r'; break;
case 'n': $strUnescaped .= '\n'; break;
case '\\': $strUnescaped .= '\\'; break;
default: // not possible
   }
}
else $strUnescaped .= $chT;
}
return $strUnescaped;
}
//------------------------------------------
function sc_transliterate($btransliterate) {
$strDest = '';

$nTextIter  = 0;
$nTexttrail = 0;

while ($nTextIter < strlen($this->strText)) {
$strRun = '';
$cSkipped   = 0;
while ($cSkipped < 7 && $nTextIter < strlen($this->strText)) {
$chT = $this->strText[$nTextIter++];

if (strpos($strRun,$chT)===false) {
$strRun .= $chT;
$cSkipped = 0;
}
else $cSkipped++;
}
while ($nTexttrail < $nTextIter) {
$nRunIdx = strpos($strRun,$this->strText[$nTexttrail++]);
if ($btransliterate) {
$nRunIdx++;
if ($nRunIdx == strlen($strRun)) $nRunIdx = 0;
}
else {
$nRunIdx--;
if ($nRunIdx == -1) $nRunIdx += strlen($strRun);
}
$strDest .= $strRun[$nRunIdx];
   }
}
$this->strText = $strDest;
}
//------------------------------------------
function sc_encypher($anperm) {
$strEncyph = '';
$nCols     = count($anperm);
$nRows     = strlen($this->strText) / $nCols;
for ($i = 0; $i < $nCols; $i++) {
$k = $anperm[ $i ];
for ($j = 0; $j < $nRows; $j++) {
$strEncyph .= $this->strText[$k];
$k         += $nCols;
   }
}
$this->strText = $strEncyph;
}
//------------------------------------------
function sc_decypher($anperm) {
$nRows    = count($anperm);
$nCols    = strlen($this->strText) / $nRows;
$anRowOfs = array();
for ($i = 0 ; $i < $nRows; $i++) $anRowOfs[ $anperm[ $i ] ] = $i * $nCols;
$strplain = '';
for ($i = 0; $i < $nCols; $i++) {
for ($j = 0; $j < $nRows; $j++)
$strplain .= $this->strText[($anRowOfs[ $j ] + $i)];
}
$this->strText = $strplain;
}
//------------------------------------------
function sc_sign($nCols) {
if ($this->bESCApE) {
$this->strText      = $this->sc_escape($this->strText);
$this->strSIGNATURE = $this->sc_escape($this->strSIGNATURE);
}
$nTextLen     = strlen($this->strText) + strlen($this->strSIGNATURE);
$nMissingCols = $nCols - ($nTextLen % $nCols);
$strpadding   = '';  
if ($nMissingCols < $nCols)
for ($i = 0; $i < $nMissingCols; $i++) $strpadding .= ' ';
$x = strlen($this->strText);
$this->strText .=  $strpadding . $this->strSIGNATURE;
}
//------------------------------------------
function sc_unsign($nCols) {
if ($this->bESCApE) {
$this->strText      = $this->sc_unescape($this->strText);
$this->strSIGNATURE = $this->sc_unescape($this->strSIGNATURE);
}
if ('' == $this->strSIGNATURE) return true;
$nTextLen = strrpos($this->strText,$this->strSIGNATURE);
echo $this->strSIGNATURE;
if (-1 == $nTextLen) return false;
$this->strText = substr($this->strText,0,$nTextLen);
return true;
}
//------------------------------------------
function sc_secure($strpasswd) {
$this->password($strpasswd);	
$anperm = $this->getpermutation();
$this->sc_sign(count($anperm));
$this->sc_transliterate(true);
$this->sc_encypher($anperm);
}
//------------------------------------------
function sc_unsecure($strpasswd) {
$this->password($strpasswd);	
$anperm = $this->getpermutation();
$this->sc_decypher($anperm);
$this->sc_transliterate(false);
return $this->sc_unsign(count($anperm));
}
}
// End -->
?>