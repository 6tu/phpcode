<?php
         /*********************************************************\
        ******                     bblocked                    ******
       *****                                                     *****
      ****               Copyleft (C) 2007  bblocked               ****
     ***                                                             ***
    **  This program is free software; you can redistribute it and/or  **
   **   modify it under the terms of the GNU General Public License     **
  **    as published by the Free Software Foundation; either version 2   **
 **     of the License, or (at your option) any later version.            **
 **                                                                       **
 **     This program is distributed in the hope that it will be useful,   **
  **    but WITHOUT ANY WARRANTY; without even the implied warranty of   **
   **   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   **
    **  GNU General Public License for more details.                   **
     ***                                                             ***
      ****                                                         ****
       ****               http://www.bblocked.org/               *****
        ******                                                 ******
         \*********************************************************/

// Start user session and set PHP settings

session_start();

#error_reporting(0);
define('BB', true);

@ini_set('session.use_only_cookies', 1);
@ini_set('session.name', 'bblocked');
@ini_set('include_path', '.' . (PHP_OS=='WINNT' ? ';':':') . './includes');


// Obtain configurations from file

require_once('config.php');



if($_config['request_url']) {

	if(check_ip(gethostbyname(trim(substr($_config['request_url'], strpos($_config['request_url'], '://')+3), '\s/\\')), $_config['ip_range'], $blocked_ip)) {
	
		$messageBox->add('This IP address (<code>' . $blocked_ip . '</code>) has been blocked by the administrator.', 'Error');
		print_template(TEMPLATE_MAIN);
	}
	
	else {
	
		switch(strtolower($_config['request_page'])) {
	
			case $_config['page_frame_setup']:
				print_template(TEMPLATE_FRAME_SET);
				break;
				
			case $_config['page_frame_header']:
				print_template(TEMPLATE_FRAME_HEAD);
				break;
				
			case $_config['page_proxy']:
				require_once('rewrite.php');
				
				if(substr(trim($_config['request_url']), 0, 6) == 'ftp://') {
				
					require_once('proxy/ftp.php');
					new FTP($_config['request_url']);
				}
				
				else {
				
					require_once('proxy/http.php');
					new HTTP($_config['request_url']);
				}
				break;
	
			default:
				header("Location: {$_config['script_url_full']}?{$_config['arg_page']}=start&{$_config['arg_url']}=" . encode_url($_config['request_url']));
				break;
		}
	}
}

else if($_config['request_page'])
	require_once('cookies.php');
	
else
	print_template(TEMPLATE_MAIN);

?>
