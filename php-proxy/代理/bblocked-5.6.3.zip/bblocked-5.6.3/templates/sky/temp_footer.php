<?php
/* Do not remove, prevents direct file access */
if(!defined('BB'))
	die();
?>
	
					<p class="footer">
						bblocked Proxy Engine Copyright &copy; 2007 <a href="http://www.bblocked.org" target="_blank" onfocus="this.blur();">bblocked.org</a><br>
						bblocked provides no warranty and is redistributable under the <a href="http://creativecommons.org/licenses/GPL/2.0/" target="_blank" onfocus="this.blur();">CC-GNU
						General Public License</a><br /><br />
						
						<a href="http://www.mozilla.com/en-US/firefox/" title="Mozilla Firefox 2.0" target="_blank" onfocus="this.blur();"><img src="<TEMPLATE_DIR>/images/firefox2_80x15.gif" width="80" height="15" border="0" alt="" /></a>&nbsp;
						<a href="http://www.php.net/" title="PHP5 powered" target="_blank" onfocus="this.blur();"><img src="<TEMPLATE_DIR>/images/php5_80x15.gif" width="80" height="15" border="0" alt="" /></a>
					</p>