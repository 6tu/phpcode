<?php
/* Do not remove, prevents direct file access */
if(!defined('BB'))
	die();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
	
		<HEADER>

		<script defer>
			if(top.location != self.location)
				top.location.href = self.location;
			
			function furl() { document.f.<ARG_URL>.select(); }
		</script>
		
		<style type="text/css">
		p {
			margin: 0px 10px 10px 10px;
		}
		#box {
			width: 800px;
			margin: 0px auto;
			padding: 0px;
			text-align: left;
		}
		
		#left {
			width: 47px;
			padding: 0;
			float: left;
		}
		
		#content {
			width: 709px;
			padding: 0;
			float: left;
			background-color: #fff;
			overflow: hidden;
		}
		
		#right {
			width: 44px;
			padding: 0;
			float: left;
		}
		
		</style>
		
	</head>
	
	<body onLoad="furl();">

		<div id="box">
			<div id="head">
				<img src="<TEMPLATE_DIR>/images/imgs_01.jpg" alt="TopImg" style="padding:0;margin:0;vertical-align:top;" />
			</div>

			<div id="left">
				<img src="<TEMPLATE_DIR>/images/imgs_02.jpg" alt="LeftImg" style="float:left;padding:0;margin:0;vertical-align:top;" />
			</div>

			<div id="content">

				<a href="http://www.bblocked.org/" target="_blank" onfocus="this.blur();"><img src="<TEMPLATE_DIR>/images/imgs_03.jpg" alt="Logo" border="0" style="padding:0;margin:0;vertical-align:top;" /></a>
				<div style="background:url(<TEMPLATE_DIR>/images/imgs_05.jpg) no-repeat;height:200px;">

					<div style="padding:10px;text-align:center;">
						Welcome to bblocked, welcome to a world of possibilities. Using bblocked's state of the art technology you are able to
						obtain access to <strong>any</strong> site you want, whenever and whereever you want! Just type in your url below, and
						submit, you are now at your destination site! So what are you waiting for! Get started now!
					</div>

					<div style="padding:10px;text-align:center;">
						<form name="f" target="_top" method="post">
	
							URL <note>(i.e. google.com)</note>:
							<input class="addr" name="<ARG_URL>" type="text" value="<CURRENT_URL>" title="bblocked Proxy" size="50" onfocus="this.value=(this.value=='http://www.bblocked.org/')?'':this.value;this.select();" onblur="this.value=(this.value=='')?'http://www.bblocked.org/':this.value;var holder=this.value;this.value='';this.value=holder;" />
							<input name="submit" type="image" value="Go To Your Site" src="<TEMPLATE_DIR>/images/go.gif" title="Go!" style="padding:0;margin:0;vertical-align:top;"  onfocus="this.blur();" />
						</form>
					</div>
				</div>
			
				<div style="background:url(<TEMPLATE_DIR>/images/imgs_06.gif) no-repeat;height:63px;">
					<FOOTER>
				</div>
			
			</div>

			<div id="right">
				<img src="<TEMPLATE_DIR>/images/imgs_04.jpg" alt="LeftImg" style="float:left;padding:0;margin:0;vertical-align:top;" />
			</div>

			
		</div>
		
	</body>
</html>
