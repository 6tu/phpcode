<?php
/* Do not remove, prevents direct file access */
if(!defined('BB'))
	die();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>

		<HEADER>

		<style type="text/css">
			<!--
			body {
				background: url('<TEMPLATE_DIR>/images/frame_header_bg.gif') repeat-x top right;
				margin: 0px;
				padding: 0px;
				width: 100%:
				height: 58px;
				min-height: 58px;
				max-height: 58px;
			}
			form {
				display: inline;
			}
			.holder {
				width: 100%;
				border: 0;
				margin: 0px;
				padding: 0px;
			}
			.main {
				text-align: center;
				width: 100%;
				margin:0px;
				padding: 0px;
			}
			.main * {
				position: relative;
				margin: 0 auto 0 auto;
				vertical-align: middle;
			}
			.logoimg {
				position: absolute;
				left: 10px;
				margin: 0;
				padding: 0;
			}
			-->
		</style>
	</head>
	
	<body>

		<div class="holder">

			<a class="logoimg" href="<SCRIPT_URL>" target="_top" title="Return To Home" onFocus="this.blur();">
				<img src="<TEMPLATE_DIR>/images/frame_header_logo.gif" alt="" border="0" />
			</a>

			<form action="<SCRIPT_URL>" name="f" target="_top" method="post">
				
				<div class="main">
					<img src="<TEMPLATE_DIR>/images/frame_header_url.gif" alt="" border="0" />
					<input class="addr" style="background-color: #ccddcc;" name="<ARG_URL>" type="text" value="<REQUEST_URL>" title="bblocked Proxy" size="80" onFocus="this.select();" onBlur="var holder=this.value;this.value='';this.value=holder;" />
					<img style="cursor: pointer;" src="<TEMPLATE_DIR>/images/go_button.gif" title="Go!" border="0" onClick="document.f.submit();" />
				</div>
				
			</form>
			
		</div>
		
	</body>
	
</html>
