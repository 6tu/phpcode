<?php
/* Do not remove, prevents direct file access */
if(!defined('BB'))
	die();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
	
		<HEADER>

		<script defer>
			if(top.location != self.location)
				top.location.href = self.location;
			
			function furl() { document.f.<ARG_URL>.select(); }
		</script>
		
	</head>
	
	<body onLoad="furl();">

		<div width="100%" align="center">
			<div class="holder">
<div style="padding:21px 0 0 16px;width:100%;height:93px;">
<img src="<TEMPLATE_DIR>/images/logo_06.gif" alt="Logo" align="left" width="226" height="93">
</div>
				<div style="margin: 18px 0 18px 0;">
					Welcome to bblocked, welcome to a world of possibilities. Using bblocked's state of the art technology you are able to
					obtain access to <strong>any</strong> site you want, whenever and whereever you want! Just type in your url below, and
					submit, you are now at your destination site! So what are you waiting for! Get started now!
				</div>

				<div style="margin: 39px 0 24px 0;">
					<form action="<SCRIPT_URL>" name="f" target="_top" method="post" onSubmit="this.submit.disabled=true;this.submit.value='-Sending Request-';">

						URL <note>(i.e. google.com)</note>:
						<input class="addr" name="<ARG_URL>" type="text" value="http://www.bblocked.org/" title="bblocked Proxy" size="50" onFocus="this.value=(this.value=='http://www.bblocked.org/')?'':this.value;this.select();" onBlur="this.value=(this.value=='')?'http://www.bblocked.org/':this.value;var holder=this.value;this.value='';this.value=holder;" />
		<input name="submit" type="image" value="Go To Your Site" src="<TEMPLATE_DIR>/images/go.gif" alt="Go!" onFocus="this.blur();" style="padding:0;margin:0;vertical-align:top;">	

					</form>
				</div>

				<FOOTER>

			</div>
		</div>

	</body>
</html>
