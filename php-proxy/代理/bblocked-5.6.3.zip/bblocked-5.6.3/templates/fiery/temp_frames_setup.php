<?php
/* Do not remove, prevents direct file access */
if(!defined('BB'))
	die();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
	<head>

		<HEADER>

	</head>

	<frameset rows="58,*" cols="*" framespacing="0" frameborder="NO" border="0">
	
		<frame src="<SCRIPT_URL>?<ARG_PAGE>=<PAGE_FRAME_HEADER>&<ARG_URL>=<REQUEST_URL_ENCODED>" name="headerFrame" scrolling="NO" noresize />
		<frame src="<SCRIPT_URL>?<ARG_PAGE>=<PAGE_PROXY>&<ARG_URL>=<REQUEST_URL_ENCODED>" name="mainFrame" />
		
	</frameset>

	<noframes></noframes>
</html>
