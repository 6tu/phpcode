<?php
/* Do not remove, prevents direct file access */
if(!defined('BB'))
	die();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>

		<HEADER>

	</head>
	
	<body>

		<div align="center">

			<a class="logoimg" href="<SCRIPT_URL>" target="_top" title="Return To Home" onFocus="this.blur();" style="position: absolute;left: 10px;margin: 0;padding: 0;">
				Home
			</a>

			<form action="<SCRIPT_URL>" name="f" target="_top" method="post">
				
				<div class="main">
					URL: 
					<input class="addr" name="<ARG_URL>" type="text" value="<REQUEST_URL>" title="bblocked Proxy" size="80" onFocus="this.select();" onBlur="var holder=this.value;this.value='';this.value=holder;" />
					<a href="#" onClick="document.f.submit();">Go!</a>
				</div>
				
			</form>
			
		</div>
		
	</body>
	
</html>
