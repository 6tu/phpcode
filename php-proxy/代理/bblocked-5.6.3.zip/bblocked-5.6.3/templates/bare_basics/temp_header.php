<?php
/* Do not remove, prevents direct file access */
if(!defined('BB'))
	die();
?>
		<title><TITLE></title>

		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<meta name="robots" content="index, nofollow" />