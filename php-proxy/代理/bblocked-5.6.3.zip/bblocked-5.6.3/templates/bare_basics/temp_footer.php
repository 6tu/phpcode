<?php
/* Do not remove, prevents direct file access */
if(!defined('BB'))
	die();
?>
				<p>&nbsp;</p>

<p class="footer">
					bblocked Proxy Engine Copyleft &copy; 2007 <a href="http://www.bblocked.org" target="_blank" onFocus="this.blur();">bblocked.org</a><br>
					bblocked provides no warranty and is redistributable under the <a href="http://creativecommons.org/licenses/GPL/2.0/" target="_blank" onFocus="this.blur();">CC-GNU
				General Public License</a></p>
