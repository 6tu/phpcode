<?php
/* Do not remove, prevents direct file access */
if(!defined('BB'))
	die();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
	
		<HEADER>
		
		<script>
			function fuser() { document.f.<ARG_USER>.select(); }
		</script>
	</head>
	
	<body onLoad="fuser();">

		<div width="100%" align="center">
			<div class="holder">

				<div style="margin: 18px 0 18px 0; width: 100%;" align="center">
					<div class="auth">
						The page you are trying to access is protected via HTTP Authentication. You must supply a
						valid username and password combination to continue to the page requested.
					</div>
				</div>

				<div style="margin: 39px 0 24px 0;">
					<form name="f" method="post">

						<input name="<ARG_REALM>" type="hidden" value="<REALM_NAME>" />						
						<p><font color="#779977" size="4">Credentials for <REALM_NAME></font></p>
						
						<p>
							Username:<br>
							<input class="addr" name="<ARG_USER>" type="text" value="" title="Username for access to '<REALM_NAME>'" size="50" /><p>

							Password:<br>
							<input class="addr" name="<ARG_PASS>" type="password" value="" title="Password for access to '<REALM_NAME>'" size="50" /><p>
						</p>
						<p><input type="submit" value="Continue"></p>
						
					</form>
				</div>

				<FOOTER>

			</div>
		</div>

	</body>
</html>
