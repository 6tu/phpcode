<?php
         /*********************************************************\
        ******               bblocked Config File              ******
       *****                                                     *****
      ****               Copyleft (C) 2007  bblocked               ****
     ***                                                             ***
    **  This program is free software; you can redistribute it and/or  **
   **   modify it under the terms of the GNU General Public License     **
  **    as published by the Free Software Foundation; either version 2   **
 **     of the License, or (at your option) any later version.            **
 **                                                                       **
 **     This program is distributed in the hope that it will be useful,   **
  **    but WITHOUT ANY WARRANTY; without even the implied warranty of   **
   **   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   **
    **  GNU General Public License for more details.                   **
     ***                                                             ***
      ****                                                         ****
       ****               http://www.bblocked.org/               *****
        ******                                                 ******
         \*********************************************************/


/* Do not remove, prevents direct file access */
if(!defined('BB'))
	die();


// Configuration Vars

$_config =	array(


	// Apperance configurations

	'template_name'	=> 'sky',	// Name of the template to apply to bblocked pages
	'force_title'	=> 0,		// Force bblocked title on proxied pages
	'powered_by'	=> 1,		// Adds Powered by....

	'title'		=> 'bblocked -:- Unleash the Web',		// Title of bblocked pages
	'powered_by_text'	=> '{:title:} - Powered by bblocked',	// Place {:title:} where you wish the *real* title to go.


	// General configurations

	'suppress_errors'	=> 0,		// Force bblocked to suppress as many errors as it can... even warnings about register_globals or SSL
	'file_uploads'	=> 1,		// Allow users to upload files through the proxy
	'encode_urls'	=> 2,		// 0 = none; 1 = ROT13; 2 = base64; 3 = base35
	'rewrite_css'	=> 1,		// Atempt to rewrite CSS URLs
	'rewrite_script'	=> 1,		// Atempt to rewrite JavaScript/VBScript URLs
	'remove_script'	=> 0,		// Remove JavaScript/VBScript
	'unsecure_ssl'	=> 1,		// Allow users to make request to SSL hosts even if bblocked is not on an SSL server


	// HTTP Header configurations

	'user_agent'	=> '',	// Custom User-Agent (leave blank to uses the user's User-Agent)
	'remove_referer'	=> 0,		// Remove Referer header
	'accept_cookies'	=> 1,		// Allow sites to set cookies
	'session_cookies'	=> 1,		// Treat all cookie as session cookies
	
	
	// Global Cache settings (alpha)
	
	'enable_cache'	=> 0,			// Enable gobal caching
	'cache_time'	=> 360,		// Max time to keep caches (in minutes)
	'cache_dir'		=> 'cache',		// Directory to keep caches in


	// External HTTP Proxy settings

	'proxy_enable'	=> 0,			// Enable external HTTP proxing
	'proxy_host'	=> '127.0.0.1',	// IP address of external HTTP proxy server
	'proxy_port'	=> 8080,		// Server port of external HTTP proxy server


	// Argument names

	'arg_url'		=> 'url',		// Argument to carry URL requests
	'arg_page'		=> 'page',		// Argument to carry page requests
	'arg_realm'		=> 'realm',		// Argument to carry Basic HTTP realm name
	'arg_user'		=> 'username',	// Argument to carry Basic HTTP username
	'arg_pass'		=> 'password',	// Argument to carry Basic HTTP passowrd


	// Page type names

	'page_proxy'		=> 'data',		// Value for arg_page to define the proxy page
	'page_frame_setup'	=> 'start',		// Value for arg_page to define the frame setup page
	'page_frame_header'	=> 'header',	// Value for arg_page to define the frame header page


	// Keyword Search settings

	'search_keywords'		=> 1,		// Use Keyword searches when domain doesn't exist
							// Below is the URL to use for searches (* denotes where the search query is to be placed)
	'keyword_url'		=> 'http://www.google.com/search?hl=en&q=*&btnI=I%27m+Feeling+Lucky&meta=',


	// Bad Word Scrambler

	'scramble_bad_words'	=> 1,		// Scramble words that proxies would block | Use 2 for Base64
							// Below is the list of words to scramble (seperate with a comma)
	'bad_words'			=> 'arse,arsehole,asshole,bastard,berk,crap,cunt,dick,dickhead,fuck,fuckhead,gay,lesbian,penis,porn,pussy,sex,twat,wanker',


	// Set options allowed to users

	'allow_user_settings'	=> 0,		// Allow users to set options for surfing

	'user_settings'		=> array(
	
		'accept_cookies'	=> array(
			'type'	=> 'checkbox',
			'desc'	=> 'Accept cookies.',
			'force'	=> 0
			),
		'session_cookies' => array(
			'type'	=> 'checkbox',
			'desc'	=> 'Treat all cookies as session cookies.',
			'force'	=> 0
			),
		'force_title'	 => array(
			'type'	=> 'checkbox',
			'desc'	=> 'Remove page titles.',
			'force'	=> 0
			),
		'remove_script' 	=> array(
			'type'	=> 'checkbox',
			'desc'	=> 'Remove client-side scripts.',
			'force'	=> 0
			),
		'remove_referer'	=> array(
			'type'	=> 'checkbox',
			'desc'	=> 'Remove HTTP referer header.',
			'force'	=> 0
			),
		'encode_urls'	 => array(
			'type'	=> 'select',
			'values'	=> 'none|rot13|base64|base35',
			'desc'	=> 'URL encoding',
			'force'	=> 0
			)
		),


	// Disallow IP addresses (supports single IPs, CIDR notation and subnet)

	'ip_range'			=> array(

		// Example #1... block a private IP address
		// 10.13.5.36


		// Example #2... block some private networks (CIDR notation)
		// 192.168/16
		// 10/8


		// Example #2... block localhost IP range (subnet)
		// 127.0.0.1:255.0.0.0
	
	),


	// Directory locations

	'icon_dir'		=> 'icons',				// Location of Icon folder
	'template_dir'	=> 'templates',			// Location of Template folder
	'rewrite_dir'	=> 'includes/rewriters',	// Location of Rewrite folder


	// Automatic configurations - best to not mess with this

	'script_url'		=> $_SERVER['SCRIPT_NAME'],
	'script_url_full'		=> (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['SCRIPT_NAME'],
	'script_web_path'		=> dirname($_SERVER['SCRIPT_NAME']),
	'script_root_path'	=> str_replace('\\', '/', realpath('.')),
	'web_root_path'		=> ($_SERVER["REQUEST_URI"]) ? $_SERVER["REQUEST_URI"] : $_SERVER["SCRIPT_NAME"],
	'bblocked_ver'		=> '5.6.3',
	'bblocked_ver_nice'	=> 'bblocked v5.6.3',
	'bblocked_ver_full'	=> 'bblocked/5.6.3'
	);


// Clean up $_config & get request page/URL

if($_config['allow_user_settings']) {

	if(is_array($_SESSION['PREF'])) {
	
		foreach($_SESSION['PREF'] as $k=>$v)
			if((bool)$v != false)
				$_config[$k] = $v;
	}

	$float = 'left';
	$_config['user_options'] = '<div style="clear: both; text-align: left; position: relative; width: 500px; margin: 12px auto 16px auto;">';
	
	foreach($_config['user_settings'] as $k=>$v) {
	
		if(isset($_REQUEST[$k])) {
		
			$user_vars=1;
			break;
		}
	}
	
	foreach($_config['user_settings'] as $k=>$v) {
	
		if((bool)$v['force'] === true)
			continue;
		
		if($user_vars)
			$_config[$k] = $_SESSION['PREF'][$k] = ($_REQUEST[$k] == 'on' ? 1 : (isset($_REQUEST[$k]) ? $_REQUEST[$k] : 0));

		unset($_POST[$k], $_GET[$k]);

		$_config['user_options'] .= "<div style=\"float: {$float}; width: 50%\">";

		switch($v['type']) {

			case 'checkbox':
				$_config['user_options'] .= "<input type=\"checkbox\" name=\"{$k}\" title=\"{$v['name']}\"" . ($_config[$k] == 1 ? ' checked' : '') . "> {$v['desc']}<br />";

				break;

			case 'radio':
				$_config['user_options'] .= $v['desc'] . ': ';

				foreach(explode('|', $v['value']) as $vk=>$vv)
					$_config['user_options'] .= "<input type=\"radio\" name=\"{$k}\" value=\"{$vk}\"" . ($_config[$k] == $vk ? ' checked' : '') . ">{$vv}";

				break;

			case 'select':
				$_config['user_options'] .= "{$v['desc']}: <select name=\"{$k}\">";

				foreach(explode('|', $v['values']) as $vk=>$vv)
					$_config['user_options'] .= "<option value=\"{$vk}\"" . ($_config[$k] == $vk ? ' selected' : '') . ">{$vv}</option>";

				$_config['user_options'] .= '</select>';
				break;

			case 'text':
			default:
				$_config['user_options'] .= "{$v['desc']}<br /><input name=\"{$k}\" title=\"{$v['name']}\" />";

				break;
		}

		$_config['user_options'] .= "</div>\n";
		$float == 'left' ? $float = 'right' : $float = 'left';
	}

	$_config['user_options'] .= '</div>';
}

unset($_config['user_settings']);

$_config['cache_dir'] = realpath($_config['cache_dir']) . '/';
$_config['template_dir'] = $_config['template_dir'] . '/' . $_config['template_name'];

$_config['request_url'] = $_REQUEST[$_config['arg_url']];
$_config['request_page'] = $_REQUEST[$_config['arg_page']];


// Define Constants

define('TEMPLATE_FOOTER',	$_config['template_dir'] . '/temp_footer.php');
define('TEMPLATE_HEADER',	$_config['template_dir'] . '/temp_header.php');

define('TEMPLATE_MAIN',		$_config['template_dir'] . '/temp_main.php');
define('TEMPLATE_FRAME_SET',	$_config['template_dir'] . '/temp_frames_setup.php');
define('TEMPLATE_FRAME_HEAD',	$_config['template_dir'] . '/temp_frames_header.php');
define('TEMPLATE_FRAME_NONE',	$_config['template_dir'] . '/temp_no_frames.php');
define('TEMPLATE_HTTP_AUTH',	$_config['template_dir'] . '/temp_http_auth.php');

require_once('include.php');

?>