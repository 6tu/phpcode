<?php
         /*********************************************************\
        ******                bblocked FTP Class               ******
       *****                                                     *****
      ****               Copyleft (C) 2007  bblocked               ****
     ***                                                             ***
    **  This program is free software; you can redistribute it and/or  **
   **   modify it under the terms of the GNU General Public License     **
  **    as published by the Free Software Foundation; either version 2   **
 **     of the License, or (at your option) any later version.            **
 **                                                                       **
 **     This program is distributed in the hope that it will be useful,   **
  **    but WITHOUT ANY WARRANTY; without even the implied warranty of   **
   **   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   **
    **  GNU General Public License for more details.                   **
     ***                                                             ***
      ****                                                         ****
       ****               http://www.bblocked.org/               *****
        ******                                                 ******
         \*********************************************************/

require('base.php');


// Extend bblocked Proxy class for FTP support

class FTP extends Proxy {

	function FTP($url=false) {
		
		if(!($url ? $this->url_parse($url, $this->_url) : is_array($this->_url)))
			die('Could not parse URL.');
		
		$this->get_ftp_dir();
	}

	function get_ftp_dir() {
	
		global $_config;
		
		$ftp_id = @ftp_connect($this->_url['host'], $this->_url['port']) or report_errors($this->_url, 'connection', 'ftp_connect');
		@ftp_login($ftp_id, 'anonymous', 'no-reply@bblocked.org') or report_errors($this->_url, 'connection', 'ftp_login');
		
		if(@ftp_chdir($ftp_id, $this->_url['path'])) {
		
			$title = "Index of {$this->_url['path']}";
			$title = addcslashes(($_config['powered_by'] ? str_replace('{:title:}', ($title ? html_entity_decode(preg_replace("'([\r\n]+\s*)'", " ", $title)) : $url['full']), $_config['powered_by_text']) : $title), "'");
			$url = addcslashes($url['full'], "'");
		
			print <<<FTP
		
<script defer>
	<!-- script added by bblocked <http://www.bblocked.org/>

		// change title of document			
		top.document.title='{$title}';
		
		// change URL in bblocked form
		top.headerFrame.document.f.{$GLOBALS['_config']['arg_url']}.value='{$url}';
	-->
</script>


<h1>Index of {$this->_url['path']}</h1>
<pre><img src="{$GLOBALS['_config']['icon_dir']}/blank.gif" alt="     "> Name                    Last modified           Size     Description
<hr>

FTP;
			print("<img src=\"{$GLOBALS['_config']['icon_dir']}/back.gif\" alt=\"[DIR]\"> <a href=\"{$GLOBALS['_config']['script_url_full']}?{$GLOBALS['_config']['arg_page']}=proxy&{$GLOBALS['_config']['arg_url']}=" . encode_url('ftp://' . $this->_url['host'] . $this->_url['prev_dir']) . "\">Parent Directory</a>\n");
			
			foreach(ftp_nlist($ftp_id, '-dF .') as $path) {
				
				$name = $name_original = basename($path);
				
				if($path{strlen($path)-1} == '@') {
				
					$path{strlen($path)-1} = '/';
					$name{strlen($name)-1} = '/';
				}
				
				if(strlen($name) >= 24)
					$name = substr($name, 0, 21) . '...';
				
				if($path{strlen($path)-1} == '/') {
				
					print('<img src="' . $GLOBALS['_config']['icon_dir'] . '/folder.gif" alt="[DIR]" /> ');
					$size = '-';
				}
					
				else {
				
					$info = array();
					switch(substr($name, strrpos($name, '.')+1)) {
						
						case 'gif':
						case 'jpg':
						case 'jpeg':
						case 'png':
							$info['Image Document'] = '/image2.gif'; break;
						
						case 'js':
						case 'css':
						case 'txt':
						case 'htm':
						case 'html':
							$info['Text Document'] = '/text.gif'; break;
						
						default:
							$info['Unknown'] = '/unknown.gif'; break;
					}
					list($title, $img) = each($info);
					print('<img src="' . $GLOBALS['_config']['icon_dir'] . $img . '" alt="[' . $title . ']" /> ');
					
					$date = date("m-M-Y H:i", ftp_mdtm($ftp_id, $path));
					$size = ftp_size($ftp_id, $path);
					
					$size = ($size>4194304 ? '?' : round(($size<1024 ? $size : $size/1024), 1) . ($size<1024 ? 'b' : ($size<1048576 ? 'k' : ($size<2097152 ? 'M' : ($size<3145728 ? 'G' : 'T')))));
				}
				print("<a href=\"{$GLOBALS['_config']['script_url_full']}?{$GLOBALS['_config']['arg_page']}=proxy&{$GLOBALS['_config']['arg_url']}=" . encode_url($this->_url['full'] . ($this->_url['full']{strlen($this->_url['full'])-1} == '/' ? '':'/') . $path) . "\" title=\"{$name_original}\" onfocus=\"this.blur();\">{$name}</a> ");
				print(str_pad($date, 41-strlen($name), ' ', STR_PAD_LEFT));
				print(str_pad($size, 10, ' ', STR_PAD_LEFT));
				print("\n");
			}
			print("</pre><hr>");
		}
		
		else {
		
			if(@ftp_get($ftp_id, $GLOBALS['_config']['tmp_dir'] . 'bblocked_temp_ftp_file', rawurldecode($this->_url['path']), FTP_ASCII)) {
	
				$this->_page = file_get_contents($GLOBALS['_config']['tmp_dir'] . 'bblocked_temp_ftp_file');
				unlink($GLOBALS['_config']['tmp_dir'] . 'bblocked_temp_ftp_file');
				
				switch(strpos($this->_url['file'], '.') !== false ? strrpos($this->_url['file'], '.') : null) {
				
					case 'gif':
						$this->_headers['content-type'] = 'image/gif';
						break;
					
					case 'jpg':
					case 'jpeg':
						$this->_headers['content-type'] = 'image/jpeg';
						break;
					
					case 'png':
						$this->_headers['content-type'] = 'image/png';
						break;
					
					case 'htm':
					case 'html':
						$this->_headers['content-type'] = 'text/html';
						break;
				
					case null:
						$this->_headers['content-type'] = 'text/plain';
						break;
					
					default:
						header('Content-Type: application/octet-stream');
						header('Content-disposition: attachment; filename=' . basename($this->_url['path']));
						print($this->_page);
						exit(0);
				}
				
				$this->output_page();
			}
			
			else
				report_errors($this->_url, 'request', 'ftp_get');
		}
		
		$_SESSION['current_url'] = $this->_url['full'];
		return true;
	}
}

?>