<?php
         /*********************************************************\
        ******               bblocked HTTP Class               ******
       *****                                                     *****
      ****               Copyleft (C) 2007  bblocked               ****
     ***                                                             ***
    **  This program is free software; you can redistribute it and/or  **
   **   modify it under the terms of the GNU General Public License     **
  **    as published by the Free Software Foundation; either version 2   **
 **     of the License, or (at your option) any later version.            **
 **                                                                       **
 **     This program is distributed in the hope that it will be useful,   **
  **    but WITHOUT ANY WARRANTY; without even the implied warranty of   **
   **   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   **
    **  GNU General Public License for more details.                   **
     ***                                                             ***
      ****                                                         ****
       ****               http://www.bblocked.org/               *****
        ******                                                 ******
         \*********************************************************/

require('base.php');


// Extend bblocked Proxy class for HTTP support

class HTTP extends Proxy {

	function HTTP($url=false) {
		
		$this->_method = strtoupper($_SERVER['REQUEST_METHOD'] ? $_SERVER['REQUEST_METHOD'] : 'GET');
		
		if(!($url ? $this->url_parse($url, $this->_url) : is_array($this->_url)))
			die('Could not parse URL.');
		
		if((bool)$GLOBALS['_config']['enable_cache'] === true) {
		
			 if($this->read_cache($data) == true)
				$this->parse_response("HTTP/1.1 200 OK\r\n" . $data, false);
			
			else if($this->send_http_request($data))
				$this->parse_response($data, true);
				
			else
				report_errors($this->_url, 'connection', 'general');
			
			$this->output_page();
		}
		
		else {
		
			if($this->send_http_request($data))
				$this->parse_response($data, false) !== false ? $this->output_page() : '';
		}
	}
	
	function send_http_request(&$output) {
	
		if($GLOBALS['_config']['proxy_enable']) {
		
			$host = $GLOBALS['_config']['proxy_host'];
			$port = $GLOBALS['_config']['proxy_port'];
		}
		
		else {
		
			$host = $this->_url['host'];
			$port = $this->_url['port'];
		}
		
		if(false === ($this->_socket = @fsockopen(($this->_url['scheme'] === 'https' && $GLOBALS['_config']['ssl'] ? 'ssl://' : 'tcp://') . $this->_url['host'], $port, $errno, $errstr, 30))) {
			
			if($GLOBALS['_config']['search_keywords'] && gethostbyname($this->_url['host']) == $this->_url['host'])
				$this->HTTP(str_replace('*', urlencode(rtrim(str_replace('http://', '', $this->_url['full']), '/')), $GLOBALS['_config']['keyword_url']));
			
			else
				report_errors($this->_url, 'connection', 'http_notfound');
			
			return false;
		}
		
		$headers = $this->_method . ' ' . $this->_url['path'];
		
		if(isset($this->_url['query'])) {
		
			$headers .= '?';
			$query = preg_split("'([&;])'", $this->_url['query'], -1, PREG_SPLIT_DELIM_CAPTURE);
			for($i = 0, $count = count($query); $i < $count; $headers .= implode('=', array_map('urlencode', array_map('urldecode', explode('=', $query[$i])))) . (isset($query[++$i]) ? $query[$i] : ''), $i++);
		}
		
		$headers .= " HTTP/1.0\r\n";
		$headers .= "Host: {$this->_url['host']}{$this->_url['port_ext']}\r\n";
		$headers .= 'User-Agent: ' . ($GLOBALS['_config']['user_agent'] ? $GLOBALS['_config']['user_agent'] : ($_SERVER['HTTP_USER_AGENT'] ? $_SERVER['HTTP_USER_AGENT'] : 'Mozilla/5.0 (' . PHP_OS . '; en-US; +http://www.bblocked.org/) ' . $GLOBALS['_config']['bblocked_ver_full'])) . "\r\n";
		$headers .= 'Accept: ' . (isset($_SERVER['HTTP_ACCEPT']) ? $_SERVER['HTTP_ACCEPT'] : '*/*;q=0.1') . "\r\n";
		
		if(isset($_SERVER['HTTP_ACCEPT_CHARSET']))
			$headers .= "Accept-Charset: {$_SERVER['HTTP_ACCEPT_CHARSET']}\r\n";
		
		if(isset($_SERVER['HTTP_ACCEPT_LANGUAGE']))
			$headers .= "Accept-Language: {$_SERVER['HTTP_ACCEPT_LANGUAGE']}\r\n";
		
		if(isset($_SERVER['HTTP_IF_MODIFIED_SINCE']))
			$headers .= "If-Modified-Since: {$_SERVER['HTTP_IF_MODIFIED_SINCE']}\r\n";
		
		if(!$GLOBALS['_config']['remove_referer'] && isset($_SERVER['HTTP_REFERER']) && preg_match("'\Q" . $GLOBALS['_config']['script_url'] . "?\E.*?\Q" . $GLOBALS['_config']['arg_url'] . "=\E([^&]*)'", $_SERVER['HTTP_REFERER'], $matches))
			$headers .= 'Referer: ' . decode_url($matches[1]) . "\r\n";
		
		if(!empty($_COOKIE)) {
		
			$cookie = '';
			$auth = array();
		
			foreach($_COOKIE as $cookie_id=>$cookie_content) {
			
				$cookie_id		= explode(';', rawurldecode($cookie_id));
				$cookie_content	= explode(';', rawurldecode($cookie_content[0]));
				
				if($cookie_id[0] === 'COOKIE') {
				
					$cookie_id[3] = str_replace('_', '.', $cookie_id[3]);
		
					if(count($cookie_id) < 4 || ($cookie_content[1] == 'secure' && $this->_url['scheme'] != 'https'))
						continue;
		
					if((preg_match("'\Q" . $cookie_id[3] . "\E$'i", $this->_url['host']) || strtolower($cookie_id[3]) == strtolower('.' . $this->_url['host'])) && preg_match("'^\Q" . $cookie_id[2] . "\E'", $this->_url['path']))
						$cookie .= ($cookie != '' ? '; ' : '') . (empty($cookie_id[1]) ? '' : $cookie_id[1] . '=') . $cookie_content[0];
				}
			}
		}
		
		if(!empty($_SESSION['data']['cookies'])) {
		
			foreach($_SESSION['data']['cookies'] as $cookie_id=>$cookie_content) {
			
				$cookie_id		= explode(';', unserialize($cookie_id));
				$cookie_content	= explode(';', unserialize($cookie_content));
				
				$cookie_id[2] = str_replace('_', '.', $cookie_id[2]);
				
				if(count($cookie_id) < 3 || ($cookie_content[1] == 'secure' && $this->_url['scheme'] != 'https'))
					continue;

				if((preg_match("'\Q" . $cookie_id[2] . "\E$'i", $this->_url['host']) || strtolower($cookie_id[2]) == strtolower('.' . $this->_url['host'])) && preg_match("'^\Q" . $cookie_id[1] . "\E'", $this->_url['path']))
					$cookie .= ($cookie != '' ? '; ' : '') . (empty($cookie_id[0]) ? '' : $cookie_id[0] . '=') . $cookie_content[0];
			}
		}
		
		if(!empty($_SESSION['data']['auth'])) {
		
			foreach($_SESSION['data']['auth'] as $auth_id=>$auth_content) {
			
				$auth_id		= explode(';', unserialize($auth_id));
				$auth_content	= explode(';', unserialize($auth_content));
				
				$auth_id[1] = str_replace('_', '.', $auth_id[1]);
				
				if($this->_url['host'] . ':' . $this->_url['port'] === $auth_id[1])
					$this->_auth[$auth_id[0]] = $v;
			}
		}
		
		if($cookie != '') {
		
			$headers .= "Cookie: $cookie\r\n";
			$this->_no_cache = true;
		}
		
		if(isset($this->_realm))
			$basic_auth_realm = $this->_realm;
		
		if(isset($_POST[$GLOBALS['_config']['arg_user']], $_POST[$GLOBALS['_config']['arg_pass']])) {
		
			$basic_auth_realm	= $_POST[$GLOBALS['_config']['arg_realm']];
			$basic_auth_header	= base64_encode($_POST[$GLOBALS['_config']['arg_user']] . ':' . $_POST[$GLOBALS['_config']['arg_pass']]);
		}
		
		if(isset($this->_url['user'], $this->_url['pass']))
			$basic_auth_header = base64_encode($this->_url['user'] . ':' . $this->_url['pass']);

		if(!empty($basic_auth_header)) {
		
			$_SESSION['data']['auth']["{$basic_auth_realm};{$this->_url['host']}:{$this->_url['port']}"] = $basic_auth_header;
			$headers .= "Authorization: Basic {$basic_auth_header}\r\n";
		}
		
		else if(!empty($basic_auth_realm) && isset($this->_auth[$basic_auth_realm]))
			$headers  .= "Authorization: Basic {$this->_auth[$basic_auth_realm]}\r\n";

		else if(list($basic_auth_realm, $basic_auth_header) = each($this->_auth))
			$headers .= "Authorization: Basic {$basic_auth_header}\r\n";

		if($this->_method == 'POST') {
		
			if(!empty($_FILES) && $GLOBALS['_config']['file_uploads']) {
			
				$boundary = '----' . md5(uniqid(rand(), true));
				
				foreach(encode_post($_POST) as $k=>$v) {
				
					$post_data .= "--{$boundary}\r\n";
					$post_data .= "Content-Disposition: form-data; name=\"{$k}\"\r\n\r\n";
					$post_data .= urldecode($v) . "\r\n";
				}
				
				foreach(get_post_files($_FILES) as $k=>$info) {
				
					$post_data .= "--{$boundary}\r\n";
					$post_data .= "Content-Disposition: form-data; name=\"{$k}\"; filename=\"{$info['name']}\"\r\n";
					$post_data .= 'content-type: ' . (empty($info['type']) ? 'application/octet-stream' : $info['type']) . "\r\n\r\n";
		
					if(is_readable($info['tmp_name']))
						$post_data .= file_get_contents($info['tmp_name']);


					$post_data .= "\r\n";
				}
				
				$post_data .= "--{$boundary}--";
				$headers .= "content-type: multipart/form-data; boundary={$boundary}\r\n";
				$headers .= "Content-Length: " . strlen($post_data) . "\r\n\r\n" . $post_data;
			}
			

			else {
			
				foreach(encode_post($_POST) as $k=>$v)
					$post_data .= (!empty($post_data) ? '&' : '') . $k . '=' . $v;
				

				$headers .= "content-type: application/x-www-form-urlencoded\r\n";
				$headers .= "Content-Length: " . strlen($post_data) . "\r\n\r\n" . $post_data;
			}
			
			$post_data = '';
		}
		
		if(fwrite($this->_socket, $headers . "\r\n") !== false) {

			while(!feof($this->_socket))
				$output .= @fgets($this->_socket, 8192);
				
			return true;
		}
		
		return false;
	}
}

?>