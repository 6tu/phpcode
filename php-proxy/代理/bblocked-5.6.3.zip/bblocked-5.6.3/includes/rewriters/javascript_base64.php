<?php
         /*********************************************************\
        ******        bblocked Javascript Base64 Encoder       ******
       *****                                                     *****
      ****               Copyleft (C) 2007  bblocked               ****
     ***                                                             ***
    **  This program is free software; you can redistribute it and/or  **
   **   modify it under the terms of the GNU General Public License     **
  **    as published by the Free Software Foundation; either version 2   **
 **     of the License, or (at your option) any later version.            **
 **                                                                       **
 **     This program is distributed in the hope that it will be useful,   **
  **    but WITHOUT ANY WARRANTY; without even the implied warranty of   **
   **   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   **
    **  GNU General Public License for more details.                   **
     ***                                                             ***
      ****                                                         ****
       ****               http://www.bblocked.org/               *****
        ******                                                 ******
         \*********************************************************/

/* Do not remove, prevents direct file access */
if(!defined('BB'))
	die();

$output = '
// This code was originally written by Tyler Akins (http://rumkin.com)and has been placed in the
// public domain. Then altered by Steven Roddis (http://stevenroddis.com.au), and placed in the public domain.

var keyStr="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";function d(a){var b="";var c,chr2,chr3;var e,enc2,enc3,enc4;var i=0;a=a.replace(/[^A-Za-z0-9\+\/\=]/g,"");do{e=keyStr.indexOf(a.charAt(i++));enc2=keyStr.indexOf(a.charAt(i++));enc3=keyStr.indexOf(a.charAt(i++));enc4=keyStr.indexOf(a.charAt(i++));c=(e<<2)|(enc2>>4);chr2=((enc2&15)<<4)|(enc3>>2);chr3=((enc3&3)<<6)|enc4;b=b+String.fromCharCode(c);if(enc3!=64){b=b+String.fromCharCode(chr2)}if(enc4!=64){b=b+String.fromCharCode(chr3)}}while(i<a.length);return b}

eval(d("'.base64_encode($output).'"));
';
?>