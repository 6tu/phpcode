<?php
         /*********************************************************\
        ******            bblocked Template class              ******
       *****                                                     *****
      ****               Copyleft (C) 2007  bblocked               ****
     ***                                                             ***
    **  This program is free software; you can redistribute it and/or  **
   **   modify it under the terms of the GNU General Public License     **
  **    as published by the Free Software Foundation; either version 2   **
 **     of the License, or (at your option) any later version.            **
 **                                                                       **
 **     This program is distributed in the hope that it will be useful,   **
  **    but WITHOUT ANY WARRANTY; without even the implied warranty of   **
   **   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   **
    **  GNU General Public License for more details.                   **
     ***                                                             ***
      ****                                                         ****
       ****               http://www.bblocked.org/               *****
        ******                                                 ******
         \*********************************************************/


/* Do not remove, prevents direct file access */
if(!defined('BB'))
	die();



// Class containing bblocked Template engine

class Template {

	function Template($file) {
	
		global $messageBox, $_config;
		
		if(!file_exists($file))
			return false;
		
		$output = $this->parse_file($file);

		$output = preg_replace("'[\x20\t]*\<HEADER\>[\x20\t]*'", $this->parse_file(TEMPLATE_HEADER), preg_replace("'[\x20\t]*\<FOOTER\>[\x20\t]*'", $this->parse_file(TEMPLATE_FOOTER), $output));
		$output = str_replace('<CURRENT_URL>', htmlentities((isset($_SESSION['current_url']) ? $_SESSION['current_url'] : 'http://www.bblocked.org/'), ENT_QUOTES), $output);
			
		foreach($_config as $k=>$v)
			if((string) $v === $v)
                $output = str_replace(strtoupper("<{$k}>"), htmlentities($v, ENT_QUOTES), $output);
		
		if($file == TEMPLATE_MAIN) {
		
			if($_config['allow_user_settings'] == true)
				$output = preg_replace("'(<\s*\/\s*form\s*>)'i", "{$_config['user_options']}\\1", $output);
		
			if(count($messageBox->_messages) >= 1) {
			
				list($top, $bottom) = preg_split("'<body'i", $output);
				
				$pos = strpos($bottom, ">");
				$output = $top . "<body" . substr($bottom, 0, $pos+1) . $messageBox->output() . substr($bottom, $pos+1);
			}
		}
	
		print($output);
	}
	
	function parse_file($file) {
	
		if(is_file($file)) {
		
			ob_start();
			include($file);
			$output = ob_get_contents();
			ob_end_clean();
			return $output;
		}
		return false;
	}
	
}

?>
