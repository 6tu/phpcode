<?php
         /*********************************************************\
        ******          bblocked Error Reporting Class         ******
       *****                                                     *****
      ****               Copyright (C) 2007  bblocked              ****
     ***                                                             ***
    **  This program is free software; you can redistribute it and/or  **
   **   modify it under the terms of the GNU General Public License     **
  **    as published by the Free Software Foundation; either version 2   **
 **     of the License, or (at your option) any later version.            **
 **                                                                       **
 **     This program is distributed in the hope that it will be useful,   **
  **    but WITHOUT ANY WARRANTY; without even the implied warranty of   **
   **   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   **
    **  GNU General Public License for more details.                   **
     ***                                                             ***
      ****                                                         ****
       ****               http://www.bblocked.org/               *****
        ******                                                 ******
         \*********************************************************/

/* Do not remove, prevents direct file access */
if(!defined('BB'))
	die();




// bblocked Error Reporting engine

function exit_on_error($url, $class, $type, $die) {
	
	global $_config;
	
	$errors = array(
	
				'connection' => array(
				
					general		=> 'An error occured while trying to connect to the page you requested.',
					
					ftp_connect		=> 'Could not connect to the FTP server (<i>'.$url['base'].'</i>).',
					ftp_login		=> 'Anonymous login not permited on this server.',
					
					http_notfound	=> 'The web site you requested could not be found.',
				),
				
				
				'request'	=> array(
				
					ftp_get		=> 'An error occured while atempting to fetch <i>' . $url['file'] . '</i> from the server.',
				)
	);
	
	$safe_url = addcslashes($url['full'], "'");
	
	print <<<ERROR
	
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<title>{$_config['title']}</title>

		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
		<meta name="robots" content="index, nofollow" />

		<link href="{$_config['template_dir']}/stylesheet.css" rel="stylesheet" type="text/css" />
		<link rel="shortcut icon" type="image/ico" href="{$_config['template_dir']}/favicon.ico" />
		<script>
			<!--
				top.headerFrame.document.f.{$_config['arg_url']}.value='{$safe_url}';
			-->
		</script>
	</head>
	
	<body style="margin: 2cm;">

	{$errors[$class][$type]}

	</body>
</html>

ERROR;
	
	$die ? die : exit(1);
}

?>
