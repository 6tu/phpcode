<?php
         /*********************************************************\
        ******              bblocked Include file              ******
       *****                                                     *****
      ****               Copyleft (C) 2007  bblocked               ****
     ***                                                             ***
    **  This program is free software; you can redistribute it and/or  **
   **   modify it under the terms of the GNU General Public License     **
  **    as published by the Free Software Foundation; either version 2   **
 **     of the License, or (at your option) any later version.            **
 **                                                                       **
 **     This program is distributed in the hope that it will be useful,   **
  **    but WITHOUT ANY WARRANTY; without even the implied warranty of   **
   **   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   **
    **  GNU General Public License for more details.                   **
     ***                                                             ***
      ****                                                         ****
       ****               http://www.bblocked.org/               *****
        ******                                                 ******
         \*********************************************************/


/* Do not remove, prevents direct file access */
if(!defined('BB'))
	die();





// Useless Features in PHP

if((bool)$_config['suppress_errors'] != true) {

	if(@ini_get('register_globals'))
		die('Register Globals is ON!');

	if(@ini_get('magic_quotes_sybase'))
		die('magic_quotes_sybase is ON!');
}

else
	error_reporting(0);

if(get_magic_quotes_runtime())
	set_magic_quotes_runtime(0);




// Prevent Magic Quotes from affecting scripts, regardless of server settings

// Make sure when reading file data,
// PHP doesn't "magically" mangle backslashes!

if(get_magic_quotes_gpc()) {

	function stripslashes_array($data) {
	
		if(is_array($data)) {
		
			foreach($data as $key=>$value)
				$data[$key] = stripslashes_array($value);

			return $data;
		}
		
		else
			return stripslashes($data);
	}
	/*
	All these global variables are slash-encoded by default,
	because    magic_quotes_gpc is set by default!
	(And magic_quotes_gpc affects more than just $_GET, $_POST, and $_COOKIE)
	*/
	$_SERVER         =stripslashes_array($_SERVER);
	$_GET            =stripslashes_array($_GET);
	$_POST           =stripslashes_array($_POST);
	$_COOKIE         =stripslashes_array($_COOKIE);
	$_FILES          =stripslashes_array($_FILES);
	$_ENV            =stripslashes_array($_ENV);
	$_REQUEST        =stripslashes_array($_REQUEST);
	$HTTP_SERVER_VARS=stripslashes_array($HTTP_SERVER_VARS);
	$HTTP_GET_VARS   =stripslashes_array($HTTP_GET_VARS);
	$HTTP_POST_VARS  =stripslashes_array($HTTP_POST_VARS);
	$HTTP_COOKIE_VARS=stripslashes_array($HTTP_COOKIE_VARS);
	$HTTP_POST_FILES =stripslashes_array($HTTP_POST_FILES);
	$HTTP_ENV_VARS   =stripslashes_array($HTTP_ENV_VARS);

	if(isset($_SESSION)) {
	
		$_SESSION         =stripslashes_array($_SESSION, '');
		$HTTP_SESSION_VARS=stripslashes_array($HTTP_SESSION_VARS, '');
	}
	/*
	The $GLOBALS array is also slash-encoded, but when all the above are
	changed, $GLOBALS is updated to reflect those changes.  (Therefore
	$GLOBALS should never be modified directly).  $GLOBALS also contains
	infinite recursion, so it's dangerous...
	*/
}





// Functions

function report_errors() {

	require('error.php');
	
	list($url, $class, $type, $die) = array_pad(func_get_args(), 4, null);
	exit_on_error($url, $class, (is_null($type) ? 'general' : $type), (is_null($die) ? false : $die));
}

function print_template($template) {

	require('template.php');
	new Template($template);
}

function check_ip($ip, $range_array, &$blocked) {

	foreach($range_array as $v) {
		
		if(strstr($v, '/')) {
		
			$range = explode('/', $v);
		
			$padding = str_repeat(".0", 3 - substr_count($range[0], '.'));
			$range[0] .= $padding;
			
			list($a, $b, $c, $d) = explode('.', $range[0]);
			
			$i = ($a << 24) + ($b << 16) + ($c << 8) + $d;
			$mask = $range[0] == 0 ? 0 : (~0 << (32 - $range[0]));
			
			list($a, $b, $c, $d) = explode('.', $ip);
			$ip = ($a << 24) + ($b << 16) + ($c << 8) + $d;
			
			if($ip >= ($i & $mask) && $ip <= ($i | (~$mask & 0xFFFFFFFF))) {
				$blocked = $v;
				return true;
			}
		}
		
		else if(strstr($v, ':')) {
		
			$range = explode(':', $v);
			
			$padding = str_repeat(".0", 3 - substr_count($range[0], '.'));
			$range[0] .= $padding;
			
			if((ip2long($ip) & ip2long($range[1])) == (ip2long($range[0]) & ip2long($range[1]))) {
				$blocked = $v;
				return true;
			}
		}
		
		else
			if($ip == $v) {
				$blocked = $v;
				return true;
			}
	}
	return false;
}

if($_config['encode_urls'] == 1) {

	function encode_url($url) { return rawurlencode(str_rot13($url)); }
	function decode_url($url) { return str_replace(array('&amp;', '&#38;'), '&', str_rot13(rawurldecode($url))); }
}

else if($_config['encode_urls'] == 2) {

	function encode_url($url) { return rawurlencode(base64_encode($url)); }
	function decode_url($url) { return str_replace(array('&amp;', '&#38;'), '&', base64_decode(rawurldecode($url))); }
}

else if($_config['encode_urls'] == 3) {

	function encode_url($url) {
	
		foreach(preg_split("''", $url) as $char) $out[] = base_convert(ord($char), 10, 35);
		return rawurlencode(implode(':', $out));
	}
	
	function decode_url($url) {
	
		foreach(explode(':', rawurldecode($url)) as $char) $out .= chr(base_convert(str_replace(array('&amp;', '&#38;'), '&', $char), 35, 10));
		return trim($out);
	}
}

else {

	function encode_url($url) { return rawurlencode($url); }
	function decode_url($url) { return str_replace(array('&amp;', '&#38;'), '&', rawurldecode($url)); }
}

function is_url($url) {

	if(preg_match("'^(ht|f)tps?://((\w+\.)+\w{2,}/?|((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.?){4})'i", trim($url)))
		return true;
	
	return false;
}

function add_cookie($name, $value, $expires = 0) {
	return rawurlencode(rawurlencode($name)) . '=' . rawurlencode(rawurlencode($value)) . (empty($expires) ? '' : '; expires=' . gmdate('D, d-M-Y H:i:s \G\M\T', $expires)) . '; path=/; domain=.' . $_SERVER['HTTP_HOST'];
}

function encode_post($array, $parent_key=null) {

	$temp = array();
	foreach($array as $k=>$v) {
	
		$k = isset($parent_key) ? sprintf('%s[%s]', $parent_key, urlencode($k)) : urlencode($k);
		
			if(is_array($v))
				$temp = array_merge($temp, encode_post($v, $k));
			
			else
				$temp[$k] = urlencode($v);
	}
	return $temp;
}

function get_post_files($array, $parent_key=null) {

	$temp = array();
	foreach($array as $k=>$v) {
	
			$k = isset($parent_key) ? sprintf('%s[%s]', $parent_key, urlencode($k)) : urlencode($k);
			
			if(is_array($value))
					$temp = array_merge_recursive($temp, get_post_files($v, $k));

			else if(preg_match("'^([^\[\]]+)\[(name|type|tmp_name)\]'", $k, $m))
					$temp[str_replace($m[0], $m[1], $key)][$m[2]] = $value;
	}
	return $temp;
}





// Classes

if((bool)$_config['suppress_errors'] != true) {

	class messageBox {

		var $_messages;
		var $_num_messages;
		
		function messageBox() {
			$this->_messages = array();
		}
		
		function add($text, $type="Warning") {
		
			$_num_messages = count($this->_messages);
			
			$this->_messages[$this->_num_messages] .= "		<tr class=\"" . $type . "Message\">\n";
			$this->_messages[$this->_num_messages] .= "			<td class=\"" . $type . "Message\">&nbsp;" . $type . ": " . $text . "</td>\n";
			$this->_messages[$this->_num_messages] .= "		</tr>\n";
		}
		
		function output() {
		
			$out = "\n\n<div class=\"messageBox\">\n";
			$out .= "  <table width=\"100%\" cellspacing=\"0\" cellpadding=\"2\" border=\"0\">\n";
			$out .= implode('', $this->_messages) . "\n";
			$out .= "  </table>\n";
			$out .= "</div>\n";
			
			return $out;
		}
	}
}




// Gather enviorment variables

if(function_exists('sys_get_temp_dir'))
	$_config['tmp_dir'] = sys_get_temp_dir();

else if(!empty($_ENV['TMP']))
	$_config['tmp_dir'] = $_ENV['TMP'];

else if(!empty($_ENV['TMPDIR']))
	$_config['tmp_dir'] = $_ENV['TMPDIR'];

else if(!empty($_ENV['TEMP']))
	$_config['tmp_dir'] = $_ENV['TEMP'];

else {

	if($tmp_file = tempnam(md5(uniqid(rand(), TRUE)), '')) {
	
		$_config['tmp_dir'] = realpath(dirname($tmp_file));
		unlink($tmp_file);
	}	
}


if($_config['request_url']) {

	if($_config['request_page'])
		$_config['request_url'] = decode_url($_config['request_url']);

	$_config['request_url_encoded'] = encode_url($_config['request_url']);
	$_config['request_url'] = (strpos($_config['request_url'], "://") === false ? 'http://':'') . $_config['request_url'];
}

else if(strlen($_SERVER['PHP_SELF']) > strlen($_config['script_url'])) {

	strstr($_SERVER['REQUEST_URI'], '?') ? $temp_url = explode('?', str_replace($_config['script_url'] . '/', '', $_SERVER['REQUEST_URI']), 2) : $temp_url[0] = str_replace($_config['script_url'] . '/', '', $_SERVER['REQUEST_URI']);
	$temp_url[0] = decode_url($temp_url[0]);
	
	$_config['request_url'] = substr($temp_url[0], 0, strpos($temp_url[0], '/')) . '://' . substr($temp_url[0], strpos($temp_url[0], '/')+1) . ($temp_url[1] ? '?' . (strtolower($_SERVER['REQUEST_METHOD']) == 'post' ? decode_url($temp_url[1]) : $temp_url[1]) : '');
	$_config['request_page'] = 'proxy';
}

$messageBox = new messageBox();
$loaded_extensions = get_loaded_extensions();

if(array_search('openssl', $loaded_extensions) && version_compare(PHP_VERSION, '4.3.0', '>='))
	$_config['ssl'] = true;

else if((bool)$_config['suppress_errors'] != true)
	$messageBox->add('SSL support disabled. <code>(OpenSSL extension no loaded.)</code>');
	
if(array_search('ftp', $loaded_extensions))
	$_config['ftp'] = true;

else if((bool)$_config['suppress_errors'] != true)
	$messageBox->add('FTP support disabled. <code>(FTP extension no loaded.)</code>');


if(array_search('zlib', $loaded_extensions)) {

	$_config['zlib'] = true;
	!ini_get('zlib.output_compression') ? ob_start('ob_gzhandler') : ob_start();
}

else
	ob_start();


?>
