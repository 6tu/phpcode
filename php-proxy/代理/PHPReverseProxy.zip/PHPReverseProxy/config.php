<?php
//域名映射表
$domain_map = array(
	'tools.deloby.com' => 'robinflying.appspot.com',
	);
//最大请求重试次数
define('MAX_FETCH_RETRY', 3);
//代理服务器的user-agent
define('USER_AGENT', 'PHPReverseProxy');
//http请求超时时间
define('MAX_TIMEOUT', 30);