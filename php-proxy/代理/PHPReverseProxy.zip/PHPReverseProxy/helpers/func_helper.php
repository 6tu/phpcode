<?php
function get_bloginfo($args = ''){
	if('url' === $args){
		return 'http://'.$_SERVER['HTTP_HOST'].'/';
	}
	return '';
}