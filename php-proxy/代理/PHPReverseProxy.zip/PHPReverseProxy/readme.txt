/**
* 脚本：php反向代理
* 作者：周乃明(robinflying@gmail.com)
* 作者博客：www.zhounaiming.com
* 使用说明：在congfig.php里设置域名映射
* 备注：从朱华<54zhua@gmail.com>的脚本里copy了两个函数：getRealIP()，getallheaders()
* 备注：使用wordpress的http类来发送HEAD,GET,POST请求
* 版本：1.0,这只是简单实现第一个版本，肯定有bug，使用这个脚本的朋友请帮忙改进
* 待添加的功能:301 302跳转，文件上传，支持cookie等
*/