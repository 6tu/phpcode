<?php    
/**
* 脚本：php反向代理
* 作者：周乃明(robinflying@gmail.com)
* 作者博客：www.zhounaiming.com
* 使用说明：在congfig.php里设置域名映射
* 备注：从朱华<54zhua@gmail.com>的脚本里copy了两个函数：getRealIP()，getallheaders()
* 备注：使用wordpress的http类来发送HEAD,GET,POST请求
* 版本：1.0,这只是简单实现第一个版本，肯定有bug，使用这个脚本的朋友请帮忙改进
* 待添加的功能:301 302跳转，文件上传，支持cookie等
*/
error_reporting( E_CORE_ERROR | E_CORE_WARNING | E_COMPILE_ERROR | E_ERROR | E_WARNING | E_PARSE | E_USER_ERROR | E_USER_WARNING );
define('ABSPATH', dirname(__FILE__) . '/');
require(ABSPATH . 'config.php');
require(ABSPATH . 'helpers/func_helper.php');
require(ABSPATH . 'helpers/wp_class_http_helper.php');
require(ABSPATH . 'helpers/wp_classes_helper.php');
require(ABSPATH . 'helpers/wp_functions_helper.php');
require(ABSPATH . 'helpers/wp_http_helper.php');
require(ABSPATH . 'helpers/wp_plugin_helper.php');

function send_error_header($status_code,$msg){
	status_header($status_code);
	echo $msg;	
	die;
}

function getRealIP()
 {
     if ( $_SERVER[HTTP_CDNUNION_FOR] != ” ){   
         $onlineip = $_SERVER[HTTP_CDNUNION_FOR];   
    }elseif(getenv('HTTP_CLIENT_IP')) {    
        $onlineip = getenv('HTTP_CLIENT_IP');   
    } elseif(getenv('HTTP_X_FORWARDED_FOR')) {    
        $onlineip = getenv('HTTP_X_FORWARDED_FOR');   
    } elseif(getenv('REMOTE_ADDR')) {    
        $onlineip = getenv('REMOTE_ADDR');   
     } else {    
         $onlineip = $_SERVER['REMOTE_ADDR'];   
     }   
     return $onlineip;   
 } 

if(!function_exists('getallheaders')){
	function getallheaders(){
		$headers = array();  
		foreach ($_SERVER as $key => $value) {  
			if ('HTTP_' == substr($key, 0, 5)) {  
				$headers[str_replace('_', '-', substr($key, 5))] = $value;  
			}
		}
		unset($headers['HOST']);
		if (isset($_SERVER['PHP_AUTH_DIGEST'])) {  
			$headers['AUTHORIZATION'] = $_SERVER['PHP_AUTH_DIGEST'];  
		} 
		elseif (isset($_SERVER['PHP_AUTH_USER']) && isset($_SERVER['PHP_AUTH_PW'])) {  
			$headers['AUTHORIZATION'] = base64_encode($_SERVER['PHP_AUTH_USER'] . ':' . $_SERVER['PHP_AUTH_PW']);  
		}  
		if ( !empty($_SERVER['CONTENT_LENGTH'])) {  
			$headers['CONTENT-LENGTH'] = $_SERVER['CONTENT_LENGTH'];  
		}
		if ( !empty($_SERVER['CONTENT_TYPE'])) {  
			$headers['CONTENT-TYPE'] = $_SERVER['CONTENT_TYPE'];  
		}  
		$headers['CLIENT-IP'] = getRealIP();  
		$headers['X-FORWARDED-FOR'] = getRealIP(); 	
		return $headers;
	}
}

$orig_method = $_SERVER['REQUEST_METHOD'];
$orig_uri = $_SERVER['REQUEST_URI'];

$orig_headers = getallheaders();
//$orig_headers = apache_response_headers();
$orig_postdata = $_POST;
$orig_domain = $_SERVER['SERVER_NAME'];
if(array_key_exists($orig_domain,$domain_map)){
	$target_domain = $domain_map[$_SERVER['SERVER_NAME']];
	$new_url = 'http://'.$target_domain.'/'.$orig_uri;
}
else{
	send_error_header(404,'domain not mapped');
}

if(!in_array($orig_method,array('GET','POST','HEAD'))){
	send_error_header(590,'method not allowed');
}

if(is_ssl()){
	send_error_header(590,'Unsupported Scheme');
}

$new_headers = array();
$content_length = 0;
foreach($orig_headers as $name=>$value){
	$name = trim(name);
	$value = trim($value);
	$nl = strtolower($name);
	$new_headers['name'] = 'value';
	if($nl == 'content-length')
		$content_length = (int)$value;
}
$new_headers["Connection"] = 'close';
$args = array('headers' =>$new_headers,'user-agent'=>USER_AGENT,'timeout' =>MAX_TIMEOUT,'sslverify'=>false,'redirection' => 5);
for($i=0;$i<MAX_FETCH_RETRY;$i++){
	if('HEAD' == $orig_method){
		$response = wp_remote_head($new_url,$args);
	}
	elseif('POST' == $orig_method){
		$args['body'] = $orig_postdata;
		$response = wp_remote_post($new_url,$args);
	}
	else{
		$response = wp_remote_get($new_url,$args);
	}
	$code =  wp_remote_retrieve_response_code($response);

	if(is_int($code)){
		$body = wp_remote_retrieve_body($response);
		status_header($code);
		$body = str_replace($target_domain,$orig_domain,$body);
		echo $body;
		die;
	}
}

send_error_header(590,'server error');