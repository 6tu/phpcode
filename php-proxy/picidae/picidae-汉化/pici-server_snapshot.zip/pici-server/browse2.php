<?php

	$no_js = true;
	require("browse.php");

?>