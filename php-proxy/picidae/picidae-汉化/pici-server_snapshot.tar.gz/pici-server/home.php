<?php
	
	// redirect to the picidae project site
	header('Location: http://www.picidae.net');

?>
