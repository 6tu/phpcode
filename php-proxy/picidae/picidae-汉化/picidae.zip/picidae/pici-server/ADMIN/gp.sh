xvfb-run --server-args="-screen 0, 1200x5050x24" /opt/lampp/htdocs/pici-server/ADMIN/web2pici --url=http://g.cn --out=/opt/lampp/htdocs/pici-server/CACHE/693c3cef797fccfcd9389518c68b989d.png > /opt/lampp/htdocs/pici-server/CACHE/error_.txt 2>&1 &

