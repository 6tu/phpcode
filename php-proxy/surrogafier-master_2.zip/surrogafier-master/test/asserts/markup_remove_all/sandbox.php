<?
$_SANDBOX['_COOKIE']['COOKIEuser_remove_cooks']='true';
$_SANDBOX['_COOKIE']['COOKIEuser_remove_referer']='true';
$_SANDBOX['_COOKIE']['COOKIEuser_remove_scripts']='true';
$_SANDBOX['_COOKIE']['COOKIEuser_remove_objects']='true';
?>
