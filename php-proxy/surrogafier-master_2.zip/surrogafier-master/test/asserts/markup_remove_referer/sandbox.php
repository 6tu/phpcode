<?
$_SANDBOX['_SERVER']['HTTP_REFERER']='http://bcable.net/';
$_SANDBOX['_COOKIE']['COOKIEuser_remove_referer']='true';
?>
