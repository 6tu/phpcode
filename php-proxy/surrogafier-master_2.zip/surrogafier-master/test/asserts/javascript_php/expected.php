
<meta name="robots" content="noindex, nofollow" /><link rel="shortcut icon" href="http://HTTP_HOST/PHP_SELF.php?=http://<?=$_GET['host']?>/favicon.ico" /><script type="text/javascript" src="http://HTTP_HOST/PHP_SELF.php?js_funcs"></script><script type="text/javascript" src="http://HTTP_HOST/PHP_SELF.php?js_regexps"></script><script type="text/javascript">COOKIEuser_do_proxy=true;COOKIEuser.CURR_URL="http://<?=$_GET['host']?>//proxy/test/asserts/javascript_php/index.php"+location.hash;COOKIEuser.gen_curr_urlobj();COOKIEuser.DOCUMENT_REFERER="";COOKIEuser.ENCRYPT_COOKIES=false;COOKIEuser.ENCRYPT_URLS=false;COOKIEuser.LOCATION_HOSTNAME="<?=$_GET['host']?>";COOKIEuser.LOCATION_PORT="80";COOKIEuser.LOCATION_SEARCH="";COOKIEuser.NEW_PAGETYPE_FRAME_TOP=2;COOKIEuser.PAGE_FRAMED=false;COOKIEuser.REMOVE_OBJECTS=false;COOKIEuser.URL_FORM=true;COOKIEuser.USERAGENT="";</script><script language="javascript">

if(false){

alert("document.cookie: "+COOKIEuser.getAttr(document,/cookie/));
alert("location.href: "+COOKIEuser.getAttr(location,/href/));
alert("location.hostname: "+COOKIEuser.getAttr(location,/hostname/));

}

if(false){

alert("document.location: "+COOKIEuser.getAttr(document,/location/));

COOKIEuser.setAttr(document,/location/,'bcable.net');

//ja=COOKIEuser.XMLHttpRequest_wrap(new XMLHttpRequest());
//return COOKIEuser.XMLHttpRequest_wrap(new XMLHttpRequest());

/*
ja=COOKIEuser.XMLHttpRequest_wrap(new XMLHttpRequest());
return COOKIEuser.XMLHttpRequest_wrap(new XMLHttpRequest());
*/

ja$ja=new Object();
COOKIEuser.setAttr(ja$ja,/cookie/,"ja");

asd="onclick='blah.innerHTML=\"<br />\";'";

document.write("<iframe src=\"http://www.google.com/\" />");

alert("location.search: "+COOKIEuser.getAttr(location,/search/));

if(COOKIEuser.getAttr(location,/search/)!="?asd") COOKIEuser.setAttr(location,/search/,"?asd");
eval(COOKIEuser.parse_all("alert('ja');","application/x-javascript"));

setTimeout("alert(location.href);",2000);

eval(COOKIEuser.parse_all(l,"application/x-javascript"))

if(eval(COOKIEuser.parse_all(l,"application/x-javascript")))

if(eval(COOKIEuser.parse_all(l+"ASD","application/x-javascript")))

if(eval(COOKIEuser.parse_all(l,"application/x-javascript"))) return l

COOKIEuser.setAttr(bob,'src','srcthingy');
COOKIEuser.setAttr(bob,this.joe.suzy[0],this.joe.suzy[1]);
COOKIEuser.setAttr(document.getElementById('bob'),'src','srcthingy');
COOKIEuser.setAttr(document.getElementById('bob'),this.joe.suzy[0],this.joe.suzy[1]);

COOKIEuser.getAttr(jsjjs,/cookie/) = {

setAttr:function(){
	return;
}

}

}

COOKIEuser.setAttr(a,/href/,foo);
COOKIEuser.setAttr(a,/href/,bar());
COOKIEuser.setAttr(a,/href/,function(){});
COOKIEuser.setAttr(a,/href/,{});
COOKIEuser.setAttr(a,/href/,(a||b)&&(c|d&e)&&f);
COOKIEuser.setAttr(a,/href/,a?b:c);

alert(COOKIEuser.getAttr(document,/cookie/));
COOKIEuser.setAttr(document,/cookie/,COOKIEuser.getAttr(document,/cookie/)+'asd');

COOKIEuser.setAttr(document,/cookie/,/asd/i);
COOKIEuser.setAttr(document,/cookie/,"; expires=asd");
COOKIEuser.setAttr(document,/cookie/,thecookie);
COOKIEuser.setAttr(document,/cookie/,thecookie+"; expires=asd");
COOKIEuser.setAttr(document,/cookie/,"; expires=asd"+thecookie);
COOKIEuser.setAttr(document,/cookie/,document.getElementById('asd').asd);
COOKIEuser.setAttr(document,/cookie/,document.getElementById[1].asd);
COOKIEuser.setAttr(document,/cookie/,document.getElementById('asd')[1].asd);
COOKIEuser.setAttr(document,/cookie/,document.getElementById("asd")[1].asd);
COOKIEuser.setAttr(document,/cookie/,document.getElementById(asd)[1].asd);
COOKIEuser.setAttr(document,/cookie/,$('asd').asd);
COOKIEuser.setAttr(document,/cookie/,$('asd')[1].asd);
COOKIEuser.setAttr(document,/cookie/,document.getElementById[asd].asd);
COOKIEuser.setAttr(document,/cookie/,document.getElementById[1]('asd').asd);
COOKIEuser.setAttr(document,/cookie/,"TZ="+COOKIEuser.getAttr(Date,/getTimezoneOffset/)+COOKIEuser.getAttr(BrowserSupport_,/tz_path/));
COOKIEuser.setAttr(document,/cookie/,"TZ="+Date.getTimezoneOffset()+COOKIEuser.getAttr(BrowserSupport_,/tz_path/));
COOKIEuser.setAttr(document,/cookie/,"TZ="+Date().getTimezoneOffset()+COOKIEuser.getAttr(BrowserSupport_,/tz_path/));
COOKIEuser.setAttr(document,/cookie/,"TZ="+(Date()).getTimezoneOffset()+COOKIEuser.getAttr(BrowserSupport_,/tz_path/));
COOKIEuser.setAttr(document,/cookie/,"TZ="+new Date().getTimezoneOffset()+COOKIEuser.getAttr(BrowserSupport_,/tz_path/));
COOKIEuser.setAttr(document,/cookie/,"TZ="+(new Date()).getTimezoneOffset()+COOKIEuser.getAttr(BrowserSupport_,/tz_path/));
COOKIEuser.setAttr(document,/cookie/,"TZ="+((new Date()).getTimezoneOffset()+COOKIEuser.getAttr(BrowserSupport_,/tz_path/)));
COOKIEuser.setAttr(document,/cookie/,"TZ="+(new Date(1+(1))).getTimezoneOffset()+COOKIEuser.getAttr(BrowserSupport_,/tz_path/));
COOKIEuser.setAttr(document,/cookie/,"TZ="+(new Date(1+(1+1))).getTimezoneOffset()+COOKIEuser.getAttr(BrowserSupport_,/tz_path/));
COOKIEuser.setAttr(document,/cookie/,("TZ="+((new Date()).getTimezoneOffset()+COOKIEuser.getAttr(BrowserSupport_,/tz_path/))));
COOKIEuser.setAttr(document,/cookie/,"ASD="+(1+1));
COOKIEuser.setAttr(document,/cookie/,"ASD="+(1+(1+1)));
COOKIEuser.setAttr(document,/cookie/,"asd"+
"qwe");
COOKIEuser.setAttr(document,/cookie/,(((("TZ="+((((new Date(1+
(COOKIEuser.getAttr(document.getElementById('asd'),0)))))).getTimezoneOffset()+COOKIEuser.getAttr(BrowserSupport_,/tz_path/)))))));
COOKIEuser.setAttr(document,/cookie/,(((("TZ=" + (((( new Date (1+
(COOKIEuser.getAttr(document.getElementById('asd'),0)))))).getTimezoneOffset() + COOKIEuser.getAttr(BrowserSupport_,/tz_path/)))))));

alert(COOKIEuser.getAttr(document,'cookie'));
COOKIEuser.setAttr(document,'cookie',COOKIEuser.getAttr(document,'cookie')+'asd');
COOKIEuser.setAttr(document,'cookie',asd);
COOKIEuser.setAttr(document,'cookie','asd');
COOKIEuser.setAttr(document,'cookie',asd+'asd');
COOKIEuser.setAttr(document,'cookie',"TZ="+(new Date()).getTimezoneOffset()+
COOKIEuser.getAttr(BrowserSupport_,/tz_path/));

COOKIEuser.setAttr(document.all,/style/,"none");
COOKIEuser.setAttr(document.all.nr.style.display,/fake/,"none");
COOKIEuser.setAttr(document.all[nr].style.display,/fake/,"none");
COOKIEuser.setAttr(document.all[nr].style,/display/,"none");
alert(COOKIEuser.getAttr(document.all[nr].style,/display/));
COOKIEuser.setAttr(document.all(nr).style,/display/,"none");
alert(COOKIEuser.getAttr(document.all(nr).style,/display/));
COOKIEuser.setAttr(document.all{nr}.style,/display/,"none");
alert(COOKIEuser.getAttr(document.all{nr}.style,/display/));

asd.qwe++;
asd.qwe--;
asd.qwe++;
COOKIEuser.getAttr(asd,/qwehjklm/);
alert(COOKIEuser.getAttr(document.all{nr}.style,/display/));
asd.qwe++;
COOKIEuser.setAttr(asd,/qwe/,COOKIEuser.getAttr(asd,/qwe/)+1);
asd.qwe++;;COOKIEuser.purge();//--></script>
