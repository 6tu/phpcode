<?
$_SANDBOX['_COOKIE']['COOKIEuser_remove_objects']='true';
?>
