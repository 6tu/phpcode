<?
$_SANDBOX['_COOKIE']['COOKIEuser_encrypt_urls']='true';
$_SANDBOX['_SESSION']['sesspref']='aaabcdefghijklmnopqrstuvwxyzzz';
?>
