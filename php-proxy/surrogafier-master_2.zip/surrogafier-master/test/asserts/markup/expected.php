<html>
<head><meta name="robots" content="noindex, nofollow" /><link rel="shortcut icon" href="http://HTTP_HOST/PHP_SELF.php?=http://localhost/favicon.ico" /><script type="text/javascript" src="http://HTTP_HOST/PHP_SELF.php?js_funcs"></script><script type="text/javascript" src="http://HTTP_HOST/PHP_SELF.php?js_regexps"></script><script type="text/javascript">COOKIEuser_do_proxy=true;COOKIEuser.CURR_URL="http://localhost//proxy/test/asserts/markup/index.php"+location.hash;COOKIEuser.gen_curr_urlobj();COOKIEuser.DOCUMENT_REFERER="";COOKIEuser.ENCRYPT_COOKIES=false;COOKIEuser.ENCRYPT_URLS=false;COOKIEuser.LOCATION_HOSTNAME="localhost";COOKIEuser.LOCATION_PORT="80";COOKIEuser.LOCATION_SEARCH="";COOKIEuser.NEW_PAGETYPE_FRAME_TOP=2;COOKIEuser.PAGE_FRAMED=false;COOKIEuser.REMOVE_OBJECTS=false;COOKIEuser.URL_FORM=true;COOKIEuser.USERAGENT="";</script>
</head>
<body style="background-image: url(&quot;http://HTTP_HOST/PHP_SELF.php?=http://<?=$_GET['host']?>/asd.gif&quot;)">

<form method="post" action="http://HTTP_HOST/PHP_SELF.php?=http://<?=$_GET['host']?>/" target="_parent" target="_self"></form>
<form target="_parent" target="_self" target="_parent"><!--COOKIEuser--><input type="hidden" name="" value="_"><input type="hidden" name="" class="COOKIEuser" value="http://<?=$_GET['host']?>/" /></form>
<form target="_parent" target="_self" target="_parent"><!--COOKIEuser--><input type="hidden" name="" value="_"></form>
<form target="_top" target="_self" target="_parent"><!--COOKIEuser--><input type="hidden" name="" value="_"></form>

<a target='_parent'></a>
<a target='_top'></a>

<a target=_parent></a>
<a target=_top></a>

<a href="http://HTTP_HOST/PHP_SELF.php?=http://google.com/" target=_top>TOP TARGET CLICK</a>

<a href="http://HTTP_HOST/PHP_SELF.php?=http://<?=$_GET['host']?>/asd.com"></a>
<a href="http://HTTP_HOST/PHP_SELF.php?=http://asd.com/"></a>
<a href="http://HTTP_HOST/PHP_SELF.php?=http://asd.com/"></a>


<a href=http://HTTP_HOST/PHP_SELF.php?=http://<?=$_GET['host']?>//proxy/test/asserts/markup/asd.com></a>
<a href='http://HTTP_HOST/PHP_SELF.php?=http://<?=$_GET['host']?>//proxy/test/asserts/markup/asd.com'></a>
<a href="http://HTTP_HOST/PHP_SELF.php?=http://<?=$_GET['host']?>//proxy/test/asserts/markup/asd.com"></a>


<a target="_self" href=http://HTTP_HOST/PHP_SELF.php?=http://<?=$_GET['host']?>//proxy/test/asserts/markup/asd.com></a>
<a target="_self" href='http://HTTP_HOST/PHP_SELF.php?=http://<?=$_GET['host']?>//proxy/test/asserts/markup/asd.com'></a>
<a target="_self" href="http://HTTP_HOST/PHP_SELF.php?=http://<?=$_GET['host']?>//proxy/test/asserts/markup/asd.com"></a>


<area href=http://HTTP_HOST/PHP_SELF.php?=http://<?=$_GET['host']?>//proxy/test/asserts/markup/asd.com></a>
<area href='http://HTTP_HOST/PHP_SELF.php?=http://<?=$_GET['host']?>//proxy/test/asserts/markup/asd.com'></a>
<area href="http://HTTP_HOST/PHP_SELF.php?=http://<?=$_GET['host']?>//proxy/test/asserts/markup/asd.com"></a>

<iframe id="ja" src="http://HTTP_HOST/PHP_SELF.php?=http://live.com/"></iframe>
<iframe id="ja2" src="http://HTTP_HOST/PHP_SELF.php?=http://www.bcable.net/"></iframe>

<select onchange=";COOKIEuser.setAttr(document,/location/,'bcable.net');;"></select>
<select onchange=";alert(COOKIEuser.getAttr(location,/hostname/));;"></select>

<select onchange=';COOKIEuser.setAttr(document,/location/,"bcable.net");;'></select>
<select onchange=';alert(COOKIEuser.getAttr(location,/hostname/));;'></select>

<select onchange=;alert(COOKIEuser.getAttr(location,/hostname/));;></select>

<!--[if IE]>
<a href="http://HTTP_HOST/PHP_SELF.php?=http://google.com/" target=_top>COMMENT TEST</a>
<![endif]-->
<!--
<a href="http://google.com" target=_top>COMMENT TEST</a>
-->

<script language="javascript">
<!--
alert('asd');
document.write("<iframe src=\"http://www.google.com/\" />");;COOKIEuser.purge();//--></script>

<script>
<!--
alert('asd');
document.write("<iframe src=\"http://www.google.com/\" />");;COOKIEuser.purge();//--></script>

<script src="http://HTTP_HOST/PHP_SELF.php?=http://<?=$_GET['host']?>//proxy/test/asserts/markup/asd.js"></script>

<noscript>
<a href="#">NOSCRIPT!</a>
</noscript>

<object>
<param />
<param />
</object>

<embed></embed>

<a href=javascript:;alert(COOKIEuser.getAttr(location,/hostname/));;></a>
<a href='javascript:;alert(COOKIEuser.getAttr(location,/hostname/));;'></a>
<a href="javascript:;alert(COOKIEuser.getAttr(location,/hostname/));;"></a>

<a target="_self" href=javascript:;alert(COOKIEuser.getAttr(location,/hostname/));;></a>
<a target="_self" href='javascript:;alert(COOKIEuser.getAttr(location,/hostname/));;'></a>
<a target="_self" href="javascript:;alert(COOKIEuser.getAttr(location,/hostname/));;"></a>

alert(location.hostname);

</body>
</html>
