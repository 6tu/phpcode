<?
$_SANDBOX['_COOKIE']['COOKIEuser_remove_cookies']='true';
$_SANDBOX['_COOKIE']["{$_SERVER['HTTP_HOST']}__COOKIEuser__asd"]=
	'%60%7E%21%40%23%24%25%5E%26%2A%28%29-%3D_%2B%5B'.
	'%5D%5C%7B%7D%7C%3B%27%3A%22%2C.%2F%3C%3E%3F';
?>
