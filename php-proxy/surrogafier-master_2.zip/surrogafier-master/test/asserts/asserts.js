var asserts=new Array(
	'cookies',

	'javascript_php',

	'markup',
	'markup_remove_cookies', 'markup_remove_referer',
	'markup_remove_scripts', 'markup_remove_objects',
	'markup_remove_all',
	'markup_encrypt_urls', 'markup_encrypt_cookies',
	'markup_encrypt_all',
	'markup_do_all',

	'post_simple','post_simple_array',
	'post_file','post_file_array',
	'post_all_formdata',

	'server_referer'

);
