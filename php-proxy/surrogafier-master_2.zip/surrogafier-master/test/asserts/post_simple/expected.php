
all characters over post:

`	~!
@ #$%^&*()-=_+[]\{}|;':",./<>?