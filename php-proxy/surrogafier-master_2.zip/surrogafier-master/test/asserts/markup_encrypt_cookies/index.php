<? var_dump($_COOKIE); ?>
