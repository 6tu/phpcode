--FILE0--

name: surro_assert.html
type: text/html
size: 36
error: 0
contents:

`	~!
@ #$%^&*()-=_+[]\{}|;':",./<>?



--FILE1--

name: surro_assert2.jpg
type: image/jpeg
size: 36
error: 0
contents:

-=_+[]\{}|;':",./<>?`	~!
@ #$%^&*()
