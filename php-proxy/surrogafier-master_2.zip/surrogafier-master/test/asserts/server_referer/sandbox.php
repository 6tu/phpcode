<?
$_SANDBOX['_SERVER']['HTTP_REFERER']=
	($_SERVER['HTTPS']=='on'?'https':'http').
	"://{$_SERVER['HTTP_HOST']}{$_SERVER['PHP_SELF']}?=&=http://www.example.com/";
?>
