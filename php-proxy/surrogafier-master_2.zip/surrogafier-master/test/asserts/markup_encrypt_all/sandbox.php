<?
$_SANDBOX['_COOKIE']['COOKIEuser_encrypt_urls']='true';
$_SANDBOX['_COOKIE']['COOKIEuser_encrypt_cooks']='true';
$_SANDBOX['_SESSION']['sesspref']='aaabcdefghijklmnopqrstuvwxyzzz';
$_SANDBOX['_COOKIE']['~anJya3FrZmt4d2pre3Z2Inp9diIjKy4meHlrbmFi']=
	'~TEcoN0k4ajlCb3BtckR0QkRCTHhGO0pZbWdAT2BNNDs5NDY6PDhCLz5'.
	'NWVs0Q1VDRExLRkhMTkpUQU9dVig2SGdsPmpLI35CXWNGe2hsQFg%3D';
?>
