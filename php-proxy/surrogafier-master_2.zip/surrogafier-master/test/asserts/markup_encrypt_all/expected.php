array(1) {
  ["2pre3Z2Inp9diIjKy4meHlrbmFi"]=>
  string(109) "~TEcoN0k4ajlCb3BtckR0QkRCTHhGO0pZbWdAT2BNNDs5NDY6PDhCLz5NWVs0Q1VDRExLRkhMTkpUQU9dVig2SGdsPmpLI35CXWNGe2hsQFg="
}
<html>
<head><meta name="robots" content="noindex, nofollow" /><link rel="shortcut icon" href="http://HTTP_HOST/PHP_SELF.php?=~a3d3dCo5SC07UDA%2BU3p%2Bc3J%2BeyUqLDxKXyJ8NCchcnExbWh1" /><script type="text/javascript" src="http://HTTP_HOST/PHP_SELF.php?js_funcs"></script><script type="text/javascript" src="http://HTTP_HOST/PHP_SELF.php?js_regexps"></script><script type="text/javascript">COOKIEuser_do_proxy=true;COOKIEuser.CURR_URL="http://<?=$_GET['host']?>//proxy/test/asserts/markup_encrypt_all/index.php"+location.hash;COOKIEuser.gen_curr_urlobj();COOKIEuser.DOCUMENT_REFERER="";COOKIEuser.ENCRYPT_COOKIES=false;COOKIEuser.ENCRYPT_URLS=true;COOKIEuser.LOCATION_HOSTNAME="<?=$_GET['host']?>";COOKIEuser.LOCATION_PORT="80";COOKIEuser.LOCATION_SEARCH="";COOKIEuser.NEW_PAGETYPE_FRAME_TOP=2;COOKIEuser.PAGE_FRAMED=false;COOKIEuser.REMOVE_OBJECTS=false;COOKIEuser.URL_FORM=true;COOKIEuser.USERAGENT="";</script>
</head>
<body style="background-image: url(&quot;http://HTTP_HOST/PHP_SELF.php?=~a3d3dCo5SC07UDA%2BU3p%2Bc3J%2BeyUqLDxKX3swIkolbGk%3D&quot;)">

<form method="post" action="http://HTTP_HOST/PHP_SELF.php?=~a3d3dCo5SC07UDA%2BU3p%2Bc3J%2BeyUqLDxKXw%3D%3D" target="_parent" target="_self" onsubmit=";return COOKIEuser.form_encrypt(this);;"></form>
<form target="_parent" target="_self" onsubmit=";return COOKIEuser.form_encrypt(this);;" target="_parent"><!--COOKIEuser--><input type="hidden" name="" value="_"><input type="hidden" name="" class="COOKIEuser" value="http://<?=$_GET['host']?>/" /></form>
<form target="_parent" target="_self" onsubmit=";return COOKIEuser.form_encrypt(this);;" target="_parent"><!--COOKIEuser--><input type="hidden" name="" value="_"></form>
<form target="_top" target="_self" onsubmit=";return COOKIEuser.form_encrypt(this);;" target="_parent"><!--COOKIEuser--><input type="hidden" name="" value="_"></form>

<a target='_parent'></a>
<a target='_top'></a>

<a target=_parent></a>
<a target=_top></a>

<a href="http://HTTP_HOST/PHP_SELF.php?=~a3d3dCo5SC07UDA%2BU3V%2BIXh%2BeEJ4JyY9S2A%3D" target=_top>TOP TARGET CLICK</a>

<a href="http://HTTP_HOST/PHP_SELF.php?=~a3d3dCo5SC07UDA%2BU3p%2Bc3J%2BeyUqLDxKX3swIkohcnA%3D"></a>
<a href="http://HTTP_HOST/PHP_SELF.php?=~a3d3dCo5SC07UDA%2BU28kdD91JCM6SF0%3D"></a>
<a href="http://HTTP_HOST/PHP_SELF.php?=~a3d3dCo5SC07UDA%2BU28kdD91JCM6SF0%3D"></a>


<a href=http://HTTP_HOST/PHP_SELF.php?=~a3d3dCo5SC07UDA%2BU3p%2Bc3J%2BeyUqLDxKXz9NYi4wcnt8KTdMe218fjA%2BU28kJXYmKSk6SF0nei4oMy57aHFmdn52e2dqdncxP1RwJXVAdiUk></a>
<a href='http://HTTP_HOST/PHP_SELF.php?=~a3d3dCo5SC07UDA%2BU3p%2Bc3J%2BeyUqLDxKXz9NYi4wcnt8KTdMe218fjA%2BU28kJXYmKSk6SF0nei4oMy57aHFmdn52e2dqdncxP1RwJXVAdiUk'></a>
<a href="http://HTTP_HOST/PHP_SELF.php?=~a3d3dCo5SC07UDA%2BU3p%2Bc3J%2BeyUqLDxKXz9NYi4wcnt8KTdMe218fjA%2BU28kJXYmKSk6SF0nei4oMy57aHFmdn52e2dqdncxP1RwJXVAdiUk"></a>


<a target="_self" href=http://HTTP_HOST/PHP_SELF.php?=~a3d3dCo5SC07UDA%2BU3p%2Bc3J%2BeyUqLDxKXz9NYi4wcnt8KTdMe218fjA%2BU28kJXYmKSk6SF0nei4oMy57aHFmdn52e2dqdncxP1RwJXVAdiUk></a>
<a target="_self" href='http://HTTP_HOST/PHP_SELF.php?=~a3d3dCo5SC07UDA%2BU3p%2Bc3J%2BeyUqLDxKXz9NYi4wcnt8KTdMe218fjA%2BU28kJXYmKSk6SF0nei4oMy57aHFmdn52e2dqdncxP1RwJXVAdiUk'></a>
<a target="_self" href="http://HTTP_HOST/PHP_SELF.php?=~a3d3dCo5SC07UDA%2BU3p%2Bc3J%2BeyUqLDxKXz9NYi4wcnt8KTdMe218fjA%2BU28kJXYmKSk6SF0nei4oMy57aHFmdn52e2dqdncxP1RwJXVAdiUk"></a>


<area href=http://HTTP_HOST/PHP_SELF.php?=~a3d3dCo5SC07UDA%2BU3p%2Bc3J%2BeyUqLDxKXz9NYi4wcnt8KTdMe218fjA%2BU28kJXYmKSk6SF0nei4oMy57aHFmdn52e2dqdncxP1RwJXVAdiUk></a>
<area href='http://HTTP_HOST/PHP_SELF.php?=~a3d3dCo5SC07UDA%2BU3p%2Bc3J%2BeyUqLDxKXz9NYi4wcnt8KTdMe218fjA%2BU28kJXYmKSk6SF0nei4oMy57aHFmdn52e2dqdncxP1RwJXVAdiUk'></a>
<area href="http://HTTP_HOST/PHP_SELF.php?=~a3d3dCo5SC07UDA%2BU3p%2Bc3J%2BeyUqLDxKXz9NYi4wcnt8KTdMe218fjA%2BU28kJXYmKSk6SF0nei4oMy57aHFmdn52e2dqdncxP1RwJXVAdiUk"></a>

<iframe id="ja" src="http://HTTP_HOST/PHP_SELF.php?=~a3d3dCo5SC07UDA%2BU3p4KHZAdiUkO0le"></iframe>
<iframe id="ja2" src="http://HTTP_HOST/PHP_SELF.php?=~a3d3dCo5SC07UDA%2BUycoKT90dnV3JHxGKSExQU5i"></iframe>

<select onchange=";COOKIEuser.setAttr(document,/location/,'bcable.net');;"></select>
<select onchange=";alert(COOKIEuser.getAttr(location,/hostname/));;"></select>

<select onchange=';COOKIEuser.setAttr(document,/location/,"bcable.net");;'></select>
<select onchange=';alert(COOKIEuser.getAttr(location,/hostname/));;'></select>

<select onchange=;alert(COOKIEuser.getAttr(location,/hostname/));;></select>

<!--[if IE]>
<a href="http://HTTP_HOST/PHP_SELF.php?=~a3d3dCo5SC07UDA%2BU3V%2BIXh%2BeEJ4JyY9S2A%3D" target=_top>COMMENT TEST</a>
<![endif]-->
<!--
<a href="http://google.com" target=_top>COMMENT TEST</a>
-->

<script language="javascript">
<!--
alert('asd');
document.write("<iframe src=\"http://www.google.com/\" />");;COOKIEuser.purge();//--></script>

<script>
<!--
alert('asd');
document.write("<iframe src=\"http://www.google.com/\" />");;COOKIEuser.purge();//--></script>

<script src="http://HTTP_HOST/PHP_SELF.php?=~a3d3dCo5SC07UDA%2BU3p%2Bc3J%2BeyUqLDxKXz9NYi4wcnt8KTdMe218fjA%2BU28kJXYmKSk6SF0nei4oMy57aHFmdn52e2dqdncxP1RwJXVAfSk%3D"></script>

<noscript>
<a href="#">NOSCRIPT!</a>
</noscript>

<object>
<param />
<param />
</object>

<embed></embed>

<a href=javascript:;alert(COOKIEuser.getAttr(location,/hostname/));;></a>
<a href='javascript:;alert(COOKIEuser.getAttr(location,/hostname/));;'></a>
<a href="javascript:;alert(COOKIEuser.getAttr(location,/hostname/));;"></a>

<a target="_self" href=javascript:;alert(COOKIEuser.getAttr(location,/hostname/));;></a>
<a target="_self" href='javascript:;alert(COOKIEuser.getAttr(location,/hostname/));;'></a>
<a target="_self" href="javascript:;alert(COOKIEuser.getAttr(location,/hostname/));;"></a>

alert(location.hostname);

</body>
</html>
