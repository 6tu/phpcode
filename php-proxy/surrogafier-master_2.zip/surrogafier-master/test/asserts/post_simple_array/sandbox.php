<?
$_SANDBOX['_SERVER']['REQUEST_METHOD']='POST';
$_SANDBOX['_POST']['allchars'][]="`\t~\r!\n@ #$%^&*()";
$_SANDBOX['_POST']['allchars'][]="-=_+[]\\{}|;':\",./<>?";
?>
