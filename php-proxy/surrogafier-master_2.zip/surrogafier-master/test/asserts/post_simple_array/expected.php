
all characters over a post array:

`	~!
@ #$%^&*():::-=_+[]\{}|;':",./<>?