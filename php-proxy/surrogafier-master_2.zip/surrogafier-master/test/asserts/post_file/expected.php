name: surro_assert.html
type: text/html
size: 36
error: 0
contents:

`	~!
@ #$%^&*()-=_+[]\{}|;':",./<>?
