<?
var_dump($_COOKIE);
include('../include/markup.php');
?>
