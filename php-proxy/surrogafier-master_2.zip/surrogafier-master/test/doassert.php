<? include('inc.php');
doassert($_GET['assert']); ?>
<html>
<head>
	<title>Surrogafier Testing</title>
	<link href="assert.css" rel="stylesheet" type="text/css" />
	<style> body { font-size: 12px; line-height: 14px; } </style>
</head>
<body>
<? dump_result(); ?>
</body>
</html>
