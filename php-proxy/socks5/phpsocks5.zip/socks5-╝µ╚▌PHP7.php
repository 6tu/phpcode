<?php
$dbhost = 'localhost';
$dbport = '3306';
$dbuser = 'root';
$dbpass = 'mysqlpassword';
$dbname = 'phpsocks5';

$secretkey = 'i8CSU0oay8lGBBaAPjNM3okObNJRrIDclKZ2YzmuxyiHnYxOqiXUXyNNLExarHPOVXHlTc2q5Amzi7ao0fM78VU3Xsaleq8OiqZN9RrwbTDvvwL7L0zAF8vwx2Fb7AsORrcOnuIpiz8uupUcJL5ezbmSvaiqsDEBBCEpLacxMnmtkXk3oLZcnuvsFLrSX95ZLViG9a1jE026LFZrfdiGCwtXGEEjxs6csVAB0FdntvBLzMePO9URzEyJDY2r00DDAUnOE4idOWob4PkiMh3CS4UGrdBdLqjjIvixFu8Ow8Fu5NgKwdgn1gVaLbgMfvJ9PKo7BL3suTrVzAbSCvgp2yaqJVHD1SVFOSwfuTx12ly3dMaIZTqdvAvOEdJaVKL6liRRAhqHwHjNX7MkzZv0Pwf549qu69Eswkh763fbr0TEwaLGBiT1BiWC4s5ZscCpYOBGuV6Rcb8T4Fwz8cvKgFdewMu9JDBYDocdojV1se4Jci56zUrPDLbRBJry0zmXLtNhE060b501Xk0V4XdOD1tKf5CiVf7pQsCQIMUHpuJj1TFi6m8sujQoYaFRX8z8OI9KW5L0cBUYrrzus3s75yOINJ9tGwJ0I6nmjKOwICxsrUXRxHJSB3LYNibq5AjRF3aWL5d3wx05dY8KmyNzfCaRCl2vNebWaPeQiLnHAr4If4yHv4KRVmjnbq1XjG2YGlddwY6f1lFWVPUhhtlN7xYekks8LVPCbFylkF9dG211LztBrU1ZNP4iP5UeaUz57uEQj2Das9GqmKw4k3ekxRw1frXIyxnWlNt8okiglLWnlE1MXqFQvGzvlImSIepTLiFCussylaRRxKKrm5a4YZ6DAslvu0Qu7eZ9vEjgpldTBnVWGHpaQJGhznaUZxwDqraAuvMmbCZLEMM8wlBwhlziXQBV64f1qkAxaVJo4Js8rWvANSd3ntqHFEVyktwCTGDiyPOxadpa33juBs5z6lK5hoLlOdb3p4uUPeZO6x8VYlJspPbOAWv84I42IxdwYw7fghCmfotNcU4Rks17wKXIhqn2z84wAP5mYjZB6FpB4IDdcHl8PhxIxYm0NR6uLfQZS2W64fsVT25RpnpkN5pxJW1S6icihkAFMeSkHCptl0h1O8FyceeYnB9eJFilesN07LbfuzRUx3URvwTB7JCcVtYINxglb8ivnoPZR3Yp8hOXyiN4i53mVmkXAe9hKMPqR2JMb9kylk52Xi7mueV4ynzDQjU8mKTo01gUa2ysFuXwtHeLv5ZFU7AGJ2Seo58Vck5WWvbxYtm9bL7K5zQbigyYRw7jXfS7uFgvHBexNcyPrGmlLkwrD09ksl1ccxNIq91BPHL3KfcL1k3H79ZJYKHcdJah2qqXbKw6M2mET6CwODlaQ5NQhwXTIrivwcFdplrN040p6Oq5HFm48iRLbhrwrAnere9X2oBQKWCSjgQYIRpiaiSz4yKsvunY7E9NLc3RVyG2NKr2sMTKPqWAsfnc3EfyVn9hRlLi0hRD4WZb9rYtcjI47WkUSh1LDFm4jCnFA7UueRKJubcFwxIwonPVpM33ye1qsTbVvUkDjMH3vnq1NMUzm2CLW7eLVADER61WlvnS0DCnZG3m0bDgkBFZwNreD5EVpHQGyY6akK0nUh0R9uA5htN9CsU34MueZqT79x4kbQeOjB1zdCpdUA87wp26mBi5fMbmuxH8Wn0p4yjGLN02j7FeYJtjErjgOgiHqYz8BtFLRWBH8qjVs9CAYnecD3n9BVCLp5rcK0Nesj8YrMJAXB7tB9qdC4ySsN8vRk2cgHuTSXekh3glDNtaKcpbhdFkArj5kIH5rx4Uccrfll0e2naTgIwLVdSGFx4zGzY5htvTlR2MsaXuvg2V6httWQPgtm4HAnn5jD0byWzXiegryeipGdR1a9SiUVjbotpa0R1C72TI6CLkzLrWZKJ2eL4nfXXWTMey4axW9RAxauZeSEtYFmKjHyp9sxGSK6ydBnLwcecHGQMiXl02nOoeDPbBP9t8f8wEyzkMUCbpt9haUc1earHdO0zqXqp2M07S2rZkAoijCM37JMZTkEJZ4bza3APLgSmh5A87rD6TQSoGUDQpMLjMFVxHu8avCWMJADsc36dAEVDOGE9boM1ELbmaENuf4aGrAXwuKO5uh6RapZxiRkvE8mMSPyk5WvokY0xqQqrQjPtS34rpOHSwvZEwghk5VSX8Uw3IZke5YRu1K81HqTvZv3XCmSZ6padv0i7KvzaxcbUwbnOQKDS8zzFpttrOFYkCXPQXVKYHcYRwr3ZzOac0WEVNoQRY2m1njsHk7rg6tFkUbTysW0GecNR8VLpSidDBQw9rjtHFuB6ooy96EZnfVdzCiHtCzPKWtvwy2smOB1o12zT5SiT1E3BkxrsV2UJ2RLUmAk7ZJNrahlw2G59YYpVZkgaHzr2d5xMEnPFmHqH1kvOlfb8m91dqyTtPamakdxtNSX3w6MfsYMoZnrLn1OLFhSPqIllPtURT2YH0dg9qxGxZJllg9di839VwSnoeHQzVcywQZGOIdVH61L0uThbDTDU0klO5SHqcTrrnuIywlB2VlwK5yTEC6f561CuiTXhBSeTlPxxloWd3YXj4CgGxYHBBBFx9w4xoT9tBW3lEisHB0NN7r3qjqJlMVr5obxDnFpEbOmHiA9r1wpDRmeAhaOAT3Gof5O1kVK8nCj8FKJ52HVy04c5nRjVwSdqzu11Q7DeplKNQXHn7EeCSZ14hrVRot8bWlK5wk5F6PEEabzggaklPSzRB0d57J5ym1Vx5djAruGKIzj3FTOV0F8iZvaKOvOHiWK1zblukzOr1al68AO3cvFNc5eAVvKaTVTF1OJ9qm5M7P47OH76rN4mU0LZoVS9b1xctC4jlfpQvraF86Djs3aL5G4KK3oCLJwW2Tdz3RvsMzNKtJL8puKyZe5KRiRuGggcHwuMvYa3S8KwQoOQeX4m7ed2ez3i3Qlpgxz74gFRRmywhtnv5gi02AQBgsyig9efj18Uxf4XrgXv1aDSwmPD1PJlmzQVmIMhdY1y7Slr3EIBfPI2W12jdC9DG6u78rVP2zJtuXhQo0CrT7tqVPkHCJ5xPqzLdQWAt2RALS7BNhcFtyPHsEx1lHt2SlBBLV8WWGZSKfl2aDYSC2MSCmRgQGj70REZqu9m6qvO2bfkO0rIvsJl89kysJ0kT5WTseQiGfICb3CTSgsOgRytDXqJAnbm2Dq17u7etYoU1fKDCvJZ3AZtoc2mj7I5cfJ6ME8kOvyKHoIitWERrQPePA5EkeQZGnY4qDxV0SwXqgIZDmVLd7qS85dqdzoLfzHkn4ZYREzFFacYs6HRKcJ2VTqinK1E1PqiPnigk2Mm4ZrCYuu2KqmbR7JpjCeS5xKkoOQ9VoIb5CcgAd1KdiEJT8AGLVAfWVjaWLhB8ZCkdeAtEEnAOkhuMtXcNYh4ORMzyQYkcNKIL4albddDZyFcjEBgHhKy4HcwPiFfHdNE171sSmvOz6RNBnKPFsRTJnx71qll1ghWopHMOXCOTps6Tnv4ViSRS92iBYYXbaPNbecrxDPcQZ6U5tyinbkiAPEPCOYqN72ploo2K7YJSJlqvL9rGFmc7JNa2nOx79CcwtP3DNSvSlrGPUoPPGbc8CcuVLvs99h7JcNQ88xjkhV0dM3rSIVKVIkybCxqlxnnzzoAmn9gaggDye6jm2xkVBaP11D6ouegda48lm0ctuRmls3GpplhIUi4Arbxd1CBS81XWFDXHMDTLlgL5HUYxyTX7Rk2Ag7DHOduaIIIABQQKyciNEDDle7s2kdqIK7R37l4wGsRLLRj61oNN1LIrMJfnhjZZXUsSXEZmNJOgVaMZN3JVsvgyRoEjG601Knjnn7GPdXi6CZK9yyOnby9ZlT7uc0zJh1MFtI8Vq7spB666qAdNbAO7xQsJkZm8SjhCgHLU1c2n5lGy4bWr2qCfrZ2XAozoDfnzEEiI3BBSL3OLtFoDJ6ykIFPdztUEjUYhRKBERLWkGuFuCwOljJRI1DVB8ZkvRouUmFiFW96EV89fAdVWTgb62tOgq0OVEU3pS1OMlUhgeQgSBiDfqKvLwlZ5WguFX71Kh5iMPevn7QYk2f0OeKtOn9Lmeil0bnWXKaJhJCb5J4mZK0nuwGdr37FW9IbL3C09dtbm31QD0F3q8N9m0n01mjnvpStvfqxRQU5JKilM0eUsxzbPUffFAVY1B4Y6RYRuJuX5V8s61sP4rGUptrgwF5J4P59stHzBNBhsYEECmpb1wkkpK28XvHaie12waAYBwH2d5B80TKgfxAE6MCDs9ASLYg0AwkvagyvwkdcoMxluFz2uJdIjPeUczEx9ITFRurwiqPbeiCLIyvIqe6XeX9yQ4J17Cap5AiTBCFCFroU2Rv1njGV1bXWrVeo7v0DK7yXyCwMDfOEJrFLKkKEPBMgizlwJKiUsXdvhGgnd8LEhDwyCw0L6uI4z3vpfpErxiCVZNa3dKue2TRp6zkZx6tXk2QgrlMTHw6pKwawVTYMKxT1no4WTnViGP6tJuIRAT9zWyW4pLcJ55D0HRIX30WiKDzPiGqBzSQgtKQq3zAEkEj3RIU1eBmDvtSeW9tzpOHb2TAU5V5TZxVvmZdqaxMbxIHUwSKqMdczRDGSPGTDUNUpUz06X5UZTuGW0BwR5EZVdrw6DGIsTrAagix1ymmoyOxc0Jiag2BJdZXSvn9j0xv12bkGd5e2zNbg2lPch0UPd01UvJTpqZnnSboLOh4FxRQk1lGPTnrFw6rLUbuD1LHBEW5MKsYCLP6BhL6GHYZaEJ7356sF8QXNFupz3lJ9wnVE6AVIk4VWwomOlfRHnHlpYLOcFniuWhis9ZR2Y2KvxDK0xLUcRuq39nXxWT33ghFmXqyAJfkxcRalRZ3cLIHR4PncRMUQvAXZvpGcjV2yqipQYZv7q3GZYP9BvGEt0pjTCeww3VrZd43UewZ5qMAXkKzNj';
$debuginfo = True;
$prefix = 'n0MaQbxFnXjhOOwjsgJqe9Zc7AhLRI';
$postfix = 'XJ2o02qqsiSIbBBWWbgGV310mmN6di';

$dbprefix = 'phpsocks5_';
$invstep = 100000;
$invmax = 3000000;

$content_type = 'image/png';
$sesscookiekey = 'PHPSESSID';
$version = "03";

// *************** PHP7 START ***************
if(!function_exists('mysql_pconnect')){
    function mysql_pconnect($dbhost, $dbuser, $dbpass){
        global $dbport;
        global $dbname;
        global $mysqli;
        $mysqli = mysqli_connect("$dbhost:$dbport", $dbuser, $dbpass, $dbname);
        return $mysqli;
        }
    function mysql_select_db($dbname){
        global $mysqli;
	    return mysqli_select_db($mysqli,$dbname);
        }
    function mysql_fetch_array($result){
        return mysqli_fetch_array($result);
        }
    function mysql_fetch_assoc($result){
        return mysqli_fetch_assoc($result);
        }
    function mysql_fetch_row($result){
        return mysqli_fetch_row($result);
        }
    function mysql_query($cxn){
        global $mysqli;
	    return mysqli_query($mysqli,$cxn);
        }
    function mysql_escape_string($data){
        global $mysqli;
		return mysqli_real_escape_string($mysqli, $data);
        }
    function mysql_real_escape_string($data){
        return mysql_real_escape_string($data);
		}
	function mysql_close(){
	    global $mysqli;
        return mysqli_close($mysqli);
        }
}
function config(){
    global $secretkey;
    global $prefix;
    global $postfix;
	$serverurl = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
	$localport = '10080';
	$localhost = '127.0.0.1';
	$config = "<br><br>\r\n ----------phpsocks5.properties----------<br><br>\r\n";
	$config .= 'serverurl=' . $serverurl . "<br>\r\n";
	$config .= 'secretkey=' . $secretkey. "<br>\r\n";
	$config .= 'prefix=' . $prefix. "<br>\r\n";
	$config .= 'postfix=' . $postfix. "<br>\r\n";
	$config .= 'localport=' . $localport. "<br>\r\n";
	$config .= 'localhost=' . $localhost. "<br>\r\n";
    return $config;
}
// *************** PHP7 END ***************
// Line 151 and 259 is changed

function phpsocks5_encrypt($datastr)
{
	global $secretkey;
	$encrypted = '';
	for($i = 0; $i < strlen($datastr); $i++)
		$encrypted .= chr(ord($datastr[$i]) ^ ord($secretkey[$i % strlen($secretkey)]));
	return $encrypted;
}

function phpsocks5_decrypt($datastr)
{
	return phpsocks5_encrypt($datastr);
}

function phpsocks5_tohex($datastr)
{
	global $debuginfo;
	if(!$debuginfo)
		return '';
	$hexstr = bin2hex($datastr);
	$hexstr .= '(';
	for($i = 0; $i < strlen($datastr); $i++)
	{
		if($datastr[$i] < ' ' || $datastr[$i] > '~')
			$hexstr .= '.';
		else
			$hexstr .= $datastr[$i];
	}
	$hexstr .= ')';
	return $hexstr;
}

function phpsocks5_log($message)
{
	global $dbprefix;
	global $debuginfo;
	if(!$debuginfo)
		return;
	error_log(date(DATE_RFC1123) . "\t" . $message . "\n", 3, $dbprefix . "log.log");
}

function phpsocks5_http_500($errmsg)
{
	header('HTTP/1.1 500');
	echo phpsocks5_encrypt(date(DATE_RFC1123) . "\t" . $errmsg);
	mysql_close();
	phpsocks5_log("http_500_" . $errmsg);
	exit;
}

function phpsocks5_usleep($usec)
{
	global $dbhost;
	global $dbport;
	global $dbuser;
	global $dbpass;
	global $dbname;
	phpsocks5_log("sleep process 1");
	mysql_close();
	phpsocks5_log("sleep process 2");
	usleep($usec);
	phpsocks5_log("sleep process 3");
	if(!mysql_pconnect("$dbhost:$dbport", $dbuser, $dbpass))
		phpsocks5_http_500('mysql_pconnect error');
	if(!mysql_select_db($dbname))
		phpsocks5_http_500('mysql_select_db error');
	if(!mysql_query('SET AUTOCOMMIT=1'))
		phpsocks5_http_500('mysql_query SET AUTOCOMMIT=1 error');
	phpsocks5_log("sleep process 4");
}

phpsocks5_log("process 1");

$phpsid = @mysql_escape_string($_COOKIE[$sesscookiekey]);

phpsocks5_log("process 2 $phpsid");

set_time_limit(30);

phpsocks5_log("process 3 $phpsid");

if(!mysql_pconnect("$dbhost:$dbport", $dbuser, $dbpass))
	phpsocks5_http_500('mysql_pconnect error');
if(!mysql_select_db($dbname))
	phpsocks5_http_500('mysql_select_db error');
if(!mysql_query('SET AUTOCOMMIT=1'))
	phpsocks5_http_500('mysql_query SET AUTOCOMMIT=1 error');

phpsocks5_log("process 4 $phpsid");

$postdata = file_get_contents("php://input");

phpsocks5_log("process 5 $phpsid before decrypt postdata: " . phpsocks5_tohex($postdata));

$postdata = phpsocks5_decrypt($postdata);

phpsocks5_log("process 6 $phpsid after decrypt postdata: " . phpsocks5_tohex($postdata));

if(!$postdata)
{
	phpsocks5_log("create table process");
	$dbversion = 0;
	if(!mysql_query("SELECT * FROM ${dbprefix}conning"))
		$dbversion = 0;
	else
	{
		$rslt = mysql_query("SELECT * FROM ${dbprefix}dbversion");
		if(!$rslt)
			$dbversion = 1;
		else
		{
			$row = mysql_fetch_row($rslt);
			if(!$row)
			{
				if($debuginfo)
					echo 'create table process fetch dbversion row error.';
				mysql_close();
				exit;
			}
			$dbversion = $row[0];
		} 
	}
	if($dbversion == 0)
	{
		if(!mysql_query("CREATE TABLE ${dbprefix}conning (  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,  sid VARCHAR(200) NOT NULL,  host VARCHAR(512) NOT NULL,  port INTEGER NOT NULL,  PRIMARY KEY (id))"))
		{
			if($debuginfo)
				echo 'Create table 1 error.';
			mysql_close();
			exit;
		}
		if(!mysql_query("CREATE TABLE ${dbprefix}sending (  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,  sid VARCHAR(200) NOT NULL,  cnt VARCHAR(8192) NOT NULL,  PRIMARY KEY (id))"))
		{
			if($debuginfo)
				echo 'Create table 2 error.';
			mysql_close();
			exit;
		}
		if(!mysql_query("CREATE TABLE ${dbprefix}recving (  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,  sid VARCHAR(200) NOT NULL,  cnt VARCHAR(8192) NOT NULL,  PRIMARY KEY (id))"))
		{
			if($debuginfo)
				echo 'Create table 3 error.';
			mysql_close();
			exit;
		}
		$dbversion = 1;
	}
	if($dbversion == 1)
	{
		if(!mysql_query("ALTER TABLE ${dbprefix}sending CHANGE COLUMN cnt cnt MEDIUMTEXT NOT NULL  ;"))
		{
			if($debuginfo)
				echo 'Alter table 2 error.';
			mysql_close();
			exit;
		}
		if(!mysql_query("ALTER TABLE ${dbprefix}recving CHANGE COLUMN cnt cnt MEDIUMTEXT NOT NULL  ;"))
		{
			if($debuginfo)
				echo 'Alter table 3 error.';
			mysql_close();
			exit;
		}
		if(!mysql_query("CREATE TABLE ${dbprefix}dbversion (  dbversion INT NOT NULL )"))
		{
			if($debuginfo)
				echo 'Create table 4 error.';
			mysql_close();
			exit;
		}
		if(!mysql_query("INSERT INTO ${dbprefix}dbversion VALUES (2)"))
		{
			if($debuginfo)
				echo 'Init table 4 error.';
			mysql_close();
			exit;
		}
		$dbversion = 2;
	}
	mysql_close();
	if($debuginfo)
		echo 'Create tables successfully.' . config();
	exit;
}

header("Content-Type: $content_type");

if($postdata[0] != $version[0] || $postdata[1] != $version[1])
	phpsocks5_http_500('version not match');

phpsocks5_log("process 7");

if($postdata[2] == "1")
{
	phpsocks5_log("connect process 1");
	if(!session_start())
		phpsocks5_http_500('session_start error');
	phpsocks5_log("connect process 2");
	$host = mysql_escape_string(strtok(substr($postdata, 3), ':'));
	$port = mysql_escape_string(strtok(':'));
	$phpsid = mysql_escape_string(session_id());
	phpsocks5_log("connect process 3 $phpsid");
	mysql_query("DELETE FROM ${dbprefix}conning WHERE sid = '" . $phpsid . "'");
	mysql_query("DELETE FROM ${dbprefix}sending WHERE sid = '" . $phpsid . "'");
	mysql_query("DELETE FROM ${dbprefix}recving WHERE sid = '" . $phpsid . "'");
	phpsocks5_log("connect process 4 $phpsid");
	if(!mysql_query("INSERT INTO ${dbprefix}conning (sid, host, port) VALUES ('" . session_id() . "', '$host', '$port')"))
		phpsocks5_http_500('mysql_query INSERT error');
	phpsocks5_log("connect process 5 $phpsid");
}
elseif($postdata[2] == "2")
{
	phpsocks5_log("background process 1 $phpsid");
	$inv = 0;
	$rslt = mysql_query("SELECT id, host, port FROM ${dbprefix}conning WHERE sid = '" . $phpsid . "'");
	if(!$rslt)
		phpsocks5_http_500('mysql_query SELECT error');
	phpsocks5_log("background process 2 $phpsid");
	$row = mysql_fetch_row($rslt);
	phpsocks5_usleep(0);
	if(!$row)
		phpsocks5_http_500('mysql_fetch_row error');
	phpsocks5_log("background process 3 $phpsid");
	$rmtskt = fsockopen($row[1], $row[2]);
	phpsocks5_log("background process 4 $phpsid");
	if(!$rmtskt)
	{
		mysql_query("DELETE FROM ${dbprefix}conning WHERE id = $row[0]");
		phpsocks5_http_500('fsockopen error');
	}
	phpsocks5_log("background process 5 $phpsid");
	if(!stream_set_blocking($rmtskt, 0))
		phpsocks5_http_500('stream_set_blocking error');
	phpsocks5_log("background process 6 $phpsid");
	while(true)
	{
		$noop = true;
		phpsocks5_log("background process 7 $phpsid");
		if(feof($rmtskt))
			phpsocks5_http_500('feof');
		phpsocks5_log("background process 8 $phpsid");
		$cnt = fread($rmtskt, 1048576);
		phpsocks5_log("background process 9 $phpsid");
		if($cnt)
		{
			phpsocks5_log("background process 10 $phpsid fread: " . phpsocks5_tohex($cnt));
			if(!mysql_query("INSERT INTO ${dbprefix}recving (sid, cnt) VALUES ('" . $phpsid . "', '" . base64_encode($cnt) . "')"))
				phpsocks5_http_500('mysql_query INSERT error');
			phpsocks5_usleep(0);
			phpsocks5_log("background process 11 $phpsid");
			$noop = false;
		}
		phpsocks5_log("background process 12 $phpsid");
		phpsocks5_usleep($inv);
		phpsocks5_log("background process 13 $phpsid");
		$rslt = mysql_query("SELECT id, cnt FROM ${dbprefix}sending WHERE sid = '" . $phpsid . "' ORDER BY id ASC LIMIT 1");
		if(!$rslt)
			phpsocks5_http_500('mysql_query SELECT error');
		$row = mysql_fetch_row($rslt);
		phpsocks5_usleep(0);
		phpsocks5_log("background process 14 $phpsid");
		if($row)
		{
			$noop = false;
			phpsocks5_log("background process 15 $phpsid");
			mysql_query("DELETE FROM ${dbprefix}sending WHERE id = $row[0]");
			phpsocks5_usleep(0);
			phpsocks5_log("background process 16 $phpsid");
			if(!$row[1])
				phpsocks5_http_500('break');
			$cnt = base64_decode($row[1]);
			phpsocks5_log("background process 17 $phpsid fwrite: " . phpsocks5_tohex($cnt));
			if(!fwrite($rmtskt, $cnt))
				phpsocks5_http_500('fwrite error');
			phpsocks5_log("background process 18 $phpsid");
		}
		if($noop)
		{
			phpsocks5_log("background process 19 $phpsid");
			$inv += $invstep;
			if($inv > $invmax)
				$inv = $invmax;
		}
		else
		{
			phpsocks5_log("background process 20 $phpsid");
			set_time_limit(30);
			phpsocks5_log("background process 21 $phpsid");
			$inv = 0;
		}
		phpsocks5_usleep($inv);
		phpsocks5_log("background process 22 $phpsid");
	}
}
elseif($postdata[2] == "3")
{
	phpsocks5_log("send process 1 $phpsid");
	if(!mysql_query("INSERT INTO ${dbprefix}sending (sid, cnt) VALUES ('" . $phpsid . "', '" . base64_encode(substr($postdata, 3)) . "')"))
		phpsocks5_http_500('mysql_query INSERT INTO error');
}
elseif($postdata[2] == "4")
{
	phpsocks5_log("receive process 1 $phpsid");
	$inv = 0;
	while(true)
	{
		phpsocks5_log("receive process 2 $phpsid");
		$rslt = mysql_query("SELECT id, cnt FROM ${dbprefix}recving WHERE sid = '" . $phpsid . "' ORDER BY id ASC LIMIT 1");
		if(!$rslt)
			phpsocks5_http_500('mysql_query SELECT error');
		phpsocks5_log("receive process 3 $phpsid");
		$row = mysql_fetch_row($rslt);
		phpsocks5_usleep(0);
		if($row)
		{
			phpsocks5_log("receive process 4 $phpsid");
			mysql_query("DELETE FROM ${dbprefix}recving WHERE id = $row[0]");
			phpsocks5_usleep(0);
			if($row[1])
			{
				$cnt = base64_decode($row[1]);
				phpsocks5_log("receive process 5 $phpsid echo: " . phpsocks5_tohex($cnt));
				echo $prefix . phpsocks5_encrypt($cnt) . $postfix;
			}
			else
				phpsocks5_http_500('break');
			phpsocks5_log("receive process 6 $phpsid");
			break;
		}
		phpsocks5_log("receive process 7 $phpsid");
		$inv += $invstep;
		if($inv > $invmax)
			$inv = $invmax;
		phpsocks5_log("receive process 8 $phpsid");
		phpsocks5_usleep($inv);
		phpsocks5_log("receive process 9 $phpsid");
	}
}
elseif($postdata[2] == "5")
{
	phpsocks5_log("close process 1 $phpsid");
	mysql_query("INSERT INTO ${dbprefix}sending (sid, cnt) VALUES ('" . $phpsid . "', '')");
	mysql_query("INSERT INTO ${dbprefix}recving (sid, cnt) VALUES ('" . $phpsid . "', '')");
	phpsocks5_log("close process 2 $phpsid");
}

phpsocks5_log("process 8 $phpsid");

mysql_close();
?>
