<?php

/**
 * author: wangxd
 * 微信公众号文章采集类
 */
class DownWxArticle {
    private   $mpwxurl = 'http://mp.weixin.qq.com';
    private   $wxgzherr= '公众号二维码下载失败=>';
    private   $wximgerr= '图片下载失败=>';
    private   $direrr  = '文件夹创建失败！';
    private   $fileerr = '资源不存在！';
    private   $dirurl  = '';
    /* 抓取微信公众号文章
     * $qcode    boolean 公众号二维码 false=>不下载 true=>下载
     * return
     * $content  string  内容
     * $tile     string  标题
     * $time     int     时间戳
     * $wxggh    string  微信公众号
     * $wxh      string  微信号
     * $qcode    string  公众号二维码
     * $tag      string  标签 原创
     */
    public function get_file_article($url,$dir='',$qcode=false)
    {
        $this->dirurl = $dir?:'/Uploads/'.date('Ymd',time());
        if(!$this->put_dir($this->dirurl)){
            exit(json_encode(array('msg'=>$this->direrr,'code'=>500)));
        }
        $file = file_get_contents($url);
        if(!$file){
            $this->put_error_log($this->dirurl,$this->fileerr);
            exit(json_encode(array('msg'=>$this->fileerr,'code'=>500)));
        }
        // 内容主体
        preg_match('/<div class="rich_media_content " id="js_content">[\s\S]*?<\/div>/',$file,$content);
        // 标题
        preg_match('/<title>(.*?)<\/title>/',$file,$title);
        $title = $title?$title[1]:'';
        // 时间
        preg_match('/<em id="post-date" class="rich_media_meta rich_media_meta_text">(.*?)<\/em>/',$file,$time);
        $time = $time?strtotime($time[1]):'';
        // 公众号
        preg_match('/<a class="rich_media_meta rich_media_meta_link rich_media_meta_nickname" href="##" id="post-user">(.*?)<\/a>/',$file,$wxgzh);
        $wxgzh = $wxgzh?$wxgzh[1]:'';
        // 微信号
        preg_match('/<span class="profile_meta_value">([\s\S]*?)<\/span>/',$file,$wxh);
        $wxh   = $wxh?$wxh[1]:'';
        // 公众号二维码
        if($qcode){
            preg_match('/window.sg_qr_code="(.*?)";/',$file,$qcode);
            $qcodeurl = str_replace('\x26amp;','&',$this->mpwxurl.$qcode[1]);
            $qcode = $this->put_file_img($this->dirurl,$qcodeurl);
            if(!$qcode){
                $this->put_error_log($this->dirurl,$this->wxgzherr.$qcodeurl);
            }
        }
        // 获取标签
        preg_match('/<span id="copyright_logo" class="rich_media_meta meta_original_tag">(.*?)<\/span>/',$file,$tag);
        $tag = $tag?$tag[1]:'';
        // 图片
        preg_match_all('/<img.*?data-src=[\'|\"](.*?(?:[\.gif|\.jpg|\.png|\.jpeg|\.?]))[\'|\"].*?[\/]?>/',$content[0],$images);
        // 储存原地址和下载后地址
        $old = array();
        $new = array();
        // 去除重复图片地址
        $images = array_unique($images[1]);
        if($images){
            foreach($images as $v){
                $filename = $this->put_file_img($this->dirurl,$v);
                if($filename){
                    // 图片保存成功 替换地址
                    $old[] = $v;
                    $new[] = $filename;
                }else{
                    // 失败记录日志
                    $this->put_error_log($this->dirurl,$this->wximgerr.$v);
                }
            }
            $old[] = 'data-src';
            $new[] = 'src';
            $content = str_replace($old,$new,$content[0]);
        }
        // 替换音频
        $content = str_replace("preview.html","player.html",$content); 
        // 获取阅读点赞评论等信息
        $comment = $this->get_comment_article($url);
        $data = array('content'=>$content,'title'=>$title,'time'=>$time,'wxgzh'=>$wxgzh,'wxh'=>$wxh,'qcode'=>$qcode?:'','tag'=>$tag?:'','comment'=>$comment);
        return json_encode(array('data'=>$data,'code'=>200,'msg'=>'ok'));
    }
    /* 抓取保存图片函数
     * return
     * $filename  string  图片地址
     */
    public function put_file_img($dir='',$image='')
    {
        // 判断图片的保存类型 截取后四位地址
        $exts = array('jpeg','png','jpg');
        $filename = $dir.'/'.uniqid().time().rand(10000,99999);
        $ext = substr($image,-5);
        $ext = explode('=',$ext);
        if(in_array($ext[1],$exts) !== false){
            $filename .= '.'.$ext[1];
        }else{
            $filename .= '.gif';
        }
        $souce = file_get_contents($image);
        if(file_put_contents($filename,$souce)){
            return $filename;
        }else{
            return false;
        }
    }
    /* 获取微信公众号文章的【点赞】【阅读】【评论】
     * 方法：将地址中的部分参数替换即可。
     *     1、s?     替换为 mp/getcomment?
     *     2、最后=  替换为 %3D
     * return
     * read_num  阅读数
     * like_num  点赞数
     * comment   评论详情
     */
    public function get_comment_article($url='')
    {
        $url = substr($url,0,-1);
        $url = str_replace('/s','/mp/getcomment',$url).'%3D';
        return file_get_contents($url);
    }
    /* 错误日志记录
     * $dir  string  文件路径
     * $data string  写入内容
     */
    public function put_error_log($dir,$data)
    {
        file_put_contents($dir.'/error.log',date('Y-m-d H:i:s',time()).$data.PHP_EOL,FILE_APPEND);
    }
    /* 创建文件夹
     * $dir string 文件夹路径
     */
    public function put_dir($dir=''){
        $bool = true;
        if(!is_dir($dir)){
            if(!mkdir($dir,777,TRUE)){
                $bool = false;
                $this->put_error_log($dir,$this->direrr.$dir);
            }
        }
        return $bool;
    }
}
 
$url = 'https://mp.weixin.qq.com/s/itDfmseKPFRagprtOOwWcA';
$article = new DownWxArticle();
$article->get_file_article($url,'',true);
 



// require WxCrawler.php
$url = 'https://mp.weixin.qq.com/s?__biz=Mzg2NjU1NDAyMw==&mid=2247511293&idx=3&sn=91290ec7c91ec60d26de61978ab7afdb';
$crawler = new DownWxArticle();
$content = $crawler->get_file_article($url);
