<?php
/* *
 * 文章起始和结束标记，提取文章内容，之后截取 <body>之前的header，并把两者合并
 * 接下来是细节修改
 */

set_time_limit(0);
require_once '/home/libs/config.php';

$article_path = ARTICLE;
$cache_path = CACHE;
$webpage_path = WEBPAGE;
$tmp_path = TMP;

$savedir = $article_path . '/csdn/';

## ================ 提交URL ================ ##
header("Content-type: text/html; charset=utf-8");
$cli = preg_match("/cli/i", php_sapi_name());
if($cli){
    # print_r($argv);
    if(!empty($argv[1])) $url = $argv[1];
    else{
        fwrite(STDOUT, "Enter url:");
        $url = trim(fgets(STDIN));
    }
}
if(empty($_GET['url']) and !$cli) die('<br><br><center>请使用参数?url=https://...</center>' . form_html());
if(isset($_GET['url'])) $url = $_GET['url'];
//echo "\r\n\r\n" . $url;

## ================ URL的文件名 ================ ##
$url_array = pathinfo(parse_url($url)['path']);
$fn = $url_array['basename'];
$fn_1 = $url_array['filename'];
if(isset($url_array['extension']))$fn_ext = $url_array['extension'];
# 获取url的内容
$html = file_get_contents($url);
file_put_contents($cache_path .'/csdn_'. $fn . '.bak', $html);


# 修改内容
preg_match('/<title>(.*?)<\/title>/iUs', $html, $title);
$title = $title ? $title[1] : '';
$head = add_head($title, $url);
// $head = explode('</head>', $html, 2)[0].'</head>';
$body = explode('</article>', $html, 2)[0];
$body = explode('<main>', $body, 2)[1];
$body = "<body><main>". $body . "</article><hr><b>" . $url . "</b></div></main><br></body></html>";
$body = str_replace('<main>',     '', $body);
$body = str_replace('</main>',     '', $body);
$body = str_replace('<div class="article-header-box">', '', $body);
$body = str_replace('<div class="article-header">',     '', $body);
$body = str_replace('<div class="article-info-box">',   '', $body);
$body = str_replace('<div class="read-count-box">',     '', $body);
# 去掉js和css风格，提取title重构head
$search = array(
            "'<script[^>]*?>.*?</script>'si", # 去掉 javascript
            "'<style[^>]*?>.*?</style>'si",   # 去掉 css
            "'<link[/!]*?[^<>]*?>'si",        # 去掉 link
           /*   "'<meta\sname[^>]*?>'si"          # 去掉 meta */
            "'<meta[/!]*?[^<>]*?>'si",        # 去掉meta
        );
$replace = array("", "", "",);
$body = preg_replace($search, $replace, $body);
$html = $head . $body;
$html_array2 = explode('<img class="article-read-img', $html, 2);
$html_array3 = explode('<article class="baidu_pl">', $html_array2[1], 2);
$html = $html_array2[0] . "</div></div><article class=\"baidu_pl\">\r\n" . $html_array3[1];



require_once LIBS . '/beautify-html.php';
$beautify = new Beautify_Html(array(
    'indent_inner_html' => false,
    'indent_char' => " ",
    'indent_size' => 2,
    'wrap_line_length' => 32786,
    'unformatted' => ['code', 'pre'],
    'preserve_newlines' => false,
    'max_preserve_newlines' => 32786,
    'indent_scripts'    => 'normal', // keep|separate|normal
));
$html = $beautify->beautify($html);



# 添加语法加亮风格
$html = preg_replace("'<pre[^>]*?>'", "\n<pre class=\"brush:php;toolbar:false\">\n", $html);
$html = str_replace(array("<pre", "</pre>"), array("\r\n<pre", "\r\n</pre>\r\n"), $html);
if(strpos($html, '</pre>') !== false){
    /* $html = preg_replace("'<div[^>]*?>'iUs", '<div>', $html); */
    $html = preg_replace("'<span[^>]*?>'iUs", '', $html);
    $html = preg_replace("'</span>'iUs", '', $html);
    $html .= add_style();
}
file_put_contents($savedir . $fn_1 . '.html', $html);
$savedir = str_replace("/", "\\", $savedir);
echo "\r\n 文章保存于 ". $savedir . $fn_1 .".html\r\n\r\n";
echo ' %chrome%\\chrome.exe '. $savedir . $fn_1 .".html\r\n\r\n";



# ================ 函数区 ================#
function form_html(){
    header("Content-type: text/html; charset=utf-8");
    $html = "<html><head><title>Get CSDN blog posts</title></head>\r\n<body><center><br>\r\n<form action=\"" . php_self() . "\"method='GET'/>\r\n";
    $html .= '<b>CSDN blog\'s URL:<input type="text" name="url" size=50 value="https://blog.csdn.net"/>' . "\r\n" . '<input type="submit" value="Send"/>';
    $html .= "</b>\r\n</form>\r\n<br>\r\n";
    echo $html;
}
# 获取当前PHP文件名
function php_self(){
    $php_self = substr($_SERVER['PHP_SELF'], strrpos($_SERVER['PHP_SELF'], '/') + 1);
    return $php_self;
}
// $html = str_replace("\r", "", $html);
// $html_array = explode("\n", $html);
// $html = '';
// foreach($html_array as $line){
//     $line = trim($line);
//     if(!empty($line)) $line .= "\r\n";
//     $html .= $line;
// }
function add_head($title, $url){
    $head = '
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <link rel="canonical" href="'.$url.'" />
  <title>'.$title.'</title>
  <style>
    body,html{
      width: 90%;
      height:100%;
      margin: auto;
      line-height: 1.8;
      background: #;
      color: #000
    }
    div.article-bar-top{
      color:#999aaa;
      width:88%;
      display:-webkit-box;
      display:-ms-flexbox;
      display:flex
    }
    .bar-content{
      display:-webkit-box;
      display:-ms-flexbox;
      display:flex;-ms-flex-wrap:wrap;
      flex-wrap:wrap;-webkit-box-align:center;-ms-flex-align:center;
      align-items:center;
      padding-left:12px
    }
    .article-type-img{
      width:36px;
      height:32px;
      line-height:32px
    }
  </style>
</head>';
    return $head;
}
function add_style(){
    $style = '
<script type="text/javascript" src="http://localhost/reader/libs/styles/SyntaxHighlighter/js/shCore.js"></script>
<script type="text/javascript" src="http://localhost/reader/libs/styles/SyntaxHighlighter/js/shBrushPhp.js"></script>
<link type="text/css" rel="stylesheet" href="http://localhost/reader/libs/styles/SyntaxHighlighter/css/shCore.css" />
<link type="text/css" rel="stylesheet" href="http://localhost/reader/libs/styles/SyntaxHighlighter/css/shThemeLiuQing.css" />
<style>
  .syntaxhighlighter{
    width: 740;
    padding-top:40px;padding-bottom:20px;
    border: 1px solid #333;
    background: url("http://localhost/reader/libs/styles/SyntaxHighlighter/top_bg.svg");
    background-size: 43px;
    background-repeat: no-repeat;
    margin-bottom: -7px;
    border-radius: 15px;
    background-position: 16px 12px;
    padding-left: 10px;
    font-size: 0.8em !important;
  }
  .gutter{
    display: none;
  }
</style>
<script type="text/javascript">
  SyntaxHighlighter.all();
</script>
    ';
    return $style;
}
