<?php
/**
 * 由于提交的 URL 中包含 & 符号时，会被批处理识别为两条命令的连续符号
 * 提交的网址两端用双引号
 */

set_time_limit(0);
require_once '/home/libs/config.php';

$libs_path = LIBS;
$article_path = ARTICLE;
$cache_path = CACHE;
$webpage_path = WEBPAGE;
$tmp_path = TMP;

$time = date('YmdHis');
//$fn_key = str_pad(crc32($url), 10, '0'); # CRC32输出长度: 8-9-10位

$savedir = $article_path . '/';





// print_r($argv);
$parameter = array('-f', '-u');
if(empty($argv[1]) or !in_array($argv[1], $parameter)) die("\r\n    usage: php nojs.php -f file or -u url");
if(empty($argv[2])) die("\r\n    没检测到第二个参数，它应该是一个文件或者URL");
$dir = getcwd();
$time = date('YmdH');
if($argv[1] === '-f') $file = $argv[2];

# 操作网络文件
$mime = '';
if($argv[1] === '-u'){
    $url = $argv[2];
    $fn_key = str_pad(crc32($url), 10, '0'); # CRC32输出长度: 8-9-10位
    $info_url = parse_url($url);
    if(!empty($info_url['path'])) $info_path = pathinfo($info_url['path']);
    else $info_path = '';
    if(!empty($info_path['filename'])) $file = $time . '-' . $info_path['filename'];
    else $file = $time . '-' . $fn_key;
    if(!empty($info_path['extension'])) $ext = $info_path['extension'];
    else $ext = '';

    # wget保存无后缀文件名的文件
    $cmd = 'wget --html-extension --adjust-extension --no-check-certificate -O ' . $file . ' "' . $url . '" 2>&1';
    exec($cmd, $out, $status);
    echo "\n\n";
    foreach($out as $key => $value){
        if($key > 10) break;
        echo '[' . $key . '] => ' . $value . "\r\n";
        if(strpos($value, 'Length') !== false) $mime = substr($value, strrpos($value, '[') + 1, -1);
        if(strpos($value, 'Saving to') !== false){
            $file1 = substr($value, strpos($value, "'") + 1, -1);
            rename($file, $file1);
            $file = $file1;
        }
    }
    if(empty($mime)) die('没检测到 Mime Type ，可以能存在错误而被终止');
    if($mime != 'text/html'){
        $ext = mime2ext($mime);
        rename($file, $file . '.' . $ext);
        $file .= '.' . $ext;
    }

    # 如果是压缩数据则解压并赋新文件名
    if(strpos($file, 'html.gz') !== false and $mime == 'text/html'){
        $html = file_get_contents("compress.zlib://" . $file);
        unlink($file);
        $file = substr($file, 0, -3);
        file_put_contents($savedir . $file, $html);
    }

    # sohu 加密图片路径解密
    if(strpos($info_url['host'], 'sohu.com') !== false){
        $img_array = explode('<img data-src="', $html);
        $key_enc = "www.sohu.com6666";
        foreach($img_array as $key => $img){
            if($key === 0) continue;
            $img1_array = explode('"', $img, 2);
            $img_enc = $img1_array[0];
            $img_dec = openssl_decrypt(base64_decode($img_enc), "AES-128-ECB", $key_enc, OPENSSL_RAW_DATA);
            $html = str_replace($img_enc, $img_dec, $html);
            $html = str_replace('<img data-src="', '<img src="', $html);
            echo $img_dec . "\r\n";
        }
    }
}


/**
 * align="center"
 * 文章主要包括三部分
 * article-header [标题  作者 发布时间 本文链接]   article 主体  还有 footer
 * cnblogs.com  <div class="post">  <span id="post_view_count">  <div id="footer">
 * 51cto.com    <article            <div class="action-box">     <div class="Footer">
 */

# 操作本地文件
$html = file_get_contents($file);
$mime = mime_content_type($file);
echo "\r\n文件的 mime type是[" . $mime . "]：";
$mime = trim(fgets(STDIN));
if(empty($mime))$mime = 'text/html';
echo $mime;
if($mime !== 'text/html') exit;

for($i = 0; $i < 100; $i++){
    $html = str_replace("\t", "    ", $html);
    $html = str_replace("\r\n", "\n", $html);
    $html = str_replace("\r", "\n", $html);
    $html = str_replace(" \n", "\n", $html);
    $html = str_replace("\n\n", "\n", $html);
}
// $html = beautify_html($html);
// file_put_contents($savedir . $file, $html);
// exit;

# 去掉js和css风格，提取title重构head
$search = array(
            "'<script[^>]*?>.*?</script>'si", # 去掉 javascript
            "'<style[^>]*?>.*?</style>'si",   # 去掉 css
            "'<link[/!]*?[^<>]*?>'si",        # 去掉 link
            /* "'<meta\sname[^>]*?>'si" */    # 去掉 meta
        );
$replace = array("", "", "",);
$html = preg_replace($search, $replace, $html);
$html = preg_replace('/<\/head>/iUs', '</head>', $html);
$html_array = explode('</head>', $html, 2);
preg_match('/<title>(.*?)<\/title>/iUs', $html_array[0], $title);
$title = $title ? $title[1] : '';
$head = add_head($title);

$html = beautify_html($html);
file_put_contents($savedir. $file, $html);
exit;







$mark = '';
do{
    echo "\r\n\r\n文章标题前面的一个html标签是[可以含标题]：";
    $tag1 = trim(fgets(STDIN));
    // mb_substr_count($html_array[1], $tag1);
    if(empty($tag1)){
        echo "输入为空\r\n";
    }else $mark = 'exitthisloop';
}while($mark != 'exitthisloop');
$content1 = explode($tag1, $html_array[1], 2)[1];

echo "\r\n\r\n文章主体结束的一个标记[含后面的标签]：";
$tag2 = trim(fgets(STDIN));
$content2 = explode($tag2, $content1, 2)[0];

$div_n1 = substr_count($tag1 . $content2 . $tag2, '<div');
$div_n2 = substr_count($tag1 . $content2 . $tag2, '</div>');
if($div_n1 > $div_n2){
    $n = $div_n1 - $div_n2;
    $div_add = '';
    for($i = 0; $i < $n; $i++){
        $div_add .= '</div>';
    }
    $tag2 .= $div_add;
}

$article = $tag1 . $content2 . $tag2;
$article = str_replace("<table", "\n<pre class=\"brush:php;toolbar:false\">\n<table", $article);
$article = str_replace("</table>", "</table>\n</pre>\n", $article);
$article = str_replace("</div>", "\n</div>\n", $article);
$article = preg_replace("'<div[^>]*?>'iUs", "<div>", $article);
$article = str_replace(array("<div>", "</div>"), array('', ''), $article);
$article = preg_replace("'<code[^>]*?>'iUs", "<code>", $article);
$article = str_replace(array("<code>", "</code>"), array('', ''), $article);
$article = str_replace('&nbsp;', ' ', $article);

for($i = 0; $i < 100; $i++){
    $article = str_replace("\t", "    ", $article);
    $article = str_replace("\r\n", "\n", $article);
    $article = str_replace("\r", "\n", $article);
    $article = str_replace(" \n", "\n", $article);
    $article = str_replace("\n\n", "\n", $article);
}





echo "\r\n\r\n版尾footer的开始标签[如<div class=\"footer\">，没有则留空]：";
$tag3 = trim(fgets(STDIN));
if(empty($tag3)) $footer = '</div><br><br></body></html>';
else{
    $content3 = explode($tag3, $html_array[1], 2)[1];
    if(strpos($tag3, '>') !== false){
        $tag3 = str_replace('>', 'style="text-align:center">', $tag3);
    }else{
        $tag3 = $tag3 . ' style="text-align:center" ';
    }
    $footer = '<br><hr>' . $tag3 . $content3;
    $footer = str_replace('</body>', '</div><br><br></body>', $footer);
}

$html = $head . $article . $footer;

$html = preg_replace("'<pre[^>]*?>'iUs", "\n<pre class=\"brush:php;toolbar:false\">\n", $html);
$html = str_replace("</pre>", "\n</pre>\n", $html);
/* $html = preg_replace("'<code[^>]*?>'iUs", "\n<code>\n", $html);
$html = str_replace("</code>", "\n</code>\n", $html); */
if(strpos($html, '</pre>') !== false) $html .= styles();

$html = beautify_html($html);
file_put_contents($savedir . $file, $html);

$ext = mime2ext($mime);
if($ext === 'htm') $ext = 'html';
$info_path = pathinfo($file);
$file1 = $info_path['filename'] . '.' . $ext;
rename($file, $file1);
echo "\n\n    all done\n";


/** ============================ 函数部分，无需修改 ============================ */

function add_head($title){
    $head = '
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
  <meta name="renderer" content="webkit">
  <meta name="force-rendering" content="webkit"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
  <meta name="referrer" content="no-referrer">

  <meta name="applicable-device" content="pc,mobile">
  <meta http-equiv="Cache-Control" content="no-transform" />
  <meta http-equiv="Cache-Control" content="no-siteapp" />
  <title>' . $title . '</title>
  <link rel="stylesheet" href="https://localhost/static/header-custom.css" type="text/css" media="screen"/>
  <!--<style type="text/css">div{background: #FDFEFE;}</style>-->
</head>
<body>
  <div id="article" class="margin-medium size-medium markdown_views">
';
    return $head;
}

function styles(){
    $style = '
    <script type="text/javascript" src="https://localhost/static/styles/SyntaxHighlighter/js/shCore.js"></script>
    <script type="text/javascript" src="https://localhost/static/styles/SyntaxHighlighter/js/shBrushBash.js"></script>
    <script type="text/javascript" src="https://localhost/static/styles/SyntaxHighlighter/js/shBrushPhp.js"></script>

    <link type="text/css" rel="stylesheet" href="https://localhost/static/styles/SyntaxHighlighter/css/shCore.css"/>
    <link type="text/css" rel="stylesheet" href="https://localhost/static/styles/SyntaxHighlighter/css/shThemeLiuQing.css"/>

    <style>
    .syntaxhighlighter{
    width: 740;
    padding-top:40px;padding-bottom:20px;
    border: 1px solid #333;
    background: url("https://localhost/static/styles/SyntaxHighlighter/top_bg.svg");
    background-size: 43px;
    background-repeat: no-repeat;
    margin-bottom: -7px;
    border-radius: 15px;
    background-position: 16px 12px;
    padding-left: 10px;
    font-size: 0.8em !important;
    }
    .gutter{
    display: none;
    }
    </style>
    <script type="text/javascript">
    SyntaxHighlighter.all();
    </script>
    ';
    return $style;
}

# HTML 格式化
function beautify_html($html){
    require_once 'libs/beautify-html.php';
    $beautify_config = array(
        'indent_inner_html' => false,
        'indent_char' => " ",
        'indent_size' => 2,
        'wrap_line_length' => 32786,
        'unformatted' => ['code', 'pre', 'span'],
        'preserve_newlines' => false,
        'max_preserve_newlines' => 32786,
        'indent_scripts' => 'normal', // keep|separate|normal
    );
    $beautify = new Beautify_Html($beautify_config);
    $html = $beautify -> beautify($html);
    return $html;
}

function mime2ext($mime){
    $ext2mime = array(
        "dwg" => "application/acad",
        "ez" => "application/andrew-inset",
        "ccad" => "application/clariscad",
        "drw" => "application/drafting",
        "tsp" => "application/dsptype",
        "dxf" => "application/dxf",
        "epub" => "application/epub+zip",
        "gz" => "application/gzip",
        "unv" => "application/i-deas",
        "jar" => "application/java-archive",
        "json" => "application/json",
        "jsonld" => "application/ld+json",
        "hqx" => "application/mac-binhex40",
        "cpt" => "application/mac-compactpro",
        "pot" => "application/mspowerpoint",
        "pps" => "application/mspowerpoint",
        "ppt" => "application/mspowerpoint",
        "ppz" => "application/mspowerpoint",
        "doc" => "application/msword",
        "bin" => "application/octet-stream",
        "class" => "application/octet-stream",
        "dms" => "application/octet-stream",
        "exe" => "application/octet-stream",
        "lha" => "application/octet-stream",
        "lzh" => "application/octet-stream",
        "oda" => "application/oda",
        "ogx" => "application/ogg",
        "pdf" => "application/pdf",
        "ai" => "application/postscript",
        "eps" => "application/postscript",
        "ps" => "application/postscript",
        "prt" => "application/pro_eng",
        "rtf" => "application/rtf",
        "set" => "application/set",
        "stl" => "application/SLA",
        "smi" => "application/smil",
        "smil" => "application/smil",
        "sol" => "application/solids",
        "step" => "application/STEP",
        "stp" => "application/STEP",
        "vda" => "application/vda",
        "azw" => "application/vnd.amazon.ebook",
        "mpkg" => "application/vnd.apple.installer+xml",
        "mif" => "application/vnd.mif",
        "xul" => "application/vnd.mozilla.xul+xml",
        "xlc" => "application/vnd.ms-excel",
        "xll" => "application/vnd.ms-excel",
        "xlm" => "application/vnd.ms-excel",
        "xls" => "application/vnd.ms-excel",
        "xlw" => "application/vnd.ms-excel",
        "eot" => "application/vnd.ms-fontobject",
        "ppt" => "application/vnd.ms-powerpoint",
        "odp" => "application/vnd.oasis.opendocument.presentation",
        "ods" => "application/vnd.oasis.opendocument.spreadsheet",
        "odt" => "application/vnd.oasis.opendocument.text",
        "pptx" => "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "xlsx" => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "rar" => "application/vnd.rar",
        "vsd" => "application/vnd.visio",
        "7z" => "application/x-7z-compressed",
        "abw" => "application/x-abiword",
        "bcpio" => "application/x-bcpio",
        "bz" => "application/x-bzip",
        "bz2" => "application/x-bzip2",
        "vcd" => "application/x-cdlink",
        "pgn" => "application/x-chess-pgn",
        "cpio" => "application/x-cpio",
        "csh" => "application/x-csh",
        "dcr" => "application/x-director",
        "dir" => "application/x-director",
        "dxr" => "application/x-director",
        "dvi" => "application/x-dvi",
        "arc" => "application/x-freearc",
        "pre" => "application/x-freelance",
        "spl" => "application/x-futuresplash",
        "gtar" => "application/x-gtar",
        "gz" => "application/x-gzip",
        "hdf" => "application/x-hdf",
        "xhtml" => "application/xhtml+xml",
        "php" => "application/x-httpd-php",
        "ipx" => "application/x-ipix",
        "ips" => "application/x-ipscript",
        "js" => "application/x-javascript",
        "skd" => "application/x-koan",
        "skm" => "application/x-koan",
        "skp" => "application/x-koan",
        "skt" => "application/x-koan",
        "latex" => "application/x-latex",
        "lsp" => "application/x-lisp",
        "scm" => "application/x-lotusscreencam",
        "cdf" => "application/x-netcdf",
        "nc" => "application/x-netcdf",
        "sh" => "application/x-sh",
        "shar" => "application/x-shar",
        "swf" => "application/x-shockwave-flash",
        "sit" => "application/x-stuffit",
        "sv4cpio" => "application/x-sv4cpio",
        "sv4crc" => "application/x-sv4crc",
        "tar" => "application/x-tar",
        "tcl" => "application/x-tcl",
        "tex" => "application/x-tex",
        "texi" => "application/x-texinfo",
        "texinfo" => "application/x-texinfo",
        "roff" => "application/x-troff",
        "t" => "application/x-troff",
        "tr" => "application/x-troff",
        "man" => "application/x-troff-man",
        "me" => "application/x-troff-me",
        "ms" => "application/x-troff-ms",
        "ustar" => "application/x-ustar",
        "src" => "application/x-wais-source",
        "zip" => "application/zip",
        "aac" => "audio/aac",
        "au" => "audio/basic",
        "snd" => "audio/basic",
        "kar" => "audio/midi",
        "mid" => "audio/midi",
        "midi" => "audio/midiaudio/x-midi",
        "mp2" => "audio/mpeg",
        "mp3" => "audio/mpeg",
        "mpga" => "audio/mpeg",
        "oga" => "audio/ogg",
        "opus" => "audio/opus",
        "tsi" => "audio/TSP-audio",
        "wav" => "audio/wav",
        "weba" => "audio/webm",
        "aif" => "audio/x-aiff",
        "aifc" => "audio/x-aiff",
        "aiff" => "audio/x-aiff",
        "ram" => "audio/x-pn-realaudio",
        "rm" => "audio/x-pn-realaudio",
        "rpm" => "audio/x-pn-realaudio-plugin",
        "ra" => "audio/x-realaudio",
        "wav" => "audio/x-wav",
        "pdb" => "chemical/x-pdb",
        "xyz" => "chemical/x-pdb",
        "otf" => "font/otf",
        "ttf" => "font/ttf",
        "woff" => "font/woff",
        "woff2" => "font/woff2",
        "bmp" => "image/bmp",
        "ras" => "image/cmu-raster",
        "gif" => "image/gif",
        "ief" => "image/ief",
        "jpeg" => "image/jpeg",
        "png" => "image/png",
        "svg" => "image/svg+xml",
        "tif" => "image/tiff",
        "tiff" => "image/tiff",
        "ico" => "image/vnd.microsoft.icon",
        "webp" => "image/webp",
        "pnm" => "image/x-portable-anymap",
        "pbm" => "image/x-portable-bitmap",
        "pgm" => "image/x-portable-graymap",
        "ppm" => "image/x-portable-pixmap",
        "rgb" => "image/x-rgb",
        "xbm" => "image/x-xbitmap",
        "xpm" => "image/x-xpixmap",
        "xwd" => "image/x-xwindowdump",
        "iges" => "model/iges",
        "igs" => "model/iges",
        "mesh" => "model/mesh",
        "msh" => "model/mesh",
        "silo" => "model/mesh",
        "vrml" => "model/vrml",
        "wrl" => "model/vrml",
        "ics" => "text/calendar",
        "css" => "text/css",
        "csv" => "text/csv",
        "htm" => "text/html",
        "html" => "text/html",
        "js" => "text/javascript",
        "mjs" => "text/javascript",
        "asc" => "text/plain",
        "c" => "text/plain",
        "cc" => "text/plain",
        "py" => "text/plain",
        "php" => "text/plain",
        "f" => "text/plain",
        "f90" => "text/plain",
        "h" => "text/plain",
        "hh" => "text/plain",
        "m" => "text/plain",
        "txt" => "text/plain",
        "rtx" => "text/richtext",
        "rtf" => "text/rtf",
        "sgm" => "text/sgml",
        "sgml" => "text/sgml",
        "tsv" => "text/tab-separated-values",
        "xml" => "text/xml",
        "etx" => "text/x-setext",
        "3gp" => "video/3gpp",
        "3g2" => "video/3gpp2",
        "ts" => "video/mp2t",
        "mpeg" => "video/mpeg",
        "mpg" => "video/mpeg",
        "ogv" => "video/ogg",
        "mov" => "video/quicktime",
        "qt" => "video/quicktime",
        "viv" => "video/vnd.vivo",
        "vivo" => "video/vnd.vivo",
        "webm" => "video/webm",
        "fli" => "video/x-fli",
        "avi" => "video/x-msvideo",
        "movie" => "video/x-sgi-movie",
        "mime" => "www/mime",
        "ice" => "x-conference/x-cooltalk",
    );
    $mime = strtolower($mime);
    if(array_search($mime, $ext2mime)) return array_search($mime, $ext2mime);
    else return 'null';
}
