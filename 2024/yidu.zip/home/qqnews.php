<?php

/**
 * 同一 ID 为 20200708A07BVQ00 的文章
 * view.inews.qq.com 域名是精简版，需要JS支持，有点RSS的意思
 * new.qq.com 则是完全的html，无需JS
 * https://view.inews.qq.com/a/20200708A07BVQ00
 * https://new.qq.com/rain/a/20200708A07BVQ00
 */


set_time_limit(0);
require_once '/home/libs/config.php';

$libs_path = LIBS;
$article_path = ARTICLE;
$cache_path = CACHE;
$webpage_path = WEBPAGE;
$tmp_path = TMP;

$time = date('YmdHis');
//$fn_key = str_pad(crc32($url), 10, '0'); # CRC32输出长度: 8-9-10位


$url = 'https://view.inews.qq.com/k/20200708A07BVQ00';
$tempfn = $cache_path . '/'. md5($url);

if(!file_exists($tempfn .'.bak')){
    $qqnews = file_get_contents($url);
    file_put_contents($tempfn.'.bak', $qqnews);
    $array_qq = explode('window.initData =', $qqnews);
    $array = explode('</script>', $array_qq[1]);
    $qq = '<script>window.initData ='. $array[0] .'</script>';
    $js = trim($array[0]);
    $js = trim($js, ';');
    if(!file_exists($tempfn .'.txt')) file_put_contents($tempfn .'.txt', $js);
}

$js = file_get_contents($tempfn .'.txt');
$array_js = json_decode($js, true);

$icon = $array_js['content']['card']['icon'];         # => 头像
$chlname = $array_js['content']['card']['chlname'];   # => 作者名
$vip_desc = $array_js['content']['card']['vip_desc']; # => 公司名，公众号名
$vip_icon = $array_js['content']['card']['vip_icon']; # => VIP标识
$source = $array_js['content']['source'];             # => 聊城王岗爱讲字
$time = $array_js['content']['time'];
$addr = $array_js['content']['userAddress'];          # => 山东
$article_id = $array_js['content']['id'];             # => 20200708A07BVQ00
$surl = $array_js['content']['surl'];
$rainurl = str_replace('view.inews.qq.com', 'new.qq.com/rain', $surl);

$useragent = isset($_SERVER['HTTP_USER_AGENT'])?trim($_SERVER['HTTP_USER_AGENT']):"";
$cookie_jar = '';

$fn_vip_icon = './article/images/vip_icon.webp';

$fn_icon = str_pad(crc32($icon), 10, '0'); #CRC32输出长度:8-9-10位
$fn_icon = './article/images/'. $fn_icon .'.webp';

if(!file_exists($fn_icon)){
    $res_array = getResponse($icon, $data = [], $cookie_jar, $useragent);
    // echo $res_array['header'];# Content-Type:image/webp
    file_put_contents($fn_icon, $res_array['body']);
}

$header = '
<table>
  <tr>
    <td rowspan="2" width=70 style="text-align:left; height:80px">
      <img style="position:absolute; z-index:1; top:85px" width="60" src="'. $fn_icon .'"/>
      <img style="position:absolute; z-index:2; top:130px; left:43px" width="20" src="'. $fn_vip_icon .'"/>
    </td>
    <td rowspan="1" valign=bottom>
      <b>'. $chlname .'</b>
    </td>
  </tr>
  <tr>
    <td>
      <small>'. $time .' '. $addr .' '. $vip_desc .'</small>
    </td>
  </tr>
</table>
';

$title = $array_js['content']['title'];
$text = $array_js['content']['content']['text'];

$attr = $array_js['content']['attribute'];
// print_r($attr);
foreach($attr as $key => $value){
    $src = $value['origUrl'];
    $width = $value['width'];
    $hight = $value['height'];
    $alt = $value['desc'];
    
    $fn_img = str_pad(crc32($src), 10, '0');
    $fn_img = './article/images/'. $fn_img .'.webp';
    if(!file_exists($fn_img)){
        $res_array = getResponse($src, $data = [], $cookie_jar, $useragent);
        // echo $res_array['header'];# Content-Type:image/webp
        file_put_contents($fn_img, $res_array['body']);
    }
    $img = '<img src="'. $fn_img .'" alt="'. $alt .'" width="'. $width .'" hight="'. $hight .'">';
    $text = str_replace('<!--'. $key .'-->', $img, $text);
}

$old = str_replace('%U', "\u", $text);
$old = str_replace('#U', '\u', $text);
$text = u2c($old);
$text = str_replace(array('</P>', '<P>',), array('</p>', "\r\n<p>"), $text);

$head = "
<!DOCTYPE html>
<html lang=\"\">
<head>
  <link rel=\"shortcut icon\" href=\"./article/images/qq_favicon2.ico\">
  <head><meta charset=\"utf-8\"/>
  <title>$title</title>
</head>\r\n\r\n";

$html = "$head<body>\r\n<h2>". $title ."</h2>\r\n". $header . $text . "\r\n<br><hr>文章来源: $surl<br>$rainurl<br><br>\r\n</body></html>";
echo $html;
$html = str_replace('./article/', './', $html);
$fn_article = str_pad(crc32($url), 10, '0') .'.html';
if(!file_exists('./article/'. $fn_article)) file_put_contents($article_path . '/'. $fn_article, $html);








/**
 * 获取网页内容
 * https://www.php.net/manual/zh/function.curl-setopt.php
 * @param  String  支持GET和POST
 * @return Array   网页内容，报头，状态码，mime类型和编码 charset
 * $res_array = getResponse($url); // echo $res_array['body'];
 *
 */
function getResponse($url, $data = [], $cookie_jar, $useragent){

    # 该链接的来源处/引用处
    $url_array = parse_url($url);
    $refer = $url_array['scheme'] . '://' . $url_array['host'] . '/';
    
    # 接受的介质类型
    $accept = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9';


    # 浏览器语言
    if(!empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) $lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
    else $lang = 'zh-CN,zh;q=0.9';

    # 浏览器标识
    if(empty($useragent)) $useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36';
    // if(empty($_SERVER['HTTP_USER_AGENT'])) $useragent = 'Wget/1.18 (mingw32/linux-gnu)';
    // else $useragent = $_SERVER['HTTP_USER_AGENT'];

    # cookie，建议绝对路径
    if(empty($cookie_jar)){
        if(!file_exists('./tmp')) mkdir('./tmp', 0777, true);
        $cookie_jar = __DIR__ .'/tmp/'. md5($url_array['host']) .'.cookie';
        if(file_exists($cookie_jar) == false) file_put_contents($cookie_jar, '');
    }
    $cookie_str = file_get_contents($cookie_jar);

    $req_header = array(
        // "Content-Type: text/html; charset=UTF-8",
        // "Content-Type: application/json",
        // "Authorization: Bearer x",
        "Accept: " . $accept,
        //"Accept-Encoding: gzip, deflate",
        "Accept-Language: " . $lang,
        // "Cache-Control: max-age=0",
        "Connection: keep-alive",
        // "Cookie: " . $cookie_str,
        "Host: " . $url_array['host'],
        // "Referer: " . $refer,
        // "User-Agent: " . $useragent,
    );

    $ch = curl_init();
    $options = array(
        # 请求部分
        CURLOPT_URL              => $url,
        CURLOPT_USERAGENT        => $useragent,
        CURLOPT_REFERER          => $refer,
        CURLOPT_ENCODING         => 'gzip, deflate',
        CURLOPT_HTTPHEADER       => $req_header,
        CURLOPT_AUTOREFERER      => true,         # 301 重定向
        CURLOPT_FOLLOWLOCATION   => true,         # 302 重定向
        // CURLOPT_MAXREDIRS        => 10,           # 最多10次重定向
        CURLOPT_COOKIESESSION    => true,         # 更新cookie
        CURLOPT_COOKIEJAR        => $cookie_jar,  # 取cookie的参数是
        CURLOPT_COOKIEFILE       => $cookie_jar,  # 发送cookie

        # 响应返回部分
        CURLOPT_RETURNTRANSFER   => true,         # 将响应结果返回，而不是直接输出
        CURLOPT_HEADER           => true,         # 输出响应标头
        CURLOPT_FAILONERROR      => true,         # 状态码大于等于400，将显示错误详情
        CURLOPT_NOBODY           => false,        # 是否输出 BODY 部分
        // CURLOPT_NOPROGRESS    => true,         # 关闭 cURL 的传输进度。
        // CURLOPT_PROGRESSFUNCTION =>
        // CURLOPT_VERBOSE          => true,      # 输出所有的信息写入到STDERR
                                                  # 或在CURLOPT_STDERR中指定的文件
        // CURLOPT_STDERR           => getcwd().'/logs/',
        // CURLOPT_DEBUGFUNCTION    => my_trace,
        // CURLOPT_DEBUGDATA        => my_tracedata,
        // CURLOPT_HTTP200ALIASES   => array(400),# 将非200视为有效的 HTTP标头行
                                                  # libcurl/c/CURLOPT_HTTP200ALIASES.html
        
        CURLOPT_TIMEOUT          => 60,           # 响应超时
        CURLOPT_CONNECTTIMEOUT   => 10,           # 链接超时

        # SSL 证书
        CURLOPT_SSL_VERIFYSTATUS => false,        # 不验证证书状态
        CURLOPT_SSL_VERIFYPEER   => false,        # 禁止验证对等证书
        // CURLOPT_CAPATH        => getcwd().'/cert/',
        // CURLOPT_CAINFO        => getcwd().'/cert/ca.crt',
        // CURLOPT_SSLCERT          => getcwd().'/cert/mycert.pem',
        // CURLOPT_SSLCERTPASSWD    => 'password',
        CURLOPT_SSL_VERIFYHOST   => 0,            # 不检查证书公用名是否存在，是否与主机名匹配
        CURLOPT_SSL_ENABLE_ALPN  => false,        # 禁用用于协商到 http2的ALPN,
        CURLOPT_SSL_ENABLE_NPN   => false,        # 禁用用于协商到 http2的NPN

        # 域名的解析及ip类型
        // CURLOPT_IPRESOLVE     => CURL_IPRESOLVE_V4,
        // CURLOPT_DNS_INTERFACE => "eth0",
        // CURLOPT_DNS_LOCAL_IP4 => "192.168.0.14",
        // CURLOPT_DNS_LOCAL_IP6 => ,
    );
    curl_setopt_array($ch, $options);

    if(!empty($data)){
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_SAFE_UPLOAD, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }
    //ob_start(); //开启浏览器缓存
    $result = curl_exec($ch);
    if(curl_exec($ch) === false){
        $curl_errno = curl_errno($ch);    # 返回最后一次的错误代码
        $curl_error = curl_error($ch);    # 返回当前会话最后一次错误的字符串
        // echo 'Curl error: '. $curl_error . "<br>\r\n";
    }
    curl_close($ch);
    //ob_end_clean();

    # try{}catch{}语句
    // try{
    //     $handles = curl_exec($ch);
    //     curl_close($ch);
    //     return $handles;
    // }
    // catch(Exception $e){
    //     echo 'Caught exception:', $e -> getMessage(), "\n";
    // }

    $res_array = explode("\r\n\r\n", $result, 2);
    if(empty($res_array[1])) $res_array[1] = '';
    $body = @$res_array[1];
    $header_all = $res_array[0];
    // echo $header_all;

    # 如果$headers为空，则连接超时
    // if(empty($res_array[0])) die('<br><br><center><b>连接超时</b></center>');
    $array_headers = http_parse_headers($res_array[0]);
    $array_headers = array_filter($array_headers);
    // $array_headers = array_change_key_case($res_array[0], CASE_LOWER); // 键值转为小写
    // print_r($array_headers);
    if(array_key_exists("0", $array_headers) == false) $array_headers[0] = '';
    $array_status = explode(' ', $array_headers[0]);
    $status = isset($array_status[1]) ? $array_status[1] : '';

    if(array_key_exists("User-Agent", $array_headers)) $ua = $array_headers['User-Agent'];
    
    // $set_cookie = $array_headers['Set-Cookie'];
    // $cookie = $array_headers['Cookie'];
// get cookies
// $cookies = array();
// preg_match_all('/Set-Cookie:(?<cookie>\s{0,}.*)$/im', $res_array[0], $cookies);

// echo "<pre>";
// print_r($cookies['cookie']); // show harvested cookies
// echo "</pre>";
    if(is_array($array_headers['Content-Type'])) $array_headers['Content-Type'] = $array_headers['Content-Type'][0];
    if(empty($array_headers['Content-Type'])) $array_headers['Content-Type'] = '';

    $array_type = explode(";", @$array_headers['Content-Type']);
    $mime_type = trim(strtolower($array_type[0]));
    $charset = preg_match("/charset=[^\w]?([-\w]+)/i", @$array_headers['Content-Type'], $temp) ? strtolower($temp[1]): "";
    if(empty($charset)){
        $charset = preg_match("/<meta.+?charset=[^\w]?([-\w]+)/i", @$res_array[1], $temp) ? strtolower($temp[1]):"";
    }
    if(empty($array_headers['Content-Type'])){
        $mime_type = '';
        $charset =  '';
    }
    
    # $body = preg_replace('/(?s)<meta http-equiv="Expires"[^>]*>/i', '', $body);
    if(strstr($mime_type, 'text/html') and $charset !== 'utf-8' and !empty($charset)){
        $body = mb_convert_encoding ($body, 'utf-8', $charset);
    }  

    $res_array = array(
        'status'     => $status,
        'mime_type'  => $mime_type,
        'charset'    => $charset,
        'header'     => $header_all,
        'body'       => $body,
    );
    return $res_array;
}




function u2c($str){
    return preg_replace_callback("#\\\u([0-9a-f]{4})#i",
        function ($r){
            return iconv('UCS-2BE', 'UTF-8', pack('H4', $r[1]));}, $str);
}

function http_parse_headers($raw_headers){
    $headers = array();
    $key = '';
    foreach(explode("\n", $raw_headers) as $i => $h){
        $h = explode(':', $h, 2);
        if (isset($h[1])){
            if (!isset($headers[$h[0]]))
                $headers[$h[0]] = trim($h[1]);
            elseif (is_array($headers[$h[0]])){
                $headers[$h[0]] = array_merge($headers[$h[0]], array(trim($h[1])));
            }else{
                $headers[$h[0]] = array_merge(array($headers[$h[0]]), array(trim($h[1])));
            }
            $key = $h[0];
        }else{
            if (substr($h[0], 0, 1) == "\t")
                $headers[$key] .= "\r\n\t" . trim($h[0]);
            elseif (!$key)
                $headers[0] = trim($h[0]);
        }
    }
    return $headers;
}
