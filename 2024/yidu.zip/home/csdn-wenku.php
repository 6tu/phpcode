<?php
set_time_limit(0);
require_once '/home/libs/config.php';

$libs_path = LIBS;
$article_path = ARTICLE;
$cache_path = CACHE;
$webpage_path = WEBPAGE;
$tmp_path = TMP;


# 适用于 csdn文库
$cli = preg_match("/cli/i", php_sapi_name());

$path = $article_path . "/csdn/";
$url = 'http://wenku.csdn.net/answer/2bd917a4f0994b26ada19ba04d6f1d92';
$url_array = pathinfo(parse_url($url)['path']);
$fn = $url_array['basename'] . '.html';
if(file_exists($path . $fn)){
    $html = file_get_contents($path . $fn);
    preg_match('/<title>(.*?)<\/title>/iUs', $html, $title);
    $title = $title ? $title[1] : '';
    if($cli){
        echo "\r\n\r\n" . ' %chrome%\\chrome.exe \\home\\article\\csdn\\' . $fn . "\r\n\r\n";
    }else{
        echo "\n<br>　相关文件　<a href=\"" . $path . $fn . "\">$title</a>";
    }
    exit;
}

$html = file_get_contents($url);
$json = explode("window.__INITIAL_STATE__=", $html)[1];
$json = explode(";</script>", $json, 2)[0];
// $code = file_get_contents('1.json');
$code = trim($json);

$data = json_decode($code, true);
// echo '<pre>';
// print_r($data);
$article_info = $data['pageData']['chatGptVO'];
$article_contents = $data['pageData']['chatContentStatusVO']['handledAnswer'];
$article_ext = $data['pageData']['extraContentList'];

# 把文章的 ``` 转变为 <pre>
$array = explode("```", $article_contents);
$article_contents = '';
foreach($array as $key => $value){
    if($key === 0){
        $article_contents .= '' . $value;
        continue;
    }
    if($key % 2 === 0){
        $article_contents .= "</pre>" . $value;
    }else{
        $article_contents .= "<pre class=\"brush:php;toolbar:false\">\n" . htmlspecialchars($value);
    }
}
// echo $article_contents;
$array0 = explode("```", $article_ext[0]['handledAnswer']);
$article_ext0 = '';
foreach($array0 as $key => $value){
    if($key === 0){
        $article_ext0 .= '' . $value;
        continue;
    }
    if($key % 2 === 0){
        $article_ext0 .= "</pre>" . $value;
    }else{
        $article_ext0 .= "<pre class=\"brush:php;toolbar:false\">\n\n" . htmlspecialchars($value);
    }
}
// echo $article_ext0;
$array1 = explode("```", $article_ext[1]['handledAnswer']);
$article_ext1 = '';
foreach($array1 as $key => $value){
    if($key === 0){
        $article_ext1 .= '' . $value;
        continue;
    }
    if($key % 2 === 0){
        $article_ext1 .= "</pre>" . $value;
    }else{
        $article_ext1 .= "<pre class=\"brush:php;toolbar:false\">\n" . htmlspecialchars($value);
    }
}
// echo $article_ext1;

# 转换完毕，组成 html 并保存
$article_ext0 = '<h2>' . $article_ext[0]['question'] . '</h2>关联网址: ' . $article_ext[0]['url'] . "<br><br>\n" . $article_ext0;
$article_ext1 = '<h2>' . $article_ext[1]['question'] . '</h2>关联网址: ' . $article_ext[1]['url'] . "<br><br>\n" . $article_ext1;
$basePath = $data['basePath'];                     //=> http://wenku.csdn.net/answer/2bd917a4f0994b26ada19ba04d6f1d92
$id = $article_info['id'];                         //=> 2bd917a4f0994b26ada19ba04d6f1d92
$title = $article_info['question'];                //=> php如何获取本机ip
$author = '作者: ' . $article_info['username'];    //=> m0_46477639
$time = '　时间: ' . $article_info['ctime'];       //=> 2023-05-25 20:04:00
$viewNum = '　浏览: ' . $article_info['viewNum'];  //=> 246
$article = '<h2>' . $title . "</h2><p>" . $author . $time . $viewNum . "</p>\n<p>" . $article_contents . $article_ext0 . $article_ext1 . "\n</p>";
$html = add_head($title, $basePath) . "<body>\n" . $article . "\n<hr>\n$basePath\n<br><br></body></html>" . add_style();
for($i = 0; $i < 100; $i++){
    $html = str_replace("\t", "    ", $html);
    $html = str_replace("\r\n", "\n", $html);
    $html = str_replace("\r", "\n", $html);
    $html = str_replace(" \n", "\n", $html);
}
echo beautify_html($html);
file_put_contents($path . $fn, $html);

# ================函数区，基本无需修改================#
function form_html(){
     header("Content-type: text/html; charset=utf-8");
     $html = "<html><head><title>Get CSDN blog posts</title></head>\r\n<body><center><br>\r\n<form action=\"" . php_self() . "\"method='GET'/>\r\n";
     $html .= '<b>CSDN blog\'s URL:<input type="text" name="url" size=50 value="https://blog.csdn.net"/>' . "\r\n" . '<input type="submit" value="Send"/>';
     $html .= "</b>\r\n</form>\r\n<br>\r\n";
     echo $html;
    }
# HTML 格式化
function beautify_html($html){
     require_once $libs_path . '/beautify-html.php';
     $beautify_config = array(
        'indent_inner_html' => false,
         'indent_char' => " ",
         'indent_size' => 2,
         'wrap_line_length' => 32786,
         'unformatted' => ['code', 'pre', 'span'],
         'preserve_newlines' => false,
         'max_preserve_newlines' => 32786,
         'indent_scripts' => 'normal', // keep|separate|normal
        );
     $beautify = new Beautify_Html($beautify_config);
     $html = $beautify -> beautify($html);
     return $html;
    }
function add_head($title, $url){
     $head = '
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <link rel="canonical" href="' . $url . '" />
  <title>' . $title . '</title>
  <style>
    body,html{
        width: 90%;
        height:100%;
        margin: auto;
        line-height: 1.8;
        background: #;
        color: #000
    }
    div.article-bar-top{
        color:#999aaa;
        width:88%;
        display:-webkit-box;
        display:-ms-flexbox;
        display:flex
    }
    .bar-content{
        display:-webkit-box;
        display:-ms-flexbox;
        display:flex;-ms-flex-wrap:wrap;
        flex-wrap:wrap;-webkit-box-align:center;-ms-flex-align:center;
        align-items:center;
        padding-left:12px
    }
    .article-type-img{
        width:36px;
        height:32px;
        line-height:32px
    }
  </style>
</head>';
     return $head;
    }
function add_style(){
     $style = '
<script type="text/javascript" src="http://localhost/reader/libs/styles/SyntaxHighlighter/js/shCore.js"></script>
<script type="text/javascript" src="http://localhost/reader/libs/styles/SyntaxHighlighter/js/shBrushPhp.js"></script>
<link type="text/css" rel="stylesheet" href="http://localhost/reader/libs/styles/SyntaxHighlighter/css/shCore.css" />
<link type="text/css" rel="stylesheet" href="http://localhost/reader/libs/styles/SyntaxHighlighter/css/shThemeLiuQing.css" />
<style>
  .syntaxhighlighter{
      width: 740;
      padding-top:40px;padding-bottom:20px;
      border: 1px solid #333;
      background: url("http://localhost/reader/libs/styles/SyntaxHighlighter/top_bg.svg");
      background-size: 43px;
      background-repeat: no-repeat;
      margin-bottom: -7px;
      border-radius: 15px;
      background-position: 16px 12px;
      padding-left: 10px;
      font-size: 0.8em !important;
      }
      .gutter{
      display: none;
      }
</style>
<script type="text/javascript">
  SyntaxHighlighter.all();
</script>
    ';
     return $style;
    }
