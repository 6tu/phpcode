<?php
$t1 = time();
$url = "https://jieqi.911cha.com/jieqige.html";
// $bin="C:\Program Files\Google\Chrome\Application\chrome.exe";
$bin = "D:\bin\ChromePortable\chrome.exe";


require_once('autoload.php');

use HeadlessChromium\BrowserFactory;
# 留空为调用默认的'chrome'，可以用'chromium-browser'或者'google-chrome'代替
// google-chrome --no-sandbox --headless --disable-gpu --screenshot https:#www.chromestatus.com/
$browserFactory = new BrowserFactory();
$browserFactory = new BrowserFactory($bin);
# start sheadless chrome
$browser = $browserFactory -> createBrowser();

try{
    # creates a new page and navigate to an URL
    $page = $browser -> createPage();
    $page -> navigate($url) -> waitForNavigation();

    # get page title
    $pageTitle = $page -> evaluate('document.title') -> getReturnValue();

    # get page content
    $pageContent = $page -> evaluate('document.documentElement.innerHTML') -> getReturnValue();
    file_put_contents('./foo/jieqige.html', $pageContent);
    // $html = $page -> getHtml(); # 可以精简网页
    // file_put_contents('./foo/jieqige2.html', $html);

    # screenshot - Say "Cheese"!😄
    // $page -> screenshot() -> saveToFile('./foo/bar.png');

    # pdf
    // $page -> pdf(['printBackground' => false]) -> saveToFile('./foo/bar.pdf');
}finally{
    # bye
    $browser -> close();
}
$t2 = time();
echo"\r\n" . ($t2 - $t1);
