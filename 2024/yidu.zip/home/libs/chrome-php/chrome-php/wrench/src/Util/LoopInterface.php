<?php

namespace Wrench\Util;

interface LoopInterface
{
    public function shouldContinue(): bool;
}
