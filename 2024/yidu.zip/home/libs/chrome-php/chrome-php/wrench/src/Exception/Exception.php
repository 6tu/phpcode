<?php

namespace Wrench\Exception;

class Exception extends \Exception
{
}
