<?php


function html_form(){
    // header("Content-type: text/html; charset=utf-8");
    $form = '
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>请输入网址</title>
    <style>
        #title{text-align:left; text-indent:3em; color:green;}
        #sec{text-align:left; text-indent:12em;}
        #form p{text-indent:0; font-size:1.5em}
        #form p input[type=text]{height:30px; width:90%}
    </style>
  </head>
  <body class="bg">
    <center>
      <h1 id="title">请输入网址</h1>
      <form action="' . $_SERVER['PHP_SELF'] . '" method="get" id="form" class="search">
        <p>
          <input type="text" placeholder="请输入网址" autocomplete="off" id="url" name="url" size=150 style="width:80%; height:60px" />
        </p>
        <p>
          <input type="checkbox" name="google-translate" value="谷歌翻译" style="width:30px; height:30px;">
          <input type="submit" id="submit" value="添加谷歌翻译 &raquo; gogo提交" style="width:auto; height:60px; font-size:24px;"/>
        </p>
      </form>
    </center>
  </body>
</html>
';
return $form;
}

function html_head($title){
    $header ='
<!DOCTYPE html>
<html lang="">

<head>
  <meta charset="utf-8"/>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
  <meta name="renderer" content="webkit">
  <meta name="force-rendering" content="webkit"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
  <meta name="referrer" content="no-referrer">
  <title>'.$title.'</title>
  <!--
  <link rel="stylesheet" href="./style/css/header-custom.css" type="text/css" media="screen"/>
  <style type="text/css">div{background: #FDFEFE;}</style>
  -->
</head>

<body>
  <div id="google_translate_element" style="float:right" ></div>
  <div id="article" class="margin-medium size-medium">
';
    return $header;
}

# HTML 格式化
# Tidy删除空格并插入换行符
function html_beautify($html){
    require_once 'beautify-html.php';
    $beautify_config = array(
        'indent_inner_html' => false,
        'indent_char' => " ",
        'indent_size' => 2,
        'wrap_line_length' => 32786,
        'unformatted' => ['code', 'pre'],
        'preserve_newlines' => false,
        'max_preserve_newlines' => 32786,
        'indent_scripts'    => 'normal', // keep|separate|normal
        );
    $beautify = new Beautify_Html($beautify_config);
    $html = $beautify->beautify($html);
    return $html;
}


# Tidy HTML 格式化
# Tidy删除空格并插入换行符
function html_tidy($html){
    if(function_exists('tidy_parse_string')){
    $tidy_config = array(
        'clean' => false,
        'indent' => true,
        'indent-spaces' => 2,
        'output-xhtml' => true,
        'show-body-only' => false,
        'wrap' => 1
        );
        $html = tidy_parse_string($html, $tidy_config, 'utf8');
        $html -> cleanRepair();
    }
    return $html;
}

/**
 * 特殊字符转换
 * @author bignerd
 * @since  2016-08-16T17:30:52+0800
 * @param  $string
 * @return $string
 */
function html_Transform($string){
    $string = str_replace('&quot;','"',$string);
    $string = str_replace('&amp;','&',$string);
    $string = str_replace('amp;','',$string);
    $string = str_replace('&lt;','<',$string);
    $string = str_replace('&gt;','>',$string);
    $string = str_replace('&nbsp;',' ',$string);
    $string = str_replace("\\", '',$string);
    return $string;
}


function html_tags_strip($tags,$str){
    $html=array();
    foreach ($tags as $tag) {
        $html[]='/<'.$tag.'.*?>[\s|\S]*?<\/'.$tag.'>/';
        $html[]='/<'.$tag.'.*?>/';
    }
    $data=preg_replace($html,'',$str);
    return $data;
}

# 获取网页中超链接的两种方法
function html_preg_link($html){
    $html = preg_replace('/\s{2,}|\n/i', '', $html); # 过滤掉换行和2个以上的空格
    preg_match_all('/(?:img|a|source|link|script)[^>]*(?:href|src)=[\'"]?([^>\'"\s]*)[\'"]?[^>]*>/i', $html, $out);
    return($out[1]);
}




/**
 * 获取文章的基本信息
 * @author bignerd
 * @since  2016-08-16T17:16:32+0800
 * @param  $content 文章详情源码
 * @return $basicInfo
 */
function wx_article_BasicInfo($content){
    $basicInfo = [];
    // 待获取item
    $item = [
        'appuin'        => 'biz',                // 公众号id
        'source_appid'  => 'appid',              // 公众号appid, window.source_appid
        'nickname'      => 'nickname',           // 公众号名称
        'user_name'     => 'user_name',          // 微信号
        'author'        => 'author',             // 作者
        'ct'            => 'date',               // 发布时间
        'create_time'   => 'create_time',        // 发布时间
        'provinceName'  => 'ip_wording',         // 发布地址, window.ip_wording
        'msg_title'     => 'title',              // 标题
        'msg_link'      => 'content_url',        // 文章链接
    ];
    foreach($item as $k => $v){
        $pattern = '/var ' . $k . '(.*?)";/s';
        if($k == 'create_time')  $pattern = '/var ' . $k . '(.*?)1;/s';
        if($k == 'msg_title')    $pattern = '/var ' . $k . '(.*?)\.html\(false\);/s';
        if($k == 'source_appid') $pattern = '/' . $k . '(.*?);/s';
        if($k == 'provinceName') $pattern = '/' . $k . '(.*?),/s';

        preg_match_all($pattern, $content, $matches);
        if(array_key_exists(1, $matches) && !empty($matches[1][0])){
            $matches[1][0] = htmlTransform(trim($matches[1][0]));
            $matches[1][0] = str_replace("'", '"', $matches[1][0]);
            $array = explode('"', $matches[1][0]);
            if($v=='title') $array[1] = trim($matches[1][0], "= '\"");
            $basicInfo[$v] = trim($array[1]);
        }else{
            $basicInfo[$v] = '';
        }
    }
    return $basicInfo;
}

function add_google_translate(){
    $translate = '
<!-- google 翻译，JS代码一般置于尾部 -->
<script type="text/javascript" src="https://gt.liuyun.org/translate_a/element.js?cb=googleTranslateElementInit"></script>
<script type="text/javascript">
  function googleTranslateElementInit() {
    new google.translate.TranslateElement({pageLanguage: "en"}, "google_translate_element");
  }
</script>
';
    return $translate;
}


# 获取url内容,返回字符串
function url_get_contents($url, $method, $stringData){
    $options_post = array(
        'http' => array(
            'method' => 'POST',
            'header' => 'Content-type:application/x-www-form-urlencoded;charset=UTF-8',
            'content' => $stringData   # 需要获取的内容
            ),
        "ssl" => array(
            "verify_peer" => false,
            "verify_peer_name" => false,
            )
        );

    $options_get = array(
        'http' => array(
            'method' => 'GET',
            'header' => "Accept-language: en\r\n" .
                        "Cookie: foo=bar\r\n" .  // check function.stream-context-create on php.net
                        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.82 Safari/537.36\r\n"
            ),
        "ssl" => array(
            "verify_peer" => false,
            "verify_peer_name" => false,
            )
        );

    $method = strtoupper(trim($method));
    if($method === 'GET') $options = $options_get;
    else $options = $options_post;
    $context = stream_context_create($options);

    set_error_handler(function($err_severity, $err_msg, $err_file, $err_line, array$err_context){
        throw new ErrorException($err_msg, 0, $err_severity, $err_file, $err_line);
    }, E_WARNING);
    try{
        $resource = file_get_contents($url, false, $context);
    }
    catch(Exception $e){
        $error = $e -> getMessage();
    }
    # restore the previous error handler 还原以前的错误处理程序
    restore_error_handler();

    if(!empty($error)) die("<pre><b>获取数据失败\r\n$error\r\n</b></pre>");
    else return $resource;

}



function file_put_img($dir,$image=''){
    // 判断图片的保存类型 截取后四位地址
    $exts = array('jpeg','png','jpg');
    $filename = $dir.'/'.uniqid().time().rand(10000,99999);
    $filename = $dir.'/'.date('Ymd') .'-'. substr(md5($image), 8, 16);
    // $ext = substr($image,-5);
    // $ext = explode('"',$ext); # 原句是 =
    $array_images = explode('"', $image);
    $ext = $array_images[2];
    if(in_array($ext, $exts) !== false){
        $filename .= '.'.$ext;
    }else{
        $filename .= '.gif';
    }
    $souce = file_get_contents($image);
    if(file_put_contents($filename,$souce)){
        return $filename;
    }else{
        return false;
    }
}


function save_error_log($dir,$data){
    file_put_contents($dir.'/error.log',date('Y-m-d H:i:s',time()).$data.PHP_EOL,FILE_APPEND);
}

// echo unicode2Chinese('\u53ea\u80fd\u4e2d\u6587\u624d\u61c2\u6211');
function unicode2Chinese($str){
    return preg_replace_callback("#\\\u([0-9a-f]{4})#i",
        function ($r){
            return iconv('UCS-2BE', 'UTF-8', pack('H4', $r[1]));}, $str);
}
