<?php
set_time_limit(0);
require_once '/home/libs/config.php';


session_start();
ini_set("display_errors", "On");
error_reporting(E_ALL | E_STRICT);
header("Content-type:text/html;charset=utf-8");
$t1 = time();
$cli = preg_match("/cli/i", php_sapi_name()) ? true : false;
if($cli){
    $url = $argv[1];
}else{
    if(empty($_GET)){
        echo html_form();
        //exit;
    }
    $url = @$_GET['url'];
    $srcurl = @$_GET['srcurl'];
}
$url = trim('https://video3-us-west.cloudokyo.cloud/video/v6/28/da/fa/28dafaab-4c29-4134-86b3-65504bbfccd5/master.m3u8');
$time = date('YmdHis');
$key = str_pad(crc32($url), 10, '0'); # CRC32输出长度: 8-9-10位
$file = $time .'-'. $key . '.mp4';
$info_url = parse_url($url);
$info = $time .' '. $file .' '. $url .' '. $srcurl ."\r\n";
$str = file_get_contents('info.log');
if(strpos($str, $url) !== false){
    echo "保存的文件是 ";
    $f = array_diff(scandir('./'), array('..', '.'));
    foreach($f as $value){
        if(strpos($value, $key) !== false){
            echo '<a href="'. $value .'">'. $value ."</a><br>\r\n";
        }
    }
    exit;
}
file_put_contents($tmp_path . '/info.log', $info, FILE_APPEND);


// $cmd = 'yt-dlp -c -o ' . $file .' '. $url;
$cmd = 'ping -n 10 127.0.0.1';
while (@ ob_end_flush()); // end all output buffers if any
$proc = popen($cmd, 'r');
echo '<pre>';
while (!feof($proc))
{
    $out = fread($proc, 4096);
    echo mb_convert_encoding($out, 'utf-8','gb2312');
    @ flush();
}
echo '</pre>';













function html_form(){
    // header("Content-type: text/html; charset=utf-8");
    $form = '
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>请输入网址</title>
    <style>
      body,html{width: 90%; height:100%; margin: auto; line-height: 1.8; background: #; color: #000}
      #title{text-align:left; text-indent:3em; color:green;}
      #sec{text-align:left; text-indent:12em;}
      #form p{text-indent:0; font-size:1.5em}
      #form p input[type=text]{height:30px; width:90%}
    </style>
  </head>
  <body class="bg">
    <center>
      <h1 id="title">请输入网址</h1>
      <form action="' . $_SERVER['PHP_SELF'] . '" method="get" id="form" class="search">
        <p>
          <input type="text" placeholder="请输入视频网址" autocomplete="off" id="url" name="url" size=150 style="width:80%; height:40px" /><br><br>
          <input type="text" placeholder="视频来源网址" autocomplete="off" id="srcurl" name="srcurl" size=150 style="width:80%; height:40px" /><br><br>
          <input type="submit" id="submit" value=" gogo提交" style="width:auto; height:60px; font-size:24px;"/>
        </p>
      </form>
    </center>
  </body>
</html>
';
return $form;
}
