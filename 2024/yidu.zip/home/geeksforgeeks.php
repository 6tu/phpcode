<?php
# <article , </article>, </h1><div class=text>

set_time_limit(0);
require_once '/home/libs/config.php';

$libs_path = LIBS;
$article_path = ARTICLE;
$cache_path = CACHE;
$webpage_path = WEBPAGE;
$tmp_path = TMP;

$url = 'https://www.geeksforgeeks.org/how-to-make-a-spider-bot-in-php/';
$cache_dir = $cache_path . '/';
$tmp_dir = $tmp_path . '/';

$fn_key = str_pad(crc32($url), 10, '0'); # CRC32输出长度: 8-9-10位
$url_cache_file = $cache_dir . date('Ymd') .'-'. $fn_key .'.bak';
$file = 'geeksforgeeks-' . date('Ymd') .'-'. $fn_key .'.html';

# cookie_jar 应该和 SEESION关联
if(!file_exists($tmp_dir)) mkdir($tmp_dir, 0777, true);
$cookie_jar = $tmp_dir . md5(parse_url($url)['host']) .'.cookie';
if(file_exists($cookie_jar) == false) file_put_contents($cookie_jar, '');

$ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36';
$refer = $url;
$html_array = getResponse($url, $data = [], $cookie_jar, $ua, $refer);

$str = '<article' . explode('<article', $html_array['body'], 2)[1];
$article = explode('</article>', $str, 2)[0] . '</article>';

$str1 = explode('<h1>', $str, 2)[1];
$title = explode('</h1>', $str1, 2)[0];

$article = '<article><h2>' . $title . '</h2><div class=text>' . explode('<div class=text>', $article, 2)[1];



$article = str_replace("<table", "\n<pre class=\"brush:php;toolbar:false\">\n<table", $article);
$article = str_replace("</table>", "</table>\n</pre>\n", $article);
$article = str_replace("</div>", "\n</div>\n", $article);
$article = preg_replace("'<div[^>]*?>'iUs", "<div>", $article);
$article = str_replace(array("<div>", "</div>"), array('', ''), $article);
$article = preg_replace("'<code[^>]*?>'iUs", "<code>", $article);
$article = str_replace(array("<code>", "</code>"), array('', ''), $article);
$article = str_replace('&nbsp;', ' ', $article);

for($i = 0; $i < 100; $i++){
    $article = str_replace("\t", "    ", $article);
    $article = str_replace("\r\n", "\n", $article);
    $article = str_replace("\r", "\n", $article);
    $article = str_replace(" \n", "\n", $article);
    $article = str_replace("\n\n", "\n", $article);
}

$article = preg_replace("'<pre[^>]*?>'iUs", "\n<pre class=\"brush:php;toolbar:false\">\n", $article);
$article = str_replace("</pre>", "\n</pre>\n", $article);
/* $html = preg_replace("'<code[^>]*?>'iUs", "\n<code>\n", $html);
$html = str_replace("</code>", "\n</code>\n", $html); */
if(strpos($article, '</pre>') !== false) $article .= styles();

$article = beautify_html($article);
file_put_contents($file, $article);


/** ============================ 函数部分，无需修改 ============================ */

function add_head($title){
    $head = '
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
  <meta name="renderer" content="webkit">
  <meta name="force-rendering" content="webkit"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
  <meta name="referrer" content="no-referrer">

  <meta name="applicable-device" content="pc,mobile">
  <meta http-equiv="Cache-Control" content="no-transform" />
  <meta http-equiv="Cache-Control" content="no-siteapp" />
  <title>' . $title . '</title>
  <link rel="stylesheet" href="https://localhost/static/header-custom.css" type="text/css" media="screen"/>
  <!--<style type="text/css">div{background: #FDFEFE;}</style>-->
</head>
<body>
  <div id="article" class="margin-medium size-medium markdown_views">
';
    return $head;
}

function styles(){
    $style = '
    <script type="text/javascript" src="https://localhost/static/styles/SyntaxHighlighter/js/shCore.js"></script>
    <script type="text/javascript" src="https://localhost/static/styles/SyntaxHighlighter/js/shBrushBash.js"></script>
    <script type="text/javascript" src="https://localhost/static/styles/SyntaxHighlighter/js/shBrushPhp.js"></script>

    <link type="text/css" rel="stylesheet" href="https://localhost/static/styles/SyntaxHighlighter/css/shCore.css"/>
    <link type="text/css" rel="stylesheet" href="https://localhost/static/styles/SyntaxHighlighter/css/shThemeLiuQing.css"/>

    <style>
    .syntaxhighlighter{
    width: 740;
    padding-top:40px;padding-bottom:20px;
    border: 1px solid #333;
    background: url("https://localhost/static/styles/SyntaxHighlighter/top_bg.svg");
    background-size: 43px;
    background-repeat: no-repeat;
    margin-bottom: -7px;
    border-radius: 15px;
    background-position: 16px 12px;
    padding-left: 10px;
    font-size: 0.8em !important;
    }
    .gutter{
    display: none;
    }
    </style>
    <script type="text/javascript">
    SyntaxHighlighter.all();
    </script>
    ';
    return $style;
}

# HTML 格式化
function beautify_html($html){
    require_once $libs_path . '/beautify-html.php';
    $beautify_config = array(
        'indent_inner_html' => false,
        'indent_char' => " ",
        'indent_size' => 2,
        'wrap_line_length' => 32786,
        'unformatted' => ['code', 'pre', 'span'],
        'preserve_newlines' => false,
        'max_preserve_newlines' => 32786,
        'indent_scripts' => 'normal', // keep|separate|normal
    );
    $beautify = new Beautify_Html($beautify_config);
    $html = $beautify -> beautify($html);
    return $html;
}


function http_parse_headers($raw_headers){
    $headers = array();
    $key = '';
    foreach(explode("\n", $raw_headers) as $i => $h){
        $h = explode(':', $h, 2);
        if (isset($h[1])){
            if (!isset($headers[$h[0]]))
                $headers[$h[0]] = trim($h[1]);
            elseif (is_array($headers[$h[0]])){
                $headers[$h[0]] = array_merge($headers[$h[0]], array(trim($h[1])));
            }else{
                $headers[$h[0]] = array_merge(array($headers[$h[0]]), array(trim($h[1])));
            }
            $key = $h[0];
        }else{
            if (substr($h[0], 0, 1) == "\t")
                $headers[$key] .= "\r\n\t" . trim($h[0]);
            elseif (!$key)
                $headers[0] = trim($h[0]);
        }
    }
    return $headers;
}

/**
 * 获取网页内容
 * https://www.php.net/manual/zh/function.curl-setopt.php
 * @param  String  支持GET和POST
 * @return Array   网页内容，报头，状态码，mime类型和编码 charset
 * $res_array = getResponse($url); // echo $res_array['body'];
 *
 */
function getResponse($url, $data = [], $cookie_jar, $useragent, $refer){

    # 该链接的来源处/引用处
    $url_array = parse_url($url);
    // $refer = $url_array['scheme'] . '://' . $url_array['host'] . '/';

    # 接受的介质类型
    $accept = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9';


    # 浏览器语言
    if(!empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) $lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
    else $lang = 'zh-CN,zh;q=0.9';

    # 浏览器标识
    if(empty($useragent)) $useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36';
    // if(empty($_SERVER['HTTP_USER_AGENT'])) $useragent = 'Wget/1.18 (mingw32/linux-gnu)';
    // else $useragent = $_SERVER['HTTP_USER_AGENT'];

    # cookie，建议绝对路径
    if(empty($cookie_jar)){
        if(!file_exists('./tmp')) mkdir('./tmp', 0777, true);
        $cookie_jar = __DIR__ .'/tmp/'. md5($url_array['host']) .'.cookie';
        if(file_exists($cookie_jar) == false) file_put_contents($cookie_jar, '');
    }
    $cookie_str = file_get_contents($cookie_jar);

    $req_header = array(
        // "Content-Type: text/html; charset=UTF-8",
        // "Content-Type: application/json",
        // "Authorization: Bearer x",
        "Accept: " . $accept,
        //"Accept-Encoding: gzip, deflate",
        "Accept-Language: " . $lang,
        // "Cache-Control: max-age=0",
        "Connection: keep-alive",
        // "Cookie: " . $cookie_str,
        "Host: " . $url_array['host'],
        // "Referer: " . $refer,
        // "User-Agent: " . $useragent,
    );

    $ch = curl_init();
    $options = array(
        # 请求部分
        CURLOPT_URL              => $url,
        CURLOPT_USERAGENT        => $useragent,
        CURLOPT_REFERER          => $refer,
        CURLOPT_ENCODING         => 'gzip, deflate',
        // CURLOPT_HTTPHEADER       => $req_header,
        CURLOPT_AUTOREFERER      => true,         # 301 重定向
        CURLOPT_FOLLOWLOCATION   => true,         # 302 重定向
        // CURLOPT_MAXREDIRS        => 10,           # 最多10次重定向
        CURLOPT_COOKIESESSION    => true,         # 更新cookie
        CURLOPT_COOKIEJAR        => $cookie_jar,  # 取cookie的参数是
        CURLOPT_COOKIEFILE       => $cookie_jar,  # 发送cookie

        # 响应返回部分
        CURLOPT_RETURNTRANSFER   => true,         # 将响应结果返回，而不是直接输出
        CURLOPT_HEADER           => true,         # 输出响应标头
        CURLOPT_FAILONERROR      => true,         # 状态码大于等于400，将显示错误详情
        CURLOPT_NOBODY           => false,        # 是否输出 BODY 部分
        // CURLOPT_NOPROGRESS    => true,         # 关闭 cURL 的传输进度。
        // CURLOPT_PROGRESSFUNCTION =>
        // CURLOPT_VERBOSE          => true,      # 输出所有的信息写入到STDERR
                                                  # 或在CURLOPT_STDERR中指定的文件
        // CURLOPT_STDERR           => getcwd().'/logs/',
        // CURLOPT_DEBUGFUNCTION    => my_trace,
        // CURLOPT_DEBUGDATA        => my_tracedata,
        // CURLOPT_HTTP200ALIASES   => array(400),# 将非200视为有效的 HTTP标头行
                                                  # libcurl/c/CURLOPT_HTTP200ALIASES.html
        
        CURLOPT_TIMEOUT          => 60,           # 响应超时
        CURLOPT_CONNECTTIMEOUT   => 10,           # 链接超时

        # SSL 证书
        CURLOPT_SSL_VERIFYSTATUS => false,        # 不验证证书状态
        CURLOPT_SSL_VERIFYPEER   => false,        # 禁止验证对等证书
        // CURLOPT_CAPATH        => getcwd().'/cert/',
        // CURLOPT_CAINFO        => getcwd().'/cert/ca.crt',
        // CURLOPT_SSLCERT          => getcwd().'/cert/mycert.pem',
        // CURLOPT_SSLCERTPASSWD    => 'password',
        CURLOPT_SSL_VERIFYHOST   => 0,            # 不检查证书公用名是否存在，是否与主机名匹配
        CURLOPT_SSL_ENABLE_ALPN  => false,        # 禁用用于协商到 http2的ALPN,
        CURLOPT_SSL_ENABLE_NPN   => false,        # 禁用用于协商到 http2的NPN

        # 域名的解析及ip类型
        // CURLOPT_IPRESOLVE     => CURL_IPRESOLVE_V4,
        // CURLOPT_DNS_INTERFACE => "eth0",
        // CURLOPT_DNS_LOCAL_IP4 => "192.168.0.14",
        // CURLOPT_DNS_LOCAL_IP6 => ,
    );
    curl_setopt_array($ch, $options);

    if(!empty($data)){
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_SAFE_UPLOAD, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }
    //ob_start(); //开启浏览器缓存
    $result = curl_exec($ch);
    if(curl_exec($ch) === false){
        $curl_errno = curl_errno($ch);    # 返回最后一次的错误代码
        $curl_error = curl_error($ch);    # 返回当前会话最后一次错误的字符串
        //echo 'Curl error: '. $curl_error . "<br>\r\n";
        //var_dump($result, curl_error($ch), curl_errno($ch));
    }
    curl_close($ch);
    //ob_end_clean();

    # try{}catch{}语句
    // try{
    //     $handles = curl_exec($ch);
    //     curl_close($ch);
    //     return $handles;
    // }
    // catch(Exception $e){
    //     echo 'Caught exception:', $e -> getMessage(), "\n";
    // }

    $res_array = explode("\r\n\r\n", $result, 2);
    if(empty($res_array[1])) $res_array[1] = '';
    $body = @$res_array[1];
    $header_all = $res_array[0];
    // echo $header_all;

    # 如果$headers为空，则连接超时
    // if(empty($res_array[0])) die('<br><br><center><b>连接超时</b></center>');
    $array_headers = http_parse_headers($res_array[0]);
    $array_headers = array_filter($array_headers);
    // $array_headers = array_change_key_case($res_array[0], CASE_LOWER); // 键值转为小写
    // print_r($array_headers);
    if(array_key_exists("0", $array_headers) == false) $array_headers[0] = '';
    $array_status = explode(' ', $array_headers[0]);
    $status = isset($array_status[1]) ? $array_status[1] : '';

    if(array_key_exists("User-Agent", $array_headers)) $ua = $array_headers['User-Agent'];
    
    // $set_cookie = $array_headers['Set-Cookie'];
    // $cookie = $array_headers['Cookie'];
// get cookies
// $cookies = array();
// preg_match_all('/Set-Cookie:(?<cookie>\s{0,}.*)$/im', $res_array[0], $cookies);

// echo "<pre>";
// print_r($cookies['cookie']); // show harvested cookies
// echo "</pre>";
    if(@is_array($array_headers['Content-Type'])) $array_headers['Content-Type'] = $array_headers['Content-Type'][0];
    if(empty($array_headers['Content-Type'])) $array_headers['Content-Type'] = '';

    $array_type = explode(";", @$array_headers['Content-Type']);
    $mime_type = trim(strtolower($array_type[0]));
    $charset = preg_match("/charset=[^\w]?([-\w]+)/i", @$array_headers['Content-Type'], $temp) ? strtolower($temp[1]): "";
    if(empty($charset)){
        $charset = preg_match("/<meta.+?charset=[^\w]?([-\w]+)/i", @$res_array[1], $temp) ? strtolower($temp[1]):"";
    }
    if(empty($array_headers['Content-Type'])){
        $mime_type = '';
        $charset =  '';
    }
    
    # $body = preg_replace('/(?s)<meta http-equiv="Expires"[^>]*>/i', '', $body);
    if(strstr($mime_type, 'text/html') and $charset !== 'utf-8' and !empty($charset)){
        $body = mb_convert_encoding ($body, 'utf-8', $charset);
    }  

    $res_array = array(
        'status'     => $status,
        'mime_type'  => $mime_type,
        'charset'    => $charset,
        'header'     => $header_all,
        'body'       => $body,
    );
    return $res_array;
}
