<?php
set_time_limit(0);
require_once '/home/libs/config.php';

$libs_path = LIBS;
$article_path = ARTICLE;
$cache_path = CACHE;
$webpage_path = WEBPAGE;
$tmp_path = TMP;

$url = 'https://www.commonhealth.com.tw/article/77244';
$url = 'https://api-ch.commonhealth.com.tw/api/v1.0/article/77244';
if(!file_exists('77244.txt')){
    $json = file_get_contents($url);
    file_put_contents('77244.txt', $json);
}else{
    $json = file_get_contents('77244.txt');
}
$array = json_decode($json, true);
$str = print_r($array, true);
file_put_contents('77244.log', $str);

$items = $array['items'][0];
$title = $items['title']['web_title'];
$preface = $items['preface']['preface'];


//2018-05-11 ．文 ／ 劉碩雅編譯 ．出處 ／ Web only ．圖片來源 ／ 蕭世英
$ctime = $items['publish_date'];
$name = $items['authors'][0]['name'];
$type = $items['authors'][0]['type'];
$source = $items['source'];
$main_image_source = $items['main_image']['image']['source'];
$main_image_url = $items['main_image']['image']['url'];

$header = '<img alt="" src="'. $main_image_url .'" >'.'<h2>'. $title .'</h2>'.'<blockquote>'.  $preface .'</blockquote>';
$header .= '<p>'. $ctime .' ．'. $type .' ／ '. $name .' ．出處 ／ '. $source .' ．圖片來源 ／ '. $main_image_source .'</p>';

$contents = $items['contents'];
$article = '';
foreach($contents as $v){
    $article .= $v['content'];
}

$html = $header .'<div class="wrap-content">'. $article .'</div>';
file_put_contents('77244.html', $html);

/*
<style>
.essay__shortcode__style, .shortcode__icon-link, .icon-extend{
    background-color: #f9f9f9;
    color: #094;
    font-size: 150%;
    margin: 40px 0;
    padding: 16px 16px 16px 64px;
    position: relative
    //background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0iTTMyLjIyNCA5Ljg4YS43MTUuNzE1IDAgMCAxLS40OTYtLjYgNi43OTggNi43OTggMCAwIDAtNi43NzYtNS45MTIgNi44MDggNi44MDggMCAwIDAtNC43NDQgMS45MTIuNzM4LjczOCAwIDAgMS0uOTA0LjEwNCA2Ljc3IDYuNzcgMCAwIDAtMy40NTYtLjkzNmMtMi45NDQgMC01LjU2OCAxLjkyOC02LjQ4OCA0LjY4YS43MjYuNzI2IDAgMCAxLS41Ni40ODhjLTMuNjk2LjY3Mi02LjQgMy40MjQtNi40IDcuNjk2czMuODI0IDcuNzQ0IDguNTQ0IDcuNzQ0aDE4LjExMmM0LjcyIDAgOC41NDQtMy43MiA4LjU0NC03Ljc0NCAwLTQuMDI0LTIuMTc2LTYuMzg0LTUuMzY4LTcuNDMyaC0uMDA4WiIgZmlsbD0iIzY5QzI4MiIvPjxwYXRoIGQ9Ik0yNy41NTIgMjkuNjI0IDI1Ljg4IDI3Ljk2bC00LjYxNiA0LjY0VjE5LjM1MmgtMi4zNTJ2MTMuMjU2bC00Ljc5Mi00Ljc5Mi0xLjY2NCAxLjY2NCA3LjA3MiA3LjA3MmEuODA2LjgwNiAwIDAgMCAxLjEzNiAwbDYuODk2LTYuOTI4aC0uMDA4WiIgZmlsbD0iIzA5NCIvPjwvc3ZnPg==)
    }
</style>
*/