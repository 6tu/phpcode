<?php
$c = file_get_contents('d:/xs/ldks8-216.cmd');
$c = str_replace('wget https://www.ldks8.net/17_17791/', '', $c);
$c_array = explode("\r\n", $c);
foreach($c_array as $v){
	$v = trim($v);
	if(empty($v)) continue;
    $file = 'd:/xs/'. $v;
    $file1 = str_replace('.html', '_1.html', $file);
    $file2 = str_replace('.html', '_2.html', $file);
	if(!file_exists($file)) continue;

    $md5file = md5_file($file);
    $md5file2 = md5_file($file2);





    $html = file_get_contents($file);
    $main_array = explode('<p>', $html, 2);
    $main = explode('<div class="read_btn">', $main_array[1], 2)[0];
    $title = explode('<div class="word_read">', $main_array[0], 2)[1];
	
    $html1 = file_get_contents($file1);
    $main1 = explode('<p>', $html1, 2)[1];
    $main1 = explode('<div class="read_btn">', $main1, 2)[0];
    $main1 = "\r\n-------------------------\r\n".$main1;
	
	if($md5file === $md5file2){
		$main2 = '';
	}else{
        $html2 = file_get_contents($file2);
        $main2 = explode('<p>', $html2, 2)[1];
        $main2 = explode('<div class="read_btn">', $main2, 2)[0];
		$main2 = "\r\n-------------------------\r\n".$main2;
	}
	
    $article = $title . $main . $main1 . $main2;


    for($i = 0; $i < 100; $i++){
        $article = str_replace("  ", " ",    $article);
        $article = str_replace("\t", "    ", $article);
        $article = str_replace(" <", "<",    $article);
        $article = str_replace("\r\n", "\n", $article);
        $article = str_replace("\r", "\n",   $article);
        $article = str_replace(" \n", "\n",  $article);
        $article = str_replace("\n\n", "\n", $article);
        $article = str_replace("\n<", "<",   $article);
        $article = str_replace("\n ", "\n",  $article);
    }
    $article = str_replace('><', ">　\n<", $article);
    $article = str_replace('<p>', "", $article);
    $article = str_replace('</p>', "<br>", $article);

    file_put_contents($file .'.txt', $article);
	file_put_contents('d:/216.txt', $article . "\r\n", FILE_APPEND);
}
