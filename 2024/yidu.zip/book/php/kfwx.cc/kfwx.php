<?php
$path = 'd:/xs/13358/';
$file_array = array_diff(scandir($path), array('..', '.', 'css'));
foreach($file_array as $value){
    $file = $path . $value;
	if(strpos($file, '.bat') !== false) continue;
    echo $file . "\r\n";
    $html = file_get_contents($file);
    # ȥ��js��css�����ȡtitle�ع�head
    $search = array(
                    "'<script[^>]*?>.*?</script>'si", # ȥ�� javascript
                    /**
                     * "'<style[^>]*?>.*?</style>'si",   # ȥ�� css
                     * "'<link[/!]*?[^<>]*?>'si",        # ȥ�� link
                     * "'<meta\sname[^>]*?>'si"
                     */# ȥ�� meta
                );
    $replace = array("", "", "",);
    $html = preg_replace($search, $replace, $html);
    $html = str_replace('<link href="/css/' , '<link href="./css/', $html);
    
    $html = preg_replace("'<a class=\"green\"[^>]*?>'", "<a class=\"green\">", $html);
    $html = str_replace('<p class="text-center booktag">' , '<p class="text-center booktag"><a class="green" href="https://www.kfwx.cc/book/13358/">���ƴ�˵</a>', $html);
    $html = str_replace('<a class="green">������ǩ</a>' , '������ѧ www.kfwx.cc', $html);
    $html = str_replace('<a class="green">ͶƱ</a>' , '', $html);
    $html = str_replace('<div class="panel-body" id="htmlContent">������ѧ www.kfwx.cc��' , '<div class="panel-body" id="htmlContent">', $html);
    $html = str_replace('<a href="https://www.kfwx.cc/book/13358/">���ƴ�˵</a>�޴���ɾ��ȫ������Ķ���' , '', $html);
    $html = str_replace('<a class="green">���ƴ�˵</a>' , '', $html);
    $html = str_replace('<a class="green">荒唐传说</a>' , '', $html);
    $html = str_replace('<br>nbsp' , '<br>&nbsp', $html);
    $html = str_replace('<div class="container body-content read-container">' , '', $html);

    $array = explode('<body>', $html);
    $h = $array[0];
    if(strpos($html, '</ol>') !== false){
        $c = explode('</ol>', $html)[1];
    }else{
        $c = $array[1];
    }
    $html = $h . '<body><div class="container body-content read-container">' . $c;
    $html = str_replace('��' , '�¡�', $html);
    $html = str_replace('�¡� ' , '�� ', $html);
    for($i = 0; $i < 100; $i++){
        $html = str_replace("\t", "    ", $html);
        $html = str_replace("\r\n", "\n", $html);
        $html = str_replace("\r", "\n", $html);
        $html = str_replace(" \n", "\n", $html);
        $html = str_replace("\n\n", "\n", $html);
        $html = str_replace('����' , '��', $html);
    }
    $html = str_replace('�� ' , ' ', $html);
    $html = beautify_html($html);
    file_put_contents($file, $html);
}

# HTML ��ʽ��
function beautify_html($html){
    require_once 'libs/beautify-html.php';
    $beautify_config = array(
        'indent_inner_html' => false,
        'indent_char' => " ",
        'indent_size' => 2,
        'wrap_line_length' => 32786,
        'unformatted' => ['code', 'pre', 'span'],
        'preserve_newlines' => false,
        'max_preserve_newlines' => 32786,
        'indent_scripts' => 'normal', // keep|separate|normal
    );
    $beautify = new Beautify_Html($beautify_config);
    $html = $beautify -> beautify($html);
    return $html;
}
