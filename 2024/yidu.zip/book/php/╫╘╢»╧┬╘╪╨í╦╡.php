<?php
$bashurl = 'http://www.xswang.org/book/';
$dir = '66086/';
$start = $dir . '71278738.html'; # 第一章链接
$end = $dir . '73244472.html';   # 最后章链接
$txt = $dir . '.txt';
if(!file_exists($dir)) mkdir($dir, 0777);

$file = $dir . pathinfo($start, PATHINFO_BASENAME);

# $key1 $key2 获取文章主体
$key1 = '<div class="bookname">';
$key2 = '<div id="footer" class="footer">';

# 得到下一章连接
$key3 = '" target="_top" class="next"';
$key4 = '/book/';


$url = $bashurl . $start;
$html = file_get_contents($url);
$article = article($html, $key1, $key2);
$article = article2($article);
$article = beautify_html($article);
file_put_contents($file, $article);
file_put_contents($txt, $article);
$next = nextlink($article, $key3, $key4);

for($i = 0; $i < 3; $i++){
    echo $next . "\r\n";
    if(strpos($next, $end) !== false) break;
    $html = file_get_contents($bashurl . $next);
    $article = article($html, $key1, $key2);
    $article = article2($article);
    $article = beautify_html($article);
    file_put_contents($next, $article);
    file_put_contents($txt, $article, FILE_APPEND);
    $next = nextlink($article, $key3, $key4);
}

function article($html, $key1, $key2){
    preg_match('/<title>(.*?)<\/title>/iUs', $html, $title);
    $title = $title ? $title[1] : '';
    $article = explode($key1, $html, 2)[1];
    $article = explode($key2, $article, 2)[0];
    for($i = 0; $i < 100; $i++){
        $article = str_replace("\t", "    ", $article);
        $article = str_replace("\r\n", "\n", $article);
        $article = str_replace("\r", "\n", $article);
        $article = str_replace(" \n", "\n", $article);
        $article = str_replace("\n ", "\n", $article);
        $article = str_replace("\n\n", "\n", $article);
        $article = str_replace("  ", " ", $article);
    }
    $article = $key1 . trim($article);
    $article = '<!DOCTYPE html><html><head><meta charset="utf-8"><title>' . trim($title) . '</title></head><body>' . $article;
    return $article;
}

function nextlink($html, $key3, $key4){
    $next = explode($key3, $html, 2)[0];
    $array = explode($key4, $next);
    $n = count($array);
    $next = $array[$n-1];
    // print_r($array); echo $n;
    return $next;
}

function article2($html){
    $html = preg_replace("'<a href=\"javascript[^>]*?>'iUs", '<a>', $html);
    $body1 = explode('<div class="lm">', $html, 2)[0];
    $body2 = explode('<p class="content_detail">', $html, 2)[1];
    $article = $body1 . '<div id="content" deep="3">' . $body2;

    $body1 = explode('<!-- <div align="center">', $article, 2)[0];
    $body2 = explode('</div> -->', $html, 2)[1];
    $article = $body1 . $body2;

    for($i = 0; $i < 100; $i++){
        $article = str_replace('<p class="content_detail">', "", $article);
        $article = str_replace('</p>', "", $article);
        $article = str_replace("\n\n", "\n", $article);
        $article = str_replace("\n<br/>", "<br>", $article);
    }
    $article = str_replace("<a>加入书签</a>", "", $article);
    $article = str_replace("</div>\n</div>\n</div>", "", $article);
    //$article = str_replace('<h1>', '<h3>', $article);
    //$article = str_replace('</h1>', '</h3>', $article);
    return $article;
}

# HTML 格式化
function beautify_html($html){
    require_once 'libs/beautify-html.php';
    $beautify_config = array(
        'indent_inner_html' => false,
        'indent_char' => " ",
        'indent_size' => 2,
        'wrap_line_length' => 32786,
        'unformatted' => ['code', 'pre', 'span'],
        'preserve_newlines' => false,
        'max_preserve_newlines' => 32786,
        'indent_scripts' => 'normal', // keep|separate|normal
    );
    $beautify = new Beautify_Html($beautify_config);
    $html = $beautify -> beautify($html);
    return $html;
}
