<?php
# 采集 笔趣阁 大明国师
# 用于电脑版网页   www.xswang.org/book/65298/
# 不适用手机版     m.xswang.org/book/65298/
$starturl = 'http://xswang.org/book/63156/68738007.html'; # 第一章链接
$end = '70478395.html'; # 最后章链接文件

$max = 500; # 循环次数，脚本运行一次下载的网页数

# 提取文章主体的标记
$key1 = '<p class="content_detail">';
$key2 = '">下一';

$url_array = parse_url($starturl);
$host = $url_array['scheme'] . '://' . $url_array['host'];
$path_array = explode('/', $url_array['path']);
$dir1 = '/' . $path_array[1] . '/';
$dir = $path_array[2];
$file_start = $path_array[2] . '/' . $path_array[3];
$txt = $dir . '.txt';
$link = $dir . '-link.log';
if(!file_exists($dir)) mkdir($dir, 0777);

// $html = file_get_contents($starturl);
$html_array = get_url_contents($starturl);
if(!empty($html_array['error'])) die($html_array['error']);
$html = $html_array['body'];
$article = article($html, $key1, $key2)['article'];
file_put_contents($file_start, $article);
file_put_contents($txt, $article);
file_put_contents($link, $url_array['path'] . "\r\n");
$next = article($html, $key1, $key2)['url'];
echo $next . "\n";
exit;
for($i = 0; $i < $max; $i++){
    sleep(rand(1, 10));
    echo $next . "\r\n";
    file_put_contents($link, $next . "\r\n", FILE_APPEND);
    if(strpos($next, $end) !== false) break;
    // $html = file_get_contents($host . $next);
    $html_array = get_url_contents($host . $next);
    if(!empty($html_array['error'])) die($html_array['error']);
    $html = $html_array['body'];

    $article = article($html, $key1, $key2)['article'];

    $file_next = str_replace($dir1, '', $next);
    file_put_contents($file_next, $article);
    file_put_contents($txt, $article, FILE_APPEND);
    $next = article($html, $key1, $key2)['url'];
}


/** ============================ 函数 ============================ */

function article($html, $key1, $key2){
    $html = preg_replace("/\r\n|\r|\n/", "\n", $html);
    $html = preg_replace("/<\s+/is", "<", $html);
    $html = preg_replace("/\s+>/is", ">", $html);
    $html = preg_replace("/<br\/>/is", "", $html);
    $html = preg_replace("'<a href=\"javascript[^>]*?>'iUs", '<a>', $html);
    $html = str_replace("<a>加入书签</a>", "", $html);
    
    preg_match('/<title>(.*?)<\/title>/iUs', $html, $title);
    $title = $title ? $title[1] : '';
    $title = trim($title);
    $title_array = explode('_', $title);
    foreach($title_array as $value){
        if(strpos($value, '第') !== false and strpos($value, '章') !== false){
            $title = $value;
            break;
        }
    }

    if(strpos($html, '">下一页') !== false){
        $key2 = '">下一页</a>';
    }else $key2 = '">下一章</a>';

    $article = explode($key1, $html, 2)[1];
    $article = explode($key2, $article, 2)[0];

    $pos = strrpos(substr($article, 0, -1), "<") + 1;
    $str = substr($article, $pos);
    $url = explode('"', $str)[1];
    $ext = pathinfo($url, PATHINFO_EXTENSION);
    if($ext !== 'html') $url = die($url . 'false: incorrect link');

    for($i = 0; $i < 100; $i++){
        $article = str_replace("\t", "    ", $article);
        $article = str_replace("\r\n", "\n", $article);
        $article = str_replace("\r", "\n", $article);
        $article = str_replace(" \n", "\n", $article);
        $article = str_replace("\n ", "\n", $article);
        $article = str_replace("\n\n", "\n", $article);
        $article = str_replace("  ", " ", $article);
    }

    $article = '<div><h1>' . $title . '</h1></div><div>' . $key1 . trim($article) . $key2 . '</div>';
    $html = '<!DOCTYPE html><html><head><meta charset="utf-8"><title>' . trim($title) . '</title></head><body>' . $article . '</body></html>';
    $html = beautify_html($html);
    return array('article' => $html, 'url' => $url);
}

# HTML 格式化
function beautify_html($html){
    require_once 'libs/beautify-html.php';
    $beautify_config = array(
        'indent_inner_html' => false,
        'indent_char' => " ",
        'indent_size' => 2,
        'wrap_line_length' => 32786,
        'unformatted' => ['code', 'pre', 'span'],
        'preserve_newlines' => false,
        'max_preserve_newlines' => 32786,
        'indent_scripts' => 'normal', // keep|separate|normal
    );
    $beautify = new Beautify_Html($beautify_config);
    $html = $beautify -> beautify($html);
    return $html;
}

# /-------------- 函数部分 --------------/#
// $url = 'http://ipip.info/';
// $res_array =url_get_contents($url);
// $res_array = get_url_contents($url);
// echo 'WAN IP: '. $res_array['body'].'<br>';
function url_get_contents($url){
    # 该链接的来源处/引用处
    $url_array = parse_url($url);
    $refer = $url_array['scheme'] . '://' . $url_array['host'] . '/';
    $pos = strrpos($url, '/', 0);
    $refer = substr($url, 0, $pos + 1);
    # 浏览器语言
    if(empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])){
        $lang = 'zh-CN,zh; q=0.9';
    }else{
        $lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
    }
     # 浏览器标识
    if(empty($_SERVER['HTTP_USER_AGENT'])){
        $useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36';
    }else{
        $useragent = $_SERVER['HTTP_USER_AGENT'];
    }
    $cookie_jar = __DIR__ . '/tmp/' . md5($url_array['host']) . '.cookie';

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL , $url);
    curl_setopt($ch, CURLOPT_USERAGENT , $useragent);
    curl_setopt($ch, CURLOPT_REFERER , $refer);
    curl_setopt($ch, CURLOPT_HTTPHEADER , ["Accept-Language: $lang"]);
    curl_setopt($ch, CURLOPT_HEADER , true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER , true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYSTATUS , false); #不验证证书状态
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER , false); #禁止验证对等证书
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST , false); #不检查证书公用名的存在和与主机名匹配
    curl_setopt($ch, CURLOPT_SSL_ENABLE_ALPN , false); #禁用用于协商到http2的ALPN,
    curl_setopt($ch, CURLOPT_SSL_ENABLE_NPN , false); #禁用用于协商到http2的NPN
    curl_setopt($ch, CURLOPT_TIMEOUT , 60); #响应超时
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT , 10); #链接超时

    $result = curl_exec($ch);
    if(curl_exec($ch) === false){
        $curl_errno = curl_errno($ch); # 返回最后一次的错误代码
        $curl_error = curl_error($ch); # 返回当前会话最后一次错误的字符串
        $result = '[' . trim($curl_errno) . '] ' . "\r\n\r\n" . trim($curl_error);
    }else{
        $curl_errno = '';
        $curl_error = '';
    }
    curl_close($ch);
    
    $res_array = explode("\r\n\r\n", $result, 2);
    $res_array = array(
        'header' => $res_array[0],
        'body' => $res_array[1],
        'error' => '[' . $curl_errno . '] ' . $curl_error,
    );
    return $res_array;
}

# 获取url内容,返回数组
function get_url_contents($url){
    # 该链接的来源处/引用处
    $url_array = parse_url($url);
    $refer = $url_array['scheme'] . '://' . $url_array['host'] . '/';
    $pos = strrpos($url, '/', 0);
    $refer = substr($url, 0, $pos + 1);
    # 浏览器语言
    if(empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])){
        $lang = 'zh-CN,zh; q=0.9';
    }else{
        $lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
    }
    # 浏览器标识
    if(empty($_SERVER['HTTP_USER_AGENT'])){
        $useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36';
    }else{
        $useragent = $_SERVER['HTTP_USER_AGENT'];
    }
    
    $options = array(
        'http' => array(
            'method' => "GET",
            'header' => "Accept-language: $lang\r\n" .
                        "Referer: $refer\r\n" .
                        "User-Agent: $useragent\r\n" .
                        "Cookie: foo=bar\r\n"
        ),
        "ssl" => array(
            "verify_peer" => false,
            "verify_peer_name" => false,
        )
    );
    
    $context = stream_context_create($options);
    set_error_handler(function($err_severity, $err_msg, $err_file, $err_line, array$err_context){
            throw new ErrorException($err_msg, 0, $err_severity, $err_file, $err_line);
    }, E_WARNING);
    try{
        $body = file_get_contents($url, false, $context);
        $header = $http_response_header;
    }
    catch(Exception $e){
        $error = $e -> getMessage();
    }
    # restore the previous error handler 还原以前的错误处理程序
    restore_error_handler();
    if(!isset($body)) $body = NULL;
    if(!isset($header)) $header = NULL;
    if(!isset($error))$error = NULL;
    $res_array = array(
        'header' => $header,
        'body' => $body,
        'error' => $error,
    );
    return $res_array;
}

function get_meta_charset($html){
    // $charset = preg_match("/<meta.+?charset=[^\w]?([-\w]+)/i", $html, $temp) ? strtolower($temp[1]):"";
    $html = preg_replace("/\r\n|\r|\n/", ' ', $html);
    $html = preg_replace("/<\s+/is", "<", $html);
    $html = preg_replace("/\s+>/is", ">", $html);
    
    preg_match_all('/<meta.*?>/i', $html, $matches);
    $meta = '';
    foreach($matches[0] as $value){
        $value = strtolower(trim($value));
        # 多个空格转为一个空格
        $value = preg_replace("/\s(?=\s)/", "\\1", $value);
        // $value = preg_replace("/ {2,}/", "", $value); # {2,}前面的空格不能少
        $value = preg_replace("/'/", '"', $value);
        $value = str_replace(array(' "', '=" '), array('"', '="'), $value);
        $value = str_replace(array('= ', ' ='), array('=', '='), $value);
        if(strpos($value, 'charset') !== false) $meta .= $value . "\n";
    }
    return $meta;
}
