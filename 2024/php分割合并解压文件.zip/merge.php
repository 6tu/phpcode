<?php
# 对生成 数字- 为前缀的文件名进行合并

$path = './temp/10m.zip';  # 合并后的文件名，和分割的文件同目录

$path_info = pathinfo($path); // print_r($path_info);
$dir = $path_info['dirname'] .'/';
$fn = $path_info['basename'];

if(file_exists($path)){
    $bakfn = $dir . date("YmdHis") .'-'. $fn;
    rename($path, $bakfn);
    echo "\n $path file already exists, renamed to $bakfn<br>\n\n";
}
$str = '';
for($i=0; ; $i++){
    $path_split = $dir . $i .'-' . $fn;
    if(file_exists($path_split) === false){
        echo " $path_split file does not exist<br>\n\n";
        break;
    }
    $str .= file_get_contents($path_split);
}
file_put_contents($path, $str);
echo " $path File merge completed<br>\n";
