<?php
# 生成 数字- 为前缀的文件名

$path = './temp/10m.zip';  # 要分割的文件
$len = 2048576;     # 分割成 2M

if(file_exists($path) === false) die("\n<br> file does not exist<br>\n");
$path_info = pathinfo($path); // print_r($path_info);
$dir = $path_info['dirname'] .'/';
$fn = $path_info['basename'];

$filesize = filesize($path);

$str = '';
for($i=0; ; $i++){
    $start = $len * $i;
    if($start > $filesize) break;
    $str = file_get_contents($path, false, null, $start, $len);
    file_put_contents($dir . $i .'-'. $fn, $str);
    echo " ". $dir . $i .'-'. $fn ."<br>\n";
}
echo "\n<br> Split completed<br>\n";
