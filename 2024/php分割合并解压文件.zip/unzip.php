<?php
# 解压缩函数，需要开启php_zip扩展

unzip_file("./temp/10m.zip", "./temp/jieya");

function unzip_file($file, $destination){
    $zip = new ZipArchive();
    if($zip -> open($file) !== TRUE){
        die (" 文件不存在或不是有效的压缩包<br>\n\n");
    }
    $zip -> extractTo($destination);
    $zip -> close();
    echo " 已解压文件到指定目录<br>\n\n";
}
