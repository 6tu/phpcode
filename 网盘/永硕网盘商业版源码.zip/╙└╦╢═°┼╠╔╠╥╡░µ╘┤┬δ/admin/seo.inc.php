<?php 


if(!defined('IN_PHPDISK') || !defined('IN_ADMINCP')) {
	exit('[PHPDisk] Access Denied');
}

switch($action){

	default:

		if($task =='update_setting'){
			form_auth(gpc('formhash','P',''),formhash());

			$setting = array(
			'open_seo' => 0,
			'meta_keywords' => '',
			'meta_description' => '',
			'open_rewrite' => 0,
			);
			$settings = gpc('setting','P',$setting);

			if(!$error){

				settings_cache($settings);

				$sysmsg[] = __('seo_update_success');
				redirect(urr(ADMINCP,"item=$item"),$sysmsg);

			}else{
				redirect('back',$sysmsg);
			}

		}else{
			$apache_rewrite_rules = trim('RewriteEngine On

RewriteRule ^file-([0-9]+)\.html$ viewfile.php?file_id=$1 [NC]
RewriteRule ^viewfile-([0-9]+)-([a-z0-9]*)\.html$ downfile.php?action=view&file_id=$1&file_key=$2 [NC]
RewriteRule ^downfile-([0-9]+)-([a-z0-9]*)\.html$ downfile.php?file_id=$1&file_key=$2 [NC]
RewriteRule ^space-(.+)\.html$ space.php?username=$1 [NC]
');
			$iis_rewrite_rules = trim('[ISAPI_Rewrite]

# 3600 = 1 hour
CacheClockRate 3600

RepeatLimit 32

# Protect httpd.ini and httpd.parse.errors files
# from accessing through HTTP

RewriteRule ^(.*)/file-([0-9]+)\.html$ $1/viewfile\.php\?file_id=$2 [I]
RewriteRule ^(.*)/viewfile-([0-9]+)-([a-z0-9]*)\.html$ $1/downfile\.php\?action=view&file_id=$2&file_key=$3 [I]
RewriteRule ^(.*)/downfile-([0-9]+)-([a-z0-9]*)\.html$ $1/downfile\.php\?file_id=$2&file_key=$3 [I]
RewriteRule ^(.*)/space-(.+)\.html$ $1/space\.php\?username=$2 [I]
');
			$nginx_rewrite_rules = trim('rewrite ^(.*)/file-([0-9]+)\.html$ $1/viewfile.php?file_id=$2 last;
rewrite ^(.*)/viewfile-([0-9]+)-([a-zA-Z0-9]*)\.html$ $1/downfile.php?action=view&file_id=$2&file_key=$3 last;
rewrite ^(.*)/downfile-([0-9]+)-([a-zA-Z0-9]*)\.html$ $1/downfile.php?file_id=$2&file_key=$3 last;
rewrite ^(.*)/space-(.+)\.html$ $1/space.php?username=$2 last;
');
			$setting = $settings;
			require_once template_echo($item,$admin_tpl_dir,'',1);
		}
}
?>