<?php 


include "../includes/commons.inc.php";

require_once template_echo('banner',$admin_tpl_dir,'',1);

include PHPDISK_ROOT."./includes/footer.inc.php";

?>
