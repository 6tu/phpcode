<?php 


include "../includes/commons.inc.php";

aheader($settings[phpdisk_url]);


?>
