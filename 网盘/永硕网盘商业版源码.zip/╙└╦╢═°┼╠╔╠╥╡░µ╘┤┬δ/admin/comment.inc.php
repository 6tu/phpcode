<?php 


if(!defined('IN_PHPDISK') || !defined('IN_ADMINCP')) {
	exit('[PHPDisk] Access Denied');
}

switch($action){

	default:

		if($task !='update_setting'){
			$cmt_ids = gpc('cmt_ids','P',array(''));
			$ids_arr = get_ids_arr($cmt_ids,__('please_select_cmts'));
			if($ids_arr[0]){
				$error = true;
				$sysmsg[] = $ids_arr[1];
			}else{
				$cmt_str = $ids_arr[1];
			}
		}

		if($task =='update_setting'){
			form_auth(gpc('formhash','P',''),formhash());

			$setting = array(
			'open_comment' => 0,
			'check_comment' => 0,
			'open_vote' => 0,
			'open_file_url' => 0,
			);
			$settings = gpc('setting','P',$setting);

			if(!$error){

				settings_cache($settings);

				$sysmsg[] = __('comment_update_success');
				redirect(urr(ADMINCP,"item=$item"),$sysmsg);

			}else{
				redirect('back',$sysmsg);
			}

		}elseif($task =='is_checked'){
			form_auth(gpc('formhash','P',''),formhash());

			if($settings['online_demo']){
				$error = true;
				$sysmsg[] = __('online_demo_deny');
			}
			if(!$error){
				$db->query_unbuffered("update {$tpf}comments set is_checked=1 where cmt_id in ($cmt_str)");
				$sysmsg[] = __('cmt_checked_success');
				redirect(urr(ADMINCP,"item=$item"),$sysmsg);
			}else{
				redirect('back',$sysmsg);
			}
		}elseif($task =='is_unchecked'){
			form_auth(gpc('formhash','P',''),formhash());

			if($settings['online_demo']){
				$error = true;
				$sysmsg[] = __('online_demo_deny');
			}
			if(!$error){
				$db->query_unbuffered("update {$tpf}comments set is_checked=0 where cmt_id in ($cmt_str)");
				$sysmsg[] = __('cmt_unchecked_success');
				redirect(urr(ADMINCP,"item=$item"),$sysmsg);
			}else{
				redirect('back',$sysmsg);
			}
		}elseif($task =='del_cmts'){
			form_auth(gpc('formhash','P',''),formhash());

			if($settings['online_demo']){
				$error = true;
				$sysmsg[] = __('online_demo_deny');
			}
			if(!$error){
				$db->query_unbuffered("delete from {$tpf}comments where cmt_id in ($cmt_str)");
				$sysmsg[] = __('del_cmt_success');
				redirect(urr(ADMINCP,"item=$item"),$sysmsg);
			}else{
				redirect('back',$sysmsg);
			}
		}else{
			$rs = $db->fetch_one_array("select count(*) as total_num from {$tpf}comments");
			$total_num = $rs['total_num'];
			$start_num = ($pg-1) * $perpage;

			$q = $db->query("select c.*,us.username from {$tpf}comments c,{$tpf}users us where c.userid=us.userid order by cmt_id desc limit $start_num,$perpage");
			$cmts = array();
			while($rs = $db->fetch_array($q)){
				$rs['username'] = $rs['username'];
				$rs['name']=$rs['file_key'];
				$rs['content'] = preg_replace("/<.+?>/i","",str_replace('<br>',LF,$rs['content']));
				$rs['status'] = $rs['is_checked'] ? "<span class='txtblue'>".__('checked_txt')."<span>" :"<span class='txtred'>".__('unchecked_txt')."</span>";
				$rs['in_time'] = date("Y-m-d H:i:s",$rs['in_time']);
				$cmts[] = $rs;
			}
			$db->free($q);
			unset($rs);
			$page_nav = multi($total_num, $perpage, $pg, urr(ADMINCP,"item=$item"));
			$setting = $settings;
			require_once template_echo($item,$admin_tpl_dir,'',1);
		}
}
?>