<?php



$configs = array(

	'dbhost' => 'localhost',

	'dbname' => 'root',

	'dbuser' => 'root',

	'dbpasswd' => '',

	'pconnect' => 0,

	'tpf' => 'epan_',

	'charset' => 'utf-8',

	'debug' => '0',

);

define('ADMINCP','admincp');


?>
