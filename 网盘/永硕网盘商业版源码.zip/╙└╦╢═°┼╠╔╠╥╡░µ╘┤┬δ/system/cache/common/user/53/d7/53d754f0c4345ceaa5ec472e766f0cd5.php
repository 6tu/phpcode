<?php

// This is PHPDISK auto-generated file. Do NOT modify me.
// Cache Time: 2013-02-23 08:30:12
// Function: index_last

if(!defined('IN_PHPDISK')){
	exit('[PHPDisk] Access Denied');
}

return 'a:2:{s:8:"username";s:7:"kuaiaaa";s:11:"a_last_user";s:26:"space.php?username=kuaiaaa";}';
?>
