<?php

// This is PHPDISK auto-generated file. Do NOT modify me.
// Cache Time: 2012-10-27 22:16:32
// Function: get_ads|adv_viewfile_download_top

if(!defined('IN_PHPDISK')){
	exit('[PHPDisk] Access Denied');
}

return 'a:0:{}';
?>
