<?php

// This is PHPDISK auto-generated file. Do NOT modify me.
// Cache Time: 2012-10-21 13:42:18
// Function: get_ads|adv_top

if(!defined('IN_PHPDISK')){
	exit('[PHPDisk] Access Denied');
}

return 'a:0:{}';
?>
