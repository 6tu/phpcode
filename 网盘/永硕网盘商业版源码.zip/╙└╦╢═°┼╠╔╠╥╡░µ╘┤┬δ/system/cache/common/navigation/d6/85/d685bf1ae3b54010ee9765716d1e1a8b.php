<?php

// This is PHPDISK auto-generated file. Do NOT modify me.
// Cache Time: 2015-04-05 22:23:39
// Function: get_navigation_link|top

if(!defined('IN_PHPDISK')){
	exit('[PHPDisk] Access Denied');
}

return 'a:0:{}';
?>
