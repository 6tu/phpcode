<?php

// This is PHPDISK auto-generated file. Do NOT modify me.
// Cache Time: 2013-02-23 08:30:12
// Function: get_last_user_list

if(!defined('IN_PHPDISK')){
	exit('[PHPDisk] Access Denied');
}

return 'a:9:{i:0;a:3:{s:8:"username";s:7:"kuaiaaa";s:8:"reg_time";s:5:"01/08";s:7:"a_space";s:26:"space.php?username=kuaiaaa";}i:1;a:3:{s:8:"username";s:10:"l399267756";s:8:"reg_time";s:5:"12/23";s:7:"a_space";s:29:"space.php?username=l399267756";}i:2;a:3:{s:8:"username";s:9:"dsiofhiro";s:8:"reg_time";s:5:"12/20";s:7:"a_space";s:28:"space.php?username=dsiofhiro";}i:3;a:3:{s:8:"username";s:3:"123";s:8:"reg_time";s:5:"12/14";s:7:"a_space";s:22:"space.php?username=123";}i:4;a:3:{s:8:"username";s:6:"aaavvv";s:8:"reg_time";s:5:"12/07";s:7:"a_space";s:25:"space.php?username=aaavvv";}i:5;a:3:{s:8:"username";s:8:"a6542113";s:8:"reg_time";s:5:"11/22";s:7:"a_space";s:27:"space.php?username=a6542113";}i:6;a:3:{s:8:"username";s:10:"liuhaifeng";s:8:"reg_time";s:5:"11/08";s:7:"a_space";s:29:"space.php?username=liuhaifeng";}i:7;a:3:{s:8:"username";s:10:"fengzhizxw";s:8:"reg_time";s:5:"10/21";s:7:"a_space";s:29:"space.php?username=fengzhizxw";}i:8;a:3:{s:8:"username";s:5:"admin";s:8:"reg_time";s:5:"10/21";s:7:"a_space";s:24:"space.php?username=admin";}}';
?>
