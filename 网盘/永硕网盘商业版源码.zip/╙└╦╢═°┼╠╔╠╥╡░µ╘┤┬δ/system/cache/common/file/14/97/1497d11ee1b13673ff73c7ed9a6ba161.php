<?php

// This is PHPDISK auto-generated file. Do NOT modify me.
// Cache Time: 2013-02-23 08:30:12
// Function: get_hot_file

if(!defined('IN_PHPDISK')){
	exit('[PHPDisk] Access Denied');
}

return 'a:0:{}';
?>
