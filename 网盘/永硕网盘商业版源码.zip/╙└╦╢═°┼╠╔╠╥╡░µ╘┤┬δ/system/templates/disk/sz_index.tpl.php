<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2015-04-23 17:22:21

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>
<table cellpadding="0" border="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
        <div id="ysleft">
        <h2>空间后台操作菜单</h2>
        <strong>主要操作</strong>
        <ul class="yslb3">
        <li><a href="/user.php">空间状态</a></li>
        <li><a href="/user.php?act=sj">空间升级</a></li>
<!--        <li><a href="/user.php?act=yq">空间延期</a></li>
-->        </ul>
        <strong>账户管理</strong>
        <ul class="yslb3">
        <li><a href="/zh.php">账户充值</a></li>
        <li><a href="/zh.php?act=cz">充值记录</a></li>
        <li><a href="/zh.php?act=xf">消费记录</a></li>
        </ul>
        <strong>空间设置</strong>
        <ul class="yslb3">
        <li><a href="/sz.php" id="xz">常规设置</a></li>
        <li><a href="/sz.php?act=qx">访客权限</a></li>
        <li><a href="/sz.php?act=lj">首页链接</a></li>
        <li><a href="/sz.php?act=px">目录排序方式</a></li>
        <li><a href="/sz.php?act=fg">空间风格</a></li>
        <li><a href="/sz.php?act=zl">设置个人资料</a></li>
        </ul>
        <strong>空间安全</strong>
        <ul class="yslb3">
        <li><a href="/aq.php">设置登录密码</a></li>
        <li><a href="/aq.php?act=glmm">修改管理密码</a></li>
        <!--<li><a href="/aq.php?act=xgyx">修改邮箱</a></li>-->
        <li><a href="/aq.php?act=szmb">设置密保</a></li>
        <li><a href="/aq.php?act=xgmb">修改密保</a></li>
        <!--<li><a href="/aq.php?act=wjmm">忘记密码</a></li>-->
        </ul>
        <strong>其它</strong>
        <ul class="yslb3">

        <li><a href="/ly.php">留言管理</a></li>
        </ul></div>
    </td><td>

<div id="ysright">
        <h1><span id="yhztxs"><label class="dl1">用户名：<font color="green"><?=$pd_username?></font>  账户余额：<?=$userinfo['wealth']?>元  <a href="/zh.php">账户充值</a> <a href="/account.php?action=logout">退出</a></label></span><img width="32" height="32" border="0" alt="" src="/images/Tools.gif">常规设置</h1>
            <div class="ysdb2">
            <form id="ctl00" action="sz.php?act=szcg" method="post" name="ctl00">
                <table width="100%" border="1" id="table1">
	                <tbody>
                    
                    <tr>
		                <td width="96" class="tdbt">1.空间标题</td>
		                <td><input type="text" style="width:400px;" id="t1" value="<?php 
 echo htmlspecialchars($userinfo['t1']);
 ?>" name="t1"></td>
	                </tr>
                    
	                
						<tr>
		                <td width="96" valign="top" class="tdbt">2.装修代码</td>
		                <td><input type="text" style="width:400px;" id="t4" name="t4" value="<?php 
 echo htmlspecialchars($userinfo['t4']);
 ?>">
                            <ul class="yslb2">
								<li>装修代码只能放置页面特效代码,网页的风格以及特效代码放置！</li>
			                    <li>如果在此处写入文字后空间美观就会导致错位，请删除所写文字即可！</li>
			                </ul>
		                </td>
	                </tr>
					
					<tr>
		                <td width="96" valign="top" class="tdbt">3.首页寄语</td>
		                <td><input type="text" style="width:400px;" id="t3" name="t3" value="<?php 
 echo htmlspecialchars($userinfo['t3']);
 ?>">
		                    <ul class="yslb2">
			                    <li>首页寄语说明只显示于网盘底部，可以写一些介绍、欢迎等类型的文字</li>
			                    <li>如果在此处写入代码后空间不能正常使用，请删除所写代码即可恢复使用！</li>
			                </ul>
		                </td>
	                </tr>
                </tbody></table>
                <br />
                <table width="100%" border="1" id="table1">
	                <tbody>
                    
                    <tr>
		                <td width="96" class="tdbt">1.SEO标题</td>
		                <td><input type="text" style="width:400px;" id="seo1" value="<?php 
 echo htmlspecialchars($userinfo['seo1']);
 ?>" name="seo1"></td>
	                </tr>
                    <tr>
		                <td width="96" class="tdbt">2.SEO关键字</td>
		                <td><input type="text" style="width:400px;" id="seo2" value="<?php 
 echo htmlspecialchars($userinfo['seo2']);
 ?>" name="seo2"></td>
	                </tr>
                    
	                <tr>
		                <td width="96" valign="top" class="tdbt">3.SEO描述</td>
		                <td><input type="text" style="width:400px;" id="seo3" name="seo3" value="<?php 
 echo htmlspecialchars($userinfo['seo3']);
 ?>">
		                </td>
	                </tr>
						                <tr>
		                <td width="96" valign="top" class="tdbt">4.网盘访问密码</td>
		                <td><input type="text" style="width:400px;" id="mima" name="mima" value="<?php 
 echo htmlspecialchars($userinfo['mima']);
 ?>">
                            <ul class="yslb2">
								<li>网盘访问密码功能后期添加中。。。。</li>
			                </ul>
		                </td>
	                </tr>
                </tbody></table>
            <p>
                <font color="#FF0000">
                <span id="ysts">请在上面修改设置</span>
                </font>
                <input type="submit" id="bu1" onclick="return confirm('请确认是否提交设置');" value="提交设置" name="bu1">
            </p>
            <ul class="yslb2">
                <li>空间标题最多支持100个字符，首页寄语最多支持600个字符。</li>
            </ul>
            </form>
            </div>
        </div>



        </td></tr></tbody></table>