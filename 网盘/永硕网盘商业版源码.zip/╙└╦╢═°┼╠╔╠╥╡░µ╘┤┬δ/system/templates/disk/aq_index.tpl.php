<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2015-04-06 16:30:24

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>
<table cellpadding="0" border="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
        <div id="ysleft">
        <h2>空间后台操作菜单</h2>
        <strong>主要操作</strong>
        <ul class="yslb3">
        <li><a href="/user.php">空间状态</a></li>
        <li><a href="/user.php?act=sj">空间升级</a></li>
<!--        <li><a href="/user.php?act=yq">空间延期</a></li>
-->        </ul>
        <strong>账户管理</strong>
        <ul class="yslb3">
        <li><a href="/zh.php">账户充值</a></li>
        <li><a href="/zh.php?act=cz">充值记录</a></li>
        <li><a href="/zh.php?act=xf">消费记录</a></li>
        </ul>
        <strong>空间设置</strong>
        <ul class="yslb3">
        <li><a href="/sz.php">常规设置</a></li>
        <li><a href="/sz.php?act=qx">访客权限</a></li>
        <li><a href="/sz.php?act=lj">首页链接</a></li>
        <li><a href="/sz.php?act=px">目录排序方式</a></li>
        <li><a href="/sz.php?act=fg">空间风格</a></li>
        <li><a href="/sz.php?act=zl">设置个人资料</a></li>
        </ul>
        <strong>空间安全</strong>
        <ul class="yslb3">
        <li><a href="/aq.php" id="xz">设置登录密码</a></li>
        <li><a href="/aq.php?act=glmm">修改管理密码</a></li>
        <li><a href="/aq.php?act=szmb">设置密保</a></li>
        <li><a href="/aq.php?act=xgmb">修改密保</a></li>
        <!--<li><a href="/aq.php?act=wjmm">忘记密码</a></li>-->
        </ul>
        <strong>其它</strong>
        <ul class="yslb3">

        <li><a href="/ly.php">留言管理</a></li>
        </ul></div>
    </td><td>
        <div id="ysright">
            <h1><label class="dl1">用户名：<font color="green"><?=$pd_username?></font>  账户余额：<?=$userinfo['wealth']?>元  <a href="/zh.php">账户充值</a> <a href="/account.php?action=logout">退出</a></label><img width="32" height="32" border="0" alt="" src="/images/xg.gif">设置登录密码</h1>
<div class="ysdb2">
            <p style="font-size:10pt; "><b>登录密码是登录空间的密码。如果不设置登录密码，则可以直接进入空间。</b></p>
            <form id="ctl00" action="aq.php?act=dlmm" method="post" name="ctl00">
                <div style="border:1px solid #C3DAEB;padding:5px; width:320px;background-color:#E4F3FC;">
                    <div onclick="document.forms[0].p1.checked=true;document.forms[0].t2.value='';" style="cursor:hand;">
                    <input type="radio" <?php  if(empty($userinfo['dlmm'])){echo ' checked="checked"';}  ?> id="p1" name="rsd" value="0">无登录密码（输入空间地址后既可直接打开空间）。</div>
                    <br>
                    <div onclick="document.forms[0].p2.checked=true;document.forms[0].t2.focus();" style="cursor:hand;">
                    <input type="radio" <?php  if(!empty($userinfo['dlmm'])){echo ' checked="checked"';}  ?> id="p2" name="rsd" value="1">设置登录密码为：<input type="text" id="t2" value="<?=$userinfo['dlmm']?>" name="t2"></div>
                </div>
                <!-- 隐藏的控件，为了可以按回车激活按钮  -->
                <div style=" display:none;"><input type="text" style="width:130px;" id="TextBox1" name="TextBox1"></div>
            <p>
                <font color="#FF0000">
                <span id="ysts">请在上面修改设置</span>
                </font>
                <input type="submit" id="bu1" onclick="return check();" value="提交设置" name="bu1">
            </p>
            <ul class="yslb2">
                <li>登录密码是登录空间的密码，请尽量不要和管理密码相同</li>
                <li>登录密码支持字母和数字，最多15个字符</li>
            </ul>
            </form>
            </div>

        </div>
        </td></tr></tbody></table>