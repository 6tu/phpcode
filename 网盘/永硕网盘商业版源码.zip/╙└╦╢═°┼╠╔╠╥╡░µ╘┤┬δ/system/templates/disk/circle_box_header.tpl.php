<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2014-09-22 22:09:57

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>
<?php 
##
#	Project: PHPDISK File Storage Solution
#	This is NOT a freeware, use is subject to license terms.
#
#	Site: http://www.phpdisk.com
#
#	$Id: circle_box_header.tpl.html 2 2011-05-27 03:00:17Z along $
#
#	Copyright (C) 2008-2012 PHPDisk Team. All Rights Reserved.
#
##
 ?>
<?php !defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied!'); ?>
<div class="user_box">
<b class="ctop">
<b class="cb1"></b><b class="cb2"></b><b class="cb3"></b><b class="cb4"></b>
</b>