<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2015-04-23 17:38:58

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>
<table cellpadding="0" border="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
        <div id="ysleft">
        <h2>空间后台操作菜单</h2>
        <strong>主要操作</strong>
        <ul class="yslb3">
        <li><a href="/user.php" id="xz">空间状态</a></li>
        <li><a href="/user.php?act=sj">空间升级</a></li>
<!--        <li><a href="/user.php?act=yq">空间延期</a></li>
-->        </ul>
        <strong>账户管理</strong>
        <ul class="yslb3">
        <li><a href="/zh.php">账户充值</a></li>
        <li><a href="/zh.php?act=cz">充值记录</a></li>
        <li><a href="/zh.php?act=xf">消费记录</a></li>
        </ul>
        <strong>空间设置</strong>
        <ul class="yslb3">
        <li><a href="/sz.php">常规设置</a></li>
        <li><a href="/sz.php?act=qx">访客权限</a></li>
        <li><a href="/sz.php?act=lj">首页链接</a></li>
        <li><a href="/sz.php?act=px">目录排序方式</a></li>
        <li><a href="/sz.php?act=fg">空间风格</a></li>
        <li><a href="/sz.php?act=zl">设置个人资料</a></li>
        </ul>
        <strong>空间安全</strong>
        <ul class="yslb3">
        <li><a href="/aq.php">设置登录密码</a></li>
        <li><a href="/aq.php?act=glmm">修改管理密码</a></li>
        <!--<li><a href="/aq.php?act=xgyx">修改邮箱</a></li>-->
        <li><a href="/aq.php?act=szmb">设置密保</a></li>
        <li><a href="/aq.php?act=xgmb">修改密保</a></li>
        <!--<li><a href="/aq.php?act=wjmm">忘记密码</a></li>-->
        </ul>
        <strong>其它</strong>
        <ul class="yslb3">
        
        <li><a href="/ly.php">留言管理</a></li>
        </ul></div>
    </td><td>
        <div id="ysright">
            <h1><span id="yhztxs"><label class="dl1">用户名：<font color="green"><?=$pd_username?></font>  账户余额：<?=$userinfo['wealth']?>元  <a href="/zh.php">账户充值</a> <a href="/account.php?action=logout">退出</a></label></span><img width="32" height="32" border="0" alt="" src="/images/ys168_sd_cg.gif">空间状态</h1>
            <h3>基本状态</h3>
            <div class="ysdb2">
                <table>
	                <tbody>
					<tr>
		                <td width="100" class="tdbt">空间地址:</td>
		                <td><span id="la01"><?=$diskurl?>k.php?name=<?=$pd_username?></span></td>
	                </tr>
						<tr>
		                <td width="100" class="tdbt">绑定域名:</td>
		                <td>
						<ul class="yslb2">
			                    <li>网盘网址太长？记不住？我们网盘升级啦！可自定义！</li>
			                    <li><a title="用支付宝余额进行购买绑定" href="#">域名绑定</a></li>
			                </ul>
						</td>
	                </tr>
	                <tr>
		                <td class="tdbt">空间级别:</td>
		                <td><span id="la03"><?=$pd_group_name?>[<?=$diskinfo['max_storage']?>] 
<a href="/user.php?act=sj">空间升级</a></span></td>
	                </tr>
	                <tr>
		                <td class="tdbt">账户余额:</td>
		                <td><span id="la04"><font size="3" color="blue"><b><u><?=$userinfo['wealth']?></u></b></font>元
<a href="/zh.php">账户充值</a>(账户余额可用于空间升级)</span></td>
	                </tr>
	                <tr>
		                <td class="tdbt">服务到期日:</td>
		                <td><span id="la05"><p><font color="red"><b><?=$dqsj?></b></font></p></span></td>
	                </tr>
                </tbody></table>
                <h3>其它方面</h3>
                
                
                    <div style="height:35px !important;height:40px;border:2px dashed #A6D2FF;padding:5px;background-color:#FFFFBB;">
	                    <font color="black">禁止存放反动、色情、游戏辅助外挂及其他国家法律法规禁止的内容，如收到举报经查实后，空间将被关闭。</font>
                    </div>
                    
                    
                
                
                <ul class="yslb2">
                <span id="la06"><li>设置密保问题可以在您忘记密码的时候找回。<a href="/aq.php?act=szmb">进行设置</a></li><li>您尚未设置Ｅ盘标题，<a href="/sz.php">进入设置</a></li><li>及时更新您的个人资料有助于我们更好的为您服务，<a href="/sz.php?act=zl">现在更新</a></li><li>设置访客权限有助于您对空间的管理，<a href="/sz.php?act=qx">进入设置</a></li><li>您尚未设置首页链接，<a href="/sz.php?act=lj">进入设置</a></li><li>如果您没有设置空间自定义区，请查看<a href="/diy.php">如何设置自定义区</a></li><li>使用中如有问题，请查看<a href="/help.php">Ｅ盘操作说明</a>，或到<a href="/kf.php">客服中心</a>和我们联系</li></span>
                </ul>
                
            </div>
        </div>
        </td></tr></tbody></table>