<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2015-04-06 17:16:52

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>
<table cellpadding="0" border="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
        <div id="ysleft">
        <h2>空间后台操作菜单</h2>
        <strong>主要操作</strong>
        <ul class="yslb3">
        <li><a href="/user.php">空间状态</a></li>
        <li><a href="/user.php?act=sj">空间升级</a></li>
<!--        <li><a href="/user.php?act=yq">空间延期</a></li>
-->        </ul>
        <strong>账户管理</strong>
        <ul class="yslb3">
        <li><a href="/zh.php" id="xz">账户充值</a></li>
        <li><a href="/zh.php?act=cz">充值记录</a></li>
        <li><a href="/zh.php?act=xf">消费记录</a></li>
        </ul>
        <strong>空间设置</strong>
        <ul class="yslb3">
        <li><a href="/sz.php">常规设置</a></li>
        <li><a href="/sz.php?act=qx">访客权限</a></li>
        <li><a href="/sz.php?act=lj">首页链接</a></li>
        <li><a href="/sz.php?act=px">目录排序方式</a></li>
        <li><a href="/sz.php?act=fg">空间风格</a></li>
        <li><a href="/sz.php?act=zl">设置个人资料</a></li>
        </ul>
        <strong>空间安全</strong>
        <ul class="yslb3">
        <li><a href="/aq.php">设置登录密码</a></li>
        <li><a href="/aq.php?act=glmm">修改管理密码</a></li>
        <!--<li><a href="/aq.php?act=xgyx">修改邮箱</a></li>-->
        <li><a href="/aq.php?act=szmb">设置密保</a></li>
        <li><a href="/aq.php?act=xgmb">修改密保</a></li>
        <!--<li><a href="/aq.php?act=wjmm">忘记密码</a></li>-->
        </ul>
        <strong>其它</strong>
        <ul class="yslb3">
   
        <li><a href="/ly.php">留言管理</a></li>
        </ul></div>
    </td><td>
    <style type="text/css">
	ul.mllb			{margin:0;width:100%;}
	ul.mllb li		{float:left;list-style-type:none;margin:3px 6px 0 0;font-size:9pt;line-height:120%;}
	ul.mllb a		{font-weight:bold;font-size:9pt;color:#000;padding:5px 3px 3px 3px;height:20px;background-color:#E1E1FF;border:1px solid #000;text-align:center;TEXT-DECORATION: none;}
	ul.mllb a:hover	{color:#490685;background-color:#FFEEE1;border:1px solid #1706FF;}
	ul.mllb a:visited {color:#000;}
</style>
        <div id="ysright">
            <h1><span id="yhztxs"><label class="dl1">用户名：<font color="green"><?=$pd_username?></font>  账户余额：<?=$userinfo['wealth']?>元  <a href="/zh.php">账户充值</a> <a href="/account.php?action=logout">退出</a></label></span><img width="32" height="32" border="0" alt="" src="/images/money.gif">支付宝支付</h1>


<div style="float:right;width:120px;border:1px solid #003399;">
<h4 style="background-color:#003399;font-size:9pt;margin:1px;padding:1px;color:#fff;text-align:center;">其它支付方式</h4>
<ul class="yslb">
<!--    <li><a href="/ht/yfk/alipay/alipay_zx.aspx">网银在线支付</a></li>
-->    <li><a href="/zh.php?act=zfb">支付宝支付</a></li>
<!--    <li><a href="/ht/yfk/tenpay/tenpay.aspx">财付通支付</a></li>
    <li><a href="/ht/yfk/yhzz.aspx">银行汇款或转账</a></li>
--></ul>
<!--&nbsp;<a href="/ht/yfk/" class="goback">返回</a>
--></div>



<div class="ysdb2">
<form name="Form1" method="post" action="/alipay.php" id="Form1">
            <table border="1" style="width:300px;">
	            <tbody><tr>
		            <td width="59" class="tdbt">充值金额:</td>
		            <td><input type="text" style="width:50px;" id="te_je" name="te_je">元</td>
	            </tr>
            </tbody></table>

            <p><input type="submit" style="width:140;" id="butj" onclick="return confirm('您现在登录充值的用户名是：\n\n<?=$pd_username?>\n\n请确认继续充值');" value="通过支付宝结算" name="butj"></p>
            </form>
            </div>
<ul class="yslb2">
                <li>支付宝结算，安全快捷，推荐使用</li>
                <li>支付宝支付支持<font color="blue">支付宝余额支付</font>和<font color="blue">银行卡在线支付</font>等多种支付方式，请在打开的页面中按需要选择支付。</li>
                <li>源码E盘内不允许存储传播任何有关反动、色情、游戏外挂、辅助、私服、黑客软件、木马、病毒、软件破解或者网站破解等违反中国法律法规的内容。如果发现或被举报并查实，将关闭违规空间，充值费用不予退回。</li>
            </ul>
        </div>
        </td></tr></tbody></table>
