<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2015-04-06 17:08:57

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>
<table border="0" cellpadding="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
        <div id="ysleft">
            <h2>说明</h2>
            <div style="padding:5px;">
	            <b><font size="3">登</font></b>录成功后，您可以在空间后台进行空间设置、空间升级或延期等，或在客服中心提交问题。
            </div>
        </div>
        </td><td>
        <div id="ysright">
            <h1><span id="yhztxs"></span>
            <img width="30" height="27" border="0" alt="" src="/ht/dl.gif">管理员登录</h1>
<?php 
if(count($sysmsg)){
 ?>
<div class="cboxcontent">
<?php 
	for($i=0;$i<count($sysmsg);$i++){
 ?>
<li><span>*</span> <?=$sysmsg[$i]?></li>
<?php 
	}
 ?>
</div>
<?php 

}
unset($sysmsg);
 ?>
           <div style="display:block;" class="ysdb2">
                <form id="ctl00" action="<?=urr("account","")?>" method="post" name="ctl00">
                <table>
	                <tbody><tr>
		                <td width="80" class="tdbt">管理员账号:</td>
		                <td><input type="text" style="width:120px;" id="dl1" value="" name="username"></td>
	                </tr>
	                <tr>
		                <td class="tdbt">管理密码:</td>
		                <td><input type="password" style="width:120px;" id="dl2" name="password"></td>
	                </tr>
	                
                </tbody></table>
                <p>
<input type="hidden" name="action" value="<?=$action?>" />
<input type="hidden" name="task" value="<?=$action?>" />
<input type="hidden" name="ref" value="<?=$ref?>" />
<input type="hidden" name="formhash" value="<?=$formhash?>" />
                <input type="submit" style="margin-left:90px;" id="bu1" value=" 登 录 " name="bu1">
                </p>
                </form>
            </div>
        </div>
    </td></tr></tbody></table>