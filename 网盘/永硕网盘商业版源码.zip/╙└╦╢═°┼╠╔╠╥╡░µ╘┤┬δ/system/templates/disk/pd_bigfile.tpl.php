<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2015-04-07 14:42:49

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>
<table cellpadding="0" border="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
        <div id="ysleft">
        <h2>帮助菜单</h2>
        <ul style="height:80px; width:170px; overflow:hidden;" class="yslb3">
	        <li><a href="/help.php">Ｅ盘使用说明</a></li>
	        <li><a href="/diy.php">如何设置自定义区</a></li>
	        <li><a href="/bigfile.php" id="xz">采用分压缩方式上传大文件</a></li>
        </ul>
        </div>
        </td><td>
        <div id="ysright">
            <h1><img width="30" height="27" border="0" alt="" src="/images/js1.gif">采用分压缩方式上传大文件</h1>
            <p style="text-indent: 2em;">为了安全稳妥的上传大文件（&gt;50M）,建议您把文件分压缩后（每个包&lt;=30M）再逐个上传。操作方法如下</p>
            <ul class="yslb2">
                <li>右键点击您要上传的文件，在右键菜单里选择"添加到压缩文件"<img width="309" height="188" alt="" src="/images/big0.gif"></li>
                <li>在弹出的界面里设置每个包的大小，一般为"30M",然后点确定即进行分压缩<img width="413" height="358" alt="" src="/images/big1.gif"></li>
                <li>文件所在目录将出现若干个分压缩包，把这些分压缩包逐个上传即可<img width="484" height="74" alt="" src="/images/big2.gif"></li>
                <li>解压方法：只要把这些分压缩包下载并存放于同一目录，点任意一个包解压即可还原成原来文件。</li>
            </ul>
        </div>
    </td></tr></tbody></table>