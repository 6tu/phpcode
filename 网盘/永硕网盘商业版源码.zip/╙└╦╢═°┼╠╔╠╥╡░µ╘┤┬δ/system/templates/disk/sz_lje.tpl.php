<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2015-04-06 17:45:09

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>
<table cellpadding="0" border="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
        <div id="ysleft">
        <h2>空间后台操作菜单</h2>
        <strong>主要操作</strong>
        <ul class="yslb3">
        <li><a href="/user.php">空间状态</a></li>
        <li><a href="/user.php?act=sj">空间升级</a></li>
<!--        <li><a href="/user.php?act=yq">空间延期</a></li>
-->        </ul>
        <strong>账户管理</strong>
        <ul class="yslb3">
        <li><a href="/zh.php">账户充值</a></li>
        <li><a href="/zh.php?act=cz">充值记录</a></li>
        <li><a href="/zh.php?act=xf">消费记录</a></li>
        </ul>
        <strong>空间设置</strong>
        <ul class="yslb3">
        <li><a href="/sz.php">常规设置</a></li>
        <li><a href="/sz.php?act=qx">访客权限</a></li>
        <li><a href="/sz.php?act=lj" id="xz">首页链接</a></li>
        <li><a href="/sz.php?act=px">目录排序方式</a></li>
        <li><a href="/sz.php?act=fg">空间风格</a></li>
        <li><a href="/sz.php?act=zl">设置个人资料</a></li>
        </ul>
        <strong>空间安全</strong>
        <ul class="yslb3">
        <li><a href="/aq.php">设置登录密码</a></li>
        <li><a href="/aq.php?act=glmm">修改管理密码</a></li>
        <!--<li><a href="/aq.php?act=xgyx">修改邮箱</a></li>-->
        <li><a href="/aq.php?act=szmb">设置密保</a></li>
        <li><a href="/aq.php?act=xgmb">修改密保</a></li>
        <!--<li><a href="/aq.php?act=wjmm">忘记密码</a></li>-->
        </ul>
        <strong>其它</strong>
        <ul class="yslb3">
        
        <li><a href="/ly.php">留言管理</a></li>
        </ul></div>
    </td><td>
<style type="text/css">
    .xs{    background: none repeat scroll 0 0 #E4F3FC;
    border: 1px solid #C3DAEB;
    color: #000000;
    font-size: 9pt;
    min-height: 50px;
    padding: 5px;
    width: 450px;
    word-break: break-all;}
</style>
<script language="javascript" type ="text/javascript">
    window.onload = function() {
        var ts = "";
        if (ts != "") { alert(ts); }
    }

    function check() {
        var ys = document.forms[0];
        if (checkzf(ys.ljmc.value) == 'F') { alert('显示名称不支持特殊字符的输入。'); ys.ljmc.focus(); return false; }
        if (checkzf(ys.ljdz.value) == 'F') { alert('链接地址不支持特殊字符的输入。'); ys.ljdz.focus(); return false; }
        if (ys.ljmc.value == '') { alert('显示名称不能为空。'); ys.ljmc.focus(); return false; }
        if (ys.ljdz.value == '') { alert('链接地址不能为空。'); ys.ljdz.focus(); return false; }
        if (ys.ljdz.value.length < 9) { alert('请填写正确完整的链接地址。地址必须是 http:// 或 https:// 或 ftp://  开头。'); ys.ljdz.focus(); return false; }
        if (ys.ljdz.value.indexOf('<') >= 0 || ys.ljdz.value.indexOf('>') >= 0) { alert('链接地址不支持特殊字符（< >）输入。'); ys.ljdz.focus(); return false; }
        var ysdz = ys.ljdz.value.toLowerCase();
        if (ysdz.substr(0, 7) != 'http://' && ysdz.substr(0, 8) != 'https://' && ysdz.substr(0, 6) != 'ftp://') { alert('请填写正确完整的链接地址。地址必须是 http:// 或 https:// 或 ftp://  开头。'); ys.ljdz.focus(); return false; }
        if (!confirm('请确认是否进行修改！')) return false;
    }
    
    function checkzf(nr) {
        var zf = "\\;,'"
        for (i = 0; i <= zf.length - 1; i++) {
            if (nr.indexOf(zf.substr(i, 1)) >= 0) { return "F" }
        }
        return "T"
    }
	function urlt(){
        window.location = "sz.php?act=lj";
	}
</script>
<div id="ysright">
        <h1><span id="yhztxs"><label class="dl1">用户名：<font color="green"><?=$pd_username?></font>  账户余额：<?=$userinfo['wealth']?>元  <a href="/zh.php">账户充值</a> <a href="/account.php?action=logout">退出</a></label></span><img width="32" height="32" border="0" alt="" src="/images/Tools.gif">首页链接-编辑</h1>
            <div class="ysdb2">
<form id="ctl00" action="sz.php?act=lkedit" method="post" name="ctl00">
                    <table style="background:#fff; border:0px;">
                        <tbody><tr>
                            <td style="border:0px;">显示名称：<input type="text" style="width:450px;" id="ljmc" value="<?php 
 echo htmlspecialchars($userlinkse['linkt']);
 ?>" name="ljmc"></td>
                        </tr>
                        <tr>
                            <td style="border:0px;">链接地址：<input type="text" style="width:450px;" id="ljdz" value="<?=$userlinkse['linku']?>" name="ljdz"></td>
                        </tr>
                    </tbody></table>
                    <br>       
                    <input type="hidden"  value="<?=$userlinkse['id']?>" name="id">             
                    <input type="submit" id="bu2" onclick="return check();" value=" 提 交 " name="bu2">&nbsp;&nbsp;
                    <input type="button" id="bu1" onclick="return urlt();" value=" 取 消 " name="bu1">
                
                </form>
            </div>
            <ul class="yslb2">
            <li>链接地址必须是 http:// 或 https:// 或 ftp://  开头。</li>
            <li>为了加强空间安全管理，防止空间内挂马，免费空间不支持写入script代码和iframe。</li>
            <li>链接名称和链接地址不支持字符（ , ; ' \ ）。链接地址不支持字符（ &lt; &gt; ）</li>
            <li>如果需要显示图片，请在显示名称的框里输入：&lt;img src="图片地址" /&gt; </li>
            <li>首页链接的位置如图所示：<br><img style="width:399px;height:171px" src="/images/sylj.gif" alt=""></li>
            </ul>

</div>

        </td></tr></tbody></table>