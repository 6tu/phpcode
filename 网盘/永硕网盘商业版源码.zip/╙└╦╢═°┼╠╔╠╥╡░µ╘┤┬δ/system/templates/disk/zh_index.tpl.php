<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2015-04-06 16:51:39

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>
<table cellpadding="0" border="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
        <div id="ysleft">
        <h2>空间后台操作菜单</h2>
        <strong>主要操作</strong>
        <ul class="yslb3">
        <li><a href="/user.php">空间状态</a></li>
        <li><a href="/user.php?act=sj">空间升级</a></li>
<!--        <li><a href="/user.php?act=yq">空间延期</a></li>
-->        </ul>
        <strong>账户管理</strong>
        <ul class="yslb3">
        <li><a href="/zh.php" id="xz">账户充值</a></li>
        <li><a href="/zh.php?act=cz">充值记录</a></li>
        <li><a href="/zh.php?act=xf">消费记录</a></li>
        </ul>
        <strong>空间设置</strong>
        <ul class="yslb3">
        <li><a href="/sz.php">常规设置</a></li>
        <li><a href="/sz.php?act=qx">访客权限</a></li>
        <li><a href="/sz.php?act=lj">首页链接</a></li>
        <li><a href="/sz.php?act=px">目录排序方式</a></li>
        <li><a href="/sz.php?act=fg">空间风格</a></li>
        <li><a href="/sz.php?act=zl">设置个人资料</a></li>
        </ul>
        <strong>空间安全</strong>
        <ul class="yslb3">
        <li><a href="/aq.php">设置登录密码</a></li>
        <li><a href="/aq.php?act=glmm">修改管理密码</a></li>
        <!--<li><a href="/aq.php?act=xgyx">修改邮箱</a></li>-->
        <li><a href="/aq.php?act=szmb">设置密保</a></li>
        <li><a href="/aq.php?act=xgmb">修改密保</a></li>
        <!--<li><a href="/aq.php?act=wjmm">忘记密码</a></li>-->
        </ul>
        <strong>其它</strong>
        <ul class="yslb3">
     
        <li><a href="/ly.php">留言管理</a></li>
        </ul></div>
    </td><td>
    <style type="text/css">
	ul.mllb			{margin:0;width:100%;}
	ul.mllb li		{float:left;list-style-type:none;margin:3px 6px 0 0;font-size:9pt;line-height:120%;}
	ul.mllb a		{font-weight:bold;font-size:9pt;color:#000;padding:5px 3px 3px 3px;height:20px;background-color:#E1E1FF;border:1px solid #000;text-align:center;TEXT-DECORATION: none;}
	ul.mllb a:hover	{color:#490685;background-color:#FFEEE1;border:1px solid #1706FF;}
	ul.mllb a:visited {color:#000;}
</style>
        <div id="ysright">
            <h1><span id="yhztxs"><label class="dl1">用户名：<font color="green"><?=$pd_username?></font>  账户余额：<?=$userinfo['wealth']?>元  <a href="/zh.php">账户充值</a> <a href="/account.php?action=logout">退出</a></label></span><img width="32" height="32" border="0" alt="" src="/images/money.gif">账户充值</h1>
            <div class="ysdb2">
            
                    <h3>账户余额</h3>
                    <div class="ysdb2">
                <table width="100%" border="1">
	                <tbody><tr>
		                <td width="107" class="tdbt">您的账户余额</td>
		                <td>
		                    <b><u><font size="4" color="#0000FF"><span id="idyfk"><?=$userinfo['wealth']?></span></font></u></b><font size="3">&nbsp;元</font>
		                    <input type="submit" id="bucx" onclick="window.location.href='/zh.php?act=index'" value="刷新" name="bucx">
		    &#12288;          </td>
	                </tr>
                </tbody></table>
            </div>
            
            <ul class="yslb2">
                <li>账户余额是为方便您在源码E盘里消费而设立的。</li>
                <li>您可以通过以下几种方式向您的账户充值。冲值和消费的记录都可以查看。</li>
            </ul>
            <h3>充值方式</h3>
            <div style="border:2px solid red;padding:5px; width:420px;background-color:#E4F3FC;"><font size="2pt" color="blue">E盘内不允许存储传播任何有关反动、色情、游戏外挂、辅助、私服、黑客软件、木马、病毒、软件破解或者网站破解等违反中国法律法规的内容。如果发现或被举报并查实，将关闭违规空间，充值费用不予退回。</font></div>
            <ul style="margin-top:20px;" class="mllb">
<!--                <li><a title="使用银行卡在线支付，安全快捷，支付成功即充值" href="/zh.php?act=yhk">银行卡在线支付</a></li>
-->                <li><a title="用支付宝余额进行支付" href="/zh.php?act=zfb">支付宝支付</a></li>
<!--                <li><a title="用财付通余额支付" href="/zh.php?act=cft">财付通支付</a></li>
--><!--                <li><a title="通过银行卡账号转账，需经客服确认才能完成充值" href="yhzz.aspx">银行汇款或转帐</a></li>
-->            </ul>
            <br>
            <p>
                <img width="16" height="16" alt="" src="/images/go.GIF"><a href="/zh.php?act=cz">充值记录</a>
                <img width="16" height="16" alt="" src="/images/go.GIF"><a href="/zh.php?act=xf">消费记录</a>
            </p>
            </div>
        </div>
        </td></tr></tbody></table>