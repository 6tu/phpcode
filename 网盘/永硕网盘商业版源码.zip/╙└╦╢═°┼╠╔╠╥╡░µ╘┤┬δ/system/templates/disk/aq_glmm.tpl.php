<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2015-04-06 16:30:23

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>
<table cellpadding="0" border="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
        <div id="ysleft">
        <h2>空间后台操作菜单</h2>
        <strong>主要操作</strong>
        <ul class="yslb3">
        <li><a href="/user.php">空间状态</a></li>
        <li><a href="/user.php?act=sj">空间升级</a></li>
<!--        <li><a href="/user.php?act=yq">空间延期</a></li>
-->        </ul>
        <strong>账户管理</strong>
        <ul class="yslb3">
        <li><a href="/zh.php">账户充值</a></li>
        <li><a href="/zh.php?act=cz">充值记录</a></li>
        <li><a href="/zh.php?act=xf">消费记录</a></li>
        </ul>
        <strong>空间设置</strong>
        <ul class="yslb3">
        <li><a href="/sz.php">常规设置</a></li>
        <li><a href="/sz.php?act=qx">访客权限</a></li>
        <li><a href="/sz.php?act=lj">首页链接</a></li>
        <li><a href="/sz.php?act=px">目录排序方式</a></li>
        <li><a href="/sz.php?act=fg">空间风格</a></li>
        <li><a href="/sz.php?act=zl">设置个人资料</a></li>
        </ul>
        <strong>空间安全</strong>
        <ul class="yslb3">
        <li><a href="/aq.php">设置登录密码</a></li>
        <li><a href="/aq.php?act=glmm" id="xz">修改管理密码</a></li>
        <!--<li><a href="/aq.php?act=xgyx">修改邮箱</a></li>-->
        <li><a href="/aq.php?act=szmb">设置密保</a></li>
        <li><a href="/aq.php?act=xgmb">修改密保</a></li>
        <!--<li><a href="/aq.php?act=wjmm">忘记密码</a></li>-->
        </ul>
        <strong>其它</strong>
        <ul class="yslb3">

        <li><a href="/ly.php">留言管理</a></li>
        </ul></div>
    </td><td>
        <div id="ysright">
            <h1><label class="dl1">用户名：<font color="green"><?=$pd_username?></font>  账户余额：<?=$userinfo['wealth']?>元  <a href="/zh.php">账户充值</a> <a href="/account.php?action=logout">退出</a></label><img width="32" height="32" border="0" alt="" src="/images/xg.gif">修改管理密码</h1>
            <form id="ctl00" action="aq.php?act=glmme" method="post" name="ctl00">
<div class="ysdb2">
                    <table width="100%" border="1" id="table1">
	                    <tbody><tr>
		                    <td width="90" class="tdbt">原管理密码：</td>
		                    <td><input type="password" style="width:150px;" id="sd_te1" name="sd_te1"></td>
	                    </tr>
	                    <tr>
		                    <td width="90" class="tdbt">新管理密码：</td>
		                    <td><input type="password" style="width:150px;" id="sd_te2" name="sd_te2"></td>
	                    </tr>
	                    <tr>
		                    <td width="90" class="tdbt">确认新密码：</td>
		                    <td><input type="password" style="width:150px;" id="sd_te3" name="sd_te3"></td>
	                    </tr>
                    </tbody></table>
	                <br>
	                <input type="submit" id="butj" onclick="return confirm('请确认是否提交修改');" value="提交修改" name="butj">
	                <br><br>
                    <ul class="yslb2">
                        <li>操作提示：管理密码是空间最高权限密码，请记好勿泄漏。</li>
                        <li>管理密码长度为6－20位。区分大小写，不支持字符：单引号、双引号、空格。</li>
                    </ul>
                </div>
            </form>

        </div>
        </td></tr></tbody></table>