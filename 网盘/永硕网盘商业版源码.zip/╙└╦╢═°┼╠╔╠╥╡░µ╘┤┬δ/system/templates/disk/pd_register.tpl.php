<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2012-11-04 14:32:35

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>
<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2012-10-21 19:09:18

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>
<?php !defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied!'); ?>
<?php require_once template_echo('circle_box_header',$user_tpl_dir);  ?>
<table border="0" cellpadding="0" style="border-collapse: collapse"><tr valign="top"><td>
<div id="ysleft">
<h2>注意事项</h2>
<div style="padding:5px;">
<b>
<font size="3">您</font></b>现在注册的是源码Ｅ盘空间，注册成功后您可以随时升级您的Ｅ盘空间。
<br /><b><font size="3">请</font></b>在右面表单中正确填写您的Email地址，此Email地址将是您忘记密码时找回的重要资料。
<br /><b><font size="3">用</font></b>户名限制3－15位，支持数字、字母和"-",但"-"不能放在开头和结尾。不区分大小写。
<br /><b><font size="3">密</font></b>码长度为6－20位。区分大小写，不支持字符：单引号、双引号、空格。
</div>
</div>
</td><td>
<div id="ysright">
<h1><img border="0" src="/ht/tree.gif" width="32" height="32" alt="" />注册源码Ｅ盘</h1>
<?php 
if($allow_register==true){
 ?>

<div class="ysdb2">
<div>
</div>

<script language="JavaScript" type="text/javascript" src="/js/ajax-dq.js"></script>
<script language="javascript" type="text/javascript">

function initIt(){

	
}
function $(rid) {return document.getElementById(rid); }
function bao(){
    if ($('jbxz').options[1].selected==true){
        //alert('抱歉，免费空间暂停注册，请选择其他类型！');
        //$('jbxz').options[0].selected=true;
        $("jbts").style.display='none';
    }else if($('jbxz').options[0].selected==true){
        $("jbts").style.display='none';
    }else{
        $("jbts" ).innerHTML="您选择的是付费空间，需要充值后才可以使用。<br>如果需要试用，请选择免费型空间，注册后可以随时进行升级。";
        $("jbts").style.display='block';
    }
}

function check(){

	if ($('tedlmc').value==''){alert('请填写用户名');$('tedlmc').focus();return false;}
	if ($('temm').value==''){alert('请填写管理密码');$('temm').focus();return false;}
	if ($('temmqr').value==''){alert('请确认管理密码');$('temmqr').focus();return false;}
	if ($('teem').value==''){alert('请填写你的Email地址');$('teem').focus();return false;}
	if ($('teemqr').value==''){alert('请确认Email地址');$('teemqr').focus();return false;}
    
    //用户名
    var reg = new RegExp("^[0-9a-zA-Z][0-9a-zA-Z\-]{1,13}[0-9a-zA-Z]$");
    if (reg.test($('tedlmc').value) == false) { alert('用户名不合法。请重新输入。'); $('tedlmc').focus();return false; }

	if ($('temm').value.length>20){alert('管理密码不能超过20个字符');$('temm').focus();return false;}
	if ($('temm').value.length<6){alert('管理密码不能少于6个字符');$('temm').focus();return false;}
	if ($('teem').value.length>50){alert('Email地址不能超过50个字符');$('teem').focus();return false;}
	if ($('teem').value.length<6){alert('请填写正确的Email地址');$('teem').focus();return false;}

	if ($('temm').value.indexOf("'")>=0){alert('管理密码中不得含有单引号，请重新填写');$('temm').focus();return false;}
	if ($('temm').value.indexOf(" ")>=0){alert('管理密码中不得含有空格，请重新填写');$('temm').focus();return false;}
	if ($('temm').value.indexOf("\"")>=0){alert('管理密码中不得含有双引号，请重新填写');$('temm').focus();return false;}

	if ($('temmqr').value!=$('temm').value){alert('密码确认有误');$('temmqr').focus();return false;}
	if ($('teem').value.indexOf("@")<0||$('teem').value.indexOf(".")<0){alert("您所写的Email地址不合法");$('teem').focus();return false;}
	if ($('teemqr').value!=$('teem').value){alert('Email地址确认有误');$('teemqr').focus();return false;}
	if ($('teem').value.indexOf("'")>=0){alert('Email地址中不得含有单引号，请重新填写');return false;}
	if ($('teem').value.indexOf("<")>=0){alert('Email地址中不得含有尖括号，请重新填写');return false;}
	if ($('teem').value.indexOf(">")>=0){alert('Email地址中不得含有尖括号，请重新填写');return false;}
}
function checkzf(dqqzf,zffw){
	for(i=0;i<=dqqzf.length-1;i++){
		if (zffw.indexOf(dqqzf.substr(i,1).toLowerCase())<0){return "F"}
	}
	return "T"
}

//用户名
function checkdlmc(){
    var reg = new RegExp("^[0-9a-zA-Z][0-9a-zA-Z\-]{1,13}[0-9a-zA-Z]$");
    if (reg.test($('tedlmc').value) == false){$("sm_dlmc").innerHTML="<img src='images/reg_f.gif' /><font color='red'>用户名不合法。请重新输入。</font>";return "";}
    sendRequest('checkusername.php', 'dlmc='+ $('tedlmc').value, xmljs, '');
}
function xmljs(s1) {$("sm_dlmc").innerHTML = s1;}
function writedlmc(){$("sm_dlmc").innerHTML='<br><font color="#777777">用户名限制3－15位，支持数字、字母和"-",但"-"不能放在开头和结尾。不区分大小写</font>';}

//级别
function checkjb(){if ($('jbxz').options[0].selected==true){$("sm_jb").innerHTML="<img src='images/reg_f.gif' /><font color='red'>请选择空间级别</font>";}else{$("sm_jb").innerHTML="<img src='images/reg_t.gif' />";}}
function writejb(){$("sm_jb").innerHTML="";}

//邮箱
function checkem(){
    if ($('teem').value==''){$("sm_em").innerHTML="<img src='images/reg_f.gif' /><font color='red'>需输入邮箱地址</font>";return "";}
    if ($('teem').value.length<6){$("sm_em").innerHTML="<img src='images/reg_f.gif' /><font color='red'>需填写正确的邮箱</font>";return "";}
    if ($('teem').value.length>50){$("sm_em").innerHTML="<img src='images/reg_f.gif' /><font color='red'>邮箱地址不能超过50个字符</font>";return "";}
    if ($('teem').value.indexOf("@")<0||$('teem').value.indexOf(".")<0){$("sm_em").innerHTML="<img src='images/reg_f.gif' /><font color='red'>邮箱地址不合法</font>";return "";}
    if ($('teem').value.indexOf("'")>=0){$("sm_em").innerHTML="<img src='images/reg_f.gif' /><font color='red'>不支持单分号</font>";return "";}
    if ($('teem').value.indexOf("<")>=0){$("sm_em").innerHTML="<img src='images/reg_f.gif' /><font color='red'>不支持尖括号</font>";return "";}
    if ($('teem').value.indexOf(">")>=0){$("sm_em").innerHTML="<img src='images/reg_f.gif' /><font color='red'>不支持尖括号</font>";return "";}
    $("sm_em").innerHTML="<img src='images/reg_t.gif' />";
}
function writeem(){$("sm_em").innerHTML="<font color='#777777'>邮箱可用于找回密码</font>";}
function checkemqr(){
    if($('teemqr').value==""){$("sm_emqr").innerHTML="<img src='images/reg_f.gif' /><font color='red'>请再次输入邮箱地址</font>";return "";}
    if($('teemqr').value!=$('teem').value){$("sm_emqr").innerHTML="<img src='images/reg_f.gif' /><font color='red'>两次输入邮箱不一致</font>";return "";}
    $("sm_emqr").innerHTML="<img src='images/reg_t.gif' />";
}
function writeemqr(){$("sm_emqr").innerHTML="<font color='#777777'>请再次输入邮箱地址</font>";}

//密码
function checkmm(){
    if ($('temm').value==''){$("sm_mm").innerHTML="<img src='images/reg_f.gif' /><font color='red'>需输入管理密码</font>";return "";}
	if ($('temm').value.length>20){$("sm_mm").innerHTML="<img src='images/reg_f.gif' /><font color='red'>需输入少于20个字符</font>";return "";}
	if ($('temm').value.length<6){$("sm_mm").innerHTML="<img src='images/reg_f.gif' /><font color='red'>需输入多于6字符</font>";return "";}
		
	if ($('temm').value.indexOf("'")>=0){$("sm_mm").innerHTML="<img src='images/reg_f.gif' /><font color='red'>管理密码中不得含有单引号，请重新填写</font>";return "";}
	if ($('temm').value.indexOf(" ")>=0){$("sm_mm").innerHTML="<img src='images/reg_f.gif' /><font color='red'>管理密码中不得含有空格，请重新填写</font>";return "";}
	if ($('temm').value.indexOf("\"")>=0){$("sm_mm").innerHTML="<img src='images/reg_f.gif' /><font color='red'>管理密码中不得含有双引号，请重新填写</font>";return "";}
		
	$("sm_mm").innerHTML="<img src='images/reg_t.gif' />";
}
function writemm(){$("sm_mm").innerHTML="<font color='#777777'>限制6-20位，区分大小写，不支持字符：单引号、双引号、空格。</font>";}
function checkmmqr(){
    if ($('temmqr').value==""){$("sm_mmqr").innerHTML="<img src='images/reg_f.gif' /><font color='red'>请再次输入管理密码</font>";return "";}
    if ($('temmqr').value!=$('temm').value){$("sm_mmqr").innerHTML="<img src='images/reg_f.gif' /><font color='red'>两次输入管理密码不一致</font>";return "";}
    $("sm_mmqr").innerHTML="<img src='images/reg_t.gif' />";
}
function writemmqr(){$("sm_mmqr").innerHTML="<font color='#777777'>请再次输入管理密码</font>";}

onload = initIt;
</script>
<div>
</div>
	<form name="ctl00" method="post" action="<?=urr("account","")?>" id="ctl00">

	<table border="1" width="100%">
	<tr>
		<td class="tdbt" width="110">用户名:</td>
		<td><input name="tedlmc" type="text" id="tedlmc" onBlur="checkdlmc();" onFocus="writedlmc();" style="width:150px;" /><span id="sm_dlmc"></span></td>
	</tr>
	
	<tr>
		<td class="tdbt">邮箱地址:</td>
		<td><input name="teem" type="text" id="teem" onBlur="checkem();" onFocus="writeem();" style="width:150px;" /><span id="sm_em"></span></td>
	</tr>
	<tr>
		<td class="tdbt">确认邮箱地址:</td>
		<td><input name="teemqr" type="text" id="teemqr" onBlur="checkemqr();" onFocus="writeemqr();" style="width:150px;" /><span id="sm_emqr"></span></td>
	</tr>
	<tr>
		<td class="tdbt">管理密码:</td>
		<td><input name="temm" type="password" id="temm" onBlur="checkmm();" onFocus="writemm();" style="width:150px;" /><span id="sm_mm"></span></td>
	</tr>
	<tr>
		<td class="tdbt">确认管理密码:</td>
		<td><input name="temmqr" type="password" id="temmqr" onBlur="checkmmqr();" onFocus="writemmqr();" style="width:150px;" /><span id="sm_mmqr"></span></td>
	</tr>
	<tr>
		<td class="tdbt">注册协议:</td>
		<td><a href="/zcxx.html" target="_blank">查看源码Ｅ盘注册协议</a>
		</td>
	</tr>

	</table>
	<div>
	&gt;<a href="list_cp.php" target ="_blank" >查看E盘产品列表</a>
	</div>
	<p>
<input type="hidden" name="action" value="<?=$action?>" />
<input type="hidden" name="task" value="<?=$action?>" />
<input type="hidden" name="invite_uid" value="<?=$invite_uid?>" />
<input type="hidden" name="formhash" value="<?=$formhash?>" />
    <input name="tjxx" type="submit" id="tjxx" value="接受注册协议并提交注册资料" style="margin-left:120px;" onClick="return check();" /></p>
	</form>

</div>

<?php 
}else{
 ?>
<p><b><font color="#FF0000">抱歉，暂停用户注册,请稍候再来。</font></b></p>
<?php 

}
 ?>

</div>
</td></tr></table>