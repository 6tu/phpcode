<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2015-04-06 17:42:12

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>
<table cellpadding="0" border="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
            <div id="ysleft">
                <h2>客服联系方式</h2>
                <?=$contact1?>
                <h2>部分客户列表</h2><marquee height="130" more,visit:www.helpor.net="" for="" ;="" author:redriver="redriver" onmouseout="helpor_net.start()" onmouseover="helpor_net.stop()" id="helpor_net" direction="UP" scrolldelay="30" scrollamount="2">
               <?=$khlb?>
                </marquee> 
            </div>
        </td><td>
            
<div id="ysright">
            <h1><img width="32" height="32" border="0" alt="" src="/ht/images/group.gif">客服中心</h1>
            <div>
	            <h3>提交问题</h3>
        	    <p><span id="ysts2">请在此处提交问题，我们会尽快回复。</span></p>
	            <div align="center" style="margin-top:10px;">
		            <textarea style="height:80px;width:380px;" id="idnr" cols="20" rows="2" name="idnr"></textarea>
        	    </div>
        	    <div style="margin-left:74px;">
        	    <input type="checkbox" id="fslyb" name="fslyb">把此问题的回复同时显示在空间的留言区内
        	    </div>
	            <p align="center">
	            <span id="czts"></span>
	            <input type="submit" id="butj" onclick="return confirm('请确认是否提交问题');" value="提交问题" name="butj">
	            </p>
            </div>
        </div>            
            
    </td></tr></tbody></table>