<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2015-04-06 16:30:28

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>
<table cellpadding="0" border="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
        <div id="ysleft">
        <h2>空间后台操作菜单</h2>
        <strong>主要操作</strong>
        <ul class="yslb3">
        <li><a href="/user.php">空间状态</a></li>
        <li><a href="/user.php?act=sj">空间升级</a></li>
<!--        <li><a href="/user.php?act=yq">空间延期</a></li>
-->        </ul>
        <strong>账户管理</strong>
        <ul class="yslb3">
        <li><a href="/zh.php">账户充值</a></li>
        <li><a href="/zh.php?act=cz">充值记录</a></li>
        <li><a href="/zh.php?act=xf">消费记录</a></li>
        </ul>
        <strong>空间设置</strong>
        <ul class="yslb3">
        <li><a href="/sz.php">常规设置</a></li>
        <li><a href="/sz.php?act=qx">访客权限</a></li>
        <li><a href="/sz.php?act=lj">首页链接</a></li>
        <li><a href="/sz.php?act=px">目录排序方式</a></li>
        <li><a href="/sz.php?act=fg" id="xz">空间风格</a></li>
        <li><a href="/sz.php?act=zl">设置个人资料</a></li>
        </ul>
        <strong>空间安全</strong>
        <ul class="yslb3">
        <li><a href="/aq.php">设置登录密码</a></li>
        <li><a href="/aq.php?act=glmm">修改管理密码</a></li>
        <!--<li><a href="/aq.php?act=xgyx">修改邮箱</a></li>-->
        <li><a href="/aq.php?act=szmb">设置密保</a></li>
        <li><a href="/aq.php?act=xgmb">修改密保</a></li>
        <!--<li><a href="/aq.php?act=wjmm">忘记密码</a></li>-->
        </ul>
        <strong>其它</strong>
        <ul class="yslb3">
        
        <li><a href="/ly.php">留言管理</a></li>
        </ul></div>
    </td><td>
        <div id="ysright">
            <h1><label class="dl1">用户名：<font color="green"><?=$pd_username?></font>  账户余额：<?=$userinfo['wealth']?>元  <a href="/zh.php">账户充值</a> <a href="/account.php?action=logout">退出</a></label><img width="32" height="32" border="0" alt="" src="/images/tools.gif">选择空间风格</h1>
            
<form id="ctl00" action="sz.php?act=fge" method="post" name="ctl00">
                <table width="48%" cellspacing="1" cellpadding="2" border="0">
	                <tbody><tr>
		                <td>
		                    <p align="center">
		                    <img width="100" height="66" border="0" alt="" onclick="document.forms[0].p1.checked=true" src="/images/fg_st_1.gif" style="cursor:hand;">
		                    </p>
		                </td>
		                <td>
						    <p align="center">
						    <img width="100" height="66" border="0" alt="" onclick="document.forms[0].p2.checked=true" src="/images/fg_st_2.gif" style="cursor:hand;">
						    </p>
						</td>
		                <td>
						    <p align="center">
						    <img width="100" height="66" border="0" alt="" onclick="document.forms[0].p3.checked=true" src="/images/fg_st_3.gif" style="cursor:hand;">
						    </p>
						</td>
	                </tr>
	                <tr>
		                <td align="center"><input type="radio" id="p1" <?php  if($userinfo['kjfg']==1){echo ' checked="checked"';}  ?> name="rsd" value="1"></td>
		                <td align="center"><input type="radio" id="p2" <?php  if($userinfo['kjfg']==2){echo ' checked="checked"';}  ?> name="rsd" value="2"></td>
		                <td align="center"><input type="radio" id="p3" <?php  if($userinfo['kjfg']==3){echo ' checked="checked"';}  ?> name="rsd" value="3"></td>
	                </tr>
	                <tr>
		                <td align="center"><img width="100" height="66" border="0" alt="" onclick="document.forms[0].p4.checked=true" src="/images/fg_st_4.gif" style="cursor:hand;"></td>
		                <td align="center"><img width="100" height="66" border="0" alt="" onclick="document.forms[0].p5.checked=true" src="/images/fg_st_5.gif" style="cursor:hand;"></td>
		                <td align="center"><img width="100" height="66" border="0" alt="" onclick="document.forms[0].p6.checked=true" src="/images/fg_st_6.gif" style="cursor:hand;"></td>
	                </tr>
	                <tr>
		                <td align="center"><input type="radio" id="p4" <?php  if($userinfo['kjfg']==4){echo ' checked="checked"';}  ?> name="rsd" value="4"></td>
		                <td align="center"><input type="radio" id="p5" <?php  if($userinfo['kjfg']==5){echo ' checked="checked"';}  ?> name="rsd" value="5"></td>
		                <td align="center"><input type="radio" id="p6" <?php  if($userinfo['kjfg']==6){echo ' checked="checked"';}  ?> name="rsd" value="6"></td>
	                </tr>
	            </tbody></table>
            <p><input type="submit" id="bu1" onclick="return confirm('请确认是否提交设置');" value="提交设置" name="bu1"></p>
            </form>
            <ul class="yslb2">
            <li>在此处可以选择您喜欢的页面风格。</li>
            </ul>


        </div>
        </td></tr></tbody></table>