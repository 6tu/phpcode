<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2015-04-06 16:36:03

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>
<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2012-10-21 19:09:18

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>
<?php !defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied!'); ?>
<?php require_once template_echo('circle_box_header',$user_tpl_dir);  ?>
<script language="javascript" type="text/javascript">
    window.onload = function() {
    if (document.forms[0].dl1.value == "") { document.forms[0].dl1.focus(); } else { document.forms[0].dl2.focus(); }
        var ts = "";
        if (ts != "") alert(ts);
    }

    function yzm() {
        var today = new Date();
        document.getElementById('imgyzm').src = "includes/imgcode.inc.php?verycode_type=<?=$settings['verycode_type']?>&t="+Math.random();
        document.getElementById('dl3').focus();
    }

</script>

<table border="0" cellpadding="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
        <div id="ysleft">
            <h2>说明</h2>
            <div style="padding:5px;">
	            <b><font size="3">登</font></b>录成功后，您可以在空间后台进行空间设置、空间升级或延期等，或在客服中心提交问题。
            </div>
        </div>
        </td><td>
        <div id="ysright">
            <h1><span id="yhztxs"></span>
            <img width="30" height="27" border="0" alt="" src="/ht/dl.gif">用户登录</h1>
<?php 
if(count($sysmsg)){
 ?>
<div class="cboxcontent">
<?php 
	for($i=0;$i<count($sysmsg);$i++){
 ?>
<li><span>*</span> <?=$sysmsg[$i]?></li>
<?php 
	}
 ?>
</div>
<?php 

}
unset($sysmsg);
 ?>
<div style="display:block;" class="ysdb2">
                <form id="ctl00" action="login.php" method="post" name="ctl00">
                <table>
	                <tbody><tr>
		                <td width="80" class="tdbt">用户名:</td>
		                <td><input type="text" style="width:120px;" id="dl1" value="" name="username"></td>
	                </tr>
	                <tr>
		                <td class="tdbt">管理密码:</td>
		                <td><input type="password" style="width:120px;" id="dl2" name="password">
			            <a class="go">忘记密码</a>
			            <!--<a class="go" href="">忘记密码</a> -->
		                </td>
	                </tr>
	                <tr>
		                <td class="tdbt">验证码:</td>
		                <td><input type="text" style="width:120px;" id="dl3" name="verycode">
			                <a href="javascript:yzm();"><img width="100" height="35" border="0" alt="" src="includes/imgcode.inc.php?verycode_type=<?=$settings['verycode_type']?>" id="imgyzm"></a>
			                <a href="javascript:yzm();">看不清楚</a>
                            <ul class="yslb2">
                                <li>请输入图片显示内容，如果图片不清楚请点击图片刷新。</li>
                            </ul>
		                </td>
	                </tr>
                </tbody></table>
                <p>
                <input type="hidden" name="task" value="login" />
                <input type="hidden" name="formhash" value="<?=$formhash?>" />
                <input type="submit" style="margin-left:90px;" id="bu1" value=" 登 录 " name="bu1">
                    &nbsp;&nbsp;<a class="go3" href="account.php?action=register">注册</a>
                </p>
                </form>
            </div>
        </div>
    </td></tr></tbody></table>