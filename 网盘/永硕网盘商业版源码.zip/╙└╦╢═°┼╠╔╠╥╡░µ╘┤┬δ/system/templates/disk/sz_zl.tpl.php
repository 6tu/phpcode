<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2015-04-06 16:35:05

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>
<table cellpadding="0" border="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
        <div id="ysleft">
        <h2>空间后台操作菜单</h2>
        <strong>主要操作</strong>
        <ul class="yslb3">
        <li><a href="/user.php">空间状态</a></li>
        <li><a href="/user.php?act=sj">空间升级</a></li>
<!--        <li><a href="/user.php?act=yq">空间延期</a></li>
-->        </ul>
        <strong>账户管理</strong>
        <ul class="yslb3">
        <li><a href="/zh.php">账户充值</a></li>
        <li><a href="/zh.php?act=cz">充值记录</a></li>
        <li><a href="/zh.php?act=xf">消费记录</a></li>
        </ul>
        <strong>空间设置</strong>
        <ul class="yslb3">
        <li><a href="/sz.php">常规设置</a></li>
        <li><a href="/sz.php?act=qx">访客权限</a></li>
        <li><a href="/sz.php?act=lj">首页链接</a></li>
        <li><a href="/sz.php?act=px">目录排序方式</a></li>
        <li><a href="/sz.php?act=fg">空间风格</a></li>
        <li><a href="/sz.php?act=zl" id="xz">设置个人资料</a></li>
        </ul>
        <strong>空间安全</strong>
        <ul class="yslb3">
        <li><a href="/aq.php">设置登录密码</a></li>
        <li><a href="/aq.php?act=glmm">修改管理密码</a></li>
        <!--<li><a href="/aq.php?act=xgyx">修改邮箱</a></li>-->
        <li><a href="/aq.php?act=szmb">设置密保</a></li>
        <li><a href="/aq.php?act=xgmb">修改密保</a></li>
        <!--<li><a href="/aq.php?act=wjmm">忘记密码</a></li>-->
        </ul>
        <strong>其它</strong>
        <ul class="yslb3">
        
        <li><a href="/ly.php">留言管理</a></li>
        </ul></div>
    </td><td>
    <script language="javascript" type="text/javascript">
    window.onload = function() { var ts = ""; if (ts != "") alert(ts); }

    function check() {
        var ys = document.forms[0];
        var zf = ys.zl_te1.value + ys.zl_te3.value + ys.zl_teqq.value + ys.zl_te4.value + ys.zl_tesfz.value;
        if (checkzf(zf) == 'F') { alert('不支持特殊字符的输入。'); return false; }

        if (!confirm('请确认是否提交设置')) return;
    }

    function checkzf(nr) {
        var zf = "/\\'<>\"&"
        for (i = 0; i <= zf.length - 1; i++) {
            if (nr.indexOf(zf.substr(i, 1)) >= 0) { return "F" }
        }
        return "T"
    }

</script>
        <div id="ysright">
            <h1><label class="dl1">用户名：<font color="green"><?=$pd_username?></font>  账户余额：<?=$userinfo['wealth']?>元  <a href="/zh.php">账户充值</a> <a href="/account.php?action=logout">退出</a></label><img width="32" height="32" border="0" alt="" src="/images/tools.gif">选择空间风格</h1>
<form id="ctl00" action="sz.php?act=zle" method="post" name="ctl00">
<div class="ysdb2">
                    <table width="100%" border="1" id="table1">
	                    <tbody><tr>
		                    <td width="90" class="tdbt">真实姓名：</td>
		                    <td><input type="text" style="width:250px;" id="zl_te1" name="zl_te1" value="<?=$userinfo['zl_te1']?>"></td>
	                    </tr>
	                    <tr>
		                    <td width="90" class="tdbt">Email：</td>
		                    <td><input type="text" style="width:250px;" id="email" name="email" value="<?=$userinfo['email']?>"></td>
	                    </tr>
	                    <tr>
		                    <td width="90" class="tdbt">联系电话：</td>
		                    <td><input type="text" style="width:250px;" id="zl_te3" name="zl_te3" value="<?=$userinfo['zl_te3']?>"></td>
	                    </tr>
	                    <tr>
		                    <td width="90" class="tdbt">联系QQ或者MSN：</td>
		                    <td><input type="text" style="width:250px;" id="zl_teqq" name="zl_teqq" value="<?=$userinfo['zl_teqq']?>"></td>
	                    </tr>
	                    <tr>
		                    <td width="90" class="tdbt">联系地址：</td>
		                    <td><input type="text" style="width:250px;" id="zl_te4" name="zl_te4" value="<?=$userinfo['zl_te4']?>"></td>
	                    </tr>
	                    <tr>
		                    <td width="90" class="tdbt">身份证号码：</td>
		                    <td><input type="text" style="width:250px;" id="zl_tesfz" name="zl_tesfz" value="<?=$userinfo['zl_tesfz']?>"></td>
	                    </tr>
                    </tbody></table>
                    <br>
                    <input type="submit" id="butj" onclick="return check();" value="提交新资料" name="butj">
                    <br><br>
                    <ul class="yslb2">
                        <li>操作提示：请认真填写本处内容，我们对用户发放通知、寄送发票等要用到此处数据。</li>
                        <li>不支持特殊字符：（/ \ ' &lt; &gt; " &amp;）</li>
                    </ul>
                </div>
            </form>


        </div>
        </td></tr></tbody></table>