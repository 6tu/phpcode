<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2014-09-23 12:22:37

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>


<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>asdfasdf-登陆</title>
</head>
<script language="javascript">
	function initIt(){document.forms[0].teqtbz.focus();}
	onload = initIt;
</script>
<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0">
<form name="ctl00" method="post" action="l.php?name=<?=$name?>&act=display" id="ctl00">
<table border="0" width="100%" cellspacing="0" cellpadding="0" height="100%">
	<tr>
		<td height="30" bgcolor="#0066B3">
		<p align="right"><span style="font-size: 9pt">
		</span>&nbsp;</td>
	</tr>
	<tr>
		<td valign="top">
		<h2 align="center" style="margin-top:40px;"><font color="#000080"><span id="l_dwmc"><?=$userinfo['t1']?></span></font></h2>
		<div align="center">
		<div style="border:1px solid green;width:307px;">
		<table border="0" width="100%" cellspacing="0" cellpadding="3" bgcolor="#E6E7E8" bordercolor="#800080">
			<tr>
				<td width="124" bordercolor="#E6E7E8">
				　</td>
				<td bordercolor="#E6E7E8" width="160">
				　</td>
			</tr>
			<tr>
				<td width="124" bordercolor="#E6E7E8">
				<p align="right"><font color="#000080">用户名:</font></td>
				<td bordercolor="#E6E7E8" width="160">
				<font color="#0000FF"><span id="L_dlmc"><?=$name?></span></font></td>
			</tr>
			<tr>
				<td width="124" bordercolor="#E6E7E8">
				<p align="right"><font color="#000080">
				<span style="font-size: 12pt">登陆密码:</span></font></td>
				<td bordercolor="#E6E7E8" width="160">
				<input name="teqtbz" type="password" id="teqtbz" style="width:100px;" />
			</td>
			</tr>
			<tr>
				<td colspan="2" bordercolor="#E6E7E8" height="50">
				<p align="center">
				<span id="l_czts"><font color="red"><?=$error?></font></span>
				<input type="submit" name="b_dl" value="登陆" id="b_dl" />
			</tr>
			</table>
			</div>
		</div>
		</td>
	</tr>
	<tr>
		<td height="10"></td>
	</tr>
	<tr>
		<td height="10" bgcolor="#0066B3">　</td>
	</tr>
	<tr>
		<td height="50" bgcolor="#E6E7E8">　</td>
	</tr>
</table>
</form>
</body>

</html>