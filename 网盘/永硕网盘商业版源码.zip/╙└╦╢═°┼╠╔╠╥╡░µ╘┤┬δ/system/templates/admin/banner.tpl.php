<?php 
// This is PHPDISK auto-generated file. Do NOT modify me.

// Cache Time:2014-09-23 12:25:31

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

?>
<?php 
##
#	Project: PHPDISK File Storage Solution
#	This is NOT a freeware, use is subject to license terms.
#
#	Site: http://www.phpdisk.com
#
#	$Id: banner.tpl.html 2 2011-05-27 03:00:17Z along $
#
#	Copyright (C) 2008-2012 PHPDisk Team. All Rights Reserved.
#
##
 ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?=$charset?>" />
<title>Banner - Powered by PHPDisk</title>
<style type="text/css">
body {
	padding:0; margin:0;font-family:verdana, arial, helvetica, sans-serif;font-size: 12px;
}
</style>
</head>

<body>
</body>
</html>
