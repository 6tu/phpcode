<?php

// This is PHPDISK auto-generated file. Do NOT modify me.
// Cache Time: 2015-04-06 17:44:46

$group_settings = array(
	'1' => array(
		'max_messages' => '0',
		'max_flow_down' => '0',
		'max_flow_view' => '0',
		'max_storage' => '0',
		'max_filesize' => '0',
		'group_file_types' => '',
		'max_folders' => '100',
		'max_files' => '100',
		'can_share' => '1',
		'secs_loading' => '5',
		'server_ids' => '0',
	),

	'2' => array(
		'max_messages' => '0',
		'max_flow_down' => '',
		'max_flow_view' => '20',
		'max_storage' => '1000M',
		'max_filesize' => '',
		'group_file_types' => '',
		'max_folders' => '100',
		'max_files' => '100',
		'can_share' => '1',
		'secs_loading' => '0',
		'server_ids' => '0',
	),

	'3' => array(
		'max_messages' => '0',
		'max_flow_down' => '0',
		'max_flow_view' => '0',
		'max_storage' => '600M',
		'max_filesize' => '0',
		'group_file_types' => '',
		'max_folders' => '100',
		'max_files' => '100',
		'can_share' => '1',
		'secs_loading' => '0',
		'server_ids' => '0',
	),

	'4' => array(
		'max_messages' => '0',
		'max_flow_down' => '10G',
		'max_flow_view' => '5G',
		'max_storage' => '400M',
		'max_filesize' => '0',
		'group_file_types' => '',
		'max_folders' => '100',
		'max_files' => '100',
		'can_share' => '1',
		'secs_loading' => '0',
		'server_ids' => '',
	),

	'5' => array(
		'max_messages' => '0',
		'max_flow_down' => '0',
		'max_flow_view' => '0',
		'max_storage' => '2000M',
		'max_filesize' => '0',
		'group_file_types' => '',
		'max_folders' => '100',
		'max_files' => '100',
		'can_share' => '0',
		'secs_loading' => '0',
		'server_ids' => '',
	),

	'6' => array(
		'max_messages' => '0',
		'max_flow_down' => '0',
		'max_flow_view' => '0',
		'max_storage' => '6000M',
		'max_filesize' => '0',
		'group_file_types' => '',
		'max_folders' => '100',
		'max_files' => '100',
		'can_share' => '0',
		'secs_loading' => '0',
		'server_ids' => '',
	),

	'7' => array(
		'max_messages' => '0',
		'max_flow_down' => '0',
		'max_flow_view' => '0',
		'max_storage' => '12000M',
		'max_filesize' => '0',
		'group_file_types' => '',
		'max_folders' => '100000',
		'max_files' => '100000',
		'can_share' => '0',
		'secs_loading' => '0',
		'server_ids' => '',
	),

);

?>
