<?php

// This is PHPDISK auto-generated file. Do NOT modify me.
// Cache Time: 2015-04-22 12:22:34

$plugin_settings = array(
	'api'=>array(
		'plugin_name'=>'api',
		'actived'=>'0',
	),
);

?>
