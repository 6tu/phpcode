<?php

// This is PHPDISK auto-generated file. Do NOT modify me.
// Cache Time: 2015-05-08 19:03:48

$stats = array(
	'all_files_count' => '0',
	'extract_code_count' => '1',
	'public_files_count' => '0',
	'public_storage_count' => '0.0B',
	'stat_time' => '1431083028',
	'total_storage_count' => '0.0B',
	'users_count' => '1',
	'users_locked_count' => '0',
	'users_open_count' => '1',
	'user_files_count' => '0',
	'user_folders_count' => '0',
	'user_storage_count' => '0.0B',
);

?>
