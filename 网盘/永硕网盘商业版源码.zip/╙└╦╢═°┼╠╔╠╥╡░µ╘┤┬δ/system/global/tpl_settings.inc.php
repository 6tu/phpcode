<?php

// This is PHPDISK auto-generated file. Do NOT modify me.
// Cache Time: 2012-10-30 14:59:01

$tpl_settings = array(
	'admin'=>array(
		'tpl_name'=>'admin',
		'actived'=>'1',
		'tpl_type'=>'admin',
	),
	'default'=>array(
		'tpl_name'=>'default',
		'actived'=>'0',
		'tpl_type'=>'user',
	),
	'disk'=>array(
		'tpl_name'=>'disk',
		'actived'=>'1',
		'tpl_type'=>'user',
	),
);

?>
