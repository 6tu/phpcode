<?php

// This is PHPDISK auto-generated file. Do NOT modify me.
// Cache Time: 2012-11-22 15:45:58

$lang_settings = array(
	'zh-cn'=>array(
		'lang_name'=>'zh-cn',
		'actived'=>'1',
	),
	'zh_cn'=>array(
		'lang_name'=>'zh_cn',
		'actived'=>'0',
	),
);

?>
