<?php
define("WEBSCAN_KEY", "341b254a43f4d73109ea0b6a3321846c");
define("WEBSCAN_VERSION", "1.6");
date_default_timezone_set('GMT');
ini_set('display_errors', '0');
?>
