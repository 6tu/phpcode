<?php 


if(!defined('IN_PHPDISK') || !defined('IN_MYDISK')) {
	exit('[PHPDisk] Access Denied');
}
require_once template_echo('my_nav_bar',$user_tpl_dir);

?>
