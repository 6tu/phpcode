<?php 

if(!defined('IN_PHPDISK')) {
	exit('[PHPDisk] Access Denied');
}

require_once template_echo('front_msg',$user_tpl_dir);
?>