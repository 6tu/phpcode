<?php 

include "includes/commons.inc.php";

$in_front = true;
define('IN_MYDISK' ,true);
$diskurl =$settings['phpdisk_url'];
$act = trim(gpc('act','G',''));
$name = trim(gpc('name','G',''));
$userinfo= @$db->fetch_one_array("select * from {$tpf}users where username='$name'");
if(empty($userinfo)){
	echo '<script type="text/javascript">alert("您访问的空间不存在!");window.location.href="/"</script>';
	exit;
}
if($act =='display'){
	
$teqtbz = trim(gpc('teqtbz','P',''));
if($teqtbz!=$userinfo['dlmm']){
	$error="登陆密码不正确！";
	$_SESSION['diskstatus']='';
}else{
	$_SESSION['diskstatus']=$name;
	header("Location:/k.php?name=".$name);
}
require_once template_echo('login_index',$user_tpl_dir);
}
else{
	require_once template_echo('login_index',$user_tpl_dir);
}


?>


