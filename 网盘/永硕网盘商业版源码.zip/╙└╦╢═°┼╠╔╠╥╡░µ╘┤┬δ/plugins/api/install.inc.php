<?php 
if(!defined('IN_PHPDISK')) {
	exit('[PHPDisk] Access Denied');
}
function install_plugin(){
	return true;
}
function uninstall_plugin(){
	return true;
}
?>