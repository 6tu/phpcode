<?php 

//	Plugin Name: 通行证整合插件
//	Plugin URL: http://www.phpdisk.com/
//	Description: 使用此插件与一些常用的系统进行整合，实现同步注册、登录、资源推送、积分兑换等。支持康盛UC(Discuz) 和phpwind8 UC 整合。 
//	Author: PHPDISK TEAM
//	Author Site: http://www.phpdisk.com/ 
//	Version: v1.2
//  PHPDISK Core: v5.5+

?> 
