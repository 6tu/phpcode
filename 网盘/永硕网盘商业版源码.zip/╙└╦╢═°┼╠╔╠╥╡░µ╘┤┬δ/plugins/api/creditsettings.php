<?php

// This is PHPDISK auto-generated file. Do NOT modify me.
// Cache Time: 2011-04-21 02:18:04

$_CACHE['creditsettings'] = array (
  '1|1' => 
  array (
    'creditsrc' => '0',
    'title' => 'Discuz! Board 威望',
    'unit' => '',
    'ratio' => '1',
  ),
);

?>