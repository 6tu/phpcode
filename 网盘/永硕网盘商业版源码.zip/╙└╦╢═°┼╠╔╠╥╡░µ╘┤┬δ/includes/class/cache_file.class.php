<?php 

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

class super_cache {

	function super_cache() {

	}
	function cache_type(){
		return array('myinfo','public','file','tag','folder','announce','user','comment','extract','space','search','ads','link','gallery','navigation');
	}
	function _set($c_type,$c_key,$no_uid,$arr,$cache_func){
		global $db,$tpf,$pd_uid;
		if(is_array($arr)){
			if($no_uid){
				$cache_dir = PHPDISK_ROOT.'system/cache/common/'.$c_type.'/'.self::store_path($c_key);
			}else{
				$cache_dir = PHPDISK_ROOT.'system/cache/'.$pd_uid.'/'.$c_type.'/'.self::store_path($c_key);
			}
			$file = $cache_dir.$c_key.'.php';
			make_dir($cache_dir);

			$str = "<?php".LF.LF;
			$str .= "// This is PHPDISK auto-generated file. Do NOT modify me.".LF;
			$str .= "// Cache Time: ".date("Y-m-d H:i:s").LF;
			$str .= "// Function: $cache_func".LF.LF;
			$str .=	"if(!defined('IN_PHPDISK')){".LF;
			$str .= "\texit('[PHPDisk] Access Denied');".LF;
			$str .= "}".LF.LF;
			//$str .= "return '".serialize(self::addslashes_array($arr))."';".LF;
			$str .= "return '".str_replace("'","\'",serialize($arr))."';".LF;
			$str .= "?>".LF;

			write_file($file,$str);

		}else{
			$str = "Cache file _set($c_type,$c_key,$cache_func) data type error!";
			logger::write('cache_log',$str);
			die($str);
		}
	}
	function get($cache_func,$c_type='public',$no_uid=1,$life_time=300){
		global $db,$tpf,$pd_uid,$settings;
		if(!in_array($c_type,self::cache_type())){
			$str = "Cache type <b>$c_type</b> is error!";
			logger::write('cache_log',$str);
			die($str);
		}
		if($settings[open_cache]){
			if($no_uid){
				$c_key = md5($c_type.$cache_func);
				$p_dir = 'common/'.$c_type.'/';
			}else{
				$c_key = md5($c_type.$cache_func.(int)$pd_uid);
				$p_dir = $pd_uid.'/'.$c_type.'/';
			}
			$file = PHPDISK_ROOT.'system/cache/'.$p_dir.self::store_path($c_key).$c_key.'.php';

			if(file_exists($file) && $life_time==0){
				return unserialize(include_once($file));
			}
			if(file_exists($file) && TS-@filemtime($file)<(int)$life_time){
				return unserialize(include_once($file));
			}else{
				//echo $file.'|'.date('Y-m-d H:i:s',@filemtime($file));
				$cache_func2 = $cache_func;
				$param1 = $param2 = '';
				if(strpos($cache_func,'|')!==false){
					$arr = explode('|',$cache_func);
					$cache_func = $arr[0];
					$param1 = $arr[1];
					$param2 = $arr[2];
				}
				if(function_exists($cache_func)){
					if($param2){
						self::_set($c_type,$c_key,$no_uid,call_user_func($cache_func,$param1,$param2),$cache_func2);
						return call_user_func($cache_func,$param1,$param2);
					}else{
						self::_set($c_type,$c_key,$no_uid,call_user_func($cache_func,$param1),$cache_func2);
						return call_user_func($cache_func,$param1);
					}
				}else{
					$str = "Function <b>$c_type,$cache_func2</b> not exists!";
					logger::write('cache_log',$str);
					die($str);
				}
			}
		}else{
			$param1 = $param2 = '';
			if(strpos($cache_func,'|')!==false){
				$arr = explode('|',$cache_func);
				$cache_func = $arr[0];
				$param1 = $arr[1];
				$param2 = $arr[2];
			}
			if($param2){
				return call_user_func($cache_func,$param1,$param2);
			}else{
				return call_user_func($cache_func,$param1);
			}
		}
	}
	function clear_all(){
		$cache_dir = PHPDISK_ROOT.'system/cache/';
		self::_get_cache_file($cache_dir);
	}
	function clear_by_key($cache_func,$c_type='public',$c_uid=0){
		if(!$c_uid){
			$c_key = md5($c_type.$cache_func);
			$p_dir = 'common/'.$c_type.'/';
		}else{
			$c_key = md5($c_type.$cache_func.(int)$c_uid);
			$p_dir = $c_uid.'/'.$c_type.'/';
		}
		$cache_dir = PHPDISK_ROOT.'system/cache/'.$p_dir.self::store_path($c_key);
		self::_get_cache_file($cache_dir,1,$c_key);
	}
	function clear_by_uid($c_uid){
		$cache_dir = PHPDISK_ROOT.'system/cache/'.$c_uid.'/';
		self::_get_cache_file($cache_dir);
	}
	function clear_by_cate($c_type){
		$cache_dir = PHPDISK_ROOT.'system/cache/common/'.$c_type.'/';
		self::_get_cache_file($cache_dir);
	}
	function clear_by_cu($c_uid,$c_type){
		$cache_dir = PHPDISK_ROOT.'system/cache/'.$c_uid.'/'.$c_type.'/';
		self::_get_cache_file($cache_dir);
	}
	function _get_cache_file($dir,$dir_flag=1,$key='') {
		static $FILE_COUNT = 1;
		$FILE_COUNT--;
		$dh = @opendir($dir);
		if($dh){
			while(false!==($filename=readdir($dh))){
				$flag = $dir_flag;
				if($filename!='.' && $filename!='..'){
					$FILE_COUNT++;
					if(is_dir($dir.$filename)){
						self::_get_cache_file($dir.$filename.'/',$dir_flag+1);

					}else{
						if(substr($filename,-4)=='.php'){
							if($key){
								@unlink($dir.$key.'.php');
							}else{
								@unlink($dir.$filename);
							}
						}
					}
				}
			}
			closedir($dh);
		}else{
			$str = "$dir not exists , [_get_cache_file]!";
			logger::write('cache_log',$str);
		}
	}
	function store_path($c_key){
		return $c_key{0}.$c_key{1}.'/'.$c_key{2}.$c_key{3}.'/';
	}
}
?>