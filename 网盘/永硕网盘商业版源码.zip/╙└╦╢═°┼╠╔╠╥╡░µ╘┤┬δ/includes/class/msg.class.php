<?php 

!defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied');

class msg {

	function msg() {

	}
	function fmsg($str,$param){
		return sprintf($str,$param);
	}
}
?>