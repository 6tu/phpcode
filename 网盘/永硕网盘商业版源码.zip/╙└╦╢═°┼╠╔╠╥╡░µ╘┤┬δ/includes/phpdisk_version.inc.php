<?php 


if(!defined('IN_PHPDISK')) {
	exit('[PHPDisk] Access Denied');
}

define('PHPDISK_EDITION','V-Core File Edition');
define('PHPDISK_VERSION','6.5.0');
define('PHPDISK_RELEASE','20120717');

?>