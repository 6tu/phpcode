<?php !defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied!'); ?>
<!--#require_once template_echo('circle_box_header',$user_tpl_dir); #-->
<table border="0" cellpadding="0" style="border-collapse: collapse"><tr valign="top"><td>
<div id="ysleft">
<h2>注意事项</h2>
<div style="padding:5px;">
<b>
<font size="3">您</font></b>现在注册的是源码Ｅ盘空间，注册成功后您可以随时升级您的Ｅ盘空间。
<br /><b><font size="3">请</font></b>在右面表单中正确填写您的Email地址，此Email地址将是您忘记密码时找回的重要资料。
<br /><b><font size="3">用</font></b>户名限制3－15位，支持数字、字母和"-",但"-"不能放在开头和结尾。不区分大小写。
<br /><b><font size="3">密</font></b>码长度为6－20位。区分大小写，不支持字符：单引号、双引号、空格。
</div>
</div>
</td><td>
<div id="ysright">
<h1><img border="0" src="/ht/images/tree.gif" width="32" height="32" alt="" />注册源码Ｅ盘</h1>
<!--#
if($allow_register==true){
#-->

<div class="ysdb2">
	<form name="ctl00" method="post" action="register.aspx" id="ctl00">
<div>
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['ctl00'];
if (!theForm) {
    theForm = document.ctl00;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<div>
</div>
	<table border="1" width="100%">
	<tr>
		<td class="tdbt" width="110">用户名:</td>
		<td><input name="tedlmc" type="text" id="tedlmc" onBlur="checkdlmc();" onFocus="writedlmc();" style="width:150px;" /><span id="sm_dlmc"></span></td>
	</tr>
	<tr>
		<td class="tdbt">空间级别:</td>
		<td><select name="jbxz" id="jbxz" onChange="bao()" onBlur="checkjb();" onFocus="writejb();" style="width:150px;">
	<option selected="selected" value="请选择">请选择</option>
	<option value="免费型400兆">免费型400兆</option>
	<option value="个人型600兆">个人型600兆</option>
	<option value="标准型1000兆">标准型1000兆</option>
	<option value="增强型2000兆">增强型2000兆</option>
	<option value="企业I型6000兆">企业I型6000兆</option>
	<option value="企业II型12000兆">企业II型12000兆</option>

</select><span id="sm_jb"></span>
        <div style=" margin-top:5px;"><a href="list_cp.aspx" target="_blank" >查看级别详情</a></div>
        <div id="jbts" style="display:none; margin-top:5px;border:1px solid #C3DAEB;padding:5px; width:350px;background-color:#E4F3FC;"></div>
		</td>
	</tr>
	<tr>
		<td class="tdbt">邮箱地址:</td>
		<td><input name="teem" type="text" id="teem" onBlur="checkem();" onFocus="writeem();" style="width:150px;" /><span id="sm_em"></span></td>
	</tr>
	<tr>
		<td class="tdbt">确认邮箱地址:</td>
		<td><input name="teemqr" type="text" id="teemqr" onBlur="checkemqr();" onFocus="writeemqr();" style="width:150px;" /><span id="sm_emqr"></span></td>
	</tr>
	<tr>
		<td class="tdbt">管理密码:</td>
		<td><input name="temm" type="password" id="temm" onBlur="checkmm();" onFocus="writemm();" style="width:150px;" /><span id="sm_mm"></span></td>
	</tr>
	<tr>
		<td class="tdbt">确认管理密码:</td>
		<td><input name="temmqr" type="password" id="temmqr" onBlur="checkmmqr();" onFocus="writemmqr();" style="width:150px;" /><span id="sm_mmqr"></span></td>
	</tr>
	<tr>
		<td class="tdbt">注册协议:</td>
		<td><a href="/lt/zl/ys168_zcxx.htm" target="_blank">查看源码Ｅ盘注册协议</a>
		</td>
	</tr>

	</table>
	<div>
	&gt;<a href="list_cp.aspx" target ="_blank" >查看E盘产品列表</a>
	&gt;<a href="ht/yfk/index.aspx" target ="_blank">查看支付方式</a>
	</div>
	<p><input name="tjxx" type="submit" id="tjxx" value="接受注册协议并提交注册资料" style="margin-left:120px;" onClick="return check();" /></p>
	</form>

</div>

<!--#
}else{
#-->
<p><b><font color="#FF0000">抱歉，暂停用户注册,请稍候再来。</font></b></p>
<!--#

}
#-->

</div>
</td></tr></table>