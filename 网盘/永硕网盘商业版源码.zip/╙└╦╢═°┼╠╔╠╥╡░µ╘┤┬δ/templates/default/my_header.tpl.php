<!--#
##
#	Project: PHPDISK File Storage Solution
#	This is NOT a freeware, use is subject to license terms.
#
#	Site: http://www.phpdisk.com
#
#	$Id: my_header.tpl.html 25 2012-03-28 15:51:08Z along $
#
#	Copyright (C) 2008-2012 PHPDisk Team. All Rights Reserved.
#
##
#-->
<?php !defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied!'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset={$charset}" />
<title>PHPDISK User's Control Panel - PHPDisk.com</title>
<script type="text/javascript">var tpl_dir = '{$user_tpl_dir}';</script>
<script type=text/javascript src="includes/js/jquery.js"></script>
<script type="text/javascript" src="includes/js/common.js"></script>
<meta name="copyright" content="Powered by PHPDisk Team, {PHPDISK_EDITION} {PHPDISK_VERSION} build{PHPDISK_RELEASE}" />
<meta name="generator" content="PHPDisk {PHPDISK_VERSION}" />
<script type="text/javascript" src="includes/js/highslide.js"></script>
<link rel="stylesheet" type="text/css" href="images/highslide.css" />
<script type="text/javascript">
hs.align = 'center';
hs.outlineType = 'rounded-white';
hs.wrapperClassName = 'draggable-header';
</script>

<link href="{$user_tpl_dir}images/mydisk.css" rel="stylesheet" type="text/css">
</head>

<!--#if($inner_box){#-->
<body style="background:#FFFFFF">
<!--#}else{#-->
<body>
<!--#}#-->
