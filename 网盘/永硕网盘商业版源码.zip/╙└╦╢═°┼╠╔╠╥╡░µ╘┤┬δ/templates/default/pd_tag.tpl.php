<!--#
##
#	Project: PHPDISK File Storage Solution
#	This is NOT a freeware, use is subject to license terms.
#
#	Site: http://www.phpdisk.com
#
#	$Id: pd_tag.tpl.html 22 2012-03-20 01:27:28Z along $
#
#	Copyright (C) 2008-2012 PHPDisk Team. All Rights Reserved.
#
##
#-->
<?php !defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied!'); ?>
<div id="container">
<div class="tit">{$tag_title}</div>
<div class="layout_box">
<div class="l">
<script language="javascript">
$(document).ready(function(){
	$("#f_tab tr").mouseover(function(){
		$(this).addClass("alt_bg");
	}).mouseout(function(){
		$(this).removeClass("alt_bg");
	});
});
</script>
<!--#if(!$tag){#-->
<div class="tag_list">
<div class="t_tit"><?=__('last_tag_title')?></div>
<ul><li>
<!--#
if(count($last_tags)){
	foreach($last_tags as $v){
#-->
<a href="{$v['a_view_tag']}">{$v['tag_name']}<span class="txtgray">{$v['tag_count']}</span></a>
<!--#
	}
	unset($last_tags);
}
#-->
</li>
</ul>
<br />
<div class="clear"></div>
</div>
<br />
<div class="tag_list">
<div class="t_tit"><?=__('hot_tag_title')?></div>
<ul>
<li>
<!--#
if(count($hot_tags)){
	foreach($hot_tags as $v){
#-->
<a href="{$v['a_view_tag']}">{$v['tag_name']}<span class="txtgray">{$v['tag_count']}</span></a>
<!--#
	}
	unset($hot_tags);
}
#-->
</li>
</ul>
<br />
<div class="clear"></div>
</div>
<!--#}else{#-->
<table align="center" width="98%" cellpadding="0" cellspacing="0" border="0" id="f_tab" class="td_line">
<!--#
if(count($files_array)){
#-->
<tr>
	<td width="50%" class="bold"><?=__('file_name')?></td>
	<td align="center" class="bold"><?=__('file_size')?></td>
	<td align="center" width="150" class="bold"><?=__('file_upload_time')?></td>
</tr>
<!--#
	foreach($files_array as $k => $v){
		$color = ($k%2 ==0) ? 'color1' :'color4';
#-->
<tr class="{$color}" height="20">
	<td class="td_line">&nbsp;{#file_icon($v['file_extension'])#}&nbsp;
	<!--#if($v['is_locked']){#-->
	<span class="txtgray" title="<?=__('file_locked')?>">{$v['file_name']} {$v['file_description']}</span>
	<!--#}elseif($v['is_image']){#-->
	<a href="{$v['a_viewfile']}" id="p_{$k}" target="_blank" >{$v['file_name']}</a>&nbsp;<span class="txtgray">{$v['file_description']}</span><br />
<div id="c_{$k}" class="menu_thumb"><img src="{$v['file_thumb']}" /></div>
<script type="text/javascript">on_menu('p_{$k}','c_{$k}','x','');</script>
	<!--#}else{#-->
	<a href="{$v['a_viewfile']}" target="_blank" >{$v['file_name']}</a> <span class="txtgray">{$v['file_description']}</span>
	<!--#}#-->
	</td>
	<td align="center" class="td_line">{$v['file_size']}</td>
	<td align="center" width="150"  class="td_line txtgray">{$v['file_time']}</td>
</tr>
<!--#		
	}
	unset($files_array);
}	
#-->
<!--#if($page_nav){#-->
<tr>
	<td colspan="6">{$page_nav}</td>
</tr>
<!--#}#-->
</table>
<!--#}#-->
</div>
<div class="r">
<div class="common_box">
<!--#if($settings['show_hot_file_right']){#-->
<div class="tit2"><?=__('hot_file')?></div>
<ul>
<!--#
if(count($hot_file)){
	foreach($hot_file as $v){
#-->
<li>{#file_icon($v['file_extension'])#} <a href="{$v['a_viewfile']}" title="{$v['file_name_all']}" target="_blank">{$v['file_name']}</a> {$v['file_views']}</li>
<!--#
	}
	unset($hot_file);
}
#-->
</ul>
</div>
<br />
<!--#}#-->
<!--#show_adv_data('adv_right');#-->
<br />
</div>
<div class="clear"></div>
</div>
</div>
