<?php 
/**
#	Project: PHPDISK File Storage Solution
#	This is NOT a freeware, use is subject to license terms.
#
#	Site: http://www.phpdisk.com
#
#	$Id: template_info.php 40 2012-06-01 06:04:01Z along $
#
#	Copyright (C) 2008-2012 PHPDisk Team. All Rights Reserved.
#
*/

//	Template Name: PHPDisk默认模板
//	Template URL: http://www.phpdisk.com/
//	Description: PHPDisk默认模板 Copyright 2008-2012 (C)。
//	Author: PHPDISK TEAM
//	Author Site: http://www.phpdisk.com/ 
//	Version: v1.1
//	Template Type: user
//  PHPDISK Core: v6.5+

?> 
