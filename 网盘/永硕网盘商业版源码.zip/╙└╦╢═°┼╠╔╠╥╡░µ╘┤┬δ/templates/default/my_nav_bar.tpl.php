<!--#
##
#	Project: PHPDISK File Storage Solution
#	This is NOT a freeware, use is subject to license terms.
#
#	Site: http://www.phpdisk.com
#
#	$Id: my_nav_bar.tpl.html 2 2011-05-27 03:00:17Z along $
#
#	Copyright (C) 2008-2012 PHPDisk Team. All Rights Reserved.
#
##
#-->
<?php !defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied!'); ?>
<div class="mydisk_file_bar">
<div class="l">
<h1>{$nav_arr['title']}</h1>
<ul>
	<li><a href="javascript:void(0);" onclick="document.location.reload();"><img src="images/reload.gif" border="0" align="absmiddle" /><?=__('md_reload')?></a>
	<a href="{$nav_arr['a_folder_create']}" onclick="return hs.htmlExpand(this,{headingText:'<?=__('md_folder_create')?>',objectType: 'iframe',width:450});"><img src="images/new_folder.gif" border="0" align="absmiddle" /><?=__('md_folder_create')?></a>
	<a href="{$nav_arr['a_upload_file']}" onclick="return hs.htmlExpand(this,{headingText:'<?=__('upload_file')?>',objectType:'upload',width:650,height:500});"><img src="images/upload_file_icon.gif" border="0" align="absmiddle" /><?=__('upload_file')?></a>
	<a href="{#urr("mydisk","item=folders&action=index")#}"><img src="images/folder.gif" border="0" align="absmiddle" /><?=__('folder_manage')?></a>
	<a href="{$nav_arr['a_list_detail']}"><img src="images/list_icon.gif" border="0" align="absmiddle" /><?=__('thumb_view')?></a>
	<a href="{#urr("mydisk","item=files&action=extract_code_list")#}"><img src="images/ico_extract.gif" border="0" align="absmiddle" /><?=__('extract_code_manage')?></a>
	<!--#if($nav_arr['a_share_folder']){#-->
	<a href="{$nav_arr['a_share_folder']}" onclick="return hs.htmlExpand(this,{headingText:'<?=__('share_folder')?>',objectType: 'iframe'});"><img src="images/share_folder.gif" border="0" align="absmiddle" /><?=__('share_folder')?></a>
	<!--#}#-->
	</li>
</ul>
</div>
<div class="r">
	<div class="tit"><?=__('disk_info')?>:</div>
	<div class="disk_info" title="<?=__('disk_remain')?>: {$nav_arr['disk_remain']}% ({$nav_arr['disk_space']})">
	<div style="background:url(images/disk_bar.gif);width:{$nav_arr['disk_fill']}px;">&nbsp;</div>
	</div>
	<div style="color:#666">{$nav_arr['now_space']}/{$nav_arr['max_storage']} (<b>{$nav_arr['disk_percent']}%</b>)</div>
</div>
</div>
<div class="clear"></div>
