<!--#
##
#	Project: PHPDISK File Storage Solution
#	This is NOT a freeware, use is subject to license terms.
#
#	Site: http://www.phpdisk.com
#
#	$Id: circle_box.tpl.html 2 2011-05-27 03:00:17Z along $
#
#	Copyright (C) 2008-2012 PHPDisk Team. All Rights Reserved.
#
##
#-->
<?php !defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied!'); ?>
<div class="body_top">
<div class="l"></div>
<div class="r"></div>
</div>
<div class="circle_box">
<a href="./"><img src="images/logo.gif" width="275" height="64" align="absmiddle" border="0" alt="{$settings['site_title']}"></a>

<div class="user_face">
<b class="ctop">
<b class="cb1"></b><b class="cb2"></b><b class="cb3"></b><b class="cb4"></b>
</b>
