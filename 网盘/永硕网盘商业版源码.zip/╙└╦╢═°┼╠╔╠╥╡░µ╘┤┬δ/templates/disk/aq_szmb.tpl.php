<table cellpadding="0" border="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
        <div id="ysleft">
        <h2>空间后台操作菜单</h2>
        <strong>主要操作</strong>
        <ul class="yslb3">
        <li><a href="/user.php">空间状态</a></li>
        <li><a href="/user.php?act=sj">空间升级</a></li>
<!--        <li><a href="/user.php?act=yq">空间延期</a></li>
-->        </ul>
        <strong>账户管理</strong>
        <ul class="yslb3">
        <li><a href="/zh.php">账户充值</a></li>
        <li><a href="/zh.php?act=cz">充值记录</a></li>
        <li><a href="/zh.php?act=xf">消费记录</a></li>
        </ul>
        <strong>空间设置</strong>
        <ul class="yslb3">
        <li><a href="/sz.php">常规设置</a></li>
        <li><a href="/sz.php?act=qx">访客权限</a></li>
        <li><a href="/sz.php?act=lj">首页链接</a></li>
        <li><a href="/sz.php?act=px">目录排序方式</a></li>
        <li><a href="/sz.php?act=fg">空间风格</a></li>
        <li><a href="/sz.php?act=zl">设置个人资料</a></li>
        </ul>
        <strong>空间安全</strong>
        <ul class="yslb3">
        <li><a href="/aq.php">设置登录密码</a></li>
        <li><a href="/aq.php?act=glmm">修改管理密码</a></li>
        <!--<li><a href="/aq.php?act=xgyx">修改邮箱</a></li>-->
        <li><a href="/aq.php?act=szmb" id="xz">设置密保</a></li>
        <li><a href="/aq.php?act=xgmb">修改密保</a></li>
        <!--<li><a href="/aq.php?act=wjmm">忘记密码</a></li>-->
        </ul>
        <strong>其它</strong>
        <ul class="yslb3">
        
        <li><a href="/ly.php">留言管理</a></li>
        </ul></div>
    </td><td>
    <script language="javascript" type="text/javascript">

    window.onload = function() {
        var ts = "";
        if (ts != "") alert(ts); }

        function dk() {

            if (document.forms[0].wen1.selectedIndex == 19) { document.getElementById("z_wt1").style.display = 'block'; document.getElementById("wenti1").focus(); }
            else {
                document.getElementById("z_wt1").style.display = 'none'; 
                if (document.forms[0].wen1.selectedIndex != 0) {
                    if (document.forms[0].wen1.selectedIndex == document.forms[0].wen2.selectedIndex) {
                        alert('抱歉，不能选择2个相同的问题。');
                        document.forms[0].wen1.selectedIndex = 0;
                    }
                }
            }
        }
        function dk2() {

            if (document.forms[0].wen2.selectedIndex == 19) { document.getElementById("z_wt2").style.display = 'block'; document.getElementById("wenti2").focus(); }
            else {
                document.getElementById("z_wt2").style.display = 'none'; 
                if (document.forms[0].wen2.selectedIndex != 0) {
                    if (document.forms[0].wen1.selectedIndex == document.forms[0].wen2.selectedIndex) {
                        alert('抱歉，不能选择2个相同的问题。');
                        document.forms[0].wen2.selectedIndex = 0;
                    }
                }
            }
        }
        function check() {
            if (!confirm('请确认是否进行提交设置')) return false;
            var ys = document.forms[0];
            if (ys.wen1.selectedIndex == 19) {
                if (ys.wenti1.value == '') { alert('自定义问题1不能为空。'); ys.wenti1.focus(); return false; }
                if (ys.wenti1.value.length > 50) { alert('自定义区问题1至少3个字符，最多50个字符。'); ys.wenti1.focus(); return false; }
                if (ys.wenti1.value.length < 3) { alert('自定义区问题1至少3个字符，最多50个字符。'); ys.wenti1.focus(); return false; }
                if (checkzf(ys.wenti1.value) == 'F') { alert('自定义区问题1不支持特殊字符的输入。'); ys.wenti1.focus(); return false; }
            }
            
            if (ys.wen2.selectedIndex == 19) {
                if (ys.wenti2.value == '') { alert('自定义问题2不能为空。'); ys.wenti2.focus(); return false; }
                if (ys.wenti2.value.length > 50) { alert('自定义区问题2至少3个字符，最多50个字符。'); ys.wenti2.focus(); return false; }
                if (ys.wenti2.value.length < 3) { alert('自定义区问题2至少3个字符，最多50个字符。'); ys.wenti2.focus(); return false; }
                if (checkzf(ys.wenti2.value) == 'F') { alert('自定义区问题2不支持特殊字符的输入。'); ys.wenti2.focus(); return false; }
            }

            if (ys.wen1.selectedIndex == 19 && ys.wen2.selectedIndex == 19) { if (ys.wenti1.value == ys.wenti2.value) { alert('抱歉，不能设置2个相同的问题。');  return false; } }
                        
            if (ys.wen1.selectedIndex == 0) { alert('请选择问题1。'); return false; }
            if (ys.daan1.value == '') { alert('答案1不能为空。'); ys.daan1.focus(); return false; }
            if (ys.daan1.value.length > 50) { alert('答案1最多50个字符。'); ys.daan1.focus(); return false; }
            if (checkzf(ys.daan1.value) == 'F') { alert('答案1不支持特殊字符的输入。'); ys.daan1.focus(); return false; }
            
            if (ys.wen2.selectedIndex == 0) { alert('请选择问题2。'); return false; }
            if (ys.daan2.value == '') { alert('答案2不能为空。'); ys.daan2.focus(); return false; }
            if (ys.daan2.value.length > 50) { alert('答案2最多50个字符。'); ys.daan2.focus(); return false; }
            if (checkzf(ys.daan2.value) == 'F') { alert('答案2不支持特殊字符的输入。'); ys.daan2.focus(); return false; }

            if (ys.daan2.value == ys.daan1.value) { alert('2个答案不能相同。'); ys.daan1.focus(); return false; }
        }

        function checkzf(nr) {
            var zf = "/\\'<>\"&"
                for (i = 0; i <= zf.length - 1; i++) {
                    if (nr.indexOf(zf.substr(i, 1)) >= 0) { return "F" }
                }
                return "T"
            }
               
</script>
        <div id="ysright">
            <h1><label class="dl1">用户名：<font color="green">{$pd_username}</font>  账户余额：{$userinfo['wealth']}元  <a href="/zh.php">账户充值</a> <a href="/account.php?action=logout">退出</a></label><img width="32" height="32" border="0" alt="" src="/images/xg.gif">设置密码保护</h1>
            <form id="ctl00" action="aq.php?act=szmbs" method="post" name="ctl00">
<div class="ysdb2">
                    <table width="100%" border="1" id="table1">
                    	<tbody>          
	                    <tr>
		                    <td width="90" class="tdbt">密保问题1：</td>
		                    <td>
		                        <select style="width:320px;" onchange="dk()" id="wen1" name="wen1">
	<option value="请选择密保问题">请选择密保问题</option>
	<option value="您母亲的姓名是？">您母亲的姓名是？</option>
	<option value="您父亲的职业是？">您父亲的职业是？</option>
	<option value="您配偶的生日是？">您配偶的生日是？</option>
	<option value="您的学号（或工号）是？">您的学号（或工号）是？</option>
	<option value="您母亲的生日是？">您母亲的生日是？</option>
	<option value="您高中班主任的名字是？">您高中班主任的名字是？</option>
	<option value="您父亲的姓名是？">您父亲的姓名是？</option>
	<option value="您的出生地是？">您的出生地是？</option>
	<option value="您小学班主任的名字是？">您小学班主任的名字是？</option>
	<option value="您小学的校名是？">您小学的校名是？</option>
	<option value="您父亲的生日是？">您父亲的生日是？</option>
	<option value="您配偶的姓名是？">您配偶的姓名是？</option>
	<option value="您母亲的职业是？">您母亲的职业是？</option>
	<option value="您初中班主任的名字是？">您初中班主任的名字是？</option>
	<option value="您配偶的职业是？">您配偶的职业是？</option>
	<option value="您最熟悉的童年好友的名字是？">您最熟悉的童年好友的名字是？</option>
	<option value="您最熟悉的学校宿舍好友的名字是？">您最熟悉的学校宿舍好友的名字是？</option>
	<option value="对您影响最大的人的名字是？">对您影响最大的人的名字是？</option>
</select>
		                    </td>
	                    </tr>
	                    <tr>
		                    <td width="90" class="tdbt">密保答案1：</td>
		                    <td><input type="text" style="width:320px;" id="daan1" name="daan1"></td>
	                    </tr>
	                    <tr>
		                    <td width="90" class="tdbt">密保问题2：</td>
		                    <td>
		                        <select style="width:320px;" onchange="dk2()" id="wen2" name="wen2">
	<option value="请选择密保问题">请选择密保问题</option>
	<option value="您母亲的姓名是？">您母亲的姓名是？</option>
	<option value="您父亲的职业是？">您父亲的职业是？</option>
	<option value="您配偶的生日是？">您配偶的生日是？</option>
	<option value="您的学号（或工号）是？">您的学号（或工号）是？</option>
	<option value="您母亲的生日是？">您母亲的生日是？</option>
	<option value="您高中班主任的名字是？">您高中班主任的名字是？</option>
	<option value="您父亲的姓名是？">您父亲的姓名是？</option>
	<option value="您的出生地是？">您的出生地是？</option>
	<option value="您小学班主任的名字是？">您小学班主任的名字是？</option>
	<option value="您小学的校名是？">您小学的校名是？</option>
	<option value="您父亲的生日是？">您父亲的生日是？</option>
	<option value="您配偶的姓名是？">您配偶的姓名是？</option>
	<option value="您母亲的职业是？">您母亲的职业是？</option>
	<option value="您初中班主任的名字是？">您初中班主任的名字是？</option>
	<option value="您配偶的职业是？">您配偶的职业是？</option>
	<option value="您最熟悉的童年好友的名字是？">您最熟悉的童年好友的名字是？</option>
	<option value="您最熟悉的学校宿舍好友的名字是？">您最熟悉的学校宿舍好友的名字是？</option>
	<option value="对您影响最大的人的名字是？">对您影响最大的人的名字是？</option>
</select>
		                    </td>
		                </tr>
	                    <tr>
		                    <td width="90" class="tdbt">密保答案2：</td>
		                    <td><input type="text" style="width:320px;" id="daan2" name="daan2"></td>
	                    </tr>                    
	                </tbody></table>
	                <br>
	                <input type="submit" id="butj" onclick="return check();" value="提交设置" name="butj">
	                <br><br>                    
                    <ul class="yslb2">
                        <li>请认真选择或填写问题、答案，此将成为您找回密码的凭据。</li>
                        <li>请牢记密保答案，如果遗失，将无法找回或重置。</li>
                        <li>问题和答案不支持字符（' &lt; &gt; / \ " &amp;）</li>
                        <li>密保答案不区分大小写</li>
                    </ul>
                </div>            </form>

        </div>
        </td></tr></tbody></table>