<?php !defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied!'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset={$charset}" />
<title>{$title}<!--#if($settings['powered_info']){#--> - Powered by PHPDisk Team<!--#}#--></title>
<link rel="shortcut icon" href="favicon.ico">
<!--#if($settings['open_seo']){#-->
<meta name="keywords" content="{$file_keywords}{$settings['meta_keywords']}" />
<meta name="description" content="{$file_description}{$settings['meta_description']}" />
<!--#}#-->
<link rel="stylesheet" href="{$user_tpl_dir}css/common.css" type="text/css" />
<script type=text/javascript src="includes/js/jquery.js"></script>
</head>
<body>
<div id="ysm">

<div id='header'><div id='logo'></div><p>－－专业数据存储、交流平台</p></div>
<div id='topnav'>&nbsp;&nbsp;&nbsp;<a href='/list_cp.php'>首页</a> | <a href='account.php?action=register'>注册Ｅ盘</a> | <a href='/list_cp.php'>Ｅ盘产品</a> | <a href='/user.php'>空间后台</a> | <a href='/kf.php'>客服中心</a> | <a href='/help.php'>操作指南</a></div>