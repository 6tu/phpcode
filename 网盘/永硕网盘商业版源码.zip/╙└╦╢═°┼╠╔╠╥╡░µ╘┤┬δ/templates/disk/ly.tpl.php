<table cellpadding="0" border="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
        <div id="ysleft">
        <h2>空间后台操作菜单</h2>
        <strong>主要操作</strong>
        <ul class="yslb3">
        <li><a href="/user.php">空间状态</a></li>
        <li><a href="/user.php?act=sj">空间升级</a></li>
<!--        <li><a href="/user.php?act=yq">空间延期</a></li>
-->        </ul>
        <strong>账户管理</strong>
        <ul class="yslb3">
        <li><a href="/zh.php">账户充值</a></li>
        <li><a href="/zh.php?act=cz">充值记录</a></li>
        <li><a href="/zh.php?act=xf">消费记录</a></li>
        </ul>
        <strong>空间设置</strong>
        <ul class="yslb3">
        <li><a href="/sz.php">常规设置</a></li>
        <li><a href="/sz.php?act=qx">访客权限</a></li>
        <li><a href="/sz.php?act=lj">首页链接</a></li>
        <li><a href="/sz.php?act=px">目录排序方式</a></li>
        <li><a href="/sz.php?act=fg">空间风格</a></li>
        <li><a href="/sz.php?act=zl">设置个人资料</a></li>
        </ul>
        <strong>空间安全</strong>
        <ul class="yslb3">
        <li><a href="/aq.php">设置登录密码</a></li>
        <li><a href="/aq.php?act=glmm">修改管理密码</a></li>
        <!--<li><a href="/aq.php?act=xgyx">修改邮箱</a></li>-->
        <li><a href="/aq.php?act=szmb">设置密保</a></li>
        <li><a href="/aq.php?act=xgmb">修改密保</a></li>
        <!--<li><a href="/aq.php?act=wjmm">忘记密码</a></li>-->
        </ul>
        <strong>其它</strong>
        <ul class="yslb3">
       
        <li><a href="/ly.php" id="xz">留言管理</a></li>
        </ul></div>
    </td><td>
    <script language="javascript" type="text/javascript">

function CheckAll(form){
	for (var i=0;i<form.elements.length;i++){
		var e = form.elements[i];
		if (e.name != 'chkall' && e.type=='checkbox'){
			e.checked = form.chkall.checked;
		}
	}
}
function CheckAll2(form){
	for (var i=0;i<form.elements.length;i++){
		var e = form.elements[i];
		if (e.name != 'chkall0' && e.type=='checkbox'){
			e.checked = form.chkall0.checked;
		}
	}
}
function CheckAll3(){
	form=document.forms[0];
	for (var i=0;i<form.elements.length;i++){
		var e = form.elements[i];
		if (e.name != 'chkall1' && e.type=='checkbox'){
			e.checked = true;
		}
	}
}
function CheckAll4(){
	form=document.forms[0];
	for (var i=0;i<form.elements.length;i++){
		var e = form.elements[i];
		if (e.name != 'chkall1' && e.type=='checkbox'){
			e.checked = false;
		}
	}
}
function scly(){
    if (!confirm('请确认是否进行删除')) return false;
	form=document.forms[0];
	var dsz="";
	for (var i=0;i<form.elements.length;i++){
		var e = form.elements[i];
		if (e.name != 'chkall' && e.name !='chkall0' && e.type=='checkbox' && e.checked){
			dsz  +=e.name;
		}
	}
	
	if(dsz==""){alert('请选择要删除的留言！');return false;}
//	document.all("ly_id").value=dsz;
	document.getElementById("ly_id").value=dsz;
//	alert(document.getElementById("ly_id").value)
//	return false;

}

</script>
        <div id="ysright">
            <h1><span id="yhztxs"><label class="dl1">用户名：<font color="green">{$pd_username}</font>  账户余额：{$userinfo['wealth']}元  <a href="/zh.php">账户充值</a> <a href="/account.php?action=logout">退出</a></label></span><img width="32" height="32" border="0" alt="" src="/images/tools.gif">加密目录密码查询</h1>
            <div class="ysdb2">
            
            <div class="ysdb">
            <form name="ctl00" method="post" action="ly.php" id="ctl00">
            <input type="hidden" name="act" value="dele" />
                    <table>
	                    <tbody><tr class="trbt">
		                    <td align="center"><input type="checkbox" title="选中/取消选中 本页所有留言" onclick="CheckAll(this.form)" value="on" name="chkall"></td>
		                    <td>留言人</td>
		                    <td>内容</td>
		                    <td>留言时间</td>
	                    </tr>
	                    {$result}       
	                    <tr>
		                    <td align="left" colspan="4">
			                    <a href="javascript:CheckAll3();"><font color="#0000FF"><u>全选</u></font></a> - 
			                    <a href="javascript:CheckAll4();"><font color="#0000FF"><u>取消</u></font></a>

		                    </td>
	                    </tr>
                    </tbody></table>
                    <p style="text-align:left;">
            <input type="submit" id="idsc" onclick="return scly();" value="删除选中留言" name="idsc">
            </p>
                    </form>
                    
            </div>
        </div>
        </td></tr></tbody></table>