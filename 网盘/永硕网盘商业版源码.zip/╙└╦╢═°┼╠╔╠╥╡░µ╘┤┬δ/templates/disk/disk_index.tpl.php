<html>
<head>
<meta http-equiv="Content-Language" content="zh-cn" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>{$webtitle}</title>
<meta name="keywords" content="{$webkey}" /> 
<meta name="description" content="{$webdes}" /> 
<link rel="Stylesheet" href="/css/{$userinfo['kjfg']}.css" type="text/css" />

<script language="JavaScript" type="text/javascript">

    var jzpd=0;var owPd=0;var wjscjs=1;
    var Qcxzt=false;var PD_gzgg="0";var xdwjsl;var duser;var dxkbt;var dxkly;var dxkjl;
    var dxksc;var dffpd;var dfgxz;var Qsjk;var dxken;var Qzdqbh = 0; ffOK = false; ccOK = false;
	var wjdxs="{$max_file_size}";
	var zhbds;
    var FFGQPD = "0";var ddlmc = "{$name}";var Qzydz = "/";var Qccym = "c5.ys168.com";
    function onloads() {_fup.ly = '{$name}'; if (Qcxzt) { ysdy();} ffOK = true;}
	function $(rid) {return document.getElementById(rid);}

	function ysdy() { if (ccOK) return; ccOK = true; frxcx.zx(); }
	function tc() { window.location = "/exit.php?dlmc=" + ddlmc; }
	function qdhost() { var x = document.domain.split("."); if (x.length == 3) return x[1] + "." + x[2]; return x[2] + "." + x[3]; }
</script>

<script language="JavaScript" type="text/javascript" src="/js/main7.js"></script>
<script language="JavaScript" type="text/javascript" src="/js/common.js"></script>
</head>
<base target="ys_ck" />


<body scroll="no" style="height:100%;" onLoad="onloads();">

<table id="ta_z" border="0" width="100%" height="100%" cellspacing="0" cellpadding="0">

<tr><td height="70" class="tdtop">
<!------wgsm-------->
	<div class="ystop">
	<h1>{$userinfo['t1']}</h1><p>
    
<!--#
    while($rs = $db->fetch_array($userlk)){
echo '<img width="12" height="8" border="0" src="/images/point.gif"><a target="_blank" href="'.$rs['linku'].'">'.$rs['linkt'].'</a>&nbsp;';
   }
#-->

    </p>
	</div>
</td></tr>
<tr><td style="padding-top:8px;">

<table border="0" width="100%" height="100%" cellspacing="0" cellpadding="0"><tr><td width="255" valign="top" style="padding:0 5px 0 5px;">

<table border="0" width="255" height="100%" cellspacing="0" cellpadding="0">
<tr><td valign="top" style="height:22px;">
	<div id="ysmenu" style="width:255px;">
            <div class="ysm1" id="mm1" style="display:block;margin-left:2px;" onMouseOver="mlq_ov(this);" onMouseOut="mlq_ou(this);" onClick="qhzml(1)">留 言</div>
            <div class="ysm0" id="mm2" style="display:block;" onMouseOver="mlq_ov(this);" onMouseOut="mlq_ou(this);" onClick="qhzml(2)">增加目录</div>
            <div class="ysm0" id="mm3" style="display:block;" onMouseOver="mlq_ov(this);" onMouseOut="mlq_ou(this);" onClick="qhzml(3)">上传文件</div>
            <div class="ysm0" id="mm4" style="display:block;" onMouseOver="mlq_ov(this);" onMouseOut="mlq_ou(this);" onClick="qhzml(4)">管理区</div>
	</div>
</td></tr><tr><td valign="top" style="height:127px;min-height:125px;">	
<!--操作区开始-->
<div id="ysmenu1" style="width:255px;height:100%;">
<div id='ml_1' style="display:block;padding-top:8px;">
	<p>姓名:<input type="text" id="xm" size="8" class="TX3">
		公开:<input type="checkbox" id="bdgkpdlyb"  checked >
		<img border="0" src="/images/00zxz1.gif" width="15" height="15" onClick="changetp('z');" style="cursor:pointer;">
		<img border="0" name="t_bq" src="/images/f1.gif" width="15" height="15">
		<img border="0" src="/images/00zxy1.gif" width="15" height="15" onClick="changetp('y');" style="cursor:pointer;"> 
		<input type="hidden" id="bdbq" value="1" />
	</p>
	<p><textarea id="nr"></textarea></p>	
	<p align="center"><input type="button" value=" 提交留言 " onClick="checkly('');" class='BT2' id="buly" /></p>
</div>
<div id='ml_2'  style="display:none;padding-top:8px;">
    <p><label class="la1">目录标题:</label><input type="text" id="bdbt" style="width:148;" class="tx3" onKeyPress="if (window.event.keyCode==13){$('bdsm').focus();return false;}"/></p>
	<p><label class="la1">签写署名:</label><input type="text" id="bdsm" style="width:148;" class="tx3" onKeyPress="if (window.event.keyCode==13){$('bdmlmm').focus();return false;}"  /></p>

	<p><label class="la1">目录密码:</label><input type="password" id="bdmlmm" class="tx3" style="width:85;" onKeyPress="if (window.event.keyCode==13){$('sutjbt').focus();return false;}"/>
	    [<a href="/help.php" target="_blank">设置指南</a>]
	
	</p>
	<p align="center" style="margin-top:6px;">
   <input type="button" id="sutjbt" value=" 添加目录 " onClick="_m.tj();" class="BT2"/>    
    </p>
</div>

<div id='ml_3' style="display:none;padding-top:8px;" >
	<div style="border-bottom:1px dashed black;text-align:center;margin-bottom:10px;">
	    <input type="radio" id="wjlx1" name="r1" checked="checked"  onclick="changelx(1);" style="cursor:pointer;"/><label for="wjlx1" style="cursor:pointer;">上传文件</label>
	    <input type="radio" id="wjlx2" name="r1" onClick="changelx(2)" style="cursor:pointer;"/><label for="wjlx2" style="cursor:pointer;">链接网址</label>
	    <input type="radio" id="wjlx3" name="r1" onClick="changelx(3)" style="cursor:pointer;"/><label for="wjlx3" style="cursor:pointer;">子目录</label>
	</div>
	<div id="idwj1" style="display:block;">
		<div  id="filesczt1" style="display:block;">
			<p style="margin-top:8px;margin-bottom:8px;">
			<input type="button" value="开始上传" class="bt2" id="filesc2" onClick="_C.kq(_CK.wjsc);" style="font-size: 20px;font-weight: bold;height: 50px;width: 220px;"/></p>
		</div>
		<div id="filesczt2" style="display:none;"></div>
	</div>
	<div id="idwj2" style="display:none;">
		<p>标题:<input type=text id="scbt2" class="tx3" size=26></p>
		<p>网址:<input type=text id="teljdz" class=tx3 size=26></p>
		<p align=center><input type="button" value="增加链接" onClick="checkfu();" class='BT2' id="bulj"/></p>
	</div>
	<div id="idwj3" style="display:none;">
		<p>子目录名:<input type=text id="tezml" class=tx3 size=20 style="background-color:#FFEBCD" onKeyPress="if (window.event.keyCode==13){$('buzml').click();return false;}" /></p>
		<p align=center><input type="button" value="增加子目录" onClick="_zml.cj();"  class='BT2' id="buzml"></p>
	</div>	
</div>
<div id='ml_4'  style="display:none;padding-top:15px;">
	<div id='glyq1' style="display:block;">
		<p align="center">管理密码:<input type="password" id="bdglymm" onKeyPress="if (window.event.keyCode==13){sutjgl.click();}"  class="tx3" style="height:18; width:70">
		<input type=button value=" 登  录 " onClick="checkgl('');" class='BT2' id="sutjgl"/></p>
		<p><font color='#008000'>注:管理员登录后可以编辑、删除空间内文件、目录、留言等。</font></p>
	</div>
	<div id='glyq2' style="display:none;">
		<p>空间级别:<span id="L_kjjb">{$diskinfo['group_name']}({$diskinfo['max_storage']})</span></p>
		<p>到期日期:<span id="L_fwdq">{$info}&nbsp;&nbsp;<a class=actuatorn href='/user.php?act=sj' target=_blank>[升级空间]</a></span></p>
		<p align="center"><input type=button value="退出管理" id='glytc'  class='bt2' onClick="fglytc();"></p>
	</div>
	<div>
		<p>
			<img src="/images/wh.gif" width="14" height="14"/><a class="jaml"  href="javascript:" onClick="kq_help();">如何编辑删除数据</a>
			<img src="/images/go.gif" width="16" height="16"/><a  href="/user.php" class="jaml" target="_blank">进入空间后台</a>
		</p>
	</div>

</div>
</div>
</td></tr>
<tr><td height="5"></td></tr>
<tr><td valign="top"><div id="lynr" class="lynrc"><label>正在读取...</label></div></td></tr>
<tr><td height="5">
</td></tr>
</table>
<!--左边窗口结束-->
</td><td style="padding:0 5px 5px 0">
<table border="0" width="100%" height="100%" cellspacing="0" cellpadding="0"><tr><td style="border:1px solid #000000;">
			<table border="0" width="100%" height="100%" cellspacing="0" cellpadding="0">
			<tr height="20" class="ta_wjq"><td>

			    <div style="float:right;">
					空间:<label id="kjz1">{$diskinfo['max_storage']}</label>M
					剩余:<label id="kjz2">{$now_space}</label>M
					访问计数:<label id="zxrsts1" style="color:yellow;">0</label>次
					在线:<label id="zxrsts" style="color:yellow;">0</label>人&nbsp;
				</div>
				<div style="padding-left:5px;">
				目录列表
				</div>
			</td></tr>
			<tr><td valign="top">
    			<div style="height:100%;word-wrap: break-word; word-break: normal;overflow-y :scroll;background-color:#ffffff;" id="dzx">
                <div id="zdy_wz0" style="display:none; float:right;">
                    <div id='idzdy' class='yszdyq' style="display:none;"></div>
                    <div id='idzdy1' class='yszdyq' style="display:none;"></div>
                </div>
	                    <div id="mainMenu"><ul id="menuList"></ul></div>
	                    <div id="zdy_bz"></div>
	                    <p style="text-align:right;" id="sxts">
	                    <a class="a1" onClick="if (confirm('是否刷新目录数据？'))_m.cxdq();" style="font:9pt;padding-left:14px;background:url(/images/refresh.gif) no-repeat 0em -0.1em;" href="javascript:">刷新目录</a></p>
				        
				</div>
				<div style="clear:both;"></div>
			</td></tr>
			</table>
</td></tr>
<tr><td height="30">
	<table border="0" width="100%" height="100%" cellpadding="0" id="table2">
	<tr><td height=20>
	<span id="laczts">{$userinfo['t3']}</span>
		{$userinfo['t4']}
	</td></tr><tr><td height="30">
	        <p align ="right">
    
			<input type="button" value="在线列表"  class='bt2' onClick="_C.kq(_CK.zxlb);"/>
			<input type="button" id="buxz" value="下载记录" onClick="_C.kq(_CK.xzlb);" class='bt2'/>
			<input type="button" id="buexit" value="退出系统" onClick="tc();" class="bt2"/>
			</p>
			<iframe name="frxcx" id="frxcx" src="/center.php?name={$name}" style="display:none;"></iframe>
		    <iframe name="ys_ck" src="about:blank" style="display:none;"></iframe>
</td></tr></table>
	
</td></tr>
</table>

</td></tr></table>
</td></tr></table>
<div id="ctrq"></div>



</body>
</html>