
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<script language="JavaScript" type="text/javascript" src="/js/aj.js"></script>
</head>
<script language="JavaScript" type="text/javascript">
function onloads(){parent.Qcxzt=true;zx();}
function zx(){var F=document.forms[0];parent.mldq({$folderid});setTimeout('dy()',15000);}
function qdhost() { var x = document.domain.split("."); if (x.length == 3) return x[1] + "." + x[2]; return x[2] + "." + x[3]; }
</script>
<body onLoad="onloads();">
<form method="post">
<input type="hidden" id="Yz0" name="Yz0" value="{$yz0}"/>
<input type="hidden" id="Yz1" name="Yz1" value="{$yz1}"/>
<input type="hidden" id="Yz2" name="Yz2" value="{$yz2}"/>
<input type="hidden" id="Yz3" name="Yz3" value="{$yz3}"/>
<input type="hidden" id="Yz4" name="Yz4" value="{$yz4}"/>
</form>

</body>
</html>