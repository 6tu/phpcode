
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>退出系统</title>
<style type="text/css">
	P {	FONT-SIZE: 10pt;line-height:140%;text-align:center;color:#9ACD32;margin-top:10px;}
	A { COLOR: #9ACD32;}
	A:hover {COLOR: yellow; TEXT-DECORATION: underline}
	h3  {color:Green;}
	img {border:0;}
</style>


</head>
<body text="#C0C0C0" bgcolor="#000000">
<p>　</p>
<h3 align="center">已安全离开系统，谢谢使用!</h3>
<hr />

<p>
<a href="/help.php">E盘操作指南</a>
<a href="/diy.php">E盘美化</a>
</p>

</body>

</html>