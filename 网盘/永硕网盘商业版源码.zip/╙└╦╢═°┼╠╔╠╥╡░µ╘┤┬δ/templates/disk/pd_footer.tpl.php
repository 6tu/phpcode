﻿<?php !defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied!'); ?>
<div id='footer'>{$footer}<table border='0' cellpadding='0' style='border-collapse: collapse;' align='center'><tr><td style='width:120px;' align='center'><div style='font-size:8pt;line-height:110%; float:right;'><a href='http://www.miitbeian.gov.cn' target=_blank><img class='tp' src='/images/shca_cc.gif' alt='通信管理局' width='38' height='43' /></a><br />鲁ICP备15009992号-2<br /></div></td><td style='width:170px;' align='center'><a href='http://www.miitbeian.gov.cn' target='_blank' ><img src='/images/clip.jpg' class='tp' alt='' /></a></td><td style='width:70px;' align='center'><a href='#' target='_blank' ><img src='/images/GA_Logo.gif' class='tp' alt=''  /></a></td></tr></table></div>
<div style=" padding-top:20px;">
        <img src="images/zxw.gif" alt="" border="0" width="199" height="59" />
        <a href="http://www.sgs.gov.cn/lz/licenseLink.do?method=licenceView&entyId=20121011160225120"></a>
<a href="http://webscan.360.cn/index/checkwebsite/url/pan.zz06.cn"><img border="0" src="http://img.webscan.360.cn/status/pai/hash/b2cdc6bcd9001a4ce5e24b5ffabf385c"/></a>    
</div>
</div>

</body>
</html>