<?php 
/**
#	Project: PHPDISK File Storage Solution
#	This is NOT a freeware, use is subject to license terms.
#
#	Site: http://www.phpdisk.com
#
#	$Id: template_info.php 9 2012-02-04 02:17:20Z along $
#
#	Copyright (C) 2008-2012 PHPDisk Team. All Rights Reserved.
#
*/

//	Template Name: 管理员后台模板
//	Template URL: http://www.phpdisk.com/
//	Description: PHPDISK官方默认后台模板 Copyright 2008-2011 (C)。
//	Author: PHPDISK TEAM
//	Author Site: http://www.phpdisk.com/ 
//	Version: v1.2
//	Template Type: admin
//  PHPDISK Core: v5.0+

?> 
