<!--#
##
#	Project: PHPDISK File Storage Solution
#	This is NOT a freeware, use is subject to license terms.
#
#	Site: http://www.phpdisk.com
#
#	$Id: adm_footer.tpl.html 2 2011-05-27 03:00:17Z along $
#
#	Copyright (C) 2008-2012 PHPDisk Team. All Rights Reserved.
#
##
#-->
<?php !defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied!'); ?>
<br/><br/>
<div style="border-bottom:1px #ccc solid">&nbsp;</div>
<br/>
<div align="center" class="f10">{$pageinfo}</div>
<div align="center" class="f10">Powered by <a href="http://www.phpdisk.com/" target="_blank">PHPDisk Team</a> {PHPDISK_EDITION} {PHPDISK_VERSION} &copy; 2008-{NOW_YEAR} All Rights Reserved.</div>
<br/><br/><br/>	
</body>
</html>
