<!--#
##
#	Project: PHPDISK File Storage Solution
#	This is NOT a freeware, use is subject to license terms.
#
#	Site: http://www.phpdisk.com
#
#	$Id: datacall.tpl.html 2 2011-05-27 03:00:17Z along $
#
#	Copyright (C) 2008-2012 PHPDisk Team. All Rights Reserved.
#
##
#-->
<?php !defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied!'); ?>
<!--#if($action =='js'){#-->
<div id="container">
<h1><?=__('js_datacall')?><!--#sitemap_tag(__('js_datacall'));#--></h1>
<div>
<div class="tips_box"><img class="img_light" src="images/light.gif" align="absmiddle" /> <b><?=__('tips')?>: </b>
<span class="txtgray"><?=__('js_datacall_tips')?></span>
</div>
<table align="center" width="100%" cellpadding="4" cellspacing="0" border="0" class="td_line">
<tr>
	<td colspan="2"><span class="bold"><?=__('js_module')?></span>: </td>
</tr>
<tr>
	<td colspan="2" class="txtgray"><?=__('js_module_tips')?></td>
</tr>
<tr>
	<td width="20%"><?=__('param_1')?>:</td>
	<td><?=__('param_1_tips')?></td>
</tr>
<tr>
	<td><?=__('param_2')?>:</td>
	<td style="word-break:break-all;word-wrap:word-break;"><?=__('param_2_tips')?><br /><strong><?=__('user_table')?></strong>:<span class="txtblue"><?=__('user_field_list')?></span><br /> <strong><?=__('file_table')?></strong>:<span class="txtblue"><?=__('file_field_list')?></span></td>
</tr>
<tr>
	<td><?=__('param_3')?>:</td>
	<td><?=__('param_3_tips')?></td>
</tr>
<tr>
	<td><?=__('param_4')?>:</td>
	<td><?=__('param_4_tips')?></td>
</tr>
<tr>
	<td colspan="2"><?=__('datacall_url')?><input type="text" size="90" id="um_id" value="{$settings['phpdisk_url']}api/datacall.php?type=&order=&by=asc&limit=" />&nbsp;<input type="button" class="btn" value="<?=__('test')?>" onclick="datacall_test();" /></td>
</tr>
</table>
<iframe style="z-index: 1; display:none;overflow:auto; width:100%; height:auto; padding:1px; border:2px #efefef solid; margin-bottom:10px;" id="test_frm" src="" frameborder="0" scrolling="auto"></iframe>
</div>
</div>
<script type="text/javascript">
function datacall_test(){
	getId('test_frm').src = getId('um_id').value;
	getId('test_frm').style.display = '';
}
</script>
<!--#}elseif($action =='sql'){#-->
<div id="container">
<h1><?=__('sql_datacall')?><!--#sitemap_tag(__('sql_datacall'));#--></h1>
<div>
<div class="tips_box"><img class="img_light" src="images/light.gif" align="absmiddle" /> <b><?=__('tips')?>: </b>
<span class="txtgray"><?=__('sql_datacall_tips')?></span>
</div>
<table align="center" width="100%" cellpadding="4" cellspacing="0" border="0" class="td_line">
<tr>
	<td colspan="2"><span class="bold"><?=__('sql_module')?></span>: </td>
</tr>
<tr>
	<td colspan="2"><?=__('sql_module_tips')?><span class="txtgray">{$sql_module}</span><br /><br /><?=__('sql_module_tech')?></td>
</tr>
</table>
</div>
</div>
<!--#}elseif($action =='add_arr' || $action =='edit_arr'){#-->
<div id="container">
<!--#if($action =='add_arr'){#-->
<h1><?=__('add_arr_datacall')?></h1>
<!--#}else{#-->
<h1><?=__('edit_arr_datacall')?></h1>
<!--#}#-->
<div>
<div class="tips_box"><img class="img_light" src="images/light.gif" align="absmiddle" /> <b><?=__('tips')?>: </b>
<span class="txtgray"><?=__('arr_datacall_tips')?></span>
</div>
<form action="{#urr(ADMINCP,"item=$item")#}" method="post">
<input type="hidden" name="action" value="{$action}"/>
<input type="hidden" name="task" value="{$action}"/>
<input type="hidden" name="dcid" value="{$dcid}" />
<input type="hidden" name="formhash" value="{$formhash}" />
<table align="center" width="100%" cellpadding="4" cellspacing="0" border="0" class="td_line">
<tr>
	<td width="30%"><span class="bold"><?=__('datacall_key')?></span>: <br /><span class="txtgray"><?=__('datacall_key_tips')?></span></td>
	<td><input type="text" name="c_key" value="{$c_key}" size="50" maxlength="200"/></td>
</tr>
<tr>
	<td><span class="bold"><?=__('datacall_value')?></span>:<br /><span class="txtgray"><?=__('datacall_value_tips')?></span></td>
	<td><textarea name="c_value" rows="8" cols="60">{#get_datacall($c_key)#}</textarea></td>
</tr>
<tr>
	<td>&nbsp;</td>
	<td><input type="submit" class="btn" value="<?=__('btn_submit')?>"/></td>
</tr>
</table>
</form>
<br />
</div>
</div>
<!--#}elseif($action =='arr'){#-->
<script language="javascript">
$(document).ready(function(){
	$("tr.tr_fs").each(function(){
		var obj = $(this).find("a");
		$(this).mouseover(function(){
			obj.css("display","");
		}).mouseout(function(){
			obj.css("display","none");
		});
	});
});
</script>
<div id="container">
<h1><?=__('arr_datacall')?><!--#sitemap_tag(__('arr_datacall'));#--></h1>
<div>
<div class="tips_box"><img class="img_light" src="images/light.gif" align="absmiddle" /> <b><?=__('tips')?>: </b>
<span class="txtgray"><?=__('arr_datacall_tips')?></span>
</div>
<table align="center" width="100%" cellpadding="4" cellspacing="0" border="0" class="td_line">
<!--#
if(count($C['arr_datacall_list'])){
#-->
<tr class="bold">
	<td width="40%"><?=__('datacall_key')?></td>
	<td><?=__('datacall_value')?></td>
</tr>
<!--#
	foreach($C['arr_datacall_list'] as $v){
#-->
<tr class="tr_fs">
	<td>{$v['dcid']}.&nbsp;&nbsp;{$v['dc_key']}&nbsp;&nbsp;
	<a href="{#urr(ADMINCP,"item=$item&action=edit_arr&dcid=$v[dcid]")#}" class="txtblue" title="<?=__('edit_tips')?>" style="display:none">[<?=__('edit')?>]</a>
	<a href="{#urr(ADMINCP,"item=$item&action=$action&task=del_arr&dcid=$v[dcid]")#}" onclick="return confirm('<?=__('del_dc_confirm')?>');" class="txtred" title="<?=__('del_tips')?>" style="display:none">[×]</a>
	</td>
	<td><textarea cols="60" rows="5" readonly="readonly">{#get_datacall($v['c_key'])#}</textarea></td>
</tr>	
<!--#
}
#-->
<tr>
	<td colspan="4">{$page_nav}&nbsp;</td>
</tr>	
<!--#
}else{
#-->
<tr>
	<td><?=__('misc_array_not_found')?></td>
</tr>
<!--#
}
#-->
<tr>
	<td colspan="4"><input type="button" class="btn" value="<?=__('add_datacall_arr')?>" onclick="go('{#urr(ADMINCP,"item=$item&action=add_arr")#}');" /></td>
</tr>
</table>
</div>
</div>

<!--#}#-->
