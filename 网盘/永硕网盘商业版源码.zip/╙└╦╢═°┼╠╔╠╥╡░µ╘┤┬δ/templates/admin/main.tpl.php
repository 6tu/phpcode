<!--#
##
#	Project: PHPDISK File Storage Solution
#	This is NOT a freeware, use is subject to license terms.
#
#	Site: http://www.phpdisk.com
#
#	$Id: main.tpl.html 22 2012-03-20 01:27:28Z along $
#
#	Copyright (C) 2008-2012 PHPDisk Team. All Rights Reserved.
#
##
#-->
<?php !defined('IN_PHPDISK') && exit('[PHPDisk] Access Denied!'); ?>
<div id="container">
<h1><?=__('admincp_statistics')?><!--#sitemap_tag(__('admincp_statistics'));#--></h1>
<div>
<div class="tips_box"><img class="img_light" src="images/light.gif" align="absmiddle" /> <b><?=__('tips')?>: </b>
<span class="txtgray"><?=__('stats_tips')?></span>
</div>
<div id="warning"></div>
<table align="center" width="100%" cellpadding="4" cellspacing="0" border="0">
<tr>
	<td width="15%" align="right"><?=__('users_count')?>: </td>
	<td>{$stats['users_count']} <?=__('piece')?>, <?=__('users_locked_count')?><a href="{#urr(ADMINCP,"item=users&action=index&gid=0&orderby=is_locked")#}"><span class="txtred bold">{$stats['users_locked_count']}</span></a> <?=__('piece')?> , <?=__('users_open_count')?><span class="txtblue bold">{$stats['users_open_count']}</span><?=__('piece')?></td>
</tr>
<tr>
	<td align="right"><?=__('user_files_count')?>: </td>
	<td>{$stats['user_files_count']} <?=__('piece')?> , <?=__('in_storage')?> <b>{$stats['user_storage_count']}</b></td>
</tr>
<tr>
	<td align="right"><?=__('public_files_count')?>: </td>
	<td>{$stats['public_files_count']} <?=__('piece')?>, <?=__('in_storage')?> <b>{$stats['public_storage_count']}</b></td>
</tr>
<tr>
	<td align="right"><?=__('total_storage_count')?>: </td>
	<td>{$stats['all_files_count']} <?=__('piece')?>, <?=__('in_storage')?> <b>{$stats['total_storage_count']}</b></td>
</tr>
<tr>
	<td align="right"><?=__('other_stats')?>: </td>
	<td><?=__('extract_code_count')?> {$stats['extract_code_count']} <?=__('piece')?>, <?=__('user_folders_count')?> {$stats['user_folders_count']} <?=__('piece')?></td>
</tr>
</table>
<br />
<table width="100%" cellpadding="4" cellspacing="1" class="tableborder" style="display:{$show_news_frame}">
<tr>
	<td class="table_title"><?=__('phpdisk_site_news')?></td>
</tr>
<tr>
	<td><iframe id="news_banner" src="./admin/banner.inc.php" style="z-index: 1;visibility: inherit; overflow: auto; width: 100%; height: 50px;" frameborder="0" scrolling="no"></iframe></td>
</tr>
</table>
<br />
<table align="center" width="100%" cellpadding="4" cellspacing="1" class="tableborder">
<tr>
	<td class="table_title" colspan="2"><?=__('system_env')?></td>
</tr>
<!--#if(!$settings['online_demo']){#-->
<tr>
	<td class="tablerow"><?=__('system_host')?>: {$_SERVER['SERVER_NAME']}({$_SERVER['SERVER_ADDR']})</td>
	<td class="tablerow" valign="top" width="50%" rowspan="6"><div style="margin-bottom:5px;"><?=__('phpdisk_email_subscribe')?></div><script >var nId = "0e1bc68fa78ff8fd7d9841059b4313737169dd94b352cf7e",nWidth="500",sColor="light",sText="<?=__('phpdisk_email_subscribe2')?>" ;</script><script src="http://list.qq.com/zh_CN/htmledition/js/qf/page/qfcode.js" charset="gb18030"></script></td>
</tr>
<tr>
	<td class="tablerow"><?=__('system_server')?>: {$_SERVER['SERVER_SOFTWARE']}</td>
</tr>
<!--#}#-->
<tr>
	<td class="tablerow"><?=__('system_base')?>: MySQL {$mysql_info}, PHP {PHP_VERSION}, <?=__('system_post_file')?> <span class="bold">{$post_max_size}</span>, <?=__('system_upload_file')?> <span class="bold">{$file_max_size}</span><span class="txtred">(<?=__('max_upload_file_tips')?>)</span></td>
<tr>
	<td class="tablerow"><?=__('system_gd_info')?>: {$gd_support} ({$gd_info})</td>
</tr>
<tr>
	<td class="tablerow"><?=__('iconv_txt')?>: (<?=__('iconv_support')?>: {$iconv_support} <?=__('or')?> <?=__('mbstring_support')?>: {$mbstring_support} ) <span class="txtgray">(<?=__('iconv_tips')?>)</span></td>
</tr>
<tr>
	<td class="tablerow"><?=__('phpdisk_prober')?>: <a href="http://bbs.phpdisk.com/viewthread.php?tid=1506" target="_blank">http://bbs.phpdisk.com/viewthread.php?tid=1506</a></td>
</tr>
</table>
<br />
<table align="center" width="100%" cellpadding="4" cellspacing="1" class="tableborder">
<tr>
	<td class="table_title"><?=__('about_system')?></td>
</tr>
<tr>
	<td class="tablerow"><?=__('program_develop')?>: <a href="http://bbs.phpdisk.com/space.php?uid=1" target="_blank">along</a></td>
</tr>
<tr>
	<td class="tablerow"><?=__('official_site')?>: <a href="http://www.phpdisk.com/" target="_blank">http://www.phpdisk.com</a></td>
</tr>
<tr>
	<td class="tablerow"><?=__('phpdisk_bbs')?>: <a href="http://bbs.phpdisk.com/" target="_blank">http://bbs.phpdisk.com</a></td>
</tr>
<tr>
	<td class="tablerow"><?=__('phpdisk_demo')?>: <a href="http://demo.phpdisk.com/" target="_blank">http://demo.phpdisk.com</a></td>
</tr>
<tr>
	<td class="tablerow"><?=__('version_info')?>: <b>PHPDisk {PHPDISK_EDITION} {PHPDISK_VERSION} [{$charset_info}]</b> (Build{PHPDISK_RELEASE})</td>
</tr>
<tr>
	<td class="tablerow"><?=__('phpdisk_commend_tips')?></td>
</tr>
</table>

</div>
</div>
<!--#if($alert){#-->
<script language="javascript">
function autoupdate(){
	var xmlhttp = createHttpRequest();
	xmlhttp.open("get","./admin/autoupdate.inc.php?action=upgrade",true);
	xmlhttp.onreadystatechange = function(){
		if(xmlhttp.readyState == 4 && xmlhttp.status == 200){
			var arr = xmlhttp.responseText.split('|');
			if(parseInt(arr[1]) > parseInt('{PHPDISK_RELEASE}')){
				getId('warning').innerHTML = "<span><?=__('last_version_is')?>："+arr[0]+" ,Release"+arr[1]+", <?=__('your_version_is')?>：{PHPDISK_EDITION} {PHPDISK_VERSION} Release{PHPDISK_RELEASE} , {$update_url}</span>";
				getId('warning').className = "warning";
			}
		}
	}
	xmlhttp.send(null);
	document.write("<img src=http://www.phpdisk.com/autoupdate.php?edition={#rawurlencode(PHPDISK_EDITION)#}&version={PHPDISK_VERSION}&release={PHPDISK_RELEASE}&server={SERVER_NAME} width=0 height=0>");
	
}
autoupdate();
</script>
<!--#}#-->
<!--#if($get_official_news){#-->
<script language="javascript">
function getnews(){
	var xmlhttp = createHttpRequest();
	xmlhttp.open("get","./admin/autoupdate.inc.php?action=getnews",true);
	xmlhttp.onreadystatechange = function(){
		if(xmlhttp.readyState == 4 && xmlhttp.status == 200){
			if(xmlhttp.responseText == 'true'){
				getId('news_banner').src = "{$news_url}";
			}
		}
	}
	xmlhttp.send(null);
}
getnews();
</script>
<!--#}#-->
