
先运行  /backup/siteslist.php 产生文件表

把两份文件表复制到 /backup/log/

修改 /backup/diff.php 并运行

用 /backup/backup.php 压缩新产生的文件

