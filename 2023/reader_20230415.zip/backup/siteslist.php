<?php

date_default_timezone_set('Asia/Hong_Kong');

$fn_bacup = $area[1] .'reader_list_utc8_'. date("YmdH") .'.txt';

//header('Content-type:text/html; charset=utf-8'); 
$dir = '/home/liuyunor/oio.pw/sites/'; #/home/liuyunor/public_html/reader/backup/20230320/reader
chdir($dir);

$array = scandir($dir);
$files ='';
foreach($array as $value){
    if($value === '.' || $value === '..') continue;
    if(is_file($value)) continue;
    // echo $value;
    $array_html = scandir($value);
    $array_html = array_diff($array_html, array(".", "..", "article_images"));
    $array_html = preg_filter('/^/', './'.$value.'/',  $array_html);
    $files .= print_r($array_html, true);
    
    if(file_exists($value .'/article_images')){
        $array_img = scandir($value .'/article_images');
        $array_img = array_diff($array_img, array(".", ".."));
        $array_img = preg_filter('/^/', './'.$value .'/article_images/', $array_img);
        $files .= print_r($array_img, true);
    }
}

//$files = preg_replace("/\r|\n/", "", $files);
$files = str_replace(array("\r", "\n", "\t", " "), array("", "", "", ""), $files);
$files = str_replace(array(")Array(", "=>"), array("", "=>\r\n"), $files);
$files = preg_replace('/\[\d+\]=>/is', "", $files);

echo mb_detect_encoding($files) ."\r\n\r\n";
$files = mb_convert_encoding($files , 'GBK', 'UTF-8');
file_put_contents(__DIR__ .'/reader_list_utc8_'. date("YmdH") .'.txt', $files);


# 删除空文件夹 find empty_fold -type d -empty -delete

