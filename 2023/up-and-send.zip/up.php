<?php

//print_r($_FILES['upfile']); //var_dump($_FILES['upfile']);

$filepath = __DIR__."/test/"; # 上载文件存放路径
$filepath = 'd:/home/test/';
// print_r($_SERVER);
$ip_allow = array();
$ipjson = 'china-ip.json';
$ip = '222.50.36.99';
//$ip = @$_SERVER['REMOTE_ADDR'];

$ipstatus = check_is_china_ip($ip, $ipjson);
if(!$ipstatus) die("\n 403 Forbidden\n");

$ext_allow = array("txt", "rtf", "doc", "rar", "exe", "zip", "7z", "png", "jpg", "gif", "bmp", "jpeg", "webp", "html", "htm");
$log = '';
$buf = ob_get_contents();
ob_end_clean();
$postmaxsize = trim(ini_get('post_max_size'));
preg_match_all('/\d+/', $postmaxsize ,$arr);
$number = $arr[0][0];
if(strpos($postmaxsize, 'M') !== false) $postmaxsize = $number*1024*1024;
if(strpos($postmaxsize, 'G') !== false) $postmaxsize = $number*1024*1024*1024;

if(strpos($buf, 'POST Content-Length') !== false) $log .= "上传文件大于最大值 $postmaxsize ";
else $log .= $buf;

# 如果为字符串,则转为数组
if(is_string($_FILES['upfile']['name'][0])){
    foreach($_FILES['upfile'] as $key => $value){
        $_FILES['upfile'][$key] = [$value];
    }
}

if(isset($_POST['uploadaction'])){
    set_time_limit(60);
    $_POST['uploadaction'] = 0;
    $n = count($_FILES['upfile']['name']);
    for($i = 0; $i < $n; $i++){
        $upfile_name = $_FILES['upfile']['name'][$i];
        $upfile_size = $_FILES['upfile']['size'][$i];
        $upfile_type = $_FILES['upfile']['type'][$i];
        $upfile_tmp  = $_FILES['upfile']['tmp_name'][$i];
        $upfile_error= $_FILES['upfile']['error'][$i];
        
        $ext = pathinfo($upfile_name, PATHINFO_EXTENSION);
        if(!in_array($ext, $ext_allow)){
            echo ("\n $upfile_name 不接收的文件类型\n");
            continue;
        }
        
        if($upfile_size < 1024) $filesize = $upfile_size . " Byte";
        elseif($upfile_size < (1024 * 1024)) $filesize = number_format((double)($upfile_size / 1024), 1) . " KB";
        else $filesize = number_format((double)($upfile_size / (1024 * 1024)), 1) . " MB";
        
        if(($upfile_tmp != "none") && ($upfile_tmp != "")){
            $filename = $filepath . $upfile_name;
            if(!file_exists($filename)){
                if(copy($upfile_tmp, $filename)){
                    unlink($upfile_tmp);
                    $log .= " $upfile_name [ $filesize ]已上传至 $filepath ";
                }else $log .= " $upfile_name 上载失败！";
            }else $log .= " $upfile_name 已经存在！";
        }
    }
    set_time_limit(30); //恢复默认超时设置
}

# ****** 从json格式数据中检测IP是否来自中国
function check_is_china_ip($ip, $ipjson){
    $ip_addr = explode('.', $ip);
    if(count($ip_addr) < 4) return false;
    $a1 = (int)$ip_addr[0];
    $a2 = (int)$ip_addr[1];
    $a3 = (int)$ip_addr[2];
    $a4 = (int)$ip_addr[3];
    $s_china = file_get_contents($ipjson);
    $tb_china = json_decode($s_china, 1);
    unset($s_china);
    if(!isset($tb_china[$a1][$a2]) || count($tb_china[$a1][$a2]) == 0) return false;
    $a = $a3 * 256 + $a4;
    foreach($tb_china[$a1][$a2] as $d){
        if($a >= $d['s'] && $a <= $d['e']){
            return true;
        }
    }
    return false;
}
?>

<html>
<head>
  <title>文件上传</title>
</head>
<body>
  <center>
  <h2>文件上传</h2>
  <form
    action="<?php echo $_SERVER['PHP_SELF']; ?>"
    method="post"
    enctype="multipart/form-data"
  >
    <input type="hidden" name="max_file_size" value="8388608" />
    <input type="hidden" name="uploadaction" value="1" />
    <input type="file" name="upfile" size="30" />
    <input name="submit" value="提交" type="submit" />
    <input name="reset" value="重置" type="reset" />
  </form>
  <?php echo "<br>". $log ."\r\n"; ?>
  </center>
</body>
</html>

