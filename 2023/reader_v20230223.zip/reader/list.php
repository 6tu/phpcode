<?php
// $img = array('jpg', 'jpeg', 'gif', 'png', 'image', 'webp', 'bmp', 'svg');
$dir = '/home/liuyunor/public_html/reader/';
$path = 'sites';

rm_empty_dir($dir.$path);

$files = getDir($path);
// print_r($f);
foreach ($files as $key => $value){
    
    # 删除指定类型文件
    // if(strpos($value, '.svg') !== false){
    //     unlink($dir.$value);
    //     continue;
    // }
    
    # 空文件
    if(filesize($dir.$value)< 1){
        unlink($dir.$value);
        continue;
    }

    if(strpos($value, '.html') !== false){
        $html = file_get_contents($dir.$value);

        # 空 body文件
        $html_h2_array = explode('</h2>', $html, 2);
        if(empty($html_h2_array[1])) $html_h2_array[1] = $html_h2_array[0];
        $html_footer_array = explode('<div id="footer">', $html_h2_array[1], 2);
        if(empty($html_footer_array[1])) $html_footer_array[1] = '';
        $body = $html_footer_array[0];
        $footer = $html_footer_array[1];
        if(strlen($body) < 30 and file_exists($dir.$value)){
            //unlink($dir.$value);
            continue;
        }

        # 空 title
        preg_match_all("/<title[\s\S]*?>(.*?)<\/title>/is", $html, $ytb_title);
        $title = isset($ytb_title[1][0]) ? trim($ytb_title[1][0]) : "";
        $title = preg_replace("/\r\n|\r|\n/", '', $title);
        if(empty($title)) $title = $value;

        echo '<a href='. $value .'>'. $title ."<br>\r\n";
    }
}

// <div id="footer">
/**
 * *遍历目录中的文件
 * *由 searchDir() 和 getDir() 两个函数组成，
 * *使用 getDir($path) ，返回数组
 *
 * @参数 $path目录路径
 */	
function searchDir($path, & $data){
    if(is_dir($path)){
        $dp = dir($path);
        while($file = $dp -> read()){
            if($file != '.' && $file != '..'){
                searchDir($path . '/' . $file, $data);
            }
        }
        $dp -> close();
    }
    if(is_file($path)){
        $data[] = $path;
    }
}
function getDir($path){
    $data = array();
    searchDir($path, $data);
    return $data;
}

/**
 * *删除所有空目录
 * 
 * @参数 $path目录路径
 */
function rm_empty_dir($path){
    if(is_dir($path) && ($handle = opendir($path)) !== false){
        while(($file = readdir($handle)) !== false){ // 遍历文件夹
            if($file != '.' && $file != '..'){
                $curfile = $path . '/' . $file;//当前目录
                if(is_dir($curfile)){ // 目录
                    rm_empty_dir($curfile);//如果是目录则继续遍历
                    if(count(scandir($curfile)) == 2){ // 目录为空,=2是因为.和..存在
                        rmdir($curfile);//删除空目录
                    }
                }
            }
        }
        closedir($handle);
    }
}


?>