<?php


/* ---------------------- 公共函数库 ---------------------- */

# 找到两个字符串完全相同的部分
# 赋值给$longest，当找到有最长的字符串，就替换$longest
function longest($str1 = '', $str2 = ''){
    $start = 0; $end = 1; $longest = ''; $len = mb_strlen($str1); # $len 不能大于这个数
    for($i = 0;$i < $len;){
        if($start >= $len) break;
        if($end > $len) break;
        $part = mb_substr($str1, $start, $end);
        if(strpos($str2, $part) !== false){
            if(mb_strlen($part) > mb_strlen($longest)) $longest = $part;
            $end++;
        }else{
            $i++;
            $start = $i-1;
            $end = 1;
        }
    }
    return $longest;
}


# 删除指定的HTML标签，$tags是数组
function strip_html_tags($tags, $str) {
    $html = array();
    foreach ($tags as $tag) {
        $html[] = "/(<(?:\/".$tag."|".$tag.")[^>]*>)/i";
    }
    $data = preg_replace($html, '', $str);
    return $data;
}

function html_form_enc(){
    // header("Content-type: text/html; charset=utf-8");
    $js_rsa = js_rsa();
    $js_display_tr = js_display_tr();
    $js_check_enable= js_check_enable();
    $js = $js_check_enable . $js_rsa . $js_display_tr ;
    $form = '
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>优化阅读&mdash;&mdash;重拾阅读的乐趣</title>

    <style>
        #title{text-align:left; text-indent:3em; color:green;}
        #sec{text-align:left; text-indent:12em;}
        #form p{text-indent:0; font-size:1.5em}
        #form p input[type=text]{height:30px; width:90%}
        //#form select{height:30px; width:90%}
        #form table{width: 91%;}
        #td{height:30px; width:90%}
        #form td input[type=text]{height:30px; width:100%}
    </style>

'.$js.'

</head>
  <body class="bg">
    <center>
      <h1 id="title">优化阅读</h1>
      <p id="sec">&mdash;&mdash;&nbsp; 重拾阅读的乐趣</p>
      <form action="' . php_self() . '" method="post" id="form" class="search">
        <p><input type="text" placeholder="请输入网址。视频网址建议末尾追加参数&format=mp4或者&format=webm" autocomplete="off" id="url" name="url" value=""  /></p>
        '.html_select_ua().'
        <p><input type="submit" id="submit" value="&raquo; gogo提交" style="width:40%; height:60px; font-size:24px;" onclick="cmdEncrypt();" /></p>
      </form>
    </center>
  </body>
</html>
    ';
    echo $form;
}

function html_form(){
    // header("Content-type: text/html; charset=utf-8");
    $form = '
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>优化阅读&mdash;&mdash;重拾阅读的乐趣</title>
    <style>
        #title{text-align:left; text-indent:3em; color:green;}
        #sec{text-align:left; text-indent:12em;}
        #form p{text-indent:0; font-size:1.5em}
        #form p input[type=text]{height:30px; width:90%}
    </style>
  </head>
  <body class="bg">
    <center>
      <h1 id="title">优化阅读</h1>
      <p id="sec">&mdash;&mdash;&nbsp; 重拾阅读的乐趣</p>
      <form action="' . php_self() . '" method="get" id="form" class="search">
        <p><input type="text" placeholder="请输入你要阅读的网址" autocomplete="off" id="url" name="url" value=""  /></p>
        <p><input type="submit" id="submit" value="&raquo; gogo提交" /></p>
      </form>
    </center>
  </body>
</html>
';
echo $form;
}

function html_head($title){
    $head='
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <meta name="renderer" content="webkit">
    <meta name="force-rendering" content="webkit"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
    <meta name="referrer" content="no-referrer">
    
    <title>'. $title .'</title>

    <link rel="stylesheet" href="'. dirname($_SERVER['PHP_SELF']) .'/libs/css/header-custom.css" type="text/css" media="screen" />
    <!--<style type="text/css">div{background: #FDFEFE;}</style>-->

  </head>

';
    return $head;
}

# 获取当前PHP文件名
function php_self(){
    $php_self = substr($_SERVER['PHP_SELF'], strrpos($_SERVER['PHP_SELF'], '/') + 1);
    return $php_self;
}

/**
 * *获取随机字串
 * 
 * @参数 $n=4 字串
 */
function rand_char($n=4) { 
    $rand = '';
    for($i = 0;$i < $n;$i++ ){
        $base = 62;
        $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $rand .= $chars[mt_rand(1, $base) - 1];
    }
    return $rand;
}
/**
 * $html-需要爬取的页面内容
 * $tag-要查找的标签
 * $attr-要查找的属性名
 * $value-属性名对应的值
 */
function get_tag_data($html,$tag,$attr,$value){
	$regex = "/<$tag.*?$attr=\".*?$value.*?\".*?>(.*?)<\/$tag>/is";
	preg_match_all($regex,$html,$matches,PREG_PATTERN_ORDER);
	return $matches[1];
}

/**
 * 安全获取GET/POST的参数
 * 
 * @param  String  $request_name
 * @param  Mixed   $default_value
 * @param  String  $method 'post', 'get', 'all' default is 'all'
 * @return String 
 */
function getRequestParam($request_name, $default_value = null, $method = "all"){
    $magic_quotes = ini_get("magic_quotes_gpc") ? true : false;
    $method = strtolower($method);
    switch(strtolower($method)){
    // default:
    case "all":
        if(isset($_POST[$request_name])){
            return $magic_quotes?stripslashes($_POST[$request_name]):$_POST[$request_name];
        }elseif(isset($_GET[$request_name])){
            return $magic_quotes?stripslashes($_GET[$request_name]):$_GET[$request_name];
        }else{
            return $default_value;
        }
        break;
    case "get":
        if(isset($_GET[$request_name])){
            return $magic_quotes ? stripslashes($_GET[$request_name]) : $_GET[$request_name];
        }else{
            return $default_value;
        }
        break;
    case "post":
        if(isset($_POST[$request_name])){
            return $magic_quotes ? stripslashes($_POST[$request_name]) : $_POST[$request_name];
        }else{
            return $default_value;
        }
        break;
    default:
        return $default_value;
        break;
    }
}

function http_parse_headers($raw_headers){
    $headers = array();
    $key = '';
    foreach(explode("\n", $raw_headers) as $i => $h){
        $h = explode(':', $h, 2);
        if(isset($h[1])){
            if(!isset($headers[$h[0]])) $headers[$h[0]] = trim($h[1]);
            elseif(is_array($headers[$h[0]])){
                // $tmp = array_merge($headers[$h[0]], array(trim($h[1])));
                // $headers[$h[0]] = $tmp;
                $headers[$h[0]] = array_merge($headers[$h[0]], array(trim($h[1])));
            }else{
                // $tmp = array_merge(array($headers[$h[0]]), array(trim($h[1])));
                // $headers[$h[0]] = $tmp;
                $headers[$h[0]] = array_merge(array($headers[$h[0]]), array(trim($h[1])));
            }
            $key = $h[0];
        }else{
            if(substr($h[0], 0, 1) == "\t") $headers[$key] .= "\r\n\t" . trim($h[0]);
            elseif(!$key) $headers[0] = trim($h[0]);
        }
    }
    return $headers;
}

/**
 * 获取网页内容
 * https://www.php.net/manual/zh/function.curl-setopt.php
 * @param  String  支持GET和POST
 * @return Array   网页内容，报头，状态码，mime类型和编码 charset
 * $res_array = getResponse($url); // echo $res_array['body'];
 *
 */
function getResponse($url, $data = [], $cookie_jar, $useragent){

    # 该链接的来源处/引用处
    $url_array = parse_url($url);
    $refer = $url_array['scheme'] . '://' . $url_array['host'] . '/';
    
    # 接受的介质类型
    $accept = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9';


    # 浏览器语言
    if(!empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) $lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
    else $lang = 'zh-CN,zh;q=0.9';

    # 浏览器标识
    if(empty($useragent)) $useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36';
    // if(empty($_SERVER['HTTP_USER_AGENT'])) $useragent = 'Wget/1.18 (mingw32/linux-gnu)';
    // else $useragent = $_SERVER['HTTP_USER_AGENT'];

    # cookie，建议绝对路径
    if(empty($cookie_jar)){
        if(!file_exists('./tmp')) mkdir('./tmp', 0777, true);
        $cookie_jar = __DIR__ .'/tmp/'. md5($url_array['host']) .'.cookie';
        if(file_exists($cookie_jar) == false) file_put_contents($cookie_jar, '');
    }
    $cookie_str = file_get_contents($cookie_jar);

    $req_header = array(
        // "Content-Type: text/html; charset=UTF-8",
        // "Content-Type: application/json",
        // "Authorization: Bearer x",
        "Accept: " . $accept,
        //"Accept-Encoding: gzip, deflate",
        "Accept-Language: " . $lang,
        // "Cache-Control: max-age=0",
        "Connection: keep-alive",
        // "Cookie: " . $cookie_str,
        "Host: " . $url_array['host'],
        // "Referer: " . $refer,
        // "User-Agent: " . $useragent,
    );

    $ch = curl_init();
    $options = array(
        # 请求部分
        CURLOPT_URL              => $url,
        CURLOPT_USERAGENT        => $useragent,
        CURLOPT_REFERER          => $refer,
        CURLOPT_ENCODING         => 'gzip, deflate',
        CURLOPT_HTTPHEADER       => $req_header,
        CURLOPT_AUTOREFERER      => true,         # 301 重定向
        CURLOPT_FOLLOWLOCATION   => true,         # 302 重定向
        // CURLOPT_MAXREDIRS        => 10,           # 最多10次重定向
        CURLOPT_COOKIESESSION    => true,         # 更新cookie
        CURLOPT_COOKIEJAR        => $cookie_jar,  # 取cookie的参数是
        CURLOPT_COOKIEFILE       => $cookie_jar,  # 发送cookie

        # 响应返回部分
        CURLOPT_RETURNTRANSFER   => true,         # 将响应结果返回，而不是直接输出
        CURLOPT_HEADER           => true,         # 输出响应标头
        CURLOPT_FAILONERROR      => true,         # 状态码大于等于400，将显示错误详情
        CURLOPT_NOBODY           => false,        # 是否输出 BODY 部分
        // CURLOPT_NOPROGRESS    => true,         # 关闭 cURL 的传输进度。
        // CURLOPT_PROGRESSFUNCTION =>
        // CURLOPT_VERBOSE          => true,      # 输出所有的信息写入到STDERR
                                                  # 或在CURLOPT_STDERR中指定的文件
        // CURLOPT_STDERR           => getcwd().'/logs/',
        // CURLOPT_DEBUGFUNCTION    => my_trace,
        // CURLOPT_DEBUGDATA        => my_tracedata,
        // CURLOPT_HTTP200ALIASES   => array(400),# 将非200视为有效的 HTTP标头行
                                                  # libcurl/c/CURLOPT_HTTP200ALIASES.html
        
        CURLOPT_TIMEOUT          => 60,           # 响应超时
        CURLOPT_CONNECTTIMEOUT   => 10,           # 链接超时

        # SSL 证书
        CURLOPT_SSL_VERIFYSTATUS => false,        # 不验证证书状态
        CURLOPT_SSL_VERIFYPEER   => false,        # 禁止验证对等证书
        // CURLOPT_CAPATH        => getcwd().'/cert/',
        // CURLOPT_CAINFO        => getcwd().'/cert/ca.crt',
        // CURLOPT_SSLCERT          => getcwd().'/cert/mycert.pem',
        // CURLOPT_SSLCERTPASSWD    => 'password',
        CURLOPT_SSL_VERIFYHOST   => 0,            # 不检查证书公用名是否存在，是否与主机名匹配
        CURLOPT_SSL_ENABLE_ALPN  => false,        # 禁用用于协商到 http2的ALPN,
        CURLOPT_SSL_ENABLE_NPN   => false,        # 禁用用于协商到 http2的NPN

        # 域名的解析及ip类型
        // CURLOPT_IPRESOLVE     => CURL_IPRESOLVE_V4,
        // CURLOPT_DNS_INTERFACE => "eth0",
        // CURLOPT_DNS_LOCAL_IP4 => "192.168.0.14",
        // CURLOPT_DNS_LOCAL_IP6 => ,
    );
    curl_setopt_array($ch, $options);

    if(!empty($data)){
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_SAFE_UPLOAD, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }
    //ob_start(); //开启浏览器缓存
    $result = curl_exec($ch);
    if(curl_exec($ch) === false){
        $curl_errno = curl_errno($ch);    # 返回最后一次的错误代码
        $curl_error = curl_error($ch);    # 返回当前会话最后一次错误的字符串
        // echo 'Curl error: '. $curl_error . "<br>\r\n";
    }
    curl_close($ch);
    //ob_end_clean();

    # try{}catch{}语句
    // try{
    //     $handles = curl_exec($ch);
    //     curl_close($ch);
    //     return $handles;
    // }
    // catch(Exception $e){
    //     echo 'Caught exception:', $e -> getMessage(), "\n";
    // }

    $res_array = explode("\r\n\r\n", $result, 2);
    if(empty($res_array[1])) $res_array[1] = '';
    $body = @$res_array[1];
    $header_all = $res_array[0];
    // echo $header_all;

    # 如果$headers为空，则连接超时
    // if(empty($res_array[0])) die('<br><br><center><b>连接超时</b></center>');
    $array_headers = http_parse_headers($res_array[0]);
    // $array_headers = array_change_key_case($res_array[0], CASE_LOWER); // 键值转为小写
    // print_r($array_headers);
    if(array_key_exists("0", $array_headers) == false) $array_headers[0] = '';
    $array_status = explode(' ', $array_headers[0]);
    $status = isset($array_status[1]) ? $array_status[1] : '';

    if(array_key_exists("User-Agent", $array_headers)) $ua = $array_headers['User-Agent'];
    
    // $set_cookie = $array_headers['Set-Cookie'];
    // $cookie = $array_headers['Cookie'];
// get cookies
// $cookies = array();
// preg_match_all('/Set-Cookie:(?<cookie>\s{0,}.*)$/im', $res_array[0], $cookies);

// echo "<pre>";
// print_r($cookies['cookie']); // show harvested cookies
// echo "</pre>";
    if(empty($array_headers['Content-Type'])) $array_headers['Content-Type'] = '';

    $array_type = explode(";", @$array_headers['Content-Type']);
    $mime_type = trim(strtolower($array_type[0]));
    $charset = preg_match("/charset=[^\w]?([-\w]+)/i", @$array_headers['Content-Type'], $temp) ? strtolower($temp[1]): "";
    if(empty($charset)){
        $charset = preg_match("/<meta.+?charset=[^\w]?([-\w]+)/i", @$res_array[1], $temp) ? strtolower($temp[1]):"";
    }
    if(empty($array_headers['Content-Type'])){
        $mime_type = '';
        $charset =  '';
    }
    
    # $body = preg_replace('/(?s)<meta http-equiv="Expires"[^>]*>/i', '', $body);
    if(strstr($mime_type, 'text/html') and $charset !== 'utf-8' and !empty($charset)){
        $body = mb_convert_encoding ($body, 'utf-8', $charset);
    }  

    $res_array = array(
        'status'     => $status,
        'mime_type'  => $mime_type,
        'charset'    => $charset,
        'header'     => $header_all,
        'body'       => $body,
    );
    return $res_array;
}

# 获取url内容,返回字符串
function get_url_contents($url, $method, $stringData){
    $options_post = array(
        'http' => array(
            'method' => 'POST',
            'header' => 'Content-type:application/x-www-form-urlencoded;charset=UTF-8',
            'content' => $stringData   # 需要获取的内容
            ),
        "ssl" => array(
            "verify_peer" => false,
            "verify_peer_name" => false,
            )
        );

    $options_get = array(
        'http' => array(
            'method' => 'GET',
            'header' => "Accept-language: en\r\n" .
                        "Cookie: foo=bar\r\n" .  // check function.stream-context-create on php.net
                        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.82 Safari/537.36\r\n"
            ),
        "ssl" => array(
            "verify_peer" => false,
            "verify_peer_name" => false,
            )
        );

    $method = strtoupper(trim($method));
    if($method === 'GET') $options = $options_get;
    else $options = $options_post;
    $context = stream_context_create($options);

    set_error_handler(function($err_severity, $err_msg, $err_file, $err_line, array$err_context){
        throw new ErrorException($err_msg, 0, $err_severity, $err_file, $err_line);
    }, E_WARNING);
    try{
        $resource = file_get_contents($url, false, $context);
    }
    catch(Exception $e){
        $error = $e -> getMessage();
    }
    # restore the previous error handler 还原以前的错误处理程序
    restore_error_handler();

    if(!empty($error)) die("<pre><b>获取数据失败\r\n$error\r\n</b></pre>");
    else return $resource;

}

# UTF8转成HTML实体
function utf2html($str){
    $ret = "";
    $max = strlen($str);
    $last = 0;
    for ($i = 0;$i < $max;$i++){
        $c = $str[$i];
        $c1 = ord($c);
        if ($c1 >> 5 == 6){
            $ret .= substr($str, $last, $i - $last);
            $c1 &= 31;  # remove the 3 bit two bytes prefix
            $c2 = ord($str[++$i]);
            $c2 &= 63;
            $c2 |= (($c1 & 3) << 6);
            $c1 >>= 2;
            $ret .= "&#" . ($c1 * 0x100 + $c2) . ";";
            $last = $i + 1;
        }
        elseif ($c1 >> 4 == 14){
            $ret .= substr($str, $last, $i - $last);
            $c2 = ord($str[++$i]);
            $c3 = ord($str[++$i]);
            $c1 &= 15;
            $c2 &= 63;
            $c3 &= 63;
            $c3 |= (($c2 & 3) << 6);
            $c2 >>= 2;
            $c2 |= (($c1 & 15) << 4);
            $c1 >>= 4;
            $ret .= '&#' . (($c1 * 0x10000) + ($c2 * 0x100) + $c3) . ';';
            $last = $i + 1;
        }
    }
    $str = $ret . substr($str, $last, $i);
    return $str;
}

/**
 * 删除指定的标签和内容
 * @param array  $tags 需要删除的标签数组
 * @param string $str 数据源
 * @param boole  $content 是否删除标签内的内容 默认为false保留内容  true不保留内容
 * @return string
 */
function html_strip_tags($tags,$str,$content=false){
    $html=array();
    foreach ($tags as $tag) {
        if($content){
            $html[]='/(<'.$tag.'.*?>[\s|\S]*?<\/'.$tag.'>)/';
        }else{
            $html[]="/(<(?:\/".$tag."|".$tag.")[^>]*>)/i";
        }
    }
    $data=preg_replace($html, '', $str);
    return $data;
}

# 判断 $html 编码并转为 utf-8。
function html_get_charset($html){
    # 正则加 i 表示不区分大小写
    preg_match("'<meta.*?charset.*?=.*?\>'si", $html, $meta_charset);                 # 提取包含charset的 meta
    if(empty($meta_charset[0])) $meta_charset[0] = '';
    $meta_charset = preg_replace("/\r\n|\r|\n/", '', $meta_charset[0]);               # 删除回车和换行
    $meta_charset = preg_replace ("/\s(?=\s)/", "\\1", trim($meta_charset));          # 删除重复的空格
    $meta_charset = str_replace(array("= ", " =",), array("=", "=",), $meta_charset); # 删除=两侧的空格
    $meta_charset = str_replace(array("'", ' ', '>', '/', "\\",), array( '"', '"', '">', '', '',), $meta_charset);
    $meta_charset = preg_replace ("/\"(?=\")/", "\\1", trim($meta_charset));          # 删除重复的"
    $meta_charset = str_replace('"charset=', ' charset=', $meta_charset);
    // preg_match('~charset=([-a-z0-9_]+)~i', $meta_charset, $temp);
    // preg_match("/<meta.+?charset=[^\w]?([-\w]+)/i", $meta_charset, $temp);
    preg_match("'<meta.*?charset=(.+?)\".*?\>'si", $meta_charset, $temp);
    if(!empty($temp[1])) $charset = trim(str_replace('"', '', strtolower($temp[1])));
    elseif(extension_loaded('mbstring')) $charset = strtolower(mb_detect_encoding($html));
    else $charset = strtolower(chkcode($html));
    if(strstr($charset, 'gb2312')) $charset = 'GBK';
    return $charset;
}
 
# 判断charset
function chkcode($html){
    $code = array(
        'GBK',
        'EUC-CN',
        'BIG5',
        'EUC-TW',
        'CP950',
        'BIG5-HKSCS',
        'UTF-8',
        'GB2312',
        'CP936',
        'BIG5-HKSCS:2001',
        'BIG5-HKSCS:1999',
        'ISO-2022-CN',
        'ISO-2022-CN-EXT',
        'SJIS',
        'JIS',
        'EUC-JP',
        'SHIFT_JIS',
        'eucJP-win',
        'SJIS-win',
        'ISO-2022-JP',
        'CP932',
        'ISO-2022-JP',
        'ISO-2022-JP-2',
        'ISO-2022-JP-1',
        'EUC-KR',
        'CP949',
        'ISO-2022-KR',
        'JOHAB',
    );
     
    foreach($code as $charset){
        if($html == @iconv('UTF-8', "$charset//IGNORE//TRANSLIT", @iconv($charset, 'UTF-8//IGNORE//TRANSLIT', $html))){
            return $charset;
            break;
        }
    }
    return 'UTF-8';
}

function js_rsa(){
    $js = '
    
    <script type="text/javascript" src="./libs/js/jsbn.js"></script>
    <script type="text/javascript" src="./libs/js/prng4.js"></script>
    <script type="text/javascript" src="./libs/js/rng.js"></script>
    <script type="text/javascript" src="./libs/js/rsa.js"></script>
    <script type="text/javascript" src="./libs/js/base64.js"></script>
    <script                        src="./libs/js/jquery-3.0.0.min.js"></script>

    <script type="text/javascript">
        function cmdEncrypt() {
            var rsa = new RSAKey();
            var modulus = "DB1EA572B55F5D9C8ADF092F5DCC3559CFEA8CE8BB54E3A71DA9B1AFBD7D17CF80ADB224FE4EA5379BC782F41C137748D8F1B5A36AD62A127EF5E87EFB25C209A66BCEE9925CE09631BF2271E81123E93438646625080FF04F4F2CF532B077E3E390486DF40E7586F0AE522C873F33170222F46BDB6084F55DE6B7031E55DBE7";
            var exponent = "10001";
            rsa.setPublic(modulus, exponent);

            var url = $("#url").val();
            
            // maxLength为明文块，最大长度 = 密钥长度/8 -11 ，这里的密钥长度为 1024
            // 由于明文块会被随机数填充至密钥长度的原因，maxLength 不宜设置为最大值117 ，但也不建议设置太小
            // 一般设置为 93～109 比较合适
            
            // 加密后的密文长度为128字节，十六进制后为 256字节，一般长度是固定的
            var maxLength = 117;
            var ApachemaxLength = 8177;
            var urllen = url.length;
            if(urllen > ApachemaxLength){ 
                var url = "";
                //return;
                alert("请求长度"+urllen+"超出了限制，该长度被Apache限制为"+ApachemaxLength);
            }

            // var base = new BASE64();
            // var url = base.encode(url);

            // 长度分割
            // let lt = ""
            // let ct = ""
            // lt = url.match(/.{1,96}/g) || "";
            // lt.forEach(function (entry) {
            //     tl = rsa.encrypt(entry);
            //     ct += tl + ",\r\n";
            // });

// 1.获取字符串截取点
const bytes = [];
bytes.push(0);
let byteNo = 0;
let c;
const len = url.length;
let temp = 0;
for (let i = 0; i < len; i++) {
    c = url.charCodeAt(i);
    if(c >= 0x010000 && c <= 0x10ffff) {       //特殊字符，如Ř，Ţ
        byteNo += 4;
    }else if(c >= 0x000800 && c <= 0x00ffff) { //中文以及标点符号
        byteNo += 3;
    }else if(c >= 0x000080 && c <= 0x0007ff) { //特殊字符，如È，Ò
        byteNo += 2;
    }else{                                     //英文以及标点符号
        byteNo += 1;
    }
    //一般设置为 93～109 比较合适
    if(byteNo % 109 >= 106 || byteNo % 109 === 0) {
        if(byteNo - temp >= 106) {
            bytes.push(i);
            temp = byteNo;
        }
    }
}

// 2.截取字符串

let ct = "";
let ctstr = "";
let enc = "";
let str;
for (let i = 0; i < bytes.length - 1; i++) {
    if(i === 0){
        str = url.substring(0, bytes[i + 1] + 1);
    }else{
        str = url.substring(bytes[i] + 1, bytes[i + 1] + 1);
    }
    enc = rsa.encrypt(str);
    ct += enc + ", \r\n";
    ctstr += str;
}
if(ctstr.length < len) {
    str = url.substring(ctstr.length, len);
    enc = rsa.encrypt(str) + ", \r\n";
    ct += enc;
}
//alert(ct);//document.write(ct);

            rsa = ct;
            //var rsa = rsa.encrypt(url);
            $("#url").val(rsa);
        }
    </script>
    ';
    return $js;
}

function js_display_tr(){
    $js = '
    <style type="text/css">
        .display_none { display: none !important; }
        .display_tr { display: table-row !important; }
        .custom_ua{ color: #008b00; }
        .current_ua{ color: #bbb; }
        .no_ua{ color: #ff0000; }
    </style>
    <script type="text/javascript">
        function useragent_change(){
            var ua=document.getElementById("useragent");
            var uac=document.getElementById("useragent_custom");
            var uacTR=document.getElementById("useragent_custom_tr");
        
            if(parseInt(ua.value)==1) uacTR.className="display_tr";
            else uacTR.className="display_none";
        }
    </script>
    ';
    return $js;
}

function js_check_enable(){
    $js = '
    <!--<script type="text/javascript" src="/reader/libs/js/jquery-1.4.4.min.js"></script>-->
    <script type="text/javascript" src="/reader/libs/js/jquery-3.0.0.min.js"></script>
    <script type="text/javascript">
        function randomString(length, chars) {
            chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            var result = "";
            for (var i = length; i > 0; --i) result += chars[Math.floor(Math.random() * chars.length)];
            return result;
        }
        
        var key = randomString(32);

        $(document).ready(function(){
            $.get("/reader/index.php?js=1", {"key":key,}, function(data,textStatus){
                if(textStatus=="success"){ //success
                    // code
                    $(data).appendTo("#msg")
                }
            },
            "html")//type);
        });
    </script>
    ';
    return $js;
}

function html_select_ua(){
    $html = '
<table border=0 cellpadding="0" cellspacing="4">

<tr><td width=100%>
<select name="useragent_select" id="useragent" onchange="useragent_change();" style="width:100%;height:30px;">
    <option value selected>选择浏览器标识 User-Agent</option>
    <optgroup label="自定义浏览器标识">
        <option value="" selected class="current_ua"> [ 正在使用的浏览器标识 User-Agent ] </option>
        <option value="-1"        class="no_ua">      [ 无需浏览器标识 ] </option>
        <option value="1"         class="custom_ua">  [ 自定义浏览器标识 ] --> 在下面的方框中输入浏览器的 User-Agent</option>
    </optgroup>
    <optgroup label="电脑及平板">
        <option value="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.51 Safari/537.36 Edg/99.0.1150.39">Windows 10 / Microsoft Edge 99.0</option>
        <option value="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.82 Safari/537.36">Windows 10 / Google Chrome 99.0</option>
        <option value="Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:98.0) Gecko/20100101 Firefox/98.0">Linux Ubuntu 20 / Firefox 98.0</option>
        <option value="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.3 Safari/605.1.15">Apple macOS Catalina 10.15 / Safari 15.3</option>
    </optgroup>
    <optgroup label="智能手机">
        <option value="Mozilla/5.0 (Linux; Android 12; Pixel 6 Build/SQ1D.220105.007; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/98.0.4758.101 Mobile Safari/537.36">Android 12 / Google Chrome</option>
        <option value="Mozilla/5.0 (Android 12; Mobile; rv:68.0) Gecko/68.0 Firefox/98.0">Android 12 / Mozilla Firefox</option>
        <option value="Mozilla/5.0 (iPhone; CPU iPhone OS 15_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.3 Mobile/15E148 Safari/604.1">Apple iOS 15.3.1 / Safari 15.3</option>
        <option value="Mozilla/5.0 (iPhone; CPU iPhone OS 10_0 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 YaBrowser/17.6.0.1578.10 Mobile/14A346 Safari/E7FBAF">Apple iOS 10.0 / Yandex Browser 17.6</option>
        <option value="Opera/9.80 (Android; Opera Mini/62.4.2254/79.13; U; en) Presto/2.12.423 Version/12.16">Android / Opera Mini 62.4</option>
    </optgroup>
    <optgroup label="不支持JavaScript(crawlers/爬虫)">
        <option value="Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)">Googlebot 2.1</option>
        <option value="Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)">Baiduspider 2.0</option>
        <option value="Wget/1.21.1-dirty (mingw32/linux-gnu; +https://www.gnu.org/software/wget/)">Wget 1.21</option>
        <option value="Apache-HttpClient/UNAVAILABLE (Java/1.8.0_272)">Apache Web Components</option>
        <option value="Lynx/2.8.5rel.1">Any / Lynx 2.8.5rel.1</option>
        <option value="Mozilla/5.0 (iPad; U; CPU OS 3_2 like Mac OS X; en-us) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B334b Safari/531.21.102011-10-16 20:23:10">iPhone OS 3.2 / Safari 4.0.4 (Update 2009/11/12)</option>
        <option value="Opera/9.80 (J2ME/MIDP; Opera Mini/4.2.20464/28.2144; U; en) Presto/2.8.119 Version/11.10">J2ME/MIDP / Opera Mini</option>
    </optgroup>
</select>
</td></tr>

<tr id="useragent_custom_tr" class="display_none"><td width=100% >
    <input type="text" name="useragent_custom" id="useragent_custom" value=""/>
</td></tr>

</table>
';
return $html;
}

function mime2ext($mime){
    $ext2mime = array(
            "dwg"        =>    "application/acad",
            "ez"         =>    "application/andrew-inset",
            "ccad"       =>    "application/clariscad",
            "drw"        =>    "application/drafting",
            "tsp"        =>    "application/dsptype",
            "dxf"        =>    "application/dxf",
            "epub"       =>    "application/epub+zip",
            "gz"         =>    "application/gzip",
            "unv"        =>    "application/i-deas",
            "jar"        =>    "application/java-archive",
            "json"       =>    "application/json",
            "jsonld"     =>    "application/ld+json",
            "hqx"        =>    "application/mac-binhex40",
            "cpt"        =>    "application/mac-compactpro",
            "pot"        =>    "application/mspowerpoint",
            "pps"        =>    "application/mspowerpoint",
            "ppt"        =>    "application/mspowerpoint",
            "ppz"        =>    "application/mspowerpoint",
            "doc"        =>    "application/msword",
            "bin"        =>    "application/octet-stream",
            "class"      =>    "application/octet-stream",
            "dms"        =>    "application/octet-stream",
            "exe"        =>    "application/octet-stream",
            "lha"        =>    "application/octet-stream",
            "lzh"        =>    "application/octet-stream",
            "oda"        =>    "application/oda",
            "ogx"        =>    "application/ogg",
            "pdf"        =>    "application/pdf",
            "ai"         =>    "application/postscript",
            "eps"        =>    "application/postscript",
            "ps"         =>    "application/postscript",
            "prt"        =>    "application/pro_eng",
            "rtf"        =>    "application/rtf",
            "set"        =>    "application/set",
            "stl"        =>    "application/SLA",
            "smi"        =>    "application/smil",
            "smil"       =>    "application/smil",
            "sol"        =>    "application/solids",
            "step"       =>    "application/STEP",
            "stp"        =>    "application/STEP",
            "vda"        =>    "application/vda",
            "azw"        =>    "application/vnd.amazon.ebook",
            "mpkg"       =>    "application/vnd.apple.installer+xml",
            "mif"        =>    "application/vnd.mif",
            "xul"        =>    "application/vnd.mozilla.xul+xml",
            "xlc"        =>    "application/vnd.ms-excel",
            "xll"        =>    "application/vnd.ms-excel",
            "xlm"        =>    "application/vnd.ms-excel",
            "xls"        =>    "application/vnd.ms-excel",
            "xlw"        =>    "application/vnd.ms-excel",
            "eot"        =>    "application/vnd.ms-fontobject",
            "ppt"        =>    "application/vnd.ms-powerpoint",
            "odp"        =>    "application/vnd.oasis.opendocument.presentation",
            "ods"        =>    "application/vnd.oasis.opendocument.spreadsheet",
            "odt"        =>    "application/vnd.oasis.opendocument.text",
            "pptx"       =>    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            "xlsx"       =>    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "docx"       =>    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "rar"        =>    "application/vnd.rar",
            "vsd"        =>    "application/vnd.visio",
            "7z"         =>    "application/x-7z-compressed",
            "abw"        =>    "application/x-abiword",
            "bcpio"      =>    "application/x-bcpio",
            "bz"         =>    "application/x-bzip",
            "bz2"        =>    "application/x-bzip2",
            "vcd"        =>    "application/x-cdlink",
            "pgn"        =>    "application/x-chess-pgn",
            "cpio"       =>    "application/x-cpio",
            "csh"        =>    "application/x-csh",
            "dcr"        =>    "application/x-director",
            "dir"        =>    "application/x-director",
            "dxr"        =>    "application/x-director",
            "dvi"        =>    "application/x-dvi",
            "arc"        =>    "application/x-freearc",
            "pre"        =>    "application/x-freelance",
            "spl"        =>    "application/x-futuresplash",
            "gtar"       =>    "application/x-gtar",
            "gz"         =>    "application/x-gzip",
            "hdf"        =>    "application/x-hdf",
            "xhtml"      =>    "application/xhtml+xml",
            "php"        =>    "application/x-httpd-php",
            "ipx"        =>    "application/x-ipix",
            "ips"        =>    "application/x-ipscript",
            "js"         =>    "application/x-javascript",
            "skd"        =>    "application/x-koan",
            "skm"        =>    "application/x-koan",
            "skp"        =>    "application/x-koan",
            "skt"        =>    "application/x-koan",
            "latex"      =>    "application/x-latex",
            "lsp"        =>    "application/x-lisp",
            "scm"        =>    "application/x-lotusscreencam",
            "cdf"        =>    "application/x-netcdf",
            "nc"         =>    "application/x-netcdf",
            "sh"         =>    "application/x-sh",
            "shar"       =>    "application/x-shar",
            "swf"        =>    "application/x-shockwave-flash",
            "sit"        =>    "application/x-stuffit",
            "sv4cpio"    =>    "application/x-sv4cpio",
            "sv4crc"     =>    "application/x-sv4crc",
            "tar"        =>    "application/x-tar",
            "tcl"        =>    "application/x-tcl",
            "tex"        =>    "application/x-tex",
            "texi"       =>    "application/x-texinfo",
            "texinfo"    =>    "application/x-texinfo",
            "roff"       =>    "application/x-troff",
            "t"          =>    "application/x-troff",
            "tr"         =>    "application/x-troff",
            "man"        =>    "application/x-troff-man",
            "me"         =>    "application/x-troff-me",
            "ms"         =>    "application/x-troff-ms",
            "ustar"      =>    "application/x-ustar",
            "src"        =>    "application/x-wais-source",
            "zip"        =>    "application/zip",
            "aac"        =>    "audio/aac",
            "au"         =>    "audio/basic",
            "snd"        =>    "audio/basic",
            "kar"        =>    "audio/midi",
            "mid"        =>    "audio/midi",
            "midi"       =>    "audio/midiaudio/x-midi",
            "mp2"        =>    "audio/mpeg",
            "mp3"        =>    "audio/mpeg",
            "mpga"       =>    "audio/mpeg",
            "oga"        =>    "audio/ogg",
            "opus"       =>    "audio/opus",
            "tsi"        =>    "audio/TSP-audio",
            "wav"        =>    "audio/wav",
            "weba"       =>    "audio/webm",
            "aif"        =>    "audio/x-aiff",
            "aifc"       =>    "audio/x-aiff",
            "aiff"       =>    "audio/x-aiff",
            "ram"        =>    "audio/x-pn-realaudio",
            "rm"         =>    "audio/x-pn-realaudio",
            "rpm"        =>    "audio/x-pn-realaudio-plugin",
            "ra"         =>    "audio/x-realaudio",
            "wav"        =>    "audio/x-wav",
            "pdb"        =>    "chemical/x-pdb",
            "xyz"        =>    "chemical/x-pdb",
            "otf"        =>    "font/otf",
            "ttf"        =>    "font/ttf",
            "woff"       =>    "font/woff",
            "woff2"      =>    "font/woff2",
            "bmp"        =>    "image/bmp",
            "ras"        =>    "image/cmu-raster",
            "gif"        =>    "image/gif",
            "ief"        =>    "image/ief",
            "jpeg"       =>    "image/jpeg",
            "png"        =>    "image/png",
            "svg"        =>    "image/svg+xml",
            "tif"        =>    "image/tiff",
            "tiff"       =>    "image/tiff",
            "ico"        =>    "image/vnd.microsoft.icon",
            "webp"       =>    "image/webp",
            "pnm"        =>    "image/x-portable-anymap",
            "pbm"        =>    "image/x-portable-bitmap",
            "pgm"        =>    "image/x-portable-graymap",
            "ppm"        =>    "image/x-portable-pixmap",
            "rgb"        =>    "image/x-rgb",
            "xbm"        =>    "image/x-xbitmap",
            "xpm"        =>    "image/x-xpixmap",
            "xwd"        =>    "image/x-xwindowdump",
            "iges"       =>    "model/iges",
            "igs"        =>    "model/iges",
            "mesh"       =>    "model/mesh",
            "msh"        =>    "model/mesh",
            "silo"       =>    "model/mesh",
            "vrml"       =>    "model/vrml",
            "wrl"        =>    "model/vrml",
            "ics"        =>    "text/calendar",
            "css"        =>    "text/css",
            "csv"        =>    "text/csv",
            "htm"        =>    "text/html",
            "html"       =>    "text/html",
            "js"         =>    "text/javascript",
            "mjs"        =>    "text/javascript",
            "asc"        =>    "text/plain",
            "c"          =>    "text/plain",
            "cc"         =>    "text/plain",
            "py"         =>    "text/plain",
            "php"        =>    "text/plain",
            "f"          =>    "text/plain",
            "f90"        =>    "text/plain",
            "h"          =>    "text/plain",
            "hh"         =>    "text/plain",
            "m"          =>    "text/plain",
            "txt"        =>    "text/plain",
            "rtx"        =>    "text/richtext",
            "rtf"        =>    "text/rtf",
            "sgm"        =>    "text/sgml",
            "sgml"       =>    "text/sgml",
            "tsv"        =>    "text/tab-separated-values",
            "xml"        =>    "text/xml",
            "etx"        =>    "text/x-setext",
            "3gp"        =>    "video/3gpp",
            "3g2"        =>    "video/3gpp2",
            "ts"         =>    "video/mp2t",
            "mpeg"       =>    "video/mpeg",
            "mpg"        =>    "video/mpeg",
            "ogv"        =>    "video/ogg",
            "mov"        =>    "video/quicktime",
            "qt"         =>    "video/quicktime",
            "viv"        =>    "video/vnd.vivo",
            "vivo"       =>    "video/vnd.vivo",
            "webm"       =>    "video/webm",
            "fli"        =>    "video/x-fli",
            "avi"        =>    "video/x-msvideo",
            "movie"      =>    "video/x-sgi-movie",
            "mime"       =>    "www/mime",
            "ice"        =>    "x-conference/x-cooltalk",
		);
    $mime = strtolower($mime);
	if(array_search($mime, $ext2mime)) return array_search($mime, $ext2mime);
    else return 'null';
}


function youtube_id($url){
    $url = trim($url);
    parse_str(parse_url($url, PHP_URL_QUERY), $variables);
    return $variables;
}

/**
 * **获取当前页面完整URL地址
 */
function get_url(){
    $sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443'?'https://':'http://';
    $php_self = $_SERVER['PHP_SELF']?$_SERVER['PHP_SELF']:$_SERVER['SCRIPT_NAME'];
    $path_info = isset($_SERVER['PATH_INFO'])?$_SERVER['PATH_INFO']:'';
    $relate_url = isset($_SERVER['REQUEST_URI'])?$_SERVER['REQUEST_URI']:$php_self . (isset($_SERVER['QUERY_STRING'])?'?' . $_SERVER['QUERY_STRING']:$path_info);
    return $sys_protocal . (isset($_SERVER['HTTP_HOST'])?$_SERVER['HTTP_HOST']:'') . $relate_url;
}

function file_search($path, $key){
    // $list = array_diff(scandir($path), array('..','.'));
    $list = scandir($path);
    $out = array();
    foreach($list as $value){
        if($value === '.' || $value === '..') continue;
        if(is_dir($value)) continue;
        // if(strstr($value, '.f248.') or strstr($value, '.f251.')) continue;
        if(strpos($value, $key) !== false) $out[] = $value;
    }
    return $out;
}

function youtube_info($html){
    //preg_match_all("/ytInitialPlayerResponse =(.*?)}}}};/is", $html, $html_array);
    //$json = trim($html_array[1][0]);
    $html = str_replace('>', ">\r\n", $html);
    $html_array = explode("\r\n", $html);
    $json = '';
    foreach($html_array as $line){
        if(strstr($line, 'var ytInitialPlayerResponse')) $json = $line;
    }
    $json_array = explode("}}}};", $json, 2);
    $json_array = explode("ytInitialPlayerResponse =", $json_array[0], 2);
    $json = trim($json_array[1]) . "}}}}";
    $ytb_info = json_decode($json, true);
    
    //['videoDetails']
    $videodetails = $ytb_info['videoDetails'];//['microformat']
    
    $microformat = $ytb_info['microformat']['playerMicroformatRenderer'];
    unset($microformat['embed']);
    unset($microformat['keywords']);
    unset($microformat['shortDescription']);
    unset($microformat['thumbnail']);
    unset($microformat['availableCountries']);
    unset($microformat['description']);
    $microformat['title'] = $videodetails['title'];
    
    $details = array("videoId" => $videodetails['videoId']) + $microformat;
    
    //['streamingData']
    $webm_format = $ytb_info['streamingData']['adaptiveFormats'];
    $mp4_format  = $ytb_info['streamingData']['formats'];
    $mp4 = array();
    foreach ($mp4_format as $key => $value) {
        if($mp4_format[$key]['itag'] === 18) $mp4['f18']=$mp4_format[$key];
        if($mp4_format[$key]['itag'] === 22) $mp4['f22']=$mp4_format[$key];
    }
    $webm = array();
    foreach ($webm_format as $key => $value) {
        if($webm_format[$key]['itag'] === 248) $webm['f248']=$webm_format[$key];
        if($webm_format[$key]['itag'] === 251) $webm['f251']=$webm_format[$key];
    }
    $videoformats = $mp4 + $webm;
    return $details + $videoformats;
}


# 获取网页中超链接的两种方法
function preg_htmllink($html){
    $html = preg_replace('/\s{2,}|\n/i', '', $html); # 过滤掉换行和2个以上的空格
    preg_match_all('/(?:img|a|source|link|script)[^>]*(?:href|src)=[\'"]?([^>\'"\s]*)[\'"]?[^>]*>/i', $html, $out);
    return($out[1]);
}

// if ( ! defined('BASEPATH')) exit('No direct script access allowed不允许直接脚本访问');
function relative_to_absolute_url($host, $path){
	$host = trim($host);
	if(empty($host)) $host = ".";
    $host_parts    = parse_url($host);
    $path_parts    = parse_url($path);
    $absolute_path = '';
    
    if (isset($path_parts['path']) && isset($host_parts['scheme']) && substr($path_parts['path'], 0, 2) === '//' && ! isset($path_parts['scheme'])){
        $path       = $host_parts['scheme'] . ':' . $path;
        $path_parts = parse_url($path);
    }
    
    if (isset($path_parts['host'])){
        return $path;
    }
    
    if (isset($host_parts['scheme'])){
        $absolute_path .= $host_parts['scheme'] . '://';
    }
    
    if (isset($host_parts['user'])){
        if (isset($host_parts['pass'])){
            $absolute_path .= $host_parts['user'] . ':' . $host_parts['pass'] . '@';
        }
        else{
            $absolute_path .= $host_parts['user'] . '@';
        }
    }
    
    if (isset($host_parts['host'])){
        $absolute_path .= $host_parts['host'];
    }
    
    if (isset($host_parts['port'])){
        $absolute_path .= ':' . $host_parts['port'];
    }
    
    if (isset($path_parts['path'])){
        $path_segments = explode('/', $path_parts['path']);
        
        if (isset($host_parts['path'])){
            $host_segments = explode('/', $host_parts['path']);
        }
        else{
            $host_segments = array('', '');
        }
        
        $i = -1;
        while (++$i < count($path_segments)){
            $path_seg  = $path_segments[$i];
            $last_item = end($host_segments);
            
            switch ($path_seg){
                case '.' :
                    if ($i === 0 || empty($last_item)){
                        array_splice($host_segments, -1);
                    }
                    break;
                case '..' :
                    if ($i === 0 && ! empty($last_item)){
                        array_splice($host_segments, -2);
                    }
                    else{
                        array_splice($host_segments, empty($last_item) ? -2 : -1);
                    }
                    break;
                case '' :
                    if ($i === 0){
                        $host_segments = array();
                    }
                    else{
                        $host_segments[] = $path_seg;
                    }
                    break;
                default :
                    if ($i === 0 && ! empty($last_item)){
                        array_splice($host_segments, -1);
                    }
                    
                    $host_segments[] = $path_seg;
                    break;
            }
        }
        
        $absolute_path .= '/' . ltrim(implode('/', $host_segments), '/');
    }
    
    if (isset($path_parts['query'])){
        $absolute_path .= '?' . $path_parts['query'];
    }
    
    if (isset($path_parts['fragment'])){
        $absolute_path .= '#' . $path_parts['fragment'];
    }
    
    return $absolute_path;
}


# Take any type of URL (relative, absolute, with base, from root, etc.)
# and return an absolute URL.
function absoluteURL($modify_url, $current_url){

    if (! preg_match('#^((https?)://(?:([a-z0-9-.]+:[a-z0-9-.]+)@)?([a-z0-9-.]+)(?::([0-9]+))?)(?:/|$)((?:[^?/]*/)*)([^?]*)(?:\?([^\#]*))?(?:\#    .*)?$#i', $current_url, $tmp)){
        # Invalid, show error
        error('invalid_url', htmlentities($current_url));
    }
    # Rename parts to more useful names
    $URL = array(
        'scheme_host'  => $tmp[1],
        'scheme'       => $tmp[2],
        'auth'         => $tmp[3],
        'host'         => strtolower($tmp[4]),
        'domain'       => strtolower(preg_match('#(?:^|\.)([a-z0-9-]+\.(?:[a-z.]{5,6}|[a-z]{2,}))$#', $tmp[4], $domain) ? $domain[1] : $tmp[4]), #     Attempt to split off the subdomain (if any)
        'port'         => $tmp[5],
        'path'         => '/' . $tmp[6],
        'filename'     => $tmp[7],
        'extension'    => pathinfo($tmp[7], PATHINFO_EXTENSION),
        'query'        => isset($tmp[8]) ? $tmp[8] : ''
        );
    $base = '';

    # Check we have something to work with
    if ($modify_url == false){
        return $modify_url;
    }
    # "//domain.com" is valid - add the HTTP protocol if we have this
    if ($modify_url[0] == '/' && isset($modify_url[1]) && $modify_url[1] == '/'){
        $modify_url = $URL['scheme'] . ':' . $modify_url;
    }
    # URIs that start with ? are relative to the page loaded
    if ($modify_url[0] == '?'){
        $modify_url = $URL['href'] . $modify_url;
    }
    # Look for http or https and if necessary, convert relative to absolute
    if (stripos($modify_url, 'http://') !== 0 && stripos($modify_url, 'https://') !== 0){
        # . refers to current directory so do nothing if we find it
        if ($modify_url == '.'){
            $modify_url = '';
        }
        # Check for the first char indicating the URL is relative from root,
        # in which case we just need to add the hostname prefix
        if ($modify_url && $modify_url[0] == '/'){
            $modify_url = $URL['scheme_host'] . $modify_url;
        }else if (isset($base)){
            # Not relative from root, is there a base href specified?
            $modify_url = $base . $modify_url;
        }else{
            # Not relative from root, no base href, must be relative to current directory
            $modify_url = $URL['scheme_host'] . $URL['path'] . $modify_url;
        }
    }
    # URL is absolute. Now attempt to simplify path.
    # Strip ./ (refers to current directory)
    $modify_url = str_replace('/./', '/', $modify_url);
    # Strip double slash #
    if (isset($modify_url[8]) && strpos($modify_url, '//', 8)){
        # $modify_url = preg_replace('#(?<!:)//#', '/', $modify_url);
}
    # Look for ../
    if (strpos($modify_url, '../')){
        # Extract path component only
        $oldPath =
        $path = parse_url($modify_url, PHP_URL_PATH);
        # Convert ../ into "go up a directory"
        while (($tmp = strpos($path, '/../')) !== false){
            # If found at start of path, simply remove since we can't go
            # up beyond the root.
            if ($tmp === 0){
                $path = substr($path, 3);
                continue;
            }
            # It was found later so find the previous /
            $previousDir = strrpos($path, '/', - (strlen($path) - $tmp + 1));
            # And splice that directory out
            $path = substr_replace($path, '', $previousDir, $tmp + 3 - $previousDir);
        }
        # Replace path component with new
        $modify_url = str_replace($oldPath, $path, $modify_url);
    }
    return $modify_url;
}
