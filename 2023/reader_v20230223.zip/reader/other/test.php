<?php
/*
# 删除无意义的空行
$source = preg_replace("/\r/", "\n", $source);
$source = preg_replace("/\s+\n/", "\n", $source);
$source = preg_replace("/\t/","    ",$source);
$source = preg_replace(array("'</head[^>]*?>.*?<'si",), array('</head><',), $source);
echo $source;
*/

$fn = './sites/secretchina/20220517-6733717510.html';

$fp = fopen($fn, 'r'); # "r"只读方式打开，指针指向文件头
$pos = 440;
fseek($fp, $pos, SEEK_CUR);
$title = fgets($fp);
$title = str_replace(array('<title>', '</title>',), '', $title);
if(mb_strlen($title) > 50) $title = mb_substr($title, 0, 30, "UTF8") .' ... ';
echo $title;