<?php
set_time_limit(0);
ignore_user_abort();
ini_set("allow_url_fopen", 1);
include_once 'function.inc.php';

$ytb_url = 'https://rr2---sn-5ualdnlr.googlevideo.com/videoplayback?expire=1674055734&ei=1rvHY4C3HIi1kwb7qrnQDQ&ip=2001%3A470%3A66%3Ade2%3A0%3A0%3A0%3A2&id=o-ADnq7a1StjyBkHWEC4F0p9654KGHA3PcNe_-6KmNStWc&itag=22&source=youtube&requiressl=yes&mh=PF&mm=31%2C26&mn=sn-5ualdnlr%2Csn-q4flrne6&ms=au%2Conr&mv=m&mvi=2&pl=53&initcwndbps=1075000&vprv=1&mime=video%2Fmp4&ns=OWWONqpmpyZLdyy4byz6kCoK&cnr=14&ratebypass=yes&dur=1547.888&lmt=1674012833894629&mt=1674033658&fvip=3&fexp=24007246&c=WEB&txp=7318224&n=kgjvKiwWJNUffXy&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cvprv%2Cmime%2Cns%2Ccnr%2Cratebypass%2Cdur%2Clmt&sig=AOq0QJ8wRQIgNCh2JY23vOerd--cJwxOWpj6bf3zdYTA_g7Jcr-H-lkCIQCZWIm2RVLFpD1y1couRjYzJMw5YHjEAcgXtwL9CAgSdg%3D%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIhAMclb0UcizaqNj0MYYYt7rzTxCPXV6nk4RvGwIP08U4OAiBBHMtQfnpnjJ5u06fJMLDtMxmFYGbpM5dzGW8pRsbPvA%3D%3D';
        

$cookie_jar = __DIR__ . '/tmp/'. md5($url_array['host']) .'.cookie';
if(file_exists($cookie_jar) == false) file_put_contents($cookie_jar, '');

$ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36';
$ytb_html_array = getResponse($ytb_url, $data = [], $cookie_jar, $ua);

$ytb_html = $ytb_html_array['body'];
$header = $ytb_html_array['header'];
$mime   = $ytb_html_array['mime_type'];
$status = $ytb_html_array['status'];
//print_r($header);
file_put_contents('y.mp4', $header);


