<?php

$html = file_get_contents('./cache/1B821A293C20409BA7DEB6F6DA2499AD.bak');
// 删除冗余
$search = array(
    "'<script[^>]*?>.*?</script>'si",     # 去掉javascript
    "'<style[^>]*?>.*?</style>'si",       # 去掉css
/*  "'<meta[/!]*?[^<>]*?>'si",            # 去掉meta */
    '|<meta property=.*?/>|i',            # 去掉 meta property
    "'<link.*?reportloaderror>'si",       # 去掉link链接
    );
$replace = array("", "", "", "", "",);
$html = preg_replace($search, $replace, $html);
$html = preg_replace("'<link.*?>'si", '', $html);

$html = absoluteURL($html);
$html = beautify_html($html);



$input = '/term/1';
$input = absoluteURL($input);
echo $input;






# Take any type of URL (relative, absolute, with base, from root, etc.)
# and return an absolute URL.
function absoluteURL($input) {
	//global $base, $URL;
$URL = 'https://www.soundofhope.org/post/379174';
//$base = 'https://www.soundofhope.org';
	# Check we have something to work with
	if ( $input == false ) {
		return $input;
	}

	# "//domain.com" is valid - add the HTTP protocol if we have this
	if ( $input[0] == '/' && isset($input[1]) && $input[1] == '/' ) {
		$input= $URL['scheme'].':'.$input;
	}

	# URIs that start with ? are relative to the page loaded
	if ($input[0] == '?') {
		$input = $URL['href'].$input;
	}

	# Look for http or https and if necessary, convert relative to absolute
	if ( stripos($input, 'http://') !== 0 && stripos($input, 'https://') !== 0 ) {

		# . refers to current directory so do nothing if we find it
		if ( $input == '.' ) {
			$input = '';
		}

		# Check for the first char indicating the URL is relative from root,
		# in which case we just need to add the hostname prefix
		if ( $input && $input[0] == '/' ) {
			$input = $URL['scheme_host'] . $input;
		} else if ( isset($base) ) {

			# Not relative from root, is there a base href specified?
			$input = $base . $input;

		} else {

			# Not relative from root, no base href, must be relative to current directory
			$input = $URL['scheme_host'] . $URL['path'] . $input;

		}
	}

	# URL is absolute. Now attempt to simplify path.	 
	# Strip ./ (refers to current directory)
	$input = str_replace('/./', '/', $input);

	# Strip double slash #
	if ( isset($input[8]) && strpos($input, '//', 8) ) {
	#	$input = preg_replace('#(?<!:)//#', '/', $input);
	}

	# Look for ../
	if ( strpos($input, '../') ) {

		# Extract path component only
		$oldPath = 
		$path		= parse_url($input, PHP_URL_PATH);

		# Convert ../ into "go up a directory"
		while ( ( $tmp = strpos($path, '/../') ) !== false ) {

			# If found at start of path, simply remove since we can't go
			# up beyond the root.
			if ( $tmp === 0 ) {
				$path = substr($path, 3);
				continue;
			}

			# It was found later so find the previous /
			$previousDir = strrpos($path, '/', - ( strlen($path) - $tmp + 1 ) );

			# And splice that directory out
			$path = substr_replace($path, '', $previousDir, $tmp+3-$previousDir);

		}

		# Replace path component with new
		$input = str_replace($oldPath, $path, $input);

	}

	return $input;

}










# HTML 格式化
function beautify_html($html){
    if(function_exists('tidy_parse_string')){
    $tidy_config = array(
        'clean' => false,
        'indent' => true,
        'indent-spaces' => 4,
        'output-xhtml' => false,
        'show-body-only' => false,
        'wrap' => 0
        );
        $html = tidy_parse_string($html, $tidy_config, 'utf8');
        $html -> cleanRepair();
    }
    else{
        require_once 'beautify-html.php';
        $beautify_config = array(
            'indent_inner_html' => false,
            'indent_char' => " ",
            'indent_size' => 2,
            'wrap_line_length' => 32786,
            'unformatted' => ['code', 'pre'],
            'preserve_newlines' => false,
            'max_preserve_newlines' => 32786,
            'indent_scripts'    => 'normal', // keep|separate|normal
            );
        $beautify = new Beautify_Html($beautify_config);
        $html = $beautify->beautify($html);
    }
    return $html;
}

