<?php

namespace Masterminds\HTML5;

/**
 * The base exception for the HTML5 project.
 */
class Exception extends \Exception
{
}
