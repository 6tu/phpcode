
#!/usr/bin/env bash

time=`date +%Y%m%d%H%M%S`

USER_NAME=$(getent passwd `who` | head -n 1 | cut -d : -f 1)
user=$USER_NAME
group=$USER_NAME

rootDir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
mv ./sites/youtube ./

# nohup zip -q -r -0 sites_${time}.zip sites   &
# nohup zip -r -0 cache_${time}.zip cache      &
# nohup zip -r -0 youtube_${time}.zip youtube  &

# mv youtube sites

