<?php

$html = file_get_contents('./wxarticle/cache/20230219-2831768423_src.txt');

preg_match("'\"og:title\"(.*)/>'iUs", $html,$content);
$msg_title = trim(trim($content[1]), ' content="');

preg_match("'\"og:url\"(.*)/>'iUs", $html,$content);
$link = trim(trim($content[1]), ' content="');

preg_match("'function htmlDecode(.+)<\/script>'iUs", $html, $var);
$var = "<script type=\"text/javascript\">\r\n". $var[0];
$var = str_replace('// var', '// var//', $var);
$array_var = articleBasicInfo($var);
$info = print_r($array_var, 1);
echo '<pre>'. $info .'</pre>';

// 删除冗余
$search = array(
    "'<script[^>]*?>.*?</script>'si",     # 去掉javascript
    "'<style[^>]*?>.*?</style>'si",       # 去掉css
/*  "'<meta[/!]*?[^<>]*?>'si",            # 去掉meta */
    '|<meta property=.*?/>|i',            # 去掉 meta property
    "'<link.*?reportloaderror>'si",       # 去掉link链接
    );
$replace = array("", "", "", "", "",);
$html = preg_replace($search, $replace, $html);

$html = str_replace(">",">\r\n", $html);
$html = str_replace('style="visibility: hidden;"',"", $html);

$html = preg_replace('%<body[^>]*?>%i', '<body>', $html);
$html = preg_replace('|<p.*?>|i', '<p>', $html);
$html = preg_replace('|<br .*?>|i', '<br>', $html);
$html = preg_replace('|<span .*?>|i', '<span>', $html);
$html = preg_replace('|style=".*?width:|i', 'style="width:', $html);

for ($i=1; $i<=50; $i++){
    $html = str_replace("\t",  "    ", $html);
    $html = str_replace("  ",  " ",    $html);
    $html = str_replace(" <",  "<",    $html);
    $html = str_replace("\r",  "",     $html);
    $html = str_replace(" \n", "\n",   $html);
    $html = str_replace("\n",  "",     $html);
}

$array_html = explode('</head>', $html);
preg_match("'<title>(.*)</title>'iUs", $array_html[0], $title);
$title = $title?$title[1]:'';
if(empty(trim($title))) $array_html[0] = preg_replace('%<title>[^>]*?</title>%i', "<title>$msg_title</title>", $array_html[0]);

preg_match("'id=\"js_content\"(.*)<\/div>'iUs", $html, $content);
$body = '<div '. $content[0];
$html = $array_html[0] .'</head><body><div id="js_article" style="width: 800px"><h2>'. $msg_title .'</h2>'. $body .'</div></body></html>';

$html = beautify_html($html);
file_put_contents('4.html', $html);








# HTML 格式化
function beautify_html($html){
    if(function_exists('tidy_parse_string')){
    $tidy_config = array(
        'clean' => false,
        'indent' => true,
        'indent-spaces' => 4,
        'output-xhtml' => false,
        'show-body-only' => false,
        'wrap' => 0
        );
        $html = tidy_parse_string($html, $tidy_config, 'utf8');
        $html -> cleanRepair();
    }
    else{
        require_once 'beautify-html.php';
        $beautify_config = array(
            'indent_inner_html' => false,
            'indent_char' => " ",
            'indent_size' => 2,
            'wrap_line_length' => 32786,
            'unformatted' => ['code', 'pre'],
            'preserve_newlines' => false,
            'max_preserve_newlines' => 32786,
            'indent_scripts'    => 'normal', // keep|separate|normal
            );
        $beautify = new Beautify_Html($beautify_config);
        $html = $beautify->beautify($html);
    }
    return $html;
}

/**
 * 获取文章的基本信息
 * @author bignerd
 * @since  2016-08-16T17:16:32+0800
 * @param  $content 文章详情源码
 * @return $basicInfo
 */
function articleBasicInfo($content){
    $basicInfo = [];
    // 待获取item
    $item = [
        'appuin'        => 'biz',                // 公众号id
        'source_appid'  => 'appid',              // 公众号appid, window.source_appid
        'nickname'      => 'nickname',           // 公众号名称
        'user_name'     => 'user_name',          // 微信号
        'author'        => 'author',             // 作者
        'ct'            => 'date',               // 发布时间
        'create_time'   => 'create_time',        // 发布时间
        'provinceName'  => 'ip_wording',         // 发布地址, window.ip_wording
        'msg_title'     => 'title',              // 标题
        'msg_link'      => 'content_url',        // 文章链接
    ];
    foreach($item as $k => $v){
        $pattern = '/var ' . $k . '(.*?)";/s';
        if($k == 'create_time')  $pattern = '/var ' . $k . '(.*?)1;/s';
        if($k == 'msg_title')    $pattern = '/var ' . $k . '(.*?)\.html\(false\);/s';
        if($k == 'source_appid') $pattern = '/' . $k . '(.*?);/s';
        if($k == 'provinceName') $pattern = '/' . $k . '(.*?),/s';

        preg_match_all($pattern, $content, $matches);
        if(array_key_exists(1, $matches) && !empty($matches[1][0])){
            $matches[1][0] = htmlTransform(trim($matches[1][0]));
            $matches[1][0] = str_replace("'", '"', $matches[1][0]);
            $array = explode('"', $matches[1][0]);
            if($v=='title') $array[1] = trim($matches[1][0], "= '\"");
            $basicInfo[$v] = trim($array[1]);
        }else{
            $basicInfo[$v] = '';
        }
    }
    return $basicInfo;
}

/**
 * 特殊字符转换
 * @author bignerd
 * @since  2016-08-16T17:30:52+0800
 * @param  $string
 * @return $string
 */
function htmlTransform($string){
    $string = str_replace('&quot;','"',$string);
    $string = str_replace('&amp;','&',$string);
    $string = str_replace('amp;','',$string);
    $string = str_replace('&lt;','<',$string);
    $string = str_replace('&gt;','>',$string);
    $string = str_replace('&nbsp;',' ',$string);
    $string = str_replace("\\", '',$string);
    return $string;
}


