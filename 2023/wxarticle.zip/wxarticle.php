<?php

/*
 * composer require mihaeu/html-formatter:*

 * https://github.com/bigbignerd/WxCrawler
 * https://github.com/songluyi/crawl_wechat
 * https://packagist.org/packages/liaosp/tool
 * https://github.com/leekachung/WxCrawler
**/


// $html_fn = date('Ymd') .'-'. str_pad(crc32($url), 10, '0') .'.html';
// $img_fn = $dir.'/'.date('Ymd') .'-'. substr(md5($image), 8, 16);

/*
$html = file_get_contents('./wxarticle/cache/20230219-2831768423_src.txt');
preg_match("'function htmlDecode(.+)<\/script>'iUs", $html, $var);
// file_put_contents('./var.js', "<script type=\"text/javascript\">\r\n". $var[0]);
// $var = file_get_contents('./var.js');
$var = str_replace('// var', '// var//', $var);
$info = articleBasicInfo($var);
print_r($info);
*/


error_reporting(E_ALL&~E_NOTICE);

if(empty($_GET['wxarticle']) and !strstr($_SERVER['HTTP_USER_AGENT'], 'Wget')) die(form_html());

$wxurl = trim($_GET['wxarticle']);

// $wxurl = 'https://mp.weixin.qq.com/s?__biz=Mzg2NjU1NDAyMw==&mid=2247511293&idx=3&sn=91290ec7c91ec60d26de61978ab7afdb&chksm=ce4bf535f93c7c23052954644cfe21db42e531616b98eac03b2e8dbee20a94bda598518ce981&exptype=unsubscribed_card_recommend_article_u2i_mainprocess_coarse_sort_tlfeeds&scene=169&subscene=200&sessionid=1676724504&clicktime=1687373&enterid=1687373&ascene=56&fasttmpl_type=0&fasttmpl_fullversion=6555751-zh_CN-zip&fasttmpl_flag=0&realreporttime=1676724618545&devicetype=android-29&version=28002036&nettype=3gnet&abtest_cookie=AAACAA%3D%3D&lang=zh_CN&session_us=gh_a55162aceb95&countrycode=CN&exportkey=n_ChQIAhIQM8njrtmr5F7RFfOAEy1Y9xLrAQIE97dBBAEAAAAAAN1nBtLR%2F5IAAAAOpnltbLcz9gKNyK89dVj02yIqphRNnQ8tYweiXaSyQ114HdEyJOSgkQmac1vw%2BX5n0w50KykTs5gVNOKObHzIwCqoTniPopU1Lzoir8GSs285hY0QEuGERlHmlbKEcBb6h6WIHugR%2BWWs0SnRpA4uyI2HfsOp9YB09AVEJYD8L%2BvkDLsqTVFWH0L8zOrZxbnlxm1QtQbR1Yc2cq3NmK2URZNe0YcDckHIUMndL3STLmUyDniI2GTfkJC0QVMiTTu4HFEmKRS3b0yrjzoQqaPqk51und8%3D&pass_ticket=8BcmRJImdYdWA32A4C%2FcaFqZvOAoaLmSNHfH5mHvKOBcGqz1rsKAzffPHKfU%2BpeFuP%2FZxpZl630dIHhCePDP6w%3D%3D&wx_header=3';

$fn = date('Ymd') .'-'. str_pad(crc32($wxurl), 10, '0');
$article_dir = './wxarticle';
$img_dir = $article_dir .'/img';
$html_fn = $article_dir .'/'. $fn .'.html';
$src_fn  = $article_dir .'/cache/'. $fn .'_src.txt';

if(file_exists($html_fn)){
    $html = file_get_contents($html_fn);
    preg_match("'<title>(.*)</title>'iUs", $html, $title);
    $title = $title?$title[1]:'';
    echo "<body><center><br><br>\r\n" . form_html() ."<br><br>\r\n" .
         "<b>已经存在的文件</b> <a href=\"". $html_fn ."\">". $html_fn ."</a><br><br>\r\n" .
         "<b>源文件</b> <a href=\"". $wxurl ."\">". $title ."</a><br><br>\r\n";
    exit;
}









$html = file_get_contents($wxurl);
file_put_contents($src_fn, $html);

/*
// 原创 清雨 养花种菜记 2023-01-24 23:44 发表于山东
<meta property="og:title" content="“亲戚三不走，邻居两不交”，老祖宗的话，听了准受益！" />
var msg_title = '“亲戚三不走，邻居两不交”，老祖宗的话，听了准受益！'.html(false);

// 时间
var create_time = "1674575068" * 1; // 发布时间，unix时间戳
var ct = "1674575068";

window.ip_wording = {
  countryName: '中国',
  countryId: '156',
  provinceName: '山东',
  provinceId: '',
  cityName: '',
  cityId: ''
};
*/

// 标题
preg_match('/<title>(.*?)<\/title>/',$html,$title);
$title = $title?$title[1]:'';
if(empty(trim($title))){
    preg_match_all('/<meta property="og:title" content="[^>]*?"/', $html, $title);
    preg_match("'content=\"(.+)\"'s", $title[0][0], $arr);
    if($arr) $title = $arr["1"];
    else $title = '';
}
$html = preg_replace('%<title>[^>]*?</title>%i', "<title>$title</title>", $html);

// 发布时间
preg_match_all('/create_time[^>]*?;/', $html, $time);
preg_match("'\"(.+)\"'s", $time[0][0], $arr);
if($arr) $ct = date("Y-m-d H:i:s", $arr["1"]);
else $ct = '';
$html = preg_replace('%<em id="publish_time"[^>]*?>.*?</em>%i', "<em id=\"publish_time\">$ct</em>", $html);

// IP 地址
preg_match_all('/provinceName: [^>]*?,/', $html, $ip_wording);
preg_match("'\'(.+)\''s", $ip_wording[0][0], $arr);
if($arr) $ip_wording = $arr["1"];
else $ip_wording = '';
$html = preg_replace('%<em id="js_ip_wording_wrp"[^>]*?>.*?</em>%i', "<em id=\"js_ip_wording_wrp\">发表于<span>$ip_wording</span></em>", $html);

// 公众号信息
preg_match("'<span class=\"rich_media_meta rich_media_meta_nickname(.+)<em id=\"publish_time's", $html, $arr);
$html = str_replace($arr[0], "<em id=\"publish_time", $html);

preg_match("'<div class=\"profile_inner\">(.+)<span class=\"profile_arrow_wrp\"'s", $arr[0], $info);
$info[1] = str_replace(array('<p class="profile_meta">', '</p>'), " ", $info[1]);
$info[1] = str_replace('</label>', '：</label>', $info[1]);
$info[1] = str_replace('<label class="profile_meta_label">', '<label class="profile_meta_label">|| ', $info[1]);
$info = "<div class=\"profile_inner\">" .$info[1];

$html = str_replace('<div class="article-tag-card__title">', $info.'<div class="article-tag-card__title">', $html);


// 内容主体
/*

$array_html = explode('<div class="wx_network_msg_wrp"', $html);
$html = $array_html[0] . '</body></html>';

// <div id="js_article" style="position:relative;" class="rich_media">
# preg_match("'id=\"js_content\"(.*)<script'iUs", $html,$content);
# preg_match("'id=\"js_article\"(.+)<div class=\"wx_network_msg_wrp\"'iUs", $html,$content);
# $html = '<div id="js_article"' .$content[1];
# print_r($html);
*/

$array_header = explode('</head>', $html);
$header = $array_header[0] ."</head>\r\n\r\n";

preg_match("'<h1 (.*)<script'iUs", $html, $content);
$html = $header .'<body><h1 '. $content[1] ."</body></html>";

// 删除冗余
$search = array("'<script[^>]*?>.*?</script>'si",     # 去掉javascript
                "'<style[^>]*?>.*?</style>'si",       # 去掉css
/*                "'<meta[/!]*?[^<>]*?>'si",            # 去掉meta */
                );
$replace = array("", "", "",);
$html = preg_replace($search, $replace, $html);
$html = strip_html_tags(array('link'), $html);
// $html = preg_replace('|<link.*?reportloaderror>|i', '', $html);
//$html = str_replace("<p data","\n<p data", $html);
$html = str_replace(">",">\n", $html);
$html = preg_replace('%<body[^>]*?>%i', '<body>', $html);
$html = preg_replace('|<p .*?>|i', '<p>', $html);
$html = preg_replace('|<br .*?>|i', '<br>', $html);
$html = preg_replace('|<span .*?>|i', '<span>', $html);
$html = preg_replace('|<div[^>]*?>|i', '<div>', $html);
$html = preg_replace('|style=".*?width:|i', 'style="width:', $html);

// 格式化
$html = str_replace("<body>", '<body><div "js_article">', $html);

require __DIR__.'/vendor/autoload.php';
$html = Mihaeu\HtmlFormatter::format($html);

for ($i=1; $i<=50; $i++){
    $html = preg_replace("/\t/","    ", $html);
    $html = preg_replace("/\r/","", $html);
    //$html = str_replace("  "," ", $html);
    $html = str_replace(" \n","\n", $html);
    $html = preg_replace("/\n\n/","\n", $html);
}


// 图片
preg_match_all('/<img.*?data-src=[\'|\"](.*?(?:[\.gif|\.jpg|\.png|\.jpeg|\.?]))[\'|\"].*?[\/]?>/', $html, $images);

// 储存原地址和下载后地址
$old = array();
$new = array();
// 去除重复图片地址
$images = array_unique($images[1]);
if($images){
    foreach($images as $v){
        // echo $v . "<br>\r\n";
        $filename = put_file_img($img_dir, $v);
        if($filename){
            // 图片保存成功 替换地址
            $old[] = $v;
            $new[] = str_ireplace($article_dir, './', $filename);
        }else{
            // 失败记录日志
            // put_error_log($dirurl,$wximgerr.$v);
        }
    }
    $old[] = 'data-src';
    $new[] = 'src';
    $html = str_replace($old,$new,$html);
}

$html = str_replace("</body>", "</div>\r\n<hr><a href=\"". $wxurl ."\">". $title ."</a><br><br>\r\n</body>", $html);

echo "<body><center><br><br>\r\n" . form_html() ."<br><br>\r\n" .
     "<b>文章保存于 </b> <a href=\"". $html_fn ."\">". $html_fn ."</a><br><br>\r\n" .
     "<b>源文件</b> <a href=\"". $wxurl ."\">". $title ."</a><br><br>\r\n";

file_put_contents($html_fn, $html);





function form_html(){
    $time = date("Y-n-j", time());
    $fn = 'https://mp.weixin.qq.com/s?__biz';
    $html = "<body><br><center>\r\n";
    $html .= '<form action="' . $_SERVER['PHP_SELF'] . '" method="GET" />' . "\r\n";
    $html .= "  <b>输入微信文章网址 </b><br><br>\r\n";
    $html .= '  <input type="text" name="wxarticle" size=150 value="'.$fn.'" style="width:80%; height:60px" />'."<br><br>\r\n";
    $html .= '  <input type="submit" value="提 交" style="width:40%; height:60px; font-size:24px;" />'."\r\n";
    $html .= "</form>\r\n</center></body>";
    echo $html;
}

function put_file_img($dir,$image=''){
    // 判断图片的保存类型 截取后四位地址
    $exts = array('jpeg','png','jpg');
    $filename = $dir.'/'.uniqid().time().rand(10000,99999);
    $filename = $dir.'/'.date('Ymd') .'-'. substr(md5($image), 8, 16);
    // $ext = substr($image,-5);
    // $ext = explode('"',$ext); # 原句是 =
    $array_images = explode('"', $image);
    $ext = $array_images[2];
    if(in_array($ext, $exts) !== false){
        $filename .= '.'.$ext;
    }else{
        $filename .= '.gif';
    }
    $souce = file_get_contents($image);
    if(file_put_contents($filename,$souce)){
        return $filename;
    }else{
        return false;
    }
}

function put_error_log($dir,$data){
    file_put_contents($dir.'/error.log',date('Y-m-d H:i:s',time()).$data.PHP_EOL,FILE_APPEND);
}

function strip_html_tags($tags,$str){
    $html=array();
    foreach ($tags as $tag) {
        $html[]='/<'.$tag.'.*?>[\s|\S]*?<\/'.$tag.'>/';
        $html[]='/<'.$tag.'.*?>/';
    }
    $data=preg_replace($html,'',$str);
    return $data;
}

# HTML 格式化
function beautify_html($html){
    if(function_exists('tidy_parse_string')){
    $tidy_config = array(
        'clean' => false,
        'indent' => true,
        'indent-spaces' => 4,
        'output-xhtml' => false,
        'show-body-only' => false,
        'wrap' => 0
        );
        $html = tidy_parse_string($html, $tidy_config, 'utf8');
        $html -> cleanRepair();
    }
    else{
        require_once 'beautify-html.php';
        $beautify_config = array(
            'indent_inner_html' => false,
            'indent_char' => " ",
            'indent_size' => 2,
            'wrap_line_length' => 32786,
            'unformatted' => ['code', 'pre'],
            'preserve_newlines' => false,
            'max_preserve_newlines' => 32786,
            'indent_scripts'	=> 'normal', // keep|separate|normal
            );
        $beautify = new Beautify_Html($beautify_config);
        $html = $beautify->beautify($html);
    }
    return $html;
}


/**
 * 获取文章的基本信息
 * @author bignerd
 * @since  2016-08-16T17:16:32+0800
 * @param  $content 文章详情源码
 * @return $basicInfo
 */
function articleBasicInfo($content){
    $basicInfo = [];
    // 待获取item
    $item = [
        'appuin'        => 'biz',                // 公众号id
        'source_appid'  => 'appid',              // 公众号appid, window.source_appid
        'nickname'      => 'nickname',           // 公众号名称
        'user_name'     => 'user_name',          // 微信号
        'author'        => 'author',             // 作者
        'ct'            => 'date',               // 发布时间
        'create_time'   => 'create_time',        // 发布时间
        'provinceName'  => 'ip_wording',         // 发布地址, window.ip_wording
        'msg_title'     => 'title',              // 标题
        'msg_link'      => 'content_url',        // 文章链接
    ];
    foreach($item as $k => $v){
        $pattern = '/var ' . $k . '(.*?)";/s';
        if($k == 'create_time')  $pattern = '/var ' . $k . '(.*?)1;/s';
        if($k == 'msg_title')    $pattern = '/var ' . $k . '(.*?)\.html\(false\);/s';
        if($k == 'source_appid') $pattern = '/' . $k . '(.*?);/s';
        if($k == 'provinceName') $pattern = '/' . $k . '(.*?),/s';

        preg_match_all($pattern, $content, $matches);
        if(array_key_exists(1, $matches) && !empty($matches[1][0])){
            $matches[1][0] = htmlTransform(trim($matches[1][0]));
            $matches[1][0] = str_replace("'", '"', $matches[1][0]);
            $array = explode('"', $matches[1][0]);
            if($v=='title') $array[1] = trim($matches[1][0], "= '\"");
            $basicInfo[$v] = trim($array[1]);
        }else{
            $basicInfo[$v] = '';
        }
    }
    return $basicInfo;
}

/**
 * 特殊字符转换
 * @author bignerd
 * @since  2016-08-16T17:30:52+0800
 * @param  $string
 * @return $string
 */
function htmlTransform($string){
    $string = str_replace('&quot;','"',$string);
    $string = str_replace('&amp;','&',$string);
    $string = str_replace('amp;','',$string);
    $string = str_replace('&lt;','<',$string);
    $string = str_replace('&gt;','>',$string);
    $string = str_replace('&nbsp;',' ',$string);
    $string = str_replace("\\", '',$string);
    return $string;
}


