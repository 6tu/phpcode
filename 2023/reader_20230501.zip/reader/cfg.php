<?php

$cip = $_SERVER["REMOTE_ADDR"];
$cip_key = str_pad(crc32($cip), 10, '0'); # CRC32输出长度: 8-9-10位
$username = 'user_'.$cip_key;
$passwd = rand_char($n=8);
$md5pwd = md5($passwd);
$usercfg = $cip_key.'.php';

$curr_file = '';
$curr_dir = dirname($curr_file);

//$session_data['expire'] = time()+$expire; 

$userdata = array(
    "ip" => $cip,
    "user" => $username,
    "passwd" => $passwd,
    "md5pwd" => $md5pwd,
	"url" => $url,
	"cache" => $cache,
    "curr_file" => $curr_file,
    "curr_dir" => $curr_dir,
	"curr_time" => $curr_time,
	"session_expire" => $session_expire
);





if(file_exists($usercfg)){

}else{
    file_put_contents($usercfg, $userdata);
}















/**
 * *获取随机字串
 * 
 * @参数 $n=4 字串
 */
function rand_char($n=4) { 
    $rand = '';
    for($i = 0;$i < $n;$i++ ){
        $base = 62;
        $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $rand .= $chars[mt_rand(1, $base) - 1];
    }
    return $rand;
}
