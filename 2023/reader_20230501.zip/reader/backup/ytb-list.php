<?php
# 获取备份服务器文件表
$url='http://us2.liuyun.org/temp/ytb-list.php';
$ytb_old_act  = curl_put_contents($url);
$url = 'http://us2.liuyun.org/temp/ytb-list_old.txt';
$ytb_old_list = curl_put_contents($url);
file_put_contents('ytb-list_old.txt', $ytb_old_list);
$array_old = json_decode($ytb_old_list);
echo $ytb_old_act . "<br>\r\n";
if($ytb_old_act != 'done') die(获取备份文件列表失败);

# 当前文件列表
$list = scandir('./sites/youtube');
// file_put_contents('ytb-list.txt', json_encode(print_r($list, true)));

foreach($array_old as $value){
    $list = array_merge(array_diff($list, array($value))); # 旧数组中的元素存在新数组中的
}
echo "以下文件需要备份<pre>\r\n".print_r($list,true);

# 增量文件用wget的下载

function curl_put_contents($url){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}
