<?php
$c = file_get_contents('reader_list.txt');
$array = explode("\r\n", $c);

foreach($array as $v){
    if(strpos($v, '_html.html') !== false){
        $new = str_replace('_html.html', '.html', $v);
        echo "mv $v $new\r\n";
    }

    if(strpos($v, '_no.html') !== false){
        $new = str_replace('_no.html', '.html', $v);
        echo "mv $v $new\r\n";
    }

    if(strpos($v, '.null') !== false){
        $new = str_replace('.null', '.html', $v);
        echo "mv $v $new\r\n";
    }
}

