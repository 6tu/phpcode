<?php

# 指定工作目录与 sites 和 cache 同文件夹

# 7zip 压缩成 7z 格式（-t7z）会特别消耗CPU，容易被 kill 
# 使用最快压缩（-mx1）即1级压缩率，能提高速度，对视频设置为 -mx0
# 文件最好存在 当前目录，避免7z 权限不足。
# 文件名不超过255个字符

date_default_timezone_set('Asia/Hong_Kong');
$area = array('tencentcloud_shanghai', 'AdvinServers_OVH_cananda');  # 需要指定商家和地域
$fn_bacup = $area[1] .'_reader_utc8_'. date("YmdH") .'.zip';

# 指定工作目录

chdir('/home/liuyunor/oio.pw'); # chdir(dirname(__DIR__)); 

$sites_ytb  = './sites/youtube';
$backup_path = './backup/'; #  __DIR__ .'/'

$splitline = "\r\n<br>========================<br>\r\n";


echo "\r\n当前工作目录 ". getcwd() ."<br>\r\n";
echo "\r\n建立备份的文件名 ". $fn_bacup ."<br>\r\n";
echo "\r\n当前系统是 ". PHP_OS ."<br>\r\n\r\n";

if(strtolower(substr(PHP_OS, 0, 3)) == 'win') $bin_7zip = "./libs/bin/7zz.exe a -mx1 -r -bt  ";
else $bin_7zip = "./libs/bin/7zz a -mx1 -r -bt  ";

$zip_sites = $bin_7zip . $backup_path.$fn_bacup ." ./sites ./cache  '-xr!youtube/' '-xr!index.html' '-xr!index.php'";
$zip_ytb =   $bin_7zip . $backup_path.'ytb_'.$fn_bacup ."  ". $sites_ytb;

echo $zip_sites ."\r\n". $zip_ytb  ."\r\n". $splitline;

$time_start = time();
if(file_exists($backup_path.$fn_bacup)) @unlink($backup_path.$fn_bacup);
exec($zip_sites, $cmd_sites_info);
echo "<pre>". join("\r\n", $cmd_sites_info) ."</pre>$splitline";
$time_end = time();
$diff = $time_end - $time_start;
echo "\r\n耗时 $diff 秒\r\n";



sleep(3);
$time_start = time();
if(file_exists($sites_ytb)){
    if(file_exists($backup_path.'ytb_'.$fn_bacup)) @unlink($backup_path.'ytb_'.$fn_bacup);
    exec($zip_ytb, $cmd_ytb_info);
    echo "<pre>". join("\r\n", $cmd_ytb_info) ."</pre>$splitline";
    $time_end= time();
    $diff = $time_end - $time_start;
    echo "\r\n耗时 $diff 秒\r\n";
}else echo "没找到 $sites_ytb 目录<br>\r\n";


sleep(3);
$mv = 'mv '. getcwd() .'/backup/*.zip  '.  __DIR__ ."/";
echo $mv ."\r\n\r\n";

// exec("mv ./backup/*.zip  ". __DIR__."/");    join()

