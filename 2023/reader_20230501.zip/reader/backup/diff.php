<?php

# 适用于增量内容比较
# 

$old = file_get_contents('./log/reader_list_utc8_2023032211.txt');
$new = file_get_contents('./log/reader_list_utc8_2023032310.txt');
$old = str_replace("\r", "", $old);
$new = str_replace("\r", "", $new);
$old_array = explode("\n", $old);
$new_array = explode("\n", $new);

# 自身取重复
$old_array = array_unique($old_array);
$new_array = array_unique($new_array);

$diff_array_old = array_merge(array_diff($old_array, $new_array)); # 数组1在数组2中没有的元素
$diff_array_new = array_merge(array_diff($new_array, $old_array)); # 数组1在数组2中没有的元素
$same_array = array_intersect($old_array, $new_array); # 返回一个交集数组


$lost_old = join("\r\n", $diff_array_old);
echo "\r\nold 中特有的内容，即为丢失的内容 \r\n $lost_old \r\n";

$add_new = join("\r\n", $diff_array_new);
$add_new = "\r\nnew 中特有的内容，即为新增的内容 \r\n $add_new \r\n";
echo $add_new;
file_put_contents('addfile.txt', $add_new);

echo "\r\n两者共有的内容 \r\n";
//print_r($same_array);
