这种安装的不可用 composer require fivefilters/readability.php

https://www.fivefilters.org/2021/readability/

git clone https://github.com/fivefilters/readability.php.git
cd readability.php
composer update


https://htmlcolorcodes.com/zh/yanse-biao/

