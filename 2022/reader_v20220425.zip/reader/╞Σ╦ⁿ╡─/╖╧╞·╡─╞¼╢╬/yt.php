<?php
echo file_search($path='sites/youtube/', $key='QPuaFQcN2ug');
function file_search($path, $key){
    //$list = array_diff(scandir($path), array('..', '.'));
	$list = scandir($path);
	foreach($list as $value){
	    if($value === '.' || $value === '..') continue;
		if(is_dir($value)) continue;
		if(strstr($value, $key)) return $value;
	}
}

exit;














$url = 'https://www.youtube.com/watch?v=DfRFahKElh8';





$cmd_dl = 'yt-dlp --no-check-certificate --id https://www.youtube.com/watch?v=DfRFahKElh8 --ffmpeg-location --merge-output-format';
exec($cmd_dl, $out_dl_array, $ret);
// $key = shell_exec($cmd_dl);

exit;
    $bin = 'yt-dlp';  # youtube-dl
    //$bin = '/home/reader/libs/bin/yt-dlp ';
    $para = '--no-check-certificate '; #--write-info-json 
    $name = '-o "%(upload_date)s-%(id)s.webm" ';
    //$name = '-o "%(id)s.mp4" ';
    $cmd_dl = $bin .' '. $para . $name . $url . ' --merge-output-format webm --ffmpeg-location /home/reader/ffmpeg '
    
    
    ;
    echo $cmd_dl;
    exec($cmd_dl, $out_dl_array, $ret);
    
    
    
    
//yt-dlp -f 248+251 --no-check-certificate  https://www.youtube.com/watch?v=DfRFahKElh8

//ffmpeg -y -i ./f248.webm -i ./f251.webm -c copy -map 0:v:0 -map 1:a:0 x.webm
//ffmpeg -y -i ./f248.webm -i ./f251.webm -c copy x.webm
