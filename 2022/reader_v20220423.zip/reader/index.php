<?php
/**
 * PHP Readability
 * 
 * @date    2022-02-01
 * 
 */

session_start();
if ($_SERVER["HTTPS"] <> "on"){
    $xredir="https://".$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
    header("Location: ".$xredir);
}

date_default_timezone_set("Asia/Shanghai");

require __DIR__.'/depend/autoload.php';
require __DIR__.'/libs/function.inc.php';
require __DIR__.'/libs/beautify-html.php';

use fivefilters\Readability\Readability;
use fivefilters\Readability\Configuration;
use fivefilters\Readability\ParseException;

/* ---------------------- Readability配置 ---------------------- */

define("DIR_ROOT",   dirname(__FILE__));
define("URL_ROOT",   "/reader/");
define("DIR_CACHE",  DIR_ROOT . '/cache');
define("CACHE_TIME", 3600 * 24);
define('USER_AGENT', "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.67 Safari/537.36");

$options = array(
    'cleanConditionally'      => false,  // true，在解析后删除某些节点
    'maxTopCandidates'        => 5,      // 5  
    'charThreshold'           => 500,    // 500   
    'articleByLine'           => false,  // false 搜索文章的署名并将其从文本中移除
    'stripUnlikelyCandidates' => false,  // true  删除那些不太可能有相关信息的节点
    'weightClasses'           => true,   // true，在评级阶段对类进行加权
    'fixRelativeURLs'         => false,  // false 将相对的URLs转换为绝对的
    'substituteEntities'      => false,  // false 禁用libxml的substituteEntities标志
    'normalizeEntities'       => false,  // false 将UTF-8字符转换为其HTML实体等价物
    'originalURL'             => '',     // 文章中的原始URL，用于固定相对URL
    'summonCthulhu'           => false,  // false，通过regex删除所有<script>节点
);

/* ---------------------- 提交URL ---------------------- */

$cli = preg_match("/cli/i", php_sapi_name());
if($cli){
    # print_r($argv);
    if(!empty($argv[1])) $url = $argv[1];
    else{
        fwrite(STDOUT, "Enter url:");
        $url = trim(fgets(STDIN));
    }
}
//if(empty($_GET['url']) and !$cli) die(html_form());
//if(isset($_GET['url'])) $url = $_GET['url'];

if(empty($_POST['url']) and !$cli){

    echo(html_form_enc());
    ob_flush();
    flush();
    sleep(1);
    if(@$_GET["js"]){
        session_start();
        $_SESSION['js'] = $_GET["key"];
        file_put_contents('./logs/js.log', print_r($_GET, true));
    }else{
        $_SESSION["js"] = null;
        die("<noscript><br><center><b> 该页面需要Javascript才能使用，建议您启用Javascript </b></center></noscript>");
    }
    ob_end_flush();
}
if(empty($_SESSION["js"])) die(html_form_enc());
## ============ 设定User-Agent
$default_ua = "Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.82 Safari/537.36";

# 当前C端有UA
if(empty($_SERVER['HTTP_USER_AGENT'])) $current_ua = -1;
else $current_ua = $_SERVER['HTTP_USER_AGENT'];
if(strlen($current_ua) < 12) $current_ua = -1;

# C端选择 UA
if(empty($_POST["useragent_select"])) $ua = $current_ua;  // 当前UA
else if($_POST["useragent_select"] === 1){                // 自定义UA
    if(strlen($_POST["useragent_custom"]) < 12) $ua = -1;
    else $ua = $_POST["useragent_custom"];
}
else if($_POST["useragent_select"] === -1) $ua = -1;      // 无UA
else{
    $ua = $_POST["useragent_select"];                     // 选定设置的UA
    if(strlen($ua) < 12) $ua = -1;
}

if($ua === -1) $ua = $default_ua;
## ============ User-Agent设定结束

//print_r($_SESSION['js']);
//print_r($_REQUEST);
//exit;


$url = trim(getRequestParam("url", ""));
$output_type = strtolower(getRequestParam("type", "html"));
//echo "\r\n\r\n" . $url;

# 解密开始
//私钥
$private_key = "-----BEGIN RSA PRIVATE KEY-----
MIICXQIBAAKBgQDbHqVytV9dnIrfCS9dzDVZz+qM6LtU46cdqbGvvX0Xz4CtsiT+
TqU3m8eC9BwTd0jY8bWjatYqEn716H77JcIJpmvO6ZJc4JYxvyJx6BEj6TQ4ZGYl
CA/wT08s9TKwd+PjkEht9A51hvCuUiyHPzMXAiL0a9tghPVd5rcDHlXb5wIDAQAB
AoGBANhrD2wZWYSi7cJWVxMkc3kuUvIzl3rDkrZIeXgjBp9y0hw8fC80zBf9Y3Oi
2Owc/7VOHmG2TqqlNAJ7TJePdnGvEG5yzHuMH6/uRPS4A+gDndM8U/sZBUYaZjbr
5M8vg6wL3yQ2awAbXu7pwLEvxVmuvhv+0jOFnqLpTRlki3ZpAkEA+Y00pTwikCEt
N+dkFGbhzZfH6bFNIkUOCrkDMgru1IargO/ggllk4fVLe7WBMWwh/0X9oTeTjLi7
Es856QMdpQJBAODIIeu7/cL3wp6Bigg7V25OSD+7uSjlCpoPSUNZIjZ6HJQsFCnU
RHsEDeD1f88g7i9AGI0htYiJXCgwd6GE9ZsCQGoCUhrfMM+JSGw3H4yLJ+DuWT4s
01d7fjuP3IulmU8u5iwfun+k+fYC/c3PjNIx3T9TvCqAMW3WC6Ix5afWawECQA6p
n2TUL3pvVPen9YwR6uMcIiReJ3becfGYu6uz/cJV9tVHhs0vtoPbwNgCy6KEQGU+
phtWrpPIegV5G+SiWq8CQQCoH+ic1j9b1DzENUb206w7KpcIhm629iUWUgBTrnlC
LzOA6xwY78V7cAUdzhTycAxhmWq/1FBlCCKtuZHVHnE/
-----END RSA PRIVATE KEY-----";

# URL 是否需要解密
if(!$cli){
    $enc = $url;
    $array_enc = explode(",", $enc);
    $dec = '';
    foreach($array_enc as $key => $chunk_enc){ 
        $key =intval($key)+1;
        $chunk_enc = trim($chunk_enc);
        if(empty($chunk_enc)) continue;
        if(!ctype_xdigit($chunk_enc)){
            echo "<head><meta http-equiv=\"refresh\" content=\"3;url=index.php\"></head>\r\n";
            echo "<body>\r\n<center><h2><br>第 ". $key ." 行包含非16进制，可能无法解密而被丢弃<br></h2></center>\r\n</body>";
            exit;
            continue;
        }
        $encrypt_data = @pack("H*", $chunk_enc);//对十六进制数据进行转换
        if(!is_int(strlen($chunk_enc)/256)){
            // echo "十六进制编码后的字节长度: ". strlen($chunk_enc) ." --> 原密文的字节长度: ". strlen($encrypt_data) ."<br><br>\r\n";
        }
        openssl_private_decrypt($encrypt_data, $decrypt_data, $private_key);
        //$dec .= base64_decode($decrypt_data) ;
        $dec .= $decrypt_data;
    }
    if(empty($dec)){
        echo "<head><meta http-equiv=\"refresh\" content=\"3;url=index.php\"></head>\r\n";
        echo "<body>\r\n<center><h2><br>没有得到解密数据，可能解密失败<br></h2></center>\r\n</body>";
        exit;
    }
    //echo "明文总字节: ". strlen($dec) ."<br><br>\r\n". $dec;
    else $url = trim($dec);
    # 解密结束
}


if(!filter_var($url, FILTER_VALIDATE_URL)){
    echo "<head><meta http-equiv=\"refresh\" content=\"3;url=index.php\"></head>\r\n";
    echo "<body>\r\n<center><h2><br>提交的网址没有通过过滤器验证<br>\r\n\"$url\"</h2></center>\r\n</body>";
    exit;
}

/* ----------------------  文件名 ---------------------- */

# 建立存储文件夹
$url_array = parse_url($url);
$host = $url_array['host'];
if(filter_var($host, FILTER_VALIDATE_IP)) $siteskey = $hosts;

$host_array = explode('.', $host);
$number = count($host_array);
$host_a2_1 = $host_array[$number-2];
$host_a2_2 = $host_array[$number-2] .'.'. $host_array[$number-1];

$domain_2level = array("ac", "biz", "co", "com", "edu", "gov", "info", "mil", "net", "org", );
$domain_2level_list = json_decode(file_get_contents(__DIR__.'/libs/domain-2level.json'));
// $host_2level_list = explode("\n", file_get_contents(__DIR__.'/libs/domain-2level.txt'));

if    (in_array($host_a2_1, $domain_2level))      $siteskey = $host_array[$number-3];
elseif(in_array($host_a2_2, $domain_2level_list)) $siteskey = $host_array[$number-3];
else $siteskey = $host_array[$number-2];

$dir_save = 'pages/'. $siteskey .'/';
if(!file_exists($dir_save)) mkdir(__DIR__.'/'.$dir_save, 0777, true);

# 提取文件名及扩展名
if(empty($url_array['path'])) $url_array['path'] = '/index.html';
$path_array = pathinfo($url_array['path']);
$fn = $path_array['basename'];
$fn_1 = $path_array['filename'];

$fn_1 = urldecode($fn_1);


if(isset($path_array['extension'])) $fn_ext = $path_array['extension'];
else $fn_ext = 'no';

# 建立新的文件名
if(4 < strlen($fn_1) and mb_strlen($fn_1) <= 16) $randkey = $fn_1;
else $randkey = rand_char($n=10);
$filename_save = date('YmdH').'-'.$randkey.'_'.$fn_ext.'.html';
$path_filename_save = $dir_save . $filename_save;

$url_hash = strtoupper(md5($url));
$url_cache_file = sprintf(DIR_CACHE . "/%s.bak", $url_hash);

/* ---------------------- 缓存请求数据，避免重复请求 ---------------------- */


if(file_exists($url_cache_file) && (time() - filemtime($url_cache_file) < CACHE_TIME)){
    $source = file_get_contents($url_cache_file);
}else{
    // $source = file_get_contents($url); 
    // $source = get_url_contents($url, $method='GET', $stringData='');
    
    # cookie_jar 应该和 SEESION关联
    if(!file_exists('./tmp')) mkdir('./tmp', 0777, true);
    $cookie_jar = __DIR__ . '/tmp/'. md5($url_array['host']) .'.cookie';
    if(!file_exists($cookie_jar)) file_put_contents($cookie_jar, '');
    
    $res_array = getResponse($url, $data = [], $cookie_file = '', $ua);
    $source = $res_array['body'];
    $header = $res_array['header'];
    $mime = $res_array['mime_type'];
    $status = $res_array['status'];
    // echo $mime;
    
    # cloudflare 云盾
    if(strpos(strtolower($source), 'please wait... | cloudflare') !== false or trim($status) == '403'){
        $cmd = 'python3 /home/reader/libs/bin/spider.py '. $url;
        exec($cmd, $array);
        $status  = $array[0];
        $charset = $array[1];
        $mime    = $array[2];
        $header  = $array[3];
        unset($array[0]);
        unset($array[1]);
        unset($array[2]);
        unset($array[3]);
        
        //echo "<pre>". $status ."\r\n". $charset ."\r\n". $mime ."\r\n".  $header;
        $header = str_replace('"', '\\"', $header);
        $header = str_replace("'", '"', $header);
        // $header = stripslashes(html_entity_decode($header));
        $header = json_decode($header,true);
        if(isset($header['Set-Cookie'])) $cookie  = $header['Set-Cookie'];
        $source = join("\r\n", $array);
        if(strstr($mime, 'text/html') and $charset !== 'utf-8'){
            $source = mb_convert_encoding ($source, 'utf-8', $charset);
        }
    }
    
    # 下载视频
    // 134 360p,135 480p,136 720p, mp4_dash
    // $url = 'https://www.youtube.com/watch?v=HojapkfJPVg';
    if(strpos(strtolower($host), 'youtube.com') !== false){
        $vid_array = explode('v=', $url);
        $vid = $vid_array[1];
        $dir_youtube = scandir('./pages/youtube/');
        foreach($dir_youtube as $value){
            if($value === '.' || $value === '..') continue;
            if(is_dir($value)) continue;
            if(strpos($value, $vid) !== false){
                echo html_form_enc();
                echo '<ul><li>存在的视频 <a href="./pages/youtube/'. $value .'">'. $value .'</a></li></ul>';
                exit;
            }
        }

        $bin = 'yt-dlp';  # youtube-dl
        $bin = '/home/reader/libs/bin/yt-dlp ';
        $para = '--no-check-certificate '; #--write-info-json 
        $name = '-o "%(upload_date)s-%(id)s.mp4" ';
        $cmd_dl = $bin .'-f best '. $para . $name . $url ;
        exec($cmd_dl, $out_dl_array, $ret);
        if($ret === 0){
            echo html_form_enc();
            echo "<pre>将下载720p MP4视频资源\r\n\r\n";
            //print_r($out_dl_array);
            $dir_current = scandir('./');
            foreach($dir_current as $value){
                if($value === '.' || $value === '..') continue;
                if(is_dir($value))continue;
                
                $media_array = pathinfo($value);
                $fn_media = $media_array['basename'];
                $fn_ext_media = $media_array['extension'];
                if($fn_ext_media === 'md') continue;
                if($fn_ext_media === 'php') continue;
                
                rename($fn_media, './pages/youtube/'. $fn_media);
                echo '<ul><li><a href="./pages/youtube/'. $fn_media .'">'. $fn_media .'</a></li></ul>';
            }
            exit;
        }else{
            echo html_form_enc();
            die('下载资源失败');
        }
    }
    if(strpos(strtolower($source), '<body>') == false) $source = str_replace("</head>", "</head>\r\n<body>", $source);

    if(strpos(strtolower($mime), 'html') !== false){
         @file_put_contents($url_cache_file, $source);
    }else{
        if(empty($path_array['extension']))$fn .= '.'. mime2ext($mime);
        elseif(strtolower($path_array['extension']) == 'php') $fn .= 's';
        $path_nohtml_save = $dir_save . date('YmdH').'-'.urldecode($fn);
    
        @file_put_contents($path_nohtml_save, $source); // 非HTML文件另行保存
        # 非HTML文件同时保一份它的header到$url_cache_file做检索
        @file_put_contents($url_cache_file, "对应的源文件:". $path_nohtml_save ."\r\n\r\n". $header);
    }
}

$cache_file_mime_type = mime_content_type($url_cache_file);
if(strlen($source) < 500 or strpos($cache_file_mime_type, 'html') == false){
    $source = file_get_contents($url_cache_file);
    //if(file_exists($url_cache_file)) unlink($url_cache_file);
    echo html_form_enc();
    die("\r\n<br><small>取到的数据如下</small><pre>\r\n". htmlspecialchars($source) ."\r\n</pre>");
}

/* ----------------------  解析HTML内容 ---------------------- */

# 转为 UTF-8 之后，HTML 实体
    # getResponse() 已经使用了编码转换
// $charset = mb_detect_encoding($source, mb_list_encodings(), true);
// if(strtolower($charset) !== 'utf-8'){
//     if(extension_loaded('mbstring')) $source = mb_convert_encoding($source, 'UTF-8', $charset);
//     elseif(extension_loaded('iconv')) $source = iconv($charset, 'UTF-8//IGNORE//TRANSLIT', $source);
//     // else die("必需安装 mbstring 或者 iconv， 否则获取的文章乱码");
// }
// $source = utf2html($source);

# 一些网站的 title 和文章标题不一致，需要从 title 中重新提取文章标题
$n = 8;
//$source = preg_replace("/\r\n|\r|\n/", '', $source); 
preg_match_all("/<title[\s\S]*?>(.*?)<\/title>/is", $source, $title_matches);
$title = isset($title_matches[1][0]) ? trim($title_matches[1][0]) : "";
//preg_match('/<title[^>]*>(.*?)<\/title>/ims', $source, $title_matches);
//$title = isset($title_matches[1]) ? trim($title_matches[1]) : "";
$title = preg_replace("/\r\n|\r|\n/", '', $title);
unset($title_matches);
// echo "<pre>\r\n";print_r($title_matches);echo $title ."<br>\r\n";// exit;

if(mb_strlen($title) < $n) $title_key = $title;
else $title_key = mb_substr($title, 0, $n, "UTF-8");
$source_array = preg_split("/<\/head>/i", $source, 2);
if(empty($source_array[1]) or strpos($source_array[1], $title_key) == false)  $article_title = $title;
else{
    # 如果 $title_key 中含有特殊字符，如 / " 等可能会导致 preg_match_all() 无效
    //preg_match_all("/$title_key.[\s\S]*?</is", $source_array[1], $matches);
    //$article_title = trim(substr($matches[0][0], 0, -1));
    $temp_array_1 = explode($title_key, $source_array[1], 2);
    $temp_array_2 = explode('<', $title_key.$temp_array_1[1], 2);
    $article_title = trim($temp_array_2[0]);
    if(strpos($article_title, '>') !== false) $article_title = trim(substr($article_title, strripos($article_title, '>')+1));
}
// $log_title = $n .' --> '. $title_key .' --> '. $article_title ."\r\n";
// echo $log_title; exit;

$options['originalURL'] = $url;
$config = new Configuration($options);
$readability = new Readability($config);

try{
    $readability -> parse($source);
    // echo $readability;
}catch(ParseException $e) {
    echo sprintf('Error processing text: %s', $e->getMessage());
    echo sprintf('处理文本时出错: %s', $e->getMessage());
}

switch($output_type){
case 'json':
    header("Content-type:text/json;charset=utf-8");
    $Data['url'] = $url;
    echo json_encode($Data);
    break;
case 'html':
    default:
    header("Content-type:text/html;charset=utf-8");
    $title = $readability -> getTitle();
    if(empty($title)) $title = '没找到title';
    if(empty($article_title)) $article_title = $title;
    $content = $readability -> getContent();
    $content = str_replace("='/", '="/',  $content);
    $content = str_replace(array('src="//', 'href="//',), array('src="https://', 'href="https://',), $content);
    $content = str_replace(array('src="/', 'href="/',),   array('src="https://'. $host .'/', 'href="https://'. $host .'/',), $content);

    $html = html_head($title) . '<body><div id="article" class="margin-medium size-medium"><h2>' . $article_title . '</h2>' . $content;
    $html .= '</div><hr><div id="footer"><a href="'. strip_tags($url) .'"><b>'. $url .'</b></a></div><br><br></body></html>';







# 处理超链接，下载相关图片
$images = array('bmp', 'png', 'jpg', 'jpeg', 'ico', 'webp', 'gif', 'svg', 'tiff', 'avif');

$img_dir = 'pages/'. $siteskey .'/article_images/';
if(!file_exists($img_dir)) mkdir(__DIR__ .'/'. $img_dir, 0777, true);

$link = preg_htmllink($html);

foreach($link as $uri){
    $uri = trim($uri);
    if(strstr($uri, '.css')) continue;
    $url_html = relative_to_absolute_url($url, $uri); # 相对链接转为完整的URL
    $html = str_replace($uri, $url_html, $html);      # 替换
    
    extract(parse_url($url_html)); # 返回变量: $scheme, $host, $path
    if(empty($path)) $path = '/';
    if(substr($path, -1) === '/') continue;
    $path_info = pathinfo($path);
    // if(empty($path_info['extension'])) $ext = ''; else $ext = $path_info['extension'];
    empty($path_info['extension']) ? $ext = '' : $ext = strtolower($path_info['extension']);
    if(empty($ext) or in_array($ext, $images, true)){
        $img_url_md5 = substr(md5($url_html), 8, 16);
        $img_fn = date('YmdH') .'-'. $img_url_md5 .'.'. $ext;
        $img_save = $img_dir . $img_fn;
        $img_url = './article_images/'. $img_fn;
        if(file_exists($img_save)){
            $html = str_replace($url_html, $img_url, $html);
            continue;
        }
                
        # cookie_jar 应该和 SEESION关联
        if(!file_exists('./tmp')) mkdir('./tmp', 0777, true);
        $cookie_jar = __DIR__ . '/tmp/'. md5($host) .'.cookie';
        if(!file_exists($cookie_jar)) file_put_contents($cookie_jar, '');

        $img_array = getResponse($url_html, $data = [], $cookie_file = '', $ua);
        $img_source = $img_array['body'];
        $header = $img_array['header'];
        $mime = $img_array['mime_type'];
        $status = $img_array['status'];
        foreach($images as $ext){
            # mime中包含bmp/png/jpeg/ico/webp/gif/svg/tiff
            if(strstr($mime, $ext)){
                if($ext == 'jpeg') $ext = 'jpg';
                $img_fn = date('YmdH') .'-'. $img_url_md5 .'.'. $ext;
                $img_save = $img_dir . $img_fn;
                $img_url = './article_images/'. $img_fn;
                if(!file_exists($img_save)) file_put_contents($img_save, $img_source);
                $html = str_replace($url_html, $img_url, $html);
            }
        }
    }
}


/* ----------------------  格式化HTML ---------------------- */

    $beautify = new Beautify_Html(array(
        'indent_inner_html'     => false,
        'indent_char'           => " ",
        'indent_size'           => 2,
        'wrap_line_length'      => 32786,
        'unformatted'           => ['code', 'pre'],
        'preserve_newlines'     => false,
        'max_preserve_newlines' => 32786,
        'indent_scripts'        => 'normal', // keep|separate|normal
        )
    );
    $html = $beautify -> beautify($html);
    file_put_contents($path_filename_save, $html);

    if(mb_strlen($article_title) > 44) $article_title = mb_substr($article_title, 0, 44, "UTF8") .' ... ';
    echo html_form_enc() . "\r\n<ul><li><a href=\"". $path_filename_save .'" target="_blank">'. $article_title .'</a></li><ul>';

    # 向远端传输该html文件
    ## 远端 url
    $url_get_remote = 'https://ca.liuyun.org/reader/sync-html.php?url=';
    
    ## 本地 html 文件的 url 不能设置为 localhost，要供远端访问
    $url_html_local = 'https://us.liuyun.org'. dirname($_SERVER['PHP_SELF']) .'/'. $path_filename_save;
    
    $sync_url = $url_get_remote . $url_html_local;
    
    $log = get_url_contents($sync_url, $method='GET', $stringData='');
    
    file_put_contents('logs/sync.log', $log."\r\n", FILE_APPEND);
}
