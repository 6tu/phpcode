# Authors

Readability.php developed by **Andres Rey**. 

Based on Arc90's readability.js (1.7.1) script available at: http://code.google.com/p/arc90labs-readability.
Copyright (c) 2010 Arc90 Inc

The AUTHORS/Contributors are (and/or have been):

* Andres Rey
* Sergiy Lavryk
* Pedro Amorim 
* Malu Decks
* Keyvan Minoukadeh
