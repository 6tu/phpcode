<?php
$path = 'sites/youtube/';
$url = 'https://www.youtube.com/watch?v=E6Yxs8M_0Bc&format=mp4';

$html = file_get_contents('/home/reader/cache/400244843B95371B274CC8C1437B1204.bak');
echo '<pre>';
print_r(youtube_info($html));
// file_put_contents('ytb.txt', print_r($details, true).print_r($videoformats,true));
function youtube_info($html){
    preg_match_all("/ytInitialPlayerResponse =(.*?);var meta/is", $html, $html_array);
    if($html_array) $json = trim($html_array["1"][0]);
    else $json = '';
    // $html = str_replace('>', ">\r\n", $html);
    // $html_array = explode("\r\n", $html);
    // $json = '';
    // foreach($html_array as $line){
    //     if(strstr($line, 'var ytInitialPlayerResponse')) $json = $line;
    // }
    // $json_array = explode(";var meta", $json, 2);
    // $json_array = explode("ytInitialPlayerResponse =", $json_array[0], 2);
    // $json = trim($json_array[1]);
    
    $ytb_info = json_decode($json, true);
    
    //['videoDetails']
    $videodetails = $ytb_info['videoDetails'];//['microformat']
    
    $microformat = $ytb_info['microformat']['playerMicroformatRenderer'];
    unset($microformat['embed']);
    unset($microformat['keywords']);
    unset($microformat['shortDescription']);
    unset($microformat['thumbnail']);
    unset($microformat['availableCountries']);
    unset($microformat['description']);
    $microformat['title'] = $videodetails['title'];
    
    $details = array("videoId" => $videodetails['videoId']) + $microformat;
    
    //['streamingData']
    $webm_format = $ytb_info['streamingData']['adaptiveFormats'];
    $mp4 = $ytb_info['streamingData']['formats'];
    $webm = array();
    foreach ($webm_format as $key => $value) {
        if($webm_format[$key]['itag'] === 248) $webm[248]=$webm_format[$key];
        if($webm_format[$key]['itag'] === 251) $webm[251]=$webm_format[$key];
    }
    $videoformats = $mp4 + $webm;
    return $details + $videoformats;
}
