cd /home/reader/sites/youtube/
yt-dlp  -f 248+251 --no-check-certificate  -o "%(upload_date)s-%(id)s" https://www.youtube.com/watch?v=l2fRJOt0Ri0

# /usr/bin/ffmpeg -y  -i  -i  -c copy 
chown www-data:www-data *
