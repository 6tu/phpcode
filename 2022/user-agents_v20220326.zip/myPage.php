<?php
if(!empty($_GET["key"]) and $_GET["js"] == 1){
    session_start();
    $_SESSION['js'] = $_GET["key"];
    file_put_contents('js.log', print_r($_GET, true));
}else die("<noscript><br><b>**</b> 该页面需要Javascript才能使用，建议您启用Javascript <b>**</b></noscript>");
?>


