<?php

// https://techblog.willshouse.com/2012/01/03/most-common-user-agents/
// https://developers.whatismybrowser.com/useragents/explore/
// https://updatemybrowser.org/
// http://whatsmyuseragent.org/
// https://tool.lu/useragent
// http://www.useragentstring.com/

// https://github.com/intoli/user-agents/blob/master/src/user-agents.json.gz
// $out = [];
// $uas = json_decode(file_get_contents(__DIR__ . '/user-agents.json'), true);
// foreach($uas as $string => $parts) {
//     $out[] = [$string, $parts];
// }
// print_r($out);

// print_r($_REQUEST);

echo "<pre>\r\n";

$default_ua = "Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.82 Safari/537.36";

# 当前C端有UA
if(empty($_SERVER['HTTP_USER_AGENT'])) $current_ua = -1;
else $current_ua = $_SERVER['HTTP_USER_AGENT'];
if(strlen($current_ua) < 12) $current_ua = -1;

# C端选择 UA
if(empty($_POST["useragent_select"])) $ua = $current_ua;  // 当前UA
else if($_POST["useragent_select"] === 1){                // 自定义UA
    if(strlen($_POST["useragent_custom"]) < 12) $ua = -1;
    else $ua = $_POST["useragent_custom"];
}
else if($_POST["useragent_select"] === -1) $ua = -1;      // 无UA
else{
    $ua = $_POST["useragent_select"];                     // 选定设置的UA
    if(strlen($ua) < 12) $ua = -1;
}

if($ua === -1) $ua = $default_ua;

echo $ua;



?>




