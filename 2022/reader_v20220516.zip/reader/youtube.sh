cd /home/reader/sites/youtube/
yt-dlp  -f 248+251 --no-check-certificate  -o "%(upload_date)s-%(id)s" https://m.youtube.com/watch?v=DPmsJQK9o-o&format=mp4

# /usr/bin/ffmpeg -y  -i  -i  -c copy 
chown www-data:www-data *
