<?php declare(strict_types = 1);
namespace PharIo\Manifest;

class ManifestLoaderException extends \Exception implements Exception {
}
