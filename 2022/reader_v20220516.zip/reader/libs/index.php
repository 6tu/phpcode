<?php

$host = $_SERVER['HTTP_HOST'];
$host = str_replace(']', '', $host);
$host = str_replace('[', '', $host);
$ipv6 = is_valid_ip($host, $ip_type='ipv6');
$ipv4 = is_valid_ip($host, $ip_type='ipv4');
if($ipv6 or $ipv4) $ip = $host;
else $ip = 'hostname';

echo forbidden_html();
exit;
# 纯IP访问提示禁止
if(strpos($host, $ip) !== false){ 
    echo forbidden_html();
    exit;
}else echo 'hello world!';





function is_valid_ip($ip = '', $ip_type = ''){
    $isValid = false;
    if($ip_type == 'ipv4'){
        // validates IPV4
        $isValid = filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4);
    }elseif($ip_type == 'ipv6'){
        // validates IPV6
        $isValid = filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6);
    }else{
        // validates IPV4 and IPV6
        $isValid = filter_var($ip, FILTER_VALIDATE_IP);
    }
    if($isValid == $ip){
        $isValid = true;
    }
    return $isValid;
}

function forbidden_html(){
    // 根据浏览器语言显示
    preg_match('/^([a-z\-]+)/i', $_SERVER['HTTP_ACCEPT_LANGUAGE'], $matches);
    $lang = strtolower($matches[1]);
    // echo $lang."<br>";
    switch ($lang){
        case 'zh-cn':
            $mult_lang = array('title' => '禁止访问',
                               'tips'  => '您无权限访问此资源。'
                            );
            break;
        default:
            $mult_lang = array('title' => 'Forbidden',
                               'tips'  => 'You don\'t have permission to access this resource.'
                            );
            break;
    }

    $forbidden_html = '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>403 '. $mult_lang['title'] .'</title>
</head>
<body>
    <h1>'. $mult_lang['title'] .'</h1>
    <p>'. $mult_lang['tips'] .'</p>
    <hr>
    <address>'. apache_get_version('Prod') .' Server at '. $_SERVER['SERVER_NAME'] .' Port '. $_SERVER['SERVER_PORT'] .'</address>
</body></html>
';
    return $forbidden_html;
}

