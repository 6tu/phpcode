<?php

echo "<pre>\r\n";
echo $_SERVER['HTTP_USER_AGENT'];
exit;
$url = 'https://product.pconline.com.cn/itbk/software/dnwt/1504/6325876.html';
$crc32 = crc32($url) . "\r\n";
$md5 = md5($url) . "\r\n";
echo $crc32.$md5;
echo sha1($url) . "\r\n";
echo hash("sha256", $url) . "\r\n";
echo hash("sha384", $url) . "\r\n";
echo hash("sha512", $url) . "\r\n";









$dir_array = array(
'51wendang',
'77c4c630f3d4a19f9f712402ae6be6b1',
'79',
'360doc',
'423down',
'917xe',
'1024sou',
'aboluowang',
'amazonaws',
'appledaily',
'baidu',
'biaodianfu',
'careerengine',
'cctv',
'chinapress',
'cnblogs',
'cnplugins',
'codeleading',
'cooluc',
'csdn',
'cxyzjd',
'd41d8cd98f00b204e9800998ecf8427e',
'douban',
'duanmeiwen',
'edrawsoft',
'epochtimes',
'geeksforgeeks',
'github',
'gushiwen',
'guwenxuexi',
'hostloc',
'huatu',
'inkuang',
'it1352',
'iteye',
'jianshu',
'jpjazz',
'jupeixun',
'liuyun',
'minghui',
'modb',
'nantong',
'net7',
'ntdtv',
'php',
'renminbao',
'ruiwen',
'secretchina',
'shenyunperformingarts',
'shimo',
'sina',
'sohu',
'soundofhope',
'techper',
'w3cub',
'wikihow',
'willshouse',
'yandex',
'yxlady',
'zhihu',
'zuowenxue',
    );

foreach($dir_array as $dir){
    $path = 'sites/' . $dir .'/';
    //echo "\r\n". $path . "\r\n";
    $fn_array = file_search($path, '.html');
    //print_r($fn_array);
    foreach($fn_array as $fn){
        $date_array = explode('-', $fn);
        $date = substr($date_array[0], 0, 8);
        $str = file_get_contents($path.$fn);
        //if(strlen($str) < 1000)unlink($path.$fn)."\r\n";
        if(strpos($str, 'Please enable cookies') !== false){ 
unlink($path.$fn);
echo $path.$fn."\r\n";
}

        $array = explode('<div id="footer">', $str);
        preg_match_all("/<b>(.*?)<\/b>/is", $array[1], $link_array);
        $url = trim($link_array[1][0]);
        $url_base64 = str_replace('=', '', base64_encode($url));
        //if(empty(pathinfo($url, PATHINFO_EXTENSION))){
        //    $fn_key = substr(strrev($url_base64), 0, 12);
        //}
        $fn_key = substr(strrev($url_base64), 0, 12);
        $fn_key = str_pad(crc32($url), 10, '0'); # CRC32输出长度: 8-9-10位
        
        $html_fn = $date .'-'. $fn_key .'.html';
        // echo $url . "\r\n".pathinfo($url, PATHINFO_FILENAME) . "\r\n";
        // echo $fn .' => '.$html_fn ."\r\n";
        //echo $html_fn ."\r\n";
        //rename($path.$fn, $path.$html_fn);
    }
}







/*
foreach($fn_array as $fn){
    $str = file_get_contents($path.$fn);
    $array = explode("\n", $str);
    foreach($array as $v){
        if(strpos($v, '[videoId]') !== false){
            $id_array = explode('=>', $v);
            $id = trim($id_array[1]);
        }
        if(strpos($v, '[uploadDate]') !== false){
            $date_array = explode('=>', $v);
            $date = trim(str_replace('-', '', $date_array[1]));
        }
    }
    $html_fn = $date .'-'. $id .'.html';
    echo $html_fn;
    rename($path.$fn, $path.$html_fn);
}
*/







function file_search($path, $key){
    // $list = array_diff(scandir($path), array('..','.'));
    $list = scandir($path);
    $out = array();
    foreach($list as $value){
        if($value === '.' || $value === '..') continue;
        if(is_dir($value)) continue;
        if(strpos($value, $key) !== false) $out[] = $value;
    }
    return $out;
}
