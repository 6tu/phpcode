<?php
$url = "https://posts.careerengine.us/p/60abb394dfc0703e4f8f2136";

$cmd = 'python3 /home/reader/libs/bin/spider.py '. $url;
exec($cmd, $array);
$status  = $array[0];
$charset = $array[1];
$mime    = $array[2];
// $cookie  = $array[3];
$header  = $array[3];

unset($array[0]);
unset($array[1]);
unset($array[2]);
unset($array[3]);
// unset($array[4]);

echo "<pre>\r\n\r\n";
//echo $status ."\r\n". $charset ."\r\n". $mime ."\r\n".  $header;

$header = str_replace('"', '\\"', $header);
$header = str_replace("'", '"', $header);
// $header = stripslashes(html_entity_decode($header));
$data = json_decode($header,true);
print_r($data);





$source = join("\r\n", $array);
// file_put_contents('tmp.txt', print_r($array, true));
file_put_contents('tmp.txt', $source);

