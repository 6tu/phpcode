<?php

require __DIR__.'/libs/function.inc.php';
$dir_save = dirname($_SERVER['PHP_SELF']) . '/pages/';

date_default_timezone_set('Asia/Shanghai');
$date = date('Y/m/d H:i:s');
file_put_contents('logs/error.log', "\r\n\r\n".$date."\r\n", FILE_APPEND);

$ip_allow_array = array(
    '173.82.181.148', 
    '203.93.166.28',
    '158.51.78.90',
    '45.131.66.163',
    '127.0.0.1',
    'localhost',
    '23.131.32.103',
);
$ip_remote = $_SERVER['REMOTE_ADDR'];
if(in_array($ip_remote, $ip_allow_array) === false)     die(file_put_contents('logs/error.log', "$ip_remote 禁止访问", FILE_APPEND));

if(!empty($_GET['url'])){
    $url = $_GET['url'];
                                                        file_put_contents('logs/error.log', $url, FILE_APPEND);
    $url_array = parse_url($url);
    
    # 判断路径和文件类型是否合法
    $number = substr_count($url_array['path'], '/');
    if($number != 4)                                    die(file_put_contents('logs/error.log', 'URL的路径无效', FILE_APPEND));
    if(strpos($url_array['path'], $dir_save) === false) die(file_put_contents('logs/error.log', 'URL的路径不匹配', FILE_APPEND));

    $path_array = pathinfo($url_array['path']);
    if(@$path_array['extension'] != 'html')             die(file_put_contents('logs/error.log', 'URL的文件类型不匹配', FILE_APPEND));

    $path_save = dirname(__DIR__).$path_array['dirname'];
    if(!file_exists($path_save)) mkdir($path_save, 0777, true);

    $fn = dirname(__DIR__).$url_array['path'];
    //echo $fn;

    $resource = get_url_contents($url, $method='GET', $stringData='');
    file_put_contents($fn, $resource);
    echo "\r\nokay";
}else{
    echo "\r\nurl not found";
}


