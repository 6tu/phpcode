<?php declare(strict_types = 1);
namespace PharIo\Version;

class InvalidVersionException extends \InvalidArgumentException implements Exception {
}
