<?php


/* ---------------------- 公共函数库 ---------------------- */
function html_form_enc(){
    header("Content-type: text/html; charset=utf-8");
    $form = '
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>优化阅读&mdash;&mdash;重拾阅读的乐趣</title>

    <style>
        #title{text-align:left; text-indent:3em; color:green;}
        #sec{text-align:left; text-indent:12em;}
        #form p{text-indent:0; font-size:1.5em}
        #form p input[type=text]{height:30px; width:90%}
    </style>

    <script type="text/javascript" src="./libs/js/jsbn.js"></script>
    <script type="text/javascript" src="./libs/js/prng4.js"></script>
    <script type="text/javascript" src="./libs/js/rng.js"></script>
    <script type="text/javascript" src="./libs/js/rsa.js"></script>
    <script type="text/javascript" src="./libs/js/base64.js"></script>
    <script                        src="./libs/js/jquery-3.0.0.min.js"></script>

    <script type="text/javascript">
        function cmdEncrypt() {
            var rsa = new RSAKey();
            var modulus = "DB1EA572B55F5D9C8ADF092F5DCC3559CFEA8CE8BB54E3A71DA9B1AFBD7D17CF80ADB224FE4EA5379BC782F41C137748D8F1B5A36AD62A127EF5E87EFB25C209A66BCEE9925CE09631BF2271E81123E93438646625080FF04F4F2CF532B077E3E390486DF40E7586F0AE522C873F33170222F46BDB6084F55DE6B7031E55DBE7";
            var exponent = "10001";
            rsa.setPublic(modulus, exponent);

            var url = $("#url").val();
            
            // maxLength为明文块，最大长度 = 密钥长度/8 -11 ，这里的密钥长度为 1024
            // 由于明文块会被随机数填充至密钥长度的原因，maxLength 不宜设置为最大值117 ，但也不建议设置太小
            // 一般设置为 93～109 比较合适
            
            // 加密后的密文长度为128字节，十六进制后为 256字节，一般长度是固定的
            var maxLength = 117;
            var ApachemaxLength = 8177;
            var urllen = url.length;
            if(urllen > ApachemaxLength){ 
                var url = "";
                //return;
                alert("请求长度"+urllen+"超出了限制，该长度被Apache限制为"+ApachemaxLength);
            }

            // var base = new BASE64();
            // var url = base.encode(url);

            // 长度分割
            // let lt = ""
            // let ct = ""
            // lt = url.match(/.{1,96}/g) || "";
            // lt.forEach(function (entry) {
            //     tl = rsa.encrypt(entry);
            //     ct += tl + ",\r\n";
            // });

// 1.获取字符串截取点
const bytes = [];
bytes.push(0);
let byteNo = 0;
let c;
const len = url.length;
let temp = 0;
for (let i = 0; i < len; i++) {
    c = url.charCodeAt(i);
    if(c >= 0x010000 && c <= 0x10ffff) {       //特殊字符，如Ř，Ţ
        byteNo += 4;
    }else if(c >= 0x000800 && c <= 0x00ffff) { //中文以及标点符号
        byteNo += 3;
    }else if(c >= 0x000080 && c <= 0x0007ff) { //特殊字符，如È，Ò
        byteNo += 2;
    }else{                                     //英文以及标点符号
        byteNo += 1;
    }
    //一般设置为 93～109 比较合适
    if(byteNo % 109 >= 106 || byteNo % 109 === 0) {
        if(byteNo - temp >= 106) {
            bytes.push(i);
            temp = byteNo;
        }
    }
}

// 2.截取字符串

let ct = "";
let ctstr = "";
let enc = "";
let str;
for (let i = 0; i < bytes.length - 1; i++) {
    if(i === 0){
        str = url.substring(0, bytes[i + 1] + 1);
    }else{
        str = url.substring(bytes[i] + 1, bytes[i + 1] + 1);
    }
    enc = rsa.encrypt(str);
    ct += enc + ", \r\n";
    ctstr += str;
}
if(ctstr.length < len) {
    str = url.substring(ctstr.length, len);
    enc = rsa.encrypt(str) + ", \r\n";
    ct += enc;
}
//alert(ct);//document.write(ct);

            rsa = ct;
            //var rsa = rsa.encrypt(url);
            $("#url").val(rsa);
        }
    </script>

</head>
  <body class="bg">
    <center>
      <h1 id="title">优化阅读</h1>
      <p id="sec">&mdash;&mdash;&nbsp; 重拾阅读的乐趣</p>
      <form action="' . php_self() . '" method="post" id="form" class="search">
        <p><input type="text" placeholder="请输入你要阅读的网址" autocomplete="off" id="url" name="url" value=""  /></p>
        <p><input type="submit" id="submit" value="&raquo; gogo提交" onclick="cmdEncrypt();" /></p>
      </form>
    </center>
  </body>
</html>
    ';
    echo $form;
}

function html_form(){
    header("Content-type: text/html; charset=utf-8");
    $form = '
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>优化阅读&mdash;&mdash;重拾阅读的乐趣</title>
    <style>
        #title{text-align:left; text-indent:3em; color:green;}
        #sec{text-align:left; text-indent:12em;}
        #form p{text-indent:0; font-size:1.5em}
        #form p input[type=text]{height:30px; width:90%}
    </style>
  </head>
  <body class="bg">
    <center>
      <h1 id="title">优化阅读</h1>
      <p id="sec">&mdash;&mdash;&nbsp; 重拾阅读的乐趣</p>
      <form action="' . php_self() . '" method="get" id="form" class="search">
        <p><input type="text" placeholder="请输入你要阅读的网址" autocomplete="off" id="url" name="url" value=""  /></p>
        <p><input type="submit" id="submit" value="&raquo; gogo提交" /></p>
      </form>
    </center>
  </body>
</html>
';
echo $form;
}

function html_head($title){
    $head='
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <meta name="renderer" content="webkit">
    <meta name="force-rendering" content="webkit"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
    <meta name="referrer" content="no-referrer">
    
    <title>'. $title .'</title>

    <link rel="stylesheet" href="'. dirname($_SERVER['PHP_SELF']) .'/libs/css/header-custom.css" type="text/css" media="screen" />
    <!--<style type="text/css">div{background: #FDFEFE;}</style>-->

  </head>

';
    return $head;
}

# 获取当前PHP文件名
function php_self(){
    $php_self = substr($_SERVER['PHP_SELF'], strrpos($_SERVER['PHP_SELF'], '/') + 1);
    return $php_self;
}

/**
 * *获取随机字串
 * 
 * @参数 $n=4 字串
 */
function rand_char($n=4) { 
    $rand = '';
    for($i = 0;$i < $n;$i++ ){
        $base = 62;
        $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $rand .= $chars[mt_rand(1, $base) - 1];
    }
    return $rand;
}
/**
 * $html-需要爬取的页面内容
 * $tag-要查找的标签
 * $attr-要查找的属性名
 * $value-属性名对应的值
 */
function get_tag_data($html,$tag,$attr,$value){
	$regex = "/<$tag.*?$attr=\".*?$value.*?\".*?>(.*?)<\/$tag>/is";
	preg_match_all($regex,$html,$matches,PREG_PATTERN_ORDER);
	return $matches[1];
}

/**
 * 安全获取GET/POST的参数
 * 
 * @param  String  $request_name
 * @param  Mixed   $default_value
 * @param  String  $method 'post', 'get', 'all' default is 'all'
 * @return String 
 */
function getRequestParam($request_name, $default_value = null, $method = "all"){
    $magic_quotes = ini_get("magic_quotes_gpc") ? true : false;
    $method = strtolower($method);
    switch(strtolower($method)){
    // default:
    case "all":
        if(isset($_POST[$request_name])){
            return $magic_quotes?stripslashes($_POST[$request_name]):$_POST[$request_name];
        }elseif(isset($_GET[$request_name])){
            return $magic_quotes?stripslashes($_GET[$request_name]):$_GET[$request_name];
        }else{
            return $default_value;
        }
        break;
    case "get":
        if(isset($_GET[$request_name])){
            return $magic_quotes ? stripslashes($_GET[$request_name]) : $_GET[$request_name];
        }else{
            return $default_value;
        }
        break;
    case "post":
        if(isset($_POST[$request_name])){
            return $magic_quotes ? stripslashes($_POST[$request_name]) : $_POST[$request_name];
        }else{
            return $default_value;
        }
        break;
    default:
        return $default_value;
        break;
    }
}

/**
 * 获取网页内容
 * 
 * @param  String  支持GET和POST
 * @return Array   网页内容，报头，状态码，mime类型和编码 charset
 * $res_array = getResponse($url); // echo $res_array['body'];
 *
 */
function getResponse($url, $data = [], $cookie_file = ''){

    $url_array = parse_url($url);
    $host = $url_array['scheme'] . '://' . $url_array['host'];
    if(!empty($_SERVER['HTTP_REFERER'])) $refer = $_SERVER['HTTP_REFERER'];
    else $refer = $host . '/';
    if(!empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) $lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
    else $lang = 'zh-CN,zh;q=0.9';
    if(!empty($_SERVER['HTTP_USER_AGENT'])) $agent = $_SERVER['HTTP_USER_AGENT'];
    else $agent = 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.67 Safari/537.36';
    $agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.82 Safari/537.36';
    // $agent = 'Wget/1.18 (mingw32)'; # 'Wget/1.17.1 (linux-gnu)';
    // echo "<pre>\r\n" . $agent . "\r\n" . $refer . "\r\n" . $lang . "\r\n\r\n";
	
    if(empty($cookie_file)){
        $cookie_file = '.cookie';
    }
	
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_USERAGENT, $agent);
    curl_setopt($ch, CURLOPT_REFERER, $refer);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Accept-Language: " . $lang));
    if(!empty($data)){
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);   # 302 重定向
    curl_setopt($ch, CURLOPT_AUTOREFERER, true);      # 301 重定向

    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_file);  # 取cookie的参数是
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file); # 发送cookie
	
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 8);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($ch);
    curl_close($ch);
	
	# try{}catch{}语句
    // try{
    //     $handles = curl_exec($ch);
    //     curl_close($ch);
    //     return $handles;
    // }
    // catch(Exception $e){
    //     echo 'Caught exception:', $e -> getMessage(), "\n";
    // }
    // unlink($cookie_file);

    $res_array = explode("\r\n\r\n", $result, 2);
    $headers = explode("\r\n", $res_array[0]);
    $status = explode(' ', $headers[0]);
    # 如果$headers为空，则连接超时
    if(empty($res_array[0])) die('<br><br><center><b>连接超时</b></center>');
    # 如果$headers状态码为404，则自定义输出页面。
    if($status[1] == '404') die("<pre><b>找不到，The requested URL was not found on this server.</b>\r\n\r\n$res_array[0]</pre>\r\n\r\n");
    # 如果$headers第一行没有200，则连接异常。
    # if($status[1] !== '200') die("<pre><b>连接异常，状态码： $status[1]</b>\r\n\r\n$res_array[0]</pre>\r\n\r\n");\

    if($status[1] !== '200'){
        $body_array = explode("\r\n\r\n", $res_array[1], 2);
        $header_all = $res_array[0] . "\r\n\r\n" . $body_array[0];
        $res_array[0] = $body_array[0];
        $body = $body_array[1];
    }else{
        $header_all = $res_array[0];
        $body = $res_array[1];
    }

    $headers = explode("\r\n", $res_array[0]);
    $status = explode(' ', $headers[0]);
    
    $headers[0] = str_replace('HTTP/1.1', 'HTTP/1.1:', $headers[0]);
    foreach($headers as $header){
        if(stripos(strtolower($header), 'content-type:') !== FALSE){
            $headerParts = explode(' ', $header);
            $mime_type = trim(strtolower($headerParts[1]));
            //if(!empty($headerParts[2])){
            //    $charset_array = explode('=', $headerParts[2]);
            //    $charset = trim(strtolower($charset_array[1]));
            //}
        }
        if(stripos(strtolower($header), 'charset') !== FALSE){
            $charset_array = explode('charset=', $header);
            $charset = trim(strtolower($charset_array[1]));
        }else{
            $charset = preg_match("/<meta.+?charset=[^\w]?([-\w]+)/i", $res_array[1], $temp) ? strtolower($temp[1]):"";
        }
    }
    if(empty($charset)) $charset = 'utf-8';
    if(strstr($charset, ';')){
        $charset_array = '';
        $charset_array = explode(';', $charset);
        $charset = trim($charset_array[0]);
        //$charset = str_replace(';', '', $charset);
    }
    if(strstr($mime_type, 'text/html') and $charset !== 'utf-8'){
        $body = mb_convert_encoding ($body, 'utf-8', $charset);
    }
    # $body = preg_replace('/(?s)<meta http-equiv="Expires"[^>]*>/i', '', $body);    
    
    # echo "<pre>\r\n$header_all\r\n\r\n" . "$status[1]\r\n$mime_type\r\n$charset\r\n\r\n";
    # header($res_array[0]);

    $res_array = array();
    $res_array['header']    = $header_all;
    $res_array['status']    = $status[1];
    $res_array['mime_type'] = $mime_type;
    $res_array['charset']   = $charset;
    $res_array['body']      = $body;
    return $res_array;
}

# 获取url内容,返回字符串
function get_url_contents($url, $method, $stringData){
    $options_post = array(
        'http' => array(
            'method' => 'POST',
            'header' => 'Content-type:application/x-www-form-urlencoded;charset=UTF-8',
            'content' => $stringData   # 需要获取的内容
            ),
        "ssl" => array(
            "verify_peer" => false,
            "verify_peer_name" => false,
            )
        );

    $options_get = array(
        'http' => array(
            'method' => 'GET',
            'header' => "Accept-language: en\r\n" .
                        "Cookie: foo=bar\r\n" .  // check function.stream-context-create on php.net
                        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.82 Safari/537.36\r\n"
            ),
        "ssl" => array(
            "verify_peer" => false,
            "verify_peer_name" => false,
            )
        );

    $method = strtoupper(trim($method));
    if($method === 'GET') $options = $options_get;
    else $options = $options_post;
    $context = stream_context_create($options);

    set_error_handler(function($err_severity, $err_msg, $err_file, $err_line, array$err_context){
        throw new ErrorException($err_msg, 0, $err_severity, $err_file, $err_line);
    }, E_WARNING);
    try{
        $resource = file_get_contents($url, false, $context);
    }
    catch(Exception $e){
        $error = $e -> getMessage();
    }
    # restore the previous error handler 还原以前的错误处理程序
    restore_error_handler();

    if(!empty($error)) die("<pre><b>获取数据失败\r\n$error\r\n</b></pre>");
    else return $resource;

}

# UTF8转成HTML实体
function utf2html($str){
    $ret = "";
    $max = strlen($str);
    $last = 0;
    for ($i = 0;$i < $max;$i++){
        $c = $str[$i];
        $c1 = ord($c);
        if ($c1 >> 5 == 6){
            $ret .= substr($str, $last, $i - $last);
            $c1 &= 31;  # remove the 3 bit two bytes prefix
            $c2 = ord($str[++$i]);
            $c2 &= 63;
            $c2 |= (($c1 & 3) << 6);
            $c1 >>= 2;
            $ret .= "&#" . ($c1 * 0x100 + $c2) . ";";
            $last = $i + 1;
        }
        elseif ($c1 >> 4 == 14){
            $ret .= substr($str, $last, $i - $last);
            $c2 = ord($str[++$i]);
            $c3 = ord($str[++$i]);
            $c1 &= 15;
            $c2 &= 63;
            $c3 &= 63;
            $c3 |= (($c2 & 3) << 6);
            $c2 >>= 2;
            $c2 |= (($c1 & 15) << 4);
            $c1 >>= 4;
            $ret .= '&#' . (($c1 * 0x10000) + ($c2 * 0x100) + $c3) . ';';
            $last = $i + 1;
        }
    }
    $str = $ret . substr($str, $last, $i);
    return $str;
}

/**
 * 删除指定的标签和内容
 * @param array  $tags 需要删除的标签数组
 * @param string $str 数据源
 * @param boole  $content 是否删除标签内的内容 默认为false保留内容  true不保留内容
 * @return string
 */
function html_strip_tags($tags,$str,$content=false){
    $html=array();
    foreach ($tags as $tag) {
        if($content){
            $html[]='/(<'.$tag.'.*?>[\s|\S]*?<\/'.$tag.'>)/';
        }else{
            $html[]="/(<(?:\/".$tag."|".$tag.")[^>]*>)/i";
        }
    }
    $data=preg_replace($html, '', $str);
    return $data;
}

# 判断 $html 编码并转为 utf-8。
function html_get_charset($html){
    # 正则加 i 表示不区分大小写
    preg_match("'<meta.*?charset.*?=.*?\>'si", $html, $meta_charset);                 # 提取包含charset的 meta
    if(empty($meta_charset[0])) $meta_charset[0] = '';
    $meta_charset = preg_replace("/\r\n|\r|\n/", '', $meta_charset[0]);               # 删除回车和换行
    $meta_charset = preg_replace ("/\s(?=\s)/", "\\1", trim($meta_charset));          # 删除重复的空格
    $meta_charset = str_replace(array("= ", " =",), array("=", "=",), $meta_charset); # 删除=两侧的空格
    $meta_charset = str_replace(array("'", ' ', '>', '/', "\\",), array( '"', '"', '">', '', '',), $meta_charset);
    $meta_charset = preg_replace ("/\"(?=\")/", "\\1", trim($meta_charset));          # 删除重复的"
    $meta_charset = str_replace('"charset=', ' charset=', $meta_charset);
    // preg_match('~charset=([-a-z0-9_]+)~i', $meta_charset, $temp);
    // preg_match("/<meta.+?charset=[^\w]?([-\w]+)/i", $meta_charset, $temp);
    preg_match("'<meta.*?charset=(.+?)\".*?\>'si", $meta_charset, $temp);
    if(!empty($temp[1])) $charset = trim(str_replace('"', '', strtolower($temp[1])));
    elseif(extension_loaded('mbstring')) $charset = strtolower(mb_detect_encoding($html));
    else $charset = strtolower(chkcode($html));
    if(strstr($charset, 'gb2312')) $charset = 'GBK';
    return $charset;
}
 
# 判断charset
function chkcode($html){
    $code = array(
        'GBK',
        'EUC-CN',
        'BIG5',
        'EUC-TW',
        'CP950',
        'BIG5-HKSCS',
        'UTF-8',
        'GB2312',
        'CP936',
        'BIG5-HKSCS:2001',
        'BIG5-HKSCS:1999',
        'ISO-2022-CN',
        'ISO-2022-CN-EXT',
        'SJIS',
        'JIS',
        'EUC-JP',
        'SHIFT_JIS',
        'eucJP-win',
        'SJIS-win',
        'ISO-2022-JP',
        'CP932',
        'ISO-2022-JP',
        'ISO-2022-JP-2',
        'ISO-2022-JP-1',
        'EUC-KR',
        'CP949',
        'ISO-2022-KR',
        'JOHAB',
    );
     
    foreach($code as $charset){
        if($html == @iconv('UTF-8', "$charset//IGNORE//TRANSLIT", @iconv($charset, 'UTF-8//IGNORE//TRANSLIT', $html))){
            return $charset;
            break;
        }
    }
    return 'UTF-8';
}
