<?php
require __DIR__.'/libs/function.inc.php';

header('Content-type:text/html;charset=utf-8');

//私钥
$private_key = "-----BEGIN RSA PRIVATE KEY-----
MIICXQIBAAKBgQDbHqVytV9dnIrfCS9dzDVZz+qM6LtU46cdqbGvvX0Xz4CtsiT+
TqU3m8eC9BwTd0jY8bWjatYqEn716H77JcIJpmvO6ZJc4JYxvyJx6BEj6TQ4ZGYl
CA/wT08s9TKwd+PjkEht9A51hvCuUiyHPzMXAiL0a9tghPVd5rcDHlXb5wIDAQAB
AoGBANhrD2wZWYSi7cJWVxMkc3kuUvIzl3rDkrZIeXgjBp9y0hw8fC80zBf9Y3Oi
2Owc/7VOHmG2TqqlNAJ7TJePdnGvEG5yzHuMH6/uRPS4A+gDndM8U/sZBUYaZjbr
5M8vg6wL3yQ2awAbXu7pwLEvxVmuvhv+0jOFnqLpTRlki3ZpAkEA+Y00pTwikCEt
N+dkFGbhzZfH6bFNIkUOCrkDMgru1IargO/ggllk4fVLe7WBMWwh/0X9oTeTjLi7
Es856QMdpQJBAODIIeu7/cL3wp6Bigg7V25OSD+7uSjlCpoPSUNZIjZ6HJQsFCnU
RHsEDeD1f88g7i9AGI0htYiJXCgwd6GE9ZsCQGoCUhrfMM+JSGw3H4yLJ+DuWT4s
01d7fjuP3IulmU8u5iwfun+k+fYC/c3PjNIx3T9TvCqAMW3WC6Ix5afWawECQA6p
n2TUL3pvVPen9YwR6uMcIiReJ3becfGYu6uz/cJV9tVHhs0vtoPbwNgCy6KEQGU+
phtWrpPIegV5G+SiWq8CQQCoH+ic1j9b1DzENUb206w7KpcIhm629iUWUgBTrnlC
LzOA6xwY78V7cAUdzhTycAxhmWq/1FBlCCKtuZHVHnE/
-----END RSA PRIVATE KEY-----";

if(empty($_POST['url'])){
    die(html_form_enc());
    //header("Location:login.html");
    //exit;
}
$enc = trim($_POST['url']); //十六进制数据

# 合并16进制字串，检测是否合格
// $str_enc = str_replace(array(",", " ", "\r", "\n"), array("", "", "", ""), $enc);
// $str_enc = preg_replace('//s*/', '', $str_enc);
// $str_enc = preg_replace(array('/,/', '/ /'), '', $str_enc);
// if(!ctype_xdigit($str_enc)){
//     echo "行包含非16进制，可能无法解密而被丢弃";
// }

# 判断长度，是否被256整除
// if(!is_int($str_enc/256)) echo '数据可能有误';


$array_enc = explode(",", $enc);
$dec = '';
foreach($array_enc as $key => $chunk_enc){
    $chunk_enc = trim($chunk_enc);
    if(empty($chunk_enc)) continue;
    if(!ctype_xdigit($chunk_enc)){
        echo $key+1 ." 行包含非16进制，可能无法解密而被丢弃";
        continue;
    }
    $encrypt_data = @pack("H*", $chunk_enc);//对十六进制数据进行转换
    if(!is_int(strlen($chunk_enc)/256)){
        echo "十六进制编码后的字节长度: ". strlen($chunk_enc) ." --> 原密文的字节长度: ". strlen($encrypt_data) ."<br><br>\r\n";
    }
    openssl_private_decrypt($encrypt_data, $decrypt_data, $private_key);
    //$dec .= base64_decode($decrypt_data) ;
    $dec .= $decrypt_data;
}
if(empty($dec)) die("没有得到解密数据，可能解密失败");
echo "明文总字节: ". strlen($dec) ."<br><br>\r\n". $dec;
