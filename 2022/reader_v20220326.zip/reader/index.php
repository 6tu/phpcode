<?php
/**
 * PHP Readability
 * 
 * @date    2022-02-01
 * 
 */

session_start();
if ($_SERVER["HTTPS"] <> "on"){
    $xredir="https://".$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
    header("Location: ".$xredir);
}

date_default_timezone_set("Asia/Shanghai");

require __DIR__.'/depend/autoload.php';
require __DIR__.'/libs/function.inc.php';
require __DIR__.'/libs/beautify-html.php';

use fivefilters\Readability\Readability;
use fivefilters\Readability\Configuration;
use fivefilters\Readability\ParseException;

/* ---------------------- Readability配置 ---------------------- */

define("DIR_ROOT",   dirname(__FILE__));
define("URL_ROOT",   "/reader/");
define("DIR_CACHE",  DIR_ROOT . '/cache');
define("CACHE_TIME", 3600 * 24);
define('USER_AGENT', "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.67 Safari/537.36");

$options = array(
    'cleanConditionally'      => false,  // true，在解析后删除某些节点
    'maxTopCandidates'        => 5,      // 5  
    'charThreshold'           => 500,    // 500   
    'articleByLine'           => false,  // false 搜索文章的署名并将其从文本中移除
    'stripUnlikelyCandidates' => false,  // true  删除那些不太可能有相关信息的节点
    'weightClasses'           => true,   // true，在评级阶段对类进行加权
    'fixRelativeURLs'         => false,  // false 将相对的URLs转换为绝对的
    'substituteEntities'      => false,  // false 禁用libxml的substituteEntities标志
    'normalizeEntities'       => false,  // false 将UTF-8字符转换为其HTML实体等价物
    'originalURL'             => '',     // 文章中的原始URL，用于固定相对URL
    'summonCthulhu'           => false,  // false，通过regex删除所有<script>节点
);

/* ---------------------- 提交URL ---------------------- */

$cli = preg_match("/cli/i", php_sapi_name());
if($cli){
    # print_r($argv);
    if(!empty($argv[1])) $url = $argv[1];
    else{
        fwrite(STDOUT, "Enter url:");
        $url = trim(fgets(STDIN));
    }
}
//if(empty($_GET['url']) and !$cli) die(html_form());
//if(isset($_GET['url'])) $url = $_GET['url'];

if(empty($_POST['url']) and !$cli){

    echo(html_form_enc());
    ob_flush();
    flush();
    sleep(1);
    if(@$_GET["js"]){
        session_start();
        $_SESSION['js'] = $_GET["key"];
        file_put_contents('/home/reader/js.log', print_r($_GET, true));
    }else die("<noscript><br><b>**</b> 该页面需要Javascript才能使用，建议您启用Javascript <b>**</b></noscript>");
    ob_end_flush();
}

## ============ 设定User-Agent
$default_ua = "Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.82 Safari/537.36";

# 当前C端有UA
if(empty($_SERVER['HTTP_USER_AGENT'])) $current_ua = -1;
else $current_ua = $_SERVER['HTTP_USER_AGENT'];
if(strlen($current_ua) < 12) $current_ua = -1;

# C端选择 UA
if(empty($_POST["useragent_select"])) $ua = $current_ua;  // 当前UA
else if($_POST["useragent_select"] === 1){                // 自定义UA
    if(strlen($_POST["useragent_custom"]) < 12) $ua = -1;
    else $ua = $_POST["useragent_custom"];
}
else if($_POST["useragent_select"] === -1) $ua = -1;      // 无UA
else{
    $ua = $_POST["useragent_select"];                     // 选定设置的UA
    if(strlen($ua) < 12) $ua = -1;
}

if($ua === -1) $ua = $default_ua;
## ============ User-Agent设定结束

//print_r($_SESSION['js']);
//print_r($_REQUEST);
//exit;


$url = trim(getRequestParam("url", ""));
$output_type = strtolower(getRequestParam("type", "html"));
//echo "\r\n\r\n" . $url;

# 解密开始
//私钥
$private_key = "-----BEGIN RSA PRIVATE KEY-----
MIICXQIBAAKBgQDbHqVytV9dnIrfCS9dzDVZz+qM6LtU46cdqbGvvX0Xz4CtsiT+
TqU3m8eC9BwTd0jY8bWjatYqEn716H77JcIJpmvO6ZJc4JYxvyJx6BEj6TQ4ZGYl
CA/wT08s9TKwd+PjkEht9A51hvCuUiyHPzMXAiL0a9tghPVd5rcDHlXb5wIDAQAB
AoGBANhrD2wZWYSi7cJWVxMkc3kuUvIzl3rDkrZIeXgjBp9y0hw8fC80zBf9Y3Oi
2Owc/7VOHmG2TqqlNAJ7TJePdnGvEG5yzHuMH6/uRPS4A+gDndM8U/sZBUYaZjbr
5M8vg6wL3yQ2awAbXu7pwLEvxVmuvhv+0jOFnqLpTRlki3ZpAkEA+Y00pTwikCEt
N+dkFGbhzZfH6bFNIkUOCrkDMgru1IargO/ggllk4fVLe7WBMWwh/0X9oTeTjLi7
Es856QMdpQJBAODIIeu7/cL3wp6Bigg7V25OSD+7uSjlCpoPSUNZIjZ6HJQsFCnU
RHsEDeD1f88g7i9AGI0htYiJXCgwd6GE9ZsCQGoCUhrfMM+JSGw3H4yLJ+DuWT4s
01d7fjuP3IulmU8u5iwfun+k+fYC/c3PjNIx3T9TvCqAMW3WC6Ix5afWawECQA6p
n2TUL3pvVPen9YwR6uMcIiReJ3becfGYu6uz/cJV9tVHhs0vtoPbwNgCy6KEQGU+
phtWrpPIegV5G+SiWq8CQQCoH+ic1j9b1DzENUb206w7KpcIhm629iUWUgBTrnlC
LzOA6xwY78V7cAUdzhTycAxhmWq/1FBlCCKtuZHVHnE/
-----END RSA PRIVATE KEY-----";

# URL 是否需要解密
if(!$cli){
    $enc = $url;
    $array_enc = explode(",", $enc);
    $dec = '';
    foreach($array_enc as $key => $chunk_enc){
        $chunk_enc = trim($chunk_enc);
        if(empty($chunk_enc)) continue;
        if(!ctype_xdigit($chunk_enc)){
            echo "<head><meta http-equiv=\"refresh\" content=\"3;url=index.php\"></head>\r\n";
            echo "<body>\r\n<center><h2><br>". $key+1 ." 行包含非16进制，可能无法解密而被丢弃<br></h2></center>\r\n</body>";
            exit;
            continue;
        }
        $encrypt_data = @pack("H*", $chunk_enc);//对十六进制数据进行转换
        if(!is_int(strlen($chunk_enc)/256)){
            // echo "十六进制编码后的字节长度: ". strlen($chunk_enc) ." --> 原密文的字节长度: ". strlen($encrypt_data) ."<br><br>\r\n";
        }
        openssl_private_decrypt($encrypt_data, $decrypt_data, $private_key);
        //$dec .= base64_decode($decrypt_data) ;
        $dec .= $decrypt_data;
    }
    if(empty($dec)){
        echo "<head><meta http-equiv=\"refresh\" content=\"3;url=index.php\"></head>\r\n";
        echo "<body>\r\n<center><h2><br>没有得到解密数据，可能解密失败<br></h2></center>\r\n</body>";
        exit;
    }
    //echo "明文总字节: ". strlen($dec) ."<br><br>\r\n". $dec;
    else $url = trim($dec);
    # 解密结束
}


if(!filter_var($url, FILTER_VALIDATE_URL)){
    echo "<head><meta http-equiv=\"refresh\" content=\"3;url=index.php\"></head>\r\n";
    echo "<body>\r\n<center><h2><br>提交的网址没有通过过滤器验证<br>\r\n\"$url\"</h2></center>\r\n</body>";
    exit;
}

/* ----------------------  文件名 ---------------------- */

# 建立存储文件夹
$url_array = parse_url($url);
$host = $url_array['host'];
if(filter_var($host, FILTER_VALIDATE_IP)) $siteskey = $hosts;

$host_array = explode('.', $host);
$number = count($host_array);
$host_a2_1 = $host_array[$number-2];
$host_a2_2 = $host_array[$number-2] .'.'. $host_array[$number-1];

$domain_2level = array("ac", "biz", "co", "com", "edu", "gov", "info", "mil", "net", "org", );
$domain_2level_list = json_decode(file_get_contents(__DIR__.'/libs/domain-2level.json'));
// $host_2level_list = explode("\n", file_get_contents(__DIR__.'/libs/domain-2level.txt'));

if    (in_array($host_a2_1, $domain_2level))      $siteskey = $host_array[$number-3];
elseif(in_array($host_a2_2, $domain_2level_list)) $siteskey = $host_array[$number-3];
else $siteskey = $host_array[$number-2];

$dir_save = 'pages/'. $siteskey .'/';
if(!file_exists($dir_save)) mkdir(__DIR__.'/'.$dir_save, 0777, true);

# 提取文件名及扩展名
if(empty($url_array['path'])) $url_array['path'] = '/index.html';
$path_array = pathinfo($url_array['path']);
$fn = $path_array['basename'];
$fn_1 = $path_array['filename'];

$fn_1 = urldecode($fn_1);


if(isset($path_array['extension'])) $fn_ext = $path_array['extension'];
else $fn_ext = 'no';

# 建立新的文件名
if(4 < strlen($fn_1) and mb_strlen($fn_1) <= 16) $randkey = $fn_1;
else $randkey = rand_char($n=10);
$filename_save = date('YmdH').'-'.$randkey.'_'.$fn_ext.'.html';
$path_filename_save = $dir_save . $filename_save;

$url_hash = strtoupper(md5($url));
$url_cache_file = sprintf(DIR_CACHE . "/%s.bak", $url_hash);

/* ---------------------- 缓存请求数据，避免重复请求 ---------------------- */

if(file_exists($url_cache_file) && (time() - filemtime($url_cache_file) < CACHE_TIME)){
    $source = file_get_contents($url_cache_file);
}else{
    // $source = file_get_contents($url); 
    // $source = get_url_contents($url, $method='GET', $stringData='');
    $res_array = getResponse($url, $data = [], $cookie_file = '', $ua);
    $source = $res_array['body'];
    @file_put_contents($url_cache_file, $source);
}
if(strlen($source) < 100){
    if(file_exists($url_cache_file)) unlink($url_cache_file);
    echo html_form_enc() ."\r\n<small>取到的数据在utf-8编码中小于100字节，数据太小被丢弃</small><br>\r\n";
    die('<pre>'. htmlspecialchars($source) .'</pre>');
}

/* ----------------------  解析HTML内容 ---------------------- */

# 转为 UTF-8 之后，HTML 实体
$charset = html_get_charset($source);
if($charset !== 'utf-8'){
    if(extension_loaded('mbstring')) $source = mb_convert_encoding($source, 'UTF-8', $charset);
    elseif(extension_loaded('iconv')) $source = iconv($charset, 'UTF-8//IGNORE//TRANSLIT', $source);
    // else die("必需安装 mbstring 或者 iconv， 否则获取的文章乱码");
}
//$source = utf2html($source);

# 一些网站的 title 和文章标题不一致，需要从 title 中重新提取文章标题
$n = 4;
// preg_match_all('/<title>(.*)<\/title>/i', $source, $content);
preg_match_all("/<title[\s\S]*?>(.*)<\/title>/i", $source, $content);
$title = isset($content[1][0]) ? trim($content[1][0]) : ""; 
$title = str_replace(array("\r", "\n"), array("", ""), $title);
// echo $charset;print_r($content);echo $title;exit;

if(mb_strlen($title) < $n ){
    $title_key = $title;
    $article_title = $title;
}else{
    $title_key = mb_substr($title, 0, $n, "UTF8");
    $source_array = preg_split("/<body/i", $source, 2);
    if(empty($source_array[1]) or strpos($source_array[1], $title_key) == false){
        $article_title = $title;
    }else{
        $source1 = str_replace(array("\r", "\n"), array("", ""), '<body'. $source_array[1]);
        // $source1 = preg_replace("/<script*?<\/script>/i", "", $source1, -1);
        $source1 = str_replace("<", "\r\n<", $source1);
        $source1 = strip_tags($source1);
        $source1_array = explode("\r\n$title_key", $source1, 2);
        $source1_array2 = explode("\r\n", @$source1_array[1], 2);
        $article_title = $title_key . $source1_array2[0];
    }
}
$log_title = $n .' --> '. $title_key .' --> '. $article_title ."\r\n";

$options['originalURL'] = $url;
$config = new Configuration($options);
$readability = new Readability($config);

try{
    $readability -> parse($source);
    //echo $readability;
}catch(ParseException $e) {
    echo sprintf('Error processing text: %s', $e->getMessage());
}

switch($output_type){
case 'json':
    header("Content-type:text/json;charset=utf-8");
    $Data['url'] = $url;
    echo json_encode($Data);
    break;
case 'html':
    default:
    header("Content-type:text/html;charset=utf-8");
    $title = $readability -> getTitle();
    if(empty($article_title)) $article_title = $title;
    $content = $readability -> getContent();
    $content = str_replace("='/", '="/',  $content);
    $content = str_replace(array('src="//', 'href="//',), array('src="https://', 'href="https://',), $content);
    $content = str_replace(array('src="/', 'href="/',),   array('src="https://'. $host .'/', 'href="https://'. $host .'/',), $content);

    $html = html_head($title) . '<body><div id="article" class="margin-medium size-medium"><h2>' . $article_title . '</h2>' . $content;
    $html .= '</div><hr><div id="footer"><a href="'. strip_tags($url) .'"><b>'. $url .'</b></a></div><br><br></body></html>';

/* ----------------------  格式化HTML ---------------------- */

    $beautify = new Beautify_Html(array(
        'indent_inner_html'     => false,
        'indent_char'           => " ",
        'indent_size'           => 2,
        'wrap_line_length'      => 32786,
        'unformatted'           => ['code', 'pre'],
        'preserve_newlines'     => false,
        'max_preserve_newlines' => 32786,
        'indent_scripts'        => 'normal', // keep|separate|normal
        )
    );
    $html = $beautify -> beautify($html);
    file_put_contents($path_filename_save, $html);

    if(mb_strlen($article_title) > 44) $article_title = mb_substr($article_title, 0, 44, "UTF8") .' ... ';
    echo html_form_enc() . "\r\n<ul><li><a href=\"". $path_filename_save .'" target="_blank">'. $article_title .'</a></li><ul>';

    # 向远端传输该html文件
    ## 远端 url
    $url_get_remote = 'https://ca.liuyun.org/reader/sync-html.php?url=';
    
    ## 本地 html 文件的 url 不能设置为 localhost，要供远端访问
    $url_html_local = 'https://us.liuyun.org'. dirname($_SERVER['PHP_SELF']) .'/'. $path_filename_save;
    
    $sync_url = $url_get_remote . $url_html_local;
    
    $log = get_url_contents($sync_url, $method='GET', $stringData='');
    
    file_put_contents('logs/sync.log', $log."\r\n", FILE_APPEND);
}
