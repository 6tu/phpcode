cd /home/reader/sites/youtube/
yt-dlp  -f best --no-check-certificate  -o "%(upload_date)s-%(id)s.mp4" https://www.youtube.com/watch?v=9l5FYacUA90&format=mp4

# /usr/bin/ffmpeg -y  -i  -i  -c copy 
chown www-data:www-data *
