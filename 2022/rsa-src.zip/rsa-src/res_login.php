
<?php
define("CRT", "ssl/server.crt");  //公钥文件
define("PEM", "ssl/server.pem");  //私钥文件

//JS->PHP 测试，不支持汉字
$data = $_POST['password'];
$txt_en = base64_encode(pack("H*", $data));  //转成base64格式
$txt_de = privatekey_decodeing($txt_en, PEM, TRUE);
var_dump($txt_de);

//PHP->PHP 测试，支持汉字:D
$data = "测试TEST";
$txt_en = publickey_encodeing($data, CRT);
$txt_de = privatekey_decodeing($txt_en, PEM);
var_dump($txt_de);


/**
  * 公钥加密
  *
  * @param string 明文
  * @param string 证书文件（.crt）
  * @return string 密文（base64编码）
  */

function publickey_encodeing($sourcestr, $fileName)
{
    $key_content = file_get_contents($fileName);
    $pubkeyid = openssl_get_publickey($key_content);
    if (openssl_public_encrypt($sourcestr, $crypttext, $pubkeyid)) {
        return base64_encode("" . $crypttext);
    }
    return False;
}

/**
  * 私钥解密
  *
  * @param string 密文（base64编码）
  * @param string 密钥文件（.pem）
  * @param string 密文是否来源于JS的RSA加密
  * @return string 明文
  */

function privatekey_decodeing($crypttext, $fileName, $fromjs = FALSE)
{
    $key_content = file_get_contents($fileName);
    $prikeyid = openssl_get_privatekey($key_content);
    $crypttext = base64_decode($crypttext);
    $padding = $fromjs ? OPENSSL_NO_PADDING : OPENSSL_PKCS1_PADDING;
    if (openssl_private_decrypt($crypttext, $sourcestr, $prikeyid, $padding)) {
        return $fromjs ? rtrim(strrev($sourcestr), "/0") : "" . $sourcestr;
    }
    return FALSE;
}




?>


$(document).ready(function () {
  //十六进制公钥
  var rsa_n = "C34E069415AC02FC4EA5F45779B7568506713E9210789D527BB89EE462662A1D0E94285E1A764F111D553ADD7C65673161E69298A8BE2212DF8016787E2F4859CD599516880D79EE5130FC5F8B7F69476938557CD3B8A79A612F1DDACCADAA5B6953ECC4716091E7C5E9F045B28004D33548EC89ED5C6B2C64D6C3697C5B9DD3";
  $("#submit").click(function () {
    setMaxDigits(131); //131 => n的十六进制位数/2+3
    var key = new RSAKeyPair("10001", "", rsa_n); //10001 => e的十六进制
    var password = $("#password").val();
    password = encryptedString(key, password); //美中不足，不支持汉字~
    $("#password").val(password);
    $("#login").submit();
  });
});

http://bestmike007.com/2011/08/secure-data-transmission-between-pure-php-and-javascript-using-rsa/
https://github.com/phpseclib/phpseclib/tree/master/phpseclib
https://www.cnblogs.com/twilight-sam/p/5549121.html
https://cloud.tencent.com/developer/article/1805024
https://unpkg.com/browse/jsencrypt@3.2.1/bin/

http://travistidwell.com/jsencrypt/
https://github.com/cqingt

在线Rsa 公私钥分解 Exponent、Modulus，Rsa公私钥指数、系数(模数)分解
http://tool.chacuo.net/cryptrsakeyparse


https://github.com/travist/jsencrypt/issues/110


UrlEncode编码/解码





<?php


define("KEY_PRIVATE", "
-----BEGIN RSA PRIVATE KEY-----
MIICWwIBAAKBgQC6LHB0pVFfBSUkTtzQVXvX4ohF3M0jb/7JdTs3GJccf+VhYjII
dOmFFGrJFXAI459VbTuobG/yoCN5OOWs7NrCZvFQ3gS9u7RU2Mf7vK3So+hP56ij
WMMzVkmBwyKF9U6NQ4Q4NhUMIpe/8HA87eps1n2emxEbxrNanvSQi3c1VwIDAQAB
AoGAR/EWP60Gha5qTN6Aq6zs3161hDGvv8rubRD1IfRJqISvsfMNHIF5H6jlHvE+
yuCS2KMOU6YbmGlTa+uVrT4VxjKqDhvRoym4oOXdZURlr2hHsQjB5A20Ud6mh2dA
TpbXodxBHz9xA/KJanesFUipQMftzfjezDCSOtM/DwiqZ+ECQQDltR45mSpmK9/k
Izk76iQiQe3Elxvhu/FFo/g23fMk4dG2ZObUmTnGED81VOp8TqR9/WJ0NFHywoGy
J/sdZdORAkEAz3uxMWWsG0ywSb6tRuxr1zVBRPkzH3v0tuNxFl09dKq2HS4U2uAD
nXFnyseSpWEZB9asrH1+frYIFjxFSra2ZwJAL/kWeeMCFtp85NFyZ4/rwffQ52jD
mu48YlXvRc4utHow6Q3Do4zoovPLr6CvZAysj992S1yN7Mwwd/uflzEn8QJADRtX
OjOeB6t0h3QQJibROSsYEG9dl2ORNexwPGVveGtATd+XWaxFDjEXyWuKDAByQFiD
V/Ilh4OgRydPiUS5iQJAdSjhqtN1kz5nyiP8tYbmwxhMojLl7qSNkYJEarhml6Wy
gvInF7gsoOg/MUC8Ytgv+f93gi2aHGR/rn0ODRkqqg==
-----END RSA PRIVATE KEY-----
"); 

function privatekey_decodeing($crypttext, $fileName, $fromjs = FALSE)
{
    $key_content = file_get_contents($fileName);
    $prikeyid = openssl_get_privatekey($key_content);
    $crypttext = base64_decode($crypttext);
    $padding = $fromjs ? OPENSSL_NO_PADDING : OPENSSL_PKCS1_PADDING;
    if (openssl_private_decrypt($crypttext, $sourcestr, $prikeyid, $padding)) {
        return $fromjs ? rtrim(strrev($sourcestr), "/0") : "" . $sourcestr;
    }
    return FALSE;
}


?>




<script type="text/javascript" src="jsencrypt.js"></script>
<script>
function encrypt(msg) {
    var rsa = new JSEncrypt();
    rsa.setPublic('
-----BEGIN PUBLIC KEY-----MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC6LHB0pVFfBSUkTtzQVXvX4ohF3M0jb/7JdTs3GJccf+VhYjIIdOmFFGrJFXAI459VbTuobG/yoCN5OOWs7NrCZvFQ3gS9u7RU2Mf7vK3So+hP56ijWMMzVkmBwyKF9U6NQ4Q4NhUMIpe/8HA87eps1n2emxEbxrNanvSQi3c1VwIDAQAB-----END PUBLIC KEY-----
', '10001');
    return rsa.encrypt(msg);
}
</script>


<script>
function encrypt() {
    var rsa = new RSAKey();
    rsa.setPublic('8a5f4d4fa7dd78ca8539ba8b9581b30c9ce04e1998cd881d5279221984bc606e2c7d3368dc184b357507966a0f20930ba665cd9e914d6b0b67c8636ffe8cacfd', '10001');
    document.getElementById('enc_text').value = rsa.encrypt(document.getElementById('plaintext').value);
}
</script>
<form action="" method="post">
Plain Text:<br/>
<input id='plaintext' type="text" size="40" value="test"/><br/>
<input type="button" onclick="encrypt()" value="Encrypt"/><br/>
Encrypted Text:<br/>
<input id="enc_text" name='enc_text' type="text" size="40"/><br/>
<input name="submit" type="submit" value="Submit" size="10"/>
</form>














