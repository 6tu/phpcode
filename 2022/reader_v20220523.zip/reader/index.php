<?php

/**
 * PHP Readability
 * 
 * @date    2022-02-01
 * 
 */
set_time_limit(0);

require __DIR__.'/libs/function.inc.php';
require __DIR__.'/libs/beautify-html.php';

/* ---------------------- 通用配置 ---------------------- */

session_start();
date_default_timezone_set("Asia/Shanghai");

if ($_SERVER["HTTPS"] <> "on"){
    $xredir="https://".$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
    header("Location: ".$xredir);
}

# 用于同步HTML 的远端 url 及本地文件的URL
$url_remote = 'https://ca.liuyun.org/reader/sync-html.php?url=';
$url_self = get_url(); # 此文件的 url，由于供远端访问不能设置为 localhost
$url_local = pathinfo($url_self, PATHINFO_DIRNAME) .'/';

define("DIR_ROOT",   dirname(__FILE__));
define("URL_ROOT",   "/reader/");
define("DIR_SITES",  'sites/');
define("DIR_LOGS",   'logs/');
define("DIR_BIN",    DIR_ROOT . '/libs/bin/');
define("DIR_CACHE",  DIR_ROOT . '/cache');
define("CACHE_TIME", 3600 * 24);
define('USER_AGENT', "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.67 Safari/537.36");


require __DIR__.'/depend/autoload.php';
use fivefilters\Readability\Readability;
use fivefilters\Readability\Configuration;
use fivefilters\Readability\ParseException;

/* ---------------------- Readability配置 ---------------------- */
$options = array(
    'cleanConditionally'      => false,  // true，在解析后删除某些节点
    'maxTopCandidates'        => 5,      // 5  
    'charThreshold'           => 500,    // 500   
    'articleByLine'           => false,  // false 搜索文章的署名并将其从文本中移除
    'stripUnlikelyCandidates' => false,  // true  删除那些不太可能有相关信息的节点
    'weightClasses'           => true,   // true，在评级阶段对类进行加权
    'fixRelativeURLs'         => false,  // false 将相对的URLs转换为绝对的
    'substituteEntities'      => false,  // false 禁用libxml的substituteEntities标志
    'normalizeEntities'       => false,  // false 将UTF-8字符转换为其HTML实体等价物
    'originalURL'             => '',     // 文章中的原始URL，用于固定相对URL
    'summonCthulhu'           => false,  // false，通过regex删除所有<script>节点
);


/* ----------------------  使用命令行 ---------------------- */

$cli = preg_match("/cli/i", php_sapi_name());
if($cli){
    # print_r($argv);
    if(!empty($argv[1])) $url = $argv[1];
    else{
        fwrite(STDOUT, "Enter url:");
        $url = trim(fgets(STDIN));
    }
}
//if(empty($_GET['url']) and !$cli) die(html_form());
//if(isset($_GET['url'])) $url = $_GET['url'];

/* ----------------------  打印表单和检测script ---------------------- */

if(empty($_POST['url']) and !$cli){

    echo(html_form_enc());
    ob_flush();
    flush();
    sleep(1);
    if(@$_GET["js"]){
        session_start();
        $_SESSION['js'] = $_GET["key"];
        // file_put_contents('./logs/js.log', print_r($_GET, true));
    }else{
        $_SESSION["js"] = null;
        die("<noscript><br><center><b> 该页面需要Javascript才能使用，建议您启用Javascript </b></center></noscript>");
    }
    ob_end_flush();
}
if(empty($_SESSION["js"])) die(html_form_enc());

/* ----------------------  设定User-Agent ---------------------- */

$default_ua = "Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.82 Safari/537.36";

# 当前C端有UA
if(empty($_SERVER['HTTP_USER_AGENT'])) $current_ua = -1;
else $current_ua = $_SERVER['HTTP_USER_AGENT'];
if(strlen($current_ua) < 12) $current_ua = -1;

# C端选择 UA
if(empty($_POST["useragent_select"])) $ua = $current_ua;  // 当前UA
else if($_POST["useragent_select"] === 1){                // 自定义UA
    if(strlen($_POST["useragent_custom"]) < 12) $ua = -1;
    else $ua = $_POST["useragent_custom"];
}
else if($_POST["useragent_select"] === -1) $ua = -1;      // 无UA
else{
    $ua = $_POST["useragent_select"];                     // 选定设置的UA
    if(strlen($ua) < 12) $ua = -1;
}

if($ua === -1) $ua = $default_ua;


/* ----------------------  处理提交的URL ---------------------- */

//print_r($_SESSION['js']);
//print_r($_REQUEST);
//exit;

$url = trim(getRequestParam("url", ""));
$output_type = strtolower(getRequestParam("type", "html"));
//echo "\r\n\r\n" . $url;

# 解密开始
//私钥
$private_key = "-----BEGIN RSA PRIVATE KEY-----
MIICXQIBAAKBgQDbHqVytV9dnIrfCS9dzDVZz+qM6LtU46cdqbGvvX0Xz4CtsiT+
TqU3m8eC9BwTd0jY8bWjatYqEn716H77JcIJpmvO6ZJc4JYxvyJx6BEj6TQ4ZGYl
CA/wT08s9TKwd+PjkEht9A51hvCuUiyHPzMXAiL0a9tghPVd5rcDHlXb5wIDAQAB
AoGBANhrD2wZWYSi7cJWVxMkc3kuUvIzl3rDkrZIeXgjBp9y0hw8fC80zBf9Y3Oi
2Owc/7VOHmG2TqqlNAJ7TJePdnGvEG5yzHuMH6/uRPS4A+gDndM8U/sZBUYaZjbr
5M8vg6wL3yQ2awAbXu7pwLEvxVmuvhv+0jOFnqLpTRlki3ZpAkEA+Y00pTwikCEt
N+dkFGbhzZfH6bFNIkUOCrkDMgru1IargO/ggllk4fVLe7WBMWwh/0X9oTeTjLi7
Es856QMdpQJBAODIIeu7/cL3wp6Bigg7V25OSD+7uSjlCpoPSUNZIjZ6HJQsFCnU
RHsEDeD1f88g7i9AGI0htYiJXCgwd6GE9ZsCQGoCUhrfMM+JSGw3H4yLJ+DuWT4s
01d7fjuP3IulmU8u5iwfun+k+fYC/c3PjNIx3T9TvCqAMW3WC6Ix5afWawECQA6p
n2TUL3pvVPen9YwR6uMcIiReJ3becfGYu6uz/cJV9tVHhs0vtoPbwNgCy6KEQGU+
phtWrpPIegV5G+SiWq8CQQCoH+ic1j9b1DzENUb206w7KpcIhm629iUWUgBTrnlC
LzOA6xwY78V7cAUdzhTycAxhmWq/1FBlCCKtuZHVHnE/
-----END RSA PRIVATE KEY-----";

# URL 是否需要解密
if(!$cli){
    $enc = $url;
    $array_enc = explode(",", $enc);
    $dec = '';
    foreach($array_enc as $key => $chunk_enc){ 
        $key =intval($key)+1;
        $chunk_enc = trim($chunk_enc);
        if(empty($chunk_enc)) continue;
        if(!ctype_xdigit($chunk_enc)){
            echo "<head><meta http-equiv=\"refresh\" content=\"3;url=index.php\"></head>\r\n";
            echo "<body>\r\n<center><h2><br>第 ". $key ." 行包含非16进制，可能无法解密而被丢弃<br></h2></center>\r\n</body>";
            exit;
            continue;
        }
        $encrypt_data = @pack("H*", $chunk_enc);//对十六进制数据进行转换
        if(!is_int(strlen($chunk_enc)/256)){
            // echo "十六进制编码后的字节长度: ". strlen($chunk_enc) ." --> 原密文的字节长度: ". strlen($encrypt_data) ."<br><br>\r\n";
        }
        openssl_private_decrypt($encrypt_data, $decrypt_data, $private_key);
        //$dec .= base64_decode($decrypt_data) ;
        $dec .= $decrypt_data;
    }
    if(empty($dec)){
        echo "<head><meta http-equiv=\"refresh\" content=\"3;url=index.php\"></head>\r\n";
        echo "<body>\r\n<center><h2><br>没有得到解密数据，可能解密失败<br></h2></center>\r\n</body>";
        exit;
    }
    //echo "明文总字节: ". strlen($dec) ."<br><br>\r\n". $dec;
    else $url = trim($dec);
    # 解密结束
}

if(strpos($url, '://') === false) $url = 'http://' . $url;

if(!filter_var($url, FILTER_VALIDATE_URL)){
    echo "<head><meta http-equiv=\"refresh\" content=\"3;url=index.php\"></head>\r\n";
    echo "<body>\r\n<center><h2><br>提交的网址没有通过过滤器验证<br>\r\n\"$url\"</h2></center>\r\n</body>";
    exit;
}

/* ----------------------  建立存储文件夹 ---------------------- */
# 替换谷歌的AMP
$amp = 'https://www.google.com/amp/s/';
if(strstr($url, $amp)){
    $amp_url = pathinfo($url);
    $url = str_replace($amp, 'https://', $amp_url['dirname']);
    if($amp_url['basename'] !== 'amp') $url .= '/'. $amp_url['basename'];
}

$url_array = parse_url($url);
$host = $url_array['host'];
if(filter_var($host, FILTER_VALIDATE_IP)) $siteskey = crc32($host);// md5($host);
else{
    $host_array = explode('.', $host);
    $number = count($host_array);
    $host_a2_1 = $host_array[$number-2];
    $host_a2_2 = $host_array[$number-2] .'.'. $host_array[$number-1];
    
    $domain_2level = array("ac", "biz", "co", "com", "edu", "gov", "info", "mil", "net", "org", );
    $domain_2level_list = json_decode(file_get_contents(__DIR__.'/libs/domain-2level.json'));
    // $host_2level_list = explode("\n", file_get_contents(__DIR__.'/libs/domain-2level.txt'));
    
    if    (in_array($host_a2_1, $domain_2level))      $siteskey = $host_array[$number-3];
    elseif(in_array($host_a2_2, $domain_2level_list)) $siteskey = $host_array[$number-3];
    else $siteskey = $host_array[$number-2];
}
$site_dir = DIR_SITES. $siteskey .'/';
if(!file_exists($site_dir)) mkdir(__DIR__.'/'.$site_dir, 0777, true);

/* ----------------------  建立新的文件名 ---------------------- */

# 提取文件名及扩展名
if(empty($url_array['path'])) $url_array['path'] = '/';
$path_array = pathinfo($url_array['path']);

$url_base64 = base64_encode($url);
// $fn_key = substr(strrev($url_base64), 2, 12);
$fn_key = str_pad(crc32($url), 10, '0'); # CRC32输出长度: 8-9-10位
$html_fn = date('Ymd') .'-'. $fn_key .'.html';
$html_fn_path = $site_dir . $html_fn;

$url_hash = strtoupper(md5($url));
$url_cache_file = sprintf(DIR_CACHE . "/%s.bak", $url_hash);

# cookie_jar 应该和 SEESION关联
if(!file_exists('./tmp')) mkdir('./tmp', 0777, true);
$cookie_jar = __DIR__ . '/tmp/'. md5($url_array['host']) .'.cookie';
if(file_exists($cookie_jar) == false) file_put_contents($cookie_jar, '');

/* ----------------------  下载youtube视频 ---------------------- */

// 134 360p,135 480p,136 720p, mp4_dash
// $url = 'https://www.youtube.com/watch?v=HojapkfJPVg';
if(strpos(strtolower($host), 'youtube.com') !== false){
    
    # 获取youtube的ID
    $ytb_array = youtube_id($url);
    if(empty($ytb_array['v'])){
        echo html_form_enc();
        echo '<ul><li> 错误的网址</li></ul>';
        exit;
    }else $ytb_id = trim($ytb_array['v']);
    
/* ************* 本地文件处理 ************* */

    # 缓存文件存在，且记录的错误信息
    if(file_exists($url_cache_file)){
        $info = file_get_contents($url_cache_file);
        if(strpos(strtolower($info), '<h2>资源获取失败</h2>') !== false){
            $array_info = explode('<body>', $info, 2);
            echo html_form_enc();
            die($array_info[1]);
        }
    }
    # 根据ID搜索本地存在的文件
    $ytb_fn_array = file_search($site_dir, $ytb_id);
    $ytb_fn = 'Not-found';
    $ytb_info = '';
    foreach($ytb_fn_array as $ytb_fn){
        if(strstr($ytb_fn, '.f248.') or strstr($ytb_fn, '.f251.')) continue;
        if(strstr($ytb_fn, '.webm') or strstr($ytb_fn, '.mp4')){
            $ytb_path = $site_dir . $ytb_fn;
            $ytb_info .= '<ul><li>存在的视频 <a href="'.$ytb_path.'">'.$ytb_fn.'</a></li></ul>';
            $media = 1;
        }
        if(strstr($ytb_fn, '.html')){
            $ytb_path = $site_dir . $ytb_fn;
            $ytb_info .= '<ul><li>相关的HTML <a href="'.$ytb_path.'">'.$ytb_fn.'</a></li></ul>';
            $text = 1;
        }
    }
    
    # 如果没有相关的media只有HTML，则删除相关的HTML及缓存文件
    if(empty($media) and !empty($text)){
        if(file_exists($url_cache_file)) unlink($url_cache_file);
        unlink($site_dir . $ytb_fn);
    }

    # 如果在本地找到相关的文件，则直接打印
    if(isset($ytb_path) and file_exists($ytb_path)){
        echo html_form_enc();
        echo $ytb_info;
        exit;
    }

/* ************* 本地文件处理结束 ************* */

    $ytb_url = 'https://www.youtube.com/watch?v='. $ytb_id;
    
    if(!file_exists($url_cache_file)){
        $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36';
        $ytb_html_array = getResponse($ytb_url, $data = [], $cookie_jar, $ua);
        $ytb_html = $ytb_html_array['body'];
        $header = $ytb_html_array['header'];
        $mime   = $ytb_html_array['mime_type'];
        $status = $ytb_html_array['status'];
        
        preg_match_all("/<title[\s\S]*?>(.*?)<\/title>/is", $ytb_html, $ytb_title);
        $title = isset($ytb_title[1][0]) ? trim($ytb_title[1][0]) : "";
        $title = preg_replace("/\r\n|\r|\n/", '', $title);

        if($status != 200 or strlen($title) < 10){
            echo html_form_enc();
            $error_title = '资源获取失败';
            $error_head = html_head($error_title) . "  <body>\r\n";
            $error_info = "<h2>'.$error_title.'</h2>\r\n<li>$url</li><br>\r\n";
            if($status != 200) $error_info .= "<li>HTTP 状态码 是 <b>$status</b><br></li>\r\n";
            if(strlen($title)<10) $error_info .= "<li>可能网址有误，获取不到有效的 TITLE</li>";
            @file_put_contents($url_cache_file, $error_head.$error_info);
            die($error_info);
        }
        @file_put_contents($url_cache_file, $ytb_html);

        $ytb_array = youtube_info($ytb_html);
        $ytb_html_fn = str_replace("-","",$ytb_array['uploadDate']) .'-'. $ytb_id .'.html';
        $ytb_html_path = $site_dir . $ytb_html_fn;
        $ytb_head = html_head($ytb_array['title']) . "  <body>\r\n$url<pre>\r\n";
        file_put_contents($ytb_html_path, $ytb_head.print_r($ytb_array, true));
    }

# 下载命令
    if(isset($ytb_array['format']) and trim($ytb_array['format']) == 'mp4') $ytb_format = '';
    else $ytb_format = '';
    $cmd_dl ="bash ". DIR_BIN. 'ytb.sh ' . $ytb_url . ' '. $ytb_format;
    
# 视频和音频合并命令
    unset($ytb_fn_array);
    $ytb_fn_array = file_search($site_dir, $ytb_id);
    $video_name = '';
    $audio_name = '';
    foreach($ytb_fn_array as $ytb_fn){
        if(strstr($ytb_fn, '.f248.')) $video_name = './'.$ytb_fn;
        if(strstr($ytb_fn, '.f251.')) $audio_name = './'.$ytb_fn;
    }
    if(!empty($video_name)) $out_name = substr($video_name, 0, strpos($video_name, '.f248')) .'.webm';
    else $out_name = '';
    $ffmpeg_bin = "/usr/bin/ffmpeg -y ";
    $ffmpeg_para1 = " -i ". $video_name;
    $ffmpeg_para2 = " -i ". $audio_name;
    $ffmpeg_para3 = " -c copy -map 0:v:0 -map 1:a:0 ";
    $ffmpeg_para3 = " -c copy ";
    $ffmpeg_para4 = $out_name;
        
    $para4_merge = ' --ffmpeg-location --merge-output-format';
    $para4_merge = ' --ffmpeg-location "/usr/bin/ffmpeg" --merge-output-format webm';
    $para4_merge = '';
    
    $cmd_merge = $ffmpeg_bin.$ffmpeg_para1.$ffmpeg_para2.$ffmpeg_para3.$ffmpeg_para4;

    chdir(__DIR__.'/'.$site_dir);
    exec($cmd_dl, $out_dl_array, $ret); // shell_exec()
    chdir(__DIR__);
    
    if($ret === 0){
        echo html_form_enc();
        echo "<pre>将下载视频资源\r\n\r\n";
        // print_r($out_dl_array);
        echo '<ul><li><a href="'.$ytb_path.'">'.$ytb_fn.'</a></li></ul>';
        exit;
    }else{
        echo html_form_enc();
        die('下载资源失败');
    }
}

/* ---------------------- 缓存请求数据，避免重复请求 ---------------------- */

if(file_exists($html_fn_path)){
    echo html_form_enc();
    
    $fp = fopen($html_fn_path, 'r');
    fseek($fp, 440, SEEK_CUR);
    $title = str_replace(array('<title>', '</title>',), '', fgets($fp));
    if(mb_strlen($title) > 30) $title = mb_substr($title, 0, 25, "UTF8") .' ... ';
    if(empty(trim($title))) $title = $html_fn;
    echo "<ul><li><a href=\"". $html_fn_path .'" target="_blank">'. $title .'</a></li><ul>';
    exit;
}

if(file_exists($url_cache_file) && (time() - filemtime($url_cache_file) < CACHE_TIME)){
    $source = file_get_contents($url_cache_file);
}else{
    $res_array = getResponse($url, $data = [], $cookie_jar, $ua);
    $source = $res_array['body'];
    $header = $res_array['header'];
    $mime = $res_array['mime_type'];
    $status = $res_array['status'];

    # cloudflare 云盾
    if(strpos(strtolower($source), 'please wait... | cloudflare') !== false or trim($status) == '403'){
        $cmd = 'python3 /home/reader/libs/bin/spider.py '. $url;
        exec($cmd, $array);
        $status  = $array[0];
        $charset = $array[1];
        $mime    = $array[2];
        $header  = $array[3];
        unset($array[0]);
        unset($array[1]);
        unset($array[2]);
        unset($array[3]);
        
        //echo "<pre>". $status ."\r\n". $charset ."\r\n". $mime ."\r\n".  $header;
        $header = str_replace('"', '\\"', $header);
        $header = str_replace("'", '"', $header);
        // $header = stripslashes(html_entity_decode($header));
        $header = json_decode($header,true);
        if(isset($header['Set-Cookie'])) $cookie  = $header['Set-Cookie'];
        $source = join("\r\n", $array);
        if(strstr($mime, 'text/html') and $charset !== 'utf-8'){
            $source = mb_convert_encoding ($source, 'utf-8', $charset);
        }
    }

    if(strpos(strtolower($mime), 'html') !== false){
        @file_put_contents($url_cache_file, $source);
    }else{
        $fn = $path_array['basename'];
        $fn = date('Ymd') .'-'. $fn_key;
        if(empty($path_array['extension']))$fn .= '.'. mime2ext($mime);
        else $fn .= '.'. $path_array['extension'];
        if(strstr($fn, '.php')) $fn .= 's';
        if(strtolower($path_array['extension']) == 'php') $fn .= 's';
        $nohtml_path = $site_dir . urldecode($fn);
        @file_put_contents($nohtml_path, $source); // 非HTML文件另行保存
        # 非HTML文件同时保一份它的header到$url_cache_file做检索
        $nohtml_link = "源文件: <a href=".$nohtml_path.">".$fn."</a>";
        $nohtml_header = "<br><pre><small>\r\n". print_r($header, true)."\r\n\r\n</small></pre>";
        @file_put_contents($url_cache_file, $nohtml_link.$nohtml_header);
        sleep(2);
    }
}

if(empty($mime)) $mime = mime_content_type($url_cache_file); # 判断文件的MIME类型
$cache = file_get_contents($url_cache_file);
$mark = mb_substr($cache, 0, 4, 'UTF-8');
if(strstr($mark, "源文件")) {
    echo html_form_enc();
    die("<br>\r\n". $cache);
}
if(!strstr($mime, 'html')){
    echo html_form_enc();
    //die("<br>\r\n不是HTML文件，请刷新再试<pre>$mime");
}
if(strlen($source) < 500){
    echo html_form_enc();
    die("fetch的数据如下<br>\r\n". htmlspecialchars($source, FALSE));
}

/* ----------------------  解析HTML内容 ---------------------- */

# getResponse() 已经将字符串转为 UTF-8编码，之后用utf2html($source)转为HTML 实体

# ================  从 title 中提取并更改文章标题

$n = 10;
preg_match_all("/<title[\s\S]*?>(.*?)<\/title>/is", $source, $title_matches);
$title = empty($title_matches[1][0]) ? "标题等待完善^&^" : trim($title_matches[1][0]);
$title = preg_replace("/\r\n|\r|\n|\t/", '', $title);

if(mb_strlen($title) < $n) $title_key = $title;
else $title_key = mb_substr($title, 0, $n, "UTF-8");

$source_array = preg_split("/<\/head>/i", $source, 2);
if(strpos(strtolower($source_array[1]), '<body') == false) $source = str_replace("</head>", "</head>\r\n<body>", $source);

$search = array(
        "'<script[^>]*?>.*?</script>'si",     # 去掉javascript
        "'<style[^>]*?>.*?</style>'si",       # 去掉css
        );
$replace = array("", "",);
$source_array[1] = preg_replace($search, $replace, $source_array[1]);
$source_array[1] = preg_replace('#<(img|image)[^>]*?>#si', '', $source_array[1]);

if(strpos($source_array[1], $title_key) !== false){
    $temp_array_1 = explode($title_key, $source_array[1], 2);
    $title_body = mb_substr($title_key.$temp_array_1[1], 0, mb_strlen($title));
    $article_title =longest($title_body, $title);
}
//echo $article_title;

if(empty($article_title)) $article_title = $title;
//unset($title_matches);
//echo "<pre>\r\n$title\r\n$title_key\r\n$article_title\r\n"; echo print_r($title_matches, true);

# 删除附加的多媒体文件，主要是<picture>下面的 source 标签
$source = strip_html_tags(array('source'), $source);
# 删除<noscript>标签，不删除标签内容
$source = preg_replace("/<noscript>|<\/noscript>/", '', $source);
# ================  Readability 提取文章
$options['originalURL'] = $url;
$config = new Configuration($options);
$readability = new Readability($config);

try{
    $readability -> parse($source);
    // echo $readability;
}catch(ParseException $e) {
    echo sprintf('Error processing text: %s', $e->getMessage());
    echo sprintf('处理文本时出错: %s', $e->getMessage());
}

switch($output_type){
case 'json':
    header("Content-type:text/json;charset=utf-8");
    $Data['url'] = $url;
    echo json_encode($Data);
    break;
case 'html':
    default:
    // header("Content-type:text/html;charset=utf-8");
    // $title = $readability -> getTitle();
    $content = $readability -> getContent();
    $content = str_replace("='/", '="/',  $content);
    $content = str_replace(array('src="//', 'href="//',), array('src="https://', 'href="https://',), $content);
    $content = str_replace(array('src="/', 'href="/',),   array('src="https://'. $host .'/', 'href="https://'. $host .'/',), $content);
}


# 如果$html前面几行存在$article_title，则$article_title为空
    $article_100 = mb_substr($content, 0, mb_strlen($article_title) + 100);
    if(strpos($article_100, '<h2>'.$article_title) !== false) $article_title = '';

    $html = html_head($title) . '<body><div id="article" class="margin-medium size-medium"><h2>' . $article_title . '</h2>' . $content;
    $html .= '</div><hr><div id="footer"><a href="'. strip_tags($url) .'"><b>'. $url .'</b></a></div><br><br></body></html>';
    $html = str_replace('<h2></h2>', '', $html);

/* ----------------------  处理超链接，下载相关图片 ---------------------- */

$images = array('bmp', 'png', 'jpg', 'jpeg', 'ico', 'webp', 'gif', 'svg', 'tiff', 'avif');

$img_dir = $site_dir .'article_images/';
if(!file_exists($img_dir)) @mkdir(__DIR__ .'/'. $img_dir, 0777, true);

$link = preg_htmllink($html);
foreach($link as $uri){
    $uri = trim($uri);
    if(strstr($uri, '.css')) continue;
    $url_html = relative_to_absolute_url($url, $uri); # 相对链接转为完整的URL
    $html = str_replace($uri, $url_html, $html);      # 替换
    
    extract(parse_url($url_html)); # 返回变量: $scheme, $host, $path
    if(empty($path)) $path = '/';
    if(substr($path, -1) === '/') continue;
    $path_info = pathinfo($path);
    // if(empty($path_info['extension'])) $ext = ''; else $ext = $path_info['extension'];
    empty($path_info['extension']) ? $ext = '' : $ext = strtolower($path_info['extension']);
    if(empty($ext) or in_array($ext, $images, true)){
        $img_url_md5 = substr(md5($url_html), 8, 16);
        $img_fn = date('Ymd') .'-'. $img_url_md5 .'.'. $ext;
        $img_save = $img_dir . $img_fn;
        $img_url = './article_images/'. $img_fn;
        if(file_exists($img_save)){
            $html = str_replace($url_html, $img_url, $html);
            //continue;
        }
//echo$url_html.' => '.$img_url."<br>";
        $img_array = getResponse($url_html, $data = [], $cookie_file = $cookie_jar, $ua);
        $img_source = $img_array['body'];
        $header = $img_array['header'];
        $mime = $img_array['mime_type'];
        $status = $img_array['status'];
    # cloudflare 云盾
    if(strpos(strtolower($img_source), 'please wait... | cloudflare') !== false or trim($status) == '403'){
        $cmd = 'python3 /home/reader/libs/bin/get_img.py '. $url_html .' '. $fn_key .'.jpg';
        exec($cmd, $array_img);
        //$header = join("\r\n", $array_img[0]);
        $mime = trim($array_img[0]);
        $status = trim($array_img[1]);
        if($status == 'True') $img_source = file_get_contents($fn_key .'.jpg');
    }
        foreach($images as $ext){
            # mime中包含bmp/png/jpeg/ico/webp/gif/svg/tiff
            if(strstr($mime, $ext)){
                if($ext == 'jpeg') $ext = 'jpg';
                $img_fn = date('Ymd') .'-'. $img_url_md5 .'.'. $ext;
                
                $img_save = $img_dir . $img_fn;
                $img_url = './article_images/'. $img_fn;
                if(!file_exists($img_save)) file_put_contents($img_save, $img_source);
                $html = str_replace($url_html, $img_url, $html);
            }
        }
    }
}

/* ----------------------  格式化HTML并保存 ---------------------- */

$beautify = new Beautify_Html(array(
    'indent_inner_html'     => false,
    'indent_char'           => " ",
    'indent_size'           => 2,
    'wrap_line_length'      => 32786,
    'unformatted'           => ['code', 'pre'],
    'preserve_newlines'     => false,
    'max_preserve_newlines' => 32786,
    'indent_scripts'        => 'normal', // keep|separate|normal
    )
);
$html = $beautify -> beautify($html);
file_put_contents($html_fn_path, $html);

/* ----------------------  打印超链接到浏览器 ---------------------- */

if(mb_strlen($article_title) > 50) $article_title = mb_substr($article_title, 0, 50, "UTF8") .' ... ';
echo html_form_enc();
echo "<ul><li><a href=\"". $html_fn_path .'" target="_blank">'. $article_title .'</a></li><ul>';

/* ----------------------  向远端传输该html文件 ---------------------- */

$url_local_html = $url_local.$html_fn_path;
$sync_url = $url_remote . $url_local_html;
$log = get_url_contents($sync_url, $method='GET', $stringData='');
// file_put_contents('logs/sync.log', $log."\r\n", FILE_APPEND);


