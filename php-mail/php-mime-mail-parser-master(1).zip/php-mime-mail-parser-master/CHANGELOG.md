####v1.0.7

[FIX] getMessageBody does not handle Content-disposition inline [#11](https://github.com/message/php-mime-mail-parser/pull/11) 

####v1.0.6

[FIX] try content-name if disposition-filename isn't set [#6](https://github.com/message/php-mime-mail-parser/pull/6) 

####v1.0.5

[ENHANCEMENT] Added `Attachment` usage example to documentation [#5](https://github.com/message/php-mime-mail-parser/pull/5) 

####v1.0.4

[FIX] Some private methods changed to protected. Fixed attechment stream 2028 characters issue [#4](https://github.com/message/php-mime-mail-parser/pull/4) 

####v1.0.3

[FIX] Added parts variable. Variable was not declared which can lead to annoying error messages in logs [#3](https://github.com/message/php-mime-mail-parser/pull/3) 

[FIX] Removed unused pivate `getPartHeader()` method

####v1.0.2

[FEATURE] Added required extensions to composer [#2](https://github.com/message/php-mime-mail-parser/pull/2) 

####v1.0.1

[FIX] Corrects an issue with getting the 'text' body in some instances [#1](https://github.com/message/php-mime-mail-parser/pull/1) 
