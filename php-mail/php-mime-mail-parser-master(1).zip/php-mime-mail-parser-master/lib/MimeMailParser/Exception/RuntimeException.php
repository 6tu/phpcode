<?php

namespace MimeMailParser\Exception;

class RuntimeException extends \RuntimeException
{
	
}