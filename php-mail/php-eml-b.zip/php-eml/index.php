<?php

/*

File Name:  Index.php
Purpose:    Display the mailing list archive 

Author:     Gareth Rushgrove
Version:    0.1a

Note that this file is part of the Sourceforge project php-eml and is licenced under the GNU GPL. For more details see www.php-eml.com

Note also that this project is currently in alpha. This probably means that its worked somewhere but your mileage may vary.

*/

// require function library

require('maillist.fnc.php');

// require rss class

require('classes/rssgenesis.class.php');

// create rss file

include('rss.inc.php');

// configuration parameters

// folder where posts are stored

$post_folder = '/www/htdocs/maillist/posts';

$directory = opendir($post_folder);

// page header

include('includes/header.inc');

// are we on the home page or looking at an individual post?

if (isset($_GET['post'])) {

	// we are on an individual page

	$currentpost = urldecode($_GET['post']);

	// make breadcrumb list

	echo '<h2><a href="index.php">Home</a> > ';

	echo $currentpost;

	echo '</h2>';

} else {

	// the home page content

	include('includes/content.inc');

}

echo '</div>'; // end header layer from header.inc file

// if post variable set then we are looking at a specific post, if not we are on the home page

if (isset($_GET['post'])) {

	$current_post = urldecode($_GET['post']);

	while (false !== ($file = readdir($directory))) {
	
		// find file that matches the selected post
	
		if(is_file("$post_folder/$file") && $file == $current_post) {

			// get date info from file

			$last_modified = filemtime("$post_folder/$file");
			$date = date("d/m/y", $last_modified);
			
			// retrieve the name, email and content from the file and place in an array 
			
			$details = getNameEmailContent($file, $post_folder);

			$output .= '<div class="post"><div class="date">' . $date . '</div><h3>' . $file . '</h3><span class="name">' . $details['name'] . '</span>' . $details['content'] . '</div>';
			
			echo $output;

		}
		
	}	

} else {	// we are on the home page

	while (false !== ($file = readdir($directory))) {
		
		if(is_file("$post_folder/$file")) {	
	
			$last_modified = filemtime("$post_folder/$file");
			$date = date("d/m/y", $last_modified);
	
			// url encode the file name for the link and remove the NNM tags for display
	
			$file_en = urlencode($file);
			$file_small = str_replace(' [NNM] ','',$file);
			$file_small = str_replace('RE:','Re:',$file_small);
			
			// retrieve the name, email and content from the file and place in an array 
			
			$details = getNameEmailContent($file, $post_folder);
	
			// are we dealing with a response or a top level post
	
			if (substr($file,0,3) == 'Re:' | substr($file,0,3) == 'RE:' ) {

				$output .= "<div class=\"listresponse\">\n<span class=\"date\">\n$date\n</span>\n<span class=\"name\">$details[name]</span><h4>\n<a href=\"$_SERVER[PHP_SELF]?post=$file_en\">$file_small</a>\n</h4>\n";

			} else {
	
				$output .= "<div class=\"listpost\">\n<span class=\"date\">\n$date\n</span>\n<span class=\"name\">$details[name]</span><h4>\n<a href=\"$_SERVER[PHP_SELF]?post=$file_en\">$file_small</a>\n</h4>\n";

			}

			

			$output .= "</div>";
		
			// place the post output into an array
		
			$array_of_posts[$last_modified] = $output;
		
			// clear the output buffer
		
			$output = '';

		}
	}

	// sort by the key which happens to be the timestamp, so we get them in order
	
	ksort($array_of_posts, SORT_NUMERIC);

	// reverse the order of the posts so we get last in first out, most current posts at the top

	$array_of_posts_reversed = array_reverse($array_of_posts);

	// display the posts

	foreach ($array_of_posts_reversed as $post) {
		echo $post;
	}



}

closedir($directory);	

// include footer

include('includes/footer.inc');

?>