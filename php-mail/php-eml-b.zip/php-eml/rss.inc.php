<?php

$rss = new rssGenesis();

$rss->setChannel (	'newcastlenewmedia.org', // Title	'http://newcastlenewmedia.org', // Link	'Local web design and development musings and discussion.', // Description	null, // Language	'Gareth Rushgrove', // Copyright	'Gareth Rushgrove', // Managing Editor	'Gareth Rushgrove', // WebMaster	null, // Rating	"auto", // PubDate	"auto", // Last Build Date	null, // Docs	null, // Skip Days	null // Skip Hours);

$post_folder = '/www/htdocs/maillist/posts';

$directory = opendir($post_folder);

while (false !== ($file = readdir($directory))) {
    
    if(is_file("$post_folder/$file")) {	

    	$last_modified = filemtime("$post_folder/$file");
    	$date = date("d/m/y", $last_modified);

    	// url encode the file name for the link and remove the NNM tags for display

    	$file_en = urlencode($file);
    	$file_small = str_replace(' [NNM] ','',$file);
    	$file_small = str_replace('RE:','Re:',$file_small);
    	
    	// retrieve the name, email and content from the file and place in an array 
    	
    	$details = getNameEmailContent($file, $post_folder);

        $output['date'] = $date;
        $output['name'] = $details['name'];
        $output['content'] = $details['content'];
        $output['title'] = $file_small;
        $output['link'] = 'http://www.newcastlenewmedia.org/?post=' .$file_en;
        
    	// place the post output into an array
    	$array_of_posts[$last_modified] = $output;
    
    	// clear the output buffer
    	$output = '';

    }
}

// sort by the key which happens to be the timestamp, so we get them in order

ksort($array_of_posts, SORT_NUMERIC);

// reverse the order of the posts so we get last in first out, most current posts at the top

$array_of_posts_reversed = array_reverse($array_of_posts);

$array_of_posts_reversed = array_slice($array_of_posts_reversed,0,15);

// display the posts

foreach ($array_of_posts_reversed as $post) {
    
    $rss->addItem (        $post['title'], // Title        $post['link'], // Link        $post['content'] // Description    );
    
}

$rss->createFile ('/www/htdocs/maillist/rss/nnm.rss');

closedir($directory);	

?>