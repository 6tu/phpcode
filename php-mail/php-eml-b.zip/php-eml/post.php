#!/bin/php
<?php

/*

File Name:  post.php
Purpose:    Manage posts, including storing the information in a file and sending mail to subscribers

Author:     Gareth Rushgrove
Version:    0.1a

Note that this file is part of the Sourceforge project php-eml and is licenced under the GNU GPL. For more details see www.php-eml.com

Note also that this project is currently in alpha. This probably means that its worked somewhere but your mileage may vary.

*/

// config

// administrators email address

$admin_email = 'admin@newcastlenewmedia.org';

// text file which stores the subscribers

$mail_list_file = '/www/htdocs/maillist/subscribers';

// folder which stores the post files, currently uses a flat file method

$post_folder = '/www/htdocs/maillist/posts';

// read from stdin, this reads the email, including all the headers

$fd = fopen("php://stdin", "r");
$email = "";
while (!feof($fd)) {
    $email .= fread($fd, 1024);
}
fclose($fd);

// handle email

$lines = explode("\n", $email);

// empty variables

$from = "";
$subject = "";
$headers = "";
$message = "";
$splittingheaders = true;

for ($i=0; $i<count($lines); $i++) {
    
    if ($splittingheaders) {
        
        // this is a header
        
        $headers .= $lines[$i]."\n";

        // look out for special headers
    
        if (preg_match("/^Subject: (.*)/", $lines[$i], $matches)) {
            $subject = $matches[1];
        }
    
        if (preg_match("/^From: (.*)/", $lines[$i], $matches)) {
            $from = $matches[1];
        }
    
    } else {
    
        // not a header, but message
    
        $message .= $lines[$i]."\n";
    
    }

    if (trim($lines[$i])=="") {
    
        // empty line, header section has ended
    
        $splittingheaders = false;
    
    }
}

// This adds [NNM] to the start of all the posts subject lines
// this is related to an existing instal and wants to be an option in a config file rather than hard coded

$subject = str_replace('[NNM] ','',$subject);

// As you get more and more replies they could build up. eg. Re: Re: RE: Re: etc. This is a crude starting point looking at this problem. Note also that some email clients seem to use Re: others RE: and potentially other common variations.

if (substr($subject,0,3) == 'Re:' | substr($subject,0,3) == 'RE:') {
	$holder = '[NNM] ';
	$holder .= 'Re: ';
	$holder .= str_replace('Re: ','',$subject);
} else {
	$holder = '[NNM] ';
	$holder .= $subject;
}

$email_subject = $holder;

// Regular expression to extract the email address

preg_match('/[^@\s]+@([-a-z0-9]+\.)+[a-z]{2,}/i',$from,$email_from_array);
$from_email = substr($email_from_array[0],1);

// this adds some context to the message, again this relates to an existing instal and needs abstracting into a config file

$email_message = 'message from ';
$email_message .= $from;
$email_message .= '


';
$email_message .= $message;
$email_message .= '---
www.newcastlenewmedia.org
';


// store in file

// set path

// more dealing with the repeated Re: bits and a few more existing install bits to remove

$subject = str_replace(' [NNM] ', '', $subject);
$subject = str_replace('RE:','Re:',$subject);
$file_subject = str_replace('Re: ','',$subject);
$file_subject = str_replace('Re:','',$file_subject);
$file_subject = str_replace('/','-',$file_subject);

if (substr($subject,0,3) == 'Re:') {
	$path = $post_folder;
	$path .= '/Re: ';
	$path .= $file_subject;
} else {
	$path = $post_folder;
	$path .= '/';
	$path .= $file_subject;	
}

$original_path = $path;

$i = 1;

// this is dealing with a naming convention for replies to posts. We add a numerical identifier to each post file name, in brackets after the file name.

while (file_exists($path)) {
	$path = $original_path;
		if (strlen($i) == '1') {
				$string = "0";
				$string .= "$i";
			} else {
					$string = $i;
				}
		$path .= " ($string)";
		$i = $i+1;
	}

$filehandle = fopen($path,'a');

// write the message to the file

fwrite($filehandle,$from);
fwrite($filehandle,"\n");
fwrite($filehandle,trim($message));
fwrite($filehandle,"\n");

fclose($filehandle);

// email subscribers list

$file = file($mail_list_file);

// extract email using a regular expression

$name = preg_replace('/[^@\s]+@([-a-z0-9]+\.)+[a-z]{2,}/i','',$from);
$name = substr_replace($name,'',-2);

// make a from header for the email, note this again includes info from the now infamous existing install.

$email_from = 'FROM:' . $name . ' <maillist@newcastlenewmedia.org>';

foreach($file as $line) {
	
	preg_match('/[^@\s]+@([-a-z0-9]+\.)+[a-z]{2,}/i',$line,$email_line_array);
	$line_email = substr($email_line_array[0],1);
	
	// send individual emails to the subscribers list
	
	mail($line_email,$email_subject,$email_message,$email_from);
}

?>