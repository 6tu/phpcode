#!/bin/php
<?php

/*

File Name:  subscribe.php
Purpose:    Adds a new subscriber to the list 

Author:     Gareth Rushgrove
Version:    0.1a

Note that this file is part of the Sourceforge project php-eml and is licenced under the GNU GPL. For more details see www.php-eml.com

Note also that this project is currently in alpha. This probably means that its worked somewhere but your mileage may vary.

This file probably needs more notes concerning what its up to, however much of this is repeated in the post.php file. This means (at least) two things. It's a bit sloppy and I can amalgamate both with the help of a couple of handy functions or classes. And I cant be bothered to write more comments until I do. Sorry.

*/

// config

$admin_email = 'garethr@newcastlenewmedia.org';

$mail_list_file = '/www/htdocs/maillist/subscribers';


// read from stdin
$fd = fopen("php://stdin", "r");
$email = "";
while (!feof($fd)) {
    $email .= fread($fd, 1024);
}
fclose($fd);

// handle email
$lines = explode("\n", $email);

// empty vars
$from = "";
$subject = "";
$headers = "";
$message = "";
$splittingheaders = true;

for ($i=0; $i<count($lines); $i++) {
    if ($splittingheaders) {
        // this is a header
        $headers .= $lines[$i]."\n";

        // look out for special headers
        if (preg_match("/^Subject: (.*)/", $lines[$i], $matches)) {
            $subject = $matches[1];
        }
        if (preg_match("/^From: (.*)/", $lines[$i], $matches)) {
            $from = $matches[1];
        }
    } else {
        // not a header, but message
        $message .= $lines[$i]."\n";
    }

    if (trim($lines[$i])=="") {
        // empty line, header section has ended
        $splittingheaders = false;
    }
}

// email administrator with new subscribers

mail($admin_email,'new subscriber',$from);

// store details in subscribers list

$filehandle = fopen($mail_list_file,'a');

fwrite($filehandle,$from);

fwrite($filehandle,"\n");

fclose($filehandle);

// regular expression to get the email address from the header

preg_match('/[^@\s]+@([-a-z0-9]+\.)+[a-z]{2,}/i',$from,$email_array);
$email = substr($email_array[0],1);

// email subscriber

mail($email,'Welcome to Newcastle New Media','You have subscribed to the Newcastle New Media mailing list and will now recieve all posts made to the list.

Why not introduce your self now by mailing a little bit about you to maillist@newcastlenewmedia.org.

Any problems please email admin@newcastlenewmedia.org.','FROM:admin@newcastlenewmedia.org');

?>