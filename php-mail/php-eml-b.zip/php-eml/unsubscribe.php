#!/bin/php
<?php

// config

/*

File Name:  unsubscribe.php
Purpose:    removes an existing subscriber from the list 

Author:     Gareth Rushgrove
Version:    0.1a

Note that this file is part of the Sourceforge project php-eml and is licenced under the GNU GPL. For more details see www.php-eml.com

Note also that this project is currently in alpha. This probably means that its worked somewhere but your mileage may vary.

This file probably needs more notes concerning what its up to, however much of this is repeated in the post.php file. This means (at least) two things. It's a bit sloppy and I can amalgamate both with the help of a couple of handy functions or classes. And I cant be bothered to write more comments until I do. Sorry.

*/

$admin_email = 'admin@newcastlenewmedia.org';

$mail_list_file = '/www/htdocs/maillist/subscribers';

// read from stdin
$fd = fopen("php://stdin", "r");
$email = "";
while (!feof($fd)) {
    $email .= fread($fd, 1024);
}
fclose($fd);

// handle email
$lines = explode("\n", $email);

// empty vars
$from = "";
$subject = "";
$headers = "";
$message = "";
$splittingheaders = true;

for ($i=0; $i<count($lines); $i++) {
    if ($splittingheaders) {
        // this is a header
        $headers .= $lines[$i]."\n";

        // look out for special headers
        if (preg_match("/^Subject: (.*)/", $lines[$i], $matches)) {
            $subject = $matches[1];
        }
        if (preg_match("/^From: (.*)/", $lines[$i], $matches)) {
            $from = $matches[1];
        }
    } else {
        // not a header, but message
        $message .= $lines[$i]."\n";
    }

    if (trim($lines[$i])=="") {
        // empty line, header section has ended
        $splittingheaders = false;
    }
}

$file = file($mail_list_file);
	
$filehandle = fopen($mail_list_file,'w');

foreach($file as $line) {
	
	preg_match('/[^@\s]+@([-a-z0-9]+\.)+[a-z]{2,}/i',$from,$email_from_array);
	$from_email = substr($email_from_array[0],1);
	
	preg_match('/[^@\s]+@([-a-z0-9]+\.)+[a-z]{2,}/i',$line,$email_line_array);
	$line_email = substr($email_line_array[0],1);
	
	if ($from_email !== $line_email) {
		fwrite($filehandle,"$line");
	}
}
	
fclose($filehandle);

// email administrator with new subscribers

mail($admin_email,'unsubscriber',$from);

// email unsubscriber

mail($from_email,'Unsubscription from Newcastle New Media','You have been unsubscribed from the Newcastle New Media mailing list. Thanks for taking part. 

If you ever want to resubscribe please email subscribe@newcastlenewmedia.org and all will be forgiven.','FROM: admin@newcastlenewmedia.org');

?>