<?php

/*

File Name:  maillist.fnc.php
Purpose:    Function library for php-eml

Author:     Gareth Rushgrove
Version:    0.1a

Note that this file is part of the Sourceforge project php-eml and is licenced under the GNU GPL. For more details see www.php-eml.com

Note also that this project is currently in alpha. This probably means that its worked somewhere but your mileage may vary.

*/



// a simple function to cout the number of subscribers

function countSubscribers() {
	
	// needs to be centralised, probably as a instance variable as part of a class?
	
	$mail_list_file = '/www/htdocs/maillist/subscribers';

	$file = file($mail_list_file);

    // read the file into an array

	foreach($file as $line) {
	
		$array[] = $line; 

	}

	$unique = array_unique($array);

    // count the unique records

	$count =  count($unique);
	
	// return the number of subscribers
	
	return $count;
}

// function to do all sorts of things but mainly to return the details of a post in a nice array

function getNameEmailContent($file,$post_folder) {
	
	// open the specified file
	
	$filehandle = fopen("$post_folder/$file",'r');
	
	$first_line = 1;
	
	while (!feof($filehandle)) {
		
		$buffer = fgets($filehandle, 4096);
		
		// regular expression to get the email address
		
		preg_match('/[^@\s]+@([-a-z0-9]+\.)+[a-z]{2,}/i',$buffer,$email_array);
		
		$buffer = preg_replace('/[^@\s]+@([-a-z0-9]+\.)+[a-z]{2,}/i','',$buffer);
		
		$email = substr($email_array[0],1);	
		
		if (substr($buffer,-2) == ">\n") {
			$buffer = substr_replace($buffer,"\n",-2);
		}
	
		if ($first_line == 1) {
			$first_line = 0;
			$name = $buffer;
			$name = str_replace('"','',$name);
		} else {
		
		  // removes some of the detritus from the message, although not all, especially from html emails
		
			$buffer = str_replace('<?php','',$buffer);
			$buffer = str_replace('?>','',$buffer);
			$buffer = strip_tags($buffer);
			$content .= nl2br($buffer);	
		}
	
	}
	
	// returns the array of information
	
	$details['name'] = $name;
	$details['email'] = $email;
	$details['content'] = $content;
		
	return $details;
}

?>