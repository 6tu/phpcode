<?php

$rss = new rssGenesis();

$rss->setChannel (	'Morethanseven', // Title	'http://www.morethanseven.net', // Link	'Musing on web development and design and examples of recent projects.', // Description	null, // Language	'Gareth Rushgrove', // Copyright	'Gareth Rushgrove', // Managing Editor	'Gareth Rushgrove', // WebMaster	null, // Rating	"auto", // PubDate	"auto", // Last Build Date	null, // Docs	null, // Skip Days	null // Skip Hours);
// list all items

$items_array = MysqlItem::listItems();

// display all items

foreach($items_array as $item_id) {

    $item = new MysqlItem($item_id);
    
    $title = $item->getTitle();        $content = $item->getContent();        $link = 'http://morethanseven.net/email2rss/index.php/';
    $link .= $item->getId();
        $rss->addItem (        "$title", // Title        "$link", // Link        "$content" // Description    );
}
$rss->createFile ('/users/gareth/sites/morethanseven.dev/rss/morethanseven.rss');
                       
?>