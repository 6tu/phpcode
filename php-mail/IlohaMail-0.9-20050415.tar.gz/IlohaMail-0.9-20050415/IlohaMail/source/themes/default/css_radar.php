<?php
$linkc=$my_colors["tool_link"];
$bgc=$my_colors["tool_bg"];
include('themes/default/css_base.php');
?>