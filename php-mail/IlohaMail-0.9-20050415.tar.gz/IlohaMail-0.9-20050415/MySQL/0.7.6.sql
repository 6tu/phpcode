alter table prefs add column html_in_frame char default '0';
alter table prefs add column show_images_inline char default '0';
