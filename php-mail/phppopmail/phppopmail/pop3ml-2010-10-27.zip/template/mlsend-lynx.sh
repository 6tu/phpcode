lynx -dump -auth=user:password http://server.com/pop3ml/mlsend.php >>/var/log/pop3ml.log
