lynx -dump -auth=user:password http://server.com/pop3ml/clean_pop3ml.php >>/var/log/pop3ml.log
