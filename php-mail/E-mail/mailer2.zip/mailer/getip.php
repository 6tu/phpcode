<?php
set_time_limit(30);
date_default_timezone_set('Asia/Shanghai');
if(file_exists('log/time.log')){
$t0=file_get_contents('log/time.log');
}else{
mkdir('log',0777);
@chmod('log');
$t0=0;
file_put_contents('log/time.log',$t0);
}
list($usec,$sec)=explode(' ',microtime());
if(($sec-$t0) < 600){
echo file_get_contents('ip.htm');
exit(0);
}
echo 'done<br>';
echo date("H:i");
?>