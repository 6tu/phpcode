<?php
/*��ʱ���������ú����ɼ�¼�ļ�����*/

include_once('inc/mime_parser.php');
include_once('inc/rfc822_addresses.php');
include_once("inc/class.pop3.php");
include_once("inc/urlcheck.php");
include_once('inc/pclzip.lib.php');
//include_once("inc/sasl/sasl.php");              # ��ʹ�� SASL ��֤��ʽʱ��Ҫע��

stream_wrapper_register('pop3', 'pop3_stream');   # ע�� pop3 ���̿���(handler)��
$pop3 = new pop3_class;
  
$user     = "pubnews@126.com";                        # Authentication user name
$password = "qq0000000";                          # Authentication password 
$pop3 -> hostname = "pop.126.com";                  # POP 3 server host name
$pop3 -> port = 110;                              # POP 3 server host port,Gmail uses 995
$pop3 -> tls = 0;                                 # Establish secure connections using TLS
$pop3 -> realm = "";                              # Authentication realm or domain 
$pop3 -> workstation = "";                        # Workstation for NTLM authentication
$apop = 0;                                        # Use APOP authentication
$pop3 -> authentication_mechanism = "USER";       # SASL authentication mechanism
$pop3 -> debug = 1;                               # Output debug information
$pop3 -> html_debug = 1;                          # Debug information is in HTML
$pop3 -> join_continuation_header_lines = 1;      # Concatenate headers split in multiple lines
if(($error = $pop3 -> Open()) == ""){
    //echo "<PRE>Connected to the POP3 server &quot;" . $pop3 -> hostname . "&quot;.</PRE>\n";
if(($error = $pop3 -> Login($user, $password, $apop)) == ""){
    //echo "<PRE>User &quot;$user&quot; logged in.</PRE>\n";
    if(($error = $pop3 -> Statistics($messages, $size)) == ""){
        //echo "<PRE>$messages messages, total of $size bytes.</PRE>\n";
        if($messages == 0) exit;
        if($messages > 0){
            $pop3 -> GetConnectionName($connection_name);
            $message = 1;
            $message_file = 'pop3://' . $connection_name . '/' . $message;
            $mime = new mime_parser_class;
            $mime -> decode_bodies = 1;            # Set to 0 for not decoding the message bodies
	    $parameters = array(
	        'File'  => $message_file, 
		//'Data'=>'My message data string',# Read a message from a string instead of a file
		//'SaveBody'=>'/tmp',              # Save the message body parts to a directory
		'SkipBody' => 0,                   # Do not retrieve or save message body parts
		);
            $success = $mime -> Decode($parameters, $decoded);
            if($success && $mime -> Analyze($decoded[0], $results)){
                //echo '<h2>Message analysis</h2>' . "\n";
                //echo '<pre>';
                //var_dump($results);
                //echo '</pre>';

                $encoding  = $results['Encoding'];
                $date      = $results['Date'];
                //$from_name = $results['From'][0]['name'];
                $from_addr = $results['From'][0]['address'];
                $subject   = $results['Subject'];

                $data = $results['Data'];
                //$data = html2wml($results['Data']);
                $data = str_replace("<p><br/></p>\n", '', $data);
                $data = str_replace("<p>", '', $data);
                $data = str_replace("</p>\n", '', $data);
                //echo $from_addr . "\r\n<br />" . $subject . "\r\n<br /><br />\r\n\r\n";
                echo $data;
                }
            else echo 'MIME message analyse error: ' . $mime -> error . "\n";
           if($from_addr='' && strpos($data,'http') !== false){


	    @file_put_contents('ip.htm',$data);
}
	    //$pop3 -> DeleteMessage($message);
            }
	     
        }
    if($error == "" && ($error = $pop3 -> Close()) == "") echo " \n"; //$pop3 -> hostname .
    }
}
if($error != "") echo "<H2>Error: ", HtmlSpecialChars($error), "</H2>";
