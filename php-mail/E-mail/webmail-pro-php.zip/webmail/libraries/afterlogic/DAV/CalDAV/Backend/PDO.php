<?php

/*
 * Copyright (C) 2002-2012 AfterLogic Corp. (www.afterlogic.com)
 * Distributed under the terms of the license described in COPYING
 * 
 */

class afterlogic_DAV_CalDAV_Backend_PDO extends Sabre_CalDAV_Backend_PDO {

    /**
     * pdo 
     * 
     * @var PDO
     */
    protected $pdo;

	public $calendarTableName;

	public $calendarObjectTableName;

	public $delegatesTableName;

	public $principalsTableName;

    /**
     * Creates the backend 
     * 
     * @param PDO $pdo 
     */
    public function __construct(PDO $pdo, $dBPrefix) {

        $this->pdo = $pdo;
        
		$this->calendarTableName = $dBPrefix.afterlogic_DAV_Constants::T_CALENDARS;
        $this->calendarObjectTableName = $dBPrefix.afterlogic_DAV_Constants::T_CALENDAROBJECTS;
		$this->delegatesTableName = $dBPrefix.afterlogic_DAV_Constants::T_DELEGATES;

    }

    /**
     * Delete a calendar and all it's objects 
     * 
     * @param string $calendarId 
     * @return void
     */
    public function deleteCalendar($calendarId) {

		parent::deleteCalendar($calendarId);
		
		$stmt = $this->pdo->prepare('DELETE FROM `'.$this->delegatesTableName.'` WHERE calendarid = ?');
		$stmt->execute(array($calendarId));
    }
	
}
