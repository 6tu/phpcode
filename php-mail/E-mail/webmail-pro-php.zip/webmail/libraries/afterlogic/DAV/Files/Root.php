<?php

class afterlogic_DAV_Files_Root extends Sabre_DAVACL_AbstractPrincipalCollection {
	
	/**
     * Creates the object
     *
     * This object must be passed the principal backend. This object will
     * filter all principals from a specified prefix ($principalPrefix). The
     * default is 'principals', if your principals are stored in a different
     * collection, override $principalPrefix
     *
     *
     * @param Sabre_DAVACL_IPrincipalBackend $principalBackend
	 * @param string $sPrivateFoldersRoot
     * @param string $principalPrefix
     */
    public function __construct(Sabre_DAVACL_IPrincipalBackend $principalBackend, $path, $principalPrefix = 'principals') {

        $this->principalPrefix = $principalPrefix;
        $this->principalBackend = $principalBackend;
		$this->path = $path;

    }
	
	/**
     * Returns the name of the node
     *
     * @return string
     */
    public function getName() {

        return afterlogic_DAV_Files_Plugin::FILES_ROOT;

    }	
	
    /**
     * This method returns a node for a principal.
     *
     * The passed array contains principal information, and is guaranteed to
     * at least contain a uri item. Other properties may or may not be
     * supplied by the authentication backend.
     *
     * @param array $principal
     * @return Sabre_DAV_INode
     */
    public function getChildForPrincipal(array $principal) {

        return new afterlogic_DAV_Files_UserFiles($this->principalBackend, $this->path, $principal['uri']);

    }	
	
}
