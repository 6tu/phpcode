<?php

class afterlogic_DAV_Delegates_Plugin extends Sabre_DAV_ServerPlugin
{

    /**
     * Reference to main server object 
     * 
     * @var Sabre_DAV_Server 
     */
    private $server;
    
	/**
     * cacheBackend 
     * 
     * @var afterlogic_DAV_Delegates_Backend_Abstract 
     */
    private $delegatesBackend;	
    
	/**
     * __construct 
     * 
     * @return void
     */
    public function __construct(afterlogic_DAV_Delegates_Backend_Abstract $delegatesBackend)
    {
		$this->delegatesBackend = $delegatesBackend;
	}

    public function initialize(Sabre_DAV_Server $server)
    {
        $this->server = $server;
		$this->server->subscribeEvent('beforeGetProperties', array($this, 'beforeGetProperties'), 90);
    }

    /**
     * Returns a plugin name.
     * 
     * Using this name other plugins will be able to access other plugins
     * using Sabre_DAV_Server::getPlugin 
     * 
     * @return string 
     */
    public function getPluginName()
    {
        return 'delegates';
    }

	/**
	 * @param string $path
	 * @param Sabre_DAV_INode $node
	 * @param array $requestedProperties
	 * @param array $returnedProperties
	 * @return void
	 */
	function beforeGetProperties($path, Sabre_DAV_INode $node, &$requestedProperties, &$returnedProperties)
	{
		if ($node instanceof afterlogic_DAV_Delegates_Principal)
		{
			$calHome = '{' . Sabre_CalDAV_Plugin::NS_CALDAV . '}calendar-home-set';
			if (($index = array_search($calHome,$requestedProperties)) !== false)
			{
				$returnedProperties[200][$calHome] = new Sabre_DAV_Property_Href(dirname($path) . '/');
				unset($requestedProperties[$index]);
			}
		}
	}


}

