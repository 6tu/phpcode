<?php

class afterlogic_DAV_Auth_Backend_Factory
{
	public static function getBackend(PDO $pdo, $dBPrefix = '')
	{
		$oBackend = null;
		if (afterlogic_DAV_Server::$UseDigest)	
		{
			$oBackend = new afterlogic_DAV_Auth_Backend_Digest($pdo, $dBPrefix);
		}
		else
		{
			$oBackend = new afterlogic_DAV_Auth_Backend_Basic($pdo, $dBPrefix);
		}
		return $oBackend;
	}
}