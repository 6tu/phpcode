<?php

/*
 * Copyright (C) 2002-2012 AfterLogic Corp. (www.afterlogic.com)
 * Distributed under the terms of the license described in COPYING
 * 
 */

abstract class afterlogic_DAV_Cache_Backend_Abstract {
	
	abstract function getRemindersCache($type = 1, $start = null, $end = null);	
	
	abstract function createRemindersCache($user, $calendarUri, $type = 0, $time = null, $startTime = null, $eventid = null);
	
	abstract function updateRemindersCache($calendarUri, $type, $time = 0, $startTime = 0, $eventid = '');

	abstract function deleteRemindersCache($calendarUri);

	abstract function deleteRemindersCacheByUser($user);
	
	abstract function getDelegates($calendarUri);
}
