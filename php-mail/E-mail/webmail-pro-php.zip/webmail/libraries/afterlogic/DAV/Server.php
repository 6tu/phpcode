<?php

/*
 * Copyright (C) 2002-2012 AfterLogic Corp. (www.afterlogic.com)
 * Distributed under the terms of the license described in COPYING
 *
 */

defined('WM_ROOTPATH') || define('WM_ROOTPATH', (dirname(__FILE__).'/../../'));

require_once WM_ROOTPATH.'application/include.php';
require_once WM_ROOTPATH.'common/inc_constants.php';
include_once WM_ROOTPATH.'libraries/afterlogic/api.php';
require_once WM_ROOTPATH.'libraries/afterlogic/DAV/autoload.php';

CApi::$bUseDbLog = false;

/* Mapping PHP errors to exceptions */
function exception_error_handler($errno, $errstr, $errfile, $errline )
{
	throw new ErrorException($errstr, 0, $errno, $errfile, $errline);
}

set_error_handler("exception_error_handler");
@ini_set('memory_limit', MEMORYLIMIT);
@set_time_limit(TIMELIMIT);
				
class afterlogic_DAV_Server extends Sabre_DAV_Server
{
	protected $authBackend;
	protected $principalBackend;
	protected $caldavBackend;
	protected $carddavBackend;
	protected $lockBackend;
	protected $cacheBackend;
	protected $delegatesBackend;

	public $oSettings;
	public $oApiCollaborationManager;

	public static $UseDigest;

	public function GetAuthBackend()
	{
		return $this->authBackend;
	}

	public function GetPrincipalBackend()
	{
		return $this->principalBackend;
	}

	public function GetCaldavBackend()
	{
		return $this->caldavBackend;
	}

	public function GetCarddavBackend()
	{
		return $this->carddavBackend;
	}

	public function GetLockBackend()
	{
		return $this->lockBackend;
	}

	public function GetCacheBackend()
	{
		return $this->cacheBackend;
	}
	
	public function GetDelegatesBackend()
	{
		return $this->delegatesBackend;
	}
	

	public function __construct($baseUri = '/')
	{
		self::$UseDigest = true;
		$this->debugExceptions = false;
		
		$this->setBaseUri($baseUri);
		date_default_timezone_set('GMT');

		/* Get WebMail Settings */
		$this->oSettings =& CApi::GetSettings();

		$sDbPrefix = $this->oSettings->GetConf('Common/DBPrefix');

		/* Database */
		$oPdo = CApi::GetPDO();
		
		if ($oPdo)
		{
			$this->authBackend = afterlogic_DAV_Auth_Backend_Factory::getBackend($oPdo, $sDbPrefix);
			$this->principalBackend = new afterlogic_DAV_Principal_Backend_PDO($oPdo, $sDbPrefix);
			$this->caldavBackend = new afterlogic_DAV_CalDAV_Backend_PDO($oPdo, $sDbPrefix);
			$this->carddavBackend = new afterlogic_DAV_CardDAV_Backend_PDO($oPdo, $sDbPrefix);
			$this->lockBackend = new afterlogic_DAV_Locks_Backend_PDO($oPdo, $sDbPrefix);
			$this->cacheBackend = new afterlogic_DAV_Cache_Backend_PDO($oPdo, $sDbPrefix);
			$this->delegatesBackend = new afterlogic_DAV_Delegates_Backend_PDO($oPdo, $sDbPrefix);

			$this->oApiCollaborationManager = CApi::Manager('collaboration');
			
			/* Authentication Plugin */
			$authPlugin = new Sabre_DAV_Auth_Plugin($this->authBackend, 'SabreDAV');
			$this->addPlugin($authPlugin);
			
			/* Logs Plugin */
			$logsPlugin = new afterlogic_DAV_Logs_Plugin();
			$this->addPlugin($logsPlugin);

			$pubCollection = array();

			/* Global Address Book */
			$pubCollection[] = new afterlogic_DAV_CardDAV_GAddressBooks($authPlugin, 'globals', 
					afterlogic_DAV_Constants::GLOBAL_CONTACTS);

			/* Public files folder */
/*			
			$pubDir = CApi::DataPath() . '/files';
			if (!file_exists($pubDir))
			{
				mkdir($pubDir);
			}
			$pubDir .= '/public';
			if (!file_exists($pubDir))
			{
				mkdir($pubDir);
			}
			$pubCollection[] = new afterlogic_DAV_Public_Directory($pubDir, 'Files');
*/
			/* Directory tree */
			$aTree = array();

			$aTree[] = new afterlogic_DAV_CardDAV_AddressBookRoot($this->principalBackend, $this->carddavBackend);
			$aTree[] = new Sabre_CalDAV_CalendarRootNode($this->principalBackend, $this->caldavBackend);
			if ($this->oApiCollaborationManager && $this->oApiCollaborationManager->IsCalendarSharingSupported())
			{
				$aTree[] = new afterlogic_DAV_Delegates_Root($oPdo, $this->principalBackend, $this->caldavBackend);
			}
			$aTree[] = new Sabre_CalDAV_Principal_Collection($this->principalBackend);
			$aTree[] = new Sabre_DAV_SimpleCollection('public', $pubCollection);
			
			/* Files Experimental */				
//			$sPath = CApi::DataPath() . '/files/private';
//			$aTree[] = new afterlogic_DAV_Files_Root($this->principalBackend, $sPath);

			/* Initializing server */
			parent::__construct($aTree);
			$this->httpResponse->setHeader("X-Server", "AfterlogicDAVServer");

			/* DAV ACL Plugin */
			$aclPlugin = new Sabre_DAVACL_Plugin();
			$mAdminPrincipal = CApi::GetConf('labs.dav.admin-principal', false);
			if ($mAdminPrincipal !== false)
			{
				$aclPlugin->adminPrincipals = array($mAdminPrincipal);
			}
			$aclPlugin->hideNodesFromListings = true;
			$this->addPlugin($aclPlugin);

			/* Cache Plugin */
			$this->addPlugin(new afterlogic_DAV_Cache_Plugin($this->cacheBackend));

			$oApiDavManager = CApi::Manager('dav');
			if (isset($oApiDavManager) && $oApiDavManager->IsMobileSyncEnabled())
			{
				/* CalDAV Plugin */
				$this->addPlugin(new Sabre_CalDAV_Plugin());

				/* CardDAV Plugin */
				$this->addPlugin(new Sabre_CardDAV_Plugin());
			}
			
			/* Calendar Delegation Plugin */
			$this->addPlugin(new afterlogic_DAV_Delegates_Plugin($this->delegatesBackend));
			
			/* ICS Export Plugin */
			$bExportPlugin = CApi::GetConf('labs.dav.use-export-plugin', false);
			if ($bExportPlugin !== false)
			{
				$this->addPlugin(new Sabre_CalDAV_ICSExportPlugin());
			}

			/* HTML Frontend Plugin */
			$bBrowserPlugin = CApi::GetConf('labs.dav.use-browser-plugin', false);
			if ($bBrowserPlugin !== false)
			{
				$this->addPlugin(new Sabre_DAV_Browser_Plugin());
			}

			/* Locks Plugin */
//			$this->addPlugin(new Sabre_DAV_Locks_Plugin($this->lockBackend));

			$this->subscribeEvent('beforeGetProperties', array($this, 'beforeGetProperties'), 90);
		}
    }

	/**
	 * @param string $path
	 * @param Sabre_DAV_INode $node
	 * @param array $requestedProperties
	 * @param array $returnedProperties
	 * @return void
	 */
	function beforeGetProperties($path, Sabre_DAV_INode $node, &$requestedProperties, &$returnedProperties)
	{
		$authPlugin = $this->getPlugin('auth');
		if (isset($authPlugin))
		{
			$oAccount = null;
			$sUser = $authPlugin->getCurrentUser();
			if (!empty($sUser))
			{
				$apiUsersManager = CApi::Manager('users');
				$oAccount = $apiUsersManager->GetAccountOnLogin($sUser);
				$carddavPlugin = $this->getPlugin('Sabre_CardDAV_Plugin');
				if (null !== $oAccount && $oAccount->User->AllowContacts && 
						$oAccount->User->GetCapa('GAB') && 	isset($carddavPlugin) && 
						$this->oApiCollaborationManager && 
						$this->oApiCollaborationManager->IsContactsGlobalSupported())
				{
					$carddavPlugin->directories = array('public/globals');
				}
			}
		}
	}
}