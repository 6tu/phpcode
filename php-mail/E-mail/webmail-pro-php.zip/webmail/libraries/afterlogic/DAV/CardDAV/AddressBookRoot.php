<?php

defined('WM_ROOTPATH') || define('WM_ROOTPATH', (dirname(__FILE__).'/../../../'));

include_once WM_ROOTPATH.'libraries/afterlogic/api.php';

class afterlogic_DAV_CardDAV_AddressBookRoot extends Sabre_CardDAV_AddressBookRoot {

	protected function getAccount($principalUri)
	{
		$oAccount = null;
		$sUser = basename($principalUri);
		if (!empty($sUser))
		{
			$apiUsersManager = CApi::Manager('users');
			$oAccount = $apiUsersManager->GetAccountOnLogin($sUser);
		}
		return $oAccount;
	}

	public function getChildForPrincipal(array $principal) {

		$oAccount = $this->getAccount($principal['uri']);
		if (null !== $oAccount && $oAccount->User->GetCapa('PAB'))
		{
			return new afterlogic_DAV_CardDAV_UserAddressBooks($this->carddavBackend, $principal['uri']);
		}
		else
		{
			return new afterlogic_DAV_CardDAV_EmptyAddressBooks($this->carddavBackend, $principal['uri']);
		}
    }

}
