<?php

/*
 * Copyright (C) 2002-2012 AfterLogic Corp. (www.afterlogic.com)
 * Distributed under the terms of the license described in COPYING
 *
 */

defined('WM_ROOTPATH') || define('WM_ROOTPATH', (dirname(__FILE__).'/../../../'));

include_once WM_ROOTPATH.'libraries/afterlogic/api.php';

class afterlogic_DAV_CardDAV_GAddressBooks extends Sabre_DAV_Directory implements Sabre_CardDAV_IDirectory, Sabre_DAV_IProperties {

	/**
	 * @var $apiGcontactsManager CApiGcontactsManager
	 */
	private $apiGcontactsManager;

	/**
	 * @var $apiUsersManager CApiUsersManager
	 */
	private $apiUsersManager;

    /**
	 * @var Sabre_DAV_Auth_Plugin
     */
    private $authPlugin;

    /**
	 * @var string
     */
    private $name;
	
    /**
	 * @var array
     */
	private $addressBookInfo;

	/**
     * Constructor
     */
    public function __construct(Sabre_DAV_Auth_Plugin $authPlugin, $name, $displayname = '')
	{
		$this->apiUsersManager = CApi::Manager('users');
		$this->authPlugin = $authPlugin;
		$this->name = $name;
		if (empty($displayname))
		{
			$displayname = $name;
		}
		$this->addressBookInfo['{DAV:}displayname'] = $displayname;
    }


	public function getAccount()
	{
		$oAccount = null;
		$sUser = $this->authPlugin->getCurrentUser();
		if (!empty($sUser))
		{
			$oAccount = $this->apiUsersManager->GetAccountOnLogin($sUser);
		}
		return $oAccount;
	}

	/**
     * @return string
     */
    public function getName()
	{
        return $this->name;
    }

    /**
     * @return array
     */
    public function getChildren()
	{
		$oAccount = $this->getAccount();
        $aCards = array();
		if (isset($oAccount) && $oAccount->User->GetCapa('GAB'))
		{
			$aContacts = array();
			$oApiCollaborationManager = CApi::Manager('collaboration');
			if ($oApiCollaborationManager)
			{
				$this->apiGcontactsManager = $oApiCollaborationManager->GetGlobalContactsManager();
				$aContacts = $this->apiGcontactsManager->GetContactItems($oAccount,
					EContactSortField::EMail, ESortOrder::ASC, 0, 999);
			}

			foreach($aContacts as $oContact)
			{
				$vCard = new Sabre_VObject_Component('VCARD');
				$vCard->VERSION = '3.0';
				$vCard->UID = $oContact->Id;
	            $vCard->EMAIL = $oContact->Email;
		        $vCard->FN = $oContact->Name;

				$aCards[] = new afterlogic_DAV_CardDAV_GCard(
					array(
						'uri' => md5($oContact->Email .'-'. $oContact->Id) . '.vcf',
						'carddata' => $vCard->serialize(),
						'lastmodified' => strtotime('2001-01-01 00:00:00')
					)
				);
			}
		}
        return $aCards;
    }
	
    public function getProperties($properties) {

        $response = array();
        foreach($properties as $propertyName) {

            if (isset($this->addressBookInfo[$propertyName])) {

                $response[$propertyName] = $this->addressBookInfo[$propertyName];

            }

        }

        return $response;

    }	
	
	/* @param array $mutations
     * @return bool|array
     */
    public function updateProperties($mutations) {

        return false;

    }	
}
