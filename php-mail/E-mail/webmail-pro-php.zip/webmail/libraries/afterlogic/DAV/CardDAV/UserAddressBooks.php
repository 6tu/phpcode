<?php

class afterlogic_DAV_CardDAV_UserAddressBooks extends Sabre_CardDAV_UserAddressBooks {


    /**
     * Returns a list of addressbooks
     *
     * @return array
     */
    public function getChildren() {

        $addressbooks = $this->carddavBackend->getAddressbooksForUser($this->principalUri);
        $objs = array();
        foreach($addressbooks as $addressbook) {
            $objs[] = new afterlogic_DAV_CardDAV_AddressBook($this->carddavBackend, $addressbook);
        }
        return $objs;

    }	
}