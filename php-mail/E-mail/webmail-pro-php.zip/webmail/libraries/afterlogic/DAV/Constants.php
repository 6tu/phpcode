<?php

class afterlogic_DAV_Constants
{
	const T_ACCOUNTS = 'awm_accounts';
	const T_PRINCIPALS = 'adav_principals';
	const T_GROUPMEMBERS = 'adav_groupmembers';
	const T_DELEGATES = 'adav_delegates';
	const T_CALENDARS = 'adav_calendars';
	const T_CALENDAROBJECTS = 'adav_calendarobjects';
	const T_ADDRESSBOOKS = 'adav_addressbooks';
	const T_CARDS = 'adav_cards';
	const T_LOCKS = 'adav_locks';
	const T_CACHE = 'adav_cache';
	
	const GLOBAL_CONTACTS = 'Global Contacts';
	const CALENDAR_DEFAULT_NAME = 'Default';
	const CALENDAR_DEFAULT_COLOR = '#EF9554';

	const ADDRESSBOOK_DEFAULT_NAME = 'Default';
	const ADDRESSBOOK_DEFAULT_DISPLAY_NAME = 'General';
	const ADDRESSBOOK_COLLECTED_NAME = 'Collected';
	const ADDRESSBOOK_COLLECTED_DISPLAY_NAME = 'Collected Addresses';
}