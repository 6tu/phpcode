<?php

defined('WM_ROOTPATH') || define('WM_ROOTPATH', (dirname(__FILE__).'/../../../'));
include_once WM_ROOTPATH.'libraries/afterlogic/api.php';

class afterlogic_DAV_Logs_Plugin extends Sabre_DAV_ServerPlugin
{

    /**
     * Reference to main server object 
     * 
     * @var Sabre_DAV_Server 
     */
    private $server;

    /**
     * __construct 
     * 
     * @return void
     */
    public function __construct()
    {
    }

    public function initialize(Sabre_DAV_Server $server)
    {
        $this->server = $server;
        $this->server->subscribeEvent('beforeMethod' ,array($this,'beforeMethod'),30);
		$this->server->subscribeEvent('afterWriteContent',array($this,'afterWriteContent'), 30);		
    }

    /**
     * Returns a plugin name.
     * 
     * Using this name other plugins will be able to access other plugins
     * using Sabre_DAV_Server::getPlugin 
     * 
     * @return string 
     */
    public function getPluginName()
    {
        return 'logs';
    }

    /**
     * This method is called before any HTTP method, but after authentication.
     * 
     * @param string $sMethod
     * @param string $sUrl
     * @throws Sabre_DAV_Exception_NotAuthenticated
     * @return bool 
     */
    public function beforeMethod($sMethod, $sUrl)
    {
		$aHeaders = $this->server->httpRequest->getHeaders();

    	CApi::Log($sMethod . ' ' . $sUrl, ELogLevel::Full, 'sabredav-');
    	CApi::LogObject($aHeaders, ELogLevel::Full, 'sabredav-');
    	CApi::Log('-------------------------------------------', ELogLevel::Full, 'sabredav-');

    	return;
    }
	
	function afterWriteContent($path, Sabre_DAV_IFile $node) 
	{
    	CApi::Log($path, ELogLevel::Full, 'sabredav-');
    	CApi::LogObject($node->get(), ELogLevel::Full, 'sabredav-');
    	CApi::Log('-------------------------------------------', ELogLevel::Full, 'sabredav-');
	}	

}

