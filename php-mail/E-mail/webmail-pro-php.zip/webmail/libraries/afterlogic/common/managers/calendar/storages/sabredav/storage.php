<?php

/*
 * Copyright (C) 2002-2012 AfterLogic Corp. (www.afterlogic.com)
 * Distributed under the terms of the license described in LICENSE.txt
 *
 */

defined('WM_ROOTPATH') || die('WM_ROOTPATH error');

require_once WM_ROOTPATH.'libraries/afterlogic/DAV/autoload.php';
require_once WM_ROOTPATH.'application/constants.php';
require_once WM_ROOTPATH.'application/functions.php';
require_once WM_ROOTPATH.'common/inc_constants.php';
require_once WM_ROOTPATH.'common/class_convertutils.php';
require_once WM_ROOTPATH.'common/class_mailprocessor.php';
require_once WM_ROOTPATH.'common/class_folders.php';
require_once WM_ROOTPATH.'common/class_smtp.php';

/*
 * @package Calendar
 */
class CApiCalendarSabredavStorage extends CApiCalendarStorage
{
	/**
	 * @var api_Settings
	 */
	protected $Settings;

	/**
	 * @var string
	 */
	public $CalendarHomeSet;

	/**
	 * @var string
	 */
	public $Principal;

	/**
	 * @var bool
	 */
	protected $Connected;

	/**
	 * @var string
	 */
	protected $User;

	/**
	 * @var string
	 */
	public $TimeZone;

	/**
	 * @var string
	 */
	protected $DbPrefix;

	/*
	 * @var CAccount
	 */
	public $Account;

	/*
	 * @var array
	 */
	protected $CacheUserCalendars;

	/*
	 * @var array
	 */
	protected $CacheSharedCalendars;

	/**
	 * @var afterlogic_DAV_Server
	 */
	protected $Server;

	/**
	 * @param CApiGlobalManager $oManager
	 */
	public function __construct(CApiGlobalManager &$oManager)
	{
		parent::__construct('sabredav', $oManager);

		CApi::Inc('common.dav.client');
		CApi::Inc('common.managers.calendar.classes.utils');

		$this->Server = new afterlogic_DAV_Server();
		$this->Settings = CApi::GetSettings();
		$this->User = null;
		$this->Principal = '';
		$this->Connected = false;
		$this->DbPrefix = $this->Settings->GetConf('Common/DBPrefix');
		$this->Account = null;

		$this->CacheUserCalendars = array();
		$this->CacheSharedCalendars = array();
	}

	/**
	 * @param CAccount $oAccount
	 */
	public function Init($oAccount)
	{
		if (($oAccount != null && ($this->User != $oAccount->Email)) ||
		    ($this->Account->Email != $oAccount->Email))
		{
			$this->Account = $oAccount;
			$this->User = $oAccount->Email;
			$this->TimeZone = $oAccount->GetDefaultStrTimeZone();

			if ($oAccount)
			{
				$oPdo = CApi::GetPDO();
				$oHelper = new afterlogic_DAV_Auth_Backend_Helper($oPdo, $this->DbPrefix);
				$oHelper->CheckPrincipals($oAccount->Email);

				$this->Connected = true;

	            $oPrincipal = null;
				$oPrincipalCollection = $this->Server->tree->getNodeForPath('principals');
				if ($oPrincipalCollection->childExists($this->User))
				{
					$oPrincipal= $oPrincipalCollection->getChild($this->User);
				}
				if (isset($oPrincipal))
				{
					$aProperties = $oPrincipal->getProperties(array('uri'));
					$this->Principal = $aProperties['uri'];
				}
				$this->CalendarHomeSet = '';

			}
		}
	}

	public function IsConnected()
	{
		return $this->Connected;
	}

	public function GetCalendarAccess($sUser, $sCalendarId)
	{
		return 0; //FULL_CONTOL
	}


	/**
	 * @param CalendarInfo  $oCalendar
	 */
	public function InitCalendar(&$oCalendar)
	{
		$oCalendar->Shared = true;
		$sRelativeUser = '';

		$sMainPrincipal = $this->GetMainPrincipalUrl($oCalendar->Principals[0]);
		$sRelativeUser = basename(urldecode($sMainPrincipal));

		list($sUser, $sDomain) = explode(DAV_EMAIL_DEV, $this->User);
		if ($sRelativeUser != '')
		{
			list($sRelativeUser, $sRelativeDomain) = explode(DAV_EMAIL_DEV, $sRelativeUser);
		}

		if ((strcmp($sRelativeUser, $sUser) != 0) &&
				preg_match('/(.+)-([A-Za-z0-9]{8})/', $sRelativeUser, $matches))
		{
			$sRelativeUser = $matches[1];
		}

		if(strcmp($sRelativeUser, $sUser) == 0)
		{
			$oCalendar->Shared = false;
			$oCalendar->Owner = $this->User;
			$oCalendar->Url = '/calendars/'.$this->User.'/'.$oCalendar->Id;
		}
		else
		{
			$oCalendar->Url = '/delegation/'.$oCalendar->Id.'/calendar';
			if($sRelativeUser != '' && $sRelativeDomain != '')
			{
				$oCalendar->Owner = $sRelativeUser . DAV_EMAIL_DEV . $sRelativeDomain;
			}
			else
			{
				$oCalendar->Owner = $this->User;
			}
		}
	}

	protected function GetCalDAVCalendar($sCalendarId)
	{
		$oCalendar = false;

		$sCalendarIdBase = basename($sCalendarId);
		if ($sCalendarIdBase == 'calendar')
		{
			$sCalendarId = basename($sCalendarIdBase);
		}
		else
		{
			$sCalendarId = $sCalendarIdBase;
		}

		$oCalendars = new Sabre_CalDAV_UserCalendars($this->Server->GetPrincipalBackend(), $this->Server->GetCaldavBackend(), $this->Principal);
		if ($oCalendars->childExists($sCalendarId))
		{
			$oCalendar = $oCalendars->getChild($sCalendarId);
		}
		else
		{
			$oCalendars = new afterlogic_DAV_Delegates_DelegatedCalendars($this->Server->GetPrincipalBackend(), 
					$this->Server->GetCaldavBackend(), $this->Server->GetDelegatesBackend(), $this->Principal);
			if ($oCalendars->childExists($sCalendarId))
			{
				$oCalendar = $oCalendars->getChild($sCalendarId);
			}
		}
		return $oCalendar;
	}

	public function GetCalendarInfo($oCalendar)
	{
		$sCalendarHome = '';
		if (!($oCalendar instanceof Sabre_CalDAV_Calendar) &&
			!($oCalendar instanceof afterlogic_DAV_Delegates_Calendar))
		{
			return false;
		}
		$aProps = $oCalendar->getProperties(
				array(
					'id',
					'uri',
					'principaluri',
					'{DAV:}displayname',
					'{'.Sabre_CalDAV_Plugin::NS_CALENDARSERVER.'}getctag',
					'{'.Sabre_CalDAV_Plugin::NS_CALDAV.'}calendar-description',
					'{http://apple.com/ns/ical/}calendar-color',
					'{http://apple.com/ns/ical/}calendar-order'
				)
		);
		$bShared = false;
		if ($oCalendar instanceof afterlogic_DAV_Delegates_Calendar)
		{
			$sCalendarHome = $aProps['id'];
			$bShared = true;
		}
		else if ($oCalendar instanceof Sabre_CalDAV_Calendar)
		{
			$sCalendarHome = $aProps['uri'];
		}

		$oCalendarInfo = new CalendarInfo($sCalendarHome);

		$oCalendarInfo->DisplayName = $aProps['{DAV:}displayname'];
		if (isset($aProps['{'.Sabre_CalDAV_Plugin::NS_CALENDARSERVER.'}getctag']))
		{
			$oCalendarInfo->CTag = $aProps['{'.Sabre_CalDAV_Plugin::NS_CALENDARSERVER.'}getctag'];
		}
		if (isset($aProps['{'.Sabre_CalDAV_Plugin::NS_CALDAV.'}calendar-description']))
		{
			$oCalendarInfo->Description = $aProps['{'.Sabre_CalDAV_Plugin::NS_CALDAV.'}calendar-description'];
		}
		if (isset($aProps['{http://apple.com/ns/ical/}calendar-color']))
		{
			$oCalendarInfo->Color = $aProps['{http://apple.com/ns/ical/}calendar-color'];
		}
		if (isset($aProps['{http://apple.com/ns/ical/}calendar-order']))
		{
			$oCalendarInfo->Order = $aProps['{http://apple.com/ns/ical/}calendar-order'];
		}
		$oCalendarInfo->Principals = array($aProps['principaluri']);
		$oCalendarInfo->Shared = $bShared;

		return $oCalendarInfo;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 */
	public function GetCalendar($oAccount, $sCalendarId)
	{
		$this->Init($oAccount);

		$oCalendar = null;
		$oCalendarInfo = false;
		if (count($this->CacheUserCalendars) > 0 && isset($this->CacheUserCalendars[$sCalendarId]))
		{
			$oCalendarInfo = $this->CacheUserCalendars[$sCalendarId];
		}
		else if (count($this->CacheSharedCalendars) > 0 && isset($this->CacheSharedCalendars[$sCalendarId]))
		{
			$oCalendarInfo = $this->CacheSharedCalendars[$sCalendarId];
		}
		else
		{
			$oCalendar = $this->GetCalDAVCalendar($sCalendarId);
			if ($oCalendar)
			{
				$oCalendarInfo = $this->GetCalendarInfo($oCalendar);

			}
		}
		if ($oCalendarInfo)
		{
			if (count($oCalendarInfo->Principals) > 0)
			{
				$oCalendarInfo->Principals = array(
					$oCalendarInfo->Principals[0].'/calendar-proxy-read',
					$oCalendarInfo->Principals[0].'/calendar-proxy-write'
				);
			}
			$oCalendarInfo->Shared = true;

			$this->InitCalendar($oCalendarInfo);
			$aCalendarUsers = array();
			$aCalendarUsers = $this->GetCalendarUsers($oAccount, $oCalendarInfo);

			$sPubLevel = null;
			$sPubHash = null;
			$aShares = array();

			foreach ($aCalendarUsers as $aCalendarUser)
			{
				if ($aCalendarUser['email'] == $this->GetPublicUser())
				{
					$sPubLevel = '1';
					$sPubHash = $this->GetPublicCalendarHash($oAccount, $sCalendarId);
				}
				else
				{
					$aShares[] = array(
						'id_share' => $aCalendarUser['email'],
						'email_to_user' => $aCalendarUser['email'],
						'access_level' => (int) $aCalendarUser['access_level']
					);
				}
			}
			$oCalendarInfo->shares = $aShares;
			$oCalendarInfo->PubLevel = $sPubLevel;
			$oCalendarInfo->PubHash = $sPubHash;
			return $oCalendarInfo;
		}
		return null;
	}

	public function GetPublicUser()
	{
		return $this->Server->GetPrincipalBackend()->getOrCreatePublicPrincipal();
	}

	/*
	 * @param string $sCalendarId
	 */
	public function GetPublicCalendarHash($oAccount, $sCalendarId)
	{
		$this->Init($oAccount);

		$iCalendarId = $this->Server->GetDelegatesBackend()->getCalendarForUser($oAccount->Email, $sCalendarId);
		if ($iCalendarId !== false)
		{
			return CCalendarUtils::encryptId($iCalendarId);
		}
		else return false;
	}

	/**
	 * @param CAccount $oAccount
	 */
	public function GetCalendars($oAccount)
	{
		$this->Init($oAccount);

		$aCalendars = array();
		if (count($this->CacheUserCalendars) > 0)
		{
			$aCalendars = $this->CacheUserCalendars;
		}
		else
		{
			$oCalendars = new Sabre_CalDAV_UserCalendars($this->Server->GetPrincipalBackend(), $this->Server->GetCaldavBackend(), $this->Principal);

			foreach ($oCalendars->getChildren() as $oCalendar)
			{
				$oCalendarInfo = $this->GetCalendarInfo($oCalendar);
				if ($oCalendarInfo)
				{
					$this->InitCalendar($oCalendarInfo);
					$aCalendars[$oCalendarInfo->Id] = $oCalendarInfo;
				}
			}

			$this->CacheUserCalendars = $aCalendars;
		}
 		return $aCalendars;
	}

	/**
	 * @param CAccount $oAccount
	 */
	public function GetCalendarsShared($oAccount)
	{
		$this->Init($oAccount);

		$aCalendars = array();
		if (count($this->CacheSharedCalendars) > 0)
		{
			$aCalendars = $this->CacheSharedCalendars;
		}
		else
		{
			$oCalendars = new afterlogic_DAV_Delegates_DelegatedCalendars($this->Server->GetPrincipalBackend(), 
					$this->Server->GetCaldavBackend(), $this->Server->GetDelegatesBackend(), $this->Principal);

			foreach ($oCalendars->getChildren() as $oCalendar)
			{
				$oCalendarInfo = $this->GetCalendarInfo($oCalendar);
				if($oCalendarInfo)
				{
					$this->InitCalendar($oCalendarInfo);
					$oCalendarInfo->SharingLevel = $oCalendar->GetMode();
					$aCalendars[$oCalendarInfo->Id] = $oCalendarInfo;
				}
			}
			$this->CacheSharedCalendars = $aCalendars;
		}

		return $aCalendars;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sName
	 * @param string $sDescription
	 * @param int $iOrder
	 * @param string $sColor
	 */
	public function CreateCalendar($oAccount, $sName, $sDescription, $iOrder, $sColor)
	{
		$this->Init($oAccount);

		$sSystemName = afterlogic_DAV_Client::getUUID();

		$oCalendars = new Sabre_CalDAV_UserCalendars($this->Server->GetPrincipalBackend(), 
				$this->Server->GetCaldavBackend(), $this->Principal);
        $aResourceType = array(
			'{DAV:}collection',
			'{urn:ietf:params:xml:ns:caldav}calendar'
		);
		$aProperties = array(
			'{DAV:}displayname' => $sName,
			'{'.Sabre_CalDAV_Plugin::NS_CALENDARSERVER.'}getctag' => 1,
			'{'.Sabre_CalDAV_Plugin::NS_CALDAV.'}calendar-description' => $sDescription,
			'{http://apple.com/ns/ical/}calendar-color' => $sColor,
			'{http://apple.com/ns/ical/}calendar-order' => $iOrder
		);
		$oCalendars->createExtendedCollection($sSystemName, $aResourceType, $aProperties);
		return $this->CalendarHomeSet.$sSystemName;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param string $sName
	 * @param string $sDescription
	 * @param int $iOrder
	 * @param string $sColor
	 */
	public function UpdateCalendar($oAccount, $sCalendarId, $sName, $sDescription, $iOrder,
			$sColor)
	{
		$this->Init($oAccount);

		$oCalendars = new Sabre_CalDAV_UserCalendars($this->Server->GetPrincipalBackend(), $this->Server->GetCaldavBackend(), $this->Principal);
		if ($oCalendars->childExists($sCalendarId))
		{
			$oCalendar = $oCalendars->getChild($sCalendarId);
			if ($oCalendar)
			{
				$aProperties = array(
					'{DAV:}displayname' => $sName,
					'{'.Sabre_CalDAV_Plugin::NS_CALDAV.'}calendar-description' => $sDescription,
					'{http://apple.com/ns/ical/}calendar-color' => $sColor,
					'{http://apple.com/ns/ical/}calendar-order' => $iOrder
				);
				$oCalendar->updateProperties($aProperties);
				return true;
			}
		}
		return false;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param string $sColor
	 */
	public function UpdateCalendarColor($oAccount, $sCalendarId, $sColor)
	{
		$this->Init($oAccount);

		$oCalendars = new Sabre_CalDAV_UserCalendars($this->Server->GetPrincipalBackend(), 
				$this->Server->GetCaldavBackend(), $this->Principal);
		if ($oCalendars->childExists($sCalendarId))
		{
			$oCalendar = $oCalendars->getChild($sCalendarId);
			if ($oCalendar)
			{
				$aProperties = array(
					'{http://apple.com/ns/ical/}calendar-color' => $sColor,
				);
				$oCalendar->updateProperties($aProperties);
				return true;
			}
		}
		return false;
	}

	/**
	 * @param string $sCalendarId
	 * @param int $iVisible
	 */
	public function UpdateCalendarVisible($sCalendarId, $iVisible)
	{
		@setcookie($sCalendarId, $iVisible, time() + 86400);
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 */
	public function DeleteCalendar($oAccount, $sCalendarId)
	{
		$this->Init($oAccount);

		$oCalendars = new Sabre_CalDAV_UserCalendars($this->Server->GetPrincipalBackend(), 
				$this->Server->GetCaldavBackend(), $this->Principal);
		if ($oCalendars->childExists($sCalendarId))
		{
			$oCalendar = $oCalendars->getChild($sCalendarId);
			if ($oCalendar)
			{
				$oCalendar->delete();

				$this->DeleteCalendarCache($oAccount, $oCalendar);

				return true;
			}
		}
		return false;
	}

	/**
	 * @param CAccount $oAccount
	 * @return bool
	 */
	public function ClearAllCalendars($oAccount)
	{
		$this->Init($oAccount);

		$oCalendars = new Sabre_CalDAV_UserCalendars($this->Server->GetPrincipalBackend(), 
				$this->Server->GetCaldavBackend(), $this->Principal);
		foreach ($oCalendars->getChildren() as $oCalendar)
		{
			if ($oCalendar instanceof Sabre_CalDAV_Calendar)
			{
				$oCalendar->delete();
			}
		}
		$this->Server->GetCacheBackend()->deleteRemindersCacheByUser($oAccount->Email);
		$this->Server->GetDelegatesBackend()->DeleteAllUsersShares($oAccount->Email);
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 *
	 * @return bool
	 */
	public function UnsubscibeCalendar($oAccount, $sCalendarId)
	{
		$this->Init($oAccount);

		$oCalendar = $this->GetCalendar($oAccount, $sCalendarId);

		if ($oCalendar)
		{
			if (count($oCalendar->Principals) > 0)
			{
				$this->Server->GetDelegatesBackend()->UnsubscribeCalendar($sCalendarId, $oAccount->Email);
			}
		}

		return true;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param string $sUserId
	 * @param int $iPerm
	 *
	 * @return bool
	 */
	public function UpdateCalendarShare($oAccount, $sCalendarId, $sUserId, $iPerms = ECalendarPermission::RemovePermission)
	{
		$this->Init($oAccount);

		$oCalendar = $this->GetCalendar($oAccount, $sCalendarId);

		if ($oCalendar)
		{
			if (count($oCalendar->Principals) > 0)
			{
				$calendarUri = $this->Server->GetDelegatesBackend()->UpdateShare($sCalendarId, $oAccount->Email, $sUserId, $iPerms);
				if ($calendarUri)
				{
					$this->DeleteRemindersCache($calendarUri);
					$this->CreateRemindersCache($sUserId, $calendarUri);
				}
			}
		}

		return true;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 */
	public function PublicCalendar($oAccount, $sCalendarId)
	{
		return $this->UpdateCalendarShare($oAccount, $sCalendarId, $this->GetPublicUser(), ECalendarPermission::Read);
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 */
	public function UnPublicCalendar($oAccount, $sCalendarId)
	{
		return $this->UpdateCalendarShare($oAccount, $sCalendarId, $this->GetPublicUser());
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $oCalendar
	 */
	public function GetCalendarUsers($oAccount, $oCalendar)
	{
		$this->Init($oAccount);

		if ($oCalendar != null)
		{
			if (count($oCalendar->Principals) > 0)
			{
				$principal = str_replace('/calendar-proxy-write', '', $oCalendar->Principals[0]);
				$principal = str_replace('/calendar-proxy-read', '', $principal);
				$principalUri = 'principals/' . basename($principal);
				$calendarUri = basename($oCalendar->Id);

				$res = $this->Server->GetDelegatesBackend()->getCalendarUsers($principalUri, $calendarUri) ;

				$result = array();
				foreach($res as $row)
				{
					$result[] = array(
						'id_share' => basename($row['uri']),
						'email' => basename($row['uri']),
						'access_level' => $row['mode']
					);
				}

				return $result;
			}
		}
		return array();
	}
	
	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @return string | bool
	 */
	public function ExportCalendarToIcs($oAccount, $sCalendarId)
	{
		$this->Init($oAccount);

		$mResult = false;
		$oCalendar = $this->GetCalDAVCalendar($sCalendarId);
		if ($oCalendar)
		{
			$calendar = new Sabre_VObject_Component('vcalendar');
			$calendar->version = '2.0';
			if (Sabre_DAV_Server::$exposeVersion) {
				$calendar->prodid = '-//SabreDAV//SabreDAV ' . Sabre_DAV_Version::VERSION . '//EN';
			} else {
				$calendar->prodid = '-//SabreDAV//SabreDAV//EN';
			}
			$calendar->calscale = 'GREGORIAN';

			$collectedTimezones = array();

			$timezones = array();
			$objects = array();
			
			foreach ($oCalendar->getChildren() as $oChild) 
			{
				$nodeComp = Sabre_VObject_Reader::read($oChild->get());
				foreach($nodeComp->children() as $child) 
				{
					switch($child->name) 
					{
						case 'VEVENT' :
						case 'VTODO' :
						case 'VJOURNAL' :
							$objects[] = $child;
							break;

						// VTIMEZONE is special, because we need to filter out the duplicates
						case 'VTIMEZONE' :
							// Naively just checking tzid.
							if (in_array((string)$child->TZID, $collectedTimezones)) continue;

							$timezones[] = $child;
							$collectedTimezones[] = $child->TZID;
							break;

					}
				}
			}
			foreach($timezones as $tz) $calendar->add($tz);
			foreach($objects as $obj) $calendar->add($obj);

			$mResult = $calendar->serialize();
		}
		
		return $mResult;
	}	

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param string $dStart
	 * @param string $dFinish
	 */
	public function GetEvents($oAccount, $sCalendarId, $dStart, $dFinish)
	{
		$this->Init($oAccount);

		$mResult = false;
		$oCalendar = $this->GetCalDAVCalendar($sCalendarId);

		if ($oCalendar)
		{
			$mResult = array();

			foreach ($oCalendar->getChildren() as $oCalendarChild)
			{
				if ($oCalendarChild instanceof Sabre_CalDAV_CalendarObject)
				{
					$sData = $oCalendarChild->get();
					$vCal = Sabre_VObject_Reader::read($sData);
					$vCalCopy = clone $vCal;
					unset($vCalCopy->VEVENT);
					foreach ($vCal->VEVENT as $vEvent)
					{
						if (isset($vEvent->DTSTART, $vEvent->DTEND) &&
							$vEvent->isInTimeRange(new DateTime($dStart), new DateTime($dFinish)))
						{
							$vCalCopy->add($vEvent);
						}
					}
					$mResult[] = $vCalCopy;
				}
			}
		}

		return $mResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param string $sEventId
	 */
	public function GetEvent($oAccount, $sCalendarId, $sEventId)
	{
		$this->Init($oAccount);

		$mResult = false;
		$oCalendar = $this->GetCalDAVCalendar($sCalendarId);

		if ($oCalendar)
		{
			foreach ($oCalendar->getChildren() as $oCalendarChild)
			{
				if ($oCalendarChild instanceof Sabre_CalDAV_CalendarObject)
				{
					$sData = $oCalendarChild->get();
					$vCal = Sabre_VObject_Reader::read($sData);
					foreach ($vCal->VEVENT as $vEvent)
					{
						$aUids = $vEvent->select('UID');
						foreach($aUids as $oUid)
						{
							if ($oUid->value == $sEventId)
							{
								$mResult['url'] = $oCalendarChild->getName();
								$mResult['href'] = $oCalendarChild->getName();
								$mResult['data'] = $sData;
								$mResult['vcal'] = $vCal;

								return $mResult;
							}
						}
					}
				}
			}
		}
		return $mResult;
	}

	/**
	}
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param Sabre_VObject_Component_VCalendar $vCal
	 */
	public function CreateEvent($oAccount, $sCalendarId, $sEventId, $vCal)
	{
		$this->Init($oAccount);

		$oCalendar = $this->GetCalDAVCalendar($sCalendarId);
		if ($oCalendar)
		{
			$oCalendar->createFile($sEventId.'.ics', $vCal->serialize());

			$this->UpdateCalendarCache($oAccount, $oCalendar);

			return $sEventId;
		}

		return null;
	}


	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param string $sEventId
	 * @param string $sData
	 */
	public function UpdateEventData($oAccount, $sCalendarId, $sEventId, $sData)
	{
		$this->Init($oAccount);

		$aData = $this->GetEvent($oAccount, $sCalendarId, $sEventId);
		$oCalendars = new Sabre_CalDAV_UserCalendars($this->Server->GetPrincipalBackend(), 
				$this->Server->GetCaldavBackend(), $this->Principal);
		$oCalendar = $oCalendars->getChild($sCalendarId);
		if ($oCalendar)
		{
			if ($aData !== false)
			{
				$oCalendarChild = $oCalendar->getChild($aData['href']);
				if ($oCalendarChild)
				{
					$oCalendarChild->put($sData);
					return true;
				}
			}
			else
			{
				$oCalendar->createFile($sEventId.'.ics', $sData);

				$this->UpdateCalendarCache($oAccount, $oCalendar);

				return true;
			}
		}
		return false;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param string $sEventId
	 * @param array $vCal
	 */
	public function UpdateEvent($oAccount, $sCalendarId, $sEventId, $vCal)
	{
		$this->Init($oAccount);

		$oCalendar = $this->GetCalDAVCalendar($sCalendarId);
		if ($oCalendar)
		{
			$oCalendarChild = $oCalendar->getChild($sEventId);
			$oCalendarChild->put($vCal->serialize());

			$this->UpdateCalendarCache($oAccount, $oCalendar);

			return true;
		}
		return false;
	}

	public function MoveEvent($oAccount, $sCalendarId, $sNewCalendarId, $sEventId, $sData)
	{
		$this->Init($oAccount);

		$oCalendar = $this->GetCalDAVCalendar($sCalendarId);
		if ($oCalendar)
		{
			$oCalendarChild = $oCalendar->getChild($sEventId);

			$oNewCalendar = $this->GetCalDAVCalendar($sNewCalendarId);
			if ($oNewCalendar)
			{
				$oNewCalendar->createFile($sEventId, $sData);
				$oCalendarChild->delete();

				$this->UpdateCalendarCache($oAccount, $oCalendar);
				$this->UpdateCalendarCache($oAccount, $oNewCalendar);

				return true;
			}
		}
		return false;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param string $sEventId
	 */
	public function DeleteEvent($oAccount, $sCalendarId, $sEventId)
	{
		$this->Init($oAccount);

		$oCalendar = $this->GetCalDAVCalendar($sCalendarId);
		if ($oCalendar)
		{
			$oCalendarChild = $oCalendar->getChild($sEventId);
			$oCalendarChild->delete();

			$this->UpdateCalendarCache($oAccount, $oCalendar);

			return true;
		}
		return false;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param string $dStart
	 * @param string $dFinish
	 */
	public function GetAlarms($oAccount, $sCalendarId, $dStart, $dFinish)
	{
		$this->Init($oAccount);

		$mResult = false;
		$oCalendar = $this->GetCalDAVCalendar($sCalendarId);

		if ($oCalendar)
		{
			$mResult = array();

			foreach ($oCalendar->getChildren() as $oCalendarChild)
			{
				if ($oCalendarChild instanceof Sabre_CalDAV_CalendarObject)
				{
					$sData = $oCalendarChild->get();
					$vCal = Sabre_VObject_Reader::read($sData);
					$vCalCopy = clone $vCal;
					unset($vCalCopy->VEVENT);
					foreach ($vCal->VEVENT as $vEvent)
					{
						if (isset($vEvent->VALARM, $vEvent->DTSTART, $vEvent->DTEND) &&
							$vEvent->isInTimeRange(new DateTime($dStart), new DateTime($dFinish)))
						{
							$vCalCopy->add($vEvent);
						}
					}
					$mResult[] = $vCalCopy;
				}
			}
		}

		return $mResult;		
	}

	public function GetRemindersCache($type, $start, $end)
	{
		return $this->Server->GetCacheBackend()->getRemindersCache($type, $start, $end);
	}

	public function CreateRemindersCache($user, $calendarUri, $type = 0, $time = null, $startTime = null,
			$eventid = null)
	{
		return $this->Server->GetCacheBackend()->createRemindersCache($user, $calendarUri, $type, $time, $startTime, $eventid);
	}

	public function UpdateRemindersCache($calendarUri, $type, $time, $startTime, $eventid)
	{
		return $this->Server->GetCacheBackend()->updateRemindersCache($calendarUri, $type, $time, $startTime, $eventid);
	}

	public function DeleteRemindersCache($calendarUri)
	{
		return $this->Server->GetCacheBackend()->deleteRemindersCache($calendarUri);
	}

	public function GetMainPrincipalUrl($principal)
	{
		$principal = str_replace('/calendar-proxy-read', '', rtrim($principal, '/'));
		$principal = str_replace('/calendar-proxy-write', '', $principal);
		$principal = rtrim($principal, '/user');
		return $principal;
	}

	public function UpdateCalendarCache($oAccount, $oCalendar)
	{
		$oCalendarInfo = $this->GetCalendarInfo($oCalendar);
		$this->InitCalendar($oCalendarInfo);

		$sUrl = trim($oCalendarInfo->Url, '/');
		$this->Server->GetCacheBackend()->deleteRemindersCache($sUrl);
		$this->Server->GetCacheBackend()->createRemindersCache($oAccount->Email, $sUrl);

		$aDelegates = $this->Server->GetCacheBackend()->getDelegates($sUrl);
		if (count($aDelegates) > 0)
		{
			foreach ($aDelegates as $aDelegate)
			{
				$this->Server->GetCacheBackend()->deleteRemindersCache($aDelegate['uri']);
				$this->Server->GetCacheBackend()->createRemindersCache($aDelegate['user'], $aDelegate['uri']);
			}
		}
	}

	public function DeleteCalendarCache($oAccount, $oCalendar)
	{
		$oCalendarInfo = $this->GetCalendarInfo($oCalendar);
		$this->InitCalendar($oCalendarInfo);

		$sUrl = trim($oCalendarInfo->Url, '/');
		$this->Server->GetCacheBackend()->deleteRemindersCache($sUrl);

		$aDelegates = $this->Server->GetCacheBackend()->getDelegates($sUrl);
		if (count($aDelegates) > 0)
		{
			foreach ($aDelegates as $aDelegate)
			{
				$this->Server->GetCacheBackend()->deleteRemindersCache($aDelegate['uri']);
			}
		}
	}
}
