<?php

/**
 * Copyright (C) 2002-2012 AfterLogic Corp. (www.afterlogic.com)
 * Distributed under the terms of the license described in LICENSE.txt
 *
 */

/**
 * @property mixed $IdEvent
   @property string $StartDate
   @property string $StartTime
   @property string $EndDate
   @property string $EndTime
   @property string $EventStartTime
   @property bool $AllDay
   @property string $Name
   @property string $Description
   @property bool $AllowRepeat
   @property string $RepeatPeriod
   @property string $RepeatTimes
   @property string $RepeatUntil
   @property string $RepeatOrder
   @property string $RepeatEnd
   @property string $RepeatWeekNum
   @property bool $RepeatSun
   @property bool $RepeatMon
   @property bool $RepeatTue
   @property bool $RepeatWed
   @property bool $RepeatThu
   @property bool $RepeatFri
   @property bool $RepeatSat
   @property string $ReminderOffset
   @property array $AppointmentsToDelete;
   @property array $AppointmentsToSave;
   
   @property string $EventStartTime;
   @property bool $Deleted;
 *
 * @package Calendar
 * @subpackage Classes
 */
class CEvent
{
	public $IdEvent;
	public $StartDate;
	public $StartTime;
	public $EndDate;
	public $EndTime;
	public $AllDay;
	public $Name;
	public $Description;
	public $Location;
	
	public $AllowRepeat;
	public $RepeatPeriod;
	public $RepeatTimes;
	public $RepeatUntil;
	public $RepeatOrder;
	public $RepeatEnd;
	public $RepeatWeekNum;
	public $RepeatSun;
	public $RepeatMon;
	public $RepeatTue;
	public $RepeatWed;
	public $RepeatThu;
	public $RepeatFri;
	public $RepeatSat;
	
	public $ReminderOffset;
	
	public $AppointmentsToDelete;
	public $AppointmentsToSave;
	
	public $EventStartTime;
    public $Deleted;

	public function __construct()
	{
		$this->IdEvent		  = null;
		$this->StartDate	  = null;
		$this->StartTime	  = null;
		$this->EndDate		  = null;
		$this->EndTime		  = null;
		$this->AllDay		  = false;
		$this->Name			  = null;
		$this->Description	  = null;
		$this->Location		  = null;
		$this->AllowRepeat	  = false;
		$this->RepeatPeriod	  = null;
		$this->RepeatTimes	  = null;
		$this->RepeatUntil	  = null;
		$this->RepeatOrder	  = null;
		$this->RepeatEnd	  = null;
		$this->RepeatWeekNum  = null;
		$this->RepeatSun	  = false;
		$this->RepeatMon	  = false;
		$this->RepeatTue	  = false;
		$this->RepeatWed	  = false;
		$this->RepeatThu	  = false;
		$this->RepeatFri	  = false;
		$this->RepeatSat	  = false;
		$this->ReminderOffset = null;
		$this->AppointmentsToDelete = null;
		$this->AppointmentsToSave = null;
		
		$this->EventStartTime = null;
		$this->Deleted = null;
	}

}
