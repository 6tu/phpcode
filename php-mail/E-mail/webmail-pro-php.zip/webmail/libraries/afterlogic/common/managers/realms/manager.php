<?php

/*
 * Copyright (C) 2002-2012 AfterLogic Corp. (www.afterlogic.com)
 * Distributed under the terms of the license described in LICENSE.txt
 *
 */

/**
 * @package Realms
 */
class CApiRealmsManager extends AApiManagerWithStorage
{
	/**
	 * @var array
	 */
	static $aRealmNameCache = array();

	/**
	 * @param CApiGlobalManager &$oManager
	 */
	public function __construct(CApiGlobalManager &$oManager, $sForcedStorage = '')
	{
		parent::__construct('realms', $oManager, $sForcedStorage);

		$this->inc('classes.realm');
	}

	/**
	 * @return bool
	 */
	public function IsRealmQuotaEnabled()
	{
		return (bool) CApi::GetConf('realm.quota', false);
	}

	public function ___QCallback($sValue)
	{
		return '"'.$sValue.'"';
	}

	/**
	 * @param string $sName
	 * @param array $aParameters
	 *
	 * @return string
	 */
	protected function systemScriptCall($sName, $aParameters = array())
	{
//__create_realm.sh   REALM_NAME QUOTA_IN_KB
//__delete_realm.sh   REALM_NAME
//
//__create_realm_domain.sh  REALM_NAME DOMAIN_NAME
//__delete_realm_domain.sh  REALM_NAME DOMAIN_NAME
//
//__set_realm_quota.sh  REALM_NAME QUOTA_IN_KB
//__get_realm_quota.sh  REALM_NAME

		$sPath = '/usr/mailsuite/scripts/';
		$sFullPath = $sPath.$sName;

		if (is_array($aParameters) && 0 < count($aParameters))
		{
			$aParameters = array_map(array(&$this, '___QCallback'), $aParameters);
		}

		$sParameters = is_array($aParameters) && 0 < count($aParameters) ?
			' '.implode(' ', $aParameters) : '';

		$sResult = '';
		if (@file_exists($sFullPath))
		{
			CApi::Log('[CMD] shell_exec "'.$sFullPath.$sParameters.'"');
			$sResult = trim(shell_exec($sFullPath.$sParameters));
			if (empty($sResult))
			{
				CApi::Log('[CMD] shell_exec / result is empty', ELogLevel::Error);
			}
			else
			{
				CApi::Log('[CMD] shell_exec = '.$sResult);
			}
		}
		else
		{
			CApi::Log('[CMD] File "'.$sFullPath.'" does not exist', ELogLevel::Error);
		}

		return $sResult;
	}

	/**
	 * @param int $iPage
	 * @param int $iRealmsPerPage
	 * @param string $sOrderBy = 'Login'
	 * @param bool $bOrderType = true
	 * @param string $sSearchDesc = ''
	 *
	 * @return array | false [Id => [Login, Description]]
	 */
	public function GetRealmList($iPage, $iRealmsPerPage, $sOrderBy = 'Login', $bOrderType = true, $sSearchDesc = '')
	{
		$aResult = false;
		try
		{
			$aResult = $this->oStorage->GetRealmList($iPage, $iRealmsPerPage, $sOrderBy, $bOrderType, $sSearchDesc);
		}
		catch (CApiBaseException $oException)
		{
			$this->setLastException($oException);
		}
		return $aResult;
	}

	/**
	 * @param string $sSearchDesc = ''
	 *
	 * @return int | false
	 */
	public function GetRealmCount($sSearchDesc = '')
	{
		$iResult = false;
		try
		{
			$iResult = $this->oStorage->GetRealmCount($sSearchDesc);
		}
		catch (CApiBaseException $oException)
		{
			$this->setLastException($oException);
		}
		return $iResult;
	}

	/**
	 * @param int $iRealmId
	 *
	 * @return CRealm
	 */
	public function GetRealmById($iRealmId)
	{
		$oRealm = null;
		try
		{
			$oRealm = $this->oStorage->GetRealmById($iRealmId);

			if ($oRealm && $this->IsRealmQuotaEnabled())
			{
				$sResult = $this->systemScriptCall('__get_realm_quota.sh', array($oRealm->Login));

				$aMatch = array();
				if (preg_match('/^(\d+) (\d+) (\d+)$/', $sResult, $aMatch) && isset($aMatch[1]) && isset($aMatch[3]))
				{
					$oRealm->QuotaInMB = (int) $aMatch[3];
					$oRealm->UsedSpaceInMB = (int) $aMatch[1];
				}
				else
				{
					if (!empty($sResult))
					{
						CApi::Log('Invalid realm quota and used space result = "'.$sResult.'"', ELogLevel::Error);
					}
				}
			}
		}
		catch (CApiBaseException $oException)
		{
			$this->setLastException($oException);
		}

		return $oRealm;
	}

	/**
	 * @param CRealm $oRealm
	 * @param CDomain $oDomain
	 *
	 * @return bool
	 */
	public function DomainCreateSystemCall(CDomain $oDomain)
	{
		if (!$this->IsRealmQuotaEnabled())
		{
			return false;
		}

		$sRealmLogin = $this->GetRealmLoginById($oDomain->IdRealm, true);
		return !empty($sRealmLogin) && '1' === $this->systemScriptCall('__create_realm_domain.sh', array($sRealmLogin, $oDomain->Name));
	}

	/**
	 * @param CRealm $oRealm
	 * @param CDomain $oDomain
	 *
	 * @return bool
	 */
	public function DomainDeleteSystemCall(CDomain $oDomain)
	{
		if (!$this->IsRealmQuotaEnabled())
		{
			return false;
		}

		$sRealmLogin = $this->GetRealmLoginById($oDomain->IdRealm, true);
		return !empty($sRealmLogin) && '1' === $this->systemScriptCall('__delete_realm_domain.sh', array($sRealmLogin, $oDomain->Name));
	}

	/**
	 * @param string $sRealmLogin
	 * @param string $sRealmPassword = null
	 *
	 * @return int
	 */
	public function GetRealmIdByLogin($sRealmLogin, $sRealmPassword = null)
	{
		$iRealmId = 0;
		try
		{
			if (!empty($sRealmLogin))
			{
				$iRealmId = $this->oStorage->GetRealmIdByLogin($sRealmLogin, $sRealmPassword);
			}
		}
		catch (CApiBaseException $oException)
		{
			$this->setLastException($oException);
		}
		return $iRealmId;
	}

	/**
	 * @param int $iIdRealm
	 * @param bool $bUseCache = false
	 *
	 * @return string
	 */
	public function GetRealmLoginById($iIdRealm, $bUseCache = false)
	{
		$sResult = '';
		try
		{
			if (0 < $iIdRealm)
			{
				if ($bUseCache && !empty(self::$aRealmNameCache[$iIdRealm]))
				{
					return self::$aRealmNameCache[$iIdRealm];
				}

				$sResult = $this->oStorage->GetRealmLoginById($iIdRealm);
				if ($bUseCache && !empty($sResult))
				{
					self::$aRealmNameCache[$iIdRealm] = $sResult;
				}
			}
		}
		catch (CApiBaseException $oException)
		{
			$this->setLastException($oException);
		}
		return $sResult;
	}

	/**
	 * @param CRealm $oRealm
	 *
	 * @return bool
	 */
	public function RealmExists(CRealm $oRealm)
	{
		$bResult = false;
		try
		{
			$bResult = $this->oStorage->RealmExists($oRealm);
		}
		catch (CApiBaseException $oException)
		{
			$this->setLastException($oException);
		}
		return $bResult;
	}

	/**
	 * @param int $iRealmId
	 *
	 * @return array
	 */
	public function GetRealmDomains($iRealmId)
	{
		$mResult = false;
		try
		{
			$mResult = $this->oStorage->GetRealmDomains($iRealmId);
		}
		catch (CApiBaseException $oException)
		{
			$this->setLastException($oException);
		}
		return $mResult;
	}

	/**
	 * @param CRealm $oRealm
	 *
	 * @return bool
	 */
	public function CreateRealm(CRealm &$oRealm)
	{
		$bResult = false;
		try
		{
			if ($oRealm->Validate())
			{
				if (!$this->RealmExists($oRealm))
				{
					if (!$this->oStorage->CreateRealm($oRealm))
					{
						throw new CApiManagerException(Errs::RealmsManager_RealmCreateFailed);
					}
				}
				else
				{
					throw new CApiManagerException(Errs::RealmsManager_RealmAlreadyExists);
				}
			}

			if ($this->IsRealmQuotaEnabled())
			{
				$this->systemScriptCall('__create_realm.sh', array($oRealm->Login, $oRealm->QuotaInMB));
			}

			$bResult = true;
		}
		catch (CApiBaseException $oException)
		{
			$bResult = false;
			$this->setLastException($oException);
		}

		return $bResult;
	}

	/**
	 * @param CRealm $oRealm
	 */
	public function UpdateRealm(CRealm $oRealm)
	{
		$bResult = false;
		try
		{
			if ($oRealm->Validate())
			{
				if (!$this->RealmExists($oRealm))
				{
					if (!$this->oStorage->UpdateRealm($oRealm))
					{
						throw new CApiManagerException(Errs::RealmsManager_RealmUpdateFailed);
					}

					if (null !== $oRealm->GetObsoleteValue('IsDisabled'))
					{
						/* @var $oDomainsApi CApiDomainsManager */
						$oDomainsApi = CApi::Manager('domains');
						if (!$oDomainsApi->EnableOrDisableDomainsByRealmId($oRealm->IdRealm, !$oRealm->IsDisabled))
						{
							$oException = $oDomainsApi->GetLastException();
							if ($oException)
							{
								throw $oException;
							}
						}
					}

					if ($this->IsRealmQuotaEnabled() && null !== $oRealm->GetObsoleteValue('QuotaInMB'))
					{
						$this->systemScriptCall('__set_realm_quota.sh', array($oRealm->Login, $oRealm->QuotaInMB));
					}
				}
				else
				{
					throw new CApiManagerException(Errs::RealmsManager_RealmAlreadyExists);
				}
			}

			$bResult = true;
		}
		catch (CApiBaseException $oException)
		{
			$bResult = false;
			$this->setLastException($oException);
		}
		return $bResult;
	}

	/**
	 * @param CRealm $oRealm
	 *
	 * @return bool
	 */
	public function DeleteRealm(CRealm $oRealm)
	{
		$bResult = false;
		try
		{
			if ($oRealm)
			{
				/* @var $oDomainsApi CApiDomainsManager */
				$oDomainsApi = CApi::Manager('domains');
				if (!$oDomainsApi->DeleteDomainsByRealmId($oRealm->IdRealm, true))
				{
					$oException = $oDomainsApi->GetLastException();
					if ($oException)
					{
						throw $oException;
					}
				}

				$bResult = $this->oStorage->DeleteRealm($oRealm->IdRealm);

				if ($bResult && $this->IsRealmQuotaEnabled())
				{
					$this->systemScriptCall('__delete_realm.sh', array($oRealm->Login));
				}
			}
		}
		catch (CApiBaseException $oException)
		{
			$this->setLastException($oException);
		}

		return $bResult;
	}
}
