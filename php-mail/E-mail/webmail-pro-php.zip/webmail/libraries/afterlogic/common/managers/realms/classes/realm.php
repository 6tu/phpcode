<?php

/*
 * Copyright (C) 2002-2012 AfterLogic Corp. (www.afterlogic.com)
 * Distributed under the terms of the license described in LICENSE.txt
 *
 */

/**
 * @property int $IdRealm
 * @property bool $IsDisabled
 * @property bool $IsEnableAdminPanelLogin
 * @property string $Login
 * @property string $Email
 * @property string $PasswordHash
 * @property string $Description
 * @property string $QuotaInMB
 * @property string $UsedSpaceInMB
 * @property int $UserCountLimit
 * @property int $DomainCountLimit
 *
 * @package Realms
 * @subpackage Classes
 */
class CRealm extends api_AContainer
{
	public function __construct($sLogin = '', $Description = '')
	{
		parent::__construct(get_class($this), 'IdRealm');

		$this->__USE_TRIM_IN_STRINGS__ = true;

		$this->SetDefaults(array(
			'IdRealm'	=> 0,
			'IsDisabled'	=> false,
			'Login'			=> $sLogin,
			'Email'			=> '',
			'PasswordHash'	=> '',
			'Description'	=> $Description,
			'IsEnableAdminPanelLogin'	=> false,
			'QuotaInMB'		=> 0,
			'UsedSpaceInMB'	=> 0,
			'UserCountLimit'	=> 0,
			'DomainCountLimit'	=> 0
		));

		$this->SetLower(array('Login', 'Email'));
	}

	/**
	 * @param string $sPassword
	 *
	 * @return string
	 */
	public static function HashPassword($sPassword)
	{
		return empty($sPassword) ? '' : md5('Awm'.md5($sPassword.'Awm'));
	}

	/**
	 * @param string $sPassword
	 *
	 * @return bool
	 */
	public function ValidatePassword($sPassword)
	{
		return self::HashPassword($sPassword) === $this->PasswordHash;
	}

	/**
	 * @param string $sPassword
	 */
	public function SetPassword($sPassword)
	{
		$this->PasswordHash = self::HashPassword($sPassword);
	}

	public function GetUserCount()
	{
		$oUsersApi = CApi::Manager('users');
		return $oUsersApi->GetUserCountByRealmId($this->IdRealm);
	}

	public function GetDomainCount()
	{
		$oDomainsApi = CApi::Manager('domains');
		return $oDomainsApi->GetDomainCount('', $this->IdRealm);
	}

	/**
	 * @return bool
	 */
	public function Validate()
	{
		switch (true)
		{
			case !api_Validate::IsValidRealmLogin($this->Login):
				throw new CApiValidationException(Errs::Validation_InvalidRealmName);
			case api_Validate::IsEmpty($this->Login):
				throw new CApiValidationException(Errs::Validation_FieldIsEmpty, null, array(
					'{{ClassName}}' => 'CRealm', '{{ClassField}}' => 'Login'));
			case !api_Validate::IsEmpty($this->Email) && !preg_match('/^[^@]+@[^@]+$/', $this->Email):
				throw new CApiValidationException(Errs::Validation_InvalidEmail, null, array(
					'{{ClassName}}' => 'CRealm', '{{ClassField}}' => 'Email'));
		}

		return true;
	}

	/**
	 * @return array
	 */
	public function GetMap()
	{
		return self::GetStaticMap();
	}

	/**
	 * @return array
	 */
	public static function GetStaticMap()
	{
		return array(
			'IdRealm'	=> array('int', 'id_realm', false),
			'IsDisabled'	=> array('bool', 'disabled'),
			'IsEnableAdminPanelLogin' => array('bool', 'login_enabled'),
			'Login'			=> array('string(255)', 'login', true, false),
			'Email'			=> array('string(255)', 'email'),
			'PasswordHash'	=> array('string(100)', 'password'),
			'Description'	=> array('string(255)', 'description'),
			'QuotaInMB'		=> array('int'),
			'UsedSpaceInMB'	=> array('int'),
			'UserCountLimit'	=> array('int', 'user_count_limit'),
			'DomainCountLimit'	=> array('int', 'domain_count_limit')
		);
	}
}
