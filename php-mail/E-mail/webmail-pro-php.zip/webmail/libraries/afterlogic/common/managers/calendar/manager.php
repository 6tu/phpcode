<?php

/*
 * Copyright (C) 2002-2012 AfterLogic Corp. (www.afterlogic.com)
 * Distributed under the terms of the license described in LICENSE.txt
 *
 */


/**
 * @package Calendar
 */
class CApiCalendarManager extends AApiManagerWithStorage
{
	/*
	 * @var $ApiUsersManager CApiUsersManager
	 */
	protected $ApiUsersManager;

	/*
	 * @var $ApiCollaborationManager CApiCollaborationManager
	 */
	public $ApiCollaborationManager;

	/**
	 * @param CApiGlobalManager &$oManager
	 */
	public function __construct(CApiGlobalManager &$oManager, $sForcedStorage = '')
	{
		parent::__construct('calendar', $oManager, $sForcedStorage);

		$this->inc('classes.utils');
		$this->inc('classes.colors');
		$this->inc('classes.calendar');
		$this->inc('classes.event');
		$this->inc('classes.exclusion');

		$this->ApiUsersManager = CApi::Manager('users');
		$this->ApiCollaborationManager = CApi::Manager('collaboration');
	}

	public function GetCalendarAccess($sUser, $sCalendarId)
	{
		$oResult = null;
		try
		{
			$oResult = $this->oStorage->GetCalendarAccess($sUser, $sCalendarId);
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	public function GetPublicUser()
	{
		$oResult = null;
		try
		{
			$oResult = $this->oStorage->GetPublicUser();
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	public function GetPublicAccount()
	{
		$oAccount = new CAccount(new CDomain());
		$oAccount->Email = $this->GetPublicUser();
		return $oAccount;
	}

	// Calendars
	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 */
	public function GetCalendar($oAccount, $sCalendarId)
	{
		$oResult = false;
		try
		{
			$oResult = $this->oStorage->GetCalendar($oAccount, $sCalendarId);
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param string $sCalendarId
	 */
	public function GetPublicCalendar($sCalendarId)
	{
		$oResult = null;
		try
		{
			$oResult = $this->oStorage->GetCalendar($this->GetPublicAccount(), $sCalendarId);
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param string $sHash
	 */
	public function GetPublicCalendarByHash($sHash)
	{
		$oResult = null;
		try
		{
			$sCalendarId = CCalendarUtils::decryptId($sHash);
			$oResult = $this->oStorage->GetCalendar($this->GetPublicAccount(), $sCalendarId);
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param string $sCalendarId
	 */
	public function GetPublicCalendarHash($oAccount, $sCalendarId)
	{
		$oResult = null;
		try
		{
			$oResult = $this->oStorage->GetPublicCalendarHash($oAccount, $sCalendarId);
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 */
	public function GetUserCalendars($oAccount)
	{
		return $this->oStorage->GetCalendars($oAccount);
	}

	/**
	 * @param CAccount $oAccount
	 */
	public function GetSharedCalendars($oAccount)
	{
		return $this->oStorage->GetCalendarsShared($oAccount);
	}

	public function ___qSortCallback ($a, $b)
	{
		return ($a['is_default'] === '1' ? -1 : 1);
	}

	/**
	 * @param CAccount $oAccount
	 */
	public function GetCalendars($oAccount)
	{
		$oResult = null;
		try
		{
			$oResult = array();
			$oResult['user'] = array();
			$oResult['shared'] = array();

			$oCalendarsOwn = $this->oStorage->GetCalendars($oAccount);
			$oCalendarsShared = array();
			if ($oAccount->User->GetCapa('CAL_SHARING'))
			{
				$oCalendarsShared = $this->oStorage->GetCalendarsShared($oAccount);
			}
			$oCalendars = array_merge($oCalendarsOwn, $oCalendarsShared);

			foreach ($oCalendars as $oCalendar)
			{
				$sCalendarActive = '1';
				$sCalendarIdForCookie = str_replace('.', '_', $oCalendar->Id);
				if (isset($_COOKIE[$sCalendarIdForCookie]))
				{
					$sCalendarActive = $_COOKIE[$sCalendarIdForCookie];
				}

				$aCalendar = array(
					'calendar_id' => $oCalendar->Id,
					'url' => $oCalendar->Url,
					'ics_download' => 'export.php?calendar&calendar_id='.$oCalendar->Id,
					'active' => $sCalendarActive,
					'color' => CalendarColors::GetColorNumber($oCalendar->Color),
					'description' => $oCalendar->Description,
					'principal_id' => $this->oStorage->GetMainPrincipalUrl($oCalendar->Principals[0]),
					'name' => $oCalendar->DisplayName,
					'user_id' => $oAccount->IdUser,
					'ical_hash' => null,
					'owner' => $oCalendar->Owner,
					'is_default' => $oCalendar->IsDefault ? '1' : '0',
				);

				if ($oCalendar->Shared)
				{
					$aCalendar['publication_hash'] = null;
					$aCalendar['publication_level'] = '0';
					$aCalendar['shares'] = array();
					$aCalendar['sharing_active'] = '1';
					$aCalendar['sharing_id'] = $oCalendar->Id;
					$aCalendar['sharing_level'] = $oCalendar->SharingLevel;
					$aCalendar['is_default'] = '0';
					$oResult['shared'][$oCalendar->Id] = $aCalendar;
				}
				else
				{
					$aCalendarUsers = $this->oStorage->GetCalendarUsers($oAccount, $oCalendar);

					$aShares = array();
					$sPubHash = null;
					$sPubLevel = null;

					foreach ($aCalendarUsers as $aCalendarUser)
					{
						if ($aCalendarUser['email'] == $this->oStorage->GetPublicUser())
						{
							$sPubLevel = '1';
							$sPubHash = $this->oStorage->GetPublicCalendarHash($oAccount, $oCalendar->Id);
						}
						else
						{
							$aShares[] = array(
								'id_share' => $aCalendarUser['email'],
								'email_to_user' => $aCalendarUser['email'],
								'access_level' => (int)$aCalendarUser['access_level']
							);
						}
					}

					$aCalendar['publication_hash'] = $sPubHash;
					$aCalendar['publication_level'] = $sPubLevel;
					$aCalendar['shares'] = $aShares;
					$aCalendar['sharing_active'] = null;
					$aCalendar['sharing_id'] = null;
					$aCalendar['sharing_level'] = null;

					$oResult['user'][$oCalendar->Id] = $aCalendar;
				}
			}
			uasort($oResult['user'], array(&$this, '___qSortCallback'));

		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sName
	 * @param string $sDescription
	 * @param int $iOrder
	 * @param string $sColor
	 */
	public function CreateCalendar($oAccount, $sName, $sDescription, $iOrder, $sColor)
	{
		$oResult = null;
		try
		{
			$oResult = $this->oStorage->CreateCalendar($oAccount, $sName, $sDescription, $iOrder, $sColor);
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param string $sName
	 * @param string $sDescription
	 * @param int $iOrder
	 * @param string $sColor
	 */
	public function UpdateCalendar($oAccount, $sCalendarId, $sName, $sDescription, $iOrder, $sColor)
	{
		$oResult = null;
		try
		{
			$oResult = $this->oStorage->UpdateCalendar($oAccount, $sCalendarId, $sName, $sDescription, $iOrder, $sColor);
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param string $sCalendarId
	 * @param int $iVisible
	 */
	public function UpdateCalendarVisible($sCalendarId, $iVisible)
	{
		$oResult = null;
		try
		{
			$this->oStorage->UpdateCalendarVisible($sCalendarId, $iVisible);
			$oResult = true;
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param string $sColor
	 */
	public function UpdateCalendarColor($oAccount, $sCalendarId, $sColor)
	{
		$oResult = null;
		try
		{
			$oResult = $this->oStorage->UpdateCalendarColor($oAccount, $sCalendarId, $sColor);
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 */
	public function DeleteCalendar($oAccount, $sCalendarId)
	{
		$oResult = null;
		try
		{
			if (basename($sCalendarId) !== afterlogic_DAV_Constants::CALENDAR_DEFAULT_NAME)
			{
				$oResult = $this->oStorage->DeleteCalendar($oAccount, $sCalendarId);
			}
			else
			{
				$oResult = false;
			}
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 */
	public function UnsubscibeCalendar($oAccount, $sCalendarId)
	{
		$oResult = null;
		if ($oAccount->User->GetCapa('CAL_SHARING'))
		{
			try
			{
				$oResult = $this->oStorage->UnsubscibeCalendar($oAccount, $sCalendarId);
			}
			catch (Exception $oException)
			{
				$oResult = false;
				$this->setLastException($oException);
			}
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param string $sUserId
	 * @param int $iPerms
	 */
	public function UpdateCalendarShare($oAccount, $sCalendarId, $sUserId, $iPerms = ECalendarPermission::RemovePermission)
	{
		$oResult = null;
		if ($oAccount->User->GetCapa('CAL_SHARING'))
		{
			try
			{
				$oResult = $this->oStorage->UpdateCalendarShare($oAccount, $sCalendarId, $sUserId, $iPerms);
			}
			catch (Exception $oException)
			{
				$oResult = false;
				$this->setLastException($oException);
			}
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 */
	public function PublicCalendar($oAccount, $sCalendarId)
	{
		$oResult = null;
		try
		{
			$oResult = $this->oStorage->PublicCalendar($oAccount, $sCalendarId);
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 */
	public function UnPublicCalendar($oAccount, $sCalendarId)
	{
		$oResult = null;
		try
		{
			$oResult = $this->oStorage->UnPublicCalendar($oAccount, $sCalendarId);
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param string $sUserId
	 */
	public function DeleteCalendarShare($oAccount, $sCalendarId, $sUserId)
	{
		$oResult = null;
		try
		{
			$oResult = $this->UpdateCalendarShare($oAccount, $sCalendarId, $sUserId);
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param FileInfo $oCalendar
	 */
	public function GetCalendarUsers($oAccount, $oCalendar)
	{
		$oResult = null;
		if ($oAccount->User->GetCapa('CAL_SHARING'))
		{
			try
			{
				$oResult = $this->oStorage->GetCalendarUsers($oAccount, $oCalendar);
			}
			catch (Exception $oException)
			{
				$oResult = false;
				$this->setLastException($oException);
			}
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @return string
	 */
	public function ExportCalendarToIcs($oAccount, $sCalendarId)
	{
		$mResult = null;
		try
		{
			$mResult = $this->oStorage->ExportCalendarToIcs($oAccount, $sCalendarId);
		}
		catch (Exception $oException)
		{
			$mResult = false;
			$this->setLastException($oException);
		}
		return $mResult;
	}


	// Events

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param string $dStart
	 * @param string $dFinish
	 */
	public function GetEvents($oAccount, $sCalendarId, $dStart = null, $dFinish = null)
	{
		$oResult = null;
		try
		{
			$oResult = array();
			$oResult['events'] = array();
			$oResult['exclusions'] = array();
			$oResult['reminders'] = array();
			$oResult['appointments'] = array();

			if ($dStart != null) $dStart = $dStart . 'T000000Z';
			if ($dFinish != null) $dFinish = $dFinish . 'T235959Z';

			$oCalendarInfo = $this->oStorage->GetCalendar($oAccount, $sCalendarId);
			if ($oCalendarInfo)
			{
				$aEvents = $this->oStorage->GetEvents($oAccount, $sCalendarId, $dStart, $dFinish);
				if (is_array($aEvents))
				{
					foreach ($aEvents as $oEvent)
					{
						try
						{
							$parsedData = $this->ParseVCalendar($oAccount, $oCalendarInfo, $oEvent);

							$oResult['events'] = array_merge($oResult['events'], $parsedData['events']);
							$oResult['exclusions'] = array_merge($oResult['exclusions'], $parsedData['exclusions']);
							$oResult['reminders'] = array_merge($oResult['reminders'], $parsedData['reminders']);
							$oResult['appointments'] = array_merge($oResult['appointments'], $parsedData['appointments']);
						}
						catch(Exception $ex)
						{
							CApi::Log("Error: Can't parsed VCALEDAR object: \r\n" . $oEvent->serialize());
						}
					}
				}
			}

			return $oResult;
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param string $sCalendarId
	 * @param string $dStart
	 * @param string $dFinish
	 */
	public function GetPublicEvents($sCalendarId, $dStart = null, $dFinish = null)
	{
		return $this->GetEvents($this->GetPublicAccount(), $sCalendarId, $dStart, $dFinish);
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param string $sEventId
	 */
	public function GetEvent($oAccount, $sCalendarId, $sEventId)
	{
		$mResult = null;
		try
		{
			$mResult = array();
			$aData = $this->oStorage->GetEvent($oAccount, $sCalendarId, $sEventId);
			if ($aData !== false)
			{
				$oCalendar = $this->oStorage->GetCalendar($oAccount, $sCalendarId);
				$mResult = $this->ParseVCalendar($oAccount, $oCalendar, $aData['vcal']);
			}
		}
		catch (Exception $oException)
		{
			$mResult = false;
			$this->setLastException($oException);
		}
		return $mResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param CEvent $oEvent
	 */
	public function CreateEvent($oAccount, $sCalendarId, $oEvent)
	{
		$oResult = null;
		try
		{
			$vCal = new Sabre_VObject_Component('VCALENDAR');
			$vCal->VERSION = "2.0";
			$vCal->CALSCALE = 'GREGORIAN';

			$sEventId = Sabre_DAV_UUIDUtil::getUUID();

			$vCal->VEVENT = new Sabre_VObject_Component('VEVENT');
			$vCal->VEVENT->SEQUENCE = 1;
			$vCal->VEVENT->TRANSP = 'OPAQUE';

			$dtstamp = new Sabre_VObject_Property_DateTime('DTSTAMP');
			$dtstamp->setDateTime(new DateTime('now'), Sabre_VObject_Property_DateTime::UTC);
			$vCal->VEVENT->add($dtstamp);

			$this->oStorage->Init($oAccount);
			$this->PrepareEvent($oAccount, $oEvent, $vCal, $vCal->VEVENT, $sEventId);
			$oResult = $this->oStorage->CreateEvent($oAccount, $sCalendarId, $sEventId, $vCal);
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param array $sData
	 */
	public function CreateEventData($oAccount, $sCalendarId, $sEventId, $sData)
	{
		$oResult = null;
		try
		{
			$vCal = Sabre_VObject_Reader::read($sData);
			if ($vCal)
			{
				$oResult = $this->oStorage->CreateEvent($oAccount, $sCalendarId, $sEventId, $vCal);
			}
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sEventId
	 * @param string $sCalendarId
	 * @param CEvent $oEvent
	 */
	public function UpdateEvent($oAccount, $sCalendarId, $sEventId, $oEvent)
	{
		$oResult = null;
		try
		{
			$aData = $this->oStorage->GetEvent($oAccount, $sCalendarId, $sEventId);
			if ($aData !== false)
			{
				$vCal = $aData['vcal'];

				if ($vCal)
				{
					$index = $this->GetBaseVEventIndex($vCal->VEVENT);
					if ($index !== false)
					{
						$this->PrepareEvent($oAccount, $oEvent, $vCal, $vCal->VEVENT[$index]);
					}
				}
				$oResult = $this->oStorage->UpdateEvent($oAccount, $sCalendarId, $aData['href'], $vCal);
			}
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	public function MoveEvent($oAccount, $sCalendarId, $sNewCalendarId, $sEventId)
	{
		$oResult = null;
		try
		{
			$aData = $this->oStorage->GetEvent($oAccount, $sCalendarId, $sEventId);
			if ($aData !== false)
			{
				$oResult = $this->oStorage->MoveEvent($oAccount, $sCalendarId, $sNewCalendarId, $aData['href'], $aData['data']);
				return true;
			}
			return false;
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param string $sEventId
	 */
	public function DeleteEvent($oAccount, $sCalendarId, $sEventId)
	{
		$oResult = null;
		try
		{
			$aData = $this->oStorage->GetEvent($oAccount, $sCalendarId, $sEventId);
			if ($aData !== false)
			{
				$vCal = $aData['vcal'];

				if ($vCal)
				{
					$iIndex = $this->GetBaseVEventIndex($vCal->VEVENT);
					if ($iIndex !== false)
					{
						$vEvent = $vCal->VEVENT[$iIndex];
						
						$sOrganizer = null;
						if (isset($vEvent->ORGANIZER))
						{
							$sOrganizer = str_replace('mailto:', '', strtolower($vEvent->ORGANIZER->value));
						}
						
						if (isset($sOrganizer))
						{
							if ($sOrganizer == $oAccount->Email)
							{
								$aAttendees = $vEvent->ATTENDEE;
								if (isset($aAttendees))
								{
									foreach($aAttendees as $oAttendee)
									{
										$sEmail = str_replace('mailto:', '', strtolower($oAttendee->value));
										$PARTSTAT = $oAttendee->offsetGet('PARTSTAT');
										if (!isset($PARTSTAT) || (isset($PARTSTAT) && $PARTSTAT->value != 'DECLINED'))
										{
											$sMethod = 'REQUEST';
											$vCal->METHOD = 'CANCEL';
											$sBody = $vCal->serialize();
											unset($vCal->METHOD);

											$this->sendAppointmentMessage($oAccount, $sEmail, $vEvent->SUMMARY->value,
													$sBody, $sMethod);
										}
									}
								}
							}
							else
							{
								$vEvent->{'LAST-MODIFIED'} = gmdate("Ymd\THis\Z");								
								unset($vEvent->ATTENDEE);
								$attendee = new Sabre_VObject_Property('ATTENDEE');
								$attendee->value = 'mailto:'.$oAccount->Email;
								$attendee->offsetSet('PARTSTAT', 'DECLINED');
								$sSubject = $vEvent->SUMMARY->value . ': Declined';
								$attendee->offsetSet('RESPONDED-AT', gmdate("Ymd\THis\Z"));
								$vEvent->add($attendee);
								
								$sMethod = 'REPLY';
								$vCal->METHOD = $sMethod;
								$sBody = $vCal->serialize();
								unset($vCal->METHOD);

								$this->sendAppointmentMessage($oAccount, $sOrganizer, $sSubject,
										$sBody, $sMethod);
							}
						}
					}
				}
				$oResult = $this->oStorage->DeleteEvent($oAccount, $sCalendarId, $aData['href']);
			}
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param string $sEventId
	 * @param string $iRecurrenceId
	 */
	public function GetExclusion($oAccount, $sCalendarId, $sEventId, $iRecurrenceId)
	{
		$oResult = null;
		try
		{
			$aEvent = $this->GetEvent($oAccount, $sCalendarId, $sEventId);
			if (is_array($aEvent) && isset($aEvent['exclusions']))
			{
				$aExclusions = $aEvent['exclusions'];
				foreach ($aExclusions as $aExclusion)
				{
					if ($iRecurrenceId == $aExclusion['id_recurrence'])
					{
						return $aExclusion;
					}
				}
			}
			return array();
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param string $sEventId
	 * @param CExclusion $oExclusion
	 * @param CEvent $oEvent
	 */
	public function UpdateExclusion($oAccount, $sCalendarId, $sEventId, $oExclusion, $oEvent)
	{
		$oResult = null;
		try
		{
			$aData = $this->oStorage->GetEvent($oAccount, $sCalendarId, $sEventId);
			if ($aData !== false)
			{
				$vCal = $aData['vcal'];
				$index = $this->GetBaseVEventIndex($vCal->VEVENT);
				if ($index !== false)
				{
					unset($vCal->VEVENT[$index]->{'LAST-MODIFIED'});
					$oLastModified = new Sabre_VObject_Property_DateTime('LAST-MODIFIED');
					$oLastModified->setDateTime(new DateTime('now'), Sabre_VObject_Property_DateTime::UTC);
					$vCal->VEVENT[$index]->add($oLastModified);

					$oDTExdate = CCalendarUtils::PrepareDateTime($oExclusion->IdRecurrence,
							$oExclusion->StartTime, $this->oStorage->TimeZone);
					$oExdate = new Sabre_VObject_Property_DateTime('EXDATE');
					$oExdate->setDateTime($oDTExdate, Sabre_VObject_Property_DateTime::UTC);
					$exdate = $oExdate->value;

					$mIndex = $this->isRecurrenceExists($vCal->VEVENT, $oExclusion->IdRecurrence);
					if ($oExclusion->Deleted)
					{
						$vCal->VEVENT[$index]->add(new Sabre_VObject_Property('EXDATE', $exdate));

						if (false !== $mIndex)
						{
							$vEvents = $vCal->VEVENT;
							unset($vCal->VEVENT);

							foreach($vEvents as $vEvent)
							{
								if ($vEvent->{'RECURRENCE-ID'})
								{
									$iRecurrenceId = $this->GetStrDate($vEvent->{'RECURRENCE-ID'}, 'Ymd');
									if ($iRecurrenceId == (int) $oExclusion->IdRecurrence)
									{
										continue;
									}
								}
								$vCal->add($vEvent);
							}
						}
					}
					else
					{
						$recurEvent = null;
						if ($mIndex === false)
						{
							$recurEvent = new Sabre_VObject_Component('VEVENT');
							$recurEvent->SEQUENCE = 1;
							$recurEvent->TRANSP = 'OPAQUE';
							$recurEvent->{'RECURRENCE-ID'} = $exdate;
							$vCal->add($recurEvent);
						}
						else if (isset($vCal->VEVENT[$mIndex]))
						{
							$recurEvent = $vCal->VEVENT[$mIndex];
						}

						if ($recurEvent)
						{
							$this->PrepareEvent($oAccount, $oEvent, $vCal, $recurEvent);
						}
					}

					return $this->oStorage->UpdateEvent($oAccount, $sCalendarId, $aData['href'], $vCal);

				}
			}
			return false;
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param string $sEventId
	 * @param string $iRecurrenceId
	 */
	public function DeleteExclusion($oAccount, $sCalendarId, $sEventId, $iRecurrenceId)
	{
		$oResult = null;
		try
		{
			$aData = $this->oStorage->GetEvent($oAccount, $sCalendarId, $sEventId);
			if ($aData !== false)
			{
				$vCal = $aData['vcal'];

				$vEvents = $vCal->VEVENT;
				unset($vCal->VEVENT);

				foreach($vEvents as $vEvent)
				{
					if ($vEvent->{'RECURRENCE-ID'})
					{
						$iServerRecurrenceId = $this->GetStrDate($vEvent->{'RECURRENCE-ID'}, 'Ymd');
						if ($iRecurrenceId == $iServerRecurrenceId)
						{
							continue;
						}
					}
					$vCal->add($vEvent);
				}
				return $this->oStorage->UpdateEvent($oAccount, $sCalendarId, $aData['href'], $vCal);
			}
			return false;
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sCalendarId
	 * @param string $dStart
	 * @param string $dFinish
	 */
	public function GetAlarms($oAccount, $sCalendarId, $dStart = null, $dFinish = null)
	{
		$oResult = null;
		try
		{
			$oResult = array();
			$oResult['data'] = array();
			$oResult['events'] = array();
			$oResult['exclusions'] = array();
			$oResult['reminders'] = array();
			$oResult['appointments'] = array();

			$oCalendarInfo = $this->oStorage->GetCalendar($oAccount, $sCalendarId);
			if ($oCalendarInfo)
			{
				$aEvents = $this->oStorage->GetAlarms($oAccount, $sCalendarId, $dStart, $dFinish);
				foreach ($aEvents as $oEvent)
				{
					$parsedData = $this->ParseVCalendar($oAccount, $oCalendarInfo, $oEvent, true);

					$oResult['data']  = array_merge($oResult['data'], $parsedData['data']);
					$oResult['events'] = array_merge($oResult['events'], $parsedData['events']);
					$oResult['exclusions'] = array_merge($oResult['exclusions'], $parsedData['exclusions']);
					$oResult['reminders'] = array_merge($oResult['reminders'], $parsedData['reminders']);
					$oResult['appointments'] = array_merge($oResult['appointments'], $parsedData['appointments']);
				}
			}
			return $oResult;
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	public function GetRemindersCache($iType = 0, $start = null, $end = null)
	{
		$oResult = null;
		try
		{
			$oResult = $this->oStorage->GetRemindersCache($iType, $start, $end);
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	public function CreateRemindersCache($user, $calendarUri, $type, $time, $startTime, $eventId)
	{
		$oResult = null;
		try
		{
			$oResult = $this->oStorage->CreateRemindersCache($user, $calendarUri, $type, $time, $startTime, $eventId);
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	public function UpdateRemindersCache($calendarUri, $type, $time = null, $startTime = null, $eventId = null)
	{
		$oResult = null;
		try
		{
			$oResult = $this->oStorage->UpdateRemindersCache($calendarUri, $type, $time, $startTime, $eventId);
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	public function DeleteRemindersCache($calendarUri)
	{
		$oResult = null;
		try
		{
			$oResult = $this->oStorage->DeleteRemindersCache($calendarUri);
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sData
	 * @param string $mFromEmail
	 *
	 * @return bool
	 */
	public function PreprocessAppointment($oAccount, $sData, $mFromEmail)
	{
		$iAccountId = $this->ApiUsersManager->GetDefaultAccountId($oAccount->IdUser);

		/* @var $oAccount CAccount */
		$oAccount = $this->ApiUsersManager->GetAccountById($iAccountId);
		
		$mResult = null;
		try
		{
			$mResult = false;
			$vCal = Sabre_VObject_Reader::read($sData);
			if ($vCal)
			{
				$oMethod = null;
				$sMethod = null;
				if (isset($vCal->METHOD))
				{
					$oMethod = $vCal->METHOD;
					$sMethod = $oMethod->value;
					if ($sMethod !== 'REQUEST' && $sMethod !== 'REPLY' && $sMethod !== 'CANCEL')
					{
						return false;
					}
				}

				$vEvents = $vCal->getBaseComponents('VEVENT');
				if (isset($vEvents) && count($vEvents) > 0)
				{
					$vEvent = $vEvents[0];
					$sEventId = $vEvent->UID->value;
					$sCalId = '';

					$oCals = $this->oStorage->GetCalendars($oAccount);
					$aServerData = false;
					$mResult = array();

					$mResult['Calendars'] = array();
					if (is_array($oCals))
					{
						foreach ($oCals as $sKey => $oCal)
						{
							$mResult['Calendars'][$sKey] = $oCal->DisplayName;
							$aServerData = $this->oStorage->GetEvent($oAccount, $oCal->Id, $sEventId);
							if ($aServerData !== false)
							{
								$aServerData['url'] = $oCal->Id;
								break;
							}
						}
					}

					$oResultCal = $vCal;
					$oResultEvent = $vEvent;

					if ($aServerData !== false)
					{
						$sCalId = $aServerData['url'];
						$serverCal = $aServerData['vcal'];
						if (isset($oMethod))
						{
							$serverCal->METHOD = $oMethod;
						}
						$serverEvents = $serverCal->getBaseComponents('VEVENT');
						$serverEvent = $serverEvents[0];

						if (isset($vEvent->{'LAST-MODIFIED'}) && isset($serverEvent->{'LAST-MODIFIED'}))
						{
							$eventLastModified = $vEvent->{'LAST-MODIFIED'}->getDateTime();
							$srvEventLastModified = $serverEvent->{'LAST-MODIFIED'}->getDateTime();
							if ($srvEventLastModified >= $eventLastModified)
							{
								$oResultCal = $serverCal;
								$oResultEvent = $serverEvent;
							}
							else
							{
								if (isset($sMethod))
								{
									if ($sMethod == 'REPLY')
									{
										$oResultCal = $serverCal;
										$oResultEvent = $serverEvent;
										if (isset($vEvent->ATTENDEE))
										{
											$attendee = $vEvent->ATTENDEE[0];
											$sEmail = str_replace('mailto:', '', strtolower($attendee->value));
											if (isset($oResultEvent->ATTENDEE))
											{
												foreach ($oResultEvent->ATTENDEE as $resultAttendee)
												{
													$sResultEmail = str_replace('mailto:', '', strtolower($resultAttendee->value));
													if ($sResultEmail == $sEmail)
													{
														$PARTSTAT = $attendee->offsetGet('PARTSTAT');
														if (isset($PARTSTAT))
														{
															$resultAttendee->offsetSet('PARTSTAT', $PARTSTAT->value);
														}
														break;
													}
												}
											}
										}
										unset($oResultCal->METHOD);
										$oResultEvent->{'LAST-MODIFIED'} = gmdate("Ymd\THis\Z");
										$this->oStorage->UpdateEventData($oAccount, $sCalId, $sEventId, $oResultCal->serialize());
										$oResultCal->METHOD = $sMethod;
									}
									else if ($sMethod == 'CANCEL')
									{
										$this->DeleteEvent($oAccount, $sCalId, $sEventId);
									}
								}
							}
						}
					}
					$mResult['Body'] = $oResultCal->serialize();
					$mResult['Action'] = $sMethod;

					$mResult['Location'] = isset($oResultEvent->LOCATION) ?
							$oResultEvent->LOCATION->value : '';
					$mResult['Description'] = isset($oResultEvent->DESCRIPTION) ?
							$oResultEvent->DESCRIPTION->value : '';
					$mResult['When'] = $this->GetStrDate($oResultEvent->DTSTART, 'D, M d, Y, H:i');
					$mResult['CalendarId'] = $sCalId;

					if (isset($oResultEvent->ATTENDEE))
					{
						foreach($oResultEvent->ATTENDEE as $attendee)
						{
							$sEmail = str_replace('mailto:', '', strtolower($attendee->value));
							$sAccountEmail = $oAccount->Email;
							if ($sMethod == 'REPLY')
							{
								$sAccountEmail = $mFromEmail;
							}
							if ($sAccountEmail == $sEmail)
							{
								$PARTSTAT = $attendee->offsetGet('PARTSTAT');
								if (isset($PARTSTAT))
								{
									$mResult['Action'] = $sMethod.'-'.$PARTSTAT->value;
								}
							}
						}
					}
				}
			}

		}
		catch (Exception $oException)
		{
			$mResult = false;
			$this->setLastException($oException);
		}

		return $mResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sAction
	 * @param string $sCalendarId
	 * @param string $sData
	 */
	public function ProcessAppointment($oAccount, $sAction, $sCalendarId, $sData)
	{
		$iAccountId = $this->ApiUsersManager->GetDefaultAccountId($oAccount->IdUser);

		/* @var $oAccount CAccount */
		$oAccount = $this->ApiUsersManager->GetAccountById($iAccountId);

		$bResult = null;
		try
		{
			$bResult = false;
			$sTo = $sSubject = $sBody = $sSummary = '';

			$vCal = Sabre_VObject_Reader::read($sData);
			if ($vCal)
			{
				$sMethod = $sMethodOriginal = $vCal->METHOD->value;
				$vEvents = $vCal->getBaseComponents('VEVENT');

				if (isset($vEvents) && count($vEvents) > 0)
				{
					$vEvent = $vEvents[0];
					$sEventId = $vEvent->UID->value;
					if (isset($vEvent->SUMMARY))
					{
						$sSummary = $vEvent->SUMMARY->value;
					}
					if (isset($vEvent->ORGANIZER))
					{
						$sTo = str_replace('mailto:', '', strtolower($vEvent->ORGANIZER->value));
					}
					if (strtoupper($sMethod) === 'REQUEST')
					{
						$sMethod = 'REPLY';
						$sSubject = $sSummary;

						unset($vEvent->ATTENDEE);
						$attendee = new Sabre_VObject_Property('ATTENDEE');
						$attendee->value = 'mailto:'.$oAccount->Email;

						switch (strtoupper($sAction))
						{
							case 'ACCEPTED':
								$attendee->offsetSet('PARTSTAT', 'ACCEPTED');
								$sSubject .= ': Accepted';
								break;
							case 'DECLINED':
								$attendee->offsetSet('PARTSTAT', 'DECLINED');
								$sSubject .= ': Declined';
								break;
							case 'TENTATIVE':
								$attendee->offsetSet('PARTSTAT', 'TENTATIVE');
								$sSubject .= ': Tentative';
								break;
						}
						$attendee->offsetSet('RESPONDED-AT', gmdate("Ymd\THis\Z"));
						$vEvent->add($attendee);
					}

					$vCal->METHOD = $sMethod;
					$vEvent->{'LAST-MODIFIED'} = gmdate("Ymd\THis\Z");

					$sBody = $vCal->serialize();

					if ($sCalendarId !== false)
					{
						unset($vCal->METHOD);
						if (strtoupper($sAction) == 'DECLINED' || strtoupper($sMethod) == 'CANCEL')
						{
							$this->DeleteEvent($oAccount, $sCalendarId, $sEventId);
						}
						else
						{
							$this->oStorage->UpdateEventData($oAccount, $sCalendarId, $sEventId, $vCal->serialize());
						}
					}

					if (strtoupper($sMethodOriginal) == 'REQUEST')
					{
						if (!empty($sTo) && !empty($sBody))
						{
							$bResult = $this->sendAppointmentMessage($oAccount, $sTo, $sSubject, $sBody, $sMethod);
						}
					}
					else
					{
						$bResult = true;
					}
				}
			}

			if (!$bResult)
			{
				CApi::Log('IcsProcessAppointment FALSE result!', ELogLevel::Error);
				CApi::Log('Email: '.$oAccount->Email.', Action: '. $sAction.', Data:', ELogLevel::Error);
				CApi::Log($sData, ELogLevel::Error);
			}

			return $bResult;
		}
		catch (Exception $oException)
		{
			$bResult = false;
			$this->setLastException($oException);
		}
		return $bResult;
	}

	public function UpdateAppointment($oAccount, $sCalendarId, $sEventId, $sAction)
	{
		$oResult = null;
		try
		{
			$aData = $this->oStorage->GetEvent($oAccount, $sCalendarId, $sEventId);
			if ($aData !== false)
			{
				$vCal = $aData['vcal'];
				$vCal->METHOD = 'REQUEST';
				return $this->ProcessAppointment($oAccount, $sAction, $sCalendarId, $vCal->serialize());
			}
		}
		catch (Exception $oException)
		{
			$oResult = false;
			$this->setLastException($oException);
		}
		return $oResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @return bool
	 */
	public function ClearAllCalendars($oAccount)
	{
		$bResult = false;
		try
		{
			$bResult = $this->oStorage->ClearAllCalendars($oAccount);
		}
		catch (CApiBaseException $oException)
		{
			$bResult = false;
			$this->setLastException($oException);
		}
		return $bResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param CalendarInfo $oCalendar
	 * @param Sabre_VObject_Component_VCalendar $vCal
	 * @param bool $bOnlyAlarms
	 */
	public function ParseVCalendar($oAccount, $oCalendar, $vCal, $bOnlyAlarms = false)
	{
		$aResult = array();
		$aResult['data'] = array();
		$aResult['events'] = array();
		$aResult['exclusions'] = array();
		$aResult['reminders'] = array();
		$aResult['appointments'] = array();

		if (isset($vCal))
		{
			$vBaseEvents = $vCal->getBaseComponents('VEVENT');
			if (isset($vBaseEvents))
			{
				foreach ($vBaseEvents as $vBaseEvent)
				{
					$sEventId = $vBaseEvent->UID->value;
					$aResult['data'][$sEventId] = $vCal;

					$bIsAppointment = false;
					// Appointments
					if ($this->ApiCollaborationManager && 
							$this->ApiCollaborationManager->IsCalendarAppointmentsSupported())
					{
						if (isset($vBaseEvent->ATTENDEE))
						{
							if (isset($vBaseEvent->ORGANIZER))
							{
								$oCalendar->Owner = str_replace('mailto:', '',
										strtolower($vBaseEvent->ORGANIZER->value));
							}
							if ($oCalendar->Owner !== $oAccount->Email)
							{
								$bIsAppointment = true;
							}

							foreach($vBaseEvent->ATTENDEE as $oAttendee)
							{
								$iStatus = 0;
								$PARTSTAT = '';
								if ($oAttendee->offsetExists('PARTSTAT'))
								{
									$PARTSTAT = $oAttendee->offsetGet('PARTSTAT');
									switch (strtoupper($PARTSTAT->value))
									{
										case 'ACCEPTED':
											$iStatus = 1;
											break;
										case 'DECLINED':
											$iStatus = 2;
											break;
										case 'TENTATIVE':
											$iStatus = 3;
											break;
									}
								}
								$sEmail = '';
								if ($oAttendee->offsetExists('EMAIL'))
								{
									$sEmail = $oAttendee->offsetGet('EMAIL')->value;
								}
								else
								{
									$sEmail = str_replace('mailto:', '', strtolower($oAttendee->value));
								}

								$oAcct = $this->ApiUsersManager->GetAccountOnLogin($sEmail);
								$iUserId = 0;
								if (isset($oAcct))
								{
									$iUserId = $oAcct->IdUser;
								}
								$iAccessType = 0;
								$aResult['appointments'][$sEventId][$sEmail] = array(
										'accessType' => $iAccessType,
										'appointmentId' => $sEmail,
										'email' => $sEmail,
										'eventId' => $sEventId,
										'status' => $iStatus,
										'userId' => $iUserId
								);
							}
						}
					}

					// Reminders
					if ($vBaseEvent->VALARM)
					{
						$iReminderId = 1;
						foreach($vBaseEvent->VALARM as $vAlarm)
						{
							if (isset($vAlarm->TRIGGER))
							{
								$aResult['reminders'][$sEventId][$iReminderId] = array(
									'id_event' => $sEventId,
									'id_reminder' => $iReminderId,
									'offset' => self::NormalizeOffset($vAlarm->TRIGGER->value)
								);
								$iReminderId++;
							}
						}
					}
					else if ($bOnlyAlarms)
					{
						continue;
					}

					$eventAllDay = '0';
					if (isset($vBaseEvent->DTSTART))
					{
						$event_dtstart = $vBaseEvent->DTSTART->value;
						$dateParam = $vBaseEvent->DTSTART->offsetGet('value');
						if ($dateParam && strtoupper($dateParam->value) == 'DATE')
						{
							$eventAllDay = '1';
							$event_dtstart = $vBaseEvent->DTSTART->value . 'T000000Z';
						}
					}

					$sEventDTStart = $this->GetStrDate($vBaseEvent->DTSTART);
					$sEventDTEnd = $this->GetStrDate($vBaseEvent->DTEND);

					$aSimpleEvent = array(
						'calendar_id' => $oCalendar->Id,
						'allday_flag' => (int) $eventAllDay,
						'event_allday' => $eventAllDay,
						'event_id' => $sEventId,
						'event_name' => $vBaseEvent->SUMMARY ? $vBaseEvent->SUMMARY->value : '',
						'event_text' => $vBaseEvent->DESCRIPTION ? $vBaseEvent->DESCRIPTION->value : '',
						'event_location' => $vBaseEvent->LOCATION ? $vBaseEvent->LOCATION->value : '',
						'event_timefrom' => $sEventDTStart,
						'event_timetill' => $sEventDTEnd,
						'event_dtstart' => $event_dtstart,
						'event_owner' => $oCalendar->Owner
					);

					$aResult['events'][$sEventId] = $aSimpleEvent;

					$aResult['events'][$sEventId]['appointment'] = $bIsAppointment;
					$aResult['events'][$sEventId]['event_appointment_access'] = '0';
					$aResult['events'][$sEventId]['event_repeats'] = '0';

					$sWeekDays = array(0, 0, 0, 0, 0, 0, 0);
					if (isset($vBaseEvent->RRULE))
					{
						$aRRULE = $this->ParseRRULE($vCal, $sEventId);
						$aResult['events'][$sEventId] = array_merge($aResult['events'][$sEventId], $aRRULE);

						$sWeekDays[0] = $aRRULE['sun'];
						$sWeekDays[1] = $aRRULE['mon'];
						$sWeekDays[2] = $aRRULE['tue'];
						$sWeekDays[3] = $aRRULE['wed'];
						$sWeekDays[4] = $aRRULE['thu'];
						$sWeekDays[5] = $aRRULE['fri'];
						$sWeekDays[6] = $aRRULE['sat'];
					}

					if (isset($vBaseEvent->EXDATE))
					{
						$aResult['events'][$sEventId]['excluded'] = '1';
						foreach ($vBaseEvent->EXDATE as $exdate)
						{
							$recurrenceId = $this->GetStrDate($exdate, 'Ymd');

//							$repeatId = DAV_Convert_Utils::_getRepeatIdExclution($exdate, $vCal, $eventId);
							$repeatId = CCalendarUtils::getRepeatIdExclution(
									new DateTime($aResult['events'][$sEventId]['event_dtstart']),
									$exdate->value,
									$aResult['events'][$sEventId]['repeat_order'],
									$aResult['events'][$sEventId]['repeat_period'],
									$sWeekDays,
									isset($aResult['events'][$sEventId]['week_number'])?
										$aResult['events'][$sEventId]['week_number']:'0'
							);

							$sExId = $sEventId.'_'.$repeatId.'_'.$recurrenceId;

							$aResult['exclusions'][$sExId] = $aSimpleEvent;
							$aResult['exclusions'][$sExId]['id_recurrence'] = $recurrenceId;
							$aResult['exclusions'][$sExId]['id_repeat'] = $repeatId;
							$aResult['exclusions'][$sExId]['is_deleted'] = '1';
						}
					}
				}
			}

			if (isset($vCal->VEVENT))
			{
				foreach ($vCal->VEVENT as $vEvent)
				{
					if (isset($vEvent->{'RECURRENCE-ID'}))
					{
						$sEventId = $vEvent->UID->value;
						if (!empty($aResult['events'][$sEventId]['event_repeats']))
						{
							$aResult['events'][$sEventId]['excluded'] = '1';

							$eventAllDay = '0';
							$dateParam = $vEvent->DTSTART->offsetGet('value');
							if ($dateParam && strtoupper($dateParam->value) == 'DATE')
							{
								$eventAllDay = '1';

								$vEvent->DTSTART->value = $vEvent->DTSTART->value . 'T000000Z';
								$vEvent->DTEND->value = $vEvent->DTEND->value . 'T000000Z';
							}

							$sEventDTStart = $this->GetStrDate($vEvent->DTSTART);
							$sEventDTEnd = $this->GetStrDate($vEvent->DTEND);

							$aSimpleEvent = array(
								'calendar_id' => $oCalendar->Id,
								'event_allday' => $eventAllDay,
								'event_id' => $sEventId,
								'event_name' => $vEvent->SUMMARY ? $vEvent->SUMMARY->value : '',
								'event_text' => $vEvent->DESCRIPTION ? $vEvent->DESCRIPTION->value : '',
								'event_location' => $vEvent->LOCATION ? $vEvent->LOCATION->value : '',
								'event_timefrom' => $sEventDTStart,
								'event_timetill' => $sEventDTEnd,
								'event_dtstart' => $vEvent->DTSTART->value,
								'event_owner' => $oCalendar->Owner
							);

							$sWeekDays = array();
							$sWeekDays[0] = isset($aResult['events'][$sEventId]['sun']) ? $aResult['events'][$sEventId]['sun'] : '0';
							$sWeekDays[1] = isset($aResult['events'][$sEventId]['mon']) ? $aResult['events'][$sEventId]['mon'] : '0';
							$sWeekDays[2] = isset($aResult['events'][$sEventId]['tue']) ? $aResult['events'][$sEventId]['tue'] : '0';
							$sWeekDays[3] = isset($aResult['events'][$sEventId]['wed']) ? $aResult['events'][$sEventId]['wed'] : '0';
							$sWeekDays[4] = isset($aResult['events'][$sEventId]['thu']) ? $aResult['events'][$sEventId]['thu'] : '0';
							$sWeekDays[5] = isset($aResult['events'][$sEventId]['fri']) ? $aResult['events'][$sEventId]['fri'] : '0';
							$sWeekDays[6] = isset($aResult['events'][$sEventId]['sat']) ? $aResult['events'][$sEventId]['sat'] : '0';

							$recurrenceId = $this->GetStrDate($vEvent->{'RECURRENCE-ID'}, 'Ymd');
	//						$repeatId = DAV_Convert_Utils::_getRepeatIdExclution($event->{'RECURRENCE-ID'}, $vCal, $eventId);

							$repeatId = CCalendarUtils::getRepeatIdExclution(
									new DateTime($aResult['events'][$sEventId]['event_dtstart']),
									$vEvent->{'RECURRENCE-ID'}->value,
									$aResult['events'][$sEventId]['repeat_order'],
									$aResult['events'][$sEventId]['repeat_period'],
									$sWeekDays,
									isset($aResult['events'][$sEventId]['week_number'])?
											$aResult['events'][$sEventId]['week_number']:'0');

							$sExId = $sEventId . '_' . $repeatId . '_' . $recurrenceId;

							$aResult['exclusions'][$sExId] = $aSimpleEvent;

							$aResult['exclusions'][$sExId]['id_recurrence'] = $recurrenceId;
							$aResult['exclusions'][$sExId]['id_repeat'] = $repeatId;
							$aResult['exclusions'][$sExId]['is_deleted'] = '0';
						}
					}
				}
			}
		}

		return $aResult;
	}

	protected function PrepareEvent($oAccount, $oEvent, &$vCal, &$vEvent, $sEventUID = null)
	{
		$oLastModified = new Sabre_VObject_Property_DateTime('LAST-MODIFIED');
		$oLastModified->setDateTime(new DateTime('now'), Sabre_VObject_Property_DateTime::UTC);
		$vEvent->{'LAST-MODIFIED'} = $oLastModified;

		if (empty($sEventUID))
		{
			if (!empty($oEvent->IdEvent))
			{
				$vEvent->UID = $oEvent->IdEvent;
			}
		}
		else
		{
			$vEvent->UID = $sEventUID;
		}

		if (!empty($oEvent->StartDate) && !empty($oEvent->StartTime) &&
				!empty($oEvent->EndDate) && !empty($oEvent->EndTime))
		{
			$bAllday = (!empty($oEvent->AllDay)) ? true : false;

			$oDTStart = CCalendarUtils::PrepareDateTime(
					$oEvent->StartDate, 
					$oEvent->StartTime,
					$this->oStorage->TimeZone, 
					$bAllday
			);
			$oDTEnd = CCalendarUtils::PrepareDateTime(
					$oEvent->EndDate, 
					$oEvent->EndTime,
					$this->oStorage->TimeZone, 
					$bAllday, 
					true
			);

			if (isset($oDTStart))
			{
				unset($vEvent->DTSTART);
				$dtstart = new Sabre_VObject_Property_DateTime('DTSTART');
				if ($bAllday)
				{
					$dtstart->setDateTime($oDTStart, Sabre_VObject_Property_DateTime::DATE);
				}
				else
				{
					$dtstart->setDateTime($oDTStart, Sabre_VObject_Property_DateTime::UTC);
				}
				$vEvent->add($dtstart);
			}
			if (isset($oDTEnd))
			{
				unset($vEvent->DTEND);
				$dtend = new Sabre_VObject_Property_DateTime('DTEND');
				if ($bAllday)
				{
					$dtend->setDateTime($oDTEnd, Sabre_VObject_Property_DateTime::DATE);
				}
				else
				{
					$dtend->setDateTime($oDTEnd, Sabre_VObject_Property_DateTime::UTC);
				}
				$vEvent->add($dtend);
			}
		}

		if (isset($oEvent->Name))
		{
			$vEvent->SUMMARY = $oEvent->Name;
		}
		if (isset($oEvent->Description))
		{
			$vEvent->DESCRIPTION = $oEvent->Description;
		}
		if (isset($oEvent->Location))
		{
			$vEvent->LOCATION = $oEvent->Location;
		}

		if ($oEvent->AllowRepeat)
		{
			$sRRULE = $this->GetRRULE($oEvent);
			if (trim($sRRULE) != '')
			{
				$rRule = new Sabre_VObject_Property('RRULE');
				$rRule->value = $sRRULE;
				$vEvent->RRULE = $rRule;
			}
		}
		else
		{
			unset($vEvent->RRULE);
		}

		unset($vEvent->VALARM);
		if (!empty($oEvent->ReminderOffset))
		{
			foreach ($oEvent->ReminderOffset as $sOffset)
			{
				$vAlarm = new Sabre_VObject_Component('VALARM');
				$vAlarm->TRIGGER = $sOffset;
				$vAlarm->DESCRIPTION = 'Alarm';
				$vAlarm->ACTION = 'DISPLAY';

				$vEvent->add($vAlarm);
			}
		}

		// Appointments
		if ($this->ApiCollaborationManager && 
				$this->ApiCollaborationManager->IsCalendarAppointmentsSupported())
		{
			$aAppointmentsToDelete = array();
			if (isset($oEvent->AppointmentsToDelete))
			{
				$aAppointmentsToDelete = $oEvent->AppointmentsToDelete;
			}
			$aAppointmentsToSave = array();
			if (isset($oEvent->AppointmentsToSave))
			{
				$aAppointmentsToSave = $oEvent->AppointmentsToSave;
			}
			$aEmails = array();
			if ($vEvent->ATTENDEE)
			{
				$aAttendees = $vEvent->ATTENDEE;

				if (count($aAttendees) <= count($aAppointmentsToDelete))
				{
					unset($vEvent->ORGANIZER);
				}

				unset($vEvent->ATTENDEE);
				foreach($aAttendees as $oAttendee)
				{
					$sEmail = str_replace('mailto:', '', strtolower($oAttendee->value));
					if (!in_array($sEmail, $aAppointmentsToDelete))
					{
						$tmpAttendee = new Sabre_VObject_Property('ATTENDEE');
						$tmpAttendee->value = $oAttendee->value;
						$vEvent->add($tmpAttendee);
						$aEmails[] = $sEmail;
					}
					else
					{
						$PARTSTAT = $oAttendee->offsetGet('PARTSTAT');
						if (!isset($PARTSTAT) || 
								(isset($PARTSTAT) && $PARTSTAT->value != 'DECLINED'))
						{
							$sMethod = 'CANCEL';
							$vCal->METHOD = $sMethod;
							$sBody = $vCal->serialize();
							unset($vCal->METHOD);
							$this->sendAppointmentMessage($oAccount, $sEmail, $vEvent->SUMMARY->value,
									$sBody, $sMethod);
						}
					}
				}
			}
			if (count($aAppointmentsToSave) > 0)
			{
				$vEvent->ORGANIZER = 'mailto:'.$oAccount->Email;
				foreach($aAppointmentsToSave as $sAppointmentSave)
				{
					if (!in_array($sAppointmentSave, $aEmails))
					{
						$oAttendee = new Sabre_VObject_Property('ATTENDEE');
						$oAttendee->value = 'mailto:'.$sAppointmentSave;
						
						$vEvent->add($oAttendee);
					}
				}
			}
			$aAttendees = $vEvent->ATTENDEE;
			if (isset($aAttendees))
			{
				foreach($aAttendees as $oAttendee)
				{
					$sEmail = str_replace('mailto:', '', strtolower($oAttendee->value));
					$PARTSTAT = $oAttendee->offsetGet('PARTSTAT');
					if (!isset($PARTSTAT) || (isset($PARTSTAT) && $PARTSTAT->value != 'DECLINED'))
					{
						$oAttendee->offsetSet('PARTSTAT', 'NEEDS-ACTION');
						$oAttendee->offsetSet('RSVP', 'TRUE');

						$sMethod = 'REQUEST';
						$vCal->METHOD = $sMethod;
						$sBody = $vCal->serialize();
						unset($vCal->METHOD);
						$this->sendAppointmentMessage($oAccount, $sEmail, $vEvent->SUMMARY->value,
								$sBody, $sMethod);
					}
				}
			}
		}
	}

	public function GetStrDate($dt, $format = 'Y-m-d H:i:s')
	{
		$parsedDT = null;
		if ($dt instanceof Sabre_VObject_Property_DateTime)
		{
			$parsedDT = $dt->getDateTime();
		}
		if ($dt instanceof Sabre_VObject_Property_MultiDateTime)
		{
			$parsedDT = $dt->getDateTimes();
			$parsedDT = current($parsedDT);
		}
		if (isset($parsedDT))
		{
			$parsedDT->setTimezone(new DateTimeZone($this->oStorage->TimeZone));
			return $parsedDT->format($format);
		}
		return null;
	}

	public function GetBaseVEventIndex($vEvents)
	{
		$mResult = false;
		$iIndex = -1;
		foreach($vEvents as $vEvent)
		{
			$iIndex++;
			if (empty($vEvent->{'RECURRENCE-ID'})) break;
		}
		if ($iIndex >= 0)
		{
			$mResult = $iIndex;
		}
		else
		{
			$mResult = false;
		}
		return $mResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sTo
	 * @param string $sSubject
	 * @param string $sBody
	 * @param string $sMethod
	 * @return WebMailMessage
	 */
	protected function buildAppointmentMessage($oAccount, $sTo, $sSubject, $sBody, $sMethod = null)
	{
		$oMessage = null;
		if ($oAccount && !empty($sTo) && !empty($sBody))
		{
			$oMessage = new WebMailMessage();
			$GLOBALS[MailDefaultCharset] = CPAGE_UTF8;
			$GLOBALS[MailInputCharset] = CPAGE_UTF8;
			$GLOBALS[MailOutputCharset] = APP_DEFAULT_OUTPUT_CHARSET;

			$oMessage->Headers->SetHeaderByName(MIMEConst_MimeVersion, '1.0');
			$oMessage->Headers->SetHeaderByName(MIMEConst_XMailer, CApi::GetConf('webmail.xmailer-value', 'PHP'));

			$sIp = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : null;
			if (null !== $sIp)
			{
				$oMessage->Headers->SetHeaderByName(MIMEConst_XOriginatingIp, $sIp);
			}

			$sServerAddr = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['SERVER_NAME'] : 'cantgetservername';
			$oMessage->Headers->SetHeaderByName(MIMEConst_MessageID,
				'<'.substr(session_id(), 0, 7).'.'.md5(time()).'@'. $sServerAddr .'>');

			$emailAccount = $oAccount->Email;

			$oMessage->SetFromAsString($emailAccount);
			$oMessage->SetToAsString($sTo);
			$oMessage->SetSubject($sSubject);
			$oMessage->SetDate(new CDateTime(time()));

			if (!empty($sMethod))
			{
				$oMessage->TextBodies->CustomContentType = 'text/calendar; method='.$sMethod.'; charset="utf-8"';
			}
			else
			{
				$oMessage->TextBodies->CustomContentType = 'text/calendar; charset="utf-8"';
			}
			$oMessage->TextBodies->CustomContentTransferEncoding = MIMEConst_8bit;
			$oMessage->TextBodies->PlainTextBodyPart = $sBody;

			$oMessage->Attachments->AddFromBinaryBody($sBody, 'invite.ics', 'application/ics', false);
		}

		return $oMessage;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sTo
	 * @param string $sSubject
	 * @param string $sBody
	 * @param string $sMethod
	 * @return WebMailMessage
	 */
	protected function sendAppointmentMessage($oAccount, $sTo, $sSubject, $sBody, $sMethod)
	{
		$oMessage = $this->buildAppointmentMessage($oAccount, $sTo, $sSubject, $sBody, $sMethod);

		CApi::Plugin()->RunHook('webmail-change-appointment-message-before-send',
			array(&$oMessage, &$oAccount));

		if ($oMessage)
		{
			$oMessage->Flags |= MESSAGEFLAGS_Seen;
			$oMessage->OriginalMailMessage = $oMessage->ToMailString(true);
			CApi::Log('IcsProcessAppointmentSendOriginalMailMessage');
			CApi::Log($oMessage->OriginalMailMessage);

			return CSmtp::SendMail($oAccount, $oMessage, null, null);
		}

		return false;
	}

	/**
	 * @param CEvent $oEvent
	 * @return string
	 */
    public function GetRRULE($oEvent)
    {
		$aPeriods = array(
			'SECONDLY',
			'MINUTELY',
			'HOURLY',
			'DAILY',
			'WEEKLY',
			'MONTHLY',
			'YEARLY'
		);

		$sRule = $sFreq = $sUntil = '';
		$iInterval = $iCount = $iEnd = 0;

		if (null !== $oEvent->RepeatPeriod)
		{
			$iPeriod = (int) $oEvent->RepeatPeriod;
			$sFreq = $aPeriods[$iPeriod + 3];

			$weekNumber = null;
			if (($iPeriod == 2 || $iPeriod == 3))
			{
				if (null !== $oEvent->WeekNumber)
				{
					$weekNumber = (int) $oEvent->WeekNumber;
					$weekNumber = ($weekNumber < 0 || $weekNumber > 4) ? 0 : $weekNumber;
				}
				else
				{
					$weekNumber = null;
				}
			}
			else
			{
				$weekNumber = null;
			}
			if (null !== $oEvent->RepeatTimes)
			{
				$iCount = (int) $oEvent->RepeatTimes;
			}
			if (null !== $oEvent->RepeatUntil)
			{
				$sTime = '00:00';
				if (!empty($oEvent->StartTime))
				{
					$sTime = $oEvent->StartTime;
				}
				$oDTUntil = CCalendarUtils::PrepareDateTime($oEvent->RepeatUntil, $sTime,
						$this->oStorage->TimeZone);
				$oUntil = new Sabre_VObject_Property_DateTime('UNTIL');
				$oUntil->setDateTime($oDTUntil, Sabre_VObject_Property_DateTime::UTC);
				$sUntil = $oUntil->value;
			}
			if (null !== $oEvent->RepeatOrder)
			{
				$iInterval = (int) $oEvent->RepeatOrder;
			}
			if (null !== $oEvent->RepeatEnd)
			{
				$iEnd = (int) $oEvent->RepeatEnd;
				if ($iEnd < 0 || $iEnd > 3)
				{
					$iEnd = 0;
				}
			}

			if($iEnd == 0)
			{
				$sRule = 'FREQ=' . $sFreq . ';INTERVAL=' . $iInterval;
			}
			else if ($iEnd == 1)
			{
				$sRule = 'FREQ=' . $sFreq . ";INTERVAL=" . $iInterval .";COUNT=" . $iCount;
			}
			else if ($iEnd == 2)
			{
				$sRule = 'FREQ=' . $sFreq . ";INTERVAL=" . $iInterval . ";UNTIL=" . $sUntil;
			}

			$aByDays = array();
			$sByDay = '';
			if ($sFreq == 'WEEKLY' || $sFreq == 'MONTHLY' || $sFreq == 'YEARLY')
			{
				if ($oEvent->RepeatSun) $aByDays[] = 'SU';
				if ($oEvent->RepeatMon) $aByDays[] = 'MO';
				if ($oEvent->RepeatTue) $aByDays[] = 'TU';
				if ($oEvent->RepeatWed) $aByDays[] = 'WE';
				if ($oEvent->RepeatThu) $aByDays[] = 'TH';
				if ($oEvent->RepeatFri) $aByDays[] = 'FR';
				if ($oEvent->RepeatSat) $aByDays[] = 'SA';
			}
			if (count($aByDays) > 0)
			{
				$sByDay = implode(',', $aByDays);
				if ($sFreq == 'WEEKLY')
				{
					$sRule .= ';BYDAY='.$sByDay;
				}
				if (($sFreq === 'MONTHLY' || $sFreq === 'YEARLY') && isset($weekNumber))
				{
					if ($weekNumber == 0) $sByDay = '1'.$sByDay;
					if ($weekNumber == 1) $sByDay = '2'.$sByDay;
					if ($weekNumber == 2) $sByDay = '3'.$sByDay;
					if ($weekNumber == 3) $sByDay = '4'.$sByDay;
					if ($weekNumber == 4) $sByDay = '-1'.$sByDay;
					$sRule .= ';BYDAY='.$sByDay;
				}
			}
		}
        return $sRule;
    }

	public function ParseRRULE($vcal, $uid)
	{
		$res = array();
		$aPeriods = array(
			'secondly',
			'minutely',
			'hourly',
			'daily',
			'weekly',
			'monthly',
			'yearly'
		);

		$res['event_repeats'] = '1';
		$res['repeat_period'] = '0';
		$res['repeat_order'] = '1';
		$res['repeat_end'] = '0';
		$res['repeat_until'] = null;
		$res['sun'] = '0';
		$res['mon'] = '0';
		$res['tue'] = '0';
		$res['wed'] = '0';
		$res['thu'] = '0';
		$res['fri'] = '0';
		$res['sat'] = '0';

		$oRecur = null;
		$oRecur = new Sabre_VObject_RecurrenceIterator($vcal, $uid);

		if (isset($oRecur))
		{
			if (isset($oRecur->frequency))
			{
				$isPosiblePeriod = array_search($oRecur->frequency, $aPeriods);
				if ($isPosiblePeriod !== false)
				{
					$res['repeat_period'] = (string) ($isPosiblePeriod - 3);
				}
			}
			if (isset($oRecur->bySetPos))
			{
				$res['week_number'] = $oRecur->bySetPos;
			}
			if (isset($oRecur->interval))
			{
				$res['repeat_order'] = $oRecur->interval;
			}
			if (isset($oRecur->count))
			{
				$res['repeat_num'] = $oRecur->count;
			}
			if (isset($oRecur->until))
			{
				$oRecur->until->setTimezone(new DateTimeZone($this->oStorage->TimeZone));
				$res['repeat_until'] = $oRecur->until->format('Y-m-d H:i:s');
			}
			if (isset($res['repeat_num']))
			{
				$res['repeat_end'] = '1';
			}
			if (isset($res['repeat_until']))
			{
				$res['repeat_end'] = '2';
			}
			if (isset($oRecur->byDay))
			{
				foreach ($oRecur->byDay as $day)
				{
					if (strlen($day) > 2)
					{
						$num = (int)substr($day, 0, -2);

						if ($num == 1) $res['week_number'] = '0';
						if ($num == 2) $res['week_number'] = '1';
						if ($num == 3) $res['week_number'] = '2';
						if ($num == 4) $res['week_number'] = '3';
						if ($num == -1) $res['week_number'] = '4';
					}

					if (strpos($day, 'SU') !== false) $res['sun'] = '1';
					if (strpos($day, 'MO') !== false) $res['mon'] = '1';
					if (strpos($day, 'TU') !== false) $res['tue'] = '1';
					if (strpos($day, 'WE') !== false) $res['wed'] = '1';
					if (strpos($day, 'TH') !== false) $res['thu'] = '1';
					if (strpos($day, 'FR') !== false) $res['fri'] = '1';
					if (strpos($day, 'SA') !== false) $res['sat'] = '1';
				}
			}
		}
		return $res;
	}

	private function isRecurrenceExists($vEvent, $sRecurrenceId)
	{
		$mResult = false;
		foreach($vEvent as $mKey => $event)
		{
			if (isset($event->{'RECURRENCE-ID'}))
			{
				$recurrenceId = $this->GetStrDate($event->{'RECURRENCE-ID'}, 'Ymd');

				if ($recurrenceId == $sRecurrenceId)
				{
					$mResult = $mKey;
					break;
				}
			}
		}

		return $mResult;
	}

	/**
	* @return string
	*/
	public function GetRootUrl($url)
	{
		$urlParts = parse_url($url);
		$path = '/';
		if (isset($urlParts['path']))
		{
			$path = $urlParts['path'];
		}
		return $path;
	}
	
    /**
	 * @param string $sOffset
	 * @return string
	 */
	public static function NormalizeOffset($sOffset)
	{
 		$aIntervals = array(5,10,15,30,60,120,180,240,300,360,420,480,540,600,660,720,1080,1440,2880,4320,5760,10080,20160);
		$sResult = '';
		$iMinutes = 0;
		try
		{
			$oInterval = new DateInterval(ltrim($sOffset, '-'));
			$iMinutes = $oInterval->i + $oInterval->h*60 + $oInterval->d*24*60;
		}
		catch (Exception $ex)
		{
			$iMinutes = 15;
		}
		if (!in_array($iMinutes, $aIntervals))
		{
			$iMinutes = 15;
		}
		$sResult = '-PT' . $iMinutes . 'M';
		
		return $sResult;
	}
}
