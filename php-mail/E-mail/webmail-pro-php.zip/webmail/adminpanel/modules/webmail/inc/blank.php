<?php

/*
 * Copyright (C) 2002-2012 AfterLogic Corp. (www.afterlogic.com)
 * Distributed under the terms of the license described in COPYING
 * 
 */

class CWebMailBlankAction extends ap_CoreModuleHelper
{
	public function UsersLogin()
	{
//		$iAccountId = null;
//		$sQueryAccountId = isset($_GET['id']) ? $_GET['id'] : null;
//		if (is_numeric($sQueryAccountId))
//		{
//			$iAccountId = (int) $sQueryAccountId;
//		}
//
//		if (null === $iAccountId || !$this->oModule->LoginToAccount($iAccountId))
//		{
			exit(AP_LANG_ERROR); // TODO
//		}
	}
}