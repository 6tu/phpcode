<table class="wm_contacts_view">
	<tr>
		<td>
			<input name="chOverrideSettings" type="checkbox" id="chOverrideSettings" class="wm_checkbox" value="1" checked="checked" />
			<label for="chOverrideSettings" id="chOverrideSettings_label">Override default domain settings</label>
		</td>
	</tr>
</table>