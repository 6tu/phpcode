<table class="wm_contacts_view">
	<tr class="<?php $this->Data->PrintInputValue('classLoginToAccount') ?>">
		<td class="wm_field_value" colspan="2">
			<br />
			<a href="<?php $this->Data->PrintInputValue('hrefLoginToAccount') ?>" target="blank">
				<input type="button" name="btnLoginToAccount" id="btnLoginToAccount" class="wm_button" value="Login to Account" />
			</a>
		</td>
	</tr>
</table>