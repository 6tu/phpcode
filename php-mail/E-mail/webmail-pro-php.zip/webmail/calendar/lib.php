<?php

/*
 * Copyright (C) 2002-2012 AfterLogic Corp. (www.afterlogic.com)
 * Distributed under the terms of the license described in COPYING
 * 
 */

/**
 * @param int $iCode
 * @param string $sDescription
 * @return string
 */
function getErrorJson($iCode, $sDescription)
{
	return json_encode(
			array(
				'error' => 'true', 
				'code' => $iCode, 
				'description' => $sDescription
			)
	);
}

/**
 * @param int $iWeekStartsOn
 * @param int $sTimeZone
 * @return array
 */

class CMonthLimits
{
    protected $from;
	protected $till;
	
	public function GetFrom()
	{
		return $this->from;
	}
	
	public function GetTill()
	{
		return $this->till;
	}

	public function __construct($iWeekStartsOn, $sTimeZone) 
	{
		$oTimeZone = new DateTimeZone($sTimeZone);
		$oTodayDateTime = new DateTime('now', $oTimeZone);

		$sYear = $oTodayDateTime->format('Y');
		$sMonth = $oTodayDateTime->format('m');
		$iDaysNum = (int)$oTodayDateTime->format('t');

		$aAddDays = array();
		$aAddDays[$iWeekStartsOn] = 0;
		for ($j = $iWeekStartsOn+1; $j<7; $j++) 
		{
			$aAddDays[$j] = $aAddDays[$j-1] + 1;
		}
		for ($k = 0; $k<$iWeekStartsOn; $k++) 
		{
			$aAddDays[$k] = $aAddDays[$j-1] + 1*($k+1);
		}

		$oFirstDateTime = new DateTime($sYear.'-'.$sMonth.'-01 12:00:00', $oTimeZone);
		$iFirstDay = (int) $oFirstDateTime->format('w');

		$oLastDateTime = clone $oFirstDateTime;
		$oLastDateTime->add(new DateInterval('P1M'));
		$iLastDay = (int) $oLastDateTime->format('w');

		$iWeekNum = ceil(($iDaysNum + $aAddDays[$iFirstDay])/7);

		$oStartInterval = new DateInterval('P0D');
		if ($iWeekNum == 6) 
		{
			$oStartInterval = new DateInterval('P'.$aAddDays[$iFirstDay].'D');
		} 
		else if ($iWeekNum == 5) 
		{
			$oStartInterval = new DateInterval('P'.(7 + $aAddDays[$iFirstDay]).'D');
		} 
		else //4
		{
			$oStartInterval = new DateInterval('P'.(14 + $aAddDays[$iFirstDay]).'D');
		}
		$oStartInterval->invert = 1;
		$oEndInterval = new DateInterval('P'.(13 - $aAddDays[$iLastDay]).'D');

		$oFirstDateTime->add($oStartInterval);
		$oLastDateTime->add($oEndInterval);

		$this->from = $oFirstDateTime->format("Ymd");
		$this->till = $oLastDateTime->format("Ymd");
	}	
}
