<?php
defined('WM_ROOTPATH') || define('WM_ROOTPATH', (dirname(__FILE__).'/../../'));

require_once WM_ROOTPATH.'libraries/afterlogic/DAV/autoload.php';
include_once WM_ROOTPATH.'libraries/afterlogic/api.php';
include_once WM_ROOTPATH.'application/include.php';
require_once(WM_ROOTPATH.'common/class_smtp.php');

define("NEED_TO_CHECK", 0);
define("REMIND", 1);
define("RECHECK", 2);

// Include Language constants
$oSettings =& CApi::GetSettings();
AppIncludeLanguage($oSettings->GetConf('Common/DefaultLanguage'));

class CReminder
{
	/**
	 * @var CApiUsersManager
	 */
	protected $apiUsersManager;

	/**
	 * @var CApiCalendarManager
	 */
	protected $apiCalendarManager;

	/**
	 * @var array
	 */
	protected $aAccounts;

	/**
	 * @var array
	 */
	protected $aCalendars;

	protected $nextRunFilePath;

	public function __construct()
	{
		$this->apiUsersManager = CApi::Manager('users');
		$this->apiCalendarManager = CApi::Manager('calendar');
		$this->aAccounts = array();
		$this->aCalendars = array();

		$this->nextRunFilePath = CApi::DataPath().'/reminder-next-run';
	}

	/**
	 * @param string $sLogin
	 * @return CAccount
	 */
	protected function &getAccount($sLogin)
	{
		$mResult = null;

		if (!isset($this->aAccounts[$sLogin]))
		{
			$this->aAccounts[$sLogin] = $this->apiUsersManager->GetAccountOnLogin($sLogin);
		}

		$mResult =& $this->aAccounts[$sLogin];

		if (30 < count($this->aAccounts[$sLogin]))
		{
			$this->aAccounts = array_slice($this->aAccounts, -30);
		}

		return $mResult;
	}

	/**
	 * @param CAccount $oAccount
	 * @param string $sUri
	 * @return CalendarInfo
	 */
	protected function &getCalendar($oAccount, $sUri)
	{
		$mResult = null;

		if (!isset($this->aCalendars[$sUri]))
		{
			$this->aCalendars[$sUri] = $this->apiCalendarManager->GetCalendar($oAccount, $sUri);
		}
		if (isset($this->aCalendars[$sUri]))
		{
			$mResult =& $this->aCalendars[$sUri];
		}

		return $mResult;
	}

	protected function CreateBodyHtml($accountEmail, $eventName, $dateStr, $calendarName, $eventText,
			$calendarColor)
	{
		return sprintf('
	<div style="padding: 10px; font-size: 12px; text-align: center;">
		<div style="border: 4px solid %s; padding: 15px; width: 370px;">
			<h2 style="margin: 5px; font-size: 18px; line-height: 1.4;">%s</h2>
			<span>%s%s</span><br/>
			<span>%s: %s</span><br/><br/>
			<span>%s</span><br/>
		</div>
		<p style="color:#667766; width: 400px; font-size: 10px;">%s</p>
	</div>',
			$calendarColor,
			$eventName,
			ucfirst(ReminderEventBegin),
			$dateStr,
			Calendar,
			$calendarName,
			$eventText,
			sprintf(str_replace(array('%EMAIL%', '%CALENDAR_NAME%'),
								array('<a href="mailto:%1$s">%1$s</a>', '%2$s'),
								ReminderEmailExplanation),
					$accountEmail,
					$calendarName));

	}

	protected function CreateBodyText($accountEmail, $eventName, $dateStr, $calendarName, $eventText)
	{
		return sprintf("%s\r\n\r\n%s%s\r\n\r\n%s: %s %s\r\n\r\n%s",
						$eventName,
						ucfirst(ReminderEventBegin),
						$dateStr,
						Calendar,
						$calendarName,
						$eventText,
						sprintf(str_replace(
									array('%EMAIL%', '%CALENDAR_NAME%'),
									array('mailto:%s', '%s'),
									ReminderEmailExplanation), 
								$accountEmail, $calendarName)
		);
	}

	protected function CreateMessage(&$account, $to, $subject, $fiendlyName, $html = null, $text = null)
	{
		$message = new WebMailMessage();
		$GLOBALS[MailDefaultCharset] = CPAGE_UTF8;
		$GLOBALS[MailInputCharset] = CPAGE_UTF8;
		$GLOBALS[MailOutputCharset] = APP_DEFAULT_OUTPUT_CHARSET;

		$message->Headers->SetHeaderByName(MIMEConst_MimeVersion, '1.0');
		$message->Headers->SetHeaderByName(MIMEConst_XMailer, CApi::GetConf('webmail.xmailer-value', 'PHP'));

		$ip = !empty($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR']
				: ((!empty($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR'] : null));

		if (null !== $ip)
		{
			$message->Headers->SetHeaderByName(MIMEConst_XOriginatingIp, $ip);
		}

		$serverAddr = 'cantgetservername';
		$message->Headers->SetHeaderByName(MIMEConst_MessageID,
			'<'.substr(mt_rand(30000, 32000) * mt_rand(30000, 32000), 0, 7).'.'.md5(time()).'@'. $serverAddr .'>'
		);

		$fromCollection = new EmailAddressCollection();
		$fromCollection->Add($account->Email, $fiendlyName);
		$message->SetFrom($fromCollection);

		$message->SetToAsString(ConvertUtils::WMBackHtmlSpecialChars($to));
		$message->SetSubject(ConvertUtils::WMBackHtmlSpecialChars($subject));
		$message->SetDate(new CDateTime(time()));

		if ($html != NULL)
		{
			$message->TextBodies->HtmlTextBodyPart =
				ConvertUtils::AddHtmlTagToHtmlBody(
					str_replace("\n", CRLF,
					str_replace("\r", '', ConvertUtils::WMBackHtmlNewCode($html)))
				);
		}
		if ($text != NULL)
		{
			$message->TextBodies->PlainTextBodyPart =
				str_replace("\n", CRLF,
				str_replace("\r", '', ConvertUtils::WMBackHtmlNewCode($text))
			);
		}
		return $message;
	}

	protected function SendMessage($oAccount, $sSubject, $sFiendlyName, $html = null, $text = null)
	{
		$message = $this->CreateMessage($oAccount, $oAccount->Email, $sSubject, $sFiendlyName, $html, $text);
		$message->OriginalMailMessage = $message->ToMailString(true);

		return CSmtp::SendMail($oAccount, $message, null, null);
	}

	protected function GetReminder($oEventStartDT, $oStartDT, $oEndDT, $sEventId, $aReminders)
	{
		$iStartEventTS = $oEventStartDT->getTimestamp();
		$iStartTS = $oStartDT->getTimestamp();
		$iEndTS = $oEndDT->getTimestamp();

		$aRemindersTime = array();
		foreach ($aReminders as $iReminder)
		{
			$iReminderOffset = CCalendarUtils::GetReminderOffset($iReminder['offset']);
			$aRemindersTime[] = $iStartEventTS - $iReminderOffset;
		}
		sort($aRemindersTime);
		foreach ($aRemindersTime as $iReminder)
		{
			if ($iReminder >= $iStartTS && $iReminder < $iEndTS)
			{
				return $iReminder;
			}
		}
		return false;
	}


	public function Execute($sCheckInterval, $sCronInterval)
	{
		CApi::Log('---------- Start cron script', ELogLevel::Full, 'cron-');

		$oNowDT = new DateTime('now', new DateTimeZone('UTC'));
		$iNowTS = $oNowDT->getTimestamp();

		$oStartDT = clone $oNowDT;
		
		if (file_exists($this->nextRunFilePath))
		{
			$handle = fopen($this->nextRunFilePath, 'r');
			$sNextRunFileTS = fread($handle, 10);
			if (!empty($sNextRunFileTS) && is_numeric($sNextRunFileTS))
			{
				$oStartDT = new DateTime();
				$oStartDT->setTimestamp($sNextRunFileTS);
				$oStartDT->setTimezone(new DateTimeZone('UTC'));
			}
		}

		$iStartTS = $oStartDT->getTimestamp();

		if ($iNowTS >= $iStartTS)
		{
			CApi::Log('Start time: '.$oStartDT->format('r'), ELogLevel::Full, 'cron-');

			$oEndDT = clone $oNowDT;
			$oEndDT->add(new DateInterval($sCheckInterval));
			$iEndTS = $oEndDT->getTimestamp();

			CApi::Log('End time: '.$oEndDT->format('r'), ELogLevel::Full, 'cron-');

			$oEndCronDT = clone $oNowDT;
			$oEndCronDT->add(new DateInterval($sCronInterval));
			$iEndCronTS = $oEndCronDT->getTimestamp();

			CApi::Log('End cron time: '.$oEndCronDT->format('r'), ELogLevel::Full, 'cron-');

			$sStart = $oStartDT->format("Ymd\THi00\Z");
			$sEnd = $oEndDT->format("Ymd\THi00\Z");

			// check cache
			$aCacheNone = $this->apiCalendarManager->GetRemindersCache(NEED_TO_CHECK);
			$aCacheReCheck = $this->apiCalendarManager->GetRemindersCache(RECHECK, $iStartTS, $iEndCronTS);

			$aCache = array();
			if (is_array($aCacheNone) && is_array($aCacheReCheck))
			{
				$aCache = array_merge($aCacheNone, $aCacheReCheck);
			}

			$iType = RECHECK;
			$sEventId = null;
			$mReminderTime = false;
			$aAlarms = array();

			foreach ($aCache as $aCacheItem)
			{
				$oAccount = $this->getAccount($aCacheItem['user']);
				if ($oAccount)
				{
					try
					{
						$aAlarms = $this->apiCalendarManager->GetAlarms($oAccount, $aCacheItem['calendaruri'], $sStart, $sEnd);
					}
					catch (Exception $ex)
					{
						CApi::Log('Calendar Exception: '.$ex->getTraceAsString(), ELogLevel::Full, 'cron-');
					}
				}

				$oEventStartDT = null;

				if (is_array($aAlarms) && count($aAlarms) > 0)
				{
					$aEvents = $aAlarms['events'];
					$aData = $aAlarms['data'];

					if (is_array($aEvents) && count($aEvents) > 0)
					{
						foreach ($aEvents as $aEvent)
						{
							$iType = NEED_TO_CHECK;
							$sEventId = $aEvent['event_id'];
							$oEventStartDT = new DateTime($aEvent['event_dtstart']);
							$bRepeats = $aEvent['event_repeats'] !== '0' ? true : false;;

							if ($bRepeats)
							{
								$oEventStartDT = CCalendarUtils::_getNextRepeat($oStartDT, $aData[$sEventId], $sEventId);
							}
							if ($oEventStartDT >= $oStartDT)
							{
								$mReminderTime = false;
								if (isset($aAlarms['reminders'][$sEventId]))
								{
									$mReminderTime = $this->GetReminder($oEventStartDT, $oStartDT, $oEndDT, $sEventId, $aAlarms['reminders'][$sEventId]);
									$iType = REMIND;
								}
								if ($mReminderTime === false)
								{
									$mReminderTime = $iEndTS;
									$iType = RECHECK;
								}
							}
							else
							{
								$oEventStartDT = null;
								$iType = NEED_TO_CHECK;
							}
						}
					}
				}

				CApi::Log('---------------------------', ELogLevel::Full, 'cron-');
				CApi::Log('User: '.$aCacheItem['user'], ELogLevel::Full, 'cron-');
				CApi::Log('Calendar uri: '.$aCacheItem['calendaruri'], ELogLevel::Full, 'cron-');
				if (isset($oEventStartDT))
				{
					$this->apiCalendarManager->UpdateRemindersCache($aCacheItem['calendaruri'], $iType, $mReminderTime, $oEventStartDT->getTimestamp(), $sEventId);

					CApi::Log('Process alarm...', ELogLevel::Full, 'cron-');
					CApi::Log('Event id: '.$sEventId, ELogLevel::Full, 'cron-');
					CApi::Log('Event start time: '.$oEventStartDT->format("Y-m-d H:i:s"), ELogLevel::Full, 'cron-');
					CApi::Log('Event reminder time: '.gmdate("Y-m-d H:i:s", $mReminderTime), ELogLevel::Full, 'cron-');
				}
				else
				{
					$this->apiCalendarManager->UpdateRemindersCache($aCacheItem['calendaruri'], $iType, $iEndCronTS);

					CApi::Log('Update reminder cache...', ELogLevel::Full, 'cron-');
					CApi::Log('Cache type: ' . $iType, ELogLevel::Full, 'cron-');
					CApi::Log('Next cron time: ' . $oEndDT->format("Y-m-d H:i:s"), ELogLevel::Full, 'cron-');
				}
				CApi::Log('---------------------------', ELogLevel::Full, 'cron-');
			}

			$aCacheRemind = $this->apiCalendarManager->GetRemindersCache(REMIND, $iStartTS, $iEndCronTS);
			$aEvents = array();
			if ($aCacheRemind && is_array($aCacheRemind) && count($aCacheRemind) > 0)
			{
				$aCacheEvents = array();
				foreach($aCacheRemind as $aCacheItem)
				{
					$oAccount = $this->getAccount($aCacheItem['user']);
					$this->apiCalendarManager->UpdateRemindersCache($aCacheItem['calendaruri'], NEED_TO_CHECK);
					if (!isset($aCacheEvents[$aCacheItem['eventid']]))
					{
						$aCacheEvents[$aCacheItem['eventid']]['data'] = $this->apiCalendarManager->GetEvent($oAccount, $aCacheItem['calendaruri'], $aCacheItem['eventid']);

						$dt = new DateTime();
						$dt->setTimestamp($aCacheItem['starttime']);
						$dt->setTimezone(new DateTimeZone($oAccount->GetDefaultStrTimeZone()));


						$sDateFormat = '';
						$sTimeFormat = '';
						if ($oAccount->User->DefaultDateFormat == EDateFormat::DDMMYYYY)
						{
							$sDateFormat = 'd/m/Y';
						}
						else
						{
							$sDateFormat = 'm/d/Y';
						}
						if ($oAccount->User->DefaultTimeFormat == ETimeFormat::F24)
						{
							$sTimeFormat = 'H:i';
						}
						else
						{
							$sTimeFormat = 'h:i A';
						}

						$aCacheEvents[$aCacheItem['eventid']]['time'] = $dt->format($sDateFormat . ' ' . $sTimeFormat);
					}
					if (isset($aCacheEvents[$aCacheItem['eventid']]))
					{
						$aEvents[$aCacheItem['user']][$aCacheItem['calendaruri']] = $aCacheEvents[$aCacheItem['eventid']];
					}
				}
			}

			foreach ($aEvents as $sEmail => $aUserEvents)
			{
				foreach ($aUserEvents as $sCalendarUri => $aUserEvent)
				{
					if (isset($aUserEvent['data']['events']))
					{
						foreach ($aUserEvent['data']['events'] as $aEvent)
						{
							$oAccount = $this->getAccount($sEmail);
							$oCalendar = $this->getCalendar($oAccount, $sCalendarUri);
							if ($oCalendar)
							{
								$sDate = $aUserEvent['time'];

								$sEventName = $aEvent['event_name'];
								$sEventText = $aEvent['event_text'];
								$sCalendarName = $oCalendar->DisplayName;
								$sCalendarColor = $oCalendar->Color;
								$sSubject = Event . ' ' . $sEventName . ' ' .  ReminderEventBegin . $sDate;
								$sFiendlyName = '';

								$sHtmlBody = $this->CreateBodyHtml($oAccount->Email, $sEventName, 
										$sDate, $sCalendarName, $sEventText, $sCalendarColor);

								$sTextBody = $this->CreateBodyText($oAccount->Email, $sEventName, 
										$sDate, $sCalendarName, $sEventText);

								$bIsMessageSent = $this->SendMessage($oAccount, $sSubject, $sFiendlyName, $sHtmlBody,
																			$sTextBody);
								$this->apiCalendarManager->UpdateRemindersCache($sCalendarUri, NEED_TO_CHECK);
								if ($bIsMessageSent)
								{
									CApi::Log("Send reminder for event: '" . $sEventName . "' started on '" . $sDate . "' to '" . $oAccount->Email ."'", ELogLevel::Full, 'cron-');
								}
								else
								{
									CApi::Log('Send reminder for event: FAILED!', ELogLevel::Full, 'cron-');
								}
							}
							else
							{
								CApi::Log('Calendar '.$sCalendarUri.' not found!', ELogLevel::Full, 'cron-');
							}
						}
					}
				}
			}

			file_put_contents($this->nextRunFilePath, $iEndCronTS);
		}
		else
		{
			CApi::Log('Time is out of cron execution interval', ELogLevel::Full, 'cron-');
		}
		CApi::Log('---------- End cron script', ELogLevel::Full, 'cron-');
	}
}

$timer = microtime(true);

$oReminder = new CReminder();
$oReminder->Execute('P2D', 'PT5M');

CApi::Log('Cron execution time: ' . (microtime(true) - $timer) . " sec.", ELogLevel::Full, 'cron-');
