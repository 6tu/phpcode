/*
 * Create
 * RefreshCalendarSelector
 * MarkEventedDays
  * CreateChangeMonthFunc
*/
function CCalendarTable ()
{
	this.m_names = [
		Lang.FullMonthJanuary,
		Lang.FullMonthFebruary,
		Lang.FullMonthMarch,
		Lang.FullMonthApril,
		Lang.FullMonthMay,
		Lang.FullMonthJune,
		Lang.FullMonthJuly,
		Lang.FullMonthAugust,
		Lang.FullMonthSeptember,
		Lang.FullMonthOctober,
		Lang.FullMonthNovember,
		Lang.FullMonthDecember
	];
	this.weeksnum = 7;

	this.middleTdSelector	= $id('middleTdSelector');
	this.monthsList			= $id('monthsList');
	this.prevMonthSwitcher	= $id('prevMonthSwitcher');
	this.nextMonthSwitcher	= $id('nextMonthSwitcher');
	this.currentMonth		= $id('MonthSelector');
	this.calendarInManagerBlock = $id('calendarInManagerBlock');

	this.weekendIds			= [];
	this.calendarRows		= [];
	this.months				= [];

	this.Create();
	this.RefreshCalendarSelector(mydate.getDate(), mydate.getMonth()+1, mydate.getFullYear());
}

CCalendarTable.prototype = {
	Create: function ()
	{
		var obj = this, i, evt_middle, cal_txt, txt, a, tempDiv, trArr, tdArr, td, title, w;
		this.monthsList.hidden = true;
		this.middleTdSelector.onmouseover = function() {
			obj.middleTdSelector.className = 'middleTdSelector_over';
		}
		this.middleTdSelector.onmouseout = function() {
			if (obj.monthsList.hidden) {
				obj.middleTdSelector.className = 'middleTdSelector';
			}
		}
		this.middleTdSelector.onclick = function() {
			obj.monthsList.style.display = (obj.monthsList.hidden) ? "block" : "none";
			obj.monthsList.hidden = !obj.monthsList.hidden;
		}

		for (i=-6, j=0; i<7; i++, j++) {
			evt_middle = document.createElement("div");
			evt_middle.className = 'event_middle';
			cal_txt = document.createElement("div");
			cal_txt.className = 'calendar_text';
			txt = document.createElement("span");
			txt.className = 'text';
			a = document.createElement("a");
			a.href = 'javascript:void(0);';
			this.months[j] = a;
			txt.appendChild(a);
			cal_txt.appendChild(txt);
			evt_middle.appendChild(cal_txt);
			this.monthsList.appendChild(evt_middle);
		}
		tempDiv = document.createElement("div");
		tempDiv.className = 'b';
		tempDiv.height = "1px !important";
		this.monthsList.appendChild(tempDiv);
		tempDiv = document.createElement("div");
		tempDiv.className = 'a';
		this.monthsList.appendChild(tempDiv);

		trArr = this.calendarInManagerBlock.getElementsByTagName("tr");
		tdArr = trArr[0].getElementsByTagName("td");
		for (i=0; i<tdArr.length; i++) {
			title = document.createTextNode(weekDaysNamesCalendar[i]);
			tdArr[i].appendChild(title);
		}

		for (w=1; w<trArr.length; w++) {
			this.calendarRows[w-1] = [];
			tdArr = trArr[w].getElementsByTagName("td");
			for(i = 0; i<7; i++){
				a = document.createElement("a");
				a.href = 'javascript:void(1);';
				tdArr[i].appendChild(a);
				this.calendarRows[w-1][i] = {td: tdArr[i], a: a}
			}
		}
	},

	RefreshCalendarSelector: function(day,month,year) //fill calendar with new data
	{
		var todayDate, today_month, today_year, today_date, PM_prev_month, PM_prev_year, NM_next_month, NM_next_year, txt;
		var i, k=0, a, m_num;

		day = Number(day);
		month = Number(month);
		year = Number(year);

		todayDate = new Date();
		today_month = todayDate.getMonth();
		today_year = todayDate.getFullYear();
		today_date = todayDate.getDate();

		// checking input data
		if (month == null || isNaN(month) || day == null || isNaN(day) || year == null || isNaN(year)) {
			month = today_month+1;
			day = today_date;
			year = today_year;
		}
		// For Previous Month
		PM_prev_month = month-1;
		PM_prev_year = year;
		if (PM_prev_month == 0) {
			PM_prev_month = 12;
			PM_prev_year = year -1;
		}
		// For Next Month
		NM_next_month = month +1;
		NM_next_year = year;
		if (NM_next_month == 13) {
			NM_next_month = 1;
			NM_next_year = year + 1;
		}

		this.prevMonthSwitcher.onclick = this.CreateChangeMonthFunc(this, PM_prev_month, PM_prev_year);
		this.nextMonthSwitcher.onclick = this.CreateChangeMonthFunc(this, NM_next_month, NM_next_year);
		PasteTextNode(this.currentMonth, (this.m_names[month - 1] + ' ' + year));

		for (i=-6, j=0; i<7; i++, j++) {
			a = this.months[j];
			m_num = month-1 + i;
			if (m_num<0) {
				a.onclick = this.CreateChangeMonthFunc(this, (12 + m_num + 1), (year-1));
				PasteTextNode(a, (this.m_names[12 + m_num] +  ' ' + (year-1)));
			} else if (m_num>=0 && m_num<=11) {
				a.onclick = this.CreateChangeMonthFunc(this, (m_num+1), year);
				if ((m_num+1) == month) a.style.fontWeight = 'bold';
				PasteTextNode(a, (this.m_names[m_num] +  ' ' + year));
			} else {
				a.onclick = this.CreateChangeMonthFunc(this, (k+1), (year+1));
				PasteTextNode(a, (this.m_names[k] +  ' ' + (year+1)));
				k++;
			}
		}

		month = month -1;
		this_date = new Date(monthLimits[year][month].bigStart);

		var link_class = "", w, tr, d, this_date_year, this_date_month, this_date_date, this_date_day, id, push_weekend;
		for (w = 0; w<this.weeksnum; w++) {
			tr = this.calendarRows[w];//tr = {td: td, a: a}
			for (d = 0; d < tr.length; d++) {
				this_date_year = this_date.getFullYear();
				this_date_month = this_date.getMonth();
				this_date_date = this_date.getDate();
				this_date_day = this_date.getDay();

				a = tr[d].a;
				id = this_date_year + Fnum((this_date_month+1),2) + Fnum(this_date_date,2);
				a.id = id;
				push_weekend = false;
				for (i=0; i<weekendDays.length; i++) {
					if (weekendDays[i] == this_date_day && setcache.showweekends == 1) {
						this.weekendIds[String(id)] = true;
						push_weekend = true;
						break;
					}
				}
				if (this_date_month != month) {
					link_class = (push_weekend) ? 'CalLinkInactiveWeekend' : 'CalLinkInactive';
				}
				else {
					link_class = 'CalLink';
				}
				a.className = link_class;
				a.onclick = function() {Switch2date(this.id);}
				PasteTextNode(a, this_date_date);
				this_date.setDate(this_date_date + 1);
			}
		}
		this.MarkEventedDays();
	},
	MarkEventedDays : function() {
		var event_id, checked = false, w, a, tr, d, tdClass = "", currentYear, currentMonth, monthStart, monthEnd, limitsDay, weekLimitsFrom, weekLimitsTill, todayDate, today_id, current_day, weekendDay;

		currentYear = mydate.getFullYear();
		currentMonth = mydate.getMonth();
		monthStart = to8(monthLimits[currentYear][currentMonth].smallStart);
		monthEnd = to8(monthLimits[currentYear][currentMonth].smallEnd);
		limitsDay = showLimits.day;
		weekLimitsFrom = showLimits.weekFrom;
		weekLimitsTill = showLimits.weekTill;

		for (w = 0; w<this.weeksnum; w++) {
			tr = this.calendarRows[w];//[k] = {td: td, a: a}
			for (d = 0; d < tr.length; d++) {
				a = tr[d].a;
				event_id = a.id;
				checked = (all_events_dates[event_id] != undefined);
				a.style.fontWeight = checked ? "bold" : "normal";

				if (view == DAY && event_id == limitsDay) {
					tdClass = 'select';
				}
				else if (view == WEEK && (event_id >= weekLimitsFrom && event_id <= weekLimitsTill)) {
					tdClass = 'select';
				}
				else if (view == MONTH && (event_id >= monthStart && event_id <= monthEnd)) {
					tdClass = 'select';
				}
				else if (setcache.showweekends == 1) {
					weekendDay = this.weekendIds[event_id];
					if (weekendDay != undefined && weekendDay == true) tdClass = 'weekend';
					else tdClass = 'basic';
				}
				else {
					tdClass = 'basic';
				}
				tr[d].td.className = tdClass;
			}
		}

		todayDate = new Date();
		today_id = to8(todayDate);
		current_day = $id(String(today_id));
		if (current_day != undefined) current_day.parentNode.className = "today";
	},

	CreateChangeMonthFunc : function(obj, PM_prev_month, PM_prev_year) {
		return function() {
			CacheLoad(new Date(PM_prev_year, (PM_prev_month-1), 1));
			obj.RefreshCalendarSelector(1, PM_prev_month, PM_prev_year);
		}
	}
}//CCalendarTable.prototype