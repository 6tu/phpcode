<!-- start of $Id: no_mail.php,v 1.10 2007/03/17 07:32:14 goddess_skuld Exp $ -->
<?php
  if (!isset($conf->loaded))
    die('Hacking attempt');
?>
<tr>
  <td colspan="<?php echo count($conf->column_order) + 1; ?>" class="inbox center">
    <?php echo convertLang2Html($html_no_mail) ?>
  </td>
</tr>
<!-- end of $Id: no_mail.php,v 1.10 2007/03/17 07:32:14 goddess_skuld Exp $ -->
