<?php
/**
 * https://www.php.net/manual/zh/function.openssl-csr-new.php
 * https://www.php.net/manual/zh/openssl.installation.php
 * https://www.php.net/manual/zh/function.openssl-csr-sign.php
 */

# set OPENSSL_CONF="C:\usr\local\ssl\openssl.cnf"
$certdir = './certs/';
if(!file_exists($certdir)) mkdir($certdir);
if(empty(getenv('OPENSSL_CONF'))) $config_file = $certdir . "conf/openssl.cnf";
else $config_file = getenv('OPENSSL_CONF');
if(!file_exists($config_file)) die($config_file . "无效");

$keybits       = 4096;                               # 私钥长度
$days          = 3650;                               # 证书有效时长
$digest_alg    = 'sha512';                           # 摘要/哈希算法
$commonName    = "secure.example.com";               # 公共名称，一般是域名

$private_path  = $certdir . "ras_private.key";       # 私钥路径
$public_path   = $certdir . "ras_public.key";        # 公钥路径
$csr_path      = $certdir . "ras_csr.pem";           # 签名请求路径
$ss_cert_path  = $certdir . "ras_ss-cert.crt";       # 证书路径
$cas_cert_path = $certdir . "ras_cas-cert.crt";      # 证书路径
$pfx_path      = $certdir . "pfx_cert.pfx";          # pfx证书文件路径
$pfx_passwd    = 'password';                         # 存储pfx证书所需密码
$private_pw    = "";                                 # 私钥密码

$ca_password   = "oQy7VEjMrxM=";                     # CA 私钥密码，与 $cakey_path 同目录
$cakey_path    = $certdir."demoCA/private/cakey.pem";# CA 私钥
$cacert_path   = $certdir . "demoCA/cacert.pem";     # CA 证书

$dn = array(
    "countryName"            => 'CN',                # 所在国家名称
    "stateOrProvinceName"    => 'State',             # 所在省份名称
    "localityName"           => 'SomewhereCity',     # 所在城市名称
    "organizationName"       => 'MySelf',            # 注册人姓名
    "organizationalUnitName" => 'Whatever',          # 组织名称
    "commonName"             => $commonName,         # 公共名称
    "emailAddress"           => 'user@domain.com'    # 邮箱
);

$options = array(
    // "config"             => $opensslpath,         # openssl.conf 文件的路径
    "digest_alg"            => $digest_alg,          # 摘要/哈希算法
    "x509_extensions"       => 'v3_ca',              # 创建 x509 证书时应该使用哪些扩展
    "req_extensions"        => '',                   # 创建 CSR 时使用哪个扩展
    "private_key_bits"      => $keybits,             # 私钥位数
    "private_key_type"      => OPENSSL_KEYTYPE_RSA,  # 创建 CSR 时应该使用哪些扩展
    "encrypt_key"           => true,                 # 对导出的密钥（带有密码短语）是否加密
    "encrypt_key_cipher"    => 'none',               # 加密规范 常量
    // "curve_name"         => 'none',               # ECC的曲线名称
);

$config = array(
    "config"                => $config_file,
    "digest_alg"            => $digest_alg,
    "private_key_bits"      => $keybits,
    "private_key_type"      => OPENSSL_KEYTYPE_RSA,
);

$extra_attributes = array();

$res = openssl_pkey_new($config);                       # 建立密钥对
if(empty($res)) die('<h2>建立密钥失败</h2>');

openssl_pkey_export($res, $private_key, NULL, $config); # 私钥
file_put_contents($private_path, $private_key);

$public_key = openssl_pkey_get_details($res)['key'];    # 公钥
file_put_contents($public_path, $public_key);

$csr = openssl_csr_new($dn, $res, $config);             # 生成证书签名请求
openssl_csr_export($csr, $csr_string, false);           # 导出签名请求
file_put_contents($csr_path, $csr_string);

$sscert = openssl_csr_sign($csr, null, $res, $days, $config); # 生成自签名RSA证书
openssl_x509_export($sscert, $cert);                    # 导出证书
file_put_contents($ss_cert_path, $cert);

# CA中心签发
$cacert_string = file_get_contents($cacert_path);
$cakey_string = file_get_contents($cakey_path);
$privkey_ca = array($cakey_string, $ca_password);
$x509 = openssl_csr_sign($csr, $cacert_string, $privkey_ca, $days = 3650, $config);
openssl_x509_export($x509, $cascert);
file_put_contents($cas_cert_path, $cascert);
// echo PHP_EOL.$cascert.PHP_EOL;

# 导出 PKCS#12 兼容证书存储文件
$args = array(
    'friendly_name' => 'www.example.com',
);
openssl_pkcs12_export_to_file($sscert, $pfx_path, $private_key, $pfx_passwd, $args);  # 返回布尔值，写入文件

// openssl_pkcs12_export($sscert, $cert_out, $private_key, $pfx_passwd);              # 返回布尔值，输出二进制
// file_put_contents('_'.$pfx_path, $cert_out);
// openssl_pkcs12_read($cert_out, $string_out, $pfx_passwd);                          # 读入二进制，输出数组
// print_r($string_out);

while($message = openssl_error_string()){
    // echo $message.'<br />'.PHP_EOL;
}

echo "\n私钥\n". $private_key ."\n\n公钥\n". $public_key;
exit;

# 可用的摘要别名
$digests = openssl_get_md_methods();
$digests_and_aliases = openssl_get_md_methods(true);
$digest_aliases = array_diff($digests_and_aliases, $digests);
print_r($digests);
print_r($digest_aliases);

# 可用的加密算法及别名
$ciphers = openssl_get_cipher_methods();
$ciphers_and_aliases = openssl_get_cipher_methods(true);
$cipher_aliases = array_diff($ciphers_and_aliases, $ciphers);
# 应避免ECB模式
$ciphers = array_filter($ciphers, function($n){ return stripos($n, "ecb") === FALSE;});
# 早在2016年8月，Openssl就声明了以下弱点：基于RC2、RC4、DES、3DES、MD5
$ciphers = array_filter($ciphers, function($c){ return stripos($c, "des") === FALSE;});
$ciphers = array_filter($ciphers, function($c){ return stripos($c, "rc2") === FALSE;});
$ciphers = array_filter($ciphers, function($c){ return stripos($c, "rc4") === FALSE;});
$ciphers = array_filter($ciphers, function($c){ return stripos($c, "md5") === FALSE;});
$cipher_aliases = array_filter($cipher_aliases, function($c){ return stripos($c, "des") === FALSE;});
$cipher_aliases = array_filter($cipher_aliases, function($c){ return stripos($c, "rc2") === FALSE;});
print_r($ciphers);
print_r($cipher_aliases);

# 获得ECC的可用曲线名称列表
$curve_names = openssl_get_curve_names();
print_r($curve_names);
