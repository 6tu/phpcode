<?php
# 获取文件名之后，有选择的输出
# 或者是从 header 中读取类型
error_reporting(E_ALL);
ini_set('display_errors', '1');
 
//将出错信息输出到一个文本文件
ini_set('error_log', dirname(__FILE__) . './error_log.txt');

if ($_SERVER["HTTPS"] <> "on"){    
    $xredir = "https://" . $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];    
    header("Location: " . $xredir);    
}

$host = base64_decode('bWluZ2h1aS5vcmc=');
$domain = 'http://www.' .$host. '/';

$rdomain = encrypt_host();

if(empty($_GET['path'])){
    $url = $domain . 'mmh/index.html';
    $html = get_contents($url);
    $html = $html['body'];
    $output = change_html($html);
    $output = str_replace($host, $rdomain, $output);
}else{
    $url = $domain . $_GET['path'];
    $html = get_contents($url);
    $output = $html['body'];
    if($html['mime_type'] == 'text/html'){
        $output = change_html($output);
        $output = str_replace($host, $rdomain, $output);
    }else{
        header('Content-Type: ' . $html['mime_type']);
        echo $output;
        exit();
    }

}

if(!empty($_GET['src'])){
    $url = $domain . $_GET['src'];
    $src_content = get_contents($url);
    $src_content = $src_content['body'];
    resheader($url);
    echo $src_content;
}

if(!empty($_GET['url'])){
    $url = str_replace($rdomain, $host, $_GET['url']);
    $pathinfo = pathinfo($url);
    $ext = $pathinfo['extension'];
    resheader($url);
    $other = get_contents($url);
    $other = $other['body'];
    if(strstr($ext, 'htm')){
        $output = $other;
        $output = str_replace($host, $rdomain, $output);
        change_html($output);
    }else echo $other;
}

/**
 * ob_start();
 * 
 * $final = '';
 * $levels = ob_get_level();
 * for ($i = 0; $i < $levels; $i++){
 * $final .= ob_get_clean();
 * }
 */

//header("Content-type: text/html; charset=UTF-8");
//echo (toutf8($output));
encrypt_mode($output);

# 加密域名
function encrypt_host(){
    # 用 SESSION 生成随机KEY
    $key = seskey();
    $array = array(substr($key, 0, 8), strtoupper(substr($key, 8, 3)), substr($key, 11, 11), strtoupper(substr($key, 24, 8)));
    // $num = rand(0, 3);
    // $key = $array[$num];
    $rdomain = $array[2] . '.' . $array[1];
	return $rdomain;
}

function seskey(){
    $tmp_path = './tmp';
    $os_name = PHP_OS;
    
    # 设定session保存路径和保存时长
    if(file_exists($tmp_path) == false) mkdir($tmp_path, 0700);
    session_save_path($tmp_path); # SESSION 存储路径
    $session_time = 864000; # SESSION 过期时间(秒)
    $lifeTime = 10; # COOKIE 保存时间(分钟)
    session_start();
    
    # 提取C段IP和生产 KEY
    $ip = $_SERVER['REMOTE_ADDR'];
    $array_ip = explode('.', $ip);
    $ip_c = $array_ip[0] . '.' . $array_ip[1] . '.' . $array_ip[2];
    $ipmd5 = strtolower(md5($ip));
    $key = $ipmd5;
    
    # 对同一浏览器记录 IP 和 KEY
    @ini_set('session.gc_maxlifetime', $session_time);
    if(empty($_SESSION[$ip_c])) $_SESSION[$ip_c] = '';
    if(empty($_SESSION['key'])) $_SESSION['key'] = $key;
    else $key = $_SESSION['key'];
    return $key;
}

# 随机值
function randkey(){
    $str = "abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $key = substr(str_shuffle($str), 26, 10);
    return $key;
}

# 修改 HTML 中的超链接
function change_html($output){
    $phpself = php_self();
    // $css = "\r\n<style>" . file_get_contents($domain . 'pub/mobile.css') . '</style>';
    // $html = explode('</title>', $html);
    // $output = $html[0] . '</title>' . $css . $html[1];
    $search = array ("'<script[^>]*?>.*?</script>'si");
    $replace = array ("");
    $output = preg_replace($search, $replace, $output);
    $output = str_replace('= ', '=', $output);
    $output = str_replace(' =', '=', $output);
    $output = str_replace('href="/favicon.ico"', 'href="./favicon.ico', $output);
    $output = str_replace('href=/', 'href=./' . $phpself . '?path=', $output);
    $output = str_replace('href=\'/', 'href=\'./' . $phpself . '?path=', $output);
    $output = str_replace('href="/', 'href="./' . $phpself . '?path=', $output);
    $output = str_replace('href=http', 'href=./' . $phpself . '?url=http', $output);
    $output = str_replace('href=\'http', 'href=\'./' . $phpself . '?url=http', $output);
    $output = str_replace('href="http', 'href="./' . $phpself . '?url=http', $output);

    $output = str_replace('src=/', 'src=./' . $phpself . '?src=', $output);
    $output = str_replace("src='/", "src='./" . $phpself . '?src=', $output);
    $output = str_replace('src="/', 'src="./' . $phpself . '?src=', $output);

    $output = str_replace('src=http', 'src=./' . $phpself . '?url=http', $output);
    $output = str_replace('src=\'http', 'src=\'./' . $phpself . '?url=http', $output);
    $output = str_replace('src="http', 'src="./' . $phpself . '?url=http', $output);
    $output = str_replace('href="./index.php?path=pub/', 'href="./pub/', $output);
    //$output = str_replace('src="./index.php?src=pub/', 'src="./pub/', $output);
    return $output;
}

# 当前执行的PHP文件名
function php_self(){
    $php_self = substr($_SERVER['PHP_SELF'], strrpos($_SERVER['PHP_SELF'], '/') + 1);
    return $php_self;
}

# 设置响应 header
function resheader($url){
    $pathinfo = pathinfo($url);
    $ext = $pathinfo['extension'];
    $filename = $pathinfo['basename'];
    $mimeType = minetype_array();
    if(array_key_exists($ext, $mimeType)){
        $mime_type = $mimeType[$ext];
    }else{
        $mime_type = 'application/x-' . $ext;
    }
    if(strstr($mime_type, 'application')){
        header('Content-Type: application/octet-stream');
        header('Content-Type: multipart/byteranges');
        header('Content-type: ' . $mime_type);
        header('Content-Disposition: attachment; filename=' .$filename);
    }else header("Content-type: " .$mime_type);
}

/**
 * 自定义 mime 类型的数组
 * 用法 minetype_array() 返回数组
 */
function minetype_array(){
    $mimeType = array(
        // applications(应用类型)
        'ai' => 'application/postscript',
        'eps' => 'application/postscript',
        'exe' => 'application/octet-stream',
        'doc' => 'application/vnd.ms-word',
        'xls' => 'application/vnd.ms-excel',
        'pdf' => 'application/pdf',
        'xml' => 'application/xml',
        'ppt' => 'application/vnd.ms-powerpoint',
        'pps' => 'application/vnd.ms-powerpoint',
        'odt' => 'application/vnd.oasis.opendocument.text',
        'swf' => 'application/x-shockwave-flash',
        
        // archives(档案类型)
        'gz' => 'application/x-gzip',
        'tgz' => 'application/x-gzip',
        'zip' => 'application/zip',
        'rar' => 'application/x-rar',
        'tar' => 'application/x-tar',
        'bz' => 'application/x-bzip2',
        'bz2' => 'application/x-bzip2',
        'tbz' => 'application/x-bzip2',
        '7z' => 'application/x-7z-compressed',
        
        // texts(文本类型)
        'txt' => 'text/plain',
        'php' => 'text/x-php',
        'html' => 'text/html',
        'htm' => 'text/html',
        'js' => 'text/javascript',
        'css' => 'text/css',
        'rtf' => 'text/rtf',
        'rtfd' => 'text/rtfd',
        'py' => 'text/x-python',
        'java' => 'text/x-java-source',
        'pl' => 'text/x-perl',
        'sql' => 'text/x-sql',
        'rb' => 'text/x-ruby',
        'sh' => 'text/x-shellscript',
        
        // images(图片类型)
        'bmp' => 'image/x-ms-bmp',
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'gif' => 'image/gif',
        'png' => 'image/png',
        'tif' => 'image/tiff',
        'tiff' => 'image/tiff',
        'tga' => 'image/x-targa',
        'psd' => 'image/vnd.adobe.photoshop',
        
        // audio(音频类型)
        'mp3' => 'audio/mpeg',
        'mid' => 'audio/midi',
        'ogg' => 'audio/ogg',
        'mp4a' => 'audio/mp4',
        'wav' => 'audio/wav',
        'wma' => 'audio/x-ms-wma',
        
        // video(视频类型)
        'avi' => 'video/x-msvideo',
        'dv' => 'video/x-dv',
        'mp4' => 'video/mp4',
        'mpeg' => 'video/mpeg',
        'mpg' => 'video/mpeg',
        'mov' => 'video/quicktime',
        'wm' => 'video/x-ms-wmv',
        'flv' => 'video/x-flv',
        'mkv' => 'video/x-matroska'
        );
    return $mimeType;
}

# 提取网页中的 charset，转换成utf-8编码，再转成HTML实体
function toutf8($output){
    $wcharset = preg_match("/<meta.+?charset=[^\w]?([-\w]+)/i",$output,$temp) ? strtolower($temp[1]):"";
    // $wtitle = preg_match("/<title>(.*)<\/title>/isU",$filecnt,$temp) ? $temp[1]:"";
    $output = mb_convert_encoding ($output,'utf-8',$wcharset);
    // $output = utf2html($output);
    return $output;
}

# UTF8转成HTML实体
function utf2html($str){
    $ret = "";
    $max = strlen($str);
    $last = 0;
    for ($i = 0;$i < $max;$i++){
        $c = $str{$i};
        $c1 = ord($c);
        if ($c1 >> 5 == 6){
            $ret .= substr($str, $last, $i - $last);
            $c1 &= 31; # remove the 3 bit two bytes prefix
            $c2 = ord($str{++$i});
            $c2 &= 63;
            $c2 |= (($c1 & 3) << 6);
            $c1 >>= 2;
            $ret .= "&#" . ($c1 * 0x100 + $c2) . ";";
            $last = $i + 1;
        }
        elseif ($c1 >> 4 == 14){
            $ret .= substr($str, $last, $i - $last);
            $c2 = ord($str{++$i});
            $c3 = ord($str{++$i});
            $c1 &= 15;
            $c2 &= 63;
            $c3 &= 63;
            $c3 |= (($c2 & 3) << 6);
            $c2 >>= 2;
            $c2 |= (($c1 & 15) << 4);
            $c1 >>= 4;
            $ret .= '&#' . (($c1 * 0x10000) + ($c2 * 0x100) + $c3) . ';';
            $last = $i + 1;
        }
    }
    $str = $ret . substr($str, $last, $i);
    return $str;
}

# 加密模式 PGP_ENCRYPT_MODE : 'gpg' 或者 'openpgp-php'.
function encrypt_mode($output){
    define('PGP_ENCRYPT_MODE', 'openpgp-php');
    define('GPG_HOME_DIR', '/var/www/.gnupg');
    define('GPG_BIN', '/usr/bin/gpg');
    
    if (PGP_ENCRYPT_MODE == 'gpg'){
        $cmd = GPG_BIN . " --homedir " . GPG_HOME_DIR . " --armor --batch -e -r 'wpgpg@ysuo.org'";
        $output = toutf8($output);
        $crypted = encrypt_command($cmd, $output);
    }
    else if (PGP_ENCRYPT_MODE == 'openpgp-php'){
        require_once("openpgp-php/vendor/autoload.php");
        require_once("openpgp-php/lib/helpers.php");
        $public_key = file_get_contents('/var/www/.gnupg/pub.txt');
        $key = OpenPGP_Message :: parse(OpenPGP :: unarmor(trim($public_key)));
        # $key = OpenPGP_Message::parse(file_get_contents('/var/www/.gnupg/pubring.gpg'));
        $output = toutf8($output);
        $data = new OpenPGP_LiteralDataPacket($output, array('format' => 'u'));
        $encrypted = OpenPGP_Crypt_Symmetric :: encrypt($key, new OpenPGP_Message(array($data)));
        $output = OpenPGP :: enarmor($encrypted -> to_bytes(), "PGP MESSAGE");
        $crypted = wordwrap($output, 64, "\n", 1);
    }
    else{
        die(" 没有加密工具");
    }
    
    $html = "<html>\r\n<head>\r\n<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>\r\n</head>\r\n";
    $html .= "<body>\r\n<center><div id='decryptbtn'></div><br/>\r\n";
    $html .= "<div id='crypted' align=\"left\" style='white-space:pre;font-family:monospace;font-size:14px;width:36%;border:dotted 1px black;overflow:auto'>\r\n";
    echo $html . $crypted . "\r\n</div></body></html>";
}

# 加密命令
function encrypt_command ($gpg_command, $data){
    $descriptors = array(
        0 => array("pipe", "r"), // stdin
        1 => array("pipe", "w"), // stdout
        2 => array("pipe", "w"), // stderr
        );
    $process = proc_open($gpg_command, $descriptors, $pipes);
    
    if (is_resource($process)){
        // send data to encrypt to stdin
        fwrite($pipes[0], $data);
        fclose($pipes[0]);
        // read stdout
        $stdout = stream_get_contents($pipes[1]);
        fclose($pipes[1]);
        // read stderr
        $stderr = stream_get_contents($pipes[2]);
        fclose($pipes[2]);
        // It is important that you close any pipes before calling
        // proc_close in order to avoid a deadlock
        $return_code = proc_close($process);
        $return_value = trim($stdout, "\n");
        // echo "$stdout";
        if (strlen($return_value) < 1){
            $return_value = "error: $stderr";
        }
    }
    return $return_value;
}

# 获取网页
function get_contents($url){
    
    if(!empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) $lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
    else $lang = 'zh-CN,zh;q=0.9';
    if(!empty($_SERVER['HTTP_USER_AGENT'])) $agent = $_SERVER['HTTP_USER_AGENT'];
    else $agent = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36';
    if(!empty($_SERVER['HTTP_REFERER'])) $refer = $_SERVER['HTTP_REFERER'];
    else $refer = 'https://www.google.com/?gws_rd=ssl';
    # echo "<pre>\r\n" . $agent . "\r\n" . $refer . "\r\n" . $lang . "\r\n\r\n";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_USERAGENT, $agent);
    curl_setopt($ch, CURLOPT_REFERER, $refer);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Accept-Language: " . $lang));
    
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);   // follow redirects
    curl_setopt($ch, CURLOPT_AUTOREFERER, true);      // set referer on redirect

    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 8);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 4);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($ch);
    curl_close($ch);
    
    $res_array = explode("\r\n\r\n", $result, 2);
    $headers = explode("\r\n", $res_array[0]);
    $status = explode(' ', $headers[0]);
    # 如果$headers为空，则连接超时
    if(empty($res_array[0])) die('<br><br><center><b>连接超时</b></center>');
    # 如果$headers状态码为404，则自定义输出页面。
    if($status[1] == '404') die("<pre><b>找不到，The requested URL was not found on this server.</b>\r\n\r\n$res_array[0]</pre>\r\n\r\n");
    # 如果$headers第一行没有200，则连接异常。
    # if($status[1] !== '200') die("<pre><b>连接异常，状态码： $status[1]</b>\r\n\r\n$res_array[0]</pre>\r\n\r\n");\

    if($status[1] !== '200'){
        $body_array = explode("\r\n\r\n", $res_array[1], 2);
        $header_all = $res_array[0] . "\r\n\r\n" . $body_array[0];
        $res_array[0] = $body_array[0];
        $body = $body_array[1];
    }else{
        $header_all = $res_array[0];
        $body = $res_array[1];
    }

    $headers = explode("\r\n", $res_array[0]);
    $status = explode(' ', $headers[0]);
    
    $headers[0] = str_replace('HTTP/1.1', 'HTTP/1.1:', $headers[0]);
    foreach($headers as $header){
        if(stripos(strtolower($header), 'content-type:') !== FALSE){
            $headerParts = explode(' ', $header);
            $mime_type = trim(strtolower($headerParts[1]));
            if(!empty($headerParts[2])){
                $charset_array = explode('=', $headerParts[2]);
                $charset = trim(strtolower($charset_array[1]));
            }else{
                $charset = preg_match("/<meta.+?charset=[^\w]?([-\w]+)/i", $res_array[1], $temp) ? strtolower($temp[1]):"";
            }
        }
    }

    if(strstr($mime_type, 'text/html')){
        $body = mb_convert_encoding ($body, 'utf-8', $charset);
    }
    # $body = preg_replace('/(?s)<meta http-equiv="Expires"[^>]*>/i', '', $body);    
    
    # echo "<pre>\r\n$header_all\r\n\r\n" . "$status[1]\r\n$mime_type\r\n$charset\r\n\r\n";
    # header($res_array[0]);

    $res_array = array();
    $res_array['header']    = $header_all;
    $res_array['status']    = $status[1];
    $res_array['mime_type'] = $mime_type;
    $res_array['charset']   = $charset;
    $res_array['body']      = $body;
    return $res_array;
}

