
function testIssue74() {
    return /'/;
}
