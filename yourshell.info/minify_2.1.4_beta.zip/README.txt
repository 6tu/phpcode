THIS IS A BETA RELEASE OF MINIFY 2.1.4

With it comes lots of new bug fixes and features (more details in
HISTORY.txt), but potentially new bugs as well, so be on the lookout. 

Please kick the tires, especially with the cookie-based debug mode 
and combining multiple groups and files together.


WELCOME TO MINIFY 2.1!

Minify is an HTTP content server. It compresses sources of content 
(usually files), combines the result and serves it with appropriate 
HTTP headers. These headers can allow clients to perform conditional 
GETs (serving content only when clients do not have a valid cache) 
and tell clients to cache the file for a period of time. 
More info: http://code.google.com/p/minify/


WORDPRESS USER?

These WP plugins integrate Minify into WordPress's style and script hooks to
get you set up faster.
  http://wordpress.org/extend/plugins/wp-minify/
  http://wordpress.org/extend/plugins/w3-total-cache/


UPGRADING

See UPGRADING.txt for instructions.


INSTALLATION AND USAGE:

1. Place the /min/ directory as a child of your DOCUMENT_ROOT 
directory: i.e. you will have: /home/user/www/min

2. Open http://yourdomain/min/ in a web browser. This will forward
you to the Minify URI Builder application, which will help you
quickly start using Minify to serve content on your site.

See the User Guide: http://code.google.com/p/minify/wiki/UserGuide


UNIT TESTING:

1. Place the /min_unit_tests/ directory as a child of your DOCUMENT_ROOT 
directory: i.e. you will have: /home/user/www/public_html/min_unit_tests

2. To run unit tests, access: http://yourdomain/min_unit_tests/test_all.php

(If you wish, the other test_*.php files can be run to test individual
components with more verbose output.)

3. Remove /min_unit_tests/ from your DOCUMENT_ROOT when you are done.


FILE ENCODINGS

Minify *should* work fine with files encoded in UTF-8 or other 8-bit 
encodings like ISO 8859/Windows-1252. By default Minify appends
";charset=utf-8" to the Content-Type headers it sends. 

Leading UTF-8 BOMs are stripped from all sources to prevent 
duplication in output files, and files are converted to Unix newlines.

