<?
$htmlcode='<html><head>
<title>up files</title></head> 
<body> 
<form enctype="multipart/form-data" action="up.php" method="post"> 
<br>
<input name="upload_file" type="file">   <input type="submit" name="upload" value="�ϴ�"> 
</form> 
</body>
</html> ';
@$upload_file=$_POST['upload_file'];
@$upload_file=$_FILES['upload_file']['tmp_name'];
@$upload_file_name=$_FILES['upload_file']['name'];
$store_dir = "up/";
if ($upload_file==""){
echo $htmlcode;
}else{
$accept_overwrite = 1;
if (file_exists($store_dir . $upload_file_name) && !$accept_overwrite) {
Echo   "�ļ����������޸��ļ������ϴ�";
exit;
}
if (!move_uploaded_file($upload_file,$store_dir.$upload_file_name)) {
exit;
}
@chmod($upload_file, 0755);
$uf = $_FILES['upload_file'];
$size = (($uf['size'])/1024);
$size=round($size, 2); 
echo  "<a href=up/".$uf['name'] . ">" .$uf['name'] ."</a>&nbsp;&nbsp;(��С:" .$size."KB)&nbsp;&nbsp;�ϴ��ɹ�\r\n<br>";
echo $htmlcode;
}
?>