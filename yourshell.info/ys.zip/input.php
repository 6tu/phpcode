<?php
$arguments = file_get_contents('php://input');
print_r($arguments);
?>