﻿<?php
$cookie_file = dirname(__FILE__) . "/cookie_" . md5(basename(__FILE__)) . ".txt"; 

//vlogin('http://tg.ncss.org.cn/stu/reg/login', 'idcard=642223198710221629&password=qq0000000');
//$res = vget('http://tg.ncss.org.cn/stu/app/arealistget?proCode=64&levelCode=2&subjectCode=2992111');

$res  = vget('http://tg.ncss.org.cn/stu/job/view?id=ff8080813f54e4d6013f565fff280fac');
$res .= vget('http://tg.ncss.org.cn/stu/job/view?id=ff8080813f54e4d6013f564370800d0c');
$res .= vget('http://tg.ncss.org.cn/stu/job/view?id=ff8080813f54e4d6013f56826e741300');
$res .= vget('http://tg.ncss.org.cn/stu/job/view?id=ff8080813f54e4d6013f5643ed260d14');
$res .= vget('http://tg.ncss.org.cn/stu/job/view?id=ff8080813f54e4d6013f563a7ee30bfd');
$res .= vget('http://tg.ncss.org.cn/stu/job/view?id=ff8080813f5bb061013f5f09f4171f9a');
$res .= vget('http://tg.ncss.org.cn/stu/job/view?id=ff8080813f54e4d6013f56bd635916ee');
$res .= vget('http://tg.ncss.org.cn/stu/job/view?id=ff8080813f54e4d6013f5691ac1e1421');
$res .= vget('http://tg.ncss.org.cn/stu/job/view?id=ff8080813f54e4d6013f56e9c68a187a');
$res .= vget('http://tg.ncss.org.cn/stu/job/view?id=ff8080813f54e4d6013f56749d7911cd');
$res .= vget('http://tg.ncss.org.cn/stu/job/view?id=ff8080813f54e4d6013f565c94200f55');
$res .= vget('http://tg.ncss.org.cn/stu/job/view?id=ff8080813f54e4d6013f5654f1db0eb7');
$res .= vget('http://tg.ncss.org.cn/stu/job/view?id=ff8080813f54e4d6013f56407b650ccb');
$res .= vget('http://tg.ncss.org.cn/stu/job/view?id=ff8080813f54e4d6013f5679504b123a');
$res .= vget('http://tg.ncss.org.cn/stu/job/view?id=ff8080813f54e4d6013f56817ecd12f4');
$res .= vget('http://tg.ncss.org.cn/stu/job/view?id=ff8080813f54e4d6013f567510f511d5');

$res = str_replace(array('<legend>岗位信息</legend>','<p><strong>岗位名称</strong></p>','<p><strong>需求人数|已报名人数</strong><small style="color:red">(每天凌晨更新)</small></p>','<p><strong>岗位要求</strong></p>','<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">','<p>详见','详见','简章','招聘','基本','条件','（一）','一','&nbsp',),array('','','','','','','','','','','','','','',),$res);
$res = trim($res); 
$res = str_replace(array("\r\n","\r","\n","\t",'</p><p>'),array('','','','','&nbsp;&nbsp;&nbsp;',),$res);
$res = str_replace(array('</fieldset>','<fieldset>','<p>','</p>','()',),array("\r\n--------------------------------\r\n",'','','','',),$res);
$res = str_replace(array('宁夏','初中政治教师'),array('','',),$res);
header("Content-type: text/html; charset=gb2312");
echo '<pre><b>宁夏初中政治教师</b>'."\r\n\r\n".$res.'</pre>';










function vlogin($url, $data){
     $curl = curl_init(); 
     curl_setopt($curl, CURLOPT_URL, $url); 
     curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0); 
     curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 1); 
     curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); 


     curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
//curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET'); 
     curl_setopt($curl, CURLOPT_AUTOREFERER, 1); 
     curl_setopt($curl, CURLOPT_POST, 1); 
     curl_setopt($curl, CURLOPT_POSTFIELDS, @$data);
     curl_setopt($curl, CURLOPT_COOKIEJAR, $GLOBALS['cookie_file']);
     curl_setopt($curl, CURLOPT_COOKIEFILE, $GLOBALS['cookie_file']);
     curl_setopt($curl, CURLOPT_TIMEOUT, 30); 
     curl_setopt($curl, CURLOPT_HEADER, 0);
     curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); 
     $tmpInfo = curl_exec($curl);
     if (curl_errno($curl)){
         echo 'Errno' . curl_error($curl);
         }
     curl_close($curl);
     return $tmpInfo;
    }
  function vget($url){ // 模拟获取内容函数      

    $curl = curl_init(); // 启动一个CURL会话      

    curl_setopt($curl, CURLOPT_URL, $url); // 要访问的地址                  

    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查      

    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 1); // 从证书中检查SSL加密算法是否存在      

    curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); // 模拟用户使用的浏览器      

    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1); // 使用自动跳转      

    curl_setopt($curl, CURLOPT_AUTOREFERER, 1); // 自动设置Referer      

    curl_setopt($curl, CURLOPT_HTTPGET, 1); // 发送一个常规的Post请求      

    curl_setopt($curl, CURLOPT_COOKIEFILE, $GLOBALS['cookie_file']); // 读取上面所储存的Cookie信息      

    curl_setopt($curl, CURLOPT_TIMEOUT, 30); // 设置超时限制防止死循环      

    curl_setopt($curl, CURLOPT_HEADER, 0); // 显示返回的Header区域内容      

    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); // 获取的信息以文件流的形式返回      

    $tmpInfo = curl_exec($curl); // 执行操作      

    if (curl_errno($curl)) {      

      echo 'Errno'.curl_error($curl);      

    }      

    curl_close($curl); // 关闭CURL会话      

    return $tmpInfo; // 返回数据      

  }  

?>

