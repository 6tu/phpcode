<?php
error_reporting(0);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL || $d=="/") {$d="";} else {if ($d=="/") {$d="";}}
if ($n==NULL) {$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);}
$go=$_GET['go']; $nm=trim($_POST['nm']);
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace('$','$$',$d); $n=str_replace('$','$$',$n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
if (($go==1)&&($nm<>NULL)) {
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true);
if (@ftp_size($ftp,$nm)==-1) {
@ftp_close($ftp);
header("Location: ftp.php?k=$k&d=$nm"); exit;
} else {
@ftp_close($ftp);
$name=preg_replace("~.*/([^/]*)~m","\\1",$nm);
$nm=preg_replace("~(.*)/[^/]*~m","\\1",$nm);
header("Location: file.php?k=$k&d=$nm&n=$name"); exit;
}
} else {
$title="连接错误...";
include("inc/in_head.php");
echo ("<p class=\"rmenu\" align=\"center\">
连接错误...<br/>");
echo "</p>";
include("inc/foot.php");
}
} else {
$num=@file_get_contents("allnumbd.dat"); $nar=NULL;
$num++; $nar=$num; if ($num>99999999) {$num=0;}
$f=@fopen("allnumbd.dat","w"); @fwrite($f,$num); @fclose($f);
$title="Go to";
include("inc/head.php");
echo ('<div class="gmenu"><a href="ftp.php?k='.$k.'&amp;d='.$rd.'">'.$d.'/</a><a href="file.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$n.'</a></div>');
echo "<div class=\"bmenu\" align=\"center\"><b>Goto:</b></div><div class=\"menu\"><p class=\"ads\">";
include("mobgold.php");
$input="<input name=\"nm\" type=\"text\" value=\"$d/$n\" maxlength=\"250\"/>";
echo ("</p><p><form action=\"go.php?k=$k&amp;d=$rd&amp;n=$rn&amp;go=1\" method=\"post\">$input
<input type=\"submit\" value=\"go\"/>
</form></p>");
include("inc/foot.php");
}
?>
