<?php
error_reporting(0);
$sid=trim($_GET['sid']);$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL || $d=="/") {$d="";} else {if ($d=="/") {$d="";}}
if ($n==NULL) {$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
$ac=trim($_GET['ac']); $nm=trim($_POST['nm']);
$chd=trim($_POST['chd']); $chf=trim($_POST['chf']);
if ($nm<>NULL) {
$repl=array("\\"=>"","/"=>"",":"=>"","*"=>"","?"=>"","\""=>"","<"=>"",">"=>"","|"=>"");
$nm=trim(strtr($nm,$repl));
include("repl.php"); $nm=u2t($nm);
if (($nm==".")||($nm=="..")) {$nm=".";}
}
if ($nm<>NULL) {
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true); $sz=ftp_size($ftp,"$d/$n");
if (($sz==-1)||($sz>1716800)) {header("Location:ftp.php?k=$k&d=$rd&amp;act=err"); exit;}
mkdir("data/$k",0777); ftp_get($ftp,"data/$k.zip","$d/$n",FTP_BINARY);
include_once('pclzip.php'); $zip=new PclZip("data/$k.zip");
if ($zip->extract(PCLZIP_OPT_PATH,"data/$k")==1) {
$st="解压失败,也许文件损坏了..!!";
} else {$st="";
if ($nm<>".") {ftp_mkdir($ftp,"$d/$nm"); $nm="/$nm/";} else {$nm="/";}
function scan($dir) {$arr=NULL; $lst=NULL;
$dh=opendir($dir); while (false!==($filename=readdir($dh))) {$lst[]=$filename;}
if ($lst<>NULL) {
for ($i=0;$i<count($lst);$i++) {
if (is_file($dir."/".$lst[$i])) {
$arr.="1:".$dir."/".$lst[$i]."\r\n";
} elseif ((is_dir($dir."/".$lst[$i]))&&($lst[$i]<>".")&&($lst[$i]<>"..")) {
$arr.="0:".$dir."/".$lst[$i]."\r\n"; $arr.=scan($dir."/".$lst[$i]);
}
} return $arr;
} else {return false;}
}
$str=scan("data/$k");
if ($str==false) {
$st="解压成功..!!";
} else {
$ar=explode("\r\n",$str); sort($ar);
for ($i=0;$i<count($ar);$i++) {
if ($ar[$i]<>NULL) {
list($p1,$p2)=split(":",$ar[$i]); $p1=trim($p1); $p2=trim($p2);
if ($p1==0) {
$name=str_replace("data/$k/","",$p2);
ftp_mkdir($ftp,"$d$nm".$name);
if ($chd<>NULL) {$cmd="chmod 0$chd $d$nm".$name; @ftp_site($ftp,$cmd);}
} else {
$name=str_replace("data/$k/","",$p2);
ftp_put($ftp,"$d$nm".$name,"data/$k/".$name,FTP_BINARY);
if ($chf<>NULL) {$cmd="chmod 0$chf $d$nm".$name; @ftp_site($ftp,$cmd);}
}
}
}
}
}
@ftp_close($ftp);
unlink("data/$k.zip"); include("rmdir.php"); rdir("data/$k");
if ($st==NULL) {$st.="解压成功..!!";}
$title="解压 ".$n." ".$st;
include("inc/head.php");

echo ("<div class=\"gmenu\" align=\"left\"><a href=\"ftp.php?k=$k&amp;d=$rd\">$d</a>/<a href=\"file.php?k=$k&amp;d=$rd&amp;n=$rn\">$n</a></div>");
echo ("<div calss=\"bmenu\"><b>$title</b></div>");
echo ("<div class=\"menu\">$st");
echo("<br/></div>");
include("inc/foot.php");
} else {
$title="Errot brot !!";

include("inc/in_head.php");echo ("<div class=\"rmenu\" align=\"left\"><br/><small>
没有连接..!!<br/></div>");
include("inc/foot.php");
}
} else {
$d=str_replace('$','$$',$d); $n=str_replace('$','$$',$n);
$num=@file_get_contents("allnumbd.dat"); $nar=NULL;
$num++; $nar=$num; if ($num>99999999) {$num=0;}
$f=@fopen("allnumbd.dat","w"); @fwrite($f,$num); @fclose($f);
if (file_exists("data/$k")) {include("rmdir.php"); rdir("data/$k");}
$dnm=preg_replace("~([^.]*).*~m","\\1",$n);
$title="解压文件 ".$n;

include("inc/head.php");echo ("<div class=\"gmenu\" align=\"left\"><a href=\"ftp.php?k=$k&amp;d=$rd\">$d</a>/<a href=\"file.php?k=$k&amp;d=$rd&amp;n=$rn\">$n</a></div><div class=\"bmenu\"><b>$title</b></div>");
$input="<div align=\"left\">Location:<br/><input name=\"nm\" type=\"text\" size=\"17\" value=\"$dnm\" maxlength=\"150\"/><br/><font color=\"red\">设置权限:</font><br/>文件权限: <input name=\"chf\" type=\"text\" value=\"666\" size=\"3\" maxlength=\"3\" format=\"*N\"/><br/>文件夹权限: <input name=\"chd\" type=\"text\" value=\"777\" size=\"3\" maxlength=\"3\" format=\"*N\"/><br/>
<br/></div>";
echo("<div class=\"menu\" align=\"left\"><form action=\"zip.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=$ac\" method=\"post\">$input<input type=\"submit\" value=\"Extract\"/></form><br/><br/></div>");
include("inc/foot.php");}
?>
