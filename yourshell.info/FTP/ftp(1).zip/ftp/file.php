<?php
error_reporting(0);
$sid=trim($_GET['sid']);
$k=trim($_GET['k']); include("key.php");
include_once("freedata.php"); freedata($k,0);
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL || $d=="/") {$d="";} elseif ($d=="/") {$d="";} if ($n==NULL) {$n="";}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);

$title="查看 ".$n;
include('inc/head.php');
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true);
$sz=@ftp_size($ftp,"$d/$n");
$tm=@ftp_mdtm($ftp,"$d/$n");
@ftp_close($ftp);

$fsz=$sz;
if ($sz<1024) {$sz="$sz bytes";}
elseif (($sz>=1024)&&($sz<1048576)) {$sz=strtr(round($sz/1024,2),".",",")." kb";}
elseif ($sz>=1048576) {$sz=strtr(round($sz/1024/1024,2),".",",")." mb";}

if ($tm<>NULL) {$tmv=gmdate("d-m-y [H:i:s]",$tm+$zn);} else {$tmv="-";}
$d=str_replace("\$","\$\$",$d); $n=str_replace("\$","\$\$",$n);
$rf=strtolower(preg_replace("~.*\.([^.]*)~m","\\1",$n));

echo("<div class=\"gmenu\"><a href=\"ftp.php?k=$k&amp;d=$rd\">$d</a>/<a href=\"file.php?k=$k&amp;d=$rd&amp;n=$n\">$n</a></div>
<div class=\"bmenu\"><b>$title</b></div>
<div class=\"menu\">文件名: $n<br/>
大小: $sz<br/>
最后编辑: ".$tmv."<hr/>");

if ((($rf=="zip")||($rf=="jar")||($rf=="tar")||($rf=="tgz")||($rf=="gz")||($rf=="gz2")||($rf=="bz")||($rf=="bz2")||($rf=="tbz")||($rf=="tbz2")||($rf=="tgz2"))&&($fsz<=11716800)&&($fsz>0)) {echo("<br/><a href=\"openarh.php?k=$k&amp;d=$rd&amp;n=$rn&amp;tp=$rf\">打开</a><br/>");
if (($rf=="zip")||($rf=="jar")) {echo("<a href=\"zip.php?k=$k&amp;d=$rd&amp;n=$rn&amp;act=ext\">解压</a><br/>");}
elseif (($rf=="tar")||($rf=="tgz")||($rf=="gz")||($rf=="gz2")||($rf=="bz")||($rf=="bz2")
||($rf=="tbz")||($rf=="tbz2")||($rf=="tgz2")) {echo("<a href=\"tgz.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=ext\">解压</a><br/>");}}
if (($rf<>"jpg")&&($rf<>"jpeg")&&($rf<>"jpe")&&($rf<>"png")&&($rf<>"gif")&&($rf<>"bmp")&&($rf<>"dll")&&($rf<>"wav")&&($rf<>"mid")&&($rf<>"midi")&&($rf<>"mp3")&&($rf<>"mmf")&&($rf<>"psd")&&($rf<>"doc")&&($rf<>"pdf")&&($rf<>"zip")&&($rf<>"rar")&&($rf<>"jar")&&($rf<>"3gp")&&($rf<>"avi")&&($rf<>"mp4")&&($rf<>"class")&&($rf<>"tgz")&&($rf<>"gz")&&($rf<>"bz")&&($rf<>"gz2")&&($rf<>"bz2")&&($rf<>"tbz")&&($rf<>"tbz2")&&($rf<>"tgz2")&&($rf<>"tar")&&($fsz<=1122880)) {
echo('
<br/><form align="left" action="edit.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ed=1&amp;msz=0&amp;kdr=1&amp;ikdr=2"/>
<input type="hidden" name="k" value="'.$k.'"><input type="hidden" name="d" value="'.$rd.'"><input type="hidden" name="n" value="'.$rn.'"><input type="hidden" name="ed" value="1"><input type="hidden" name="msz" value="0"><input type="hidden" name="kdr" value="5">
每页行数[1-50]: </small><input name="ln" type="text" value="10" maxlength="2" size="2" format="*N"/><br/>
每页字数[32-1024]: <input name="msz" type="text" value="0" maxlength="4" size="2" format="*N"/><br/><input type="submit" value="编辑 v1.0"/></form><br/><small>');

echo('
<form align="left" action="edit2.php?k=".$k."&d="$rd."&n=".$rn."&ed=1&msz=0&kdr=5"/>
<input type="hidden" name="k" value="'.$k.'"><input type="hidden" name="d" value="'.$rd.'"><input type="hidden" name="n" value="'.$rn.'"><input type="hidden" name="ed" value="1"><input type="hidden" name="msz" value="0"><input type="hidden" name="kdr" value="5">
每页行数[1-50]: </small><input name="ln" type="text" value="10" maxlength="2" size="2" format="*N"/><br/>
每页字数[32-1024]: <input name="msz" type="text" value="0" maxlength="4" size="2" format="*N"/><br/><input type="submit" value="编辑 v2.0"/></form><br/><small>');
}
if (($rf=="txt")&&($fsz<=204800)) {echo('<br/><a href="book.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">Create book</a><br/>');}
if (($rf=="sql")&&($fsz<=204800)) {echo('<br/><a href="inst.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">Create sql setup wizard</a><br/>');}
echo("</div>");
echo('<div class="phdr"><h3>添加到剪切板:</h3></div><p class="menu">[<a href="actn.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'&amp;ac=copy&amp;t=f&amp;go=1">复制</a>][<a href="actn.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'&amp;ac=cut&amp;t=f&amp;go=1">剪切</a>]');
if (($rf<>"zip")&&($rf<>"jar")&&($rf<>"rar")&&($rf<>"tgz")&&($rf<>"gz")&&($rf<>"bz")&&($rf<>"gz2")&&($rf<>"bz2")&&($rf<>"tbz")&&($rf<>"tbz2")&&($rf<>"tgz2")&&($rf<>"tar")&&($fsz<=3145728)) {echo("[<a href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=arh&amp;t=f&amp;go=1\">ZIP</a>][<a href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=at&amp;t=f\">TAR</a>]<br/>");}
else {echo("</p>");}
if (($rf<>"zip")&&($rf<>"jar")&&($rf<>"rar")&&($rf<>"tgz")&&($rf<>"gz")&&($rf<>"bz")&&($rf<>"gz2")&&($rf<>"bz2")&&($rf<>"tbz")&&($rf<>"tbz2")&&($rf<>"tgz2")&&($rf<>"tar")&&($fsz<=3145728)) {echo("<div class=\"phdr\"><h3>添加到压缩文档:</h3></div><p class=\"menu\">[<a href=\"ecopy.php?k=$k&amp;d=$rd&amp;n=$rn&amp;tp=a\">ZIP</a>][<a href=\"ecopy.php?k=$k&amp;d=$rd&amp;n=$rn&amp;tp=t\">TAR</a>]</p>");}
echo("<div class=\"phdr\"><h3>操作:</h3></div><p class=\"menu\">");
echo(" <a href=\"ecopy.php?k=$k&amp;d=$rd&amp;n=$rn&amp;tp=c\">复制</a> &nbsp;
<a href=\"ecopy.php?k=$k&amp;d=$rd&amp;n=$rn&amp;tp=m\">移动</a> &nbsp;");
echo("<a href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=ren&amp;t=f\">重命名</a> &nbsp;
<a href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=del&amp;t=f\">删除</a> &nbsp;");
echo('<a href="download.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">下载</a> &nbsp;
</p>');
include('inc/foot.php');
} else {
echo("<p class=\"rmenu\" align='center'><small>
错误..!!<br/>
</small></p>
");
include('inc/foot.php');
}
?>
