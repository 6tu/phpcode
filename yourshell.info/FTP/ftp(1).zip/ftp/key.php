<?php
include_once("cnfg.php");
if ($fl=@file("inc/barakatak.dat")) {$cnt=count($fl); $time=time();
for ($i=0;$i<$cnt;$i++) {
list($p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9)=split('\^',trim($fl[$i]));
$sr=$p2; $lg=$p3; $ps=$p4; $skl=$p5; $p6=NULL; $shs=$p7; $ib=$p8; $tema=$p9;
if ($p1==$k) {
$str=""; $fl[$i]="$p1^$sr^$lg^$ps^$skl^$time^$shs^$ib^$tema\r\n";
for ($j=0;$j<count($fl);$j++) {$str.=$fl[$j];}
$f=@fopen("inc/barakatak.dat","w"); @fwrite($f,$str); @fclose($f);
break;
} else {
if ($i==$cnt-1) {header("Location: index.php"); exit;}
}
}
} else {header("Location: index.php"); exit;}
?>
