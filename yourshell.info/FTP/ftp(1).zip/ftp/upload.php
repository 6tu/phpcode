<?php
error_reporting(0);
$sid=trim($_GET['sid']);
$k=trim($_GET['k']);
include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL || $d=="/") {$d="";} else {if ($d=="/") {$d="";}}
if ($n==NULL) {$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);}
if ($n==NULL) {$n=preg_replace("~.*/([^/]*)~m","\\1",$d); $d=preg_replace("~(.*)/[^/]*~m","\\1",$d);}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);

$cnt=count($_FILES['nm']['name']);

$title="上传文件";
include("inc/head.php");
echo("<div class=\"gmenu\" align=\"left\"><a href=\"ftp.php?k=$k&amp;d=$rd\">$d/</a><a href=\"ftp.php?k=$k&amp;d=$rd&amp;n=$rn\">$n</a></div>");
echo("<div class=\"bmenu\"><b>选择文件最大 7 MB</b></div>");
if ($cnt<>NULL) {$st="";
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true);
for ($i=0;$i<$cnt;$i++) {
if (($_FILES['nm']['name'][$i]<>NULL)&&($_FILES['nm']['size'][$i]<=7340032)&&($_FILES['nm']['size'][$i]>0)) {
$name=preg_replace("~.*/([^/]*)~m","\\1",$_FILES['nm']['name'][$i]);
if (ftp_put($ftp,"$d/$n/$name",$_FILES['nm']['tmp_name'][$i],FTP_BINARY)) {
$sz=$_FILES['nm']['size'][$i];
$st.="<div class=\"gmenu\">文件 <b><font color=\"red\">".htmlspecialchars($name)."</font></b>($sz b)上传成功</div>";
} else {$st.="<div class=\"rmenu\">文件<font color=\"red\"> \"".htmlspecialchars($name)."\" </font>上传失败..!!</div>";}
}
}
@ftp_close($ftp);
if ($st==NULL) {$st="<div class=\"rmenu\">没有上传..!!</div>";}
echo("$st");
} else {
echo("<div class=\"rmenu\"><font color=\"red\">连接失败..!!</font></div>");
include("inc/foot.php"); exit;
}
}
$memex="<input name=\"nm[]\" type=\"file\" size=\"17\"><br>";
echo("<div class=\"menu\"><form action=\"upload.php?k=$k&amp;d=$rd&amp;n=$rn\" enctype=\"multipart/form-data\" method=\"post\">
$memex $memex $memex $memex $memex
<input type=\"submit\" value=\"上传\">
</form><div class=\"ads\"><br/>");
include("buzz.php");
echo("<br/></div></div>");
include("inc/foot.php");
?>
