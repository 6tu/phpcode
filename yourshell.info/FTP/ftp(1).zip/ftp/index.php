<?php
error_reporting(0);
$act=trim($_GET['act']);
$judul='WapFTP';
include('inc/top.php');
if(empty($_COOKIE['QualigoIframeNavbar'])) {
setcookie('QualigoIframeNavbar','disabled',time()+(24*3600*30));
}
if($act=="Login") { $msg="<div class=\"rmenu\" align=\"center\">在此登录</div>";
} elseif($act=="err") {$msg="<div class=\"rmenu\" align=\"center\">连接失败，请重试 !</div>"; } elseif($act=="update") {$msg="<div class=\"rmenu\" align=\"center\">请更新数据...!</div>"; } echo $msg;
echo '<form action="ftp.php" method="get">
<div style="text-align:center;">
<div class="menu"><font color="silver">服务器:</font><br/><input name="server" /></div><div class="footer">
<font color="silver">用户名:</font><br/><input name="user"/></div>

<div class="menu">
<font color="silver">密码:</font><br/><input type="password" name="pass"/></div>
<div class="footer">
<font color="silver">默认目录:</font><br/><input name="d" value="/"/></div>
<div class="menu"><input type="checkbox" name="size"value="1" checked="checked"/><font color="silver">显示文件大小</font></div>

<div class="footer"> <input type="checkbox" name="icons" value="1" checked="checked"/><font color="silver">显示文件图标</font></div>
<div class="menu">
<font color="silver">每页显示</font><br/>
<select name="items"><option value="20" selected="selected">20</option><option value="10">10</option><option value="30">30</option><option value="40">40</option><option value="50">50</option><option value="60">60</option><option value="70">70</option><option value="80">80</option><option value="90">90</option><option value="100">100</option>
</select></div>
<div class="footer">
<font color="silver">主题皮肤</font><br/><select name="tema"><option value="1" selected="selected">默认</option><option value="2">brown</option><option value="3">classic</option><option value="4">oz</option><option value="5">zlp</option>
</select></div>
<div class="jembut">
<input type="submit" style="font-weight:bold;color:#DDD;" name="go" value="LOGIN"/></form></div></div>';
?>
