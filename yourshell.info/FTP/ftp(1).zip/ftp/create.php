<?php
error_reporting(0);$sid=trim($_GET['sid']);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL || $d=="/") {$d="";} else {if ($d=="/") {$d="";}}
if ($n==NULL) {$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
/*$d=str_replace('$','$',$d); $n=str_replace('$','$',$n);*/
$tp=trim($_GET['tp']); $nm=trim($_POST['nm']);
$ch=trim($_POST['ch']); if ($nm<>NULL) {
$repl=array("\\"=>"","/"=>"",":"=>"","*"=>"","?"=>"","\""=>"","<"=>"",">"=>"",
"|"=>"","`"=>""," "=>"_");
$nm=trim(strtr($nm,$repl));include("repl.php"); $nm=u2t($nm);
if (($nm==".")||($nm=="..")) {$nm="";}
}
if ((($tp=="f")||($tp=="d"))&&($nm<>NULL)) {
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true); $fnm="";
$d=str_replace('$','$',$d); $n=str_replace('$','$',$n);
if ($tp=="f") {
$newf="new.php";

if (strlen($ch)<>3) {$ch="644";}
@ftp_put($ftp,"$d/$n/$nm",$newf,FTP_BINARY);
$cmd="chmod 0$ch $d/$n/$nm"; @ftp_site($ftp,$cmd);
@ftp_close($ftp);
header("Location:ftp.php?k=$k&d=$rd&n=$rn&act=pm"); exit;
} elseif ($tp=="d") {
if (strlen($ch)<>3) {$ch="755";}
@ftp_mkdir($ftp,"$d/$n/$nm");
$cmd="chmod 0$ch $d/$n/$nm"; @ftp_site($ftp,$cmd);
@ftp_close($ftp);
header("Location:ftp.php?k=$k&d=$rd&n=$rn&act=pm"); exit;
} else {header("Location:ftp.php?k=$k&d=$rd&n=$rn"); exit;}
} else {
$title="连接错误..";
include("inc/head.php");
echo("<div class=\"rmenu\"><p align=\"center\">
连接错误</p></div>
");
include("inc/foot.php");
}
} elseif ($tp=="f") {
$num=@file_get_contents("allnumbd.dat");
$num  ; if ($num>9999999) {$num=0;}
$f=@fopen("allnumbd.dat","w"); @fwrite($f,$num); @fclose($f);
$title="创建文件";
include("inc/head.php");
echo("<div class=\"gmenu\" align=\"left\"><a href=\"ftp.php?k=$k&amp;d=$rd&amp;n=$rn\">$d/</a><a href=\"ftp.php?k=$k&amp;d=$rd&amp;n=$rn\">$n/</a></div>
<div class=\"bmenu\"><b>$title</b></div><div class=\"menu\"><br/>
<form action=\"create.php?k=$k&amp;d=$rd&amp;n=$rn&amp;tp=f\" method=\"post\">
文件名:<input name=\"nm\" type=\"text\" value=\"new.php\" maxlength=\"150\"/><br/>
权限:
<input name=\"ch\" type=\"text\" value=\"644\" size=\"3\" maxlength=\"3\" format=\"*N\"/><br /><input type=\"submit\" value=\"创建\"/>
</form></div>");
include("inc/foot.php");
} elseif ($tp=="d") {
$num=@file_get_contents("allnumbd.dat");
$num  ; if ($num>9999999) {$num=0;}$f=@fopen("allnumbd.dat","w"); @fwrite($f,$num); @fclose($f);
$title="创建文件夹";
include("inc/head.php");
echo("<div class=\"gmenu\" align=\"left\">
<a href=\"ftp.php?k=$k&amp;d=$rd\">$d/</a><a href=\"ftp.php?k=$k&amp;d=$rd&amp;n=$rn\">$n</a></div>");
$inp="文件夹名: <input name=\"nm\" type=\"text\" value=\"new\" maxlength=\"150\"/><br/>";
$inpc="权限: <input name=\"ch\" type=\"text\" value=\"755\" size=\"3\" maxlength=\"3\" format=\"*N\"/>";
echo("<div class=\"bmenu\"><b>$title</b></div>");
echo("<div class=\"menu\"><br/><form action=\"create.php?k=$k&amp;d=$rd&amp;n=$rn&amp;tp=d\" method=\"post\">$inp$inpc<br /><input type=\"submit\" value=\"创建\"/>
</form>");
echo("</div>
");
include("inc/foot.php");
} else {
include("inc/head.php");
echo '连接错误';
include("inc/foot.php");
}
?>
