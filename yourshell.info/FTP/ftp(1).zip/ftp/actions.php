<?php
error_reporting(0);
$sid=trim($_GET['sid']);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL || $d=="/") {$d="";}if ($n==NULL) {$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
$title="常用操作";
include('inc/head.php');
echo ('<div class="gmenu"><a href="ftp.php?k='.$k.'&amp;d='.$rd.'">'.$d.'</a>/<a href="ftp.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$n.'</a></div>');

$memex=$_POST['f'];
if(empty($memex)) {
header("Location: ftp.php?k=$k&d=$rd&n=$rn&act=err");
}
elseif(!$_POST['ss']){
$pp=$_POST['f'];
$nrs=0;
foreach($pp as $ff) {
$nrs++; }
print "<div class=\"phdr\"><b>共选择了 $nrs 个文件</b></div><div class=\"menu\"><form action='?k=$k&amp;d=$rd&amp;n=$rn' method='post'>";
$pp=$_POST['f'];
foreach($pp as $ff){
print "<input type='hidden' name='f[]' value='$ff'><font color='red'> $ff </font><br/>";
}
if(isset($_POST['ch'])) { print "<br/><input type='hidden' name='ch' value='chm' />
更改权限..<br/>权限: <input type='text' name='cmds' value='666' size='3' maxlength='3' format='*N' /><br/>";
}
elseif(isset($_POST['del'])) {
print "<br/><input type='hidden' name='del' value='ddd'><font color='red'>你确定要删除选定的文件吗..??!!</font><br/>";
}
elseif(isset($_POST['m'])) { print "<br/><input type='hidden' name='m' value='mmm'><b>移动到:</b><br/>";
print "<input name='mv' type='text' size='17' value='$d/$n' maxlength='250'/><br/>
权限: <input name='cmds'
type='text' value='666' size='3' maxlength='3' format='*N'/><br/>";
}
elseif(isset($_POST['c'])) { print "<br/><input type='hidden' name='c' value='ccc'><b>复制到:</b><br/>";
print "<input name='cp' type='text' size='17' value='$d/$n' maxlength='250' /><br/>
权限: <input name='cmds'
type='text' value='644' size='3' maxlength='3' format='*N' /><br/>";
}
elseif(isset($_POST['arh'])) { print "<br/><input type='hidden' name='arh' value='aaa'><b>创建文档在:</b><br/>";
print "<input name='arch' type='text' size='17' value='$d/$n/selected.zip' maxlength='250'/><br/>
权限: <input name='cmds' type='text' value='666' size='3' maxlength='3' format='*N'/><br/>";
}

print "<br/><input type='submit' value='执行' name='ss'></form><br/>";
print "<a href='ftp.php?k=$k&amp;d=$rd&amp;n=$rn'>返回</a><br/></div>";
include('inc/foot.php');
} else {
if (($ftp=ftp_connect($sr))&&(ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true);
if(isset($_POST['ch'])) {
$cmds=$_POST['cmds'];
foreach ($_POST['f'] as $fly) { $cmd="chmod 0$cmds $d/$n/$fly"; @ ftp_site($ftp,$cmd);
header("Location: ftp.php?k=$k&d=$rd&n=$rn&act=chmod");
}
}
elseif(isset($_POST['del'])) {
foreach ($_POST['f'] as $fly)
{ftp_delete($ftp,"$d/$n/$fly");
header("Location: ftp.php?k=$k&d=$rd&n=$rn&act=delete");
}
}
elseif(isset($_POST['m'])) {
$mv=$_POST['mv']; $cmds=$_POST['cmds'];
foreach ($_POST['f'] as $fly) {
@ftp_rename($ftp,"$d/$n/$fly","$mv/$fly");
$cmd="chmod 0$cmds $mv/$fly"; @ftp_site($ftp,$cmd);
header("Location: ftp.php?k=$k&d=$rd&n=$rn&act=move");
}
}
elseif(isset($_POST['c'])) {
$cp=$_POST['cp']; $cmds=$_POST['cmds'];
foreach ($_POST['f'] as $fly) {
@ftp_get($ftp,"data/$k.bk","$d/$n/$fly",FTP_BINARY);
@ftp_put($ftp,"$cp/$fly","data/$k.bk",FTP_BINARY);
@unlink("data/$k.bk");
$cmd="chmod 0$cmds $cp/$fly";
@ftp_site($ftp,$cmd);
header("Location: ftp.php?k=$k&d=$rd&n=$rn&act=copy");
}
}
elseif((isset($_POST['arh']))&&(@ftp_size($ftp,"$d/$n")<=3145728)) {
$arch=$_POST['arch'];
$cmds=$_POST['cmds'];
foreach ($_POST['f'] as $fly)
{
@mkdir("data/$k",0777);
@ftp_get($ftp,"data/$k/$fly","$d/$n/$fly",FTP_BINARY);
include_once('pclzip.php'); $zip=new PclZip("data/$k.zip");
if($zip->create("data/$k",PCLZIP_OPT_REMOVE_PATH,"data/$k",PCLZIP_OPT_COMMENT,$cmm)<>0) {
@ftp_put($ftp,"$arch","data/$k.zip",FTP_BINARY);
}
@unlink("data/$k.zip");
$cmd="chmod 0$cmds $arch";
@ftp_site($ftp,$cmd);
header("Location: ftp.php?k=$k&d=$rd&n=$rn&act=zip");
}
} else {
include_once("tar.php");
$tar=new Archive_Tar("data/$k.tar");
if ($tar->createModify("data/$k","","data/$k")) {
@ftp_put($ftp,"$nm","data/$k.tar",FTP_BINARY);
} @unlink("data/$k.tar");
}
include_once("rmdir.php"); rdir("data/$k");
} else {
print "<p>连接错误..!!</p>";}
include('inc/foot.php');
}
?>
