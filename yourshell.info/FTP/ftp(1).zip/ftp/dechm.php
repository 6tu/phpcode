<?php
error_reporting(0);
function dechm($schm) {
 $n1=0; $n2=0; $n3=0; $ar=array(4,2,1);
 for ($chi=1;$chi<=3;$chi++) {if ($schm[$chi]<>"-") {$n1=$n1+$ar[$chi-1];}}
 for ($chi=4;$chi<=6;$chi++) {if ($schm[$chi]<>"-") {$n2=$n2+$ar[$chi-4];}}
 for ($chi=7;$chi<=9;$chi++) {if ($schm[$chi]<>"-") {$n3=$n3+$ar[$chi-7];}}
 return $n1.$n2.$n3;
}
?>