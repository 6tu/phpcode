<?php
error_reporting(0);
$k=trim($_GET['k']); include("key.php"); include_once("cnfg.php");
$str="";
if ($fl=@file("inc/barakatak.dat")) {
for ($i=0;$i<count($fl);$i++) {
list($p1,$p2,$p3,$p4,$p5,$p6,$p7)=split('\^',trim($fl[$i]));
if ($p1<>$k) {$str.=$fl[$i];}
else {
include_once("freedata.php"); freedata($p1);
}
}
}
$f=@fopen("inc/barakatak.dat","w"); @fwrite($f,$str); @fclose($f);
$sid=trim($_GET['sid']);
include("inc/top.php");
echo '<div class="bmenu">Ok! 您已退出，记录已清除！</div></div></div>';
exit;
?>
