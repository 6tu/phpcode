<?php
function u2t($text) {
$u2t=array(
"k"=>"k",
"Т"=>"T"
);
return strtr($text,$u2t);
}
?>