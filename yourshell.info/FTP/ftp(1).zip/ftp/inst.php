<?php
error_reporting(0);
$sid=$_GET["sid"];
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL || $d=="/") {$d="";} if ($n==NULL) {$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d); $n=str_replace(".|htaccess",".htaccess",$n);
$nm=trim($_POST['nm']); $csr=trim($_POST['csr']); $cus=trim($_POST['cus']);
$cps=trim($_POST['cps']); $cbd=trim($_POST['cbd']); $dp=trim($_POST['dp']);
$cr=trim($_POST['cr']); $in=trim($_POST['in']);
if ($nm<>NULL) {
$repl=array("\\"=>"","/"=>"",":"=>"","*"=>"","?"=>"","\""=>"","<"=>"",">"=>"",
"|"=>"","`"=>""," "=>"_");
$nm=trim(strtr($nm,$repl));
include("repl.php"); $nm=u2t($nm);
if (($nm==".")||($nm=="..")) {$nm="";}
}
if (($nm==NULL)||(($dp==NULL)&&($cr==NULL)&&($in==NULL))) {
$num=@file_get_contents("allnumbd.dat");
$num++; if ($num>9999999) {$num=0;}
$f=@fopen("allnumbd.dat","w"); @fwrite($f,$num); @fclose($f);
/*$d=str_replace('$','$$',$d); $n=str_replace('$','$$',$n);*/
$title="Create database";
include("inc/head.php");
echo ("<div class=\"gmenu\" align=\"left\"><a href=\"ftp.php?k=$k&amp;d=$rd\">$d</a>/<a href=\"file.php?k=$k&amp;d=$rd&amp;n=$rn\">$n</a></div><div class=\"bmenu\"><b>$title</b></div>");
$input="File: <input name=\"nm\" type=\"text\" value=\"install.php\" maxlength=\"150\"/><br/>Server:<input name=\"csr\" type=\"text\" value=\"localhost\" maxlength=\"150\"/><br/>Username: <input name=\"cus\" type=\"text\" value=\"\" maxlength=\"150\"/><br/><small>
Password: </small><input name=\"cps\" type=\"text\" value=\"\" maxlength=\"150\"/><br/>Database Name: <input name=\"cbd\" type=\"text\" value=\"\" maxlength=\"150\"/><br/><input type=\"checkbox\" name=\"dp\" value=\"1\" checked=\"checked\"/>DROP <input type=\"checkbox\" name=\"cr\" checked=\"checked\" value=\"1\">CREATE <input type=\"checkbox\" name=\"in\" checked=\"checked\" value=\"1\">INSERT";
echo("<div><form action=\"inst.php?k=$k&amp;d=$rd&amp;n=$rn\" method=\"post\">$input<input type=\"submit\" value=\"Create\"/></form></div>");
include("inc/foot.php");
} else {
if (($ftp=ftp_connect($sr))&&(ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true); $sz=@ftp_size($ftp,"$d/$n");
if (($sz<1)||($sz>204800)) {header("Location: ftp.php?k=$k&d=$rd"); exit;}
@ftp_get($ftp,"data/$k.txt","$d/$n",FTP_BINARY);
$drop=1; $create=1; $insert=1;
if ($dp<>1) {$drop=0;} if ($cr<>1) {$create=0;} if ($in<>1) {$insert=0;}
$sql=file_get_contents("data/$k.txt");
$sql=str_replace("\r\n","\n",$sql); $sql=str_replace("\n","\r",$sql);
$sql=preg_replace("~(--|##)[^\r]*\r~","\r",$sql);
$sql=preg_replace("~\r\s*\r~","\r",$sql);
$fd='';
if ($drop==1) {$fd.='DROP';}
if ($create==1) {if ($drop==1) {$fd.='|';} $fd.='CREATE';}
if ($insert==1) {if (($create==1)||($drop==1)) {$fd.='|';} $fd.='INSERT';}
preg_match_all("~(".$fd.").*(\r[)][^()]*)?;~iU",$sql,$ar);
$cnt=count($ar[0]); if ($cnt>999) {$cnt=999;}
$f=@fopen("data/$k.txt","w");
@fwrite($f,'<?php'."\r\n\r\n".'header("Content-Type: text/vnd.wap.wml; charset=utf-8");'."\r\n".'echo("<?xml version=\"1.0\" encoding=\"utf-8\"?><!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.2//EN\" \"http://www.wapforum.org/DTD/wml_1.2.xml\"><wml><head><meta forua=\"true\" http-equiv=\"Cache-Control\" content=\"no-cache,no-store,must-revalidate\"/></head><card title=\"Install\"><p><small>\r\n");'."\r\n".'$ms=mysql_connect("'.$csr.'","'.$cus.'","'.$cps.'") or exit("Connection Failed");'."\r\n".'mysql_select_db("'.$cbd.'") or exit("Database Not Select");'."\r\n".'echo("--BEGIN--<br/><br/>\r\n");'."\r\n");
for ($i=0;$i<$cnt;$i++) {
if (strtolower(trim($ar[1][$i]))=='drop') {
@fwrite($f,'$query="'.trim(str_replace('"','\"',str_replace("\r","",$ar[0][$i]))).'";'."\r\n".'mysql_query($query);'."\r\n");
} elseif (strtolower(trim($ar[1][$i]))=='create') {
@fwrite($f,'$query="'.trim(str_replace('"','\"',str_replace("\r","",$ar[0][$i]))).'";'."\r\n".'$r=mysql_query($query);'."\r\n".'if (!$r) {echo("Error!! CREATE TABLE \"'.preg_replace("~\s*CREATE TABLE[^(;`]*[`]?([^\s(`]*)[`]?\s*[(].*~i","\\1",str_replace("\r","",$ar[0][$i]),1).'\"<br/>\r\n");}'."\r\n");
} elseif (strtolower(trim($ar[1][$i]))=='insert') {
@fwrite($f,'$query="'.trim(str_replace('"','\"',str_replace("\r","",$ar[0][$i]))).'";'."\r\n".'mysql_query($query);'."\r\n");
}
}
@fwrite($f,'mysql_close($ms);'."\r\n".'echo("<br/>--AND--\r\n</small></p></card></wml>");'."\r\n".'?>');
@fclose($f);
@ftp_put($ftp,"$d/$nm","data/$k.txt",FTP_BINARY);
@ftp_close($ftp); @unlink("data/$k.txt");
header("Location:ftp.php?k=$k&d=$rd&amp;act=pm"); exit;
} else {
echo("<p class=\"rmenu\" align=\"center\">no connection</p>");
include("inc/foot.php");
}
}
?>