<?php
error_reporting(0);
$sid=$_GET["sid"];
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL || $d=="/") {$d="";} else {if ($d=="/") {$d="";}}
if ($n==NULL) {$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);}
$rd=rawurlencode($d); $rn=rawurlencode($n);
/*$d=str_replace('$','$$',$d); $n=str_replace('$','$$',$n);*/
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
if (!$fls=@file("data/$k.act")) {header("Location:list.php?k=$k&d=$rd&n=$rn"); exit;}
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true);
$cnt=count($fls); $acn=0; $arh=NULL; $arhs=0; $arh2=NULL; $arhs2=0;
function scand($conn,$dir) {$arr=NULL; ftp_chdir($conn,$dir);
if ($lst=ftp_nlist($conn,".")) {
$ctns=count($lst); if ($ctns>700) {$ctns=700;}
for ($j=0;$j<$ctns;$j++) {$fl=$dir."/".$lst[$j];
if ((ftp_size($conn,$fl)===-1)&&(preg_replace("~.*/([^/]*)~m","\\1",$fl)<>".")&&
(preg_replace("~.*/([^/]*)~m","\\1",$fl)<>"..")) {
$arr.="0:".$fl."\r\n"; $arr.=scand($conn,$fl);
} else {$arr.="1:".$fl."\r\n";}
} return $arr;
} else {return false;}
}
for ($i=0;$i<$cnt;$i++) {
list($p1,$p2,$p3)=split('[|]',$fls[$i]);
$p1=trim($p1); $p2=trim($p2); $p3=trim($p3);
if ($p1[strlen($p1)-1]=="/") {$p1[strlen($p1)-1]="";}
if ($p3=="cut") {$p1=str_replace("\$\$","\$",$p1);
$name=preg_replace("~.*/([^/]*)~m","\\1",$p1);
if (ftp_rename($ftp,$p1,"$d/$n/$name")) {$acn++;}
}
if (($p3=="copy")&&($p2=="f")) {$p1=str_replace("\$\$","\$",$p1);
$name=preg_replace("~.*/([^/]*)~m","\\1",$p1);
ftp_get($ftp,"data/$k.bk","$p1",FTP_BINARY);
if (ftp_put($ftp,"$d/$n/$name","data/$k.bk",FTP_BINARY)) {$acn++;}
unlink("data/$k.bk");
}
if (($p3=="arh")&&($p2=="f")) {
if (($arhs<=3145728)&&(count($arh)<=50)) {
$arhs=$arhs+ftp_size($ftp,$p1);
if ($arhs<=3145728) {$p1=str_replace("\$\$","\$",$p1); $arh[]=$p1; $acn++;}
}
}
if ((($p3=="at1")||($p3=="at2")||($p3=="at3")||($p3=="at4")||($p3=="at5"))&&($p2=="f")) {
if (($arhs2<=3145728)&&(count($arh2[$p3])<=50)) {
$arhs2=$arhs2+ftp_size($ftp,$p1);
if ($arhs2<=3145728) {$p1=str_replace("\$\$","\$",$p1); $arh2[$p3][]=$p1; $acn++;}
}
}
if (($p3=="copy")&&($p2=="d")) {$p1=str_replace("\$\$","\$",$p1);
$str=scand($ftp,$p1);
if ($str<>false) {
$ar=explode("\r\n",$str); sort($ar);
$nm=preg_replace("~.*/([^/]*)~m","\\1",$p1);
$dnm=preg_replace("~(.*)/[^/]*~m","\\1",$p1);
if ($dnm<>NULL) {$dnm.="/";}
@ftp_mkdir($ftp,"$d/$n/".$nm);
for ($j=0;$j<count($ar);$j++) {
if ($ar[$j]<>NULL) {
list($p1,$p2)=split(":",$ar[$j]); $p1=trim($p1); $p2=trim($p2);
if ($p1==0) {
$name=preg_replace("~^".$dnm."~im","",$p2);
@ftp_mkdir($ftp,"$d/$n/".$name);
} else {
$name=preg_replace("~^".$dnm."~im","",$p2);
@ftp_get($ftp,"data/$k.bk","$p2",FTP_BINARY);
@ftp_put($ftp,"$d/$n/$name","data/$k.bk",FTP_BINARY);
@unlink("data/$k.bk");
}
}
} $acn++;
}
}
}
if ($arh<>NULL) {
@mkdir("data/$k",0777); $str="";
for ($i=0;$i<count($arh);$i++) {
$name=preg_replace("~.*/([^/]*)~m","\\1",$arh[$i]);
@ftp_get($ftp,"data/$k/$name",$arh[$i],FTP_BINARY);
if ($i<>0) {$str.=",";} $str.="data/$k/$name";
}
include('pclzip.php'); $zip=new PclZip("data/$k.zip");
if ($zip->create($str,PCLZIP_OPT_REMOVE_ALL_PATH,PCLZIP_OPT_COMMENT,$cmm)<>0) {
@ftp_put($ftp,"$d/$n/new.zip","data/$k.zip",FTP_BINARY);
}
@unlink("data/$k.zip");
for ($i=0;$i<count($arh);$i++) {
$name=preg_replace("~.*/([^/]*)~m","\\1",$arh[$i]);
@unlink("data/$k/$name");
}
@rmdir("data/$k");
}
if ($arh2<>NULL) {
include("tar.php");
if ($arh2["at1"]<>NULL) {@mkdir("data/$k",0777);
for ($i=0;$i<count($arh2["at1"]);$i++) {
$name=preg_replace("~.*/([^/]*)~m","\\1",$arh2["at1"][$i]);
@ftp_get($ftp,"data/$k/$name",$arh2["at1"][$i],FTP_BINARY);
}
$tar=new Archive_Tar("data/$k.tar");
if ($tar->createModify("data/$k","","data/$k")) {
@ftp_put($ftp,"$d/$n/new.tar","data/$k.tar",FTP_BINARY);
} @unlink("data/$k.tar");
for ($i=0;$i<count($arh2["at1"]);$i++) {
$name=preg_replace("~.*/([^/]*)~m","\\1",$arh2["at1"][$i]);
@unlink("data/$k/$name");
}
@rmdir("data/$k");
}
if ($arh2["at2"]<>NULL) {@mkdir("data/$k",0777);
for ($i=0;$i<count($arh2["at2"]);$i++) {
$name=preg_replace("~.*/([^/]*)~m","\\1",$arh2["at2"][$i]);
@ftp_get($ftp,"data/$k/$name",$arh2["at2"][$i],FTP_BINARY);
}
$tar=new Archive_Tar("data/$k.tgz");
if ($tar->createModify("data/$k","","data/$k")) {
@ftp_put($ftp,"$d/$n/new.tgz","data/$k.tgz",FTP_BINARY);
} @unlink("data/$k.tgz");
for ($i=0;$i<count($arh2["at2"]);$i++) {
$name=preg_replace("~.*/([^/]*)~m","\\1",$arh2["at2"][$i]);
@unlink("data/$k/$name");
}
@rmdir("data/$k");
}
if ($arh2["at3"]<>NULL) {@mkdir("data/$k",0777);
for ($i=0;$i<count($arh2["at3"]);$i++) {
$name=preg_replace("~.*/([^/]*)~m","\\1",$arh2["at3"][$i]);
@ftp_get($ftp,"data/$k/$name",$arh2["at3"][$i],FTP_BINARY);
}
$tar=new Archive_Tar("data/$k.tgz2");
if ($tar->createModify("data/$k","","data/$k")) {
@ftp_put($ftp,"$d/$n/new.tgz2","data/$k.tgz2",FTP_BINARY);
} @unlink("data/$k.tgz2");
for ($i=0;$i<count($arh2["at3"]);$i++) {
$name=preg_replace("~.*/([^/]*)~m","\\1",$arh2["at3"][$i]);
@unlink("data/$k/$name");
}
@rmdir("data/$k");
}
if ($arh2["at4"]<>NULL) {@mkdir("data/$k",0777);
for ($i=0;$i<count($arh2["at4"]);$i++) {
$name=preg_replace("~.*/([^/]*)~m","\\1",$arh2["at4"][$i]);
@ftp_get($ftp,"data/$k/$name",$arh2["at4"][$i],FTP_BINARY);
}
$tar=new Archive_Tar("data/$k.tbz");
if ($tar->createModify("data/$k","","data/$k")) {
@ftp_put($ftp,"$d/$n/new.tbz","data/$k.tbz",FTP_BINARY);
} @unlink("data/$k.tbz");
for ($i=0;$i<count($arh2["at4"]);$i++) {
$name=preg_replace("~.*/([^/]*)~m","\\1",$arh2["at4"][$i]);
@unlink("data/$k/$name");
}
@rmdir("data/$k");
}
if ($arh2["at5"]<>NULL) {@mkdir("data/$k",0777);
for ($i=0;$i<count($arh2["at5"]);$i++) {
$name=preg_replace("~.*/([^/]*)~m","\\1",$arh2["at5"][$i]);
@ftp_get($ftp,"data/$k/$name",$arh2["at5"][$i],FTP_BINARY);
}
$tar=new Archive_Tar("data/$k.tbz2");
if ($tar->createModify("data/$k","","data/$k")) {
@ftp_put($ftp,"$d/$n/new.tbz2","data/$k.tbz2",FTP_BINARY);
} @unlink("data/$k.tbz2");
for ($i=0;$i<count($arh2["at5"]);$i++) {
$name=preg_replace("~.*/([^/]*)~m","\\1",$arh2["at5"][$i]);
@unlink("data/$k/$name");
}
@rmdir("data/$k");
}
}
@ftp_close($ftp);
$title="List";
include("inc/head.php");
echo ('<div class="gmenu"><a href="ftp.php?k='.$k.'&amp;d='.$rd.'">'.$d.'</a>/<a href="ftp.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$n.'</a></div>');
echo "<div class=\"bmenu\" align=\"center\"><b>$title</b></div>";
echo("<p class=\"menu\" align=\"left\">
total files: $acn/$cnt<br/>
<center><a href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=rmall&amp;go=1\">clear list</a></center></p>");
include("inc/foot.php");
} else {
$title="No Connection...";
include("inc/in_head.php");
echo("<p class=\"rmenu\">
No Connection...</p>");
include("inc/foot.php");
}
?>