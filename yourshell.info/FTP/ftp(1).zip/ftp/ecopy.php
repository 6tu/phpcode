<?php
error_reporting(0);
$sid=trim($_GET["sid"]);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL || $d=="/") {$d="";} if ($n==NULL) {$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
$tp=trim($_GET['tp']); $nm=trim($_POST['nm']); $ch=trim($_POST['ch']);
if ($nm<>NULL) {
$repl=array("\\"=>"",":"=>"","*"=>"","?"=>"","\""=>"","<"=>"",">"=>"","|"=>"");
$nm=trim(strtr($nm,$repl));
include("repl.php"); $nm=u2t($nm);
if (($nm==".")||($nm=="..")) {$nm="";}
}
if (($tp<>NULL)&&($nm==NULL)||(strlen($ch)<>3)) {
$num=@file_get_contents("allnumbd.dat"); $nar=NULL;
$num++; $nar=$num; if ($num>99999999) {$num=0;}
$f=@fopen("allnumbd.dat","w"); @fwrite($f,$num); @fclose($f);
if ($d=="/") {$d="";}
if ($tp=="c") {
$vl=$d."/~".$n; $v1="复制到"; $v2="复制!";
} elseif ($tp=="m") {
$vl=$d."/".$n; $v1="移动到"; $v2="移动!";
} elseif ($tp=="a") {
$vl=$d."/".preg_replace("~([^.]*).*~m","\\1",$n).".zip";
$v1="压缩到"; $v2="压缩!";
} elseif ($tp=="t") {
$vl=$d."/".preg_replace("~([^.]*).*~m","\\1",$n).".tgz";
$v1="压缩到"; $v2="压缩";
} else {header("Location:ftp.php?k=$k&d=$rd"); exit;}
$title=$v1;
include("inc/head.php");
echo("<div class=\"gmenu\"><a href=\"ftp.php?k=$k&amp;d=$rd\">$d</a>/<a href=\"file.php?k=$k&amp;d=$rd&amp;n=$rn\">$n</a></div><div class=\"bmenu\"><b>$title</b></div>");
$v21="$v1: <input name=\"nm\" type=\"text\" value=\"$vl\" maxlength=\"250\"/><br/>";
$v2c="权限:<input name=\"ch\" type=\"text\" value=\"644\" size=\"3\" maxlength=\"3\" format=\"*N\"/>";
echo "<div class=\"menu\"><br/><form action=\"ecopy.php?k=$k&amp;d=$rd&amp;n=$rn&amp;tp=$tp\" method=\"post\">$v21$v2c<br/><input type=\"submit\" value=\"$v2\"/></form><br/>";
echo "</div>";
include("inc/foot.php");
} else {
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true);
if ((substr($nm,-1)<>"/")&&($d."/".$n<>$nm)) {
if ($tp=="c") {
@ftp_get($ftp,"data/$k.bk","$d/$n",FTP_BINARY);
@ftp_put($ftp,"$nm","data/$k.bk",FTP_BINARY);
@unlink("data/$k.bk");
$cmd="chmod 0$ch $nm"; @ftp_site($ftp,$cmd);
} elseif ($tp=="m") {
@ftp_rename($ftp,"$d/$n","$nm");
$cmd="chmod 0$ch $nm"; @ftp_site($ftp,$cmd);
} elseif (($tp=="a")&&(@ftp_size($ftp,"$d/$n")<=3145728)) {
include('pclzip.php'); $zip=new PclZip("data/$k.zip");
mkdir("data/$k",0777);
ftp_get($ftp,"data/$k/$n","$d/$n",FTP_BINARY);
if ($zip->create("data/$k/$n",PCLZIP_OPT_REMOVE_ALL_PATH,PCLZIP_OPT_COMMENT,$cmm)<>0) {
@ftp_put($ftp,"$nm","data/$k.zip",FTP_BINARY);
}
@unlink("data/$k.zip");
@unlink("data/$k/$n"); @rmdir("data/$k");
} elseif (($tp=="t")&&(@ftp_size($ftp,"$d/$n")<=3145728)) {mkdir("data/$k",0777);
$name=preg_replace("~.*/([^/]*)~m","\\1",$nm);
include('tar.php'); $tar=new Archive_Tar("data/$k/$name");
ftp_get($ftp,"data/$k/$n","$d/$n",FTP_BINARY);
if ($tar->createModify("data/$k/$n","","data/$k")) {
@ftp_put($ftp,"$nm","data/$k/$name",FTP_BINARY);
}
@unlink("data/$k/$name");
@unlink("data/$k/$n"); @rmdir("data/$k");
}
}
@ftp_close($ftp);
header("Location:ftp.php?k=$k&d=$rd&act=pm"); exit;
} else {
$title="不能连接";
include("inc/in_head.php");
echo("<p class=\"rmenu\">连接服务器失败.</p>"); include("inc/foot.php");
}
}
?>
