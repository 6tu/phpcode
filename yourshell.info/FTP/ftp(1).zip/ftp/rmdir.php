<?php
error_reporting(0);
function rdir($dir) {
 if ($handle=opendir($dir)) {
  while (($file=readdir($handle))<>false) {
   if (is_file($dir."/".$file)) {
    if ($file<>'crbook.zip') {
     chmod($dir."/".$file,0777); unlink($dir."/".$file);
    }
   }
   elseif (is_dir($dir."/".$file)&&($file<>".")&&($file<>".."))
   {chmod($dir."/".$file,0777); rdir($dir."/".$file);}
  } closedir($handle);
  chmod($dir,0777);
  if (rmdir($dir)) {return true;} else {return false;}
 }
}
?>