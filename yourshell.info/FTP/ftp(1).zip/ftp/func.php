<?php
error_reporting(0);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL || $d=="/") {$d="";} elseif ($d=="/") {$d="";} if ($n==NULL) {$n="";}
$fc=trim($_GET['fc']); $kdr=trim($_GET['kdr']);
$rd=rawurlencode($d); $rn=rawurlencode($n); $p=trim($_GET['p']);
$h=trim($_GET['h']); if ($h==1) {$h="&amp;h=1";}
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
$rp1=trim(stripslashes($_POST['rp1'])); $rp2=trim(stripslashes($_POST['rp2'])); $v=$_GET['ln'];
if ($fc<>NULL) {
if (($fc>1)||(($fc==1)&&($rp1<>NULL))) {
if ($txt=@file_get_contents("data/$k.ed")) {
@copy("data/$k.ed","data/$k.edbk");
include("utf.php");
function chars($ch) {
global $kdr;
if (($ch[1]>=0)&&($ch[1]<=255)) {
if ($kdr==5) {return chr($ch[1]);}
else {return w2u(chr($ch[1]));}
} else {return $ch[0];}
}
$rp1=preg_replace_callback("~#_(\d{1,3})#~",chars,$rp1);
if ($rp2<>NULL) {$rp2=preg_replace_callback("~#_(\d{1,3})#~",chars,$rp2);}
else {$rp2="";}
if ($fc==1) {$txt=str_replace($rp1,$rp2,$txt);}
elseif ($fc==2) {
$txt=str_replace("\n\r","",$txt);
$txt=preg_replace("~^\r\n~","",$txt,1);
}
elseif ($fc==3) {$txt=preg_replace("~[ ]{2,}~"," ",$txt);}
elseif ($fc==4) {$txt=preg_replace("~<[^<>]*>~","",$txt);}
$f=@fopen("data/$k.ed","w");
@fwrite($f,$txt);
@fclose($f);
}
if ($h<>NULL) {$h="2";} else {$h="";}
header("Location: edit$h.php?k=$k&d=$rd&n=$rn&kdr=$kdr&p=$p&ln=$v"); exit;
} elseif ($fc==1) {
$title="替换文本";
include("inc/head.php");
echo ('<div class="gmenu"><a href="ftp.php?k='.$k.'&amp;d='.$rd.'">'.$d.'/</a><a href="file.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$n.'</a></div>');
echo "<div class=\"bmenu\" align=\"center\"><b>$title</b></div>";
echo("<p class=\"menu\" align=\"left\">");
$alt1="<small>文本: </small><input name=\"rp1\" type=\"text\" maxlength=\"100\"/><br/><small>替换成: </small><input name=\"rp2\" type=\"text\" maxlength=\"100\"/><br/>";
echo("<form action=\"func.php?k=$k&amp;d=$rd&amp;n=$rn&amp;kdr=$kdr&amp;p=$p&amp;fc=1$h&amp;ln=$v\" method=\"post\">$alt1<input type=\"submit\" value=\"替换\"/></form></p>");
include("inc/foot.php");
}
} else {
$title="操作";
include("inc/head.php");
echo ('<div class="gmenu"><a href="ftp.php?k='.$k.'&amp;d='.$rd.'">'.$d.'/</a><a href="file.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$n.'</a></div>');
echo "<div class=\"bmenu\" align=\"center\"><b>$title</b></div>";
echo("<p class=\"menu\" align=\"left\"><small>
<a href=\"func.php?k=$k&amp;d=$rd&amp;n=$rn&amp;kdr=$kdr&amp;p=$p&amp;fc=1$h&amp;ln=$v\">替换文本</a><br/>
<a href=\"func.php?k=$k&amp;d=$rd&amp;n=$rn&amp;kdr=$kdr&amp;p=$p&amp;fc=2$h&amp;ln=$v\">删除空行</a><br/>
<a href=\"func.php?k=$k&amp;d=$rd&amp;n=$rn&amp;kdr=$kdr&amp;p=$p&amp;fc=3$h&amp;ln=$v\">删除不必要的符号</a><br/>
<a href=\"func.php?k=$k&amp;d=$rd&amp;n=$rn&amp;kdr=$kdr&amp;p=$p&amp;fc=4$h&amp;ln=$v\">删除标记</a></small></p>");
include("inc/foot.php");
}
?>