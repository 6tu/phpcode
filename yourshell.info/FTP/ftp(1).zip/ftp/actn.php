<?php
error_reporting(0);
$sid=trim($_GET['sid']);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL || $d=="/") {$d="";} elseif ($d=="/") {$d="";}
if ($n==NULL) {$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
$ac=trim($_GET['ac']); $t=trim($_GET['t']); $go=trim($_GET['go']); $nm=trim($_POST['nm']);
if ($nm<>NULL) {
$repl=array("\\"=>"",":"=>"","*"=>"","?"=>"","\""=>"","<"=>"",">"=>"","|"=>"");
$nm=trim(strtr($nm,$repl));
if ($ac<>"mv") {$nm=str_replace("/","",$nm);}
include("repl.php"); $nm=u2t($nm);
}
if ($go<>1){if (($ac=="del")&&($t=="f")) {
$title="删除文件";
include("inc/head.php");
echo('<div class="gmenu" align="left"><a
href="ftp.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$d.'/</a><a
href="file.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$n.'</a></div>');
echo "<div class=\"bmenu\"><b>$title</b></div>";
echo "<div class=\"menu\" align=\"center\">";
echo "
<p>你确定要删除这个文件吗?<br/><br/><a class=\"rmenu\" href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=del&amp;t=f&amp;go=1\"> 执行 </a></p></div>";
include("inc/foot.php");
} elseif ($ac=="delf") {
$title="删除文件夹";
include("inc/head.php");
echo('<div class="gmenu" align="left"><a
href="ftp.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$d.'/</a><a
href="file.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$n.'</a></div>');
echo "<div class=\"bmenu\"><b>$title</b></div>";
echo "<div class=\"menu\" align=\"center\">";
echo "
<p>你确定要删除这个文件夹吗?<br/><br/><a class=\"rmenu\" href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=delf&amp;t=d&amp;go=1\"> 执行 </a></p></div>";
include("inc/foot.php");
} elseif (($ac=="ren")||($ac=="mv")) {
if ($n==NULL) {
$n=preg_replace("~.*/([^/]*)~m","\\1",$d); $d=preg_replace("~(.*)/[^/]*~m","\\1",$d);
$rn=str_replace(".htaccess",".|htaccess",$n);
$rd=str_replace(".htaccess",".|htaccess",$d);
}
$num=@file_get_contents("allnumbd.dat"); $nar=NULL;
$num++; $nar=$num; if ($num>99999999) {$num=0;}
$f=@fopen("allnumbd.dat","w"); @fwrite($f,$num); @fclose($f);
if ($ac=="ren") {$sn="重命名"; $vl=$n;}
else {$sn="移动"; $vl=$d."/".$n;}
$title=$sn;
include("inc/head.php");
echo('<div class="gmenu" align="left"><a
href="ftp.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$d.'/</a><a
href="file.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$n.'</a></div>');
echo "<div class=\"bmenu\"><b>$title</b></div>";
echo "<div class=\"menu\" align=\"center\">";
$ajaja="$sn:<input name=\"nm\" type=\"text\" value=\"$vl\" maxlength=\"150\"/><br/>";
echo "<p><form action=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=$ac&amp;t=$t&amp;go=1\" method=\"post\">$ajaja<input type=\"submit\" value=\"执行\"/></form></p></div>";
include("inc/foot.php");
} elseif (($ac=="at")&&($t=="f")) {
$title="创建压缩文档";
include("inc/head.php");
echo "<div class=\"gmenu\"><a href=\"ftp.php?k=$k&amp;d=$rd&amp;n=$rn\">$d/</a><a href=\"file.php?k=$k&amp;d=$rd&amp;n=$rn\">$n</a></div>";
echo "<div class=\"bmenu\"><b>$title</b></div><div class=\"menu\" align=\"center\">";
$slt="格式:</small>
<select name=\"ac\" value=\"at2\">
<option value=\"at1\">TAR</option>
<option value=\"at2\">TGZ</option>
<option value=\"at3\">TGZ2</option>
<option value=\"at4\">TBZ</option>
<option value=\"at5\">TBZ2</option>
</select><br/>";
echo "<p><form action=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;t=f&amp;go=1\" method=\"get\">$slt<input type=\"submit\" value=\"执行\"/></form></p></div>";
include("inc/foot.php");
}
} else {$stb="";
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true);
$st="<div class=\"gmenu\">保存文件.</div>";
if (($ac=="del")&&($t=="f")) {//del file
if (@ftp_delete($ftp,"$d/$n")) {
@ftp_close($ftp);
header("Location: ftp.php?k=$k&d=$rd&act=pm"); exit;
} else {$st="<div class=\"gmenu\">删除文件.</div>";}
} elseif (($ac=="delf")&&($t=="d")) {//del all dir
function rdir($conn,$dir) {ftp_chdir($conn,$dir);
$arr=ftp_nlist($conn,"."); $ctns=count($arr); if ($ctns>700) {$ctns=700;}
for ($i=0;$i<$ctns;$i++) {$fl=$dir."/".$arr[$i];
if ((ftp_size($conn,$fl)==-1)&&(preg_replace("~.*/([^/]*)~m","\\1",$fl)<>".")&&
(preg_replace("~.*/([^/]*)~m","\\1",$fl)<>"..")) {rdir($conn,$fl);}
else {@ftp_delete($conn,$fl);}
} ftp_chdir($conn,"/");
@ftp_delete($conn,$dir."/".".htaccess");
if (ftp_rmdir($conn,$dir)) {return true;} else {return false;}
}
if ($n==NULL) {
$n=preg_replace("~.*/([^/]*)~m","\\1",$d); $d=preg_replace("~(.*)/[^/]*~m","\\1",$d);
$rn=str_replace(".htaccess",".|htaccess",$n);
$rd=str_replace(".htaccess",".|htaccess",$d);
}
if (@rdir($ftp,"$d/$n")) {
@ftp_close($ftp);
header("Location: ftp.php?k=$k&d=$rd&act=pm"); exit;
} else {$st="删除文件夹.";}
@ftp_close($ftp);
} elseif (($ac=="mv")&&($t=="d")) {//move dir
if (@ftp_rename($ftp,$d."/".$n,$nm)) {
@ftp_close($ftp);
$nm=str_replace(".htaccess",".|htaccess",$nm);
$nm=rawurlencode($nm);
header("Location: ftp.php?k=$k&d=$nm&act=pm"); exit;
} else {$st="文件夹不能被移动.";}
} elseif (($ac=="ren")&&($t=="d")) {//rename dir
if (@ftp_rename($ftp,$d."/".$n,$d."/".$nm)) {@ftp_close($ftp);
$nm=str_replace(".htaccess",".|htaccess",$nm);
$nm=rawurlencode($nm);
header("Location: ftp.php?k=$k&d=$rd&n=$nm&act=pm"); exit;
} else {$st="改名失败.";}
} elseif (($ac=="ren")&&($t=="f")) {//rename file
if (@ftp_rename($ftp,$d."/".$n,$d."/".$nm)) {
@ftp_close($ftp);
header("Location: ftp.php?k=$k&d=$rd&act=pm"); exit;
} else {$st="改名失败.";}
} elseif (($ac=="copy")||($ac=="cut")||($ac=="arh")||($ac=="at1")||
($ac=="at2")||($ac=="at3")||($ac=="at4")||($ac=="at5")) {//add act
$flist=@file("data/$k.act");if($n[strlen($n)-1]=="/") {$n[strlen($n)-1]="";}
$str="$d/$n|$t|$ac\r\n";
if ($flist<>NULL) {
for ($i=0;$i<count($flist);$i++) {if ($i==100) {break;} $str.=$flist[$i];}
}
$f=@fopen("data/$k.act","w"); @fwrite($f,$str); @fclose($f);
if ($t=="d") {$st="文件夹 \"".htmlspecialchars($d."/".$n)."\" 已经添加到剪贴板.";}
else {$stb="<div class=\"gmenu\"><a href=\"ftp.php?k=$k&amp;d=$rd\">$d</a>/<a href=\"file.php?k=$k&amp;d=$rd&amp;n=$rn\">$n</a></div>"; $st="文件 \"".htmlspecialchars($d."/".$n)."\" 已经添加到剪贴板.";}
} elseif ($ac=="rm") {//list; remove
$lnm=rawurldecode(trim(str_replace(".|htaccess",".htaccess",$_GET['lnm'])));
if ($flist=@file("data/$k.act")) {$str="";
for ($i=0;$i<count($flist);$i++) {
list($p1,$p2,$p3)=split('[|]',$flist[$i]); $p1=trim($p1);
if ($p1<>$lnm) {$str.=$flist[$i];}
}
$f=@fopen("data/$k.act","w"); @fwrite($f,$str); @fclose($f);
header("Location: list.php?k=$k&d=$rd&n=$rn"); exit;
} else {$st="<div class=\"rmenu\">错误</div>";}
} elseif ($ac=="rmall") {//list; remove all
if (unlink("data/$k.act")) {
header("Location: list.php?k=$k&d=$rd&n=$rn"); exit;
} else {$st="<div class=\"rmenu\">失败.</div>";}
}
@ftp_close($ftp);
$title=$st;
include("inc/head.php");
echo "$st $stb";
include("inc/foot.php");
} else {
$title="连接错误..!!";
include("inc/in_head.php");
echo "<p class=\rmenu\">连接错误...</p>";
include("inc/foot.php");
}
}
?>
