<?php
error_reporting(0);
$sid=trim($_GET['sid']);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL || $d=="/") {$d="";}
if ($n==NULL) {$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);}
$url=trim(stripslashes($_POST['url']));
if ($url=="<http://>") {$url=NULL;}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace('$','$$',$d); $n=str_replace('$','$$',$n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
$title="导入文件";
include("inc/head.php");
echo ('<div class="gmenu" align="left"><a href="ftp.php?k='.$k.'&amp;d='.$rd.'">'.$d.'</a>/<a href="ftp.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$n.'</a></div>');
echo ("<div class=\"bmenu\" align=\"left\">$title</div>");
if ($url<>NULL) {
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true);
@preg_match_all("~<([^*>]*)[*]?([^*>]*)[*]?([acm]{1})?>~m",$url,$arr);
if ($arr<>NULL) {include("repl.php");
$cn=count($arr[0]); $str=""; $pp=""; $imp=0; $addl=0;
if ($cn>25) {$cn=25;}
for ($i=0;$i<$cn;$i++) {
$curl=$arr[1][$i];
if (strpos($curl,'"')!==false) {
if (substr_count($curl,'"')==1) {
$pp=preg_replace("~^([^\"]*).*~","\\1",$curl);
if ($pp[strlen($pp)-1]=="/") {$pp[strlen($pp)-1]="";}
}
$curl=str_replace('"','',$curl);
} elseif ($pp<>NULL) {
if ((strlen($curl)<5)||(@substr($curl,0,5)<>"http:")) {
if ($curl[0]=="/") {$curl=substr($curl,1);} $curl=trim($pp)."/".trim($curl);
}
}
if ($arr[2][$i]==NULL) {
$sv=preg_replace("~.*/([^/]*)~m","\\1",$curl);
if ($sv==NULL) {$sv="index.wml";}
} else {$sv=$arr[2][$i];}
$repl=array("\\"=>"",":"=>"","*"=>"","?"=>"","\""=>"","<"=>"",">"=>"","|"=>"");
$sv=trim(strtr($sv,$repl));
$sv=u2t($sv);
if ($n[strlen($n)-1]=="/") {$n[strlen($n)-1]="";}
if ($sv[0]=="/") {$svf=$sv;} else {$svf=$d."/".$n."/".$sv;}
if (strpos($curl,"http://")===0) {$fsz=NULL;
$host=preg_replace("~.*://([^/]*).*~","\\1",$curl,1);
$path=preg_replace("~.*://[^/]*(/.*)~","\\1",$curl,1);
if (($host<>$curl)&&($path<>$curl)) {
$f=@fsockopen($host,80,$e,$e,7);
@fputs($f,"HEAD $path HTTP/1.1\r\nHost: $host\r\nConnection: close\r\nContent-Type: application/x-www-form-urlencoded\r\n\r\n");
$header="";
while (!feof($f)) {$header.=@fgets($f,1024);}
@fclose($f);
if (strpos($header,"Content-Length:")!==false) {
eregi("Content-Length: ([0-9]*)",$header,$mss);
$fsz=trim($mss[1]);
}
}
if (($fsz==NULL)||($fsz<=6242880)) {
if (copy($curl,"data/$k.bk")) {
if (filesize("data/$k.bk")<=6242880) {
if (ftp_put($ftp,$svf,"data/$k.bk",FTP_BINARY)) {
$imp++;
$ac=NULL;
if ($arr[3][$i]<>NULL) {
if ($arr[3][$i]=="m") {$ac="cut";}
else if ($arr[3][$i]=="c") {$ac="copy";}
else if ($arr[3][$i]=="a") {$ac="arh";}
}
if ($ac<>NULL) {$addl++; $str.="$svf|f|$ac\r\n";}
}
} else {$st.="file ".htmlspecialchars(str_replace('$','$$',$curl),ENT_QUOTES)." 导入失败, 最大 5MB.<br/>\r\n";}
} else {$st.="<div class=\"rmenu\">文件 ".htmlspecialchars(str_replace('$','$$',$curl),ENT_QUOTES)." 不能导入.</div>\r\n";}
} else {$st.="<div class=\"rmenu\">文件 ".htmlspecialchars(str_replace('$','$$',$curl),ENT_QUOTES)." hmm, 最大5MB.</div>\r\n";}
} else {$st.="<div class=\"rmenu\">文件 ".htmlspecialchars(str_replace('$','$$',$curl),ENT_QUOTES)."不能被导入.</div>\r\n";}
@unlink("data/$k.bk");
}
if ($str<>NULL) {
$flist=@file("data/$k.act");
if ($flist<>NULL) {
for ($j=0;$j<count($flist);$j++) {if ($j==100) {break;} $str.=$flist[$j];}
}
$f=@fopen("data/$k.act","w"); @fwrite($f,$str); @fclose($f);
}
if ($cn<>NULL) {
if ($st<>NULL) {$st.="\r\n";}
$st.="<div class=\"gmenu\">导入文件: <font color=\"red\">".htmlspecialchars($sv)."</font></div>\r\n";
if ($addl<>NULL) {$st.="<div class=\"menu\">添加文件到剪切板: $addl<br/><a href=\"list.php?k=$k&amp;d=$rd&amp;n=$rn\">lists</a></div>\r\n";}
$st.="";
}
} else {$st="<div class=\"rmenu\">导入错误!.</div>";}
@ftp_close($ftp);
$num=@file_get_contents("allnumbd.dat"); $nar=NULL;
$num++; $nar=$num; if ($num>99999999) {$num=0;}
$f=@fopen("allnumbd.dat","w"); @fwrite($f,$num); @fclose($f);
if ($pp<>NULL) {$purl="&lt;".htmlspecialchars(trim($pp))."&gt;";} else {$purl="&lt;http://&gt;";}
echo("<center><b>$st</b></center>");
$download="<small>URL's:<br/></small><input name=\"url\" type=\"text\" value=\"$purl\"/>";
echo("<div class=\"menu\" align=\"left\"><form action=\"import.php?k=$k&amp;d=$rd&amp;n=$rn\" method=\"post\">$download<br/><input type=\"submit\" value=\"导入\"/></form></div>");
include("inc/foot.php");
} else {
echo("<p class=\"rmenu\">错误</p>");
include("inc/foot.php");
}
} else {
$num=@file_get_contents("allnumbd.dat"); $nar=NULL;
$num++; $nar=$num; if ($num>99999999) {$num=0;}
$f=@fopen("allnumbd.dat","w"); @fwrite($f,$num); @fclose($f);
$download="URL's:<br/><input name=\"url\" type=\"text\" value=\"&lt;http://&gt;\"/>";
echo("<div class=\"menu\" align=\"left\"><form action=\"import.php?k=$k&amp;d=$rd&amp;n=$rn\" method=\"post\">$download<br/><input type=\"submit\" value=\"导入\"/></form></div>");
include("inc/foot.php");
}
?>
