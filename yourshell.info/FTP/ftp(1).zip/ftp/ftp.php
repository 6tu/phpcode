<?php
error_reporting(0);
$act=trim($_GET['act']);
$go=trim($_GET['go']);
$LOGIN=trim($_GET['LOGIN']);
include("inc/login.php");
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL || $d=="/") {$d="";} if ($n==NULL) {$n="";}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true);
$sz=@ftp_size($ftp,"$d,$n,$nm");
$tm=@ftp_mdtm($ftp,"$d/$n");
@ftp_close($ftp);

$fsz=$sz;
if ($size<100) {$sz="".$sz."B";}
elseif ($size<1024) {$sz="".str_replace(".",",",round($size/1024,3))."kB";}
elseif ($size<102400) {$sz="".round($size/1024,3)."kB";}
else {$sz="".str_replace(".",",",round($size/1024/1024,3))."MB";}
} else {$sz="";}

if ($tm<>NULL) {$tmv=gmdate("d-m-y,H:i:s a" , time() +3600*7);} else {$tmv="-";}
$d=str_replace("\$","\$\$",$d); $n=str_replace("\$","\$\$",$n);
$rf=strtolower(preg_replace("~.*\.([^.]*)~m","\\1",$n));if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true); $links="";
ftp_chdir($ftp,$d."/".$n); $curd=ftp_pwd($ftp);
if ($curd<>"/") {
$back=preg_replace("~(.*)/[^/]*~m","\\1",$curd);
$back=str_replace(".htaccess",".|htaccess",$back);
}
include("flist.php"); $fls=flist($ftp,$curd,$k);
@ftp_close($ftp);

$p=trim($_GET['p']); $cnt=count($fls);$v=$skl; if (($v<1)||($v>100)) {$v=15;} $allp=ceil($cnt/$v);
if (($p==NULL)||($p==0)) {$p=1;} elseif ($p>$allp) {$p=$allp;}
$begin=$p*$v-$v; if ($begin>$cnt) {$begin=0;}
$end=$begin+$v; if ($end>$cnt) {$end=$cnt;}
for ($i=$begin;$i<$end;$i++) {$links.=$fls[$i]."<br/>\r\n";} $bl="";
if ($p>1) {$v=$p-1; $bl.="<a style=\"color:red\" href=\"ftp.php?k=$k&amp;d=$rd&amp;n=$rn&amp;p=$v\"><b>&lt;&lt;</b></a> | ";} elseif ($allp>$p) {$bl.="<b>&lt;&lt;</b> | ";}
if ($allp>$p) {$v=$p+1; $bl.="<a style=\"color:red\" href=\"ftp.php?k=$k&amp;d=$rd&amp;n=$rn&amp;p=$v\"><b>&gt;&gt;</b></a><br/>\r\n";} elseif ($p>1) {$bl.="<b>&gt;&gt;</b><br/>\r\n";}
if ($bl<>NULL) {$bl="Page: $p/$allp<br/>$bl
<form action='ftp.php'><input type='hidden' name='k' value='$k'/><input type='hidden' name='d' value='$rd'/><input type='hidden' name='n' value='$rn'/><input name='p' type='text' value='$p' size='2' format='*N'/><input type='submit' value='Go'/></form>";}
$d=str_replace("\$","\$\$",$d); $n=str_replace("\$","\$\$",$n);
$curd=str_replace("\$","\$\$",$curd); $links=str_replace("\$","\$\$",$links);
$title="Listing ".$curd;
include('inc/head.php');
echo("<div class=\"gmenu\">$curd</div>");
if ($curd<>"/") {
if ($ib==1) {
$icn="<img src=\"img/back.png\" width=\"16\" height=\"16\" alt=\"&lt;\" />";
} else {$icn="Up";}
echo("<div class=\"menu\">$icn<a href=\"ftp.php?k=$k&amp;d=$back\"><b>..</b></a></div>");
}
echo("<div class=\"menu\">");
if ($act=="pm") {
$msg="<p>操作完成 !</p>";
} elseif ($act=="errs") {
$msg="<p>没有选择文件 !</p>";
} elseif ($act=="copy") {
$msg="<p>复制完成</p>";
} elseif ($act=="move") {
$msg="<p>移动完成</p>";
} elseif ($act=="zip") {
$msg="<p>压缩成功</p>";
} elseif ($act=="delete") {
$msg="<p>删除成功</p>";
} elseif ($act=="chmod") {
$msg="<p>权限修改成功</p>";
}elseif ($act=="LOGIN") {
$msg="<p>提醒：不要忘了退出哦！</p>";}echo("<center><font color=\"red\"><b>$msg</b></font></center>");
echo("<br/>$bl<br/>");
echo "<form action='actions.php?k=$k&d=$rd&n=$rn' align='left' method='post'>";
echo("$links</div>");
echo("<div class=\"phdr\"><h3>选中操作:</h3></div><div class=\"menu\" style=\"padding:1px\"><input type='submit' name='del' value='删除' /><input type='submit' name='c' value='复制' /><input type='submit' name='m' value='移动' /><input type='submit' name='ch' value='权限' /><input type='submit' name='arh' value='添加到zip' /></form></div>");
echo("<div class=\"menu2\">$bl</div>");
{echo("<div class=\"phdr\"><h3>剪贴板操作:</h3></div><p class=\"menu\">[<a href=\"ecopy.php?k=$k&amp;d=$rd&amp;n=$rn&amp;tp=c\">复制</a>][<a href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=cut&amp;t=d&amp;go=1\">剪切</a>]</p>
<div class=\"phdr\"><h3>常用操作:</h3></div><p class=\"menu\"><a href=\"arhdir.php?k=$k&amp;d=$rd&amp;n=$rn\">压缩</a> &nbsp;
<a href=\"list.php?k=$k&amp;d=$rd&amp;n=$rn\">剪贴板</a> &nbsp;<a href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=mv&amp;t=d\">移动</a> &nbsp;
<a href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=ren&amp;t=d\">重命名</a> &nbsp;
<a href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=delf\">删除</a></p>");}
echo("<div class=\"phdr\"><h3>
创建操作: </h3></div><p class=\"menu\">
<a href=\"create.php?k=$k&amp;d=$rd&amp;n=$rn&amp;tp=f\">文件</a> &nbsp;
<a href=\"create.php?k=$k&amp;d=$rd&amp;n=$rn&amp;tp=d\">文件夹</a> &nbsp;
<a href=\"import.php?k=$k&amp;d=$rd&amp;n=$rn\">导入</a> &nbsp;
<a href=\"upload.php?k=$k&amp;d=$rd&amp;n=$rn\">上传</a></p>");
include('inc/foot.php');
} else {
header ("Location: index.php?act=err");
/* $title="连接错误..";
include("inc/in_head.php");
echo('<div class="rmenu" align="left"><small>
连接错误<br/>
<br/></div>');
include('inc/foot.php'); */
}
?>
