<?php
$dftp='./';
$judul='WapFTP';
$cmm="Date (GMT +08:00)\r\n".date("d.m.y, H:i:s");
$php='/usr/local/bin/php';
?>
