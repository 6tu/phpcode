<?php
error_reporting(0);
$sid=trim($_GET['sid']);
$k=trim($_GET['k']); include("key.php"); $t=trim($_GET['t']);
if ((($t=="wml")||($t=="htm")||($t=="html")||($t=="txt")||($t=="pr")||($t=="pr2"))&&(file_exists("data/$k.ed"))) {
if (($t=="pr")||($t=="pr2")) {
$fl=@file_get_contents("data/$k.ed");
function chrpl($str) {
for ($j=0;$j<32;$j++) {
if ($j<>13) {$str=str_replace(chr($j),'',$str);}
}
return $str;
}
$fl=chrpl($fl);
$fl=htmlspecialchars($fl,ENT_QUOTES);
if ($t=="pr2") {
$fl=preg_replace("~&lt;[^<>]*&gt;~iU",
"<font color=\"#0000ff\">\\0</font>",$fl);
$fl=preg_replace("~(&lt;[^\s!]*\s)([^<>]*)([/?]?&gt;)~iU",
"\\1<font color=\"#007f7f\">\\2</font>\\3",$fl);
$fl=preg_replace("~&lt;!--.*--&gt;~iU",
"<font color=\"#909090\">\\0</font>",$fl);
$fl=preg_replace("~(&quot;|&#039;)[^<>]*(&quot;|&#039;)~iU",
"<font color=\"#900000\">\\0</font>",$fl);
$fl=str_replace("\r","<br>\r\n",$fl);
} else {$fl=str_replace('$','$$',$fl); $fl=str_replace("\r","<br/>\r\n",$fl);}
if ($t=="pr") {
header("Cache-Control: no-cache, must-revalidate");
header("Content-Type: text/vnd.wap.wml; charset=Utf-8");
echo ("<?xml version=\"1.0\" encoding=\"Utf-8\"?><!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.2//EN\" \"http://www.wapforum.org/DTD/wml_1.2.xml\"><wml>
<head><meta forua=\"true\" http-equiv=\"Cache-Control\" content=\"no-cache,no-store,must-revalidate\"/></head><card title=\"checking code\">
<p align=\"left\"><small>
$fl</small></p>
</card></wml>");
} else {
$title="Դ��";
include("inc/head.php");
echo("<div class=\"bmenu\"><b>Source code</b></div><div class=\"phpcode\"><p>
$fl</p></div>");
include("inc/foot.php");
}
} else {
$fl=@file_get_contents("data/$k.ed");
if ($t=="wml") {header("Content-Type: text/vnd.wap.wml; charset=utf-8");}
elseif (($t=="htm")||($t=="html")) {header("Content-Type: text/html; charset=utf-8");}
elseif ($t=="txt") {header("Content-Type: text/plain; charset=utf-8");}
echo $fl; exit;
}
}
?>
