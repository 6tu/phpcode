<?php
ob_start();
$sid=trim($_GET['sid']);
header("Content-type: text/html; charset=utf-8");
date_default_timezone_set ("PRC");
$jam=date("H:i:s",time());echo '<?xml version="1.0" encoding="iso-8859-1"?>  <!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http:/www.wapforum.org/DTD/xhtml-mobile10.dtd">  <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">  <head>  <title>'.$judul.' | '.$jam.'</title> <meta name="Charset" content="UTF-8" />  <link rel="shortcut icon" href="favicon.ico">';
echo '<link rel="stylesheet"  type="text/css" href="theme/1/style.css" media="all, handheld"></head><body><div class="gmenu"></div><div class="maintxt">';
?>
