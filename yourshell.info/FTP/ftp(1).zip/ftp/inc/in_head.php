<?php
ob_start();
$sid=trim($_GET['sid']);
header("Content-type: text/html; charset=utf-8");
date_default_timezone_set ("PRC");
$jam=date("H:i:s",time());   echo '<?xml version="1.0" encoding="iso-8859-1"?>  <!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http:/www.wapforum.org/DTD/xhtml-mobile10.dtd">  <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">  <head>  <title>'.$title.' | '.$jam.'</title> 
<link rel="shortcut icon" href="favicon.ico">';  echo "<link rel=\"stylesheet\"  type=\"text/css\" href=\"theme/$tema/style.css\" media=\"all, handheld\">";  echo '</head><body><div class="logo" align="center">';
echo("</div><div class=\"header\" align=\"center\"><b>$judul</b></div><div class=\"maintxt\">");  echo "<div class=\"bmenu\" align=\"center\">Wap3在线FTP </div>";  ?>
