<?php
ob_start();
$sid=trim($_GET['sid']);
$login=$lg.'@'.$sr;
header("Content-type: text/html; charset=utf-8");
date_default_timezone_set ("PRC");
$jam=date("H:i:s",time());
echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http:/www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>'.$title.' | '.$jam.'</title>
<meta name="Charset" content="UTF-8" />
<link rel="stylesheet" href="theme/1/style.css" type="text/css" />
<link rel="shortcut icon" href="favicon.ico"></head><body><div class="logo" align="center">';
echo "</div><div class=\"header\" align=\"center\"><b>$login</b></div>";echo('<div class="maintxt">');
echo("<div class=\"fmenu\" style=\"text-align:left\"> <a href='javascript:history.back(2)'>返回</a> <a href=\"go.php?k=$k&amp;d=$rd&amp;n=$rn\" accesskey=\"5\" title=\"go\">跳转</a> <a href=\"exit.php?k=$k\" accesskey=\"0\" title=\"logout\">退出</a></div>");
?>
