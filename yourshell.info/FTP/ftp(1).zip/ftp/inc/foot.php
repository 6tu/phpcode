<?php
list($msec,$sec)=explode(chr(3),microtime());
echo '<div class="gmenu" align="right"><small>in '.round(($sec + $msec) - $conf['headtime'],3).'&nbsp;s</small></div></body></html>';
?>