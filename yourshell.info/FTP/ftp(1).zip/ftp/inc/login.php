<?php
error_reporting(0);
$server=rawurldecode(trim($_GET['server']));
$user=rawurldecode(trim($_GET['user']));
$pass=rawurldecode(trim($_GET['pass']));
$d=rawurldecode(trim($_GET['d']));
$go=rawurldecode(trim($_GET['go']));
$tema=rawurldecode(trim($_GET['tema']));
include_once("cnfg.php");

if (($server==NULL)||($user==NULL))
{
if ($server==NULL) {$server=$_SERVER['HTTP_HOST'];}
} else {
$arr=array("0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F",
"G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y",
"Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r",
"s","t","u","v","w","x","y","z");
$key=$arr[rand(0,61)].$arr[rand(0,61)].$arr[rand(0,61)].$arr[rand(0,61)].$arr[rand(0,61)].$arr[rand(0,61)].$arr[rand(0,61)];
$repl=array("^"=>""); $time=time(); $server=strtolower(trim(strtr($server,$repl)));
$user=trim(strtr($user,$repl)); $pass=trim(strtr($pass,$repl));
$items=trim($_GET['items']); if (($items<10)||($items>100)) {$v=$items;}
$size=trim($_GET['size']); if ($size==1) {$size=1;} else {$size=0;}
$icons=trim($_GET['icons']); if ($icons==1) {$icons=1;} else {$icons=0;}
$tema=trim($_GET['tema']);
if($tema=="1") {
$tema="1";
}
elseif($tema=="2") {
$tema="2";
}
elseif($tema=="3") {
$tema="3";
}
elseif($tema=="4") {
$tema="4";
}
elseif($tema=="5") {
$tema="5";
}
else {$tema="1";}
$str=$key."^$server^$user^$pass^$items^$time^$size^$icons^$tema\r\n"; $fl=@file("inc/barakatak.dat");
if ($fl<>NULL) {
for ($i=0;$i<count($fl);$i++) {
list($p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9)=split('\^',trim($fl[$i]));
if ($p1==$key) {
header("Location: ftp.php?server=$server&user=$user&pass=$pass"); exit;
}
if (($time-$p6<2700)&&($p2<>$server)&&($p3<>$user)) {$str.=$fl[$i];}
else {
include_once("freedata.php"); freedata($p1);
}
}
}
$f=@fopen("inc/barakatak.dat","w"); @fwrite($f,$str); @fclose($f);
$dir=""; if (($d<>NULL)&&($d<>"/")) {$dir="&d=".rawurlencode($d);
}
$dir=str_replace(".htaccess",".|htaccess",$dir);
header("Location: ftp.php?k=$key$dir&act=LOGIN"); exit;
}
?>
