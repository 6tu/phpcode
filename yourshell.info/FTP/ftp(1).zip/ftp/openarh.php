<?php
error_reporting(0);
$sid=trim($_GET['sid']);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL || $d=="/") {$d="";} if ($n==NULL) {$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);}
$rd=rawurlencode($d); $rn=rawurlencode($n); $tp=trim($_GET['tp']);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
$nm=trim($_POST['nm']); $chf=trim($_POST['chf']); $chd=trim($_POST['chd']);
if ($nm<>NULL) {
$repl=array("\\"=>"",":"=>"","*"=>"","?"=>"","\""=>"","<"=>"",">"=>"","|"=>"");
$nm=trim(strtr($nm,$repl));
include("repl.php"); $nm=u2t($nm);
if ($nm=="..") {$nm="";}
}
if (($nm==NULL)||(strlen($chf)<>3)||(strlen($chd)<>3)) {
$num=@file_get_contents("allnumbd.dat"); $nar=NULL;
$num++; $nar=$num; if ($num>99999999) {$num=0;}
$f=@fopen("allnumbd.dat","w"); @fwrite($f,$num); @fclose($f);
if ($d=="/") {$d="";} $n=str_replace("\$","\$",$n); $d=str_replace("\$","\$",$d);
$vl=$d."/".preg_replace("~([^.]*).*~m","\\1",$n);
$title="Open archive";
include("inc/head.php");
echo ("<div class=\"gmenu\" align=\"left\"><a href=\"ftp.php?k=$k&amp;d=$rd\">$d</a>/<a href=\"file.php?k=$k&amp;d=$rd&amp;n=$rn\">$n</a></div>");
echo "<div class=\"bmenu\"><b>$title</b></div>";
$input="extract to:<input name=\"nm\" type=\"text\" value=\"$vl\" maxlength=\"250\"/><br/>CHMOD files:<input name=\"chf\" type=\"text\" value=\"644\" size=\"3\" maxlength=\"3\" format=\"*N\"/><br/>CHMOD folders:<input name=\"chd\" type=\"text\" value=\"755\" size=\"3\" maxlength=\"3\"/>";
echo("<div class=\"menu\"><p><form action=\"openarh.php?k=$k&amp;d=$rd&amp;n=$rn&amp;tp=$tp\" method=\"post\">$input<br/><input type=\"submit\" value=\"Open\"/></form></p></div>");include("inc/foot.php");
} else {
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true); $sz=ftp_size($ftp,"$d/$n");
if (($sz==-1)||($sz>916800)) {header("Location:ftp.php?k=$k&d=$rd"); exit;}
if ($nm[0]<>"/") {if ($nm==".") {$nm="";} $nm=$d."/".$nm;}
$nm=preg_replace("~(^/)|(/$)|(//)~","",$nm);
$nm=str_replace('$','$$',$nm);
if (($tp=="zip")||($tp=="jar")) {
@ftp_get($ftp,"data/$k.zip","$d/$n",FTP_BINARY);
include_once('pclzip.php'); $zip=new PclZip("data/$k.zip");
if (($lst=$zip->listContent())==0) {$st="your file corrupted or unknown format.";}
$f=@fopen("data/$k.aopen","w");
@fwrite($f,$nm."::".$chf."::".$chd."::zip\r\n");
for ($i=0;$i<count($lst);$i++) {
$fnm=trim($lst[$i]['stored_filename']);
$fd=trim($lst[$i]['folder']); if ($fd<>1) {$fd=0;}
if ($fd==1) {$fnm=preg_replace("~(^/)|(/$)~","",$fnm);}
@fwrite($f,$i."::".$fnm."::".$fd."::".trim($lst[$i]['size'])."::".trim($lst[$i]['compressed_size'])."\r\n");
}
@fclose($f);
} else {
@ftp_get($ftp,"data/$k.tar","$d/$n",FTP_BINARY);
include_once("tar.php"); $tar=new Archive_Tar("data/$k.tar");
if (($lst=$tar->listContent())==0) {$st="maybe your file corrupted or unknown format.";}
$f=@fopen("data/$k.aopen","w");
@fwrite($f,$nm."::".$chf."::".$chd."::tar\r\n");
for ($i=0;$i<count($lst);$i++) {
$fnm=trim($lst[$i]['filename']);
$fd=trim($lst[$i]['typeflag']); if ($fd==5) {$fd=1;} else {$fd=0;}
if ($fd==1) {$fnm=preg_replace("~(^/)|(/$)~","",$fnm);}
@fwrite($f,$i."::".$fnm."::".$fd."::".trim($lst[$i]['size'])."::0\r\n");
}
@fclose($f);
}
@ftp_close($ftp);
header("Location: shopen.php?k=$k&d=$rd&n=$rn"); exit;
} else {
$title="No connection...";
include("inc/in_head.php");
echo("<p class=\"rmenu\" align=\"center\"><small>
no connection...</p>");
include("inc/foot.php");
}
}
?>
