<?php
error_reporting(0);
$sid=trim($_GET['sid']);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL || $d=="/") {$d="";} else {if ($d=="/") {$d="";}}
if ($n==NULL) {$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);}
if ($n==NULL) {$n=preg_replace("~.*/([^/]*)~m","\\1",$d); $d=preg_replace("~(.*)/[^/]*~m","\\1",$d);}
$mr=trim($_GET['mr']); $error=0;
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
$title="Checking Script";
include("inc/head.php");
echo "<div class=\"gmenu\" align=\"left\"><small>
Checking script..</div><div class=\"menu\">
";

if (file_exists("data/$k.ed")) {
@exec($php.' -c -f -l "data/'.$k.'.ed"',$rt,$v); $erl=0;
if (($v==255)||(count($rt)==3)) {
echo("Host not support: "); $st=trim(strip_tags($rt[1])); $error=1;
if ($st<>NULL) {
$srp=trim(preg_replace("~[^:]*:(.*)(in [^\s]*data/".$k.".ed).*~","\\1",$st,1));
echo str_replace("$k.ed","",$srp);
$st=str_replace("$k.ed","",$st);
$erl=preg_replace("~.*\s(\d*)$~","\\1",$st,1);
if ($erl<>NULL) {
$pg=ceil($erl/15);
echo("<br>\r\n <font color='red'>Lines to page: $erl; pages: $pg</font>");
}
} else {echo("Host not support..!!");}
echo("<br><br>\r\n");
} elseif ($v===0) {
$error=2;
echo("No syntax errors detected..!!<br><br>\r\n");
}
if (($error==1)||($mr==1)) {
$fl=str_replace("\n","",trim(file_get_contents("data/$k.ed")));
$fl=highlight_string($fl,true);
$fl=str_replace(array('<code>','</code>','</span>'),array('','','</font>'),$fl);
$fl=str_replace('span style="color: ','font color="',$fl);
$arr=split("\r",$fl); $cnt=count($arr);
if ($mr==1) {$begin=0; $end=$cnt;}
else {$begin=$erl-2; $end=$erl+1; if ($begin<0) {$begin=0;} if ($end>$cnt) {$end=$cnt;}}
for ($i=$begin;$i<$end;$i++) {
if ($i==$erl-1) {$fcl="ff0000"; $bcl="ffffff";} else {$fcl="ffffff"; $bcl="ffffff";}
echo("<span style=\"color:#$fcl;\">".($i+1)." </span>".$arr[$i]."<br/><br/>\r\n");
}
} elseif ($error<>2) {echo("No syntax errors detected..!!<br/><br/><a href=\"chck2.php?k=$k&amp;mr=1\">Show all lines..</a><br/><br/>\r\n");}
} else {echo("File not found..!!<br/><br/>\r\n");}

if (($mr<>1)&&($error<>0)) {
if ($error==1) {echo("<br/><a href=\"chck.php?k=$k&amp;mr=1\">Checking syntax</a><br/>");}
else {echo("<a href=\"chck2.php?k=$k&amp;mr=1\">Show all lines</a>");}
}
echo"</div>";
include("inc/foot.php");
?>
