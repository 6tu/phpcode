<?php
function flist($res,$dr,$skey) {global $dftp, $shs, $ib;
if (strpos($dr," ")===false) {$al="-al ";} else {$al="";}
$lines=@ftp_rawlist($res,$al.$dr); $fnm=NULL; $dnm=NULL;
include("dechm.php");
for ($i=0;$i<count($lines);$i++) {
$name=@preg_replace("~([^\s]*[\s]*){8}\s{1}(.*)~m","\\2",$lines[$i]);
$size=@preg_replace("~([^\s]*[\s]*){4}\s{1}([^\s]*)(.*)~m","\\2",$lines[$i]);
if (($name<>".")&&($name<>"..")) {$rname=$name;
if (strpos($name,".htaccess")!==false) {
$name=str_replace(".htaccess",".|htaccess",$name);
}
$chm=@preg_replace("~([^\s]*).*~m","\\1",$lines[$i]);
$nchm=dechm($chm);
if ($chm[0]=="-") {
if ($shs==1) {
if ($size<100) {$sz="; ".$size."B";}
elseif ($size<1024) {$sz="; ".str_replace(".",",",round($size/1024,3))."kB";}
elseif ($size<102400) {$sz="; ".round($size/1024,3)."kB";}
else {$sz="; ".str_replace(".",",",round($size/1024/1024,3))."MB";}
} else {$sz="";}
if ($ib==1) {
$rf=strtolower(preg_replace("~.*\.([^.]*)~m","\\1",str_replace('|','',$name)));
if ($rf==NULL) {$rf="?";}
$icn="<img src=\"img/unkn.png\" width=\"16\" height=\"16\" alt=\".\"/>";
$ar1=array("3gp","avi","bmp","doc","exe","gif","htm","html","jpg","jpe","jpeg",
"mdb","mid","midi","mp3","php","png","ppt","psd","rar","rtf","ttf","wav","wml",
"xls","xml","wmv","txt","zip","tar","tgz","tbz","tgz2","tbz2","fla","swf",
"htaccess","css","py","log","ini","jar","jad","sql");
$ar2=array("3gp","avi","bmp","doc","exe","gif","htm","htm","jpg","jpg","jpg",
"mdb","mid","mid","mp3","php","png","ppt","psd","rar","rtf","ttf","wav","wml",
"xls","xml","wmv","txt","zip","rar","rar","rar","rar","rar","fla","swf",
"htaccess","css","py","log","css","jar","jad","sql");
$ct=count($ar1);
for ($j=0;$j<$ct;$j++) {
if ($rf==$ar1[$j]) {
$icn="<img src=\"img/".$ar2[$j].".png\" width=\"16\" height=\"16\" alt=\".\"/>";
break;
}
}
} else {$icn="";}
$fnm[]="$icn<input type=\"checkbox\" name=\"f[]\" id=\"f[]\" value=\"$rname\" /><a href=\"file.php?k=$skey&amp;d=".rawurlencode($dr)."&amp;n=".rawurlencode($name)."\">$rname</a> [<a href=\"chmod.php?k=$skey&amp;d=".rawurlencode($dr)."&amp;n=".rawurlencode($name)."&amp;ch=$nchm\">$nchm</a>$sz]";
} else {
if ($ib==1) {
$icn="<img src=\"img/cldir.png\" width=\"16\" height=\"16\" alt=\"&gt;\"/>";
} else {$icn="&gt;";}
$dnm[]="$icn<a href=\"ftp.php?k=$skey&amp;d=".rawurlencode($dr)."&amp;n=".rawurlencode($name)."\">$rname</a> [<a href=\"chmod.php?k=$skey&amp;d=".rawurlencode($dr)."&amp;n=".rawurlencode($name)."&amp;ch=$nchm\">$nchm</a>]";
}
}
}
if ($fnm==NULL) {return $dnm;}
elseif ($dnm==NULL) {return $fnm;}
else {return array_merge($dnm,$fnm);}
}
?>
