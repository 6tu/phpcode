<?php
header('Location: detector.php');
exit;
?>
