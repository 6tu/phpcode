<?php
// Load the class
//require_once('library/ZipFolder.php');

// Create a class object
//$folder = new ZipFolder();

// Set the load path of the compressed archive
//$folder->setSavePath("C:/wamp/www/ZipFolder/");

// Set the zip file to be uncompressed
//$folder->setFile('SampleArchive.zip');

// Set the name of the folder where the zip file will be uncompressed
//$folder->setFolder("NewFolder");

// Set the save path of the uncompressed archive
//$folder->setSavePath("C:/wamp/www/ZipFolder/Test/");

// Once the parameters have been set we will uncompress the zip file
//$folder->openZip();

// After the zip folder has been uncompressed we will delete it
//$folder->eraseZip();
?>
