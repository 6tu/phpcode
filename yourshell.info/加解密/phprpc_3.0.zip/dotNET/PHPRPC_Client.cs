/**********************************************************\
|                                                          |
| The implementation of PHPRPC Protocol 3.0                |
|                                                          |
| PHPRPC_Client.cs                                         |
|                                                          |
| Release 3.0.0                                            |
| Copyright (c) 2005-2008 by Team-PHPRPC                   |
|                                                          |
| WebSite:  http://www.phprpc.org/                         |
|           http://www.phprpc.net/                         |
|           http://www.phprpc.com/                         |
|           http://sourceforge.net/projects/php-rpc/       |
|                                                          |
| Authors:  Ma Bingyao <andot@ujn.edu.cn>                  |
|                                                          |
| This file may be distributed and/or modified under the   |
| terms of the GNU Lesser General Public License (LGPL)    |
| version 3.0 as published by the Free Software Foundation |
| and appearing in the included file LICENSE.              |
|                                                          |
\**********************************************************/

/* PHPRPC Client library.
 *
 * Copyright (C) 2005-2008 Ma Bingyao <andot@ujn.edu.cn>
 * Version: 3.0.0
 * LastModified: Feb 24, 2008
 * This library is free.  You can redistribute it and/or modify it.
 */

namespace org.phprpc {
    using System;
    using System.Collections;
    using System.IO;
    using System.Net;
    using System.Reflection;
    using System.Text;
    using System.Text.RegularExpressions;
    using org.phprpc.util;

    public class PHPRPC_Client {
        private Int32 timeout = 30000;
        private Byte[] key = null;
        private Uri url = null;
        private UInt32 keylen = 128;
        private Byte encryptMode = 0;
        private Encoding encoding = Encoding.UTF8;
        private String output = String.Empty;
        private PHPRPC_Error warning = null;
        private IWebProxy proxy = null;
        private ICredentials credentials = null;
        private Double serverVersion = 0;
        private String cookie = null;

#if (PocketPC || Smartphone || WindowsCE)
        private static Assembly[] assemblies = new Assembly[] { Assembly.GetCallingAssembly(), Assembly.GetExecutingAssembly() };
#else
        private static Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
#endif
        private PHPFormatter formatter = null;

        public PHPRPC_Client() {
            formatter = new PHPFormatter(Encoding.UTF8, assemblies);
        }

        public PHPRPC_Client(String serverURL) : this() {
            UseService(serverURL);
        }

        public UInt32 KeyLength {
            get {
                return keylen;
            }
            set {
                if (key == null) {
                    keylen = value;
                }
            }
        }

        public Byte EncryptMode {
            get {
                return encryptMode;
            }
            set {
                if ((value >= 0) && (value <= 3)) {
                    encryptMode = value;
                }
                else {
                    encryptMode = 0;
                }
            }
        }

        public String Charset {
            get {
                return encoding.WebName;
            }
            set {
                encoding = Encoding.GetEncoding(value);
                formatter.Encoding = encoding;
            }
        }

        public Int32 Timeout {
            get {
                return timeout;
            }
            set {
                timeout = value;
            }
        }

        public String Output {
            get {
                return output;
            }
        }

        public PHPRPC_Error Warning {
            get {
                return warning;
            }
        }

        public IWebProxy Proxy {
            get {
                return proxy;
            }
            set {
                proxy = value;
            }
        }

        public ICredentials Credentials {
            get {
                return credentials;
            }
            set {
                credentials = value;
            }
        }

        public Boolean UseService(String serverURL) {
            url = new Uri(serverURL);
            if (!url.Scheme.Equals("http") && !url.Scheme.Equals("https")) {
                url = null;
                return false;
            }
            key = null;
            keylen = 128;
            encryptMode = 0;
            encoding = Encoding.UTF8;
            formatter.Encoding = encoding;
            return true;
        }

#if !(PocketPC || Smartphone || WindowsCE)
        public Object UseService(Type type) {
            PHPRPC_InvocationHandler handler = new PHPRPC_InvocationHandler(this);
            if (type.IsInterface) {
                return DynamicProxy.NewInstance(AppDomain.CurrentDomain, new Type[] { type }, handler);
            }
            else {
                return DynamicProxy.NewInstance(AppDomain.CurrentDomain, type.GetInterfaces(), handler);
            }
        }

        public Object UseService(Type[] interfaces) {
            PHPRPC_InvocationHandler handler = new PHPRPC_InvocationHandler(this);
            return DynamicProxy.NewInstance(AppDomain.CurrentDomain, interfaces, handler);
        }

        public Object UseService(String serverURL, Type type) {
            if (UseService(serverURL)) {
                return UseService(type);
            }
            else {
                return null;
            }
        }

        public Object UseService(String serverURL, Type[] interfaces) {
            if (UseService(serverURL)) {
                return UseService(interfaces);
            }
            else {
                return null;
            }
        }
#endif

        public Object Invoke(String function, Object[] args) {
            return Invoke(function, args, false);
        }

        public Object Invoke(String function, Object[] args, Boolean byRef) {
            try {
                KeyExchange();
                StringBuilder requestBody = new StringBuilder();
                requestBody.Append("phprpc_func=").Append(function);
                if (args != null && args.Length > 0) {
                    requestBody.Append("&phprpc_args=");
                    requestBody.Append(Base64Encode(Encrypt(Serialize(args), 1)).Replace("+", "%2B"));
                }
                requestBody.Append("&phprpc_encrypt=").Append(encryptMode);
                if (!byRef) {
                    requestBody.Append("&phprpc_ref=false");
                }
                Hashtable result = POST(requestBody.ToString());
                Int32 errno = (Int32)result["phprpc_errno"];
                if (errno > 0) {
                    String errstr = (String)result["phprpc_errstr"];
                    warning = new PHPRPC_Error(errno, errstr);
                }
                else {
                    warning = null;
                }
                if (result.ContainsKey("phprpc_output")) {
                    output = (String)result["phprpc_output"];
                }
                else {
                    output = String.Empty;
                }
                if (result.ContainsKey("phprpc_result")) {
                    if (result.ContainsKey("phprpc_args")) {
                        Object[] arguments = (Object[])PHPConvert.ToArray((AssocArray)Deserialize(Decrypt((Byte[])result["phprpc_args"], 1)), typeof(Object[]));
                        for (Int32 i = 0; i < Math.Min(args.Length, arguments.Length); i++) {
                            args[i] = arguments[i];
                        }
                    }
                    return Deserialize(Decrypt((Byte[])result["phprpc_result"], 2));
                }
                else {
                    return warning;
                }
            }
            catch (PHPRPC_Error e) {
                return e;
            }
            catch (Exception e) {
                return new PHPRPC_Error(1, e.ToString());
            }
        }

        private void KeyExchange() {
            if (key != null || encryptMode == 0) {
                return;
            }
            Hashtable result = POST("phprpc_encrypt=true&phprpc_keylen=" + keylen);
            if (result.ContainsKey("phprpc_keylen")) {
                keylen = (UInt32)result["phprpc_keylen"];
            }
            else {
                keylen = 128;
            }
            if (result.ContainsKey("phprpc_encrypt")) {
                AssocArray encrypt = (AssocArray)Deserialize((Byte[])result["phprpc_encrypt"]);
                BigInteger x = BigInteger.GenerateRandom((Int32)keylen - 1);
                x.SetBit(keylen - 2);
                BigInteger y = BigInteger.Parse(PHPConvert.ToString(encrypt["y"]));
                BigInteger p = BigInteger.Parse(PHPConvert.ToString(encrypt["p"]));
                BigInteger g = BigInteger.Parse(PHPConvert.ToString(encrypt["g"]));
                if (keylen == 128) {
                    this.key = new byte[16];
                    Byte[] k = y.ModPow(x, p).GetBytes();
                    for (Int32 i = 1, n = Math.Min(k.Length, 16); i <= n; i++) {
                        this.key[16 - i] = k[n - i];
                    }
                }
                else {
                    key = MD5.Hash(Encoding.ASCII.GetBytes(y.ModPow(x, p).ToString()));
                }
                POST("phprpc_encrypt=" + g.ModPow(x, p).ToString());
            }
            else {
                key = null;
                encryptMode = 0;
            }
        }

        private Hashtable POST(String requestString) {
            HttpWebRequest request = WebRequest.Create(url) as HttpWebRequest;
            request.Method = "POST";
            request.Accept = "*.*";
            request.AllowWriteStreamBuffering = true;
            request.SendChunked = false;
            request.KeepAlive = true;
#if (PocketPC || Smartphone || WindowsCE)
            request.UserAgent = "PHPRPC Client 3.0 for .NET Compact Framework";
#else
            request.UserAgent = "PHPRPC Client 3.0 for .NET Framework";
#endif
            request.ContentType = String.Concat("application/x-www-form-urlencoded; charset=", Charset);
            if (proxy != null) {
                request.Proxy = proxy;
            }
            else {
                request.Proxy = GlobalProxySelection.GetEmptyWebProxy();
            }
            if (cookie != null) {
                request.Headers["Cookie"] = cookie;
            }
            request.Credentials = credentials;
            request.Timeout = timeout;
            Byte[] buf = encoding.GetBytes(requestString);
            request.ContentLength = buf.Length;
            Stream rs = request.GetRequestStream();
            rs.Write(buf, 0, buf.Length);
            rs.Close();
            HttpWebResponse response = request.GetResponse() as HttpWebResponse;
            String xPoweredBy = response.GetResponseHeader("X-Powered-By");
            Int32 pos = xPoweredBy.IndexOf("PHPRPC Server/");
            if (pos < 0) {
                response.Close();
                throw new PHPRPC_Error(1, "Illegal PHPRPC Server!");
            }
            else {
                serverVersion = Double.Parse(xPoweredBy.Substring(pos + 14));
            }
            String cookies = response.GetResponseHeader("Set-Cookie");
            if (cookies != String.Empty) {
                cookies = RemoveCookie(cookies, "path=");
                cookies = RemoveCookie(cookies, "domain=");
                cookies = RemoveCookie(cookies, "expires=");
                cookie = cookies;
            }
            return GetResponseBody(response);
        }

        private String RemoveCookie(String cookies, String name) {
            Int32 pos1 = cookies.IndexOf(name);
            if (pos1 > -1) {
                Int32 pos2 = cookies.IndexOf(';', pos1);
                Int32 count = 0;
                if (pos2 == -1) {
                    count = cookies.Length - pos1;
                }
                else {
                    count = pos2 - pos1 + 1;
                }
                cookies = cookies.Remove(pos1, count);
            }
            return cookies;
        }

        private Hashtable GetResponseBody(HttpWebResponse response) {
            StreamReader sr = new StreamReader(response.GetResponseStream());
            Hashtable result = new Hashtable();
            String buf;
            while ((buf = sr.ReadLine()) != null) {
                Int32 pos = buf.IndexOf('=');
                if (pos > -1) {
                    String left = buf.Substring(0, pos);
                    String right = buf.Substring(pos + 2, buf.Length - pos - 4);
                    if (left.Equals("phprpc_errno")) {
                        result[left] = Int32.Parse(right);
                    }
                    else if (left.Equals("phprpc_keylen")) {
                        result[left] = UInt32.Parse(right);
                    }
                    else {
                        result[left] = Base64Decode(right);
                        if (left.Equals("phprpc_errstr")) {
                            Byte[] bytes = (Byte[])result[left];
                            result[left] = encoding.GetString(bytes, 0, bytes.Length);
                        }
                        else if (left.Equals("phprpc_output")) {
                            Byte[] bytes = (Byte[])result[left];
                            if (serverVersion >= 3) {
                                bytes = Decrypt(bytes, 3);
                            }
                            result[left] = encoding.GetString(bytes, 0, bytes.Length);
                        }
                    }
                }
            }
            sr.Close();
            response.Close();
            return result;
        }

        private Byte[] Serialize(Object obj) {
            MemoryStream ms = new MemoryStream();
            formatter.Serialize(ms, obj);
            Byte[] result = ms.ToArray();
            ms.Close();
            return result;
        }

        private Object Deserialize(Byte[] data) {
            MemoryStream ms = new MemoryStream(data);
            ms.Position = 0;
            Object result = formatter.Deserialize(ms);
            ms.Close();
            return result;
        }

        private Byte[] Encrypt(Byte[] data, Byte level) {
            if (key != null && encryptMode >= level) {
                data = XXTEA.Encrypt(data, key);
            }
            return data;
        }

        private Byte[] Decrypt(Byte[] data, Byte level) {
            if (key != null && encryptMode >= level) {
                data = XXTEA.Decrypt(data, key);
            }
            return data;
        }

        private String Base64Encode(Byte[] data) {
            return Convert.ToBase64String(data, 0, data.Length);
        }

        private Byte[] Base64Decode(String data) {
            if (data == null) {
                return null;
            }
            if (data == String.Empty) {
                return new Byte[0];
            }
            return Convert.FromBase64String(data);
        }

    }
}
