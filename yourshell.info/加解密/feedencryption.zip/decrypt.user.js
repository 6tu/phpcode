// ==UserScript==
// @name            Google Reader Feed Decryption
// @namespace       http://www.kuederle.com/
// @description     Decrypts an encrypted RSS feed in Google Reader. Only useful in conjunction with the feed encryption scripts found on the script's website. In order to use this script properly, you must set its encryption key to the one you used to encrypt your file. Do this by editing this script before installing it.
// @include         http://reader.google.com/reader/*
// @include         https://reader.google.com/reader/*
// @include         http://www.google.com/reader/*
// @include         https://www.google.com/reader/*
// ==/UserScript==

// The only thing to do is to change this following value exactly to the
// one you used to encrypt your feed.
var encryptionKey = "editThisVariable"; // To be sure, use only a-z, A-Z, 0-9 characters for your key.

/**
 * This function is called when a new entry has been
 * added.
 *
 * @param event The event.
 */
function onEntryAdded(event)
{
	var index;
    var element = event.target;
    if (element.nodeName=='DIV' && element.className.indexOf('entry')>-1) {
		var regEx = new RegExp(/\$bfencstart\$([^$]*)\$bfencend\$/g);
		var match,code,index,length,changed=false;
		var decrypted = element.innerHTML;
		while(match = regEx.exec(element.innerHTML)) {
			changed=true;
			
			// Remove spaces and line breaks.
			code = match[1].replace(/[^A-F0-9]+/gi,"");
			
			index = decrypted.indexOf(match[0]);
			length = match[0].length;
			decrypted = decrypted.substr(0,index)+xxtea_decrypt(dehexify(code),encryptionKey)+decrypted.substr(index+length);
		}
		if(changed)
			element.innerHTML = decrypted;
    }
}

// Run when new entries are loaded.
document.body.addEventListener('DOMNodeInserted', onEntryAdded, false);

// The following code was taken from: http://www.coolcode.cn/show-128-1.html
 
function long2str(v, w) {
    var vl = v.length;
    var n = (vl - 1) << 2;
    if (w) {
        var m = v[vl - 1];
        if ((m < n - 3) || (m > n)) return null;
        n = m;
    }
    for (var i = 0; i < vl; i++) {
        v[i] = String.fromCharCode(v[i] & 0xff,
                                   v[i] >>> 8 & 0xff,
                                   v[i] >>> 16 & 0xff,
                                   v[i] >>> 24 & 0xff);
    }
    if (w) {
        return v.join('').substring(0, n);
    }
    else {
        return v.join('');
    }
}
 
function str2long(s, w) {
    var len = s.length;
    var v = [];
    for (var i = 0; i < len; i += 4) {
        v[i >> 2] = s.charCodeAt(i)
                  | s.charCodeAt(i + 1) << 8
                  | s.charCodeAt(i + 2) << 16
                  | s.charCodeAt(i + 3) << 24;
    }
    if (w) {
        v[v.length] = len;
    }
    return v;
}
 
function xxtea_encrypt(str, key) {
    if (str == "") {
        return "";
    }
    var v = str2long(str, true);
    var k = str2long(key, false);
    if (k.length < 4) {
        k.length = 4;
    }
    var n = v.length - 1;
 
    var z = v[n], y = v[0], delta = 0x9E3779B9;
    var mx, e, p, q = Math.floor(6 + 52 / (n + 1)), sum = 0;
    while (0 < q--) {
        sum = sum + delta & 0xffffffff;
        e = sum >>> 2 & 3;
        for (p = 0; p < n; p++) {
            y = v[p + 1];
            mx = (z >>> 5 ^ y << 2) + (y >>> 3 ^ z << 4) ^ (sum ^ y) + (k[p & 3 ^ e] ^ z);
            z = v[p] = v[p] + mx & 0xffffffff;
        }
        y = v[0];
        mx = (z >>> 5 ^ y << 2) + (y >>> 3 ^ z << 4) ^ (sum ^ y) + (k[p & 3 ^ e] ^ z);
        z = v[n] = v[n] + mx & 0xffffffff;
    }
 
    return long2str(v, false);
}
 
function xxtea_decrypt(str, key) {
    if (str == "") {
        return "";
    }
    var v = str2long(str, false);
    var k = str2long(key, false);
    if (k.length < 4) {
        k.length = 4;
    }
    var n = v.length - 1;
 
    var z = v[n - 1], y = v[0], delta = 0x9E3779B9;
    var mx, e, p, q = Math.floor(6 + 52 / (n + 1)), sum = q * delta & 0xffffffff;
    while (sum != 0) {
        e = sum >>> 2 & 3;
        for (p = n; p > 0; p--) {
            z = v[p - 1];
            mx = (z >>> 5 ^ y << 2) + (y >>> 3 ^ z << 4) ^ (sum ^ y) + (k[p & 3 ^ e] ^ z);
            y = v[p] = v[p] - mx & 0xffffffff;
        }
        z = v[n];
        mx = (z >>> 5 ^ y << 2) + (y >>> 3 ^ z << 4) ^ (sum ^ y) + (k[p & 3 ^ e] ^ z);
        y = v[0] = v[0] - mx & 0xffffffff;
        sum = sum - delta & 0xffffffff;
    }
 
    return long2str(v, true);
}

// The following code was taken from: http://www.babelfish.nl/?view=actTEA

function hexify(oct) {
   var res="";
   for (var i=0; i<oct.length; ) {
      var b = oct.charCodeAt(i++);
      res+='0123456789ABCDEF'.charAt(b>>4&0xF);
      res+='0123456789ABCDEF'.charAt(b&0xF);
   }
   return res;
}

function dehexify(hex) {//assumes even number of hex digits
   var res="";
   for (var i=0; i<hex.length; ) {
      var b = hex.charCodeAt(i++);
      var c = hex.charCodeAt(i++);
      res += String.fromCharCode(((b-(b>64?55:48))<<4)+c-(c>64?55:48));
   }
   return res;
}
