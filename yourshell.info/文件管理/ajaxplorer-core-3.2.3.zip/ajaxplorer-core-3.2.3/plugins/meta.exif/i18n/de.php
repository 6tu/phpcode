<?php

$mess = array(
"1" => "Exif Ortsangabe", 
"2" => "Karte", 
);

?>
