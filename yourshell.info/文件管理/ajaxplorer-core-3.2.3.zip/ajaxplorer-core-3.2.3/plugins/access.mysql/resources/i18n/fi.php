<?php
//---------------------------------------------------------------------------------------------------
//							
//	AjaXplorer
//	
//	Copyright 2007-2008 Charles du Jeu - LGPL
//  www.Ajaxplorer.info
//
//	Finnish translation by Aleksi Postari
//	aleksi (at) postari.net
//	Last update: 07.09.2010
// 
//---------------------------------------------------------------------------------------------------

$mess=array(
"1" => "Luo taulu",
"2" => "Syötä SQL lauseesi tähän",
"3"	=> "Hae",
"4"	=> "Tyhjennä"
);
?>
