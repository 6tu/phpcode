<?php
//---------------------------------------------------------------------------------------------------
//							
//	AjaXplorer
//	
//	Copyright 2007-2008 Charles du Jeu - LGPL
//  www.Ajaxplorer.info
//
//  Reference dictionnary for translations
// Slovenian translation: April 21 2011 by Vladimir Bohinc (vladimir.bohinc@gmail.com)
// 
//---------------------------------------------------------------------------------------------------
$mess=array(
"1"	=> "Urejevalnik izvorne kode",
"2"	=> "Označevalnik sintakse CodeMirror",
"3" => "Ovijanje",
"3b"=> "Preklop ovijanja kode",
"4" => "Oštevilčenje",
"5" => "Preklop oštevilčenja vrstic",
"6"	=> "Pojdi v vrstico",
"7" => "Razveljavi",
"8"	=> "Uveljavi",
"9"	=> "Iskanje besedila",
"10" => "Velikost zamika"
);
?>