<?php
//---------------------------------------------------------------------------------------------------
//							
//	AjaXplorer
//	
//	Copyright 2007-2008 Charles du Jeu - LGPL
//  www.Ajaxplorer.info
//
//  Reference dictionnary for translations
// Slovenian translation: April 21 2011 by Vladimir Bohinc (vladimir.bohinc@gmail.com)
// 
//---------------------------------------------------------------------------------------------------
$mess=array(
"1" => "Metapodatki",
"2" => "Brez oznake",
"3" => "Odstrani oceno",
"4" => "Nepomembno",
"5" => "Opravilo",
"6" => "Osebno",
"7" => "Služba", 
"8" => "Pomembno"
);
?>
