<?php

$mess=array(
"1" => "Name",
"2" => "Titel",
"3" => "Abfragbar",
"4" => "Style",
"5" => "Stichwörter",
"6" => "Vorschau",
)

?>
