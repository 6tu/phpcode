<?php
//---------------------------------------------------------------------------------------------------
//							
//	AjaXplorer
//	
//	Copyright 2007-2008 Charles du Jeu - LGPL
//  www.Ajaxplorer.info
//
//  Reference dictionnary for translations
// Slovenian translation: April 21 2011 by Vladimir Bohinc (vladimir.bohinc@gmail.com)
// 
//---------------------------------------------------------------------------------------------------
$mess = array(
"name" => "Pregledovalnik e-pošte",
"title" => "Pregledovalnik elektronskih sporočil",
"1" => "Od",
"2" => "Za",
"3" => "Zadeva",
"4"	=> "Datum",
"5" => "Priloge",
"6" => "Prenesi e-pošto",
"7" => "Priloga %s je bila uspešno kopirana v %s",
"8" => "Ciljne datoteke ni bilo mogoče odpreti!",
"9" => "Priloge ni bilo mogoče najti!",
"10" => "Prenesi ",
"11" => "Kopiraj prilogo na strežnik",
"12" => "Kk",
);
?>