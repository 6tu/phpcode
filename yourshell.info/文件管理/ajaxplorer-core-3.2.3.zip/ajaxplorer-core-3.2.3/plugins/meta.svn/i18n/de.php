<?php

$mess = array(
"1" => "Versionen", 
"11" => "SVN-Log des aktuellen Verzeichnisses", 
"2" => "Log auswählen",
"21" => "SVN-Log der ausgewählen Datei oder des Verzeichnisses",
"3" => "Zu Revision wechseln",
);

?>
