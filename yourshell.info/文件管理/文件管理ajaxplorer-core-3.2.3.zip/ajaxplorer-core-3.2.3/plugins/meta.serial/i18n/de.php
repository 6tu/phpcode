<?php
//---------------------------------------------------------------------------------------------------
//							
//	AjaXplorer
//	
//	Copyright 2007-2010 Charles du Jeu - LGPL
//  www.Ajaxplorer.info
//
//	german translation: Axel Otterstätter <axel.otterstaetter@googlemail.com>
// 
//---------------------------------------------------------------------------------------------------

$mess=array(
"1" => "Datei Metadaten",
"2" => "Kein Label",
"3" => "Bewertung entfernen",
"4" => "Niedrig",
"5" => "Todo",
"6" => "Persönlich",
"7" => "Arbeit", 
"8" => "Wichtig"
);
?>
