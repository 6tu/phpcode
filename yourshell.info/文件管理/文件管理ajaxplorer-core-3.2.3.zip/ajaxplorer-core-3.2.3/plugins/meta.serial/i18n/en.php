<?php
//---------------------------------------------------------------------------------------------------
//							
//	AjaXplorer
//	
//	Copyright 2007-2010 Charles du Jeu - LGPL
//  www.Ajaxplorer.info
//
//  Reference dictionnary for translations
// 
//---------------------------------------------------------------------------------------------------

$mess=array(
"1" => "File Meta Data",
"2" => "No Label",
"3" => "Remove Rating",
"4" => "Low",
"5" => "Todo",
"6" => "Personal",
"7" => "Work", 
"8" => "Important"
);
?>
