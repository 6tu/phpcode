<?php
//---------------------------------------------------------------------------------------------------
//							
//	AjaXplorer
//	
//	Copyright 2007-2008 Charles du Jeu - LGPL
//  www.Ajaxplorer.info
//
//  Reference dictionnary for translations
// Slovenian translation: April 21 2011 by Vladimir Bohinc (vladimir.bohinc@gmail.com)
// 
//---------------------------------------------------------------------------------------------------
$mess = array(
"1" => "Razredi in vmesniki",
"2" => "Lastnosti in metode",
"3" => "Izvorna koda"
); 
?>