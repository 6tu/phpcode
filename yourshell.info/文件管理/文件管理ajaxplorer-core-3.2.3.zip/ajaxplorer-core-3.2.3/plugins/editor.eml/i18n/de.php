<?php 
$mess = array(
"name" => "E-Mail Betrachter",
"title" => "E-Mail Betrachter",
"1" => "Von",
"2" => "An",
"3" => "Betreff",
"4"	=> "Datum",
"5" => "Anhänge",
"6" => "Download EML",
"7" => "Anhang %s wurde erfolgreich nach %s kopiert.",
"8" => "Zieldatei konnte nicht geöffnet werden!",
"9" => "Anhang wurde nicht gefunden!",
"10" => "Download ",
"11" => "Kopieren des Anhangs auf den Server",
"12" => "Cc",
);
?>
