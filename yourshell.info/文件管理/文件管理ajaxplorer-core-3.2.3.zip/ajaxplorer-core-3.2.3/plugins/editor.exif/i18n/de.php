<?php

$mess = array(
"1" => "Exif Reader", 
"2" => "Exif Daten anzeigen", 
);

?>
