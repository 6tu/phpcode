<?php

$mess = array(
"1" => "Lector Exif", 
"2" => "Visualizar datos Exif", 
);

?>
