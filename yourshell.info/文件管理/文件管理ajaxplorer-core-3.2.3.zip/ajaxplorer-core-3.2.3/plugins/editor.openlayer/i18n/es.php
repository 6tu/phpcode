<?php

$mess=array(
"1" => "Mapa OpenLayers",
"2" => "Filro",
"3" => "Posición",
"4" => "Capas",
"5" => "Antialias",
"6" => "Formato",
"7" => "Estilos",
"8" => "Filtrar",
"9" => "Buscar",
"10" => "Limpiar",
)

?>
