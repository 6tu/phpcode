<br>
<br>
<br>
<br>
<div align="center" style="font-family:Arial, Helvetica, Sans-serif;font-size:25px;color:#AAA;font-weight:bold;">Please wait while closing Pixlr editor...</div>