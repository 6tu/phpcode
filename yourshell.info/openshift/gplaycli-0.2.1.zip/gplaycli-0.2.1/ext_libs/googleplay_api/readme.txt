These files come from the GooglePlayAPI project ( https://github.com/egirault/googleplay-api/ )
This project is released under the BSD license.
