<?php
#
# 神级狂婿岳风
# 
# 作者：吻天的狼
# 
# https://m.2yt.info/
# https://www.78zw.com/13_13141/
# https://www.dizishu.com/b/90831/

set_time_limit(0);
$base_path = $_SERVER['DOCUMENT_ROOT'] . '/book/';

date_default_timezone_set ('Asia/Hong_Kong');
$t = date("Ymd_H-i-s");

if(isset($_SERVER['HTTP_REFERER']) and (strpos($_SERVER['HTTP_REFERER'],'cron.php') !== false)){
    echo "收到来自于 cron.php 访问.<br>\r\n";
}

header("content-type:text/html;charset=utf-8");
$array = array('https://www.xbiquge.cc/book/51687/,           div#maininfo,     utf-8',
              );

$title = '极品赘婿--苏允柳媛   作者： 二五八';
$head = '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="">';
$head .= '<title>' . $title . "</title></head>\r\n<body>";
echo $head . '<h3>' . $title . '</h3>';

$u = '';
foreach ($array as $key => $value){
    $ex = explode(',', $value);
    $url = trim($ex[0]);
    $div = trim($ex[1]);
    $charset = trim($ex[2]);
    $res_array = getResponse($url);
    // $charset = $res_array['charset'];
    $html = $res_array['body'];
    // unlink($cookie_file);

    # phpQuery主要难点，编码转换
    if($charset == 'gbk') $html =  mb_convert_encoding($html,"utf-8", $charset);
    // file_put_contents('x.htm', $html);
    $main = getmaininfo($html, $div, $charset);
    if($charset == 'utf-8') $main =  mb_convert_encoding($main,"utf-8", "gbk");
    // file_put_contents('m.htm', $main);
    // echo $main;

    //$main = str_replace('>', ">\r\n", $main);
    $arr_c = explode("\n",$main);
    foreach($arr_c as $l){
        if(strpos($l,'2020') !== false){
            $c = $l;
        }
    }

    $c = preg_replace ( "/\s(?=\s)/","\\1",$c);
    $c = str_replace("\t", '', $c);
    $c = strip_tags($c, "<br>");
    $u .= $c;
    $out = "\r\n<br><b>$key => <a href=$url > $url </a></b><br>\r\n" . $c . "<br>\r\n";
    echo $out;
}

unset($ex);

# 更新数据记录
$bak_ufn = $base_path . $t . '_uf.txt'; 
$bak_ufn = $base_path . '_uf.txt' ;
$ufn = $base_path . 'uf.txt';
if(!file_exists($ufn)) file_put_contents($ufn, '');
$uf = file_get_contents($ufn);
if($u !== $uf){
    @rename($ufn, $bak_ufn);
    file_put_contents($ufn, $u);
    file_get_contents('http://pub.6tu.me/caiji/xbiquge-list.php');
    file_get_contents('http://pub.6tu.me/caiji/xbiquge.php');
}

echo "\r\n<br><b>已有更新？<a href='xbiquge-list.php'>更新目录</a> 和 <a href='xbiquge.php'>更新章节</a></b>\r\n";


echo "\r\n<br><hr  size='1px' width='300' align='left' />\r\n";

$more = array( 'https://www.xiaoshuobi.cc/read/81849/,          div#maininfo,     utf-8',
               'http://www.kanshu8.net/book/6774/,              div.pt-bookdetail,     ',
               'https://m.mingrenteahouse.com/shu/60944.html,   div.book-info,    utf-8',
               'https://m.63xs.com/book/96935/,                 div.block_txt2,   gbk  ',
               'https://www.uczw.com/html/46/46068/,            div#maininfo,     gbk  ',
               'https://www.tianyabook.com/shu/15886.html,      div.col-md-10,    utf-8',
               'http://www.biqugexs.com/26_26824/,              div#maininfo,     gbk  ',
               'https://www.78zw.com/6_6285/,                   div#maininfo,     gbk  ',
              );
foreach ($more as $key => $value){
    $ex = explode(',', $value);
    $url = trim($ex[0]);
    $out = "\r\n<br>$key => <a href=$url > $url </a>\r\n";
    echo $out;
}

function getmaininfo($html, $div, $charset){
    require_once('./lib/phpQuery/phpQuery.php');
    phpQuery :: $defaultCharset = 'utf-8';
    $html = phpQuery :: newDocumentHTML($html, $charset = '');
    $title = pq("title") -> text();
    $maininfo = pq($div) -> html();
    return($maininfo);
}

# $res_array = array();
# $res_array['header']    = $header_all;
# $res_array['status']    = $status[1];
# $res_array['mime_type'] = $mime_type;
# $res_array['charset']   = $charset;
# $res_array['body']      = $body;

# 支持GET和POST,返回值网页内容，报头，状态码，mime类型和编码 charset
function getResponse($url, $data = [], $cookie_file = ''){

    $url_array = parse_url($url);
    $host = $url_array['scheme'] . '://' . $url_array['host'];
    if(!empty($_SERVER['HTTP_REFERER'])) $refer = $_SERVER['HTTP_REFERER'];
    else $refer = $host . '/';
    if(!empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) $lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
    else $lang = 'zh-CN,zh;q=0.9';
    if(!empty($_SERVER['HTTP_USER_AGENT'])) $agent = $_SERVER['HTTP_USER_AGENT'];
    else $agent = 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.67 Safari/537.36';
    // $agent = 'Wget/1.18 (mingw32)'; # 'Wget/1.17.1 (linux-gnu)';
    // echo "<pre>\r\n" . $agent . "\r\n" . $refer . "\r\n" . $lang . "\r\n\r\n";
    $agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36';
    if(empty($cookie_file)){
        $cookie_file = '.cookie';
    }
	
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_USERAGENT, $agent);
    curl_setopt($ch, CURLOPT_REFERER, $refer);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Accept-Language: " . $lang));
    if(!empty($data)){
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);   # 302 重定向
    curl_setopt($ch, CURLOPT_AUTOREFERER, true);      # 301 重定向

    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_file);  # 取cookie的参数是
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file); # 发送cookie
	
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($ch);
    curl_close($ch);
	
	# try{}catch{}语句
    // try{
    //     $handles = curl_exec($ch);
    //     curl_close($ch);
    //     return $handles;
    // }
    // catch(Exception $e){
    //     echo 'Caught exception:', $e -> getMessage(), "\n";
    // }
    // unlink($cookie_file);

    $res_array = explode("\r\n\r\n", $result, 2);
    $headers = explode("\r\n", $res_array[0]);
    $status = explode(' ', $headers[0]);
    # 如果$headers为空，则连接超时
    if(empty($res_array[0])) die('<br><br><center><b>连接超时</b></center>');
    # 如果$headers状态码为404，则自定义输出页面。
    if($status[1] == '404') die("<pre><b>找不到，The requested URL was not found on this server.</b>\r\n\r\n$res_array[0]</pre>\r\n\r\n");
    # 如果$headers第一行没有200，则连接异常。
    # if($status[1] !== '200') die("<pre><b>连接异常，状态码： $status[1]</b>\r\n\r\n$res_array[0]</pre>\r\n\r\n");\

    if($status[1] !== '200'){
        $body_array = explode("\r\n\r\n", $res_array[1], 2);
        $header_all = $res_array[0] . "\r\n\r\n" . $body_array[0];
        $res_array[0] = $body_array[0];
        $body = $body_array[1];
    }else{
        $header_all = $res_array[0];
        $body = $res_array[1];
    }

    $headers = explode("\r\n", $res_array[0]);
    $status = explode(' ', $headers[0]);
    
    $headers[0] = str_replace('HTTP/1.1', 'HTTP/1.1:', $headers[0]);
    foreach($headers as $header){
        if(stripos(strtolower($header), 'content-type:') !== FALSE){
            $headerParts = explode(' ', $header);
            $mime_type = trim(strtolower($headerParts[1]));
            //if(!empty($headerParts[2])){
            //    $charset_array = explode('=', $headerParts[2]);
            //    $charset = trim(strtolower($charset_array[1]));
            //}
        }
        if(stripos(strtolower($header), 'charset') !== FALSE){
            $charset_array = explode('charset=', $header);
            $charset = trim(strtolower($charset_array[1]));
        }else{
            $charset = preg_match("/<meta.+?charset=[^\w]?([-\w]+)/i", $res_array[1], $temp) ? strtolower($temp[1]):"";
        }
    }
    if(empty($charset)) $charset = 'utf-8';
    if(strstr($charset, ';')){
        $charset_array = '';
        $charset_array = explode(';', $charset);
        $charset = trim($charset_array[0]);
        //$charset = str_replace(';', '', $charset);
    }
    if(strstr($mime_type, 'text/html') and $charset !== 'utf-8'){
        //$body = mb_convert_encoding ($body, 'utf-8', $charset);
    }
    # $body = preg_replace('/(?s)<meta http-equiv="Expires"[^>]*>/i', '', $body);    
    
    # echo "<pre>\r\n$header_all\r\n\r\n" . "$status[1]\r\n$mime_type\r\n$charset\r\n\r\n";
    # header($res_array[0]);

    $res_array = array();
    $res_array['header']    = $header_all;
    $res_array['status']    = $status[1];
    $res_array['mime_type'] = $mime_type;
    $res_array['charset']   = $charset;
    $res_array['body']      = $body;
    return $res_array;
}




