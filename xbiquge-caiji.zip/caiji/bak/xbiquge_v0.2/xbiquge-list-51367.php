<?php

set_time_limit(0);
$id = '51367/';
$url = 'https://www.xbiquge.cc/book/' . $id;
$base_path = $_SERVER['DOCUMENT_ROOT'] . '/book/';

# 扫描本地目录中的文件
$local_dir_array = scandir($base_path . $id);
$local_dir_array = array_diff($local_dir_array, [".", "..", "index.html"]);
file_put_contents($base_path . 'all.txt', print_r($local_dir_array, true));
echo "<pre><font size='4'>\r\nIt is recommended to run suyun.php first.<br>\r\n";
echo "Directory read complete.<br>\r\n";

# 从本地index.html中提取所有超链接及最后的一个链接
if(!file_exists($base_path . $id . 'index.html')){
    echo $base_path . $id ."index.html file does not exist.<br>\r\n";
    file_put_contents($base_path . $id . 'index.html', '');
}
$local_index = file_get_contents($base_path . $id . 'index.html');
preg_match_all('/<a[^<]+href="(.+?)"/is', $local_index, $local_link);
$local_index_last_link = $url . $local_link[1][0] . "\r\n";
echo "Latest links in index.html: <br>\r\n" . $local_index_last_link . "\r\n";

$local_diff = array_diff($local_link[1], $local_dir_array);
if(!empty($local_diff)){
    echo "本地文件与本地index.html中的链接存在差异:<br>\r\n"; 
    $local_diff_str = join($local_diff);
    $local_diff_str = str_replace('.html', ".html\r\n", $local_diff_str);
    echo $local_diff_str . "<br>";
}

# $local_index_last_link , $local_dir_array, $local_link[1]
/** --------------- 本地数据处理完毕 --------------- **/

# 获取源端index.html并重新排序后写入本地index.html
$chaset = 'gbk';
$div = 'div#list';
$remote_index = caiji_info($url, $chaset, $div);
$remote_index = str_replace("'", '"', $remote_index);
$remote_index_array_temp1 = explode('</dt>', $remote_index);
$remote_index_array_temp2 = explode("\n", $remote_index_array_temp1[1]);

$remote_index_array = array_reverse($remote_index_array_temp2);
$remote_index_str = join($remote_index_array);
$remote_index_str = $remote_index_array_temp1[0] . '</dt>' . $remote_index_str . "\r\n</dl>";
$remote_index_str = str_replace('</dd><dd>', "</dd>\r\n<dd>", $remote_index_str);
$remote_index_str = str_replace('</dt></dl>', "</dt>\r\n", $remote_index_str);
$remote_index_str = str_replace("<dl>\n", "\r\n<dl>", $remote_index_str);
file_put_contents($base_path . $id . 'index.html', $remote_index_str);
echo "The index.html file has been sussessfully updated.<br>\r\n";

# 本地文件和源端index.html中差异的超链接将写入 newurl.txt
preg_match_all('/<a[^<]+href="(.+?)"/is', $remote_index_str, $remote_link);
$remote_diff = array_diff($remote_link[1], $local_dir_array);
$diff_link = '';
if(!empty($remote_diff)){
    foreach($remote_diff as $remote_diff_str){
        if(empty($remote_diff_str)) continue;
        $diff_link .= $url . $remote_diff_str . "\r\n";
    }
}
if(empty($diff_link)) die("All files are already up-to-date.无需更新<br>\r\n");
echo "The following links will be UPDATED:<br>\r\n";
echo $diff_link . "<br>\r\n";
file_put_contents($base_path . 'newurl.txt', $local_index_last_link . $diff_link);
# 由于首页没有探测到文件名,而且代码处理不一致,故不能将网站首页加入到newurl.txt


function caiji_info($url, $chaset, $div){
    if(empty($url)) die('url is empty');
    if(empty($chaset)) $chaset = 'gbk';
    if(empty($div)) $div = 'div#maininfo';
    require_once('./lib/phpQuery/phpQuery.php');
    phpQuery :: $defaultCharset = $chaset;
    $html = phpQuery :: newDocumentFile($url);
    // $html = phpQuery::newDocument($html);
    $title = pq("title") -> text();
    $maininfo = pq($div) -> html();
    if($chaset == 'gbk') $maininfo = mb_convert_encoding($maininfo, 'utf-8', 'GBK');
    $head = '<!DOCTYPE html><html lang="zh-CN"><head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	';
    $head .= '<title>' . $title . '</title></head><body>';
    $output = $head . $maininfo;
    return $output;
}


?>