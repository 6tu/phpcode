<?php

# 更新章节
# 读取由 xbiquge-list.php 生成的newurl.txt的内容
# 按内容的URL更新文件

set_time_limit(0);

$id = '51367/';
$base_path = $_SERVER['DOCUMENT_ROOT'] . '/book/';
$path = $base_path . $id;

$chaset = 'gbk';
$div = 'div.content_read';

$foot = '<div class="footer_cont">
    <p>小说<a href="https://www.xbiquge.cc/book/51687/" title="极品赘婿">极品赘婿</a>所有内容均来自互联网，笔趣阁只为原作者二五八的小说进行宣传。欢迎各位书友支持二五八并收藏<a href="https://www.xbiquge.cc/book/51687/" title="极品赘婿">极品赘婿最新章节</a>。</p>
    </div>';

$list = file_get_contents($base_path . 'newurl.txt');

echo "<pre><font size='4'>\r\n";
if(empty($list)) die("newurl.txt is empty,try running xbiquge-list.php .或者无需更新<br>\r\n");
else echo "The following links will be UPDATED:<br>\r\n";

$array = explode("\r\n", $list);
foreach($array as $url){
    echo $url . "\r\n";
    $fn = basename($url);
	$new = $path . $fn;
    if(empty($url)) continue;
	$body = caiji_info($url, $chaset, $div);
	$array1 = explode('<div id="content" name="content">', $body);
	$array2 = explode('<div class="tjlist"', $array1[0]);
	$body = $array2[0] .'<div id="content" name="content">'. $array1[1];
	# 删除js
    $preg = "/<script[\s\S]*?<\/script>/i";
    $html = preg_replace($preg, "", $body, -1);
	$html = str_replace("https://www.xbiquge.cc", "", $html);
	$html .= $foot;
	file_put_contents($new, $html);
}

echo "Sussessfully updated<br>\r\n";
file_put_contents($base_path . 'newurl.txt', '');

function caiji_info($url, $chaset, $div){
    if(empty($url)) die('url is empty');
    if(empty($chaset)) $chaset = 'gbk';
    if(empty($div)) $div = 'div#maininfo';
    require_once('./lib/phpQuery/phpQuery.php');
    phpQuery :: $defaultCharset = $chaset;
    $html = phpQuery :: newDocumentFile($url);
    // $html = phpQuery::newDocument($html);
    $title = pq("title") -> text();
    $maininfo = pq($div) -> html();
    if($chaset == 'gbk') $maininfo = mb_convert_encoding($maininfo, 'utf-8', 'GBK');
    $head = '<!DOCTYPE html><html lang="zh-CN">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" type="text/css" href="/book/biqugecss/common.css" />
    <link rel="stylesheet" type="text/css" href="/book/biqugecss/read.css" />';
    $head .= '        <title>' . $title . '</title>
	</head>
	<body>';
    $output = $head . $maininfo;
    return $output;
}

?>